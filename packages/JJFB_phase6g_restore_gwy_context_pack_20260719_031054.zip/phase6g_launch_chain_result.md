# Phase 6G — launch chain result

- class: `?`
- CFG36: `yes`
- STARTGAME: `no`
- RUNAPP: `no`
- shell_summary: `?`

## Success ladder

- min (not SHELL_BYPASSED + shell open + no alias): `PENDING`
- mid (startGame/runapp + strCom): `PENDING`
