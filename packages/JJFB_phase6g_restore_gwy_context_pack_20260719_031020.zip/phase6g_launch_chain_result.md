# Phase 6G — launch chain result

- class: `SHELL_RUNAPP_CHAINED`
- CFG36: `yes`
- STARTGAME: `yes`
- RUNAPP: `yes`
- shell_summary: `[JJFB_GWY_SHELL_SUMMARY] class=SHELL_RUNAPP_CHAINED shell_open=yes gbrwcore=no gamelist=no gbrwshell=no jjfb_real=no jjfb_alias=no update_stub=no runapp_chained=yes stop=after_runapp_chain evidence=TARGET_OBSERVED`

## Success ladder

- min (not SHELL_BYPASSED + shell open + no alias): `PENDING`
- mid (startGame/runapp + strCom): `PASS`
