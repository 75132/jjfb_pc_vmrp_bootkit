# Phase 6G — resource root mapping

mythroad_root hint: `C:\Users\24231\Desktop\jjfb_pc_vmrp_bootkit\game_files\mythroad\240x320`
gwy_root hint: `C:\Users\24231\Desktop\jjfb_pc_vmrp_bootkit\game_files\mythroad\240x320/gwy`

| guest | host | ok | alias? |
|---|---|---|---|
| `mythroad/sdk_key.dat` | `C:\Users\24231\Desktop\jjfb_pc_vmrp_bootkit\out\vmrp_run\overlay/mythroad/sdk_key.dat` | 1 | no |
| `mythroad/sdk_key.dat` | `C:\Users\24231\Desktop\jjfb_pc_vmrp_bootkit\out\vmrp_run\overlay/mythroad/sdk_key.dat` | 1 | no |

- shell_package_opens≈0
- jjfb_alias_opens=0
- real_jjfb_opens≈0
- expected_gwy_dir=`C:\Users\24231\Desktop\jjfb_pc_vmrp_bootkit\game_files\mythroad\240x320\gwy`
