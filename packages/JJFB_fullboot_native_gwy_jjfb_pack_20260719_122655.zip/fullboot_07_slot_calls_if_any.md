# Full Boot 07 — Slot Calls

- SLOT_CALL count: 1

## SLOT_CALL

- `[JJFB_EXTCHUNK_SLOT_CALL] off=0x28 pc=0x280058 r0=0x1 r1=0x64 r2=0x0 r3=0x0 r4=0x1 ret=0x0 evidence=TARGET_OBSERVED`
