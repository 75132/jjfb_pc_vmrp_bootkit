# Full Boot 03 — Gamelist cfg36 / no_update

## CFG36_BUILD

- `[JJFB_GAMELIST_CFG36_BUILD] param_fmt_va=0x2E846C note=format_string_mapped evidence=TARGET_OBSERVED`
## POST_UPDATE

- (none)
## UPDATE_STUB

- `[JJFB_GWY_UPDATE_STUB] layer=gwy_shell result=no_update reason=launcher_shim`
- `[JJFB_GWY_UPDATE_STUB] apply=initNetwork mode=cmnet pkg=gwy/gbrwcore.mrp result=MR_SUCCESS_sync`
