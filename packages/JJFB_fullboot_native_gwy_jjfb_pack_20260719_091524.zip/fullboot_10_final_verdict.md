# Full Boot 10 — Final Verdict

- **verdict:** `FAIL`
- **class:** `DSM_HEAP_OOM_ON_CONTINUE`
- **level:** `blocked`
- package_scope: `True`
- gamelist init_ok: `False`
- gamelist platform context: `False`
- cfg36: `False` post_update: `False`
- native_shell runapp: `False` jjfb open: `False`
- mrc_init: `False` visual: `True`
- host_runapp_equivalent used: `False`
- OOM: `True` heap_free events: `1`

## Blockers

- DSM heap OOM on continue (4MB mem_get)
- gamelist.ext init_ok missing
- gamelist EXTCHUNK/ER_RW/R9 incomplete
- no CFG36_BUILD
- no RUNAPP source=native_shell
- jjfb.mrp not opened
- mrc_init not reached

## DSM heap

## JJFB_DSM_HEAP

- `[JJFB_DSM_HEAP] action=free guest=0x282A54 len=4194304 reason=shell_core_continue evidence=TARGET_OBSERVED`
