# Full Boot 09 — Visual Natural Chain

## DRAW

- `[JJFB_DRAW] api=mr_drawBitmap bmp=0xFFFFFFFF x=1 y=2622388 w=12 h=2620280 evidence=DOCUMENTED`
## REFRESH

- `[JJFB_REFRESH] api=mr_drawBitmap note=mrc_refreshScreen_path evidence=DOCUMENTED`
