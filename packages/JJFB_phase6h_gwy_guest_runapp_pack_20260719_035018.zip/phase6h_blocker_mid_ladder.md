# Phase 6H — mid-ladder blocker

## Verdict

**Min ladder PASS** (`shell_native_exec_gate=open`, guest PC in `gbrwcore.ext`, exports registered as string VAs).  
**Mid ladder PENDING**: no guest-native `lib.runapp` / `lib.startGame` call; no gamelist `mr_start`; P+0xC writes = 0.

## Evidence (TARGET_OBSERVED)

| Claim | Tag / fact |
|---|---|
| Guest shell EXT executes | `[JJFB_SHELL_GUEST_PC] pc=0x2EB804 module=gbrwcore.ext` |
| Gate open | `[JJFB_SHELL_NATIVE_GATE]` / prior SUMMARY `class=EXEC_GATE_OPEN` |
| Exports are string VAs, not entries | `kind=string_va_not_entry` for `lib.startGame` / `lib.runapp` |
| Host equivalent absent | no `host_runapp_equivalent_after_no_update` |
| Callee ER_RW missing | `R9_SWITCH_BLOCKED reason=CALLEE_ER_RW_NOT_AVAILABLE module=gbrwcore.ext` |
| Entry selection wrong vs header | `entry_class=WRONG_ENTRY_SELECTION` first_pc=`0x30CA96` header=`0x2EB7E8` |
| Nested P still empty at +0xC | `P=0x2AC8DC P+0xC=0x0` pre/post continuation |
| Gamelist not started | SUMMARY `gamelist=no` |

## Classification

- Shell `cfunction.ext` → reg.ext primary: **CROSS_TARGET** (working for gbrwcore).
- Gate / guest PC: **TARGET_OBSERVED**.
- “Gamelist post-update builds cfg36 then calls runapp”: **HYPOTHESIS** (static strings only; live branch not reached).
- Fault-through-null-extChunk as mid blocker: **HYPOTHESIS** pending full fault capture (prior runs: `fault_addr≈0x28` with `P+0xC=0`).

## Forbidden

No invented P+0xC, no R9 promotion, no force UI, no host runapp equivalent.

## Next discriminating experiment

1. Keep process alive past gate-open (GATE tag only; finalize on fault/export/exit).
2. Capture mem-fault PC/addr while `[JJFB_EXTCHUNK_PHASE] P+0xC=0` still holds.
3. Decide: is the NULL deref `*(P+0xC)+off` inside gbrwcore before any gamelist handoff?

If yes → mid blocked on **publication / extChunk fill inside guest shell**, not on runapp dispatch.  
If fault never happens and gamelist never starts → chase **update/no_update branch inside gbrwcore** (observe-only).
