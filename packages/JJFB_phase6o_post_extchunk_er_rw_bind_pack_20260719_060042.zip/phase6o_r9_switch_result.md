# Phase 6O R9 Switch

- attempts=1
- JJFB_R9_SWITCH_OK=1
- classic ENTER new_r9 for gbrwcore=1
- early CALLEE_ER_RW_NOT_AVAILABLE=1
- JJFB deferred blocked=0

## Attempts

- `[JJFB_R9_SWITCH_ATTEMPT] module=gbrwcore.ext module_id=3 callee_er_rw=0x29EA0 caller_r9=0x280400 call_kind=RUNTIME_ENTRY reason=platform_er_rw_publication_restore evidence=DOCUMENTED`

## OK

- `[JJFB_R9_SWITCH_OK] module=gbrwcore.ext module_id=3 r9=0x29EA0 er_rw_len=0x18 evidence=DOCUMENTED`
