# Phase 6O Registry Bind

bound=True

- gbrwcore.ext id=3 registry_base=0x29EA0 registry_len=0x18 reason=mr_c_function_st_metadata_bind
