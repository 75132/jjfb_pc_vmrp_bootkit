# Phase 6O Post-Entry Continuation

- extChunk PUBLISH nonzero seen: True
- mythroad exit: False
- mid R9 path: True
- 6O summary: [JJFB_6O_SUMMARY] mode=gbrwcore_only bound=yes module=gbrwcore.ext module_id=3 P=0x2AC8DC er_rw_base=0x29EA0 er_rw_len=0x18 deferred_switch=yes stop=mem_fault evidence=TARGET_OBSERVED
