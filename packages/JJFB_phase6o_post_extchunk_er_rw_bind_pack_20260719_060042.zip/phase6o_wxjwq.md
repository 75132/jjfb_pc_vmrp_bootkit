# Phase 6O wxjwq

- `[JJFB_ER_RW_BIND] module=gbrwcore.ext module_id=3 P=0x2AC8DC p_base=0x29EA0 p_len=0x18 registry_base=0x29EA0 registry_len=0x18 reason=mr_c_function_st_metadata_bind evidence=DOCUMENTED`
