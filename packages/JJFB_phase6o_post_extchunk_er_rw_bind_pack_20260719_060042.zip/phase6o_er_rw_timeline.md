# Phase 6O ER_RW Timeline

## JJFB_ER_RW_BIND

- module=gbrwcore.ext id=3 P=0x2AC8DC p_base=0x29EA0 p_len=0x18 registry=0x29EA0/0x18 reason=mr_c_function_st_metadata_bind

## MODULE_ER_RW (gbrwcore)

- (none)

## Early BOOTSTRAP CALLEE_ER_RW_NOT_AVAILABLE (expected before P fill)

- count=1

## Post-bind terminal blocked

- `False`
