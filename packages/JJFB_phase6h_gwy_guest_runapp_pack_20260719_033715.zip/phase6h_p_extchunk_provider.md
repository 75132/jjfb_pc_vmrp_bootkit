# Phase 6H — P+0xC provider

- writes_seen: `0`
- natural write observed: `no`

- provider: **not observed** (do not fake)
