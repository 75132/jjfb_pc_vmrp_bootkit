# Phase 6J — publication verdict

## Verdict: **D**

No +0/+4/+8/+0xC writers observed; enlarge source/doc compare — still no fake.

## Legend

- **A**: legitimate publication routine exists but was not called
- **B**: entry selection wrong; skipped init/publication
- **C**: P+0xC should come from cfunction.ext/reg.ext primary publication flow
- **D**: no writer found across samples — keep researching; no fake

## Next phase (not implemented in 6J)

Expand multi-game/source compare; still forbid inventing extChunk

## Runs considered

- `gbrwcore_jjfb`
- `gbrwcore_wxjwq`

Forbidden: invent P+0xC, R9 promotion, force UI, host_runapp_equivalent.
