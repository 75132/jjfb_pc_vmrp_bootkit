# Original GWY full deep analysis pack

Main document: `ORIGINAL_GWY_FULL_DEEP_ANALYSIS.md`.

CSV files include all ZIP entries, MRP summaries, member manifests, EXT summaries, strings, cfg.bin path records, start.mr/mrc_loader/reg-primary groupings.

Focused files include static field-pattern scans for key EXT modules and full string tables for key packages.
