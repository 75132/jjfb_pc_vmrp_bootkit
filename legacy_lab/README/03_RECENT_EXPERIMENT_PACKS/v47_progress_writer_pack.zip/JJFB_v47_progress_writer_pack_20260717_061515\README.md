﻿# JJFB v47
Find progress/AC8 writers; linear driver proves bar anim but NOT check-update entry.
10140 handler=0x306305; timer does not write progress.
