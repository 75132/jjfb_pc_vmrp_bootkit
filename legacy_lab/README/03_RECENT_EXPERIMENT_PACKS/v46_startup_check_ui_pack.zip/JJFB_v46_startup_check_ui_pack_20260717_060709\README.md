﻿# JJFB v46 pack
Stay in ui_mode=0x45; make startup-check UI/animation run.
Key finding: progress loop is one-shot; count must be >0 before first 0x2EFA9E.
Check-net/update strings exist but are never read yet.
