# JJFB v41 — 目标改为跑机甲风暴，不是完善模拟器

生成时间：2026-07-17

## 目标重心（已切换）

```text
目标：把机甲风暴网游跑起来
手段：遇到阻塞才补最小平台兼容
不追求完整模拟器 / 不追求 UI 像素级还原
```

## 本轮做了什么

1. **轴映射**：`2f9968` 强制返回 WIDTH=240（splash 用它做水平居中）
2. **slogo**：字符串 VA 从错误的 `0x314EF4`(speedlight) 改为 `0x3142DC`；`ERW+0xAC8` 门控最小 nudge
3. **chrome**：仍只 guard，不精修 310BB4
4. **状态面包屑**：`JJFB_GAME_STATE` 打 login/server/slogo 资源名

## 证据

### A) slogo 已出现（`JJFB_SLOGO_NUDGE=1`，默认）

```text
[JJFB_GAME_STATE] SLOGO_NUDGE ac8 0 -> 1
[JJFB_BMP_REQ] name=slogo!157!58.bmp
[JJFB_2EC6B0_BLIT] slogo!157!58.bmp x=41 y=82 w=157 h=58
```

`(240-157)/2 ≈ 41`，不裁剪。仍是 host blit + DEBUG_PRESENT（`fp150C=0x270F`）。

### B) loadingbar 轴修复（`JJFB_SLOGO_NUDGE=0` 对照）

```text
2f9968 natural=320 -> ret 240
loadingbar x≈19（不再 59 裁剪）
```

### C) 取舍（对游戏推进更重要）

```text
AC8>0 → 走 slogo 分支 → 随后常进 0x2E9C2C 一带
      → 本帧不再请求 loadingbar
      → 出现 wy_jiao/wy_xian/jiantou（登录相关 UI 装饰开始加载）
JJFB_NET / initNetwork / socket = 仍为 0
```

默认保留 slogo 路径（更接近完整启动页），loadingbar 可用 `JJFB_SLOGO_NUDGE=0` 对照。

## 仍不是

```text
原生 DispUpEx / mrc_refreshScreen
完整 chrome ABI
网络层
```

## 跑法

```powershell
.\RUN_V41_GAME_FIRST.ps1 -Mode 45
# 对照 loadingbar 居中： $env:JJFB_SLOGO_NUDGE="0"
```

## 下一步（仍服务“往后跑”）

```text
P0：追 splash 退出 / ui_mode 离开 0x45 / 进入 login·server
P0：出现 initNetwork / socket / connect / 20000·21002·6009 立刻切网络
P1：首屏够用即可（已有 slogo；loadingbar 轴已可修）
P3：chrome 继续只 guard
```
