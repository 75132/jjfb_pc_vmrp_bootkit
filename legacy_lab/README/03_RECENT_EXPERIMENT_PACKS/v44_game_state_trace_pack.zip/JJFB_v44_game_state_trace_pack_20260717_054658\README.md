﻿# JJFB v44 pack

- reports/v44_game_state_blocker.md  — conclusion
- reports/Cursor_JJFB_v44_*.md       — task spec
- scripts/RUN_V44_GAME_STATE_TRACE.ps1
- logs/v44_*_stdout.txt
- bridge.c (snapshot)

Verdict: stuck on forced ui_mode=0x45; no guest writes to AC8/progress/ui_mode; 2EC6B0 RET A/B does not advance game.
