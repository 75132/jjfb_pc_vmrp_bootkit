﻿# JJFB v40 结论：真正 blit 入口找到；loadingbar 已按客机坐标 DEBUG present

生成时间：2026-07-17

## 一句话

```text
splash 贴图入口是 0x2EC6B0 → blx *(ERW+0x150C)；
该 FP 当前为哨兵 0x270F，所以原生永远画不出来。
host 在 0x2EC6B0 用客机坐标 blit loadingbar @ (59,140) + DEBUG_PRESENT。
仍不是原生 DispUpEx / mrc_refreshScreen。
```

## 证据（logs/v40_mode45_stdout.txt）

```text
[JJFB_2EC6B0] #1 lr=0x2EFA97 obj=0x6BD090 x=59 y=140
  sp4=0xC9(201) sp8=0x1D(29) fp150C=0x270F name=loadingbar!201!29.bmp
[JJFB_2EC6B0_BLIT] name=loadingbar!201!29.bmp x=59 y=140 w=201 h=29
[JJFB_DEBUG_PRESENT] from 2EC6B0_BLIT dirty 59,140 181x29
[JJFB_2EC6B0_GUARD] bad fp150C=0x270F -> host blit only, ret lr
```

裁剪成 181 宽是因为 x=59 时 59+201>240，右侧出界——这是客机自己的布局结果。

## 坐标公式（反汇编确认）

`0x2EFA54..0x2EFA92`：

```text
h = 2f9968()           // screen height (320)
x = (h - bmp.w) / 2    // (320-201)/2 = 59
w = 2f995c()           // screen width  (240)
y = w - 0x64           // 240-100 = 140
bl 0x2EC6B0(obj, x, y, ...)
```

不是 EAGER 的 (19,200)。

## 根因

| 项 | 值 |
|----|-----|
| 绘制包装 | `0x2EC6B0` |
| 调用点 | `0x2EFA92`（loadingbar）、`0x2EF9DA`（#0x1c 槽，疑似 slogo 路径） |
| 最终 FP | `*(ERW+0x150C)` |
| 当前 FP | `0x270F`（坏哨兵，与 `drawFP@1510` 同类） |

**禁止**把 `0x150C` 盲接到 `mr_drawBitmap`：栈参数是扩展 blit（含 keycolor `0xF81F` 等），ABI ≠ 简单 `(bmp,x,y,w,h)`。

## 仍缺

```text
bar / textbar：已 PARENT_STORE，但本帧 progress 循环未再调 0x2EC6B0
slogo：0x45 下字符串读仍为 0；入口前有计数器 ble 跳过 0x2EF8A6 一带
原生 DispUpEx / mrc_refreshScreen = 0
```

## 已锁定（勿回退）

```text
0x10134 返回 pixel ptr
240×320 固定
EAGER 默认关
FORCE ui_mode=0x45（十六进制）
DEBUG_PRESENT ≠ 原生 refresh
```

## 跑法

```powershell
.\RUN_V40_SPLASH_BLIT.ps1 -Mode 45
# 关闭 host blit 只观察： $env:JJFB_SPLASH_HOST_BLIT="0"
```

## 下一步（v41）

```text
1. 搞清 ERW+0x150C 应由谁写入；对照真机/完整初始化，切勿盲 seed 到 mr_drawBitmap
2. 放行/补齐 splash 前半段计数器，让 0x2EF9DA 的 #0x1c（slogo 候选）路径跑起来
3. 让 progress 循环画出 bar/textbar（仍用客机坐标）
4. 继续区分 DEBUG_PRESENT vs 原生 refresh
```
