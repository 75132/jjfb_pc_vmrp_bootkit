# JJFB v40 — splash draw via 0x2EC6B0 + guest coords host blit
# Default: no eager blit. FORCE splash 0x45. Host-blit splash bmps at guest x/y.

param(
  [string]$Mode = "45",
  [int]$Seconds = 18
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$rt = Join-Path $root "runtime\vmrp_win32\vmrp_win32_20220102"
$src = Join-Path $root "runtime\vmrp_src_build_v27\vmrp-master"

$env:Path = "C:\msys64\mingw32\bin;" + $env:Path
$env:JJFB_SCREEN_W = "240"
$env:JJFB_SCREEN_H = "320"
$env:JJFB_ALLOW_CHROME = "1"
$env:JJFB_CHROME_ALLOW_CALLS = "8"
$env:JJFB_CHROME_SKIP_310BB4 = "1"
$env:JJFB_310BB4_HOST_BLIT = "1"
$env:JJFB_10134_EAGER_BLIT = "0"
$env:JJFB_10134_RET = "pixels"
$env:JJFB_FORCE_SPLASH_NUDGE = $Mode
$env:JJFB_SPLASH_HOST_BLIT = "1"

Write-Host "=== JJFB v40 splash blit mode=$Mode ==="

Push-Location $src
try {
  Write-Host "Building bridge.c ..."
  & gcc -g -Wall -DNETWORK_SUPPORT -DVMRP -m32 -c bridge.c -o bridge.o
  if ($LASTEXITCODE -ne 0) { throw "gcc bridge.c failed" }
  # Relink main.exe into runtime (same recipe as handoff)
  $objs = @(
    "bridge.o","main.o","memory.o","mythroad/mythroad.o","mythroad/utils.o",
    "mythroad/base64_decode.o","mythroad/mr_encode.o","mythroad/mr_inflate.o",
    "mythroad/string.o","network.o","timer.o","utils.o"
  ) | Where-Object { Test-Path $_ }
  # Prefer existing project link script if present; else copy .o and use runtime main.exe rebuild note
  if (Test-Path ".\main.exe") {
    # Incremental: just replace bridge.o then full link if Makefile targets exist
  }
} finally {
  Pop-Location
}

# Copy freshly built artifacts if present
$built = Join-Path $src "main.exe"
if (Test-Path $built) {
  Copy-Item -Force $built (Join-Path $rt "main.exe")
  Write-Host "Copied main.exe -> runtime"
} else {
  Write-Host "WARN: no main.exe in build dir; using existing runtime main.exe (rebuild may be incomplete)"
}

if (Test-Path (Join-Path $rt "jjfb_loader_stdout.txt")) {
  Remove-Item (Join-Path $rt "jjfb_loader_stdout.txt") -Force
}

$p = Start-Process -FilePath (Join-Path $rt "main.exe") -WorkingDirectory $rt -PassThru
Write-Host "pid=$($p.Id)"
Start-Sleep -Seconds $Seconds
if (-not $p.HasExited) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue }

$logDir = Join-Path $root "logs"
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$out = Join-Path $logDir ("v40_mode" + $Mode + "_stdout.txt")
Copy-Item -Force (Join-Path $rt "jjfb_loader_stdout.txt") $out
Write-Host "saved $out"
Select-String -Path $out -Pattern "2EC6B0|2EC6B0_BLIT|2EC712|DEBUG_PRESENT|SPLASH_ENTER|drawFP@150C|GUARD" |
  Select-Object -First 40 | ForEach-Object { $_.Line }
