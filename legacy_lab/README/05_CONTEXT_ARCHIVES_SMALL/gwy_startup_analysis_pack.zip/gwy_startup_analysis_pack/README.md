# gwy_startup_analysis_pack

这是针对上传包中 `320x480/网游/gwy` 和 `320x480/冒泡组件` 的启动链分析结果。

优先阅读：

```text
reports/gwy_startup_analysis.md
```

给 OpenClaw 的下一步任务：

```text
openclaw/OPENCLAW_GWY_NEXT_TASK.txt
```

表格：

```text
tables/gwy_mrp_inventory.csv
tables/cfg_bin_mrp_paths.csv
```

字符串证据：

```text
strings/
```
