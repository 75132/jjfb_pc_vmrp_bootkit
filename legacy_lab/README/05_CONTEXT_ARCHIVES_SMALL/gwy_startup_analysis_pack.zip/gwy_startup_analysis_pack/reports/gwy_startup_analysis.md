# gwy/网游启动方法分析报告

## 结论

这包里确实有“网游启动链”，不是只靠单个游戏 MRP 直接启动。

更接近原始流程的是：

```text
/sdcard/mythroad/cookie.mrp
        ↓
冒泡组件 game.ext / app 列表 / 下载组件
        ↓
/sdcard/mythroad/gwy.mrp
        ↓
gwy.mrp 内的 cfunction.ext
        ↓
gwy/reglogin.mrp
gwy/dload.mrp
gwy/gui.mrp
gwy/rollscr.mrp
gwy/gamelist.mrp
gwy/resmng.mrp
gwy/vdload.mrp
gwy/pmsg.mrp
gwy/embfrd.mrp
gwy/svrctrl.mrp
gwy/font.mrp
        ↓
gwy/gamelist.mrp 读取 gwy/cfg.bin
        ↓
按 cfg.bin 里的路径启动具体游戏，例如：
gwy/jjfb.mrp
gwy/xyol.mrp
gwy/yxlm.mrp
gwy/zsol.mrp
```

所以：**gwy.mrp 是网游大厅/壳，gwy/gamelist.mrp + gwy/cfg.bin 是本地游戏列表和启动入口，具体游戏 MRP 是被这个壳加载的。**

## 原包说明的关键证据

`冒泡组件/说明.txt` 写得很直接：

```text
使用时放入mythroad目录下，运行cookie.mrp即可。
这些组件仅适合于更新游戏，不要用其更新列表，更新列表只会得到2011年6月12号的列表……
```

这说明原作者的思路就是：先跑 `cookie.mrp`，用冒泡组件/网游壳去更新或进入游戏。

## gwy.mrp 的启动证据

`gwy.mrp` 内只有 8 个条目：

```text
start.mr
mrc_loader.ext
bubble.bmp
bubble_bk.bmp
sfc.bin
logo.bmp
graphics.ext
cfunction.ext
```

`gwy.mrp` 自己不是某个具体游戏，它是加载器。它的 `cfunction.ext` 里明文出现了这些模块路径：

```text
gwy\reglogin.mrp
gwy\dload.mrp
gwy\gui.mrp
gwy\rollscr.mrp
gwy\gamelist.mrp
gwy\resmng.mrp
gwy\vdload.mrp
gwy\pmsg.mrp
gwy\embfrd.mrp
gwy\svrctrl.mrp
gwy\font.mrp
```

这些就是网游大厅/登录/下载/列表/资源管理模块。

## gamelist.mrp 的启动证据

`gwy/gamelist.mrp` 的 `gamelist.ext` 里出现了：

```text
gwy/cfg.bin
gwy/%s.mrp
%s.mrp
gwy.mrp
gwyblink
nmrpname
bmrpname
napptype=%d_nextid=%d_ncode=%d_narg=%d_narg1=%d_nmrpname=%s_gwyblink
```

这说明 `gamelist.mrp` 会读取 `gwy/cfg.bin`，然后按列表里的 MRP 路径启动游戏。

## cfg.bin 中发现的游戏入口

`gwy/cfg.bin` 里发现了 49 条 MRP 路径。高价值的包括：

```text
gwy/jjfb.mrp      机甲风暴 / robotol，本地资源在 gwy/jjfbol/
gwy/xyol.mrp      西游 OL，本地资源在 gwy/xyol/
gwy/yxlm.mrp      yxlm，本地资源在 gwy/yxlm/
gwy/zsol.mrp      战神 OL/梦幻相关，本地资源主要在 gwy/mhxx/mm_320x480/
gwy/gkdxy.mrp     本地资源在 gwy/gkdxy/
gwy/sanguo.mrp    本地资源在 gwy/sanguo/
gwy/sgmj.mrp      本地资源在 gwy/sgmj/
gwy/smd.mrp       本地资源在 gwy/smd/
gwy/spacetime.mrp 本地资源在 gwy/spacetime/
gwy/tlbb.mrp      本地资源在 gwy/tlbb/320x480/
gwy/ssjx.mrp      本地资源在 gwy/ssjx/
gwy/ajss.mrp      本地资源在 gwy/ajss/
gwy/assg.mrp      本地资源在 gwy/assg/
```

完整列表在：

```text
tables/cfg_bin_mrp_paths.csv
```

## 为什么直接启动游戏容易卡

大量具体网游 MRP 的 `start.mr` 里有同一段 SDK 检查逻辑：

```text
sdk_key.dat
IMEI
hstype
cann`t find sdk key!
```

也就是说，很多具体游戏直接运行时会先读 `sdk_key.dat`。没有这个文件就会先死在 SDK key 检查阶段。

扫描结果显示，以下主游戏 MRP 都需要 `sdk_key.dat`：

```text
ajss.mrp
assg.mrp
bbjq.mrp
gkdxy.mrp
jjfb.mrp
sanguo.mrp
sgmj.mrp
smd.mrp
spacetime.mrp
ssjx.mrp
tlbb.mrp
tyol.mrp
wm2.mrp
wm2pet.mrp
wxjwq.mrp
xaqd.mrp
xyol.mrp
yxlm.mrp
zsol.mrp
```

所以正确测试时，建议至少放置：

```text
/sdcard/mythroad/sdk_key.dat
/sdcard/mythroad/gwy/sdk_key.dat
```

内容可以先用 15 字节测试值，例如：

```text
123456789012345
```

## 现在最可行的启动路线

### 路线 A：原始入口

```text
/sdcard/mythroad/cookie.mrp
```

要求目录：

```text
/sdcard/mythroad/cookie.mrp
/sdcard/mythroad/app320480/
/sdcard/mythroad/plugin320480/
/sdcard/mythroad/plugins/
/sdcard/mythroad/system/
/sdcard/mythroad/gwy.mrp
/sdcard/mythroad/gwy/
```

### 路线 B：跳过冒泡首页，直接进网游大厅

```text
/sdcard/mythroad/gwy.mrp
```

要求目录：

```text
/sdcard/mythroad/gwy.mrp
/sdcard/mythroad/gwy/cfg.bin
/sdcard/mythroad/gwy/gamelist.mrp
/sdcard/mythroad/gwy/reglogin.mrp
/sdcard/mythroad/gwy/dload.mrp
/sdcard/mythroad/gwy/gui.mrp
/sdcard/mythroad/gwy/rollscr.mrp
/sdcard/mythroad/gwy/resmng.mrp
/sdcard/mythroad/gwy/vdload.mrp
/sdcard/mythroad/gwy/pmsg.mrp
/sdcard/mythroad/gwy/embfrd.mrp
/sdcard/mythroad/gwy/svrctrl.mrp
/sdcard/mythroad/gwy/font.mrp
```

### 路线 C：直接跑具体游戏，不推荐作为第一路线

例如：

```text
/sdcard/mythroad/gwy/jjfb.mrp
/sdcard/mythroad/gwy/xyol.mrp
/sdcard/mythroad/gwy/yxlm.mrp
```

但这种会遇到：

```text
1. sdk_key.dat 检查；
2. 部分游戏的 start.mr 依赖公共 cfunction.ext / 原大厅环境；
3. 游戏内部仍可能强制联网更新。
```

## 强制联网更新的位置判断

这不是简单的“少一个启动文件”。当前文件里能看到多个下载/更新模块：

```text
cookie.mrp -> game.ext
  applist
  applist2.sky-mobi.net:9999
  applist2upload.sky-mobi.net:9998
  mdsmlst.dl
  mdsm.lst
  .mrp.sid

gwy/dload.mrp -> download.ext
gwy/vdload.mrp -> vdload.ext
gwy/gamelist.mrp -> gamelist.ext
```

另外具体游戏内也有更新线索，例如 `jjfb.mrp` 的 `robotol.ext` 出现：

```text
inGameDown2.v
downVersion
ingameDown
scoreShop.txt
gwy/jjfbol/
```

所以真正卡游戏的“强制更新”很可能在两层：

```text
第一层：冒泡/网游大厅更新列表、组件、MRP SID；
第二层：具体游戏自己的资源/版本检查。
```

## 建议下一步

先不要再盯 `wap.skmeg.com/error.jsp`，这个可能只是模拟器/兼容层报错页。

更稳的路线是：

```text
1. 用 /sdcard/mythroad/gwy.mrp 作为入口；
2. 保证 /sdcard/mythroad/gwy/ 完整存在；
3. 加 sdk_key.dat 到 mythroad 根目录和 gwy 目录；
4. 抓包启动 gwy.mrp 到点击具体游戏的完整流程；
5. 重点看：
   - applist2.sky-mobi.net:9999
   - mrc_freesky.51mrp.com
   - 51mrp.com
   - 111.1.17.146:21003
   - bcs.duapp.com/myplugins/dyd.apk
6. 如果要绕过更新，应优先 patch/mock：
   - cookie.mrp/game.ext 的 applist2 请求；
   - gwy/dload.mrp 或 gwy/vdload.mrp 的下载结果；
   - 具体游戏 ext 的 version/downVersion/ingameDown 检查。
```

## 本包内容

```text
reports/gwy_startup_analysis.md
tables/gwy_mrp_inventory.csv
tables/cfg_bin_mrp_paths.csv
strings/*.txt
openclaw/OPENCLAW_GWY_NEXT_TASK.txt
```
