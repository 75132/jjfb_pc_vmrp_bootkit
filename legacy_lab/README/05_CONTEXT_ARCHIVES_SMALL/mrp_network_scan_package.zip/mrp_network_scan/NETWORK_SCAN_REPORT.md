# MRP 网络接口静态扫描报告

- 生成时间：2026-07-12T07:50:43
- 扫描输入：`3aa55816-b260-45b6-9e3b-9fd7fe4676d4.zip` + 单独上传的 `cfunction(1).ext`
- 扫描文件数：2457
- 原始命中数：1791
- endpoint 候选去重数：11
- 网络 API/提示字符串命中数：1765

## 结论快照

### 高可信 URL/host:port

- `url` `https://github.com/zengming00/sdk`；来源：/mnt/data/cfunction(1).ext

### 中可信 endpoint / 域名候选

- `domain` `github.com`；来源：/mnt/data/cfunction(1).ext
- `http_path` `/github.com/zengming00/sdk`；来源：/mnt/data/cfunction(1).ext

### 低可信/可能噪声候选

- `domain` `g.cn`；来源：zip:jjfbol.mrp/_raw/gameattackmodule.ext
- `http_path` `/(/V`；来源：zip:jjfbol.mrp/_raw/robotol.ext
- `http_path` `/IyD/HHD`；来源：zip:jjfbol.mrp/_meta/decoded_texts.json | zip:jjfbol.mrp/_meta/strings_by_entry.json | zip:jjfbol.mrp/_meta/texts/robotol.ext.utf8.txt | zip:jjfbol.mrp/_raw/robotol.ext::gzip1 | zip:jjfbol.mrp/robotol.ext
- `http_path` `/J@h/MJD`；来源：zip:jjfbol.mrp/_meta/strings_by_entry.json | zip:jjfbol.mrp/_meta/texts/robotol.ext.utf8.txt | zip:jjfbol.mrp/_raw/robotol.ext::gzip1 | zip:jjfbol.mrp/robotol.ext
- `http_path` `/L/M`；来源：zip:jjfbol.mrp/_meta/decoded_texts.json | zip:jjfbol.mrp/_meta/strings_by_entry.json | zip:jjfbol.mrp/_meta/texts/robotol.ext.utf8.txt | zip:jjfbol.mrp/_raw/robotol.ext::gzip1 | zip:jjfbol.mrp/robotol.ext
- `http_path` `/N/I`；来源：zip:jjfbol.mrp/_meta/strings_by_entry.json | zip:jjfbol.mrp/_meta/texts/robotol.ext.utf8.txt | zip:jjfbol.mrp/_raw/robotol.ext::gzip1 | zip:jjfbol.mrp/robotol.ext
- `http_path` `/_(/`；来源：zip:jjfbol.mrp/_raw/robotol.ext
- `http_path` `/k/k/k`；来源：zip:jjfbol/bmm8.mrp/_meta/decoded_texts.json | zip:jjfbol/bmm8.mrp/_meta/texts/m8!160!120@bmm8.bmp.utf8.txt

## 网络相关模块排行

- `decoded_texts.json` score=1069；terms=ip:246, dsm:3, tcp:1, apn:1; examples=network_string:ipQ\u0018\u0000\u0016\u0000\u0014\u0000\u0012\u0000Q\b/\u0000\u000e\u0000-\u0000 | network_string:IpAQA | network_string:IP9Sc | network_api:TCp\u00110\".*5 | http_path:/k/k/k | network_string:|@imgPath=|@
- `cfunction(1).ext` score=1035；terms=send:18, ip:17, dsm:15, sms:15, socket:14, Call:14, network:12, connect:10, recv:8, tcp:7; examples=url:https://github.com/zengming00/sdk | domain:github.com | http_path:/github.com/zengming00/sdk | network_api:mr_unzip | network_string:is a a multi-part gzip file | network_string:nozip | network_api:_mr_readFile: "%s"
- `itemtype@itemtype.txt` score=868；terms=ip:217; examples=network_string:|@imgPath=|@itemCount=25
@itemDetail|@id=0|@isShow=true|@equipType=0|@canGrowAt | network_string:|@intro=|@weaponImageID=2|@dongImageID=-1|@wingImageID=-1|@useLevel=2
@itemDeta | network_string:|@intro=|
- `itemtype@itemtype.txt.utf8.txt` score=868；terms=ip:217; examples=network_string:|@imgPath=|@itemCount=25
@itemDetail|@id=0|@isShow=true|@equipType=0|@canGrowA | network_string:|@intro=|@weaponImageID=2|@dongImageID=-1|@wingImageID=-1|@useLevel=2
@itemDet | network_string:|@intro=|
- `itemtype@itemtype.txt::gzip1` score=868；terms=ip:217; examples=network_string:|@imgPath=|@itemCount=25
@itemDetail|@id=0|@isShow=true|@equipType=0|@canGrowAt | network_string:|@intro=|@weaponImageID=2|@dongImageID=-1|@wingImageID=-1|@useLevel=2
@itemDeta | network_string:|@intro=|
- `strings_by_entry.json` score=853；terms=ip:2; examples=network_api:{
  "start.mr": {
    "ascii": [
      "@start.mr",
      "this_key",
      | network_api:{
  "start.mr": {
    "ascii": [
      "@start.mr",
      "this_key",
      | network_api:{
  "start.mr": {
- `robotol.ext` score=460；terms=ip:58, 充值:20, dsm:8, 连接:6, 发送:6, Call:4, 网络:4, receive:2, 超时:2, 登陆:2; examples=http_path:/IyD/HHD | http_path:/N/I | http_path:/J@h/MJD | http_path:/L/M | network_string:$IPhID | network_string:sL|DsM | network_string:qIpJID | network_string:IPJID
- `index.json` score=240；terms=ip:60; examples=network_string:\\jjfb\\jjfbol\\attack.mrp",
  "head": {
    "h0": 1196446285,
    "h1": 711, | network_string:\\jjfb\\jjfbol\\bigWorldMap.mrp",
  "head": {
    "h0": 1196446285,
    "h1": | network_string:\\jjfb\\j
- `othermodule.ext` score=152；terms=ip:16, 充值:16, Call:4, receive:2; examples=network_string:(VIP)1 | network_string:(VIP)3 | network_string:mrc_extMpsFpCall:err | network_string:exRam:scan skipped! | network_string:Interrupt received | network_string:Pure virtual fn called | network_string:ipG | 
- `robotol.ext.utf8.txt` score=136；terms=ip:25, dsm:4, Call:2, receive:1; examples=http_path:/IyD/HHD | http_path:/N/I | http_path:/J@h/MJD | http_path:/L/M | network_string:$IPhID | network_string:sL|DsM | network_string:qIpJID | network_string:IPJID
- `mailmodule.ext` score=96；terms=发送:10, ip:6, Call:4, receive:2, 充值:2; examples=network_string:mrc_extMpsFpCall:err | network_string:exRam:scan skipped! | network_string:Interrupt received | network_string:Pure virtual fn called | network_string:ipG | network_string:邮件已发送！ | network_string:发送邮件 | ne
- `shopmodule.ext` score=88；terms=ip:8, Call:4, 充值:4, 登录:4, receive:2; examples=network_string:mrc_extMpsFpCall:err | network_string:exRam:scan skipped! | network_string:Interrupt received | network_string:Pure virtual fn called | network_string:ipG | network_string:能量块不够！请先充值！ | network_string:只有VI
- `gameattackmodule.ext` score=84；terms=ip:10, dsm:4, Call:4, receive:2; examples=network_string:IpmID | network_string:{DSM | network_string:mrc_extMpsFpCall:err | network_string:exRam:scan skipped! | network_string:Interrupt received | network_string:Pure virtual fn called | network_string:IpmID坉虹 |
- `viewmanmodule.ext` score=84；terms=ip:15, Call:4, receive:2; examples=network_string:#VIP/ | network_string:mrc_extMpsFpCall:err | network_string:exRam:scan skipped! | network_string:Interrupt received | network_string:Pure virtual fn called | network_string:ipG | network_string:暂未开通VIP特权 
- `mainmenumodule.ext` score=80；terms=服务器:8, Call:4, ip:4, receive:2, 登录:2; examples=network_string:mrc_extMpsFpCall:err | network_string:exRam:scan skipped! | network_string:Interrupt received | network_string:Pure virtual fn called | network_string:ipG | network_string:获取服务器列表 | network_string:此服务器暂关闭，
- `chatmodule.ext` score=68；terms=发送:6, ip:5, Call:4, receive:2; examples=network_string:mrc_extMpsFpCall:err | network_string:exRam:scan skipped! | network_string:Interrupt received | network_string:Pure virtual fn called | network_string:ipG | network_string:发送消息 | network_string:暂未加入队伍，不能发送
- `itembagshopmodule.ext` score=64；terms=ip:8, Call:4, receive:2, 服务器:2; examples=network_string:IID
iPC | network_string:mrc_extMpsFpCall:err | network_string:exRam:scan skipped! | network_string:Interrupt received | network_string:Pure virtual fn called | network_string:IID
iPC蕀 | network_string:ipG
- `itemhechengmodule.ext` score=60；terms=ip:7, Call:4, receive:2, 充值:2; examples=network_string:mrc_extMpsFpCall:err | network_string:exRam:scan skipped! | network_string:Interrupt received | network_string:Pure virtual fn called | network_string:ipG | network_string:能量块不够！请先充值！ | network_string:4bIP
- `leitaimodule.ext` score=56；terms=Call:4, ip:4, 充值:4, receive:2; examples=network_string:mrc_extMpsFpCall:err | network_string:exRam:scan skipped! | network_string:Interrupt received | network_string:Pure virtual fn called | network_string:ipG | network_string:能量块不够!请先充值! | network_string:能量块不
- `taobaomodule.ext` score=56；terms=Call:4, ip:4, 充值:4, receive:2; examples=network_string:mrc_extMpsFpCall:err | network_string:exRam:scan skipped! | network_string:Interrupt received | network_string:Pure virtual fn called | network_string:ipG | network_string:能量块不够！请先充值！ | network_string:能量块不

## 关键网络 API 字符串

- `{
  "start.mr": {
    "ascii": [
      "@start.mr",
      "this_key",
      "p_mr_param",
      "param_len",
      "_com",
      "_mr_c_load",
      "gc_times",
      "dealevent",
      "dealtimer",
      "suspend",
      "resume",
      "sysinfo` 来源：zip:jjfbol/attack.mrp/_meta/strings_by_entry.json offset=0x0
- `TCp\u00110\".*5` 来源：zip:jjfbol/bmm4.mrp/_meta/decoded_texts.json offset=0x197bb
- `梅炉录梅楼9聨TCp` 来源：zip:jjfbol/bmm4.mrp/_meta/texts/m4!160!120@bmm4.bmp.utf8.txt offset=
- `mr_unzip` 来源：/mnt/data/cfunction(1).ext offset=0x2d4a8
- `_mr_readFile: "%s" Unzip err!` 来源：/mnt/data/cfunction(1).ext offset=0x2d714
- `cmnet` 来源：/mnt/data/cfunction(1).ext offset=0x2dd00
- `socket` 来源：/mnt/data/cfunction(1).ext offset=0x2dd08
- `Socket IDLE!` 来源：/mnt/data/cfunction(1).ext offset=0x2dd10
- `_mr_smsDsmSave` 来源：/mnt/data/cfunction(1).ext offset=0x2dd88
- `mr_smsIndiaction check ok!` 来源：/mnt/data/cfunction(1).ext offset=0x2ddd8
- `ConnectWAP` 来源：/mnt/data/cfunction(1).ext offset=0x2df64
- `GetNetworkID` 来源：/mnt/data/cfunction(1).ext offset=0x2df70
- `SendSms` 来源：/mnt/data/cfunction(1).ext offset=0x2df80
- `_mr_smsCheckNum` 来源：/mnt/data/cfunction(1).ext offset=0x2e308
- `sendSms` 来源：/mnt/data/cfunction(1).ext offset=0x2e328
- `Clean Network!` 来源：/mnt/data/cfunction(1).ext offset=0x4f454
- `Socket is IDLE!` 来源：/mnt/data/cfunction(1).ext offset=0x4f488
- `initNetworkCB param err!` 来源：/mnt/data/cfunction(1).ext offset=0x4f4a0
- `mr_initNetwork return err!` 来源：/mnt/data/cfunction(1).ext offset=0x4f4bc
- `bad tcp/udp` 来源：/mnt/data/cfunction(1).ext offset=0x4f4e0
- `tcp send:err!` 来源：/mnt/data/cfunction(1).ext offset=0x4f4f4
- `udp sendto:err!` 来源：/mnt/data/cfunction(1).ext offset=0x4f504
- `tcp recv:err!` 来源：/mnt/data/cfunction(1).ext offset=0x4f518
- `udp recvfrom:err!` 来源：/mnt/data/cfunction(1).ext offset=0x4f528
- `mr_connect failed!` 来源：/mnt/data/cfunction(1).ext offset=0x4f544
- `mr_socket, %d` 来源：/mnt/data/cfunction(1).ext offset=0x4f558
- `connect` 来源：/mnt/data/cfunction(1).ext offset=0x4f568
- `sendto` 来源：/mnt/data/cfunction(1).ext offset=0x4f584
- `send` 来源：/mnt/data/cfunction(1).ext offset=0x4f58c
- `mr_exit() called by mythroad!` 来源：/mnt/data/cfunction(1).ext offset=0x4f67c
- `[INFO]mr_sendSms(%s)` 来源：/mnt/data/cfunction(1).ext offset=0x4f8d8
- `[INFO]mr_call(%s)` 来源：/mnt/data/cfunction(1).ext offset=0x4f8f0
- `[INFO]mr_connectWAP(%s)` 来源：/mnt/data/cfunction(1).ext offset=0x4f904
- `[INFO]getSocketState(%d)` 来源：/mnt/data/cfunction(1).ext offset=0x4f91c
- `[INFO]mr_initNetwork(mod:%s)` 来源：/mnt/data/cfunction(1).ext offset=0x4fa14
- `mr_closeNetwork` 来源：/mnt/data/cfunction(1).ext offset=0x4fa40
- `[INFO]mr_socket(type:%d, protocol:%d)` 来源：/mnt/data/cfunction(1).ext offset=0x4fa50
- `[INFO]mr_connect(s:%d, ip:%d, port:%d, type:%d)` 来源：/mnt/data/cfunction(1).ext offset=0x4fa78
- `[INFO]mr_closeSocket(%d)` 来源：/mnt/data/cfunction(1).ext offset=0x4faa8
- `[INFO]mr_recv(%d)` 来源：/mnt/data/cfunction(1).ext offset=0x4fac4
- `[INFO]mr_send %d %s` 来源：/mnt/data/cfunction(1).ext offset=0x4fad8
- `[INFO]mr_recvfrom(%d,%s,%d,%d,%d)` 来源：/mnt/data/cfunction(1).ext offset=0x4faec
- `[INFO]mr_sendto(%d,%s,%d,%d,%d)` 来源：/mnt/data/cfunction(1).ext offset=0x4fb10
- `wap` 来源：/mnt/data/cfunction(1).ext offset=
- `tcp` 来源：/mnt/data/cfunction(1).ext offset=
- `udp` 来源：/mnt/data/cfunction(1).ext offset=

## 文件说明

- `endpoint_candidates.csv/json`：URL、域名、IPv4、host:port、HTTP 路径候选去重汇总。
- `network_findings_all.csv/json`：全部原始命中，带来源、偏移、上下文。
- `network_api_strings.csv`：socket/connect/send/recv/WAP/SMS/Network 等接口字符串。
- `suspected_network_modules.csv`：按网络命中打分的模块/文件排序。

## 注意

静态字符串扫描只能发现硬编码 URL/IP/端口和可见 API 名称。若服务器地址是运行时拼接、配置下载、数字常量 IP、或被压缩/加密，需要继续做动态 hook：拦截 `mr_socket/mr_connect/mr_send/mr_recv`。