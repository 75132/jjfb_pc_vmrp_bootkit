# 下一步动态确认建议

1. 优先 hook / 打日志：
   - mr_initNetwork(mod)
   - mr_socket(type, protocol)
   - mr_connect(s, ip, port, type)
   - mr_send(s, buf, len)
   - mr_recv(s)
   - mr_sendto / mr_recvfrom
   - mr_closeSocket / mr_closeNetwork

2. 静态结果显示：`cfunction.ext` 内有完整网络封装字符串，游戏功能模块大概率通过它联网。

3. 如果要做本地服务端，先不要改业务模块，先在模拟器层把 `mr_connect` 的 ip/port 打印出来，并可选重定向到 127.0.0.1。

4. 如果没有打印出域名/IP，说明地址可能以整数或脚本参数传入，需要追踪 `mr_connect(s, ip, port, type)` 的调用栈和参数来源。
