# MRP 网络 endpoint / 接口提取结果（精简版）

## 1. 域名 / URL / IP / 端口结论

- **没有发现明确的游戏服务器域名、硬编码 IPv4、URL 或 host:port。**
- URL 候选：1 个；其中可见的高可信 URL 是 SDK 参考地址，不像游戏服务器。
- 域名候选：1 个；主要是 SDK 地址里的 `github.com`。
- 硬编码 IPv4 候选：0 个。
- `host:port` 候选：0 个。

### SDK/运行库参考地址，不像游戏服务器

- `url` `https://github.com/zengming00/sdk` 来源：/mnt/data/cfunction(1).ext
- `domain` `github.com` 来源：/mnt/data/cfunction(1).ext
- `http_path` `/github.com/zengming00/sdk` 来源：/mnt/data/cfunction(1).ext

## 2. 已识别到的网络 API / 接口层

网络封装集中在 `cfunction.ext`，关键字符串如下：

- offset ``：`tcp`
- offset ``：`udp`
- offset `0x4f464`：`getHost`
- offset `0x4f4bc`：`mr_initNetwork return err!`
- offset `0x4f4e0`：`bad tcp/udp`
- offset `0x4f4f4`：`tcp send:err!`
- offset `0x4f504`：`udp sendto:err!`
- offset `0x4f518`：`tcp recv:err!`
- offset `0x4f528`：`udp recvfrom:err!`
- offset `0x4f544`：`mr_connect failed!`
- offset `0x4f558`：`mr_socket, %d`
- offset `0x4f8d8`：`[INFO]mr_sendSms(%s)`
- offset `0x4f904`：`[INFO]mr_connectWAP(%s)`
- offset `0x4f91c`：`[INFO]getSocketState(%d)`
- offset `0x4fa14`：`[INFO]mr_initNetwork(mod:%s)`
- offset `0x4fa40`：`mr_closeNetwork`
- offset `0x4fa50`：`[INFO]mr_socket(type:%d, protocol:%d)`
- offset `0x4fa78`：`[INFO]mr_connect(s:%d, ip:%d, port:%d, type:%d)`
- offset `0x4fac4`：`[INFO]mr_recv(%d)`
- offset `0x4fad8`：`[INFO]mr_send %d %s`
- offset `0x4faec`：`[INFO]mr_recvfrom(%d,%s,%d,%d,%d)`
- offset `0x4fb10`：`[INFO]mr_sendto(%d,%s,%d,%d,%d)`

## 3. 运行模型判断

静态上看，游戏没有把旧服务器地址直接明文写死在资源表里；更像是：
```text
业务模块/脚本 → cfunction.ext socket 封装 → MRP/模拟器网络 API → 实际网络
```
因此，下一步不要优先找 URL，而应动态 hook `mr_connect(s, ip, port, type)`，打印运行时传入的 `ip/port/type`。

## 4. 建议 hook 点

```c
mr_initNetwork(mod)
mr_socket(type, protocol)
mr_connect(s, ip, port, type)
mr_send(s, buf, len)
mr_recv(s)
mr_sendto(s, buf, len, ip, port)
mr_recvfrom(s, buf, len, ip, port)
mr_closeSocket(s)
mr_closeNetwork()
```

## 5. 输出文件

- `endpoint_candidates.csv/json`：所有 URL/域名/IP/端口候选。
- `cfunction_network_api_clean.csv`：清洗后的网络 API 字符串。
- `network_findings_all.csv/json`：完整原始扫描结果，含低可信噪声。
- `network_modules_clean.csv`：建议优先追踪的模块。