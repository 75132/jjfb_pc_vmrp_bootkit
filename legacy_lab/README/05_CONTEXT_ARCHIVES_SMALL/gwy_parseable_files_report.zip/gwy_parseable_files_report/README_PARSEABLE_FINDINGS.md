# G WY/MRP/CFG 可解析信息报告（给下一步抓包与 mock 用）

## 结论

不是完全不能解析。现在能解析出三层信息：

1. **MRP 容器层**：能解出 `gamelist.mrp`、`dload.mrp`、`vdload.mrp`、`reglogin.mrp` 等包内资源列表；`.ext` 可解 gzip，能看到 `MRPGCMAP` 和大量字符串。
2. **cfg.bin 目录层**：能按固定记录提取 `gwy/*.mrp`、图标、条目标题、部分 URL。这个对“点任意应用都弹更新”最有价值。
3. **代码逻辑层**：`.ext` 是 ARM/Thumb 二进制，不能直接还原源码，但能抽出关键字符串和函数名；要精确分支还需要反汇编。

## 对当前问题最有价值的文件

- `gwy/gamelist.mrp`：入口调度、弹窗、`gwy/cfg.bin`、`gwy/%s.mrp`、`gwyblink`、`nmrpname/bmrpname/napptype/nextid/narg`。
- `gwy/cfg.bin`：公共网游/应用条目目录。已解析出 `机甲风暴(火爆公测)` 对应 `gwy/jjfb.mrp` 和图标 `ng_jjfb.gif`。
- `gwy/vdload.mrp`：版本/下载链，含 `/simpleDownload`、`/continueDownload`、`/dl_confirm`、`spd.skymobiapp.com:6009` 这类证据。
- `gwy/gbrwcore.mrp`：平台浏览器/启动函数，含 `startGame`、`runapp`、`download`、`isFileOnServerNewer`、`getFileVersion`。

## 关键解析产物

- `cfg_app272_entries.csv`：从 `cfg.bin` 解析出的应用/游戏条目；重点看 `title/icon/target_mrp/url`。
- `notable_cfg_entries.csv`：过滤后的重点条目，包括机甲风暴、wapgame、assg、gkdxy 等。
- `cfg_module48_entries.csv`：公共模块列表。
- `selected_mrp_entries.csv`：选定 MRP 的包内文件清单。
- `mrp_update_evidence_hits.csv`：更新/下载/启动相关字符串命中。
- `extracted_selected_mrp/*.strings.txt`：模块字符串明细。

## 当前最重要的文件证据

### 1. cfg.bin 能解析出机甲风暴条目

在 `cfg_app272_entries.csv` / `notable_cfg_entries.csv` 中能看到：

```text
标题：机甲风暴(火爆公测)
图标：ng_jjfb.gif
目标：gwy/jjfb.mrp
```

这说明点击条目最终目标确实是本地 `gwy/jjfb.mrp`，但会先经过 `gamelist/cfg` 的公共更新检查。

### 2. gamelist.ext 里有强制更新弹窗文本

`mrp_update_evidence_hits.csv` 中能看到 `gamelist.mrp -> gamelist.ext` 命中：

```text
软件需要联网检查更新
是否立刻更新
检测到新版本
检测到公共模块有新版本
版本更新完毕
正在更新
文件更新成功
文件更新失败
```

这说明弹窗不是机甲风暴自己的逻辑，而是 `gamelist` 公共启动检查。

### 3. vdload.ext 证明存在 HTTP 下载/确认链

能看到：

```text
spd.skymobiapp.com:6009
/simpleDownload
/continueDownload
/dl_confirm
Content-Type:application/x-tar
POST %s HTTP/1.1
```

这说明 20000 之外，还可能存在 HTTP/6009 更新链；但当前 mock 已把二进制链推进到 25B，因此先围绕 25B 事务测试。

## 不能直接解析的部分

`.ext` 解开后是 `MRPGCMAP + ARM/Thumb` 机器码，不是脚本源码。现在能做：

- 提字符串；
- 定位模块；
- 反汇编找分支；
- 根据字符串交叉引用定位“更新完成/失败”的跳转。

不能直接做到：

- 一键还原 C 源码；
- 直接知道 25B 的完整二进制回复格式。

## 给 OpenClaw 的新任务

```text
不是完全不能解析。先使用本包里的 cfg_app272_entries.csv、notable_cfg_entries.csv 和 mrp_update_evidence_hits.csv。
当前文件证据表明：gwy/cfg.bin 能解析出条目目录，机甲风暴对应 gwy/jjfb.mrp；gamelist.ext 负责强制更新弹窗；vdload.ext 负责版本/下载确认链。
下一步不要泛泛猜包，应该把 25B 事务和 gamelist/vdload 的“更新完成/无需更新/空文件列表”语义对应起来。
```
