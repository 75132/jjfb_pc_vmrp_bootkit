from pathlib import Path
import sys, gzip, struct, re

p = Path(sys.argv[1])
b = p.read_bytes()
print('file', p, 'size', len(b))
print('contains dload.mrp?', b'dload.mrp' in b)
print('contains jjfb.mrp?', b'jjfb.mrp' in b)
