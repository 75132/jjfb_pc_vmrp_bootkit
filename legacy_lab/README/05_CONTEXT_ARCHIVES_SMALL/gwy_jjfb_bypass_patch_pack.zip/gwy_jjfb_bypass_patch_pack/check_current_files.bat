@echo off
setlocal
cd /d "%~dp0"
echo [INFO] patch pack dir: %CD%
adb devices
echo.

echo [mythroad/gwy]
adb shell "ls -l /sdcard/mythroad/gwy/cfg.bin /sdcard/mythroad/gwy/gamelist.mrp /sdcard/mythroad/gwy/jjfb.mrp /sdcard/mythroad/gwy/sdk_key.dat 2>/dev/null"
echo.
echo [mythroad/240x320/gwy]
adb shell "ls -l /sdcard/mythroad/240x320/gwy/cfg.bin /sdcard/mythroad/240x320/gwy/gamelist.mrp /sdcard/mythroad/240x320/gwy/jjfb.mrp /sdcard/mythroad/240x320/gwy/sdk_key.dat 2>/dev/null"
pause
