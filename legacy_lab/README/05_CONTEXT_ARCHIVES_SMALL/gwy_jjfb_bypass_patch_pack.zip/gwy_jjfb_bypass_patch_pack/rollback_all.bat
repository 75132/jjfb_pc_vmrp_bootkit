@echo off
setlocal
cd /d "%~dp0"
echo [INFO] patch pack dir: %CD%
adb devices
echo.

echo [INFO] rollback from /sdcard backup
adb shell "if [ -f /sdcard/mythroad/gwy/_patch_backup/cfg.bin.bak ]; then cp /sdcard/mythroad/gwy/_patch_backup/cfg.bin.bak /sdcard/mythroad/gwy/cfg.bin; fi"
adb shell "if [ -f /sdcard/mythroad/gwy/_patch_backup/gamelist.mrp.bak ]; then cp /sdcard/mythroad/gwy/_patch_backup/gamelist.mrp.bak /sdcard/mythroad/gwy/gamelist.mrp; fi"
adb shell "if [ -f /sdcard/mythroad/240x320/gwy/_patch_backup/cfg.bin.bak ]; then cp /sdcard/mythroad/240x320/gwy/_patch_backup/cfg.bin.bak /sdcard/mythroad/240x320/gwy/cfg.bin; fi"
adb shell "if [ -f /sdcard/mythroad/240x320/gwy/_patch_backup/gamelist.mrp.bak ]; then cp /sdcard/mythroad/240x320/gwy/_patch_backup/gamelist.mrp.bak /sdcard/mythroad/240x320/gwy/gamelist.mrp; fi"
echo [DONE] rollback attempted.
pause
