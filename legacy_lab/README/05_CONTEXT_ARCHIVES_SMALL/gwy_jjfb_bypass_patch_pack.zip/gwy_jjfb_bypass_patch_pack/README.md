# gwy_jjfb_bypass_patch_pack

目标：绕过网游专区点击“机甲风暴”后的强制联网检查，让它尽量直接启动 `gwy/jjfb.mrp`。

优先看：

```text
reports/analysis_and_test_plan.md
```

推荐测试顺序：

```text
1. rollback_all.bat
2. install_01_gamelist_dload_to_jjfb.bat
3. 测试机甲风暴

如果无变化：
1. rollback_all.bat
2. install_03_combined_recommended.bat
3. 测试机甲风暴
```

每次只测一个补丁，不要叠加。
