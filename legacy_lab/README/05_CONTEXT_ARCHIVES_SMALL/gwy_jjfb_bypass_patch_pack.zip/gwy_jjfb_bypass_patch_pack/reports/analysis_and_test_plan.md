# gwy / 机甲风暴 强制联网检查 patch 包

## 当前分析结论

你现在卡住的位置已经不是 `dyd.apk`，也不是 21003 劫持失败。最新抓包说明：

```text
gwy/gamelist 选择“机甲风暴”
↓
进入 111.1.17.146:21003 认证/ACK
↓
真实服务器也只回认证和 ACK，不下发游戏启动业务数据
↓
客户端主动断开/重连
```

所以继续补 21003 mock 的收益不高。现在应该改为 patch 本地大厅逻辑：**让 `gwy/gamelist.mrp` 不再把“确定更新”导向下载/联网检查，而是直接导向 `gwy/jjfb.mrp`。**

## 本包做了什么

我做了 5 个实验补丁，按优先级测试：

### 01_gamelist_dload_to_jjfb

改 `gwy/gamelist.mrp` 里面的 `gamelist.ext` 字符串池：

```text
dload.mrp  →  jjfb.mrp\0
```

原因：`gamelist.ext` 明确包含 `dload.mrp`，而当前界面“软件需要联网检查更新 → 确定”很可能就是调用 `dload.mrp`。这个补丁把下载器入口换成机甲风暴入口。

这是我认为**最值得先试**的补丁。

### 02_cfg_jjfb_remove_update05

只改外部：

```text
gwy/cfg.bin
```

把 `gwy/jjfb.mrp` 记录的动作列表：

```text
03 05 FF FF ...
```

改成：

```text
03 FF FF FF ...
```

推测 `05` 可能是“更新/检查”动作，`03` 更像“启动/进入”动作。

### 03_combined_recommended

组合补丁：

```text
gamelist.mrp: dload.mrp → jjfb.mrp
cfg.bin:      03 05 → 03 FF
```

如果 01 有变化但还没进游戏，就试这个。

### 04_cfg_jjfb_action_0803

把 `jjfb` 的动作列表改成 `xyol/yxlm` 常见的：

```text
08 03 FF FF ...
```

备用实验。

### 05_cfg_jjfb_nextid0_remove05

在 02 基础上，再把 `jjfb` 记录里的一个疑似 `nextid/ncode` 字段从 `01` 改成 `00`。这个激进一点，最后再试。

## jjfb cfg 定位证据

外部 `gwy/cfg.bin` 中：

```text
gwy/jjfb.mrp offset = 10943
record_start       = 10808
action_list offset = 10983
old action bytes   = 0305ffffffffffffffffffffffffffff
```

`gamelist.ext` 中：

```text
dload.mrp offset in uncompressed gamelist.ext = 82564
```

## 测试顺序

建议按这个顺序：

```text
1. install_01_gamelist_dload_to_jjfb.bat
2. install_03_combined_recommended.bat
3. install_02_cfg_jjfb_remove_update05.bat
4. install_04_cfg_jjfb_action_0803.bat
5. install_05_cfg_jjfb_nextid0_remove05.bat
```

每次测试前先运行：

```text
rollback_all.bat
```

再安装新的补丁，避免多个实验叠在一起影响判断。

## 判断标准

运行 iacMrp / gwy.mrp，进入网游专区，选“机甲风暴”。

### 好结果

```text
不再出现“软件需要联网检查更新”
或者点“确定”后不再连接 21003
或者直接进入/加载 jjfb
```

### 中间结果

```text
提示变化、错误变化、变成 sdk_key 报错、路径找不到
```

这也是好事，说明 patch 命中了启动分支。

### 坏结果

```text
仍然完全一样地进入 21003 长轮询
```

说明这个补丁没打到关键分支，回滚后试下一个。

## 文件位置

所有补丁都同时推送到两个可能路径：

```text
/sdcard/mythroad/gwy/
/sdcard/mythroad/240x320/gwy/
```

因为你的截图里这两个位置都存在。
