; function-oriented angr/capstone disassembly

; ===== sub_0 @ 0x0 offset=0x0 size=8 blocks=1 cc=1 =====
; block 0x0
0x000000:	ldrbmi  	r5, [r0, -sp, asr #4]
0x000004:	subpl   	r4, r1, r3, asr #26
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0x4b54

; ===== _start @ 0x8 offset=0x8 size=20 blocks=2 cc=1 =====
; block 0x8
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0x4b54
; block 0x18
0x000018:	pop     	{r4, pc}

; ===== sub_1c @ 0x1c offset=0x1c size=4 blocks=1 cc=1 =====
; block 0x1c
0x00001c:	andeq   	r4, r0, r8, ror r7
0x000020:	ands    	r2, r0, #128, #8
0x000024:	rsbmi   	r0, r0, #0
0x000028:	eors    	r3, r2, r1, asr #32
0x00002c:	rsbhs   	r1, r1, #0
0x000030:	rsbs    	ip, r0, r1, lsr #3
0x000034:	blo     	#0xbc

; ===== sub_20 @ 0x20 offset=0x20 size=424 blocks=31 cc=14 =====
; block 0x20
0x000020:	ands    	r2, r0, #128, #8
0x000024:	rsbmi   	r0, r0, #0
0x000028:	eors    	r3, r2, r1, asr #32
0x00002c:	rsbhs   	r1, r1, #0
0x000030:	rsbs    	ip, r0, r1, lsr #3
0x000034:	blo     	#0xbc
; block 0x38
0x000038:	rsbs    	ip, r0, r1, lsr #8
0x00003c:	blo     	#0x80
; block 0x40
0x000040:	lsl     	r0, r0, #8
0x000044:	orr     	r2, r2, #0xff000000
0x000048:	rsbs    	ip, r0, r1, lsr #4
0x00004c:	blo     	#0xb0
; block 0x50
0x000050:	rsbs    	ip, r0, r1, lsr #8
0x000054:	blo     	#0x80
; block 0x58
0x000058:	lsl     	r0, r0, #8
0x00005c:	orr     	r2, r2, #0xff0000
0x000060:	rsbs    	ip, r0, r1, lsr #8
0x000064:	lslhs   	r0, r0, #8
0x000068:	orrhs   	r2, r2, #0xff00
0x00006c:	rsbs    	ip, r0, r1, lsr #4
0x000070:	blo     	#0xb0
; block 0x74
0x000074:	rsbs    	ip, r0, #0
0x000078:	bhs     	#0xf8
; block 0x7c
0x00007c:	lsrhs   	r0, r0, #8
0x000080:	rsbs    	ip, r0, r1, lsr #7
0x000084:	subhs   	r1, r1, r0, lsl #7
0x000088:	adc     	r2, r2, r2
0x00008c:	rsbs    	ip, r0, r1, lsr #6
0x000090:	subhs   	r1, r1, r0, lsl #6
0x000094:	adc     	r2, r2, r2
0x000098:	rsbs    	ip, r0, r1, lsr #5
0x00009c:	subhs   	r1, r1, r0, lsl #5
0x0000a0:	adc     	r2, r2, r2
0x0000a4:	rsbs    	ip, r0, r1, lsr #4
0x0000a8:	subhs   	r1, r1, r0, lsl #4
0x0000ac:	adc     	r2, r2, r2
0x0000b0:	rsbs    	ip, r0, r1, lsr #3
0x0000b4:	subhs   	r1, r1, r0, lsl #3
0x0000b8:	adc     	r2, r2, r2
0x0000bc:	rsbs    	ip, r0, r1, lsr #2
0x0000c0:	subhs   	r1, r1, r0, lsl #2
0x0000c4:	adc     	r2, r2, r2
0x0000c8:	rsbs    	ip, r0, r1, lsr #1
0x0000cc:	subhs   	r1, r1, r0, lsl #1
0x0000d0:	adc     	r2, r2, r2
0x0000d4:	rsbs    	ip, r0, r1
0x0000d8:	subhs   	r1, r1, r0
0x0000dc:	adcs    	r2, r2, r2
0x0000e0:	bhs     	#0x7c
; block 0x80
0x000080:	rsbs    	ip, r0, r1, lsr #7
0x000084:	subhs   	r1, r1, r0, lsl #7
0x000088:	adc     	r2, r2, r2
0x00008c:	rsbs    	ip, r0, r1, lsr #6
0x000090:	subhs   	r1, r1, r0, lsl #6
0x000094:	adc     	r2, r2, r2
0x000098:	rsbs    	ip, r0, r1, lsr #5
0x00009c:	subhs   	r1, r1, r0, lsl #5
0x0000a0:	adc     	r2, r2, r2
0x0000a4:	rsbs    	ip, r0, r1, lsr #4
0x0000a8:	subhs   	r1, r1, r0, lsl #4
0x0000ac:	adc     	r2, r2, r2
0x0000b0:	rsbs    	ip, r0, r1, lsr #3
0x0000b4:	subhs   	r1, r1, r0, lsl #3
0x0000b8:	adc     	r2, r2, r2
0x0000bc:	rsbs    	ip, r0, r1, lsr #2
0x0000c0:	subhs   	r1, r1, r0, lsl #2
0x0000c4:	adc     	r2, r2, r2
0x0000c8:	rsbs    	ip, r0, r1, lsr #1
0x0000cc:	subhs   	r1, r1, r0, lsl #1
0x0000d0:	adc     	r2, r2, r2
0x0000d4:	rsbs    	ip, r0, r1
0x0000d8:	subhs   	r1, r1, r0
0x0000dc:	adcs    	r2, r2, r2
0x0000e0:	bhs     	#0x7c
; block 0xb0
0x0000b0:	rsbs    	ip, r0, r1, lsr #3
0x0000b4:	subhs   	r1, r1, r0, lsl #3
0x0000b8:	adc     	r2, r2, r2
0x0000bc:	rsbs    	ip, r0, r1, lsr #2
0x0000c0:	subhs   	r1, r1, r0, lsl #2
0x0000c4:	adc     	r2, r2, r2
0x0000c8:	rsbs    	ip, r0, r1, lsr #1
0x0000cc:	subhs   	r1, r1, r0, lsl #1
0x0000d0:	adc     	r2, r2, r2
0x0000d4:	rsbs    	ip, r0, r1
0x0000d8:	subhs   	r1, r1, r0
0x0000dc:	adcs    	r2, r2, r2
0x0000e0:	bhs     	#0x7c
; block 0xbc
0x0000bc:	rsbs    	ip, r0, r1, lsr #2
0x0000c0:	subhs   	r1, r1, r0, lsl #2
0x0000c4:	adc     	r2, r2, r2
0x0000c8:	rsbs    	ip, r0, r1, lsr #1
0x0000cc:	subhs   	r1, r1, r0, lsl #1
0x0000d0:	adc     	r2, r2, r2
0x0000d4:	rsbs    	ip, r0, r1
0x0000d8:	subhs   	r1, r1, r0
0x0000dc:	adcs    	r2, r2, r2
0x0000e0:	bhs     	#0x7c
; block 0xe4
0x0000e4:	eors    	r0, r2, r3, asr #31
0x0000e8:	add     	r0, r0, r3, lsr #31
0x0000ec:	rsbhs   	r1, r1, #0
0x0000f0:	bx      	lr
; block 0xf8
0x0000f8:	mov     	r0, #2
0x0000fc:	mov     	r1, #2
0x000100:	b       	#0x118
; block 0x118
0x000118:	push    	{r4, lr}
0x00011c:	blx     	#0x134
; block 0x120
0x000120:	cmp     	r0, #0
0x000124:	popeq   	{r4, lr}
0x000128:	bxeq    	lr
; block 0x128
0x000128:	bxeq    	lr
; block 0x12c
0x00012c:	pop     	{r4, lr}
0x000130:	b       	#0x17c
; block 0x17c
0x00017c:	mov     	r0, #0x18
0x000180:	ldr     	r1, [pc, #8]
0x000184:	svc     	#0x123456
; block 0x188
0x000188:	bx      	lr
; block 0x8c3
0x0008c3:	ldr     	r2, [r4, #8]
0x0008c5:	bl      	#0x4c2d
; block 0x8c9
0x0008c9:	lsls    	r0, r0, #0x18
0x0008cb:	asrs    	r0, r0, #0x18
0x0008cd:	cmp     	r0, #1
0x0008cf:	bne     	#0x935
; block 0x8d1
0x0008d1:	movs    	r1, #0
0x0008d3:	str     	r1, [sp]
0x0008d5:	str     	r1, [sp, #4]
0x0008d7:	movs    	r2, #0
0x0008d9:	str     	r2, [sp, #8]
0x0008db:	movs    	r1, #0x45
0x0008dd:	adds    	r3, r5, #0
0x0008df:	adds    	r0, r6, #0
0x0008e1:	ldr     	r2, [r4, #8]
0x0008e3:	bl      	#0x4c2d
; block 0x8e7
0x0008e7:	ldr     	r7, [pc, #0x78]
0x0008e9:	movs    	r1, #0
0x0008eb:	add     	r7, sb
0x0008ed:	str     	r0, [r7, #0x58]
0x0008ef:	str     	r1, [sp]
0x0008f1:	str     	r1, [sp, #4]
0x0008f3:	movs    	r2, #0
0x0008f5:	str     	r2, [sp, #8]
0x0008f7:	movs    	r1, #0x46
0x0008f9:	adds    	r3, r5, #0
0x0008fb:	adds    	r0, r6, #0
0x0008fd:	ldr     	r2, [r4, #8]
0x0008ff:	bl      	#0x4c2d
; block 0x903
0x000903:	strb    	r0, [r7, #8]
0x000905:	movs    	r1, #0
0x000907:	str     	r1, [sp]
0x000909:	str     	r1, [sp, #4]
0x00090b:	movs    	r2, #0
0x00090d:	str     	r2, [sp, #8]
0x00090f:	movs    	r1, #0x47
0x000911:	adds    	r3, r5, #0
0x000913:	adds    	r0, r6, #0
0x000915:	ldr     	r2, [r4, #8]
0x000917:	bl      	#0x4c2d
; block 0x91b
0x00091b:	str     	r0, [r7, #0x5c]
0x00091d:	movs    	r1, #0
0x00091f:	str     	r1, [sp]
0x000921:	str     	r1, [sp, #4]
0x000923:	movs    	r2, #0
0x000925:	str     	r2, [sp, #8]
0x000927:	movs    	r1, #0x47
0x000929:	adds    	r3, r5, #0
0x00092b:	adds    	r0, r6, #0
0x00092d:	ldr     	r2, [r4, #8]
0x00092f:	bl      	#0x4c2d
; block 0x933
0x000933:	str     	r0, [r7, #0x60]
0x000935:	movs    	r1, #0
0x000937:	movs    	r2, #0
0x000939:	str     	r2, [sp, #8]
0x00093b:	str     	r1, [sp]
0x00093d:	str     	r1, [sp, #4]
0x00093f:	movs    	r1, #0xe1
0x000941:	movs    	r2, #0x17
0x000943:	adds    	r3, r5, #0
0x000945:	adds    	r0, r6, #0
0x000947:	bl      	#0x4c2d
; block 0x935
0x000935:	movs    	r1, #0
0x000937:	movs    	r2, #0
0x000939:	str     	r2, [sp, #8]
0x00093b:	str     	r1, [sp]
0x00093d:	str     	r1, [sp, #4]
0x00093f:	movs    	r1, #0xe1
0x000941:	movs    	r2, #0x17
0x000943:	adds    	r3, r5, #0
0x000945:	adds    	r0, r6, #0
0x000947:	bl      	#0x4c2d
; block 0x94b
0x00094b:	subs    	r0, #0xff
0x00094d:	subs    	r0, #0x3c
0x00094f:	bne     	#0x959
; block 0x951
0x000951:	bl      	#0x3a41
; block 0x955
0x000955:	add     	sp, #0xc
0x000957:	pop     	{r4, r5, r6, r7, pc}
; block 0x959
0x000959:	bl      	#0x3ba1
; block 0x95d
0x00095d:	b       	#0x955

; ===== sub_f4 @ 0xf4 offset=0xf4 size=4 blocks=1 cc=1 =====
; block 0xf4
0x0000f4:	andeq   	r4, r0, r8, ror r7
0x0000f8:	mov     	r0, #2
0x0000fc:	mov     	r1, #2
0x000100:	b       	#0x118

; ===== sub_109 @ 0x109 offset=0x108 size=2 blocks=1 cc=1 =====
; block 0x109
0x000109:	bx      	r2

; ===== sub_10b @ 0x10b offset=0x10a size=2 blocks=1 cc=1 =====
; block 0x10b
0x00010b:	bx      	r3

; ===== sub_135 @ 0x135 offset=0x134 size=58 blocks=7 cc=3 =====
; block 0x135
0x000135:	push    	{r4, r5, r6, lr}
0x000137:	ldr     	r6, [pc, #0x38]
0x000139:	adds    	r5, r1, #0
0x00013b:	adds    	r1, r0, #0
0x00013d:	adds    	r4, r0, #0
0x00013f:	add     	r6, pc
0x000141:	adds    	r0, r6, #0
0x000143:	bl      	#0x147
; block 0x147
0x000147:	adds    	r2, r0, #0
0x000149:	cmp     	r0, r6
0x00014b:	bne     	#0x15b
; block 0x14d
0x00014d:	adds    	r1, r5, #0
0x00014f:	adds    	r0, r4, #0
0x000151:	bl      	#0x195
; block 0x155
0x000155:	pop     	{r4, r5, r6}
0x000157:	pop     	{r3}
0x000159:	bx      	r3
; block 0x15b
0x00015b:	ldr     	r0, [pc, #0x18]
0x00015d:	add     	r0, pc
0x00015f:	cmp     	r2, r0
0x000161:	beq     	#0x16b
; block 0x163
0x000163:	adds    	r1, r5, #0
0x000165:	adds    	r0, r4, #0
0x000167:	bl      	#0x109
; block 0x16b
0x00016b:	movs    	r0, #0
0x00016d:	b       	#0x155

; ===== sub_177 @ 0x177 offset=0x176 size=6 blocks=1 cc=1 =====
; block 0x177
0x000177:	vqshl.u32	q10, q12, #0x17
0x00017b:	movs    	r0, r0
0x00017d:	movs    	r0, r3
0x00017f:	b       	#0x8c3

; ===== sub_18d @ 0x18d offset=0x18c size=8 blocks=1 cc=1 =====
; block 0x18d
0x00018d:	lsls    	r1, r4, #4
0x00018f:	movs    	r0, r0
0x000191:	movs    	r6, r4
0x000193:	movs    	r2, r0
0x000195:	push    	{r3, r4, r5, lr}
0x000197:	subs    	r2, r0, #1
0x000199:	cmp     	r2, #0xd
0x00019b:	adr     	r4, #0x90
0x00019d:	bhs     	#0x1ed

; ===== sub_195 @ 0x195 offset=0x194 size=150 blocks=27 cc=18 =====
; block 0x195
0x000195:	push    	{r3, r4, r5, lr}
0x000197:	subs    	r2, r0, #1
0x000199:	cmp     	r2, #0xd
0x00019b:	adr     	r4, #0x90
0x00019d:	bhs     	#0x1ed
; block 0x19f
0x00019f:	movs    	r2, #0x17
0x0001a1:	ldr     	r3, [pc, #0x8c]
0x0001a3:	muls    	r2, r0, r2
0x0001a5:	add     	r3, pc
0x0001a7:	adds    	r5, r2, r3
0x0001a9:	subs    	r5, #0x17
0x0001ab:	cmp     	r0, #2
0x0001ad:	bne     	#0x1d9
; block 0x1af
0x0001af:	lsls    	r0, r1, #5
0x0001b1:	bpl     	#0x1b7
; block 0x1b3
0x0001b3:	adr     	r4, #0x80
0x0001b5:	b       	#0x1ef
; block 0x1b7
0x0001b7:	ldr     	r0, [pc, #0x90]
0x0001b9:	ands    	r0, r1
0x0001bb:	beq     	#0x1c1
; block 0x1bd
0x0001bd:	adr     	r4, #0x8c
0x0001bf:	b       	#0x1ef
; block 0x1c1
0x0001c1:	lsls    	r0, r1, #3
0x0001c3:	bpl     	#0x1c9
; block 0x1c5
0x0001c5:	adr     	r4, #0x94
0x0001c7:	b       	#0x1ef
; block 0x1c9
0x0001c9:	lsls    	r0, r1, #2
0x0001cb:	bpl     	#0x1d1
; block 0x1cd
0x0001cd:	adr     	r4, #0x98
0x0001cf:	b       	#0x1ef
; block 0x1d1
0x0001d1:	lsls    	r0, r1, #1
0x0001d3:	bpl     	#0x1ef
; block 0x1d5
0x0001d5:	adr     	r4, #0x9c
0x0001d7:	b       	#0x1ef
; block 0x1d9
0x0001d9:	cmp     	r0, #8
0x0001db:	bne     	#0x1e1
; block 0x1dd
0x0001dd:	adds    	r4, r1, #0
0x0001df:	b       	#0x1ef
; block 0x1e1
0x0001e1:	cmp     	r0, #9
0x0001e3:	bne     	#0x1ef
; block 0x1e5
0x0001e5:	cmp     	r1, #1
0x0001e7:	bne     	#0x1ef
; block 0x1e9
0x0001e9:	adr     	r5, #0x98
0x0001eb:	b       	#0x1ef
; block 0x1ed
0x0001ed:	adr     	r5, #0xac
0x0001ef:	movs    	r0, #0xa
0x0001f1:	bl      	#0x2b5
; block 0x1ef
0x0001ef:	movs    	r0, #0xa
0x0001f1:	bl      	#0x2b5
; block 0x1f5
0x0001f5:	ldrb    	r0, [r5]
0x0001f7:	cmp     	r0, #0
0x0001f9:	beq     	#0x209
; block 0x1fb
0x0001fb:	ldrb    	r0, [r5]
0x0001fd:	adds    	r5, #1
0x0001ff:	bl      	#0x2b5
; block 0x203
0x000203:	ldrb    	r0, [r5]
0x000205:	cmp     	r0, #0
0x000207:	bne     	#0x1fb
; block 0x209
0x000209:	ldrb    	r0, [r4]
0x00020b:	cmp     	r0, #0
0x00020d:	beq     	#0x21d
; block 0x20f
0x00020f:	ldrb    	r0, [r4]
0x000211:	adds    	r4, #1
0x000213:	bl      	#0x2b5
; block 0x217
0x000217:	ldrb    	r0, [r4]
0x000219:	cmp     	r0, #0
0x00021b:	bne     	#0x20f
; block 0x21d
0x00021d:	movs    	r0, #0xa
0x00021f:	bl      	#0x2b5
; block 0x223
0x000223:	pop     	{r3, r4, r5}
0x000225:	pop     	{r3}
0x000227:	movs    	r0, #1
0x000229:	bx      	r3

; ===== sub_231 @ 0x231 offset=0x230 size=130 blocks=2 cc=1 =====
; block 0x231
0x000231:	ldrsh   	r0, [r3, r5]
0x000233:	movs    	r0, r0
0x000235:	ldr     	r1, [r1, #0x64]
0x000237:	str     	r6, [r6, #0x14]
0x000239:	ldr     	r4, [r5, #0x14]
0x00023b:	movs    	r0, #0x64
0x00023d:	strb    	r7, [r1, #1]
0x00023f:	strb    	r5, [r4, #9]
0x000241:	strb    	r1, [r4, #0x11]
0x000243:	ldr     	r1, [r5, #0x74]
0x000245:	lsls    	r6, r5, #1
0x000247:	movs    	r0, r0
0x000249:	movs    	r2, r0
0x00024b:	lsrs    	r0, r0, #0x20
0x00024d:	ldr     	r4, [r0, #0x14]
0x00024f:	ldr     	r6, [r6, #0x14]
0x000251:	str     	r4, [r4, #0x54]
0x000253:	tst     	r0, r4
0x000255:	movs    	r0, #0x79
0x000257:	str     	r2, [r3, #0x54]
0x000259:	ldr     	r2, [r6, #0x74]
0x00025b:	movs    	r0, r0
0x00025d:	strb    	r7, [r1, #0x19]
0x00025f:	strb    	r5, [r4, #9]
0x000261:	ldr     	r6, [r4, #0x44]
0x000263:	strb    	r7, [r5, #0x1d]
0x000265:	movs    	r0, r0
0x000267:	movs    	r0, r0
0x000269:	ldr     	r5, [r2, #0x64]
0x00026b:	str     	r4, [r4, #0x54]
0x00026d:	str     	r2, [r6, #0x64]
0x00026f:	ldr     	r4, [r5, #0x74]
0x000271:	lsls    	r7, r6, #1
0x000273:	movs    	r0, r0
0x000275:	ldr     	r1, [r1, #0x64]
0x000277:	ldrb    	r5, [r4, #1]
0x000279:	str     	r1, [r4, #0x34]
0x00027b:	movs    	r0, #0x74
0x00027d:	str     	r2, [r2, #0x54]
0x00027f:	strb    	r3, [r6, #0x15]
0x000281:	strb    	r4, [r5, #0x11]
0x000283:	movs    	r0, r0
0x000285:	movs    	r0, #0x3a
0x000287:	str     	r0, [r1, #0x54]
0x000289:	strb    	r1, [r4, #1]
0x00028b:	ldr     	r0, [r4, #0x50]
0x00028d:	ldr     	r5, [r4, #0x54]
0x00028f:	strb    	r7, [r5, #9]
0x000291:	movs    	r0, #0x79
0x000293:	ldr     	r3, [r4, #0x74]
0x000295:	strb    	r2, [r6, #9]
0x000297:	strb    	r5, [r6, #1]
0x000299:	str     	r4, [r6, #0x54]
0x00029b:	lsls    	r4, r4, #1
0x00029d:	ldr     	r5, [r2, #0x64]
0x00029f:	ldr     	r3, [r5, #0x64]
0x0002a1:	strb    	r7, [r5, #0x1d]
0x0002a3:	movs    	r0, #0x6e
0x0002a5:	ldr     	r3, [r6, #0x14]
0x0002a7:	ldr     	r7, [r4, #0x64]
0x0002a9:	ldr     	r1, [r4, #0x44]
0x0002ab:	movs    	r0, r0
0x0002ad:	bx      	pc
; block 0x2b0
0x0002b0:	bx      	lr

; ===== sub_2b5 @ 0x2b5 offset=0x2b4 size=18 blocks=2 cc=1 =====
; block 0x2b5
0x0002b5:	push    	{r3, lr}
0x0002b7:	add     	r3, sp, #0
0x0002b9:	strb    	r0, [r3]
0x0002bb:	movs    	r0, #3
0x0002bd:	mov     	r1, sp
0x0002bf:	svc     	#0xab
; block 0x2c1
0x0002c1:	add     	sp, #4
0x0002c3:	pop     	{r3}
0x0002c5:	bx      	r3

; ===== sub_2c8 @ 0x2c8 offset=0x2c8 size=16 blocks=1 cc=1 =====
; block 0x2c8
0x0002c8:	ldr     	r0, [pc, #8]
0x0002cc:	ldr     	r1, [pc, #8]
0x0002d0:	add     	r0, r0, r1
0x0002d4:	bx      	lr

; ===== sub_2d9 @ 0x2d9 offset=0x2d8 size=102 blocks=6 cc=4 =====
; block 0x2d9
0x0002d9:	movs    	r4, r0
0x0002db:	movs    	r0, r0
0x0002dd:	lsls    	r4, r2, #7
0x0002df:	movs    	r0, r0
0x0002e1:	str     	r0, [sp]
0x0002e3:	b       	#0x627
; block 0x627
0x000627:	lsls    	r0, r0, #9
0x000629:	bl      	#0x4c2d
; block 0x62d
0x00062d:	movs    	r1, #0
0x00062f:	str     	r1, [sp]
0x000631:	str     	r1, [sp, #4]
0x000633:	movs    	r2, #0
0x000635:	str     	r2, [sp, #8]
0x000637:	movs    	r1, #0x45
0x000639:	adds    	r3, r5, #0
0x00063b:	movs    	r0, #0xf1
0x00063d:	lsls    	r0, r0, #9
0x00063f:	ldr     	r2, [r4, #8]
0x000641:	bl      	#0x4c2d
; block 0x645
0x000645:	movs    	r1, #0
0x000647:	str     	r1, [sp]
0x000649:	str     	r1, [sp, #4]
0x00064b:	adds    	r6, r0, #0
0x00064d:	movs    	r2, #0
0x00064f:	str     	r2, [sp, #8]
0x000651:	movs    	r0, #0xf1
0x000653:	adds    	r3, r5, #0
0x000655:	movs    	r1, #0x45
0x000657:	lsls    	r0, r0, #9
0x000659:	ldr     	r2, [r4, #8]
0x00065b:	bl      	#0x4c2d
; block 0x65f
0x00065f:	ldr     	r1, [pc, #0x20]
0x000661:	movs    	r2, #0
0x000663:	add     	r1, sb
0x000665:	str     	r0, [r1, #0x68]
0x000667:	str     	r6, [r1, #0x64]
0x000669:	movs    	r1, #0
0x00066b:	str     	r1, [sp]
0x00066d:	str     	r1, [sp, #4]
0x00066f:	movs    	r1, #0x2c
0x000671:	movs    	r0, #0xf1
0x000673:	adds    	r3, r5, #0
0x000675:	lsls    	r0, r0, #9
0x000677:	str     	r2, [sp, #8]
0x000679:	bl      	#0x4c2d
; block 0x67d
0x00067d:	add     	sp, #0x10
0x00067f:	pop     	{r4, r5, r6, pc}

; ===== sub_2e5 @ 0x2e5 offset=0x2e4 size=4 blocks=1 cc=1 =====
; block 0x2e5
0x0002e5:	vrhadd.u16	d14, d14, d31
0x0002e9:	adds    	r0, #0x14
0x0002eb:	b       	#0xfffffe2d

; ===== sub_2e8 @ 0x2e8 offset=0x2e8 size=28 blocks=1 cc=1 =====
; block 0x2e8
0x0002e8:	ldr     	r3, [pc, #0x14]
0x0002ec:	asr     	r2, r0, #0x1f
0x0002f0:	smull   	ip, r1, r3, r0
0x0002f4:	mvn     	r3, #0x13
0x0002f8:	rsb     	r1, r2, r1, asr #3
0x0002fc:	mla     	r0, r3, r1, r0
0x000300:	bx      	lr

; ===== sub_305 @ 0x305 offset=0x304 size=4 blocks=1 cc=1 =====
; block 0x305
0x000305:	str     	r7, [r4, #0x64]
0x000307:	str     	r6, [r4, #0x64]
0x000309:	adds    	r0, #0x14
0x00030b:	b       	#0xfffffe4d

; ===== sub_308 @ 0x308 offset=0x308 size=28 blocks=1 cc=1 =====
; block 0x308
0x000308:	ldr     	r3, [pc, #0x14]
0x00030c:	asr     	r2, r0, #0x1f
0x000310:	smull   	ip, r1, r3, r0
0x000314:	mvn     	r3, #5
0x000318:	rsb     	r1, r2, r1
0x00031c:	mla     	r0, r3, r1, r0
0x000320:	bx      	lr

; ===== sub_324 @ 0x324 offset=0x324 size=4 blocks=1 cc=1 =====
; block 0x324
0x000324:	bhs     	#0xfeaaadd8

; ===== sub_329 @ 0x329 offset=0x328 size=22 blocks=1 cc=1 =====
; block 0x329
0x000329:	push    	{r4, r5, lr}
0x00032b:	ldr     	r4, [pc, #0xb4]
0x00032d:	movs    	r2, #0x1c
0x00032f:	add     	r4, pc
0x000331:	ldr     	r0, [r4, #0x38]
0x000333:	movs    	r1, #0
0x000335:	ldr     	r3, [r0, #0x38]
0x000337:	ldr     	r0, [pc, #0xac]
0x000339:	sub     	sp, #0xc
0x00033b:	add     	r0, sb
0x00033d:	blx     	r3

; ===== sub_34b @ 0x34b offset=0x34a size=148 blocks=5 cc=2 =====
; block 0x34b
0x00034b:	str     	r1, [sp, #4]
0x00034d:	movs    	r1, #0x64
0x00034f:	movs    	r0, #1
0x000351:	str     	r2, [sp, #8]
0x000353:	bl      	#0x4c2d
; block 0x357
0x000357:	ldr     	r1, [pc, #0x8c]
0x000359:	movs    	r0, #0
0x00035b:	add     	r1, sb
0x00035d:	subs    	r1, #0x7c
0x00035f:	str     	r0, [r1, #8]
0x000361:	ldr     	r5, [pc, #0x80]
0x000363:	str     	r0, [r1, #0x10]
0x000365:	str     	r0, [r1, #0xc]
0x000367:	add     	r5, sb
0x000369:	subs    	r5, #0xfc
0x00036b:	movs    	r0, #1
0x00036d:	str     	r0, [r5, #0x18]
0x00036f:	ldr     	r0, [r4, #0x38]
0x000371:	ldr     	r2, [pc, #0x74]
0x000373:	ldr     	r1, [r0, #0x68]
0x000375:	add     	r2, sb
0x000377:	str     	r1, [r5, #0x2c]
0x000379:	ldr     	r1, [r0, #0xc]
0x00037b:	ldr     	r4, [pc, #0x70]
0x00037d:	str     	r1, [r5, #0x30]
0x00037f:	ldr     	r1, [r0, #0x10]
0x000381:	str     	r1, [r5, #0x34]
0x000383:	ldr     	r1, [r0, #0x14]
0x000385:	str     	r1, [r5, #0x38]
0x000387:	ldr     	r1, [r0, #0x18]
0x000389:	str     	r1, [r5, #0x3c]
0x00038b:	ldr     	r1, [r0, #0x1c]
0x00038d:	str     	r1, [r5, #0x40]
0x00038f:	ldr     	r1, [r0, #0x20]
0x000391:	str     	r1, [r5, #0x44]
0x000393:	ldr     	r1, [r0, #0x24]
0x000395:	str     	r1, [r5, #0x48]
0x000397:	ldr     	r1, [r0, #0x28]
0x000399:	str     	r1, [r5, #0x4c]
0x00039b:	ldr     	r1, [r0, #0x2c]
0x00039d:	str     	r1, [r5, #0x50]
0x00039f:	ldr     	r1, [r0, #0x30]
0x0003a1:	str     	r1, [r5, #0x54]
0x0003a3:	ldr     	r1, [r0, #0x34]
0x0003a5:	str     	r1, [r5, #0x58]
0x0003a7:	ldr     	r1, [r0, #0x38]
0x0003a9:	str     	r1, [r5, #0x5c]
0x0003ab:	ldr     	r1, [r0, #0x3c]
0x0003ad:	str     	r1, [r5, #0x60]
0x0003af:	ldr     	r1, [r0, #0x40]
0x0003b1:	str     	r1, [r5, #0x64]
0x0003b3:	ldr     	r1, [r0, #0x44]
0x0003b5:	str     	r1, [r5, #0x68]
0x0003b7:	ldr     	r1, [r0, #0x48]
0x0003b9:	str     	r1, [r5, #0x6c]
0x0003bb:	ldr     	r1, [r0, #0x4c]
0x0003bd:	str     	r1, [r5, #0x70]
0x0003bf:	movs    	r1, #0
0x0003c1:	str     	r1, [r2]
0x0003c3:	movs    	r1, #1
0x0003c5:	lsls    	r1, r1, #9
0x0003c7:	adds    	r0, r0, r1
0x0003c9:	ldr     	r3, [r0, #8]
0x0003cb:	movs    	r1, #7
0x0003cd:	adds    	r2, r4, #0
0x0003cf:	movs    	r0, #0
0x0003d1:	blx     	r3
; block 0x3d3
0x0003d3:	cmp     	r0, r4
0x0003d5:	bne     	#0x3db
; block 0x3d7
0x0003d7:	subs    	r0, #2
0x0003d9:	str     	r0, [r5, #0x28]
0x0003db:	add     	sp, #0xc
0x0003dd:	pop     	{r4, r5, pc}
; block 0x3db
0x0003db:	add     	sp, #0xc
0x0003dd:	pop     	{r4, r5, pc}

; ===== sub_3e1 @ 0x3e1 offset=0x3e0 size=16 blocks=1 cc=1 =====
; block 0x3e1
0x0003e1:	ldc2    	p15, c15, [r6], {0xff}
0x0003e5:	lsls    	r0, r7, #6
0x0003e7:	movs    	r0, r0
0x0003e9:	lsls    	r4, r2, #7
0x0003eb:	movs    	r0, r0
0x0003ed:	movs    	r7, #0xf
0x0003ef:	movs    	r0, r0
0x0003f1:	push    	{r4, r5, r6, r7, lr}
0x0003f3:	sub     	sp, #0x14
0x0003f5:	movs    	r5, #0
0x0003f7:	movs    	r2, #0
0x0003f9:	movs    	r1, #0
0x0003fb:	str     	r2, [sp, #8]
0x0003fd:	adds    	r3, r5, #0
0x0003ff:	adds    	r4, r0, #0
0x000401:	adds    	r2, r0, #0
0x000403:	str     	r1, [sp]
0x000405:	str     	r1, [sp, #4]
0x000407:	movs    	r1, #0x44
0x000409:	movs    	r0, #0xf1
0x00040b:	lsls    	r0, r0, #9
0x00040d:	bl      	#0x4c2d

; ===== sub_3f1 @ 0x3f1 offset=0x3f0 size=280 blocks=13 cc=11 =====
; block 0x3f1
0x0003f1:	push    	{r4, r5, r6, r7, lr}
0x0003f3:	sub     	sp, #0x14
0x0003f5:	movs    	r5, #0
0x0003f7:	movs    	r2, #0
0x0003f9:	movs    	r1, #0
0x0003fb:	str     	r2, [sp, #8]
0x0003fd:	adds    	r3, r5, #0
0x0003ff:	adds    	r4, r0, #0
0x000401:	adds    	r2, r0, #0
0x000403:	str     	r1, [sp]
0x000405:	str     	r1, [sp, #4]
0x000407:	movs    	r1, #0x44
0x000409:	movs    	r0, #0xf1
0x00040b:	lsls    	r0, r0, #9
0x00040d:	bl      	#0x4c2d
; block 0x411
0x000411:	movs    	r1, #0
0x000413:	str     	r1, [sp]
0x000415:	str     	r1, [sp, #4]
0x000417:	movs    	r2, #0
0x000419:	str     	r2, [sp, #8]
0x00041b:	movs    	r1, #0x45
0x00041d:	adds    	r3, r5, #0
0x00041f:	movs    	r0, #0xf1
0x000421:	lsls    	r0, r0, #9
0x000423:	ldr     	r2, [r4, #8]
0x000425:	bl      	#0x4c2d
; block 0x429
0x000429:	movs    	r1, #0
0x00042b:	str     	r1, [sp]
0x00042d:	str     	r1, [sp, #4]
0x00042f:	str     	r0, [sp, #0x10]
0x000431:	movs    	r2, #0
0x000433:	str     	r2, [sp, #8]
0x000435:	movs    	r0, #0xf1
0x000437:	movs    	r1, #0x47
0x000439:	adds    	r3, r5, #0
0x00043b:	lsls    	r0, r0, #9
0x00043d:	ldr     	r2, [r4, #8]
0x00043f:	bl      	#0x4c2d
; block 0x443
0x000443:	movs    	r1, #0
0x000445:	str     	r1, [sp]
0x000447:	str     	r1, [sp, #4]
0x000449:	adds    	r6, r0, #0
0x00044b:	movs    	r2, #0
0x00044d:	str     	r2, [sp, #8]
0x00044f:	movs    	r0, #0xf1
0x000451:	adds    	r3, r5, #0
0x000453:	movs    	r1, #0x46
0x000455:	lsls    	r0, r0, #9
0x000457:	ldr     	r2, [r4, #8]
0x000459:	bl      	#0x4c2d
; block 0x45d
0x00045d:	ldr     	r7, [pc, #0xa8]
0x00045f:	movs    	r1, #0
0x000461:	add     	r7, sb
0x000463:	strb    	r0, [r7, #1]
0x000465:	str     	r1, [sp]
0x000467:	str     	r1, [sp, #4]
0x000469:	movs    	r2, #0
0x00046b:	str     	r2, [sp, #8]
0x00046d:	movs    	r1, #0x46
0x00046f:	movs    	r0, #0xf1
0x000471:	adds    	r3, r5, #0
0x000473:	lsls    	r0, r0, #9
0x000475:	ldr     	r2, [r4, #8]
0x000477:	bl      	#0x4c2d
; block 0x47b
0x00047b:	strb    	r0, [r7, #7]
0x00047d:	movs    	r1, #0
0x00047f:	str     	r1, [sp]
0x000481:	str     	r1, [sp, #4]
0x000483:	movs    	r2, #0
0x000485:	str     	r2, [sp, #8]
0x000487:	movs    	r1, #0x45
0x000489:	movs    	r0, #0xf1
0x00048b:	adds    	r3, r5, #0
0x00048d:	lsls    	r0, r0, #9
0x00048f:	ldr     	r2, [r4, #8]
0x000491:	bl      	#0x4c2d
; block 0x495
0x000495:	str     	r0, [r7, #0x54]
0x000497:	movs    	r1, #0
0x000499:	str     	r1, [sp]
0x00049b:	str     	r1, [sp, #4]
0x00049d:	movs    	r2, #0
0x00049f:	movs    	r1, #0x2c
0x0004a1:	movs    	r0, #0xf1
0x0004a3:	adds    	r3, r5, #0
0x0004a5:	lsls    	r0, r0, #9
0x0004a7:	str     	r2, [sp, #8]
0x0004a9:	bl      	#0x4c2d
; block 0x4ad
0x0004ad:	movs    	r1, #0
0x0004af:	movs    	r2, #0
0x0004b1:	str     	r2, [sp, #8]
0x0004b3:	str     	r1, [sp]
0x0004b5:	str     	r1, [sp, #4]
0x0004b7:	adds    	r3, r5, #0
0x0004b9:	adds    	r2, r6, #0
0x0004bb:	movs    	r1, #0x33
0x0004bd:	movs    	r0, #0xf1
0x0004bf:	lsls    	r0, r0, #9
0x0004c1:	bl      	#0x4c2d
; block 0x4c5
0x0004c5:	movs    	r1, #0
0x0004c7:	movs    	r2, #0
0x0004c9:	str     	r2, [sp, #8]
0x0004cb:	str     	r1, [sp]
0x0004cd:	str     	r1, [sp, #4]
0x0004cf:	adds    	r3, r5, #0
0x0004d1:	adds    	r2, r6, #0
0x0004d3:	movs    	r1, #9
0x0004d5:	movs    	r0, #0xf1
0x0004d7:	lsls    	r0, r0, #9
0x0004d9:	bl      	#0x4c2d
; block 0x4dd
0x0004dd:	ldr     	r0, [sp, #0x10]
0x0004df:	lsls    	r4, r0, #2
0x0004e1:	ldr     	r0, [r7, #0x28]
0x0004e3:	ldr     	r3, [r0, r4]
0x0004e5:	cmp     	r3, #0
0x0004e7:	beq     	#0x505
; block 0x4e9
0x0004e9:	movs    	r2, #0
0x0004eb:	movs    	r1, #0
0x0004ed:	str     	r2, [sp, #8]
0x0004ef:	adds    	r2, r3, #0
0x0004f1:	str     	r1, [sp]
0x0004f3:	str     	r1, [sp, #4]
0x0004f5:	movs    	r1, #9
0x0004f7:	adds    	r3, r5, #0
0x0004f9:	movs    	r0, #0xf1
0x0004fb:	lsls    	r0, r0, #9
0x0004fd:	bl      	#0x4c2d
; block 0x501
0x000501:	ldr     	r0, [r7, #0x28]
0x000503:	str     	r5, [r0, r4]
0x000505:	add     	sp, #0x14
0x000507:	pop     	{r4, r5, r6, r7, pc}
; block 0x505
0x000505:	add     	sp, #0x14
0x000507:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_509 @ 0x509 offset=0x508 size=4 blocks=1 cc=1 =====
; block 0x509
0x000509:	movs    	r4, r0
0x00050b:	movs    	r0, r0
0x00050d:	push    	{r4, r5, r6, r7, lr}
0x00050f:	sub     	sp, #0xc
0x000511:	movs    	r4, #0
0x000513:	movs    	r2, #0
0x000515:	movs    	r1, #0
0x000517:	str     	r2, [sp, #8]
0x000519:	adds    	r3, r4, #0
0x00051b:	adds    	r5, r0, #0
0x00051d:	adds    	r2, r0, #0
0x00051f:	str     	r1, [sp]
0x000521:	str     	r1, [sp, #4]
0x000523:	movs    	r1, #0x44
0x000525:	movs    	r0, #0xf1
0x000527:	lsls    	r0, r0, #9
0x000529:	bl      	#0x4c2d

; ===== sub_50d @ 0x50d offset=0x50c size=256 blocks=11 cc=10 =====
; block 0x50d
0x00050d:	push    	{r4, r5, r6, r7, lr}
0x00050f:	sub     	sp, #0xc
0x000511:	movs    	r4, #0
0x000513:	movs    	r2, #0
0x000515:	movs    	r1, #0
0x000517:	str     	r2, [sp, #8]
0x000519:	adds    	r3, r4, #0
0x00051b:	adds    	r5, r0, #0
0x00051d:	adds    	r2, r0, #0
0x00051f:	str     	r1, [sp]
0x000521:	str     	r1, [sp, #4]
0x000523:	movs    	r1, #0x44
0x000525:	movs    	r0, #0xf1
0x000527:	lsls    	r0, r0, #9
0x000529:	bl      	#0x4c2d
; block 0x52d
0x00052d:	movs    	r1, #0
0x00052f:	str     	r1, [sp]
0x000531:	str     	r1, [sp, #4]
0x000533:	movs    	r2, #0
0x000535:	str     	r2, [sp, #8]
0x000537:	movs    	r1, #0x47
0x000539:	adds    	r3, r4, #0
0x00053b:	movs    	r0, #0xf1
0x00053d:	lsls    	r0, r0, #9
0x00053f:	ldr     	r2, [r5, #8]
0x000541:	bl      	#0x4c2d
; block 0x545
0x000545:	movs    	r1, #0
0x000547:	adds    	r6, r0, #0
0x000549:	movs    	r2, #0
0x00054b:	str     	r2, [sp, #8]
0x00054d:	str     	r1, [sp]
0x00054f:	str     	r1, [sp, #4]
0x000551:	adds    	r3, r4, #0
0x000553:	adds    	r2, r5, #0
0x000555:	movs    	r1, #0xa8
0x000557:	movs    	r0, #0xf1
0x000559:	lsls    	r0, r0, #9
0x00055b:	bl      	#0x4c2d
; block 0x55f
0x00055f:	movs    	r1, #0
0x000561:	str     	r1, [sp]
0x000563:	str     	r1, [sp, #4]
0x000565:	movs    	r2, #0
0x000567:	str     	r2, [sp, #8]
0x000569:	adds    	r5, r0, #0
0x00056b:	ldr     	r2, [r0]
0x00056d:	movs    	r0, #0xf1
0x00056f:	adds    	r3, r4, #0
0x000571:	movs    	r1, #0x90
0x000573:	lsls    	r0, r0, #9
0x000575:	bl      	#0x4c2d
; block 0x579
0x000579:	movs    	r2, #0
0x00057b:	movs    	r1, #0
0x00057d:	str     	r2, [sp, #8]
0x00057f:	adds    	r7, r0, #0
0x000581:	adds    	r3, r4, #0
0x000583:	adds    	r2, r0, #0
0x000585:	str     	r1, [sp]
0x000587:	str     	r1, [sp, #4]
0x000589:	movs    	r1, #0x8f
0x00058b:	movs    	r0, #0xf1
0x00058d:	lsls    	r0, r0, #9
0x00058f:	bl      	#0x4c2d
; block 0x593
0x000593:	movs    	r1, #0
0x000595:	movs    	r2, #0
0x000597:	str     	r2, [sp, #8]
0x000599:	str     	r1, [sp]
0x00059b:	str     	r1, [sp, #4]
0x00059d:	adds    	r3, r4, #0
0x00059f:	adds    	r2, r7, #0
0x0005a1:	movs    	r1, #0x8e
0x0005a3:	movs    	r0, #0xf1
0x0005a5:	lsls    	r0, r0, #9
0x0005a7:	bl      	#0x4c2d
; block 0x5ab
0x0005ab:	movs    	r1, #0
0x0005ad:	movs    	r2, #0
0x0005af:	str     	r2, [sp, #8]
0x0005b1:	str     	r1, [sp]
0x0005b3:	str     	r1, [sp, #4]
0x0005b5:	adds    	r3, r4, #0
0x0005b7:	adds    	r2, r5, #0
0x0005b9:	movs    	r1, #0xa9
0x0005bb:	movs    	r0, #0xf1
0x0005bd:	lsls    	r0, r0, #9
0x0005bf:	bl      	#0x4c2d
; block 0x5c3
0x0005c3:	movs    	r1, #0
0x0005c5:	str     	r1, [sp]
0x0005c7:	str     	r1, [sp, #4]
0x0005c9:	movs    	r2, #0
0x0005cb:	movs    	r1, #0x2c
0x0005cd:	adds    	r3, r4, #0
0x0005cf:	movs    	r0, #0xf1
0x0005d1:	lsls    	r0, r0, #9
0x0005d3:	str     	r2, [sp, #8]
0x0005d5:	bl      	#0x4c2d
; block 0x5d9
0x0005d9:	movs    	r1, #0
0x0005db:	movs    	r2, #0
0x0005dd:	str     	r2, [sp, #8]
0x0005df:	str     	r1, [sp]
0x0005e1:	str     	r1, [sp, #4]
0x0005e3:	adds    	r3, r4, #0
0x0005e5:	adds    	r2, r6, #0
0x0005e7:	movs    	r1, #0x33
0x0005e9:	movs    	r0, #0xf1
0x0005eb:	lsls    	r0, r0, #9
0x0005ed:	bl      	#0x4c2d
; block 0x5f1
0x0005f1:	movs    	r1, #0
0x0005f3:	movs    	r2, #0
0x0005f5:	str     	r2, [sp, #8]
0x0005f7:	str     	r1, [sp]
0x0005f9:	str     	r1, [sp, #4]
0x0005fb:	adds    	r3, r4, #0
0x0005fd:	adds    	r2, r6, #0
0x0005ff:	movs    	r1, #9
0x000601:	movs    	r0, #0xf1
0x000603:	lsls    	r0, r0, #9
0x000605:	bl      	#0x4c2d
; block 0x609
0x000609:	add     	sp, #0xc
0x00060b:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_60d @ 0x60d offset=0x60c size=26 blocks=1 cc=1 =====
; block 0x60d
0x00060d:	push    	{r4, r5, r6, lr}
0x00060f:	sub     	sp, #0x10
0x000611:	movs    	r5, #0
0x000613:	movs    	r2, #0
0x000615:	movs    	r1, #0
0x000617:	str     	r2, [sp, #8]
0x000619:	adds    	r3, r5, #0
0x00061b:	adds    	r4, r0, #0
0x00061d:	adds    	r2, r0, #0
0x00061f:	str     	r1, [sp]
0x000621:	str     	r1, [sp, #4]
0x000623:	movs    	r1, #0x44
0x000625:	movs    	r0, #0xf1
0x000627:	lsls    	r0, r0, #9
0x000629:	bl      	#0x4c2d

; ===== sub_681 @ 0x681 offset=0x680 size=4 blocks=1 cc=1 =====
; block 0x681
0x000681:	movs    	r4, r0
0x000683:	movs    	r0, r0
0x000685:	push    	{r4, r5, r6, r7, lr}
0x000687:	sub     	sp, #0xc
0x000689:	movs    	r6, #0
0x00068b:	movs    	r2, #0
0x00068d:	movs    	r1, #0
0x00068f:	str     	r2, [sp, #8]
0x000691:	adds    	r3, r6, #0
0x000693:	adds    	r5, r0, #0
0x000695:	adds    	r2, r0, #0
0x000697:	str     	r1, [sp]
0x000699:	str     	r1, [sp, #4]
0x00069b:	movs    	r1, #0x44
0x00069d:	movs    	r0, #0xf1
0x00069f:	movs    	r4, #0
0x0006a1:	lsls    	r0, r0, #9
0x0006a3:	bl      	#0x4c2d

; ===== sub_685 @ 0x685 offset=0x684 size=302 blocks=17 cc=12 =====
; block 0x685
0x000685:	push    	{r4, r5, r6, r7, lr}
0x000687:	sub     	sp, #0xc
0x000689:	movs    	r6, #0
0x00068b:	movs    	r2, #0
0x00068d:	movs    	r1, #0
0x00068f:	str     	r2, [sp, #8]
0x000691:	adds    	r3, r6, #0
0x000693:	adds    	r5, r0, #0
0x000695:	adds    	r2, r0, #0
0x000697:	str     	r1, [sp]
0x000699:	str     	r1, [sp, #4]
0x00069b:	movs    	r1, #0x44
0x00069d:	movs    	r0, #0xf1
0x00069f:	movs    	r4, #0
0x0006a1:	lsls    	r0, r0, #9
0x0006a3:	bl      	#0x4c2d
; block 0x6a7
0x0006a7:	movs    	r1, #0
0x0006a9:	str     	r1, [sp]
0x0006ab:	str     	r1, [sp, #4]
0x0006ad:	movs    	r2, #0
0x0006af:	str     	r2, [sp, #8]
0x0006b1:	movs    	r1, #0x46
0x0006b3:	adds    	r3, r6, #0
0x0006b5:	movs    	r0, #0xf1
0x0006b7:	lsls    	r0, r0, #9
0x0006b9:	ldr     	r2, [r5, #8]
0x0006bb:	bl      	#0x4c2d
; block 0x6bf
0x0006bf:	ldr     	r7, [pc, #0xf4]
0x0006c1:	movs    	r1, #0
0x0006c3:	add     	r7, sb
0x0006c5:	strb    	r0, [r7, #7]
0x0006c7:	str     	r1, [sp]
0x0006c9:	str     	r1, [sp, #4]
0x0006cb:	movs    	r2, #0
0x0006cd:	str     	r2, [sp, #8]
0x0006cf:	movs    	r1, #0x45
0x0006d1:	movs    	r0, #0xf1
0x0006d3:	adds    	r3, r6, #0
0x0006d5:	lsls    	r0, r0, #9
0x0006d7:	ldr     	r2, [r5, #8]
0x0006d9:	bl      	#0x4c2d
; block 0x6dd
0x0006dd:	str     	r0, [r7, #0x54]
0x0006df:	movs    	r1, #0
0x0006e1:	str     	r1, [sp]
0x0006e3:	str     	r1, [sp, #4]
0x0006e5:	movs    	r2, #0
0x0006e7:	str     	r2, [sp, #8]
0x0006e9:	movs    	r1, #0x46
0x0006eb:	movs    	r0, #0xf1
0x0006ed:	adds    	r3, r6, #0
0x0006ef:	lsls    	r0, r0, #9
0x0006f1:	ldr     	r2, [r5, #8]
0x0006f3:	bl      	#0x4c2d
; block 0x6f7
0x0006f7:	strb    	r0, [r7, #1]
0x0006f9:	movs    	r1, #0
0x0006fb:	str     	r1, [sp]
0x0006fd:	str     	r1, [sp, #4]
0x0006ff:	movs    	r2, #0
0x000701:	str     	r2, [sp, #8]
0x000703:	movs    	r1, #0x46
0x000705:	movs    	r0, #0xf1
0x000707:	adds    	r3, r6, #0
0x000709:	lsls    	r0, r0, #9
0x00070b:	ldr     	r2, [r5, #8]
0x00070d:	bl      	#0x4c2d
; block 0x711
0x000711:	lsls    	r6, r0, #0x18
0x000713:	movs    	r1, #0
0x000715:	movs    	r2, #0
0x000717:	str     	r2, [sp, #8]
0x000719:	str     	r1, [sp]
0x00071b:	str     	r1, [sp, #4]
0x00071d:	asrs    	r6, r6, #0x18
0x00071f:	adds    	r2, r6, #0
0x000721:	movs    	r1, #0xa
0x000723:	movs    	r0, #0xf1
0x000725:	movs    	r3, #4
0x000727:	lsls    	r0, r0, #9
0x000729:	bl      	#0x4c2d
; block 0x72d
0x00072d:	str     	r0, [r7, #0x28]
0x00072f:	movs    	r1, #0
0x000731:	movs    	r2, #0
0x000733:	str     	r2, [sp, #8]
0x000735:	str     	r1, [sp]
0x000737:	str     	r1, [sp, #4]
0x000739:	movs    	r1, #0xa
0x00073b:	adds    	r2, r6, #0
0x00073d:	movs    	r0, #0xf1
0x00073f:	movs    	r3, #4
0x000741:	lsls    	r0, r0, #9
0x000743:	bl      	#0x4c2d
; block 0x747
0x000747:	str     	r0, [r7, #0x2c]
0x000749:	cmp     	r6, #0
0x00074b:	ble     	#0x7ab
; block 0x74d
0x00074d:	movs    	r7, #0
0x00074f:	movs    	r1, #0
0x000751:	str     	r1, [sp]
0x000753:	str     	r1, [sp, #4]
0x000755:	movs    	r2, #0
0x000757:	str     	r2, [sp, #8]
0x000759:	movs    	r1, #0x46
0x00075b:	adds    	r3, r7, #0
0x00075d:	movs    	r0, #0xf1
0x00075f:	lsls    	r0, r0, #9
0x000761:	ldr     	r2, [r5, #8]
0x000763:	bl      	#0x4c2d
; block 0x74f
0x00074f:	movs    	r1, #0
0x000751:	str     	r1, [sp]
0x000753:	str     	r1, [sp, #4]
0x000755:	movs    	r2, #0
0x000757:	str     	r2, [sp, #8]
0x000759:	movs    	r1, #0x46
0x00075b:	adds    	r3, r7, #0
0x00075d:	movs    	r0, #0xf1
0x00075f:	lsls    	r0, r0, #9
0x000761:	ldr     	r2, [r5, #8]
0x000763:	bl      	#0x4c2d
; block 0x767
0x000767:	lsls    	r0, r0, #0x18
0x000769:	asrs    	r0, r0, #0x18
0x00076b:	bne     	#0x779
; block 0x76d
0x00076d:	ldr     	r1, [pc, #0x44]
0x00076f:	lsls    	r0, r4, #2
0x000771:	add     	r1, sb
0x000773:	ldr     	r1, [r1, #0x28]
0x000775:	str     	r7, [r1, r0]
0x000777:	b       	#0x79b
; block 0x779
0x000779:	movs    	r1, #0
0x00077b:	str     	r1, [sp]
0x00077d:	str     	r1, [sp, #4]
0x00077f:	movs    	r2, #0
0x000781:	str     	r2, [sp, #8]
0x000783:	movs    	r1, #0x47
0x000785:	adds    	r3, r7, #0
0x000787:	movs    	r0, #0xf1
0x000789:	lsls    	r0, r0, #9
0x00078b:	ldr     	r2, [r5, #8]
0x00078d:	bl      	#0x4c2d
; block 0x791
0x000791:	ldr     	r2, [pc, #0x20]
0x000793:	lsls    	r1, r4, #2
0x000795:	add     	r2, sb
0x000797:	ldr     	r2, [r2, #0x28]
0x000799:	str     	r0, [r2, r1]
0x00079b:	ldr     	r1, [pc, #0x18]
0x00079d:	lsls    	r0, r4, #2
0x00079f:	add     	r1, sb
0x0007a1:	ldr     	r1, [r1, #0x2c]
0x0007a3:	adds    	r4, #1
0x0007a5:	cmp     	r4, r6
0x0007a7:	str     	r7, [r1, r0]
0x0007a9:	blt     	#0x74f
; block 0x79b
0x00079b:	ldr     	r1, [pc, #0x18]
0x00079d:	lsls    	r0, r4, #2
0x00079f:	add     	r1, sb
0x0007a1:	ldr     	r1, [r1, #0x2c]
0x0007a3:	adds    	r4, #1
0x0007a5:	cmp     	r4, r6
0x0007a7:	str     	r7, [r1, r0]
0x0007a9:	blt     	#0x74f
; block 0x7ab
0x0007ab:	bl      	#0x39c5
; block 0x7af
0x0007af:	add     	sp, #0xc
0x0007b1:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_7b5 @ 0x7b5 offset=0x7b4 size=4 blocks=1 cc=1 =====
; block 0x7b5
0x0007b5:	movs    	r4, r0
0x0007b7:	movs    	r0, r0
0x0007b9:	push    	{r4, r5, r6, r7, lr}
0x0007bb:	sub     	sp, #0xc
0x0007bd:	movs    	r1, #0
0x0007bf:	movs    	r2, #0
0x0007c1:	str     	r2, [sp, #8]
0x0007c3:	str     	r1, [sp]
0x0007c5:	str     	r1, [sp, #4]
0x0007c7:	movs    	r6, #0xf1
0x0007c9:	movs    	r5, #0
0x0007cb:	adds    	r3, r5, #0
0x0007cd:	lsls    	r6, r6, #9
0x0007cf:	movs    	r1, #0x44
0x0007d1:	adds    	r2, r0, #0
0x0007d3:	adds    	r4, r0, #0
0x0007d5:	adds    	r0, r6, #0
0x0007d7:	bl      	#0x4c2d

; ===== sub_7b9 @ 0x7b9 offset=0x7b8 size=266 blocks=16 cc=12 =====
; block 0x7b9
0x0007b9:	push    	{r4, r5, r6, r7, lr}
0x0007bb:	sub     	sp, #0xc
0x0007bd:	movs    	r1, #0
0x0007bf:	movs    	r2, #0
0x0007c1:	str     	r2, [sp, #8]
0x0007c3:	str     	r1, [sp]
0x0007c5:	str     	r1, [sp, #4]
0x0007c7:	movs    	r6, #0xf1
0x0007c9:	movs    	r5, #0
0x0007cb:	adds    	r3, r5, #0
0x0007cd:	lsls    	r6, r6, #9
0x0007cf:	movs    	r1, #0x44
0x0007d1:	adds    	r2, r0, #0
0x0007d3:	adds    	r4, r0, #0
0x0007d5:	adds    	r0, r6, #0
0x0007d7:	bl      	#0x4c2d
; block 0x7db
0x0007db:	movs    	r1, #0
0x0007dd:	str     	r1, [sp]
0x0007df:	str     	r1, [sp, #4]
0x0007e1:	movs    	r2, #0
0x0007e3:	str     	r2, [sp, #8]
0x0007e5:	movs    	r1, #0x46
0x0007e7:	adds    	r3, r5, #0
0x0007e9:	adds    	r0, r6, #0
0x0007eb:	ldr     	r2, [r4, #8]
0x0007ed:	bl      	#0x4c2d
; block 0x7f1
0x0007f1:	ldr     	r7, [pc, #0x16c]
0x0007f3:	movs    	r1, #0
0x0007f5:	add     	r7, sb
0x0007f7:	strb    	r0, [r7, #6]
0x0007f9:	str     	r1, [sp]
0x0007fb:	str     	r1, [sp, #4]
0x0007fd:	movs    	r2, #0
0x0007ff:	str     	r2, [sp, #8]
0x000801:	movs    	r1, #0x45
0x000803:	adds    	r3, r5, #0
0x000805:	adds    	r0, r6, #0
0x000807:	ldr     	r2, [r4, #8]
0x000809:	bl      	#0x4c2d
; block 0x80d
0x00080d:	str     	r0, [r7, #0x50]
0x00080f:	movs    	r1, #0
0x000811:	str     	r1, [sp]
0x000813:	str     	r1, [sp, #4]
0x000815:	movs    	r2, #0
0x000817:	str     	r2, [sp, #8]
0x000819:	movs    	r1, #0x46
0x00081b:	adds    	r3, r5, #0
0x00081d:	adds    	r0, r6, #0
0x00081f:	ldr     	r2, [r4, #8]
0x000821:	bl      	#0x4c2d
; block 0x825
0x000825:	lsls    	r0, r0, #0x18
0x000827:	asrs    	r0, r0, #0x18
0x000829:	cmp     	r0, #1
0x00082b:	bne     	#0x83b
; block 0x82d
0x00082d:	adds    	r0, r4, #0
0x00082f:	bl      	#0x50a5
; block 0x833
0x000833:	adds    	r1, r7, #0
0x000835:	str     	r0, [r1, #0x4c]
0x000837:	movs    	r1, #0
0x000839:	str     	r1, [r0, #8]
0x00083b:	movs    	r1, #0
0x00083d:	str     	r1, [sp]
0x00083f:	str     	r1, [sp, #4]
0x000841:	movs    	r2, #0
0x000843:	str     	r2, [sp, #8]
0x000845:	movs    	r1, #0x46
0x000847:	movs    	r3, #0
0x000849:	movs    	r0, #0xf1
0x00084b:	lsls    	r0, r0, #9
0x00084d:	ldr     	r2, [r4, #8]
0x00084f:	bl      	#0x4c2d
; block 0x83b
0x00083b:	movs    	r1, #0
0x00083d:	str     	r1, [sp]
0x00083f:	str     	r1, [sp, #4]
0x000841:	movs    	r2, #0
0x000843:	str     	r2, [sp, #8]
0x000845:	movs    	r1, #0x46
0x000847:	movs    	r3, #0
0x000849:	movs    	r0, #0xf1
0x00084b:	lsls    	r0, r0, #9
0x00084d:	ldr     	r2, [r4, #8]
0x00084f:	bl      	#0x4c2d
; block 0x853
0x000853:	lsls    	r0, r0, #0x18
0x000855:	asrs    	r0, r0, #0x18
0x000857:	cmp     	r0, #1
0x000859:	bne     	#0x8ad
; block 0x85b
0x00085b:	movs    	r1, #0
0x00085d:	str     	r1, [sp]
0x00085f:	str     	r1, [sp, #4]
0x000861:	movs    	r2, #0
0x000863:	str     	r2, [sp, #8]
0x000865:	movs    	r1, #0x46
0x000867:	movs    	r3, #0
0x000869:	movs    	r0, #0xf1
0x00086b:	lsls    	r0, r0, #9
0x00086d:	ldr     	r2, [r4, #8]
0x00086f:	bl      	#0x4c2d
; block 0x873
0x000873:	lsls    	r6, r0, #0x18
0x000875:	movs    	r1, #0
0x000877:	movs    	r2, #0
0x000879:	str     	r2, [sp, #8]
0x00087b:	str     	r1, [sp]
0x00087d:	str     	r1, [sp, #4]
0x00087f:	asrs    	r6, r6, #0x18
0x000881:	adds    	r2, r6, #0
0x000883:	movs    	r1, #0xa
0x000885:	movs    	r0, #0xf1
0x000887:	movs    	r3, #4
0x000889:	lsls    	r0, r0, #9
0x00088b:	bl      	#0x4c2d
; block 0x88f
0x00088f:	adds    	r7, r0, #0
0x000891:	movs    	r5, #0
0x000893:	cmp     	r6, #0
0x000895:	ble     	#0x8a7
; block 0x897
0x000897:	adds    	r0, r4, #0
0x000899:	bl      	#0x50a5
; block 0x89d
0x00089d:	lsls    	r1, r5, #2
0x00089f:	adds    	r5, #1
0x0008a1:	cmp     	r5, r6
0x0008a3:	str     	r0, [r7, r1]
0x0008a5:	blt     	#0x897
; block 0x8a7
0x0008a7:	ldr     	r0, [pc, #0xb8]
0x0008a9:	add     	r0, sb
0x0008ab:	str     	r7, [r0, #0x34]
0x0008ad:	movs    	r1, #0
0x0008af:	str     	r1, [sp]
0x0008b1:	str     	r1, [sp, #4]
0x0008b3:	movs    	r2, #0
0x0008b5:	movs    	r5, #0
0x0008b7:	movs    	r6, #0xf1
0x0008b9:	lsls    	r6, r6, #9
0x0008bb:	adds    	r3, r5, #0
0x0008bd:	str     	r2, [sp, #8]
0x0008bf:	movs    	r1, #0x46
0x0008c1:	adds    	r0, r6, #0
0x0008c3:	ldr     	r2, [r4, #8]
0x0008c5:	bl      	#0x4c2d
; block 0x8ad
0x0008ad:	movs    	r1, #0
0x0008af:	str     	r1, [sp]
0x0008b1:	str     	r1, [sp, #4]
0x0008b3:	movs    	r2, #0
0x0008b5:	movs    	r5, #0
0x0008b7:	movs    	r6, #0xf1
0x0008b9:	lsls    	r6, r6, #9
0x0008bb:	adds    	r3, r5, #0
0x0008bd:	str     	r2, [sp, #8]
0x0008bf:	movs    	r1, #0x46
0x0008c1:	adds    	r0, r6, #0
0x0008c3:	ldr     	r2, [r4, #8]
0x0008c5:	bl      	#0x4c2d

; ===== sub_961 @ 0x961 offset=0x960 size=4 blocks=1 cc=1 =====
; block 0x961
0x000961:	movs    	r4, r0
0x000963:	movs    	r0, r0
0x000965:	push    	{r4, r5, r6, r7, lr}
0x000967:	sub     	sp, #0xc
0x000969:	movs    	r7, #0
0x00096b:	movs    	r2, #0
0x00096d:	movs    	r1, #0
0x00096f:	str     	r2, [sp, #8]
0x000971:	adds    	r5, r7, #0
0x000973:	adds    	r3, r7, #0
0x000975:	adds    	r4, r0, #0
0x000977:	adds    	r2, r0, #0
0x000979:	str     	r1, [sp]
0x00097b:	str     	r1, [sp, #4]
0x00097d:	movs    	r1, #0x44
0x00097f:	movs    	r0, #0xf1
0x000981:	lsls    	r0, r0, #9
0x000983:	bl      	#0x4c2d

; ===== sub_965 @ 0x965 offset=0x964 size=586 blocks=31 cc=27 =====
; block 0x965
0x000965:	push    	{r4, r5, r6, r7, lr}
0x000967:	sub     	sp, #0xc
0x000969:	movs    	r7, #0
0x00096b:	movs    	r2, #0
0x00096d:	movs    	r1, #0
0x00096f:	str     	r2, [sp, #8]
0x000971:	adds    	r5, r7, #0
0x000973:	adds    	r3, r7, #0
0x000975:	adds    	r4, r0, #0
0x000977:	adds    	r2, r0, #0
0x000979:	str     	r1, [sp]
0x00097b:	str     	r1, [sp, #4]
0x00097d:	movs    	r1, #0x44
0x00097f:	movs    	r0, #0xf1
0x000981:	lsls    	r0, r0, #9
0x000983:	bl      	#0x4c2d
; block 0x987
0x000987:	movs    	r1, #0
0x000989:	str     	r1, [sp]
0x00098b:	str     	r1, [sp, #4]
0x00098d:	movs    	r2, #0
0x00098f:	str     	r2, [sp, #8]
0x000991:	movs    	r1, #0x46
0x000993:	adds    	r3, r5, #0
0x000995:	movs    	r0, #0xf1
0x000997:	lsls    	r0, r0, #9
0x000999:	ldr     	r2, [r4, #8]
0x00099b:	bl      	#0x4c2d
; block 0x99f
0x00099f:	ldr     	r6, [pc, #0x210]
0x0009a1:	movs    	r1, #0
0x0009a3:	add     	r6, sb
0x0009a5:	strb    	r0, [r6, #6]
0x0009a7:	str     	r1, [sp]
0x0009a9:	str     	r1, [sp, #4]
0x0009ab:	movs    	r2, #0
0x0009ad:	str     	r2, [sp, #8]
0x0009af:	movs    	r1, #0x45
0x0009b1:	movs    	r0, #0xf1
0x0009b3:	adds    	r3, r5, #0
0x0009b5:	lsls    	r0, r0, #9
0x0009b7:	ldr     	r2, [r4, #8]
0x0009b9:	bl      	#0x4c2d
; block 0x9bd
0x0009bd:	str     	r0, [r6, #0x50]
0x0009bf:	movs    	r1, #0
0x0009c1:	str     	r1, [sp]
0x0009c3:	str     	r1, [sp, #4]
0x0009c5:	movs    	r2, #0
0x0009c7:	str     	r2, [sp, #8]
0x0009c9:	movs    	r1, #0x46
0x0009cb:	movs    	r0, #0xf1
0x0009cd:	adds    	r3, r5, #0
0x0009cf:	lsls    	r0, r0, #9
0x0009d1:	ldr     	r2, [r4, #8]
0x0009d3:	bl      	#0x4c2d
; block 0x9d7
0x0009d7:	strb    	r0, [r6, #4]
0x0009d9:	movs    	r1, #0
0x0009db:	str     	r1, [sp]
0x0009dd:	str     	r1, [sp, #4]
0x0009df:	movs    	r2, #0
0x0009e1:	str     	r2, [sp, #8]
0x0009e3:	movs    	r1, #0x46
0x0009e5:	movs    	r0, #0xf1
0x0009e7:	adds    	r3, r5, #0
0x0009e9:	lsls    	r0, r0, #9
0x0009eb:	ldr     	r2, [r4, #8]
0x0009ed:	bl      	#0x4c2d
; block 0x9f1
0x0009f1:	strb    	r0, [r6, #5]
0x0009f3:	movs    	r1, #0
0x0009f5:	str     	r1, [sp]
0x0009f7:	str     	r1, [sp, #4]
0x0009f9:	movs    	r2, #0
0x0009fb:	str     	r2, [sp, #8]
0x0009fd:	movs    	r1, #0x47
0x0009ff:	movs    	r0, #0xf1
0x000a01:	adds    	r3, r5, #0
0x000a03:	lsls    	r0, r0, #9
0x000a05:	ldr     	r2, [r4, #8]
0x000a07:	bl      	#0x4c2d
; block 0xa0b
0x000a0b:	str     	r0, [r6, #0x5c]
0x000a0d:	movs    	r1, #0
0x000a0f:	str     	r1, [sp]
0x000a11:	str     	r1, [sp, #4]
0x000a13:	movs    	r2, #0
0x000a15:	str     	r2, [sp, #8]
0x000a17:	movs    	r1, #0x47
0x000a19:	movs    	r0, #0xf1
0x000a1b:	adds    	r3, r5, #0
0x000a1d:	lsls    	r0, r0, #9
0x000a1f:	ldr     	r2, [r4, #8]
0x000a21:	bl      	#0x4c2d
; block 0xa25
0x000a25:	str     	r0, [r6, #0x60]
0x000a27:	movs    	r1, #0
0x000a29:	str     	r1, [sp]
0x000a2b:	str     	r1, [sp, #4]
0x000a2d:	movs    	r2, #0
0x000a2f:	str     	r2, [sp, #8]
0x000a31:	movs    	r1, #0x46
0x000a33:	movs    	r0, #0xf1
0x000a35:	adds    	r3, r5, #0
0x000a37:	lsls    	r0, r0, #9
0x000a39:	ldr     	r2, [r4, #8]
0x000a3b:	bl      	#0x4c2d
; block 0xa3f
0x000a3f:	lsls    	r0, r0, #0x18
0x000a41:	asrs    	r0, r0, #0x18
0x000a43:	cmp     	r0, #1
0x000a45:	bne     	#0xaad
; block 0xa47
0x000a47:	movs    	r1, #0
0x000a49:	str     	r1, [sp]
0x000a4b:	str     	r1, [sp, #4]
0x000a4d:	movs    	r2, #0
0x000a4f:	str     	r2, [sp, #8]
0x000a51:	movs    	r1, #0x46
0x000a53:	adds    	r3, r7, #0
0x000a55:	movs    	r0, #0xf1
0x000a57:	lsls    	r0, r0, #9
0x000a59:	ldr     	r2, [r4, #8]
0x000a5b:	bl      	#0x4c2d
; block 0xa5f
0x000a5f:	lsls    	r6, r0, #0x18
0x000a61:	movs    	r1, #0
0x000a63:	movs    	r2, #0
0x000a65:	str     	r2, [sp, #8]
0x000a67:	str     	r1, [sp]
0x000a69:	str     	r1, [sp, #4]
0x000a6b:	asrs    	r6, r6, #0x18
0x000a6d:	adds    	r2, r6, #0
0x000a6f:	movs    	r1, #0xa
0x000a71:	movs    	r0, #0xf1
0x000a73:	movs    	r3, #4
0x000a75:	lsls    	r0, r0, #9
0x000a77:	bl      	#0x4c2d
; block 0xa7b
0x000a7b:	ldr     	r2, [pc, #0x134]
0x000a7d:	cmp     	r6, #0
0x000a7f:	add     	r2, sb
0x000a81:	str     	r0, [r2, #0x1c]
0x000a83:	ble     	#0xaad
; block 0xa85
0x000a85:	movs    	r1, #0
0x000a87:	str     	r1, [sp]
0x000a89:	str     	r1, [sp, #4]
0x000a8b:	movs    	r2, #0
0x000a8d:	str     	r2, [sp, #8]
0x000a8f:	movs    	r1, #0x45
0x000a91:	adds    	r3, r7, #0
0x000a93:	movs    	r0, #0xf1
0x000a95:	lsls    	r0, r0, #9
0x000a97:	ldr     	r2, [r4, #8]
0x000a99:	bl      	#0x4c2d
; block 0xa9d
0x000a9d:	ldr     	r2, [pc, #0x110]
0x000a9f:	lsls    	r1, r5, #2
0x000aa1:	add     	r2, sb
0x000aa3:	ldr     	r2, [r2, #0x1c]
0x000aa5:	adds    	r5, #1
0x000aa7:	cmp     	r5, r6
0x000aa9:	str     	r0, [r2, r1]
0x000aab:	blt     	#0xa85
; block 0xaad
0x000aad:	movs    	r1, #0
0x000aaf:	str     	r1, [sp]
0x000ab1:	str     	r1, [sp, #4]
0x000ab3:	movs    	r2, #0
0x000ab5:	str     	r2, [sp, #8]
0x000ab7:	movs    	r1, #0x46
0x000ab9:	adds    	r3, r7, #0
0x000abb:	movs    	r0, #0xf1
0x000abd:	lsls    	r0, r0, #9
0x000abf:	ldr     	r2, [r4, #8]
0x000ac1:	bl      	#0x4c2d
; block 0xac5
0x000ac5:	lsls    	r0, r0, #0x18
0x000ac7:	asrs    	r0, r0, #0x18
0x000ac9:	cmp     	r0, #1
0x000acb:	bne     	#0xb35
; block 0xacd
0x000acd:	movs    	r1, #0
0x000acf:	str     	r1, [sp]
0x000ad1:	str     	r1, [sp, #4]
0x000ad3:	movs    	r2, #0
0x000ad5:	str     	r2, [sp, #8]
0x000ad7:	movs    	r1, #0x46
0x000ad9:	movs    	r5, #0
0x000adb:	adds    	r3, r7, #0
0x000add:	movs    	r0, #0xf1
0x000adf:	lsls    	r0, r0, #9
0x000ae1:	ldr     	r2, [r4, #8]
0x000ae3:	bl      	#0x4c2d
; block 0xae7
0x000ae7:	lsls    	r6, r0, #0x18
0x000ae9:	movs    	r1, #0
0x000aeb:	movs    	r2, #0
0x000aed:	str     	r2, [sp, #8]
0x000aef:	str     	r1, [sp]
0x000af1:	str     	r1, [sp, #4]
0x000af3:	asrs    	r6, r6, #0x18
0x000af5:	adds    	r2, r6, #0
0x000af7:	movs    	r1, #0xa
0x000af9:	movs    	r0, #0xf1
0x000afb:	movs    	r3, #4
0x000afd:	lsls    	r0, r0, #9
0x000aff:	bl      	#0x4c2d
; block 0xb03
0x000b03:	ldr     	r2, [pc, #0xac]
0x000b05:	cmp     	r6, #0
0x000b07:	add     	r2, sb
0x000b09:	str     	r0, [r2, #0x20]
0x000b0b:	ble     	#0xb35
; block 0xb0d
0x000b0d:	movs    	r1, #0
0x000b0f:	str     	r1, [sp]
0x000b11:	str     	r1, [sp, #4]
0x000b13:	movs    	r2, #0
0x000b15:	str     	r2, [sp, #8]
0x000b17:	movs    	r1, #0x45
0x000b19:	adds    	r3, r7, #0
0x000b1b:	movs    	r0, #0xf1
0x000b1d:	lsls    	r0, r0, #9
0x000b1f:	ldr     	r2, [r4, #8]
0x000b21:	bl      	#0x4c2d
; block 0xb25
0x000b25:	ldr     	r2, [pc, #0x88]
0x000b27:	lsls    	r1, r5, #2
0x000b29:	add     	r2, sb
0x000b2b:	ldr     	r2, [r2, #0x20]
0x000b2d:	adds    	r5, #1
0x000b2f:	cmp     	r5, r6
0x000b31:	str     	r0, [r2, r1]
0x000b33:	blt     	#0xb0d
; block 0xb35
0x000b35:	movs    	r1, #0
0x000b37:	str     	r1, [sp]
0x000b39:	str     	r1, [sp, #4]
0x000b3b:	movs    	r2, #0
0x000b3d:	movs    	r6, #0xf1
0x000b3f:	lsls    	r6, r6, #9
0x000b41:	str     	r2, [sp, #8]
0x000b43:	movs    	r1, #0x46
0x000b45:	adds    	r5, r7, #0
0x000b47:	adds    	r3, r7, #0
0x000b49:	adds    	r0, r6, #0
0x000b4b:	ldr     	r2, [r4, #8]
0x000b4d:	bl      	#0x4c2d
; block 0xb51
0x000b51:	lsls    	r0, r0, #0x18
0x000b53:	asrs    	r0, r0, #0x18
0x000b55:	cmp     	r0, #1
0x000b57:	bne     	#0xba7
; block 0xb59
0x000b59:	movs    	r1, #0
0x000b5b:	str     	r1, [sp]
0x000b5d:	str     	r1, [sp, #4]
0x000b5f:	movs    	r2, #0
0x000b61:	str     	r2, [sp, #8]
0x000b63:	movs    	r1, #0x46
0x000b65:	adds    	r3, r5, #0
0x000b67:	adds    	r0, r6, #0
0x000b69:	ldr     	r2, [r4, #8]
0x000b6b:	bl      	#0x4c2d
; block 0xb6f
0x000b6f:	movs    	r1, #0
0x000b71:	lsls    	r5, r0, #0x18
0x000b73:	movs    	r2, #0
0x000b75:	str     	r2, [sp, #8]
0x000b77:	asrs    	r5, r5, #0x18
0x000b79:	str     	r1, [sp]
0x000b7b:	str     	r1, [sp, #4]
0x000b7d:	movs    	r1, #0xa
0x000b7f:	adds    	r2, r5, #0
0x000b81:	movs    	r3, #4
0x000b83:	adds    	r0, r6, #0
0x000b85:	bl      	#0x4c2d
; block 0xb89
0x000b89:	adds    	r7, r0, #0
0x000b8b:	movs    	r6, #0
0x000b8d:	cmp     	r5, #0
0x000b8f:	ble     	#0xba1
; block 0xb91
0x000b91:	adds    	r0, r4, #0
0x000b93:	bl      	#0x50a5
; block 0xb97
0x000b97:	lsls    	r1, r6, #2
0x000b99:	adds    	r6, #1
0x000b9b:	cmp     	r6, r5
0x000b9d:	str     	r0, [r7, r1]
0x000b9f:	blt     	#0xb91
; block 0xba1
0x000ba1:	ldr     	r2, [pc, #0xc]
0x000ba3:	add     	r2, sb
0x000ba5:	str     	r7, [r2, #0x34]
0x000ba7:	bl      	#0x3b39
; block 0xba7
0x000ba7:	bl      	#0x3b39
; block 0xbab
0x000bab:	add     	sp, #0xc
0x000bad:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_bb1 @ 0xbb1 offset=0xbb0 size=4 blocks=1 cc=1 =====
; block 0xbb1
0x000bb1:	movs    	r4, r0
0x000bb3:	movs    	r0, r0
0x000bb5:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x000bb7:	sub     	sp, #0x94
0x000bb9:	adds    	r7, r1, #0
0x000bbb:	movs    	r1, #0
0x000bbd:	movs    	r2, #0
0x000bbf:	str     	r1, [sp]
0x000bc1:	str     	r1, [sp, #4]
0x000bc3:	movs    	r1, #0x11
0x000bc5:	str     	r2, [sp, #8]
0x000bc7:	movs    	r0, #0xf1
0x000bc9:	movs    	r3, #4
0x000bcb:	lsls    	r0, r0, #9
0x000bcd:	ldr     	r2, [sp, #0x94]
0x000bcf:	bl      	#0x4c2d

; ===== sub_bb5 @ 0xbb5 offset=0xbb4 size=738 blocks=40 cc=29 =====
; block 0xbb5
0x000bb5:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x000bb7:	sub     	sp, #0x94
0x000bb9:	adds    	r7, r1, #0
0x000bbb:	movs    	r1, #0
0x000bbd:	movs    	r2, #0
0x000bbf:	str     	r1, [sp]
0x000bc1:	str     	r1, [sp, #4]
0x000bc3:	movs    	r1, #0x11
0x000bc5:	str     	r2, [sp, #8]
0x000bc7:	movs    	r0, #0xf1
0x000bc9:	movs    	r3, #4
0x000bcb:	lsls    	r0, r0, #9
0x000bcd:	ldr     	r2, [sp, #0x94]
0x000bcf:	bl      	#0x4c2d
; block 0xbd3
0x000bd3:	movs    	r1, #0
0x000bd5:	adds    	r5, r0, #0
0x000bd7:	movs    	r2, #0
0x000bd9:	str     	r2, [sp, #8]
0x000bdb:	str     	r1, [sp]
0x000bdd:	str     	r1, [sp, #4]
0x000bdf:	movs    	r4, #0
0x000be1:	adds    	r3, r4, #0
0x000be3:	movs    	r1, #0xe1
0x000be5:	movs    	r2, #0x2d
0x000be7:	movs    	r0, #0xf1
0x000be9:	lsls    	r0, r0, #9
0x000beb:	bl      	#0x4c2d
; block 0xbef
0x000bef:	movs    	r1, #0
0x000bf1:	movs    	r2, #0
0x000bf3:	str     	r2, [sp, #8]
0x000bf5:	str     	r1, [sp]
0x000bf7:	str     	r1, [sp, #4]
0x000bf9:	str     	r0, [sp, #0x78]
0x000bfb:	movs    	r0, #0xf1
0x000bfd:	movs    	r1, #0xe1
0x000bff:	movs    	r2, #0x2e
0x000c01:	adds    	r3, r4, #0
0x000c03:	lsls    	r0, r0, #9
0x000c05:	bl      	#0x4c2d
; block 0xc09
0x000c09:	str     	r0, [sp, #0x7c]
0x000c0b:	cmp     	r5, #0
0x000c0d:	ble     	#0xcf5
; block 0xc0f
0x000c0f:	movs    	r6, #0x19
0x000c11:	adds    	r0, r6, #0
0x000c13:	ldr     	r1, [sp, #0xb8]
0x000c15:	blx     	#0x20
; block 0xc19
0x000c19:	str     	r0, [sp, #0x74]
0x000c1b:	ldr     	r0, [sp, #0xbc]
0x000c1d:	ldr     	r4, [sp, #0x9c]
0x000c1f:	ldr     	r1, [r0]
0x000c21:	ldr     	r0, [sp, #0x74]
0x000c23:	adds    	r4, #3
0x000c25:	str     	r1, [sp, #0x90]
0x000c27:	blx     	#0x20
; block 0xc2b
0x000c2b:	ldr     	r2, [sp, #0x74]
0x000c2d:	muls    	r0, r2, r0
0x000c2f:	str     	r0, [sp, #0x70]
0x000c31:	ldr     	r1, [sp, #0x70]
0x000c33:	adds    	r0, r5, #0
0x000c35:	adds    	r1, r1, r2
0x000c37:	cmp     	r1, r5
0x000c39:	bge     	#0xc3d
; block 0xc3b
0x000c3b:	adds    	r0, r1, #0
0x000c3d:	str     	r0, [sp, #0x6c]
0x000c3f:	ldr     	r0, [sp, #0xb8]
0x000c41:	ldr     	r2, [sp, #0x90]
0x000c43:	str     	r0, [sp]
0x000c45:	ldr     	r0, [sp, #0xa0]
0x000c47:	str     	r2, [sp, #8]
0x000c49:	adds    	r2, r7, r0
0x000c4b:	subs    	r2, #0xc
0x000c4d:	movs    	r0, #0xf1
0x000c4f:	movs    	r1, #0x3b
0x000c51:	lsls    	r0, r0, #9
0x000c53:	str     	r5, [sp, #4]
0x000c55:	ldr     	r3, [sp, #0x9c]
0x000c57:	bl      	#0x4c2d
; block 0xc3d
0x000c3d:	str     	r0, [sp, #0x6c]
0x000c3f:	ldr     	r0, [sp, #0xb8]
0x000c41:	ldr     	r2, [sp, #0x90]
0x000c43:	str     	r0, [sp]
0x000c45:	ldr     	r0, [sp, #0xa0]
0x000c47:	str     	r2, [sp, #8]
0x000c49:	adds    	r2, r7, r0
0x000c4b:	subs    	r2, #0xc
0x000c4d:	movs    	r0, #0xf1
0x000c4f:	movs    	r1, #0x3b
0x000c51:	lsls    	r0, r0, #9
0x000c53:	str     	r5, [sp, #4]
0x000c55:	ldr     	r3, [sp, #0x9c]
0x000c57:	bl      	#0x4c2d
; block 0xc5b
0x000c5b:	ldr     	r0, [sp, #0xa0]
0x000c5d:	ldr     	r5, [sp, #0x70]
0x000c5f:	subs    	r0, #0xc
0x000c61:	str     	r0, [sp, #0xa0]
0x000c63:	ldr     	r0, [sp, #0x6c]
0x000c65:	cmp     	r5, r0
0x000c67:	bge     	#0xcf5
; block 0xc69
0x000c69:	adds    	r0, r7, #5
0x000c6b:	str     	r0, [sp, #0x88]
0x000c6d:	ldr     	r0, [sp, #0xa0]
0x000c6f:	add     	r1, sp, #0x30
0x000c71:	adds    	r3, r7, r0
0x000c73:	subs    	r3, #0x3f
0x000c75:	str     	r3, [sp, #0x84]
0x000c77:	str     	r1, [sp, #0x8c]
0x000c79:	ldr     	r1, [sp, #0x94]
0x000c7b:	lsls    	r0, r5, #2
0x000c7d:	ldr     	r2, [r1, r0]
0x000c7f:	movs    	r3, #8
0x000c81:	ldrsb   	r0, [r2, r3]
0x000c83:	ldr     	r1, [r2, #4]
0x000c85:	str     	r1, [sp, #0x68]
0x000c87:	ldr     	r3, [r2, #0xc]
0x000c89:	str     	r3, [sp, #0x64]
0x000c8b:	ldr     	r1, [r2, #0x14]
0x000c8d:	str     	r1, [sp, #0x60]
0x000c8f:	bl      	#0x3931
; block 0xc79
0x000c79:	ldr     	r1, [sp, #0x94]
0x000c7b:	lsls    	r0, r5, #2
0x000c7d:	ldr     	r2, [r1, r0]
0x000c7f:	movs    	r3, #8
0x000c81:	ldrsb   	r0, [r2, r3]
0x000c83:	ldr     	r1, [r2, #4]
0x000c85:	str     	r1, [sp, #0x68]
0x000c87:	ldr     	r3, [r2, #0xc]
0x000c89:	str     	r3, [sp, #0x64]
0x000c8b:	ldr     	r1, [r2, #0x14]
0x000c8d:	str     	r1, [sp, #0x60]
0x000c8f:	bl      	#0x3931
; block 0xc93
0x000c93:	str     	r0, [sp, #0x5c]
0x000c95:	movs    	r3, #0x18
0x000c97:	ldrsb   	r0, [r2, r3]
0x000c99:	movs    	r2, #0
0x000c9b:	subs    	r3, r4, #5
0x000c9d:	str     	r0, [sp, #0x58]
0x000c9f:	ldr     	r0, [sp, #0xa0]
0x000ca1:	str     	r2, [sp, #8]
0x000ca3:	str     	r0, [sp]
0x000ca5:	movs    	r0, #0xf1
0x000ca7:	adds    	r2, r7, #0
0x000ca9:	movs    	r1, #0x2e
0x000cab:	lsls    	r0, r0, #9
0x000cad:	str     	r3, [sp, #0x80]
0x000caf:	str     	r6, [sp, #4]
0x000cb1:	bl      	#0x4c2d
; block 0xcb5
0x000cb5:	ldr     	r0, [sp, #0xc0]
0x000cb7:	cmp     	r0, #1
0x000cb9:	bne     	#0xd17
; block 0xcbb
0x000cbb:	ldr     	r0, [sp, #0xa0]
0x000cbd:	movs    	r2, #0
0x000cbf:	str     	r0, [sp]
0x000cc1:	str     	r2, [sp, #8]
0x000cc3:	adds    	r2, r7, #0
0x000cc5:	movs    	r0, #0xf1
0x000cc7:	movs    	r1, #0x2f
0x000cc9:	lsls    	r0, r0, #9
0x000ccb:	ldr     	r3, [sp, #0x80]
0x000ccd:	str     	r6, [sp, #4]
0x000ccf:	bl      	#0x4c2d
; block 0xcd3
0x000cd3:	cmp     	r0, #1
0x000cd5:	bne     	#0xd17
; block 0xcd7
0x000cd7:	ldr     	r0, [sp, #0xbc]
0x000cd9:	ldr     	r0, [r0]
0x000cdb:	cmp     	r0, r5
0x000cdd:	bne     	#0xcfd
; block 0xcdf
0x000cdf:	ldr     	r1, [sp, #0xa0]
0x000ce1:	ldr     	r0, [sp, #0x80]
0x000ce3:	str     	r1, [sp, #4]
0x000ce5:	str     	r0, [sp]
0x000ce7:	movs    	r0, #0xf1
0x000ce9:	movs    	r1, #0x23
0x000ceb:	adds    	r3, r7, #0
0x000ced:	movs    	r2, #4
0x000cef:	lsls    	r0, r0, #9
0x000cf1:	str     	r6, [sp, #8]
0x000cf3:	b       	#0xcf7
; block 0xcf5
0x000cf5:	b       	#0xe93
; block 0xcf7
0x000cf7:	bl      	#0x4c2d
; block 0xcfb
0x000cfb:	b       	#0xd17
; block 0xcfd
0x000cfd:	ldr     	r0, [sp, #0xbc]
0x000cff:	movs    	r1, #0
0x000d01:	str     	r5, [r0]
0x000d03:	str     	r1, [sp]
0x000d05:	str     	r1, [sp, #4]
0x000d07:	movs    	r2, #0
0x000d09:	movs    	r1, #0xe6
0x000d0b:	movs    	r0, #0xf1
0x000d0d:	movs    	r3, #0
0x000d0f:	lsls    	r0, r0, #9
0x000d11:	str     	r2, [sp, #8]
0x000d13:	bl      	#0x4c2d
; block 0xd17
0x000d17:	ldr     	r0, [sp, #0xbc]
0x000d19:	ldr     	r0, [r0]
0x000d1b:	cmp     	r0, r5
0x000d1d:	bne     	#0xd3d
; block 0xd1f
0x000d1f:	ldr     	r0, [sp, #0xc0]
0x000d21:	cmp     	r0, #0
0x000d23:	beq     	#0xd3d
; block 0xd25
0x000d25:	ldr     	r0, [sp, #0xa0]
0x000d27:	movs    	r2, #0
0x000d29:	str     	r0, [sp]
0x000d2b:	str     	r2, [sp, #8]
0x000d2d:	adds    	r2, r7, #0
0x000d2f:	movs    	r0, #0xf1
0x000d31:	movs    	r1, #0x30
0x000d33:	lsls    	r0, r0, #9
0x000d35:	ldr     	r3, [sp, #0x80]
0x000d37:	str     	r6, [sp, #4]
0x000d39:	bl      	#0x4c2d
; block 0xd3d
0x000d3d:	ldr     	r0, [sp, #0xcc]
0x000d3f:	cmp     	r0, #0
0x000d41:	bne     	#0xdbb
; block 0xd43
0x000d43:	ldr     	r0, [sp, #0x60]
0x000d45:	adds    	r3, r0, #1
0x000d47:	beq     	#0xd7d
; block 0xd49
0x000d49:	ldr     	r0, [sp, #0x58]
0x000d4b:	ldr     	r1, [sp, #0x8c]
0x000d4d:	movs    	r2, #1
0x000d4f:	strb    	r0, [r1, #4]
0x000d51:	ldr     	r0, [sp, #0x60]
0x000d53:	ldr     	r1, [sp, #0x7c]
0x000d55:	str     	r0, [sp, #0x14]
0x000d57:	ldr     	r0, [sp, #0xc8]
0x000d59:	add     	r3, sp, #0x10
0x000d5b:	subs    	r0, r0, r1
0x000d5d:	lsrs    	r1, r0, #0x1f
0x000d5f:	adds    	r0, r1, r0
0x000d61:	asrs    	r0, r0, #1
0x000d63:	adds    	r1, r0, r4
0x000d65:	ldr     	r0, [sp, #0x88]
0x000d67:	str     	r1, [sp, #4]
0x000d69:	movs    	r1, #0xff
0x000d6b:	str     	r0, [sp]
0x000d6d:	movs    	r0, #0xf1
0x000d6f:	adds    	r1, #0x51
0x000d71:	str     	r2, [sp, #8]
0x000d73:	ldr     	r2, [sp, #0x64]
0x000d75:	lsls    	r0, r0, #9
0x000d77:	bl      	#0x4c2d
; block 0xd7b
0x000d7b:	b       	#0xe01
; block 0xd7d
0x000d7d:	ldr     	r0, [sp, #0x88]
0x000d7f:	ldr     	r3, [sp, #0x64]
0x000d81:	str     	r0, [sp, #0x3c]
0x000d83:	ldr     	r1, [sp, #0x7c]
0x000d85:	ldr     	r0, [sp, #0xc8]
0x000d87:	str     	r3, [sp, #0x38]
0x000d89:	subs    	r0, r0, r1
0x000d8b:	lsrs    	r1, r0, #0x1f
0x000d8d:	adds    	r0, r1, r0
0x000d8f:	asrs    	r0, r0, #1
0x000d91:	adds    	r0, r0, r4
0x000d93:	str     	r0, [sp, #0x40]
0x000d95:	movs    	r0, #0xff
0x000d97:	str     	r0, [sp, #0x44]
0x000d99:	str     	r0, [sp, #0x48]
0x000d9b:	movs    	r1, #0
0x000d9d:	movs    	r3, #0
0x000d9f:	movs    	r2, #0
0x000da1:	str     	r1, [sp]
0x000da3:	str     	r1, [sp, #4]
0x000da5:	str     	r0, [sp, #0x4c]
0x000da7:	movs    	r0, #0xf1
0x000da9:	movs    	r1, #0x56
0x000dab:	str     	r2, [sp, #8]
0x000dad:	add     	r2, sp, #0x38
0x000daf:	lsls    	r0, r0, #9
0x000db1:	str     	r3, [sp, #0x50]
0x000db3:	str     	r3, [sp, #0x54]
0x000db5:	bl      	#0x4c2d
; block 0xdb9
0x000db9:	b       	#0xe01
; block 0xdbb
0x000dbb:	movs    	r2, #0
0x000dbd:	str     	r2, [sp, #8]
0x000dbf:	movs    	r1, #0
0x000dc1:	ldr     	r2, [pc, #0xd4]
0x000dc3:	str     	r1, [sp]
0x000dc5:	str     	r1, [sp, #4]
0x000dc7:	add     	r2, pc
0x000dc9:	movs    	r1, #0x2d
0x000dcb:	movs    	r0, #0xf1
0x000dcd:	lsls    	r0, r0, #9
0x000dcf:	ldr     	r3, [sp, #0x64]
0x000dd1:	bl      	#0x4c2d
; block 0xdd5
0x000dd5:	adds    	r3, r0, #0
0x000dd7:	ldr     	r0, [sp, #0x60]
0x000dd9:	ldr     	r1, [sp, #0x7c]
0x000ddb:	mov     	ip, r0
0x000ddd:	ldr     	r0, [sp, #0xc8]
0x000ddf:	movs    	r2, #0
0x000de1:	subs    	r0, r0, r1
0x000de3:	lsrs    	r1, r0, #0x1f
0x000de5:	adds    	r0, r1, r0
0x000de7:	asrs    	r0, r0, #1
0x000de9:	adds    	r1, r0, r4
0x000deb:	ldr     	r0, [sp, #0x88]
0x000ded:	mvns    	r2, r2
0x000def:	str     	r1, [sp, #4]
0x000df1:	str     	r0, [sp]
0x000df3:	movs    	r0, #0xf1
0x000df5:	movs    	r1, #0xae
0x000df7:	str     	r2, [sp, #8]
0x000df9:	mov     	r2, ip
0x000dfb:	lsls    	r0, r0, #9
0x000dfd:	bl      	#0x4c2d
; block 0xe01
0x000e01:	ldr     	r0, [pc, #0x98]
0x000e03:	movs    	r3, #3
0x000e05:	add     	r0, sb
0x000e07:	ldrsb   	r0, [r0, r3]
0x000e09:	cmp     	r0, #0
0x000e0b:	bne     	#0xe87
; block 0xe0d
0x000e0d:	add     	r1, sp, #0x78
0x000e0f:	str     	r1, [sp, #4]
0x000e11:	add     	r2, sp, #0x7c
0x000e13:	str     	r0, [sp]
0x000e15:	movs    	r0, #0xf1
0x000e17:	str     	r2, [sp, #8]
0x000e19:	movs    	r1, #0x2a
0x000e1b:	movs    	r3, #0
0x000e1d:	lsls    	r0, r0, #9
0x000e1f:	ldr     	r2, [sp, #0x5c]
0x000e21:	bl      	#0x4c2d
; block 0xe25
0x000e25:	ldr     	r0, [sp, #0x5c]
0x000e27:	ldr     	r3, [sp, #0x84]
0x000e29:	str     	r0, [sp, #0x38]
0x000e2b:	ldr     	r0, [sp, #0x78]
0x000e2d:	movs    	r1, #0
0x000e2f:	subs    	r0, r3, r0
0x000e31:	subs    	r0, #3
0x000e33:	str     	r0, [sp, #0x3c]
0x000e35:	adds    	r0, r4, #3
0x000e37:	str     	r0, [sp, #0x40]
0x000e39:	movs    	r0, #0xff
0x000e3b:	str     	r0, [sp, #0x44]
0x000e3d:	str     	r0, [sp, #0x48]
0x000e3f:	movs    	r3, #0
0x000e41:	movs    	r2, #0
0x000e43:	str     	r1, [sp, #4]
0x000e45:	str     	r0, [sp, #0x4c]
0x000e47:	str     	r1, [sp]
0x000e49:	movs    	r1, #0x56
0x000e4b:	movs    	r0, #0xf1
0x000e4d:	str     	r2, [sp, #8]
0x000e4f:	add     	r2, sp, #0x38
0x000e51:	lsls    	r0, r0, #9
0x000e53:	str     	r3, [sp, #0x50]
0x000e55:	str     	r3, [sp, #0x54]
0x000e57:	bl      	#0x4c2d
; block 0xe5b
0x000e5b:	ldr     	r0, [sp, #0xc8]
0x000e5d:	ldr     	r1, [sp, #0x7c]
0x000e5f:	subs    	r0, r0, r1
0x000e61:	lsrs    	r2, r0, #0x1f
0x000e63:	adds    	r0, r2, r0
0x000e65:	asrs    	r0, r0, #1
0x000e67:	subs    	r1, #9
0x000e69:	asrs    	r1, r1, #1
0x000e6b:	adds    	r0, r0, r4
0x000e6d:	adds    	r0, r0, r1
0x000e6f:	movs    	r1, #0
0x000e71:	str     	r1, [sp, #4]
0x000e73:	movs    	r2, #0
0x000e75:	str     	r0, [sp]
0x000e77:	movs    	r0, #0xf1
0x000e79:	str     	r2, [sp, #8]
0x000e7b:	movs    	r1, #0xd8
0x000e7d:	lsls    	r0, r0, #9
0x000e7f:	ldr     	r2, [sp, #0x68]
0x000e81:	ldr     	r3, [sp, #0x84]
0x000e83:	bl      	#0x4c2d
; block 0xe87
0x000e87:	ldr     	r0, [sp, #0x6c]
0x000e89:	adds    	r4, r4, r6
0x000e8b:	adds    	r5, #1
0x000e8d:	cmp     	r5, r0
0x000e8f:	bge     	#0xe93
; block 0xe91
0x000e91:	b       	#0xc79
; block 0xe93
0x000e93:	add     	sp, #0xa4
0x000e95:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_e99 @ 0xe99 offset=0xe98 size=8 blocks=1 cc=1 =====
; block 0xe99
0x000e99:	ldr     	r5, [pc, #0x2a8]
0x000e9b:	movs    	r0, r0
0x000e9d:	movs    	r4, r0
0x000e9f:	movs    	r0, r0
0x000ea1:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x000ea3:	adds    	r4, r0, #0
0x000ea5:	adds    	r7, r1, #0
0x000ea7:	sub     	sp, #0x3c
0x000ea9:	movs    	r1, #0
0x000eab:	ldr     	r5, [pc, #0x3d0]
0x000ead:	movs    	r2, #0
0x000eaf:	str     	r2, [sp, #8]
0x000eb1:	str     	r1, [sp]
0x000eb3:	str     	r1, [sp, #4]
0x000eb5:	add     	r5, sb
0x000eb7:	ldr     	r0, [r5, #0x38]
0x000eb9:	movs    	r1, #0x11
0x000ebb:	ldr     	r2, [r0]
0x000ebd:	movs    	r0, #0xf1
0x000ebf:	movs    	r3, #4
0x000ec1:	lsls    	r0, r0, #9
0x000ec3:	bl      	#0x4c2d

; ===== sub_ea1 @ 0xea1 offset=0xea0 size=986 blocks=53 cc=39 =====
; block 0xea1
0x000ea1:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x000ea3:	adds    	r4, r0, #0
0x000ea5:	adds    	r7, r1, #0
0x000ea7:	sub     	sp, #0x3c
0x000ea9:	movs    	r1, #0
0x000eab:	ldr     	r5, [pc, #0x3d0]
0x000ead:	movs    	r2, #0
0x000eaf:	str     	r2, [sp, #8]
0x000eb1:	str     	r1, [sp]
0x000eb3:	str     	r1, [sp, #4]
0x000eb5:	add     	r5, sb
0x000eb7:	ldr     	r0, [r5, #0x38]
0x000eb9:	movs    	r1, #0x11
0x000ebb:	ldr     	r2, [r0]
0x000ebd:	movs    	r0, #0xf1
0x000ebf:	movs    	r3, #4
0x000ec1:	lsls    	r0, r0, #9
0x000ec3:	bl      	#0x4c2d
; block 0xec7
0x000ec7:	str     	r0, [sp, #0x30]
0x000ec9:	adds    	r0, r7, #0
0x000ecb:	subs    	r0, #0x14
0x000ecd:	movs    	r6, #0
0x000ecf:	adds    	r4, #8
0x000ed1:	str     	r4, [sp, #0x3c]
0x000ed3:	blx     	#0x2e8
; block 0xed7
0x000ed7:	adds    	r7, r0, #0
0x000ed9:	ldr     	r0, [sp, #0x30]
0x000edb:	adds    	r4, r1, #0
0x000edd:	adds    	r0, r4, #0
0x000edf:	ldr     	r1, [r5, #0x6c]
0x000ee1:	blx     	#0x20
; block 0xee5
0x000ee5:	muls    	r0, r4, r0
0x000ee7:	str     	r0, [sp, #0x2c]
0x000ee9:	ldr     	r1, [sp, #0x2c]
0x000eeb:	ldr     	r0, [sp, #0x30]
0x000eed:	adds    	r1, r1, r4
0x000eef:	cmp     	r1, r0
0x000ef1:	bge     	#0xef5
; block 0xef3
0x000ef3:	adds    	r0, r1, #0
0x000ef5:	ldr     	r5, [sp, #0x44]
0x000ef7:	ldr     	r4, [sp, #0x2c]
0x000ef9:	adds    	r5, #3
0x000efb:	cmp     	r4, r0
0x000efd:	str     	r0, [sp, #0x28]
0x000eff:	bge     	#0xfe5
; block 0xef5
0x000ef5:	ldr     	r5, [sp, #0x44]
0x000ef7:	ldr     	r4, [sp, #0x2c]
0x000ef9:	adds    	r5, #3
0x000efb:	cmp     	r4, r0
0x000efd:	str     	r0, [sp, #0x28]
0x000eff:	bge     	#0xfe5
; block 0xf01
0x000f01:	lsrs    	r0, r7, #0x1f
0x000f03:	adds    	r0, r0, r7
0x000f05:	asrs    	r0, r0, #1
0x000f07:	str     	r0, [sp, #0x38]
0x000f09:	lsls    	r1, r6, #2
0x000f0b:	adds    	r1, r1, r6
0x000f0d:	ldr     	r2, [sp, #0x3c]
0x000f0f:	lsls    	r1, r1, #2
0x000f11:	adds    	r1, r1, r2
0x000f13:	ldr     	r0, [sp, #0x38]
0x000f15:	movs    	r2, #0
0x000f17:	adds    	r7, r0, r1
0x000f19:	str     	r7, [sp, #0x34]
0x000f1b:	movs    	r1, #0x10
0x000f1d:	movs    	r0, #0x14
0x000f1f:	str     	r0, [sp]
0x000f21:	str     	r1, [sp, #4]
0x000f23:	adds    	r7, #4
0x000f25:	str     	r2, [sp, #8]
0x000f27:	adds    	r3, r5, #0
0x000f29:	adds    	r2, r7, #0
0x000f2b:	movs    	r1, #0x2f
0x000f2d:	movs    	r0, #0xf1
0x000f2f:	lsls    	r0, r0, #9
0x000f31:	bl      	#0x4c2d
; block 0xf09
0x000f09:	lsls    	r1, r6, #2
0x000f0b:	adds    	r1, r1, r6
0x000f0d:	ldr     	r2, [sp, #0x3c]
0x000f0f:	lsls    	r1, r1, #2
0x000f11:	adds    	r1, r1, r2
0x000f13:	ldr     	r0, [sp, #0x38]
0x000f15:	movs    	r2, #0
0x000f17:	adds    	r7, r0, r1
0x000f19:	str     	r7, [sp, #0x34]
0x000f1b:	movs    	r1, #0x10
0x000f1d:	movs    	r0, #0x14
0x000f1f:	str     	r0, [sp]
0x000f21:	str     	r1, [sp, #4]
0x000f23:	adds    	r7, #4
0x000f25:	str     	r2, [sp, #8]
0x000f27:	adds    	r3, r5, #0
0x000f29:	adds    	r2, r7, #0
0x000f2b:	movs    	r1, #0x2f
0x000f2d:	movs    	r0, #0xf1
0x000f2f:	lsls    	r0, r0, #9
0x000f31:	bl      	#0x4c2d
; block 0xf35
0x000f35:	cmp     	r0, #1
0x000f37:	bne     	#0xf5d
; block 0xf39
0x000f39:	ldr     	r1, [pc, #0x340]
0x000f3b:	add     	r1, sb
0x000f3d:	ldr     	r0, [r1, #0x6c]
0x000f3f:	cmp     	r0, r4
0x000f41:	beq     	#0xf5d
; block 0xf43
0x000f43:	movs    	r3, #0
0x000f45:	str     	r3, [r1, #0x3c]
0x000f47:	str     	r4, [r1, #0x6c]
0x000f49:	movs    	r1, #0
0x000f4b:	str     	r1, [sp]
0x000f4d:	str     	r1, [sp, #4]
0x000f4f:	movs    	r2, #0
0x000f51:	movs    	r1, #0xe6
0x000f53:	movs    	r0, #0xf1
0x000f55:	lsls    	r0, r0, #9
0x000f57:	str     	r2, [sp, #8]
0x000f59:	bl      	#0x4c2d
; block 0xf5d
0x000f5d:	ldr     	r0, [pc, #0x31c]
0x000f5f:	add     	r0, sb
0x000f61:	ldr     	r0, [r0, #0x6c]
0x000f63:	cmp     	r0, r4
0x000f65:	bne     	#0x1037
; block 0xf67
0x000f67:	ldr     	r2, [pc, #0x314]
0x000f69:	movs    	r0, #0
0x000f6b:	add     	r2, sb
0x000f6d:	ldr     	r1, [r2, #0x3c]
0x000f6f:	cmp     	r1, #0
0x000f71:	bne     	#0xf9f
; block 0xf73
0x000f73:	movs    	r2, #0
0x000f75:	str     	r2, [sp, #8]
0x000f77:	str     	r1, [sp]
0x000f79:	str     	r1, [sp, #4]
0x000f7b:	movs    	r1, #0xe1
0x000f7d:	movs    	r2, #0x27
0x000f7f:	movs    	r3, #0
0x000f81:	movs    	r0, #0xf1
0x000f83:	lsls    	r0, r0, #9
0x000f85:	bl      	#0x4c2d
; block 0xf89
0x000f89:	asrs    	r1, r0, #0x1f
0x000f8b:	lsrs    	r1, r1, #0x1e
0x000f8d:	adds    	r0, r1, r0
0x000f8f:	asrs    	r0, r0, #2
0x000f91:	lsrs    	r1, r0, #0x1f
0x000f93:	adds    	r1, r1, r0
0x000f95:	asrs    	r1, r1, #1
0x000f97:	lsls    	r1, r1, #1
0x000f99:	subs    	r0, r0, r1
0x000f9b:	lsls    	r0, r0, #1
0x000f9d:	adds    	r0, #1
0x000f9f:	subs    	r3, r5, r0
0x000fa1:	ldr     	r0, [sp, #0x34]
0x000fa3:	subs    	r3, #2
0x000fa5:	adds    	r0, #2
0x000fa7:	mov     	ip, r0
0x000fa9:	movs    	r0, #0x12
0x000fab:	movs    	r2, #1
0x000fad:	movs    	r1, #0x14
0x000faf:	str     	r1, [sp, #4]
0x000fb1:	str     	r0, [sp]
0x000fb3:	movs    	r0, #0xf1
0x000fb5:	movs    	r1, #0xc4
0x000fb7:	str     	r2, [sp, #8]
0x000fb9:	mov     	r2, ip
0x000fbb:	lsls    	r0, r0, #9
0x000fbd:	bl      	#0x4c2d
; block 0xf9f
0x000f9f:	subs    	r3, r5, r0
0x000fa1:	ldr     	r0, [sp, #0x34]
0x000fa3:	subs    	r3, #2
0x000fa5:	adds    	r0, #2
0x000fa7:	mov     	ip, r0
0x000fa9:	movs    	r0, #0x12
0x000fab:	movs    	r2, #1
0x000fad:	movs    	r1, #0x14
0x000faf:	str     	r1, [sp, #4]
0x000fb1:	str     	r0, [sp]
0x000fb3:	movs    	r0, #0xf1
0x000fb5:	movs    	r1, #0xc4
0x000fb7:	str     	r2, [sp, #8]
0x000fb9:	mov     	r2, ip
0x000fbb:	lsls    	r0, r0, #9
0x000fbd:	bl      	#0x4c2d
; block 0xfc1
0x000fc1:	ldr     	r2, [pc, #0x2b8]
0x000fc3:	str     	r7, [sp, #0xc]
0x000fc5:	add     	r2, sb
0x000fc7:	ldr     	r1, [r2, #0x3c]
0x000fc9:	movs    	r0, #0
0x000fcb:	cmp     	r1, #0
0x000fcd:	bne     	#0x1009
; block 0xfcf
0x000fcf:	movs    	r3, #0
0x000fd1:	ldr     	r1, [r2, #0x6c]
0x000fd3:	adds    	r0, r3, #0
0x000fd5:	cmp     	r1, r4
0x000fd7:	bne     	#0x1009
; block 0xfd9
0x000fd9:	movs    	r2, #0
0x000fdb:	movs    	r1, #0
0x000fdd:	str     	r1, [sp]
0x000fdf:	str     	r1, [sp, #4]
0x000fe1:	str     	r2, [sp, #8]
0x000fe3:	b       	#0xfe7
; block 0xfe5
0x000fe5:	b       	#0x10d1
; block 0xfe7
0x000fe7:	movs    	r2, #0x27
0x000fe9:	movs    	r1, #0xe1
0x000feb:	movs    	r0, #0xf1
0x000fed:	lsls    	r0, r0, #9
0x000fef:	bl      	#0x4c2d
; block 0xff3
0x000ff3:	asrs    	r1, r0, #0x1f
0x000ff5:	lsrs    	r1, r1, #0x1e
0x000ff7:	adds    	r0, r1, r0
0x000ff9:	asrs    	r0, r0, #2
0x000ffb:	lsrs    	r1, r0, #0x1f
0x000ffd:	adds    	r1, r1, r0
0x000fff:	asrs    	r1, r1, #1
0x001001:	lsls    	r1, r1, #1
0x001003:	subs    	r0, r0, r1
0x001005:	lsls    	r0, r0, #1
0x001007:	adds    	r0, #1
0x001009:	subs    	r0, r5, r0
0x00100b:	str     	r0, [sp, #0x10]
0x00100d:	movs    	r0, #0xe
0x00100f:	str     	r0, [sp, #0x14]
0x001011:	movs    	r0, #0x10
0x001013:	str     	r0, [sp, #0x18]
0x001015:	movs    	r0, #0x8b
0x001017:	str     	r0, [sp, #0x1c]
0x001019:	movs    	r0, #0x90
0x00101b:	str     	r0, [sp, #0x20]
0x00101d:	movs    	r3, #0
0x00101f:	movs    	r1, #0
0x001021:	str     	r3, [sp, #0x24]
0x001023:	movs    	r2, #0
0x001025:	str     	r1, [sp, #4]
0x001027:	str     	r1, [sp]
0x001029:	movs    	r1, #0x1f
0x00102b:	str     	r2, [sp, #8]
0x00102d:	movs    	r0, #0xf1
0x00102f:	lsls    	r0, r0, #9
0x001031:	add     	r2, sp, #0xc
0x001033:	bl      	#0x4c2d
; block 0x1009
0x001009:	subs    	r0, r5, r0
0x00100b:	str     	r0, [sp, #0x10]
0x00100d:	movs    	r0, #0xe
0x00100f:	str     	r0, [sp, #0x14]
0x001011:	movs    	r0, #0x10
0x001013:	str     	r0, [sp, #0x18]
0x001015:	movs    	r0, #0x8b
0x001017:	str     	r0, [sp, #0x1c]
0x001019:	movs    	r0, #0x90
0x00101b:	str     	r0, [sp, #0x20]
0x00101d:	movs    	r3, #0
0x00101f:	movs    	r1, #0
0x001021:	str     	r3, [sp, #0x24]
0x001023:	movs    	r2, #0
0x001025:	str     	r1, [sp, #4]
0x001027:	str     	r1, [sp]
0x001029:	movs    	r1, #0x1f
0x00102b:	str     	r2, [sp, #8]
0x00102d:	movs    	r0, #0xf1
0x00102f:	lsls    	r0, r0, #9
0x001031:	add     	r2, sp, #0xc
0x001033:	bl      	#0x4c2d
; block 0x1037
0x001037:	movs    	r1, #0
0x001039:	movs    	r2, #0
0x00103b:	str     	r2, [sp, #8]
0x00103d:	str     	r1, [sp]
0x00103f:	str     	r1, [sp, #4]
0x001041:	movs    	r1, #0xe1
0x001043:	movs    	r2, #0xb8
0x001045:	movs    	r3, #0
0x001047:	movs    	r0, #0xf1
0x001049:	lsls    	r0, r0, #9
0x00104b:	bl      	#0x4c2d
; block 0x104f
0x00104f:	str     	r7, [sp, #0x14]
0x001051:	ldr     	r7, [pc, #0x228]
0x001053:	str     	r0, [sp, #0x10]
0x001055:	add     	r7, sb
0x001057:	ldr     	r1, [r7, #0x3c]
0x001059:	movs    	r0, #0
0x00105b:	cmp     	r1, #0
0x00105d:	bne     	#0x1095
; block 0x105f
0x00105f:	movs    	r3, #0
0x001061:	ldr     	r1, [r7, #0x6c]
0x001063:	adds    	r0, r3, #0
0x001065:	cmp     	r1, r4
0x001067:	bne     	#0x1095
; block 0x1069
0x001069:	movs    	r1, #0
0x00106b:	movs    	r2, #0
0x00106d:	str     	r2, [sp, #8]
0x00106f:	str     	r1, [sp]
0x001071:	str     	r1, [sp, #4]
0x001073:	movs    	r1, #0xe1
0x001075:	movs    	r2, #0x27
0x001077:	movs    	r0, #0xf1
0x001079:	lsls    	r0, r0, #9
0x00107b:	bl      	#0x4c2d
; block 0x107f
0x00107f:	asrs    	r1, r0, #0x1f
0x001081:	lsrs    	r1, r1, #0x1e
0x001083:	adds    	r0, r1, r0
0x001085:	asrs    	r0, r0, #2
0x001087:	lsrs    	r1, r0, #0x1f
0x001089:	adds    	r1, r1, r0
0x00108b:	asrs    	r1, r1, #1
0x00108d:	lsls    	r1, r1, #1
0x00108f:	subs    	r0, r0, r1
0x001091:	lsls    	r0, r0, #1
0x001093:	adds    	r0, #1
0x001095:	subs    	r0, r5, r0
0x001097:	str     	r0, [sp, #0x18]
0x001099:	movs    	r0, #0x10
0x00109b:	str     	r0, [sp, #0x1c]
0x00109d:	str     	r0, [sp, #0x20]
0x00109f:	ldr     	r0, [r7, #0x38]
0x0010a1:	lsls    	r1, r4, #2
0x0010a3:	ldr     	r0, [r0]
0x0010a5:	movs    	r3, #8
0x0010a7:	ldr     	r0, [r0, r1]
0x0010a9:	movs    	r1, #0
0x0010ab:	ldrsb   	r0, [r0, r3]
0x0010ad:	movs    	r2, #0
0x0010af:	str     	r1, [sp]
0x0010b1:	str     	r0, [sp, #0x24]
0x0010b3:	str     	r1, [sp, #4]
0x0010b5:	movs    	r1, #0x22
0x0010b7:	movs    	r0, #0xf1
0x0010b9:	str     	r2, [sp, #8]
0x0010bb:	movs    	r3, #0
0x0010bd:	lsls    	r0, r0, #9
0x0010bf:	add     	r2, sp, #0x10
0x0010c1:	bl      	#0x4c2d
; block 0x1095
0x001095:	subs    	r0, r5, r0
0x001097:	str     	r0, [sp, #0x18]
0x001099:	movs    	r0, #0x10
0x00109b:	str     	r0, [sp, #0x1c]
0x00109d:	str     	r0, [sp, #0x20]
0x00109f:	ldr     	r0, [r7, #0x38]
0x0010a1:	lsls    	r1, r4, #2
0x0010a3:	ldr     	r0, [r0]
0x0010a5:	movs    	r3, #8
0x0010a7:	ldr     	r0, [r0, r1]
0x0010a9:	movs    	r1, #0
0x0010ab:	ldrsb   	r0, [r0, r3]
0x0010ad:	movs    	r2, #0
0x0010af:	str     	r1, [sp]
0x0010b1:	str     	r0, [sp, #0x24]
0x0010b3:	str     	r1, [sp, #4]
0x0010b5:	movs    	r1, #0x22
0x0010b7:	movs    	r0, #0xf1
0x0010b9:	str     	r2, [sp, #8]
0x0010bb:	movs    	r3, #0
0x0010bd:	lsls    	r0, r0, #9
0x0010bf:	add     	r2, sp, #0x10
0x0010c1:	bl      	#0x4c2d
; block 0x10c5
0x0010c5:	ldr     	r0, [sp, #0x28]
0x0010c7:	adds    	r6, #1
0x0010c9:	adds    	r4, #1
0x0010cb:	cmp     	r4, r0
0x0010cd:	bge     	#0x10d1
; block 0x10cf
0x0010cf:	b       	#0xf09
; block 0x10d1
0x0010d1:	ldr     	r0, [pc, #0x1a8]
0x0010d3:	add     	r0, sb
0x0010d5:	ldr     	r0, [r0, #0x3c]
0x0010d7:	cmp     	r0, #0
0x0010d9:	bne     	#0x11bf
; block 0x10db
0x0010db:	ldr     	r0, [sp, #0x2c]
0x0010dd:	movs    	r4, #8
0x0010df:	cmp     	r0, #0
0x0010e1:	ble     	#0x118b
; block 0x10e3
0x0010e3:	movs    	r1, #0
0x0010e5:	movs    	r2, #0
0x0010e7:	str     	r2, [sp, #8]
0x0010e9:	str     	r1, [sp]
0x0010eb:	str     	r1, [sp, #4]
0x0010ed:	movs    	r6, #0
0x0010ef:	adds    	r3, r6, #0
0x0010f1:	movs    	r1, #0xe1
0x0010f3:	movs    	r2, #0x26
0x0010f5:	movs    	r0, #0xf1
0x0010f7:	lsls    	r0, r0, #9
0x0010f9:	bl      	#0x4c2d
; block 0x10fd
0x0010fd:	movs    	r1, #0
0x0010ff:	movs    	r2, #0
0x001101:	str     	r2, [sp, #8]
0x001103:	str     	r1, [sp]
0x001105:	str     	r1, [sp, #4]
0x001107:	str     	r0, [sp, #0x10]
0x001109:	movs    	r0, #0xf1
0x00110b:	movs    	r1, #0xe1
0x00110d:	movs    	r2, #0x27
0x00110f:	adds    	r3, r6, #0
0x001111:	lsls    	r0, r0, #9
0x001113:	bl      	#0x4c2d
; block 0x1117
0x001117:	blx     	#0x308
; block 0x111b
0x00111b:	lsrs    	r0, r1, #0x1f
0x00111d:	adds    	r0, r0, r1
0x00111f:	asrs    	r0, r0, #1
0x001121:	lsls    	r0, r0, #1
0x001123:	subs    	r0, r1, r0
0x001125:	lsls    	r0, r0, #1
0x001127:	str     	r0, [sp, #0x14]
0x001129:	movs    	r0, #0xe
0x00112b:	str     	r0, [sp, #0x20]
0x00112d:	movs    	r1, #0
0x00112f:	str     	r6, [sp, #0x24]
0x001131:	movs    	r2, #0
0x001133:	str     	r1, [sp, #4]
0x001135:	str     	r1, [sp]
0x001137:	movs    	r1, #0x22
0x001139:	str     	r2, [sp, #8]
0x00113b:	movs    	r0, #0xf1
0x00113d:	adds    	r3, r6, #0
0x00113f:	lsls    	r0, r0, #9
0x001141:	add     	r2, sp, #0x10
0x001143:	str     	r5, [sp, #0x18]
0x001145:	str     	r4, [sp, #0x1c]
0x001147:	bl      	#0x4c2d
; block 0x114b
0x00114b:	movs    	r1, #0
0x00114d:	movs    	r2, #0
0x00114f:	str     	r2, [sp, #8]
0x001151:	str     	r1, [sp]
0x001153:	str     	r1, [sp, #4]
0x001155:	movs    	r1, #0xe1
0x001157:	movs    	r2, #0x27
0x001159:	adds    	r3, r6, #0
0x00115b:	movs    	r0, #0xf1
0x00115d:	lsls    	r0, r0, #9
0x00115f:	bl      	#0x4c2d
; block 0x1163
0x001163:	blx     	#0x308
; block 0x1167
0x001167:	lsrs    	r0, r1, #0x1f
0x001169:	adds    	r0, r0, r1
0x00116b:	asrs    	r0, r0, #1
0x00116d:	lsls    	r0, r0, #1
0x00116f:	subs    	r0, r1, r0
0x001171:	lsls    	r3, r0, #1
0x001173:	movs    	r1, #0x1e
0x001175:	movs    	r2, #0x14
0x001177:	str     	r2, [sp, #8]
0x001179:	str     	r1, [sp, #4]
0x00117b:	movs    	r1, #0x23
0x00117d:	movs    	r2, #2
0x00117f:	subs    	r3, #0x14
0x001181:	movs    	r0, #0xf1
0x001183:	lsls    	r0, r0, #9
0x001185:	str     	r5, [sp]
0x001187:	bl      	#0x4c2d
; block 0x118b
0x00118b:	ldr     	r0, [sp, #0x28]
0x00118d:	ldr     	r1, [sp, #0x30]
0x00118f:	cmp     	r0, r1
0x001191:	bge     	#0x11bf
; block 0x1193
0x001193:	movs    	r1, #0
0x001195:	movs    	r2, #0
0x001197:	str     	r2, [sp, #8]
0x001199:	str     	r1, [sp]
0x00119b:	str     	r1, [sp, #4]
0x00119d:	movs    	r6, #0
0x00119f:	adds    	r3, r6, #0
0x0011a1:	movs    	r1, #0xe1
0x0011a3:	movs    	r2, #0x26
0x0011a5:	movs    	r0, #0xf1
0x0011a7:	lsls    	r0, r0, #9
0x0011a9:	bl      	#0x4c2d
; block 0x11ad
0x0011ad:	movs    	r1, #0
0x0011af:	movs    	r2, #0
0x0011b1:	str     	r1, [sp]
0x0011b3:	str     	r1, [sp, #4]
0x0011b5:	adds    	r3, r6, #0
0x0011b7:	movs    	r1, #0x1c
0x0011b9:	str     	r2, [sp, #8]
0x0011bb:	str     	r0, [sp, #0x10]
0x0011bd:	b       	#0x11c1
; block 0x11bf
0x0011bf:	b       	#0x1277
; block 0x11c1
0x0011c1:	movs    	r0, #0xf1
0x0011c3:	lsls    	r0, r0, #9
0x0011c5:	bl      	#0x4c2d
; block 0x11c9
0x0011c9:	adds    	r7, r0, #0
0x0011cb:	movs    	r1, #0
0x0011cd:	movs    	r2, #0
0x0011cf:	str     	r2, [sp, #8]
0x0011d1:	str     	r1, [sp]
0x0011d3:	str     	r1, [sp, #4]
0x0011d5:	subs    	r7, #8
0x0011d7:	adds    	r3, r6, #0
0x0011d9:	movs    	r1, #0xe1
0x0011db:	movs    	r2, #0x27
0x0011dd:	movs    	r0, #0xf1
0x0011df:	lsls    	r0, r0, #9
0x0011e1:	bl      	#0x4c2d
; block 0x11e5
0x0011e5:	blx     	#0x308
; block 0x11e9
0x0011e9:	lsrs    	r0, r1, #0x1f
0x0011eb:	adds    	r0, r0, r1
0x0011ed:	asrs    	r0, r0, #1
0x0011ef:	lsls    	r0, r0, #1
0x0011f1:	subs    	r0, r1, r0
0x0011f3:	lsls    	r0, r0, #1
0x0011f5:	subs    	r0, r7, r0
0x0011f7:	str     	r0, [sp, #0x14]
0x0011f9:	movs    	r0, #0xe
0x0011fb:	str     	r0, [sp, #0x20]
0x0011fd:	movs    	r0, #1
0x0011ff:	str     	r0, [sp, #0x24]
0x001201:	movs    	r1, #0
0x001203:	movs    	r2, #0
0x001205:	str     	r1, [sp]
0x001207:	str     	r1, [sp, #4]
0x001209:	movs    	r1, #0x22
0x00120b:	str     	r2, [sp, #8]
0x00120d:	movs    	r0, #0xf1
0x00120f:	adds    	r3, r6, #0
0x001211:	lsls    	r0, r0, #9
0x001213:	add     	r2, sp, #0x10
0x001215:	str     	r5, [sp, #0x18]
0x001217:	str     	r4, [sp, #0x1c]
0x001219:	bl      	#0x4c2d
; block 0x121d
0x00121d:	movs    	r1, #0
0x00121f:	str     	r1, [sp]
0x001221:	str     	r1, [sp, #4]
0x001223:	movs    	r2, #0
0x001225:	movs    	r1, #0x1c
0x001227:	adds    	r3, r6, #0
0x001229:	movs    	r0, #0xf1
0x00122b:	lsls    	r0, r0, #9
0x00122d:	str     	r2, [sp, #8]
0x00122f:	bl      	#0x4c2d
; block 0x1233
0x001233:	adds    	r4, r0, #0
0x001235:	movs    	r1, #0
0x001237:	movs    	r2, #0
0x001239:	str     	r2, [sp, #8]
0x00123b:	str     	r1, [sp]
0x00123d:	str     	r1, [sp, #4]
0x00123f:	subs    	r4, #8
0x001241:	adds    	r3, r6, #0
0x001243:	movs    	r1, #0xe1
0x001245:	movs    	r2, #0x27
0x001247:	movs    	r0, #0xf1
0x001249:	lsls    	r0, r0, #9
0x00124b:	bl      	#0x4c2d
; block 0x124f
0x00124f:	blx     	#0x308
; block 0x1253
0x001253:	lsrs    	r0, r1, #0x1f
0x001255:	adds    	r0, r0, r1
0x001257:	asrs    	r0, r0, #1
0x001259:	lsls    	r0, r0, #1
0x00125b:	subs    	r0, r1, r0
0x00125d:	lsls    	r0, r0, #1
0x00125f:	movs    	r1, #0x1e
0x001261:	movs    	r2, #0x14
0x001263:	str     	r2, [sp, #8]
0x001265:	str     	r1, [sp, #4]
0x001267:	subs    	r3, r4, r0
0x001269:	movs    	r0, #0xf1
0x00126b:	movs    	r1, #0x23
0x00126d:	movs    	r2, #3
0x00126f:	lsls    	r0, r0, #9
0x001271:	str     	r5, [sp]
0x001273:	bl      	#0x4c2d
; block 0x1277
0x001277:	add     	sp, #0x4c
0x001279:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_127d @ 0x127d offset=0x127c size=4 blocks=1 cc=1 =====
; block 0x127d
0x00127d:	movs    	r4, r0
0x00127f:	movs    	r0, r0
0x001281:	push    	{r4, r5, r6, r7, lr}
0x001283:	sub     	sp, #0x7c
0x001285:	movs    	r7, #0
0x001287:	movs    	r0, #0x3c
0x001289:	str     	r0, [sp, #0x50]
0x00128b:	movs    	r6, #0x46
0x00128d:	movs    	r2, #0
0x00128f:	movs    	r1, #0
0x001291:	movs    	r0, #0
0x001293:	str     	r7, [sp, #0x44]
0x001295:	bl      	#0x4bdd

; ===== sub_1281 @ 0x1281 offset=0x1280 size=1704 blocks=80 cc=58 =====
; block 0x1281
0x001281:	push    	{r4, r5, r6, r7, lr}
0x001283:	sub     	sp, #0x7c
0x001285:	movs    	r7, #0
0x001287:	movs    	r0, #0x3c
0x001289:	str     	r0, [sp, #0x50]
0x00128b:	movs    	r6, #0x46
0x00128d:	movs    	r2, #0
0x00128f:	movs    	r1, #0
0x001291:	movs    	r0, #0
0x001293:	str     	r7, [sp, #0x44]
0x001295:	bl      	#0x4bdd
; block 0x1299
0x001299:	movs    	r1, #0
0x00129b:	ldr     	r0, [pc, #0x3e8]
0x00129d:	str     	r1, [sp]
0x00129f:	str     	r1, [sp, #4]
0x0012a1:	movs    	r2, #0
0x0012a3:	str     	r2, [sp, #8]
0x0012a5:	add     	r0, sb
0x0012a7:	ldr     	r2, [r0, #0x28]
0x0012a9:	movs    	r0, #0xf1
0x0012ab:	movs    	r1, #0x11
0x0012ad:	movs    	r3, #4
0x0012af:	lsls    	r0, r0, #9
0x0012b1:	bl      	#0x4c2d
; block 0x12b5
0x0012b5:	adds    	r1, r0, #0
0x0012b7:	movs    	r0, #3
0x0012b9:	str     	r0, [sp, #0x58]
0x0012bb:	blx     	#0x20
; block 0x12bf
0x0012bf:	str     	r0, [sp, #0x54]
0x0012c1:	ldr     	r0, [pc, #0x3c0]
0x0012c3:	ldr     	r1, [sp, #0x58]
0x0012c5:	add     	r0, sb
0x0012c7:	str     	r1, [r0, #0x40]
0x0012c9:	ldr     	r1, [pc, #0x3b8]
0x0012cb:	ldr     	r0, [sp, #0x54]
0x0012cd:	add     	r1, sb
0x0012cf:	str     	r0, [r1, #0x44]
0x0012d1:	movs    	r1, #0
0x0012d3:	str     	r1, [sp]
0x0012d5:	str     	r1, [sp, #4]
0x0012d7:	movs    	r2, #0
0x0012d9:	movs    	r5, #0
0x0012db:	adds    	r3, r5, #0
0x0012dd:	movs    	r1, #0x1c
0x0012df:	movs    	r0, #0xf1
0x0012e1:	lsls    	r0, r0, #9
0x0012e3:	str     	r2, [sp, #8]
0x0012e5:	bl      	#0x4c2d
; block 0x12e9
0x0012e9:	subs    	r0, #0xd2
0x0012eb:	lsrs    	r1, r0, #0x1f
0x0012ed:	adds    	r0, r1, r0
0x0012ef:	asrs    	r1, r0, #1
0x0012f1:	str     	r1, [sp, #0x4c]
0x0012f3:	movs    	r1, #0x28
0x0012f5:	str     	r1, [sp, #0x48]
0x0012f7:	movs    	r1, #0
0x0012f9:	ldr     	r0, [pc, #0x388]
0x0012fb:	str     	r1, [sp]
0x0012fd:	str     	r1, [sp, #4]
0x0012ff:	movs    	r2, #0
0x001301:	str     	r2, [sp, #8]
0x001303:	movs    	r3, #1
0x001305:	add     	r0, sb
0x001307:	ldrsb   	r2, [r0, r3]
0x001309:	movs    	r0, #0xf1
0x00130b:	lsls    	r0, r0, #9
0x00130d:	movs    	r1, #0x3f
0x00130f:	adds    	r3, r5, #0
0x001311:	bl      	#0x4c2d
; block 0x1315
0x001315:	adds    	r4, r0, #0
0x001317:	movs    	r0, #0x64
0x001319:	movs    	r1, #0x19
0x00131b:	str     	r1, [sp, #4]
0x00131d:	str     	r0, [sp]
0x00131f:	movs    	r2, #0
0x001321:	movs    	r0, #0xf1
0x001323:	movs    	r1, #0x32
0x001325:	adds    	r3, r5, #0
0x001327:	lsls    	r0, r0, #9
0x001329:	str     	r2, [sp, #8]
0x00132b:	bl      	#0x4c2d
; block 0x132f
0x00132f:	movs    	r2, #0
0x001331:	movs    	r1, #5
0x001333:	str     	r2, [sp, #8]
0x001335:	ldr     	r2, [pc, #0x350]
0x001337:	str     	r1, [sp]
0x001339:	str     	r1, [sp, #4]
0x00133b:	adds    	r3, r4, #0
0x00133d:	add     	r2, pc
0x00133f:	movs    	r1, #0x3c
0x001341:	movs    	r0, #0xf1
0x001343:	lsls    	r0, r0, #9
0x001345:	bl      	#0x4c2d
; block 0x1349
0x001349:	movs    	r1, #0
0x00134b:	movs    	r2, #0
0x00134d:	str     	r2, [sp, #8]
0x00134f:	str     	r1, [sp]
0x001351:	str     	r1, [sp, #4]
0x001353:	adds    	r3, r5, #0
0x001355:	adds    	r2, r4, #0
0x001357:	movs    	r1, #9
0x001359:	movs    	r0, #0xf1
0x00135b:	lsls    	r0, r0, #9
0x00135d:	bl      	#0x4c2d
; block 0x1361
0x001361:	ldr     	r0, [sp, #0x54]
0x001363:	cmp     	r0, #0
0x001365:	ble     	#0x144b
; block 0x1367
0x001367:	adds    	r3, r6, #0
0x001369:	subs    	r3, #0xa
0x00136b:	ldr     	r0, [sp, #0x50]
0x00136d:	str     	r3, [sp, #0x78]
0x00136f:	subs    	r0, #0xa
0x001371:	str     	r0, [sp, #0x74]
0x001373:	movs    	r0, #0
0x001375:	ldr     	r1, [sp, #0x58]
0x001377:	str     	r0, [sp, #0x40]
0x001379:	cmp     	r1, #0
0x00137b:	ble     	#0x144d
; block 0x1373
0x001373:	movs    	r0, #0
0x001375:	ldr     	r1, [sp, #0x58]
0x001377:	str     	r0, [sp, #0x40]
0x001379:	cmp     	r1, #0
0x00137b:	ble     	#0x144d
; block 0x137d
0x00137d:	ldr     	r0, [sp, #0x44]
0x00137f:	ldr     	r1, [sp, #0x50]
0x001381:	muls    	r0, r1, r0
0x001383:	ldr     	r1, [sp, #0x48]
0x001385:	adds    	r0, r0, r1
0x001387:	adds    	r3, r0, #0
0x001389:	adds    	r3, #0xa
0x00138b:	str     	r0, [sp, #0x70]
0x00138d:	adds    	r0, #5
0x00138f:	str     	r0, [sp, #0x68]
0x001391:	str     	r3, [sp, #0x6c]
0x001393:	ldr     	r0, [sp, #0x40]
0x001395:	ldr     	r1, [sp, #0x4c]
0x001397:	muls    	r0, r6, r0
0x001399:	ldr     	r5, [sp, #0x70]
0x00139b:	adds    	r4, r0, r1
0x00139d:	ldr     	r1, [pc, #0x2e4]
0x00139f:	lsls    	r0, r7, #2
0x0013a1:	str     	r0, [sp, #0x64]
0x0013a3:	add     	r1, sb
0x0013a5:	ldr     	r1, [r1, #0x28]
0x0013a7:	movs    	r2, #0
0x0013a9:	ldr     	r0, [r1, r0]
0x0013ab:	ldr     	r1, [sp, #0x50]
0x0013ad:	str     	r2, [sp, #8]
0x0013af:	adds    	r3, r5, #0
0x0013b1:	str     	r0, [sp, #0x34]
0x0013b3:	str     	r1, [sp, #4]
0x0013b5:	movs    	r1, #0x32
0x0013b7:	movs    	r0, #0xf1
0x0013b9:	adds    	r2, r4, #0
0x0013bb:	lsls    	r0, r0, #9
0x0013bd:	str     	r6, [sp]
0x0013bf:	bl      	#0x4c2d
; block 0x1393
0x001393:	ldr     	r0, [sp, #0x40]
0x001395:	ldr     	r1, [sp, #0x4c]
0x001397:	muls    	r0, r6, r0
0x001399:	ldr     	r5, [sp, #0x70]
0x00139b:	adds    	r4, r0, r1
0x00139d:	ldr     	r1, [pc, #0x2e4]
0x00139f:	lsls    	r0, r7, #2
0x0013a1:	str     	r0, [sp, #0x64]
0x0013a3:	add     	r1, sb
0x0013a5:	ldr     	r1, [r1, #0x28]
0x0013a7:	movs    	r2, #0
0x0013a9:	ldr     	r0, [r1, r0]
0x0013ab:	ldr     	r1, [sp, #0x50]
0x0013ad:	str     	r2, [sp, #8]
0x0013af:	adds    	r3, r5, #0
0x0013b1:	str     	r0, [sp, #0x34]
0x0013b3:	str     	r1, [sp, #4]
0x0013b5:	movs    	r1, #0x32
0x0013b7:	movs    	r0, #0xf1
0x0013b9:	adds    	r2, r4, #0
0x0013bb:	lsls    	r0, r0, #9
0x0013bd:	str     	r6, [sp]
0x0013bf:	bl      	#0x4c2d
; block 0x13c3
0x0013c3:	ldr     	r0, [pc, #0x2c0]
0x0013c5:	movs    	r3, #2
0x0013c7:	add     	r0, sb
0x0013c9:	ldrsb   	r0, [r0, r3]
0x0013cb:	cmp     	r0, #0
0x0013cd:	beq     	#0x14a7
; block 0x13cf
0x0013cf:	ldr     	r0, [sp, #0x34]
0x0013d1:	cmp     	r0, #0
0x0013d3:	bne     	#0x14a9
; block 0x13d5
0x0013d5:	ldr     	r0, [pc, #0x2b4]
0x0013d7:	add     	r0, pc
0x0013d9:	movs    	r1, #0
0x0013db:	movs    	r2, #0
0x0013dd:	str     	r2, [sp, #8]
0x0013df:	str     	r1, [sp]
0x0013e1:	str     	r1, [sp, #4]
0x0013e3:	str     	r0, [sp, #0x30]
0x0013e5:	movs    	r0, #0xf1
0x0013e7:	movs    	r1, #0xe1
0x0013e9:	movs    	r2, #0x28
0x0013eb:	movs    	r3, #0
0x0013ed:	lsls    	r0, r0, #9
0x0013ef:	bl      	#0x4c2d
; block 0x13f3
0x0013f3:	movs    	r1, #0
0x0013f5:	movs    	r2, #0
0x0013f7:	str     	r2, [sp, #8]
0x0013f9:	str     	r1, [sp]
0x0013fb:	str     	r1, [sp, #4]
0x0013fd:	str     	r0, [sp, #0x2c]
0x0013ff:	movs    	r0, #0xf1
0x001401:	movs    	r1, #0xe1
0x001403:	movs    	r2, #0x29
0x001405:	movs    	r3, #0
0x001407:	lsls    	r0, r0, #9
0x001409:	bl      	#0x4c2d
; block 0x140d
0x00140d:	adds    	r3, r0, #0
0x00140f:	ldr     	r0, [sp, #0x2c]
0x001411:	add     	r1, sp, #0x3c
0x001413:	str     	r1, [sp, #4]
0x001415:	add     	r2, sp, #0x38
0x001417:	str     	r0, [sp]
0x001419:	movs    	r0, #0xf1
0x00141b:	str     	r2, [sp, #8]
0x00141d:	movs    	r1, #0x2a
0x00141f:	lsls    	r0, r0, #9
0x001421:	ldr     	r2, [sp, #0x30]
0x001423:	bl      	#0x4c2d
; block 0x1427
0x001427:	ldr     	r0, [sp, #0x30]
0x001429:	str     	r0, [sp, #0x10]
0x00142b:	ldr     	r0, [sp, #0x3c]
0x00142d:	subs    	r0, r6, r0
0x00142f:	lsrs    	r1, r0, #0x1f
0x001431:	adds    	r0, r1, r0
0x001433:	asrs    	r0, r0, #1
0x001435:	adds    	r0, r0, r4
0x001437:	str     	r0, [sp, #0x14]
0x001439:	ldr     	r0, [sp, #0x50]
0x00143b:	ldr     	r1, [sp, #0x38]
0x00143d:	subs    	r0, r0, r1
0x00143f:	lsrs    	r1, r0, #0x1f
0x001441:	adds    	r0, r1, r0
0x001443:	asrs    	r0, r0, #1
0x001445:	adds    	r0, r0, r5
0x001447:	str     	r0, [sp, #0x18]
0x001449:	b       	#0x144f
; block 0x144b
0x00144b:	b       	#0x189d
; block 0x144d
0x00144d:	b       	#0x188f
; block 0x144f
0x00144f:	movs    	r0, #0xff
0x001451:	str     	r0, [sp, #0x20]
0x001453:	str     	r0, [sp, #0x1c]
0x001455:	movs    	r0, #0xc8
0x001457:	str     	r0, [sp, #0x24]
0x001459:	movs    	r1, #0
0x00145b:	movs    	r2, #0
0x00145d:	str     	r2, [sp, #8]
0x00145f:	str     	r1, [sp]
0x001461:	str     	r1, [sp, #4]
0x001463:	movs    	r1, #0xe1
0x001465:	movs    	r2, #0x29
0x001467:	movs    	r0, #0xf1
0x001469:	movs    	r3, #0
0x00146b:	lsls    	r0, r0, #9
0x00146d:	bl      	#0x4c2d
; block 0x1471
0x001471:	str     	r0, [sp, #0x28]
0x001473:	movs    	r1, #0
0x001475:	movs    	r2, #0
0x001477:	str     	r2, [sp, #8]
0x001479:	str     	r1, [sp]
0x00147b:	str     	r1, [sp, #4]
0x00147d:	movs    	r1, #0xe1
0x00147f:	movs    	r2, #0x28
0x001481:	movs    	r0, #0xf1
0x001483:	movs    	r3, #0
0x001485:	lsls    	r0, r0, #9
0x001487:	bl      	#0x4c2d
; block 0x148b
0x00148b:	movs    	r1, #0
0x00148d:	movs    	r2, #0
0x00148f:	str     	r1, [sp]
0x001491:	str     	r1, [sp, #4]
0x001493:	str     	r0, [sp, #0x2c]
0x001495:	movs    	r0, #0xf1
0x001497:	movs    	r1, #0x56
0x001499:	str     	r2, [sp, #8]
0x00149b:	movs    	r3, #0
0x00149d:	lsls    	r0, r0, #9
0x00149f:	add     	r2, sp, #0x10
0x0014a1:	bl      	#0x4c2d
; block 0x14a5
0x0014a5:	b       	#0x1599
; block 0x14a7
0x0014a7:	b       	#0x159b
; block 0x14a9
0x0014a9:	b       	#0x14ab
; block 0x14ab
0x0014ab:	ldr     	r5, [pc, #0x1d8]
0x0014ad:	ldr     	r0, [sp, #0x64]
0x0014af:	add     	r5, sb
0x0014b1:	ldr     	r1, [r5, #0x2c]
0x0014b3:	ldr     	r0, [r1, r0]
0x0014b5:	cmp     	r0, #0
0x0014b7:	bne     	#0x14d7
; block 0x14b9
0x0014b9:	movs    	r1, #0
0x0014bb:	movs    	r2, #0
0x0014bd:	str     	r1, [sp]
0x0014bf:	str     	r1, [sp, #4]
0x0014c1:	movs    	r1, #0x42
0x0014c3:	str     	r2, [sp, #8]
0x0014c5:	movs    	r0, #0xf1
0x0014c7:	lsls    	r0, r0, #9
0x0014c9:	ldr     	r2, [sp, #0x34]
0x0014cb:	ldr     	r3, [sp, #0x78]
0x0014cd:	bl      	#0x4c2d
; block 0x14d1
0x0014d1:	ldr     	r1, [sp, #0x64]
0x0014d3:	ldr     	r2, [r5, #0x2c]
0x0014d5:	str     	r0, [r2, r1]
0x0014d7:	movs    	r1, #0
0x0014d9:	ldr     	r5, [pc, #0x1a8]
0x0014db:	str     	r1, [sp, #4]
0x0014dd:	movs    	r2, #0
0x0014df:	str     	r2, [sp, #8]
0x0014e1:	ldr     	r0, [sp, #0x64]
0x0014e3:	str     	r1, [sp]
0x0014e5:	add     	r5, sb
0x0014e7:	ldr     	r1, [r5, #0x2c]
0x0014e9:	movs    	r3, #4
0x0014eb:	ldr     	r2, [r1, r0]
0x0014ed:	movs    	r0, #0xf1
0x0014ef:	movs    	r1, #0x11
0x0014f1:	lsls    	r0, r0, #9
0x0014f3:	bl      	#0x4c2d
; block 0x14d7
0x0014d7:	movs    	r1, #0
0x0014d9:	ldr     	r5, [pc, #0x1a8]
0x0014db:	str     	r1, [sp, #4]
0x0014dd:	movs    	r2, #0
0x0014df:	str     	r2, [sp, #8]
0x0014e1:	ldr     	r0, [sp, #0x64]
0x0014e3:	str     	r1, [sp]
0x0014e5:	add     	r5, sb
0x0014e7:	ldr     	r1, [r5, #0x2c]
0x0014e9:	movs    	r3, #4
0x0014eb:	ldr     	r2, [r1, r0]
0x0014ed:	movs    	r0, #0xf1
0x0014ef:	movs    	r1, #0x11
0x0014f1:	lsls    	r0, r0, #9
0x0014f3:	bl      	#0x4c2d
; block 0x14f7
0x0014f7:	ldr     	r3, [sp, #0x6c]
0x0014f9:	movs    	r5, #0
0x0014fb:	cmp     	r0, #0
0x0014fd:	str     	r0, [sp, #0x30]
0x0014ff:	str     	r3, [sp, #0x2c]
0x001501:	ble     	#0x1599
; block 0x1503
0x001503:	ldr     	r1, [pc, #0x180]
0x001505:	ldr     	r0, [sp, #0x64]
0x001507:	add     	r1, sb
0x001509:	ldr     	r1, [r1, #0x2c]
0x00150b:	movs    	r2, #0
0x00150d:	ldr     	r0, [r1, r0]
0x00150f:	lsls    	r1, r5, #2
0x001511:	ldr     	r0, [r0, r1]
0x001513:	movs    	r1, #0
0x001515:	str     	r0, [sp, #0x28]
0x001517:	str     	r2, [sp, #8]
0x001519:	str     	r1, [sp]
0x00151b:	str     	r1, [sp, #4]
0x00151d:	movs    	r1, #0xe1
0x00151f:	movs    	r2, #0x28
0x001521:	movs    	r0, #0xf1
0x001523:	movs    	r3, #0
0x001525:	lsls    	r0, r0, #9
0x001527:	bl      	#0x4c2d
; block 0x152b
0x00152b:	str     	r0, [sp, #0x24]
0x00152d:	movs    	r1, #0
0x00152f:	movs    	r2, #0
0x001531:	str     	r2, [sp, #8]
0x001533:	str     	r1, [sp]
0x001535:	str     	r1, [sp, #4]
0x001537:	movs    	r1, #0xe1
0x001539:	movs    	r2, #0x29
0x00153b:	movs    	r0, #0xf1
0x00153d:	movs    	r3, #0
0x00153f:	lsls    	r0, r0, #9
0x001541:	bl      	#0x4c2d
; block 0x1545
0x001545:	adds    	r3, r0, #0
0x001547:	ldr     	r0, [sp, #0x24]
0x001549:	add     	r1, sp, #0x3c
0x00154b:	str     	r1, [sp, #4]
0x00154d:	add     	r2, sp, #0x38
0x00154f:	str     	r0, [sp]
0x001551:	movs    	r0, #0xf1
0x001553:	str     	r2, [sp, #8]
0x001555:	movs    	r1, #0x2a
0x001557:	lsls    	r0, r0, #9
0x001559:	ldr     	r2, [sp, #0x28]
0x00155b:	bl      	#0x4c2d
; block 0x155f
0x00155f:	ldr     	r0, [sp, #0x3c]
0x001561:	ldr     	r3, [sp, #0x2c]
0x001563:	subs    	r0, r6, r0
0x001565:	lsrs    	r1, r0, #0x1f
0x001567:	adds    	r0, r1, r0
0x001569:	asrs    	r0, r0, #1
0x00156b:	mov     	ip, r0
0x00156d:	ldr     	r0, [sp, #0x38]
0x00156f:	movs    	r1, #0
0x001571:	adds    	r0, #2
0x001573:	muls    	r0, r5, r0
0x001575:	str     	r1, [sp, #4]
0x001577:	adds    	r0, r0, r3
0x001579:	movs    	r2, #0
0x00157b:	str     	r0, [sp]
0x00157d:	movs    	r1, #0xff
0x00157f:	adds    	r1, #0x38
0x001581:	movs    	r0, #0xf1
0x001583:	str     	r2, [sp, #8]
0x001585:	add     	ip, r4
0x001587:	mov     	r3, ip
0x001589:	ldr     	r2, [sp, #0x28]
0x00158b:	lsls    	r0, r0, #9
0x00158d:	bl      	#0x4c2d
; block 0x1591
0x001591:	ldr     	r0, [sp, #0x30]
0x001593:	adds    	r5, #1
0x001595:	cmp     	r5, r0
0x001597:	blt     	#0x1503
; block 0x1599
0x001599:	b       	#0x187f
; block 0x159b
0x00159b:	ldr     	r1, [sp, #0x50]
0x00159d:	movs    	r2, #0
0x00159f:	str     	r2, [sp, #8]
0x0015a1:	adds    	r3, r5, #0
0x0015a3:	str     	r1, [sp, #4]
0x0015a5:	movs    	r1, #0x2f
0x0015a7:	adds    	r2, r4, #0
0x0015a9:	movs    	r0, #0xf1
0x0015ab:	lsls    	r0, r0, #9
0x0015ad:	str     	r6, [sp]
0x0015af:	bl      	#0x4c2d
; block 0x15b3
0x0015b3:	cmp     	r0, #1
0x0015b5:	bne     	#0x15db
; block 0x15b7
0x0015b7:	ldr     	r1, [pc, #0xcc]
0x0015b9:	add     	r1, sb
0x0015bb:	ldr     	r0, [r1, #0x10]
0x0015bd:	cmp     	r0, r7
0x0015bf:	bne     	#0x15d9
; block 0x15c1
0x0015c1:	ldr     	r2, [sp, #0x50]
0x0015c3:	adds    	r3, r4, #0
0x0015c5:	str     	r2, [sp, #8]
0x0015c7:	movs    	r2, #4
0x0015c9:	movs    	r1, #0x23
0x0015cb:	movs    	r0, #0xf1
0x0015cd:	lsls    	r0, r0, #9
0x0015cf:	str     	r5, [sp]
0x0015d1:	str     	r6, [sp, #4]
0x0015d3:	bl      	#0x4c2d
; block 0x15d7
0x0015d7:	b       	#0x15db
; block 0x15d9
0x0015d9:	str     	r7, [r1, #0x10]
0x0015db:	ldr     	r0, [sp, #0x34]
0x0015dd:	cmp     	r0, #0
0x0015df:	bne     	#0x16c5
; block 0x15db
0x0015db:	ldr     	r0, [sp, #0x34]
0x0015dd:	cmp     	r0, #0
0x0015df:	bne     	#0x16c5
; block 0x15e1
0x0015e1:	ldr     	r0, [pc, #0xac]
0x0015e3:	add     	r0, pc
0x0015e5:	str     	r0, [sp, #0x30]
0x0015e7:	ldr     	r0, [pc, #0x9c]
0x0015e9:	add     	r0, sb
0x0015eb:	ldr     	r0, [r0, #0x10]
0x0015ed:	cmp     	r0, r7
0x0015ef:	bne     	#0x1645
; block 0x15f1
0x0015f1:	movs    	r1, #0
0x0015f3:	movs    	r2, #0
0x0015f5:	str     	r2, [sp, #8]
0x0015f7:	str     	r1, [sp]
0x0015f9:	str     	r1, [sp, #4]
0x0015fb:	movs    	r1, #0xe1
0x0015fd:	movs    	r2, #0x27
0x0015ff:	movs    	r3, #0
0x001601:	movs    	r0, #0xf1
0x001603:	lsls    	r0, r0, #9
0x001605:	bl      	#0x4c2d
; block 0x1609
0x001609:	lsrs    	r1, r0, #0x1f
0x00160b:	adds    	r0, r1, r0
0x00160d:	asrs    	r0, r0, #1
0x00160f:	lsls    	r0, r0, #0x1f
0x001611:	bmi     	#0x1645
; block 0x1613
0x001613:	adds    	r0, r4, #5
0x001615:	str     	r0, [sp, #0x14]
0x001617:	ldr     	r0, [sp, #0x68]
0x001619:	movs    	r1, #0
0x00161b:	str     	r0, [sp, #0x18]
0x00161d:	ldr     	r0, [sp, #0x74]
0x00161f:	ldr     	r3, [sp, #0x78]
0x001621:	str     	r0, [sp, #0x20]
0x001623:	movs    	r0, #0xc8
0x001625:	str     	r0, [sp, #0x24]
0x001627:	movs    	r0, #0x64
0x001629:	str     	r0, [sp, #0x28]
0x00162b:	movs    	r2, #0
0x00162d:	str     	r0, [sp, #0x2c]
0x00162f:	str     	r1, [sp, #4]
0x001631:	str     	r1, [sp]
0x001633:	str     	r3, [sp, #0x1c]
0x001635:	movs    	r3, #0
0x001637:	movs    	r1, #0x1f
0x001639:	movs    	r0, #0xf1
0x00163b:	str     	r2, [sp, #8]
0x00163d:	add     	r2, sp, #0x14
0x00163f:	lsls    	r0, r0, #9
0x001641:	bl      	#0x4c2d
; block 0x1645
0x001645:	movs    	r1, #0
0x001647:	movs    	r2, #0
0x001649:	str     	r2, [sp, #8]
0x00164b:	str     	r1, [sp]
0x00164d:	str     	r1, [sp, #4]
0x00164f:	movs    	r1, #0xe1
0x001651:	movs    	r2, #0x28
0x001653:	movs    	r3, #0
0x001655:	movs    	r0, #0xf1
0x001657:	lsls    	r0, r0, #9
0x001659:	bl      	#0x4c2d
; block 0x165d
0x00165d:	movs    	r1, #0
0x00165f:	movs    	r2, #0
0x001661:	str     	r2, [sp, #8]
0x001663:	str     	r1, [sp]
0x001665:	str     	r1, [sp, #4]
0x001667:	str     	r0, [sp, #0x2c]
0x001669:	movs    	r0, #0xf1
0x00166b:	movs    	r1, #0xe1
0x00166d:	movs    	r2, #0x29
0x00166f:	movs    	r3, #0
0x001671:	lsls    	r0, r0, #9
0x001673:	bl      	#0x4c2d
; block 0x1677
0x001677:	adds    	r3, r0, #0
0x001679:	ldr     	r0, [sp, #0x2c]
0x00167b:	add     	r2, sp, #0x38
0x00167d:	add     	r1, sp, #0x3c
0x00167f:	str     	r0, [sp]
0x001681:	b       	#0x1695
; block 0x1695
0x001695:	str     	r1, [sp, #4]
0x001697:	movs    	r1, #0x2a
0x001699:	str     	r2, [sp, #8]
0x00169b:	movs    	r0, #0xf1
0x00169d:	lsls    	r0, r0, #9
0x00169f:	ldr     	r2, [sp, #0x30]
0x0016a1:	bl      	#0x4c2d
; block 0x16a5
0x0016a5:	ldr     	r0, [sp, #0x30]
0x0016a7:	str     	r0, [sp, #0x10]
0x0016a9:	ldr     	r0, [sp, #0x3c]
0x0016ab:	subs    	r0, r6, r0
0x0016ad:	lsrs    	r1, r0, #0x1f
0x0016af:	adds    	r0, r1, r0
0x0016b1:	asrs    	r0, r0, #1
0x0016b3:	adds    	r0, r0, r4
0x0016b5:	str     	r0, [sp, #0x14]
0x0016b7:	ldr     	r0, [sp, #0x50]
0x0016b9:	ldr     	r1, [sp, #0x38]
0x0016bb:	subs    	r0, r0, r1
0x0016bd:	lsrs    	r1, r0, #0x1f
0x0016bf:	adds    	r0, r1, r0
0x0016c1:	asrs    	r0, r0, #1
0x0016c3:	b       	#0x16c7
; block 0x16c5
0x0016c5:	b       	#0x1723
; block 0x16c7
0x0016c7:	adds    	r0, r0, r5
0x0016c9:	str     	r0, [sp, #0x18]
0x0016cb:	movs    	r0, #0xff
0x0016cd:	str     	r0, [sp, #0x20]
0x0016cf:	str     	r0, [sp, #0x1c]
0x0016d1:	movs    	r0, #0xc8
0x0016d3:	str     	r0, [sp, #0x24]
0x0016d5:	movs    	r1, #0
0x0016d7:	movs    	r2, #0
0x0016d9:	str     	r2, [sp, #8]
0x0016db:	str     	r1, [sp]
0x0016dd:	str     	r1, [sp, #4]
0x0016df:	movs    	r1, #0xe1
0x0016e1:	movs    	r2, #0x29
0x0016e3:	movs    	r0, #0xf1
0x0016e5:	movs    	r3, #0
0x0016e7:	lsls    	r0, r0, #9
0x0016e9:	bl      	#0x4c2d
; block 0x16ed
0x0016ed:	str     	r0, [sp, #0x28]
0x0016ef:	movs    	r1, #0
0x0016f1:	movs    	r2, #0
0x0016f3:	str     	r2, [sp, #8]
0x0016f5:	str     	r1, [sp]
0x0016f7:	str     	r1, [sp, #4]
0x0016f9:	movs    	r1, #0xe1
0x0016fb:	movs    	r2, #0x28
0x0016fd:	movs    	r0, #0xf1
0x0016ff:	movs    	r3, #0
0x001701:	lsls    	r0, r0, #9
0x001703:	bl      	#0x4c2d
; block 0x1707
0x001707:	movs    	r1, #0
0x001709:	movs    	r2, #0
0x00170b:	str     	r1, [sp]
0x00170d:	str     	r1, [sp, #4]
0x00170f:	str     	r0, [sp, #0x2c]
0x001711:	movs    	r0, #0xf1
0x001713:	movs    	r1, #0x56
0x001715:	str     	r2, [sp, #8]
0x001717:	movs    	r3, #0
0x001719:	lsls    	r0, r0, #9
0x00171b:	add     	r2, sp, #0x10
0x00171d:	bl      	#0x4c2d
; block 0x1721
0x001721:	b       	#0x187f
; block 0x1723
0x001723:	ldr     	r0, [pc, #0x218]
0x001725:	add     	r0, pc
0x001727:	str     	r0, [sp, #0x30]
0x001729:	adds    	r0, r4, #5
0x00172b:	str     	r0, [sp, #0x60]
0x00172d:	str     	r0, [sp, #0x14]
0x00172f:	ldr     	r0, [sp, #0x68]
0x001731:	movs    	r1, #0
0x001733:	str     	r0, [sp, #0x18]
0x001735:	str     	r0, [sp, #0x5c]
0x001737:	ldr     	r0, [sp, #0x74]
0x001739:	ldr     	r3, [sp, #0x78]
0x00173b:	str     	r0, [sp, #0x20]
0x00173d:	movs    	r0, #0x64
0x00173f:	str     	r0, [sp, #0x24]
0x001741:	str     	r0, [sp, #0x28]
0x001743:	movs    	r2, #0
0x001745:	str     	r1, [sp, #4]
0x001747:	str     	r0, [sp, #0x2c]
0x001749:	str     	r1, [sp]
0x00174b:	str     	r3, [sp, #0x1c]
0x00174d:	movs    	r3, #0
0x00174f:	movs    	r1, #0x1f
0x001751:	movs    	r0, #0xf1
0x001753:	str     	r2, [sp, #8]
0x001755:	add     	r2, sp, #0x14
0x001757:	lsls    	r0, r0, #9
0x001759:	bl      	#0x4c2d
; block 0x175d
0x00175d:	ldr     	r0, [pc, #0x1e0]
0x00175f:	add     	r0, sb
0x001761:	ldr     	r0, [r0, #0x10]
0x001763:	cmp     	r0, r7
0x001765:	bne     	#0x17bb
; block 0x1767
0x001767:	movs    	r1, #0
0x001769:	movs    	r2, #0
0x00176b:	str     	r2, [sp, #8]
0x00176d:	str     	r1, [sp]
0x00176f:	str     	r1, [sp, #4]
0x001771:	movs    	r1, #0xe1
0x001773:	movs    	r2, #0x27
0x001775:	movs    	r3, #0
0x001777:	movs    	r0, #0xf1
0x001779:	lsls    	r0, r0, #9
0x00177b:	bl      	#0x4c2d
; block 0x177f
0x00177f:	lsrs    	r1, r0, #0x1f
0x001781:	adds    	r0, r1, r0
0x001783:	asrs    	r0, r0, #1
0x001785:	lsls    	r0, r0, #0x1f
0x001787:	bmi     	#0x17bb
; block 0x1789
0x001789:	ldr     	r0, [sp, #0x60]
0x00178b:	movs    	r1, #0
0x00178d:	str     	r0, [sp, #0x14]
0x00178f:	ldr     	r0, [sp, #0x5c]
0x001791:	movs    	r2, #0
0x001793:	str     	r0, [sp, #0x18]
0x001795:	ldr     	r0, [sp, #0x74]
0x001797:	ldr     	r3, [sp, #0x78]
0x001799:	str     	r0, [sp, #0x20]
0x00179b:	movs    	r0, #0xc8
0x00179d:	str     	r0, [sp, #0x24]
0x00179f:	movs    	r0, #0x64
0x0017a1:	str     	r0, [sp, #0x28]
0x0017a3:	str     	r0, [sp, #0x2c]
0x0017a5:	str     	r1, [sp, #4]
0x0017a7:	str     	r1, [sp]
0x0017a9:	str     	r3, [sp, #0x1c]
0x0017ab:	movs    	r3, #0
0x0017ad:	movs    	r1, #0x1f
0x0017af:	movs    	r0, #0xf1
0x0017b1:	str     	r2, [sp, #8]
0x0017b3:	add     	r2, sp, #0x14
0x0017b5:	lsls    	r0, r0, #9
0x0017b7:	bl      	#0x4c2d
; block 0x17bb
0x0017bb:	movs    	r1, #0
0x0017bd:	movs    	r2, #0
0x0017bf:	str     	r2, [sp, #8]
0x0017c1:	str     	r1, [sp]
0x0017c3:	str     	r1, [sp, #4]
0x0017c5:	movs    	r1, #0xe1
0x0017c7:	movs    	r2, #0x28
0x0017c9:	movs    	r3, #0
0x0017cb:	movs    	r0, #0xf1
0x0017cd:	lsls    	r0, r0, #9
0x0017cf:	bl      	#0x4c2d
; block 0x17d3
0x0017d3:	movs    	r1, #0
0x0017d5:	movs    	r2, #0
0x0017d7:	str     	r2, [sp, #8]
0x0017d9:	str     	r1, [sp]
0x0017db:	str     	r1, [sp, #4]
0x0017dd:	str     	r0, [sp, #0x2c]
0x0017df:	movs    	r0, #0xf1
0x0017e1:	movs    	r1, #0xe1
0x0017e3:	movs    	r2, #0x29
0x0017e5:	movs    	r3, #0
0x0017e7:	lsls    	r0, r0, #9
0x0017e9:	bl      	#0x4c2d
; block 0x17ed
0x0017ed:	adds    	r3, r0, #0
0x0017ef:	ldr     	r0, [sp, #0x2c]
0x0017f1:	add     	r1, sp, #0x3c
0x0017f3:	str     	r1, [sp, #4]
0x0017f5:	add     	r2, sp, #0x38
0x0017f7:	str     	r0, [sp]
0x0017f9:	movs    	r0, #0xf1
0x0017fb:	str     	r2, [sp, #8]
0x0017fd:	movs    	r1, #0x2a
0x0017ff:	lsls    	r0, r0, #9
0x001801:	ldr     	r2, [sp, #0x30]
0x001803:	bl      	#0x4c2d
; block 0x1807
0x001807:	ldr     	r0, [sp, #0x30]
0x001809:	movs    	r2, #0
0x00180b:	str     	r0, [sp, #0x10]
0x00180d:	ldr     	r0, [sp, #0x3c]
0x00180f:	str     	r2, [sp, #8]
0x001811:	subs    	r0, r6, r0
0x001813:	lsrs    	r1, r0, #0x1f
0x001815:	adds    	r0, r1, r0
0x001817:	asrs    	r0, r0, #1
0x001819:	adds    	r0, r0, r4
0x00181b:	str     	r0, [sp, #0x14]
0x00181d:	ldr     	r0, [sp, #0x50]
0x00181f:	ldr     	r1, [sp, #0x38]
0x001821:	movs    	r2, #0x29
0x001823:	subs    	r0, r0, r1
0x001825:	lsrs    	r1, r0, #0x1f
0x001827:	adds    	r0, r1, r0
0x001829:	asrs    	r0, r0, #1
0x00182b:	adds    	r0, r0, r5
0x00182d:	str     	r0, [sp, #0x18]
0x00182f:	movs    	r0, #0xff
0x001831:	str     	r0, [sp, #0x20]
0x001833:	str     	r0, [sp, #0x1c]
0x001835:	movs    	r0, #0xc8
0x001837:	str     	r0, [sp, #0x24]
0x001839:	movs    	r1, #0
0x00183b:	str     	r1, [sp]
0x00183d:	str     	r1, [sp, #4]
0x00183f:	movs    	r1, #0xe1
0x001841:	movs    	r0, #0xf1
0x001843:	movs    	r3, #0
0x001845:	lsls    	r0, r0, #9
0x001847:	bl      	#0x4c2d
; block 0x184b
0x00184b:	str     	r0, [sp, #0x28]
0x00184d:	movs    	r1, #0
0x00184f:	movs    	r2, #0
0x001851:	str     	r2, [sp, #8]
0x001853:	str     	r1, [sp]
0x001855:	str     	r1, [sp, #4]
0x001857:	movs    	r1, #0xe1
0x001859:	movs    	r2, #0x28
0x00185b:	movs    	r0, #0xf1
0x00185d:	movs    	r3, #0
0x00185f:	lsls    	r0, r0, #9
0x001861:	bl      	#0x4c2d
; block 0x1865
0x001865:	movs    	r1, #0
0x001867:	movs    	r2, #0
0x001869:	str     	r1, [sp]
0x00186b:	str     	r1, [sp, #4]
0x00186d:	str     	r0, [sp, #0x2c]
0x00186f:	movs    	r0, #0xf1
0x001871:	movs    	r1, #0x56
0x001873:	str     	r2, [sp, #8]
0x001875:	movs    	r3, #0
0x001877:	lsls    	r0, r0, #9
0x001879:	add     	r2, sp, #0x10
0x00187b:	bl      	#0x4c2d
; block 0x187f
0x00187f:	ldr     	r0, [sp, #0x40]
0x001881:	ldr     	r1, [sp, #0x58]
0x001883:	adds    	r0, #1
0x001885:	adds    	r7, #1
0x001887:	cmp     	r0, r1
0x001889:	str     	r0, [sp, #0x40]
0x00188b:	bge     	#0x188f
; block 0x188d
0x00188d:	b       	#0x1393
; block 0x188f
0x00188f:	ldr     	r0, [sp, #0x44]
0x001891:	ldr     	r1, [sp, #0x54]
0x001893:	adds    	r0, #1
0x001895:	str     	r0, [sp, #0x44]
0x001897:	cmp     	r0, r1
0x001899:	bge     	#0x189d
; block 0x189b
0x00189b:	b       	#0x1373
; block 0x189d
0x00189d:	ldr     	r0, [pc, #0xa0]
0x00189f:	movs    	r3, #2
0x0018a1:	add     	r0, sb
0x0018a3:	ldrsb   	r1, [r0, r3]
0x0018a5:	movs    	r0, #1
0x0018a7:	cmp     	r1, #0
0x0018a9:	beq     	#0x18db
; block 0x18ab
0x0018ab:	ldr     	r1, [pc, #0x98]
0x0018ad:	add     	r1, pc
0x0018af:	str     	r1, [sp, #0x2c]
0x0018b1:	movs    	r1, #0xc8
0x0018b3:	movs    	r5, #0
0x0018b5:	str     	r1, [sp, #0x30]
0x0018b7:	str     	r5, [sp, #0x34]
0x0018b9:	str     	r5, [sp, #0x38]
0x0018bb:	add     	r3, sp, #0x20
0x0018bd:	strb    	r0, [r3, #0x1c]
0x0018bf:	strb    	r5, [r3, #0x1d]
0x0018c1:	movs    	r1, #0
0x0018c3:	movs    	r2, #0
0x0018c5:	str     	r1, [sp]
0x0018c7:	str     	r1, [sp, #4]
0x0018c9:	movs    	r1, #0x41
0x0018cb:	str     	r2, [sp, #8]
0x0018cd:	adds    	r3, r5, #0
0x0018cf:	movs    	r0, #0xf1
0x0018d1:	lsls    	r0, r0, #9
0x0018d3:	add     	r2, sp, #0x2c
0x0018d5:	bl      	#0x4c2d
; block 0x18d9
0x0018d9:	b       	#0x1909
; block 0x18db
0x0018db:	ldr     	r1, [pc, #0x6c]
0x0018dd:	add     	r1, pc
0x0018df:	str     	r1, [sp, #0x2c]
0x0018e1:	movs    	r1, #0xc8
0x0018e3:	movs    	r5, #0
0x0018e5:	str     	r1, [sp, #0x30]
0x0018e7:	str     	r5, [sp, #0x34]
0x0018e9:	str     	r5, [sp, #0x38]
0x0018eb:	add     	r3, sp, #0x20
0x0018ed:	strb    	r0, [r3, #0x1c]
0x0018ef:	strb    	r5, [r3, #0x1d]
0x0018f1:	movs    	r1, #0
0x0018f3:	movs    	r2, #0
0x0018f5:	str     	r1, [sp]
0x0018f7:	str     	r1, [sp, #4]
0x0018f9:	movs    	r1, #0x41
0x0018fb:	str     	r2, [sp, #8]
0x0018fd:	adds    	r3, r5, #0
0x0018ff:	movs    	r0, #0xf1
0x001901:	lsls    	r0, r0, #9
0x001903:	add     	r2, sp, #0x2c
0x001905:	bl      	#0x4c2d
; block 0x1909
0x001909:	ldr     	r0, [pc, #0x40]
0x00190b:	add     	r0, pc
0x00190d:	movs    	r1, #0xc8
0x00190f:	movs    	r5, #0
0x001911:	str     	r1, [sp, #0x30]
0x001913:	str     	r0, [sp, #0x2c]
0x001915:	str     	r5, [sp, #0x34]
0x001917:	str     	r5, [sp, #0x38]
0x001919:	add     	r3, sp, #0x20
0x00191b:	strb    	r5, [r3, #0x1c]
0x00191d:	strb    	r5, [r3, #0x1d]
0x00191f:	movs    	r1, #0
0x001921:	movs    	r2, #0
0x001923:	str     	r1, [sp]
0x001925:	str     	r1, [sp, #4]
0x001927:	movs    	r1, #0x41
0x001929:	str     	r2, [sp, #8]
0x00192b:	adds    	r3, r5, #0
0x00192d:	movs    	r0, #0xf1
0x00192f:	lsls    	r0, r0, #9
0x001931:	add     	r2, sp, #0x2c
0x001933:	bl      	#0x4c2d
; block 0x1937
0x001937:	add     	sp, #0x7c
0x001939:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_1955 @ 0x1955 offset=0x1954 size=1924 blocks=83 cc=71 =====
; block 0x1955
0x001955:	movs    	r1, #0
0x001957:	str     	r1, [sp]
0x001959:	str     	r1, [sp, #4]
0x00195b:	movs    	r7, #0xf1
0x00195d:	movs    	r5, #0
0x00195f:	movs    	r2, #0
0x001961:	adds    	r3, r5, #0
0x001963:	lsls    	r7, r7, #9
0x001965:	movs    	r1, #0x1c
0x001967:	adds    	r0, r7, #0
0x001969:	str     	r2, [sp, #8]
0x00196b:	bl      	#0x4c2d
; block 0x196f
0x00196f:	adds    	r4, r0, #0
0x001971:	movs    	r0, #0x19
0x001973:	str     	r0, [sp, #0x38]
0x001975:	movs    	r1, #0
0x001977:	movs    	r0, #0x46
0x001979:	str     	r0, [sp, #0x34]
0x00197b:	str     	r1, [sp]
0x00197d:	str     	r1, [sp, #4]
0x00197f:	movs    	r1, #0xff
0x001981:	movs    	r0, #0x19
0x001983:	movs    	r2, #0
0x001985:	str     	r0, [sp, #0x30]
0x001987:	adds    	r1, #0x26
0x001989:	movs    	r6, #0x11
0x00198b:	adds    	r3, r5, #0
0x00198d:	adds    	r0, r7, #0
0x00198f:	str     	r2, [sp, #8]
0x001991:	bl      	#0x4c2d
; block 0x1995
0x001995:	movs    	r1, #0
0x001997:	movs    	r2, #0
0x001999:	str     	r2, [sp, #8]
0x00199b:	str     	r1, [sp]
0x00199d:	str     	r1, [sp, #4]
0x00199f:	movs    	r1, #0xe1
0x0019a1:	movs    	r2, #0xed
0x0019a3:	adds    	r3, r5, #0
0x0019a5:	adds    	r0, r7, #0
0x0019a7:	bl      	#0x4c2d
; block 0x19ab
0x0019ab:	cmp     	r0, #0
0x0019ad:	ble     	#0x1a93
; block 0x19af
0x0019af:	movs    	r1, #0
0x0019b1:	str     	r1, [sp]
0x0019b3:	str     	r1, [sp, #4]
0x0019b5:	movs    	r1, #0xff
0x0019b7:	movs    	r2, #0
0x0019b9:	adds    	r1, #0x25
0x0019bb:	adds    	r3, r5, #0
0x0019bd:	adds    	r0, r7, #0
0x0019bf:	str     	r2, [sp, #8]
0x0019c1:	bl      	#0x4c2d
; block 0x19c5
0x0019c5:	movs    	r2, #0
0x0019c7:	movs    	r1, #0
0x0019c9:	movs    	r0, #0
0x0019cb:	bl      	#0x4bdd
; block 0x19cf
0x0019cf:	movs    	r1, #0
0x0019d1:	str     	r1, [sp]
0x0019d3:	str     	r1, [sp, #4]
0x0019d5:	movs    	r2, #0
0x0019d7:	movs    	r1, #0x1c
0x0019d9:	adds    	r3, r5, #0
0x0019db:	adds    	r0, r7, #0
0x0019dd:	str     	r2, [sp, #8]
0x0019df:	bl      	#0x4c2d
; block 0x19e3
0x0019e3:	ldr     	r1, [sp, #0x38]
0x0019e5:	movs    	r2, #0
0x0019e7:	str     	r2, [sp, #8]
0x0019e9:	str     	r1, [sp, #4]
0x0019eb:	movs    	r1, #0x32
0x0019ed:	adds    	r2, r5, #0
0x0019ef:	str     	r0, [sp]
0x0019f1:	adds    	r3, r5, #0
0x0019f3:	adds    	r0, r7, #0
0x0019f5:	bl      	#0x4c2d
; block 0x19f9
0x0019f9:	movs    	r2, #0
0x0019fb:	str     	r2, [sp, #8]
0x0019fd:	movs    	r1, #0
0x0019ff:	ldr     	r0, [pc, #0x3e0]
0x001a01:	ldr     	r2, [pc, #0x3e0]
0x001a03:	str     	r1, [sp]
0x001a05:	str     	r1, [sp, #4]
0x001a07:	add     	r0, sb
0x001a09:	add     	r2, pc
0x001a0b:	movs    	r1, #0x2d
0x001a0d:	ldr     	r3, [r0, #0x5c]
0x001a0f:	adds    	r0, r7, #0
0x001a11:	bl      	#0x4c2d
; block 0x1a15
0x001a15:	movs    	r1, #0
0x001a17:	adds    	r7, r0, #0
0x001a19:	movs    	r2, #0
0x001a1b:	str     	r2, [sp, #8]
0x001a1d:	str     	r1, [sp]
0x001a1f:	str     	r1, [sp, #4]
0x001a21:	movs    	r1, #0xe1
0x001a23:	movs    	r2, #0x28
0x001a25:	movs    	r0, #0xf1
0x001a27:	adds    	r3, r5, #0
0x001a29:	lsls    	r0, r0, #9
0x001a2b:	bl      	#0x4c2d
; block 0x1a2f
0x001a2f:	movs    	r1, #0
0x001a31:	movs    	r2, #0
0x001a33:	str     	r2, [sp, #8]
0x001a35:	str     	r1, [sp]
0x001a37:	str     	r1, [sp, #4]
0x001a39:	str     	r0, [sp, #0x2c]
0x001a3b:	movs    	r0, #0xf1
0x001a3d:	movs    	r1, #0xe1
0x001a3f:	movs    	r2, #0x29
0x001a41:	adds    	r3, r5, #0
0x001a43:	lsls    	r0, r0, #9
0x001a45:	bl      	#0x4c2d
; block 0x1a49
0x001a49:	adds    	r3, r0, #0
0x001a4b:	ldr     	r0, [sp, #0x2c]
0x001a4d:	add     	r2, sp, #0x3c
0x001a4f:	add     	r1, sp, #0x40
0x001a51:	str     	r1, [sp, #4]
0x001a53:	str     	r2, [sp, #8]
0x001a55:	str     	r0, [sp]
0x001a57:	movs    	r0, #0xf1
0x001a59:	adds    	r2, r7, #0
0x001a5b:	movs    	r1, #0x2a
0x001a5d:	lsls    	r0, r0, #9
0x001a5f:	bl      	#0x4c2d
; block 0x1a63
0x001a63:	movs    	r1, #0
0x001a65:	str     	r1, [sp]
0x001a67:	str     	r1, [sp, #4]
0x001a69:	movs    	r2, #0
0x001a6b:	movs    	r1, #0x1c
0x001a6d:	adds    	r3, r5, #0
0x001a6f:	movs    	r0, #0xf1
0x001a71:	lsls    	r0, r0, #9
0x001a73:	str     	r2, [sp, #8]
0x001a75:	str     	r7, [sp, #0x10]
0x001a77:	bl      	#0x4c2d
; block 0x1a7b
0x001a7b:	ldr     	r1, [sp, #0x40]
0x001a7d:	subs    	r0, r0, r1
0x001a7f:	asrs    	r0, r0, #1
0x001a81:	str     	r0, [sp, #0x14]
0x001a83:	ldr     	r0, [sp, #0x38]
0x001a85:	ldr     	r1, [sp, #0x3c]
0x001a87:	subs    	r0, r0, r1
0x001a89:	asrs    	r0, r0, #1
0x001a8b:	str     	r0, [sp, #0x18]
0x001a8d:	movs    	r0, #0xff
0x001a8f:	str     	r0, [sp, #0x1c]
0x001a91:	b       	#0x1a95
; block 0x1a93
0x001a93:	b       	#0x20e1
; block 0x1a95
0x001a95:	str     	r0, [sp, #0x20]
0x001a97:	movs    	r0, #0xc8
0x001a99:	str     	r0, [sp, #0x24]
0x001a9b:	movs    	r1, #0
0x001a9d:	movs    	r2, #0
0x001a9f:	str     	r2, [sp, #8]
0x001aa1:	str     	r1, [sp]
0x001aa3:	str     	r1, [sp, #4]
0x001aa5:	movs    	r1, #0xe1
0x001aa7:	movs    	r2, #0x29
0x001aa9:	movs    	r0, #0xf1
0x001aab:	adds    	r3, r5, #0
0x001aad:	lsls    	r0, r0, #9
0x001aaf:	bl      	#0x4c2d
; block 0x1ab3
0x001ab3:	str     	r0, [sp, #0x28]
0x001ab5:	movs    	r1, #0
0x001ab7:	movs    	r2, #0
0x001ab9:	str     	r2, [sp, #8]
0x001abb:	str     	r1, [sp]
0x001abd:	str     	r1, [sp, #4]
0x001abf:	movs    	r1, #0xe1
0x001ac1:	movs    	r2, #0x28
0x001ac3:	movs    	r0, #0xf1
0x001ac5:	adds    	r3, r5, #0
0x001ac7:	lsls    	r0, r0, #9
0x001ac9:	bl      	#0x4c2d
; block 0x1acd
0x001acd:	movs    	r1, #0
0x001acf:	movs    	r2, #0
0x001ad1:	str     	r1, [sp]
0x001ad3:	str     	r1, [sp, #4]
0x001ad5:	str     	r0, [sp, #0x2c]
0x001ad7:	movs    	r0, #0xf1
0x001ad9:	movs    	r1, #0x56
0x001adb:	str     	r2, [sp, #8]
0x001add:	adds    	r3, r5, #0
0x001adf:	lsls    	r0, r0, #9
0x001ae1:	add     	r2, sp, #0x10
0x001ae3:	bl      	#0x4c2d
; block 0x1ae7
0x001ae7:	ldr     	r1, [sp, #0x34]
0x001ae9:	movs    	r7, #0x19
0x001aeb:	movs    	r2, #0
0x001aed:	str     	r2, [sp, #8]
0x001aef:	adds    	r3, r7, #0
0x001af1:	str     	r1, [sp, #4]
0x001af3:	movs    	r1, #0x2e
0x001af5:	adds    	r2, r5, #0
0x001af7:	movs    	r0, #0xf1
0x001af9:	lsls    	r0, r0, #9
0x001afb:	str     	r4, [sp]
0x001afd:	bl      	#0x4c2d
; block 0x1b01
0x001b01:	movs    	r1, #0
0x001b03:	movs    	r2, #0
0x001b05:	str     	r2, [sp, #8]
0x001b07:	str     	r1, [sp]
0x001b09:	str     	r1, [sp, #4]
0x001b0b:	movs    	r1, #0xe1
0x001b0d:	movs    	r2, #0x58
0x001b0f:	adds    	r3, r5, #0
0x001b11:	movs    	r0, #0xf1
0x001b13:	lsls    	r0, r0, #9
0x001b15:	bl      	#0x4c2d
; block 0x1b19
0x001b19:	cmp     	r0, #0
0x001b1b:	bne     	#0x1b6d
; block 0x1b1d
0x001b1d:	ldr     	r0, [pc, #0x2c0]
0x001b1f:	movs    	r1, #0
0x001b21:	add     	r0, sb
0x001b23:	ldr     	r5, [r0, #0x60]
0x001b25:	adds    	r3, r4, #0
0x001b27:	movs    	r2, #0
0x001b29:	str     	r2, [sp, #8]
0x001b2b:	subs    	r3, #0x14
0x001b2d:	str     	r1, [sp]
0x001b2f:	str     	r1, [sp, #4]
0x001b31:	movs    	r1, #0x42
0x001b33:	adds    	r2, r5, #0
0x001b35:	movs    	r0, #0xf1
0x001b37:	lsls    	r0, r0, #9
0x001b39:	bl      	#0x4c2d
; block 0x1b3d
0x001b3d:	movs    	r1, #0
0x001b3f:	movs    	r2, #0
0x001b41:	str     	r2, [sp, #8]
0x001b43:	str     	r1, [sp]
0x001b45:	str     	r1, [sp, #4]
0x001b47:	adds    	r3, r0, #0
0x001b49:	movs    	r0, #0xf1
0x001b4b:	movs    	r1, #0x14
0x001b4d:	movs    	r2, #0x58
0x001b4f:	lsls    	r0, r0, #9
0x001b51:	bl      	#0x4c2d
; block 0x1b55
0x001b55:	movs    	r1, #0
0x001b57:	movs    	r2, #0
0x001b59:	str     	r2, [sp, #8]
0x001b5b:	str     	r1, [sp]
0x001b5d:	str     	r1, [sp, #4]
0x001b5f:	movs    	r1, #0x14
0x001b61:	movs    	r2, #0x7b
0x001b63:	movs    	r3, #0
0x001b65:	movs    	r0, #0xf1
0x001b67:	lsls    	r0, r0, #9
0x001b69:	bl      	#0x4c2d
; block 0x1b6d
0x001b6d:	movs    	r1, #0
0x001b6f:	movs    	r2, #0
0x001b71:	str     	r2, [sp, #8]
0x001b73:	str     	r1, [sp]
0x001b75:	str     	r1, [sp, #4]
0x001b77:	movs    	r5, #0
0x001b79:	adds    	r3, r5, #0
0x001b7b:	movs    	r1, #0xe1
0x001b7d:	movs    	r2, #0x58
0x001b7f:	movs    	r0, #0xf1
0x001b81:	lsls    	r0, r0, #9
0x001b83:	bl      	#0x4c2d
; block 0x1b87
0x001b87:	movs    	r1, #0
0x001b89:	movs    	r2, #0
0x001b8b:	str     	r2, [sp, #8]
0x001b8d:	str     	r1, [sp]
0x001b8f:	str     	r1, [sp, #4]
0x001b91:	str     	r0, [sp, #0x14]
0x001b93:	movs    	r0, #0xf1
0x001b95:	movs    	r1, #0xe1
0x001b97:	movs    	r2, #0x7b
0x001b99:	adds    	r3, r5, #0
0x001b9b:	lsls    	r0, r0, #9
0x001b9d:	bl      	#0x4c2d
; block 0x1ba1
0x001ba1:	str     	r0, [sp, #0x18]
0x001ba3:	movs    	r0, #5
0x001ba5:	str     	r0, [sp, #0x1c]
0x001ba7:	adds    	r0, r4, #0
0x001ba9:	subs    	r0, #0x14
0x001bab:	str     	r0, [sp, #0x24]
0x001bad:	movs    	r0, #0x3c
0x001baf:	str     	r0, [sp, #0x28]
0x001bb1:	str     	r7, [sp, #0x20]
0x001bb3:	add     	r3, sp, #0x20
0x001bb5:	strb    	r5, [r3, #0xc]
0x001bb7:	movs    	r0, #1
0x001bb9:	strb    	r0, [r3, #0xd]
0x001bbb:	movs    	r1, #0
0x001bbd:	movs    	r2, #0
0x001bbf:	str     	r1, [sp]
0x001bc1:	str     	r1, [sp, #4]
0x001bc3:	movs    	r1, #0x43
0x001bc5:	str     	r2, [sp, #8]
0x001bc7:	movs    	r0, #0xf1
0x001bc9:	adds    	r3, r5, #0
0x001bcb:	lsls    	r0, r0, #9
0x001bcd:	add     	r2, sp, #0x14
0x001bcf:	bl      	#0x4c2d
; block 0x1bd3
0x001bd3:	ldr     	r1, [sp, #0x30]
0x001bd5:	movs    	r2, #0
0x001bd7:	str     	r2, [sp, #8]
0x001bd9:	str     	r1, [sp, #4]
0x001bdb:	movs    	r1, #0x31
0x001bdd:	adds    	r2, r5, #0
0x001bdf:	movs    	r3, #0x5f
0x001be1:	movs    	r0, #0xf1
0x001be3:	lsls    	r0, r0, #9
0x001be5:	str     	r4, [sp]
0x001be7:	bl      	#0x4c2d
; block 0x1beb
0x001beb:	ldr     	r4, [pc, #0x1fc]
0x001bed:	add     	r4, pc
0x001bef:	movs    	r1, #0
0x001bf1:	movs    	r2, #0
0x001bf3:	str     	r2, [sp, #8]
0x001bf5:	str     	r1, [sp]
0x001bf7:	str     	r1, [sp, #4]
0x001bf9:	movs    	r1, #0xe1
0x001bfb:	movs    	r2, #0x28
0x001bfd:	adds    	r3, r5, #0
0x001bff:	movs    	r0, #0xf1
0x001c01:	lsls    	r0, r0, #9
0x001c03:	bl      	#0x4c2d
; block 0x1c07
0x001c07:	movs    	r1, #0
0x001c09:	adds    	r7, r0, #0
0x001c0b:	movs    	r2, #0
0x001c0d:	str     	r2, [sp, #8]
0x001c0f:	str     	r1, [sp]
0x001c11:	str     	r1, [sp, #4]
0x001c13:	movs    	r1, #0xe1
0x001c15:	movs    	r2, #0x29
0x001c17:	movs    	r0, #0xf1
0x001c19:	adds    	r3, r5, #0
0x001c1b:	lsls    	r0, r0, #9
0x001c1d:	bl      	#0x4c2d
; block 0x1c21
0x001c21:	adds    	r3, r0, #0
0x001c23:	add     	r2, sp, #0x3c
0x001c25:	add     	r1, sp, #0x40
0x001c27:	str     	r1, [sp, #4]
0x001c29:	str     	r2, [sp, #8]
0x001c2b:	adds    	r2, r4, #0
0x001c2d:	movs    	r1, #0x2a
0x001c2f:	movs    	r0, #0xf1
0x001c31:	lsls    	r0, r0, #9
0x001c33:	str     	r7, [sp]
0x001c35:	bl      	#0x4c2d
; block 0x1c39
0x001c39:	movs    	r1, #0
0x001c3b:	str     	r1, [sp]
0x001c3d:	str     	r1, [sp, #4]
0x001c3f:	movs    	r2, #0
0x001c41:	movs    	r1, #0x1c
0x001c43:	adds    	r3, r5, #0
0x001c45:	movs    	r0, #0xf1
0x001c47:	lsls    	r0, r0, #9
0x001c49:	str     	r2, [sp, #8]
0x001c4b:	str     	r4, [sp, #0x10]
0x001c4d:	bl      	#0x4c2d
; block 0x1c51
0x001c51:	ldr     	r1, [sp, #0x40]
0x001c53:	movs    	r4, #0xc8
0x001c55:	subs    	r0, r0, r1
0x001c57:	asrs    	r0, r0, #1
0x001c59:	str     	r0, [sp, #0x14]
0x001c5b:	ldr     	r0, [sp, #0x30]
0x001c5d:	ldr     	r1, [sp, #0x3c]
0x001c5f:	str     	r4, [sp, #0x24]
0x001c61:	subs    	r0, r0, r1
0x001c63:	asrs    	r0, r0, #1
0x001c65:	adds    	r0, #0x5f
0x001c67:	str     	r0, [sp, #0x18]
0x001c69:	movs    	r0, #0xff
0x001c6b:	str     	r0, [sp, #0x20]
0x001c6d:	movs    	r1, #0
0x001c6f:	movs    	r2, #0
0x001c71:	str     	r2, [sp, #8]
0x001c73:	str     	r1, [sp]
0x001c75:	str     	r1, [sp, #4]
0x001c77:	str     	r0, [sp, #0x1c]
0x001c79:	movs    	r0, #0xf1
0x001c7b:	movs    	r1, #0xe1
0x001c7d:	movs    	r2, #0x29
0x001c7f:	adds    	r3, r5, #0
0x001c81:	lsls    	r0, r0, #9
0x001c83:	bl      	#0x4c2d
; block 0x1c87
0x001c87:	str     	r0, [sp, #0x28]
0x001c89:	movs    	r1, #0
0x001c8b:	movs    	r2, #0
0x001c8d:	str     	r2, [sp, #8]
0x001c8f:	str     	r1, [sp]
0x001c91:	str     	r1, [sp, #4]
0x001c93:	movs    	r1, #0xe1
0x001c95:	movs    	r2, #0x28
0x001c97:	movs    	r0, #0xf1
0x001c99:	adds    	r3, r5, #0
0x001c9b:	lsls    	r0, r0, #9
0x001c9d:	bl      	#0x4c2d
; block 0x1ca1
0x001ca1:	movs    	r1, #0
0x001ca3:	movs    	r2, #0
0x001ca5:	str     	r1, [sp]
0x001ca7:	str     	r1, [sp, #4]
0x001ca9:	str     	r0, [sp, #0x2c]
0x001cab:	movs    	r0, #0xf1
0x001cad:	movs    	r1, #0x56
0x001caf:	str     	r2, [sp, #8]
0x001cb1:	adds    	r3, r5, #0
0x001cb3:	lsls    	r0, r0, #9
0x001cb5:	add     	r2, sp, #0x10
0x001cb7:	bl      	#0x4c2d
; block 0x1cbb
0x001cbb:	movs    	r1, #0
0x001cbd:	str     	r1, [sp]
0x001cbf:	str     	r1, [sp, #4]
0x001cc1:	movs    	r2, #0
0x001cc3:	movs    	r1, #0x1d
0x001cc5:	movs    	r7, #0x78
0x001cc7:	adds    	r3, r5, #0
0x001cc9:	movs    	r0, #0xf1
0x001ccb:	lsls    	r0, r0, #9
0x001ccd:	str     	r2, [sp, #8]
0x001ccf:	bl      	#0x4c2d
; block 0x1cd3
0x001cd3:	movs    	r1, #0
0x001cd5:	subs    	r4, r0, r7
0x001cd7:	str     	r1, [sp]
0x001cd9:	str     	r1, [sp, #4]
0x001cdb:	movs    	r2, #0
0x001cdd:	movs    	r1, #0x1c
0x001cdf:	movs    	r0, #0xf1
0x001ce1:	adds    	r3, r5, #0
0x001ce3:	lsls    	r0, r0, #9
0x001ce5:	str     	r2, [sp, #8]
0x001ce7:	bl      	#0x4c2d
; block 0x1ceb
0x001ceb:	movs    	r2, #0
0x001ced:	str     	r2, [sp, #8]
0x001cef:	str     	r0, [sp]
0x001cf1:	adds    	r3, r7, #0
0x001cf3:	adds    	r2, r5, #0
0x001cf5:	movs    	r0, #0xf1
0x001cf7:	movs    	r1, #0x32
0x001cf9:	lsls    	r0, r0, #9
0x001cfb:	str     	r4, [sp, #4]
0x001cfd:	bl      	#0x4c2d
; block 0x1d01
0x001d01:	ldr     	r1, [pc, #0xdc]
0x001d03:	movs    	r0, #1
0x001d05:	add     	r1, sb
0x001d07:	strb    	r0, [r1]
0x001d09:	adds    	r0, r1, #0
0x001d0b:	ldr     	r0, [r0, #0x4c]
0x001d0d:	movs    	r4, #0x7d
0x001d0f:	cmp     	r0, #0
0x001d11:	beq     	#0x1ddf
; block 0x1d13
0x001d13:	bl      	#0x36dd
; block 0x1d17
0x001d17:	movs    	r1, #0
0x001d19:	adds    	r5, r0, #0
0x001d1b:	str     	r1, [sp]
0x001d1d:	str     	r1, [sp, #4]
0x001d1f:	movs    	r2, #0
0x001d21:	movs    	r7, #0
0x001d23:	adds    	r3, r7, #0
0x001d25:	movs    	r1, #0x1c
0x001d27:	movs    	r0, #0xf1
0x001d29:	lsls    	r0, r0, #9
0x001d2b:	str     	r2, [sp, #8]
0x001d2d:	bl      	#0x4c2d
; block 0x1d31
0x001d31:	movs    	r2, #0
0x001d33:	str     	r0, [sp]
0x001d35:	movs    	r0, #0xf1
0x001d37:	adds    	r3, r4, #0
0x001d39:	movs    	r1, #0x30
0x001d3b:	lsls    	r0, r0, #9
0x001d3d:	str     	r2, [sp, #8]
0x001d3f:	str     	r6, [sp, #4]
0x001d41:	bl      	#0x4c2d
; block 0x1d45
0x001d45:	movs    	r1, #0
0x001d47:	movs    	r2, #0
0x001d49:	str     	r2, [sp, #8]
0x001d4b:	str     	r1, [sp]
0x001d4d:	str     	r1, [sp, #4]
0x001d4f:	movs    	r1, #0xe1
0x001d51:	movs    	r2, #0x28
0x001d53:	adds    	r3, r7, #0
0x001d55:	movs    	r0, #0xf1
0x001d57:	lsls    	r0, r0, #9
0x001d59:	bl      	#0x4c2d
; block 0x1d5d
0x001d5d:	movs    	r1, #0
0x001d5f:	adds    	r4, r0, #0
0x001d61:	movs    	r2, #0
0x001d63:	str     	r2, [sp, #8]
0x001d65:	str     	r1, [sp]
0x001d67:	str     	r1, [sp, #4]
0x001d69:	movs    	r1, #0xe1
0x001d6b:	movs    	r2, #0x29
0x001d6d:	movs    	r0, #0xf1
0x001d6f:	adds    	r3, r7, #0
0x001d71:	lsls    	r0, r0, #9
0x001d73:	bl      	#0x4c2d
; block 0x1d77
0x001d77:	adds    	r3, r0, #0
0x001d79:	add     	r2, sp, #0x3c
0x001d7b:	add     	r1, sp, #0x40
0x001d7d:	str     	r1, [sp, #4]
0x001d7f:	str     	r2, [sp, #8]
0x001d81:	adds    	r2, r5, #0
0x001d83:	movs    	r1, #0x2a
0x001d85:	movs    	r0, #0xf1
0x001d87:	lsls    	r0, r0, #9
0x001d89:	str     	r4, [sp]
0x001d8b:	bl      	#0x4c2d
; block 0x1d8f
0x001d8f:	movs    	r0, #0xa
0x001d91:	str     	r0, [sp, #0x14]
0x001d93:	ldr     	r0, [sp, #0x3c]
0x001d95:	movs    	r4, #0xc8
0x001d97:	subs    	r0, r6, r0
0x001d99:	asrs    	r0, r0, #1
0x001d9b:	adds    	r0, #0x7d
0x001d9d:	str     	r0, [sp, #0x18]
0x001d9f:	movs    	r0, #0xff
0x001da1:	str     	r0, [sp, #0x20]
0x001da3:	movs    	r1, #0
0x001da5:	str     	r4, [sp, #0x24]
0x001da7:	movs    	r2, #0
0x001da9:	str     	r2, [sp, #8]
0x001dab:	str     	r1, [sp, #4]
0x001dad:	str     	r1, [sp]
0x001daf:	str     	r0, [sp, #0x1c]
0x001db1:	movs    	r0, #0xf1
0x001db3:	movs    	r1, #0xe1
0x001db5:	movs    	r2, #0x29
0x001db7:	adds    	r3, r7, #0
0x001db9:	lsls    	r0, r0, #9
0x001dbb:	str     	r5, [sp, #0x10]
0x001dbd:	bl      	#0x4c2d
; block 0x1dc1
0x001dc1:	str     	r0, [sp, #0x28]
0x001dc3:	movs    	r1, #0
0x001dc5:	movs    	r2, #0
0x001dc7:	str     	r2, [sp, #8]
0x001dc9:	str     	r1, [sp]
0x001dcb:	str     	r1, [sp, #4]
0x001dcd:	movs    	r1, #0xe1
0x001dcf:	movs    	r2, #0x28
0x001dd1:	movs    	r0, #0xf1
0x001dd3:	adds    	r3, r7, #0
0x001dd5:	lsls    	r0, r0, #9
0x001dd7:	bl      	#0x4c2d
; block 0x1ddb
0x001ddb:	str     	r0, [sp, #0x2c]
0x001ddd:	b       	#0x1ded
; block 0x1ddf
0x001ddf:	b       	#0x1e07
; block 0x1ded
0x001ded:	movs    	r1, #0
0x001def:	movs    	r2, #0
0x001df1:	str     	r1, [sp]
0x001df3:	str     	r1, [sp, #4]
0x001df5:	movs    	r1, #0x56
0x001df7:	str     	r2, [sp, #8]
0x001df9:	adds    	r3, r7, #0
0x001dfb:	movs    	r0, #0xf1
0x001dfd:	lsls    	r0, r0, #9
0x001dff:	add     	r2, sp, #0x10
0x001e01:	bl      	#0x4c2d
; block 0x1e05
0x001e05:	movs    	r4, #0x8e
0x001e07:	ldr     	r0, [pc, #0x2dc]
0x001e09:	add     	r0, sb
0x001e0b:	ldr     	r5, [r0, #0x34]
0x001e0d:	cmp     	r5, #0
0x001e0f:	beq     	#0x1ef7
; block 0x1e07
0x001e07:	ldr     	r0, [pc, #0x2dc]
0x001e09:	add     	r0, sb
0x001e0b:	ldr     	r5, [r0, #0x34]
0x001e0d:	cmp     	r5, #0
0x001e0f:	beq     	#0x1ef7
; block 0x1e11
0x001e11:	movs    	r1, #0
0x001e13:	movs    	r2, #0
0x001e15:	str     	r2, [sp, #8]
0x001e17:	str     	r1, [sp]
0x001e19:	str     	r1, [sp, #4]
0x001e1b:	movs    	r7, #0xf1
0x001e1d:	lsls    	r7, r7, #9
0x001e1f:	movs    	r1, #0x11
0x001e21:	adds    	r2, r5, #0
0x001e23:	movs    	r3, #4
0x001e25:	adds    	r0, r7, #0
0x001e27:	bl      	#0x4c2d
; block 0x1e2b
0x001e2b:	movs    	r5, #0
0x001e2d:	cmp     	r0, #0
0x001e2f:	str     	r0, [sp, #0x2c]
0x001e31:	ble     	#0x1ef7
; block 0x1e33
0x001e33:	ldr     	r1, [pc, #0x2b0]
0x001e35:	lsls    	r0, r5, #2
0x001e37:	add     	r1, sb
0x001e39:	ldr     	r1, [r1, #0x34]
0x001e3b:	ldr     	r0, [r1, r0]
0x001e3d:	bl      	#0x36dd
; block 0x1e41
0x001e41:	movs    	r1, #0
0x001e43:	movs    	r2, #0
0x001e45:	str     	r2, [sp, #8]
0x001e47:	str     	r1, [sp]
0x001e49:	str     	r1, [sp, #4]
0x001e4b:	adds    	r7, r0, #0
0x001e4d:	movs    	r0, #0xf1
0x001e4f:	movs    	r1, #0xe1
0x001e51:	movs    	r2, #0x28
0x001e53:	movs    	r3, #0
0x001e55:	lsls    	r0, r0, #9
0x001e57:	bl      	#0x4c2d
; block 0x1e5b
0x001e5b:	str     	r0, [sp, #0x28]
0x001e5d:	movs    	r1, #0
0x001e5f:	movs    	r2, #0
0x001e61:	str     	r2, [sp, #8]
0x001e63:	str     	r1, [sp]
0x001e65:	str     	r1, [sp, #4]
0x001e67:	movs    	r1, #0xe1
0x001e69:	movs    	r2, #0x29
0x001e6b:	movs    	r0, #0xf1
0x001e6d:	movs    	r3, #0
0x001e6f:	lsls    	r0, r0, #9
0x001e71:	bl      	#0x4c2d
; block 0x1e75
0x001e75:	adds    	r3, r0, #0
0x001e77:	ldr     	r0, [sp, #0x28]
0x001e79:	add     	r2, sp, #0x3c
0x001e7b:	add     	r1, sp, #0x40
0x001e7d:	str     	r1, [sp, #4]
0x001e7f:	str     	r2, [sp, #8]
0x001e81:	str     	r0, [sp]
0x001e83:	movs    	r0, #0xf1
0x001e85:	adds    	r2, r7, #0
0x001e87:	movs    	r1, #0x2a
0x001e89:	lsls    	r0, r0, #9
0x001e8b:	bl      	#0x4c2d
; block 0x1e8f
0x001e8f:	movs    	r0, #0xa
0x001e91:	str     	r0, [sp, #0x10]
0x001e93:	ldr     	r0, [sp, #0x3c]
0x001e95:	movs    	r1, #0
0x001e97:	subs    	r0, r6, r0
0x001e99:	asrs    	r0, r0, #1
0x001e9b:	adds    	r0, r0, r4
0x001e9d:	str     	r0, [sp, #0x14]
0x001e9f:	movs    	r0, #0xff
0x001ea1:	str     	r0, [sp, #0x18]
0x001ea3:	str     	r0, [sp, #0x1c]
0x001ea5:	movs    	r0, #0xc8
0x001ea7:	str     	r0, [sp, #0x20]
0x001ea9:	movs    	r2, #0
0x001eab:	str     	r2, [sp, #8]
0x001ead:	str     	r1, [sp]
0x001eaf:	str     	r1, [sp, #4]
0x001eb1:	movs    	r1, #0xe1
0x001eb3:	movs    	r2, #0x29
0x001eb5:	movs    	r0, #0xf1
0x001eb7:	movs    	r3, #0
0x001eb9:	lsls    	r0, r0, #9
0x001ebb:	str     	r7, [sp, #0xc]
0x001ebd:	bl      	#0x4c2d
; block 0x1ec1
0x001ec1:	str     	r0, [sp, #0x24]
0x001ec3:	movs    	r1, #0
0x001ec5:	movs    	r2, #0
0x001ec7:	str     	r2, [sp, #8]
0x001ec9:	str     	r1, [sp]
0x001ecb:	str     	r1, [sp, #4]
0x001ecd:	movs    	r1, #0xe1
0x001ecf:	movs    	r2, #0x28
0x001ed1:	movs    	r0, #0xf1
0x001ed3:	movs    	r3, #0
0x001ed5:	lsls    	r0, r0, #9
0x001ed7:	bl      	#0x4c2d
; block 0x1edb
0x001edb:	str     	r0, [sp, #0x28]
0x001edd:	movs    	r1, #0
0x001edf:	movs    	r2, #0
0x001ee1:	str     	r1, [sp]
0x001ee3:	str     	r1, [sp, #4]
0x001ee5:	movs    	r1, #0x56
0x001ee7:	str     	r2, [sp, #8]
0x001ee9:	movs    	r0, #0xf1
0x001eeb:	movs    	r3, #0
0x001eed:	lsls    	r0, r0, #9
0x001eef:	add     	r2, sp, #0xc
0x001ef1:	bl      	#0x4c2d
; block 0x1ef5
0x001ef5:	b       	#0x1ef9
; block 0x1ef7
0x001ef7:	b       	#0x1f03
; block 0x1ef9
0x001ef9:	ldr     	r0, [sp, #0x2c]
0x001efb:	adds    	r4, r4, r6
0x001efd:	adds    	r5, #1
0x001eff:	cmp     	r5, r0
0x001f01:	blt     	#0x1e33
; block 0x1f03
0x001f03:	ldr     	r0, [pc, #0x1e0]
0x001f05:	movs    	r3, #6
0x001f07:	add     	r0, sb
0x001f09:	ldrsb   	r0, [r0, r3]
0x001f0b:	bl      	#0x3931
; block 0x1f0f
0x001f0f:	movs    	r2, #0
0x001f11:	adds    	r3, r0, #0
0x001f13:	movs    	r1, #0
0x001f15:	str     	r2, [sp, #8]
0x001f17:	ldr     	r2, [pc, #0x1d0]
0x001f19:	str     	r1, [sp]
0x001f1b:	str     	r1, [sp, #4]
0x001f1d:	add     	r2, pc
0x001f1f:	movs    	r1, #0x2d
0x001f21:	movs    	r0, #0xf1
0x001f23:	lsls    	r0, r0, #9
0x001f25:	bl      	#0x4c2d
; block 0x1f29
0x001f29:	adds    	r7, r0, #0
0x001f2b:	movs    	r1, #0
0x001f2d:	ldr     	r0, [pc, #0x1b4]
0x001f2f:	str     	r1, [sp]
0x001f31:	str     	r1, [sp, #4]
0x001f33:	movs    	r2, #0
0x001f35:	str     	r2, [sp, #8]
0x001f37:	add     	r0, sb
0x001f39:	ldr     	r2, [r0, #0x50]
0x001f3b:	movs    	r5, #0
0x001f3d:	adds    	r3, r5, #0
0x001f3f:	movs    	r0, #0xf1
0x001f41:	movs    	r1, #0x3f
0x001f43:	lsls    	r0, r0, #9
0x001f45:	bl      	#0x4c2d
; block 0x1f49
0x001f49:	movs    	r2, #0
0x001f4b:	movs    	r1, #0
0x001f4d:	ldr     	r3, [pc, #0x19c]
0x001f4f:	str     	r1, [sp]
0x001f51:	str     	r1, [sp, #4]
0x001f53:	str     	r2, [sp, #8]
0x001f55:	str     	r0, [sp, #0x2c]
0x001f57:	add     	r3, pc
0x001f59:	adds    	r2, r7, #0
0x001f5b:	movs    	r1, #0x2d
0x001f5d:	movs    	r0, #0xf1
0x001f5f:	lsls    	r0, r0, #9
0x001f61:	bl      	#0x4c2d
; block 0x1f65
0x001f65:	movs    	r2, #0
0x001f67:	movs    	r1, #0
0x001f69:	str     	r2, [sp, #8]
0x001f6b:	adds    	r2, r0, #0
0x001f6d:	str     	r1, [sp]
0x001f6f:	str     	r1, [sp, #4]
0x001f71:	movs    	r1, #0x2d
0x001f73:	movs    	r0, #0xf1
0x001f75:	lsls    	r0, r0, #9
0x001f77:	ldr     	r3, [sp, #0x2c]
0x001f79:	bl      	#0x4c2d
; block 0x1f7d
0x001f7d:	movs    	r1, #0
0x001f7f:	adds    	r7, r0, #0
0x001f81:	movs    	r2, #0
0x001f83:	str     	r1, [sp]
0x001f85:	str     	r1, [sp, #4]
0x001f87:	movs    	r1, #9
0x001f89:	str     	r2, [sp, #8]
0x001f8b:	movs    	r0, #0xf1
0x001f8d:	adds    	r3, r5, #0
0x001f8f:	lsls    	r0, r0, #9
0x001f91:	ldr     	r2, [sp, #0x2c]
0x001f93:	bl      	#0x4c2d
; block 0x1f97
0x001f97:	movs    	r1, #0
0x001f99:	movs    	r2, #0
0x001f9b:	str     	r2, [sp, #8]
0x001f9d:	str     	r1, [sp]
0x001f9f:	str     	r1, [sp, #4]
0x001fa1:	movs    	r1, #0xe1
0x001fa3:	movs    	r2, #0x28
0x001fa5:	adds    	r3, r5, #0
0x001fa7:	movs    	r0, #0xf1
0x001fa9:	lsls    	r0, r0, #9
0x001fab:	bl      	#0x4c2d
; block 0x1faf
0x001faf:	str     	r0, [sp, #0x28]
0x001fb1:	movs    	r1, #0
0x001fb3:	movs    	r2, #0
0x001fb5:	str     	r2, [sp, #8]
0x001fb7:	str     	r1, [sp]
0x001fb9:	str     	r1, [sp, #4]
0x001fbb:	movs    	r1, #0xe1
0x001fbd:	movs    	r2, #0x29
0x001fbf:	movs    	r0, #0xf1
0x001fc1:	adds    	r3, r5, #0
0x001fc3:	lsls    	r0, r0, #9
0x001fc5:	bl      	#0x4c2d
; block 0x1fc9
0x001fc9:	adds    	r3, r0, #0
0x001fcb:	ldr     	r0, [sp, #0x28]
0x001fcd:	add     	r2, sp, #0x3c
0x001fcf:	add     	r1, sp, #0x40
0x001fd1:	str     	r1, [sp, #4]
0x001fd3:	str     	r2, [sp, #8]
0x001fd5:	str     	r0, [sp]
0x001fd7:	movs    	r0, #0xf1
0x001fd9:	adds    	r2, r7, #0
0x001fdb:	movs    	r1, #0x2a
0x001fdd:	lsls    	r0, r0, #9
0x001fdf:	bl      	#0x4c2d
; block 0x1fe3
0x001fe3:	movs    	r0, #0xa
0x001fe5:	str     	r0, [sp, #0x10]
0x001fe7:	ldr     	r0, [sp, #0x3c]
0x001fe9:	movs    	r1, #0
0x001feb:	subs    	r0, r6, r0
0x001fed:	asrs    	r0, r0, #1
0x001fef:	adds    	r0, r0, r4
0x001ff1:	str     	r0, [sp, #0x14]
0x001ff3:	movs    	r0, #0xff
0x001ff5:	movs    	r4, #0xc8
0x001ff7:	str     	r4, [sp, #0x20]
0x001ff9:	movs    	r2, #0
0x001ffb:	str     	r2, [sp, #8]
0x001ffd:	str     	r1, [sp]
0x001fff:	str     	r0, [sp, #0x18]
0x002001:	str     	r0, [sp, #0x1c]
0x002003:	str     	r1, [sp, #4]
0x002005:	movs    	r1, #0xe1
0x002007:	movs    	r0, #0xf1
0x002009:	movs    	r2, #0x29
0x00200b:	adds    	r3, r5, #0
0x00200d:	lsls    	r0, r0, #9
0x00200f:	str     	r7, [sp, #0xc]
0x002011:	bl      	#0x4c2d
; block 0x2015
0x002015:	str     	r0, [sp, #0x24]
0x002017:	movs    	r1, #0
0x002019:	movs    	r2, #0
0x00201b:	str     	r2, [sp, #8]
0x00201d:	str     	r1, [sp]
0x00201f:	str     	r1, [sp, #4]
0x002021:	movs    	r1, #0xe1
0x002023:	movs    	r2, #0x28
0x002025:	movs    	r0, #0xf1
0x002027:	adds    	r3, r5, #0
0x002029:	lsls    	r0, r0, #9
0x00202b:	bl      	#0x4c2d
; block 0x202f
0x00202f:	str     	r0, [sp, #0x28]
0x002031:	movs    	r1, #0
0x002033:	movs    	r2, #0
0x002035:	str     	r1, [sp]
0x002037:	str     	r1, [sp, #4]
0x002039:	movs    	r1, #0x56
0x00203b:	str     	r2, [sp, #8]
0x00203d:	movs    	r0, #0xf1
0x00203f:	adds    	r3, r5, #0
0x002041:	lsls    	r0, r0, #9
0x002043:	add     	r2, sp, #0xc
0x002045:	bl      	#0x4c2d
; block 0x2049
0x002049:	ldr     	r0, [pc, #0x98]
0x00204b:	add     	r0, sb
0x00204d:	ldr     	r0, [r0, #0x4c]
0x00204f:	cmp     	r0, #0
0x002051:	beq     	#0x208b
; block 0x2053
0x002053:	ldr     	r0, [pc, #0x90]
0x002055:	add     	r0, sb
0x002057:	ldr     	r0, [r0, #0x30]
0x002059:	cmp     	r0, #0
0x00205b:	bne     	#0x208b
; block 0x205d
0x00205d:	ldr     	r0, [pc, #0x90]
0x00205f:	add     	r0, pc
0x002061:	str     	r0, [sp, #0x1c]
0x002063:	movs    	r0, #1
0x002065:	str     	r4, [sp, #0x20]
0x002067:	str     	r5, [sp, #0x24]
0x002069:	str     	r5, [sp, #0x28]
0x00206b:	add     	r3, sp, #0x20
0x00206d:	strb    	r0, [r3, #0xc]
0x00206f:	strb    	r5, [r3, #0xd]
0x002071:	movs    	r1, #0
0x002073:	movs    	r2, #0
0x002075:	str     	r1, [sp]
0x002077:	str     	r1, [sp, #4]
0x002079:	movs    	r1, #0x41
0x00207b:	str     	r2, [sp, #8]
0x00207d:	adds    	r3, r5, #0
0x00207f:	movs    	r0, #0xf1
0x002081:	lsls    	r0, r0, #9
0x002083:	add     	r2, sp, #0x1c
0x002085:	bl      	#0x4c2d
; block 0x2089
0x002089:	b       	#0x20b7
; block 0x208b
0x00208b:	ldr     	r0, [pc, #0x68]
0x00208d:	add     	r0, pc
0x00208f:	str     	r0, [sp, #0x1c]
0x002091:	movs    	r0, #1
0x002093:	str     	r4, [sp, #0x20]
0x002095:	str     	r5, [sp, #0x24]
0x002097:	str     	r5, [sp, #0x28]
0x002099:	add     	r3, sp, #0x20
0x00209b:	strb    	r0, [r3, #0xc]
0x00209d:	strb    	r5, [r3, #0xd]
0x00209f:	movs    	r1, #0
0x0020a1:	movs    	r2, #0
0x0020a3:	str     	r1, [sp]
0x0020a5:	str     	r1, [sp, #4]
0x0020a7:	movs    	r1, #0x41
0x0020a9:	str     	r2, [sp, #8]
0x0020ab:	adds    	r3, r5, #0
0x0020ad:	movs    	r0, #0xf1
0x0020af:	lsls    	r0, r0, #9
0x0020b1:	add     	r2, sp, #0x1c
0x0020b3:	bl      	#0x4c2d
; block 0x20b7
0x0020b7:	ldr     	r0, [pc, #0x40]
0x0020b9:	add     	r0, pc
0x0020bb:	str     	r0, [sp, #0x1c]
0x0020bd:	str     	r4, [sp, #0x20]
0x0020bf:	str     	r5, [sp, #0x24]
0x0020c1:	str     	r5, [sp, #0x28]
0x0020c3:	add     	r3, sp, #0x20
0x0020c5:	strb    	r5, [r3, #0xc]
0x0020c7:	strb    	r5, [r3, #0xd]
0x0020c9:	movs    	r1, #0
0x0020cb:	movs    	r2, #0
0x0020cd:	str     	r1, [sp]
0x0020cf:	str     	r1, [sp, #4]
0x0020d1:	movs    	r1, #0x41
0x0020d3:	str     	r2, [sp, #8]
0x0020d5:	adds    	r3, r5, #0
0x0020d7:	movs    	r0, #0xf1
0x0020d9:	lsls    	r0, r0, #9
0x0020db:	add     	r2, sp, #0x1c
0x0020dd:	bl      	#0x4c2d
; block 0x20e1
0x0020e1:	add     	sp, #0x44
0x0020e3:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_1de1 @ 0x1de1 offset=0x1de0 size=12 blocks=1 cc=1 =====
; block 0x1de1
0x001de1:	movs    	r4, r0
0x001de3:	movs    	r0, r0
0x001de5:	sbcs    	r4, r2
0x001de7:	movs    	r0, r0
0x001de9:	subs    	r7, #0xbc
0x001deb:	movs    	r0, r0
0x001ded:	movs    	r1, #0
0x001def:	movs    	r2, #0
0x001df1:	str     	r1, [sp]
0x001df3:	str     	r1, [sp, #4]
0x001df5:	movs    	r1, #0x56
0x001df7:	str     	r2, [sp, #8]
0x001df9:	adds    	r3, r7, #0
0x001dfb:	movs    	r0, #0xf1
0x001dfd:	lsls    	r0, r0, #9
0x001dff:	add     	r2, sp, #0x10
0x001e01:	bl      	#0x4c2d

; ===== sub_20fd @ 0x20fd offset=0x20fc size=1008 blocks=49 cc=39 =====
; block 0x20fd
0x0020fd:	push    	{r4, r5, r6, r7, lr}
0x0020ff:	sub     	sp, #0x3c
0x002101:	movs    	r1, #0
0x002103:	str     	r1, [sp]
0x002105:	str     	r1, [sp, #4]
0x002107:	movs    	r6, #0xf1
0x002109:	movs    	r2, #0
0x00210b:	lsls    	r6, r6, #9
0x00210d:	movs    	r1, #0x1c
0x00210f:	movs    	r3, #0
0x002111:	adds    	r0, r6, #0
0x002113:	str     	r2, [sp, #8]
0x002115:	bl      	#0x4c2d
; block 0x2119
0x002119:	adds    	r5, r0, #0
0x00211b:	ldr     	r0, [pc, #0x3d0]
0x00211d:	movs    	r7, #0x1a
0x00211f:	str     	r7, [sp, #0x30]
0x002121:	add     	r0, sb
0x002123:	ldr     	r0, [r0, #0x38]
0x002125:	movs    	r4, #0x3c
0x002127:	cmp     	r0, #0
0x002129:	bne     	#0x2145
; block 0x212b
0x00212b:	movs    	r1, #0
0x00212d:	movs    	r2, #0
0x00212f:	str     	r2, [sp, #8]
0x002131:	str     	r1, [sp]
0x002133:	str     	r1, [sp, #4]
0x002135:	movs    	r1, #0x9c
0x002137:	movs    	r2, #0x12
0x002139:	movs    	r3, #0
0x00213b:	adds    	r0, r6, #0
0x00213d:	bl      	#0x4c2d
; block 0x2141
0x002141:	add     	sp, #0x3c
0x002143:	pop     	{r4, r5, r6, r7, pc}
; block 0x2145
0x002145:	movs    	r1, #0
0x002147:	str     	r1, [sp]
0x002149:	str     	r1, [sp, #4]
0x00214b:	movs    	r1, #0xff
0x00214d:	movs    	r2, #0
0x00214f:	adds    	r1, #0x26
0x002151:	movs    	r3, #0
0x002153:	adds    	r0, r6, #0
0x002155:	str     	r2, [sp, #8]
0x002157:	bl      	#0x4c2d
; block 0x215b
0x00215b:	movs    	r1, #0
0x00215d:	movs    	r2, #0
0x00215f:	str     	r2, [sp, #8]
0x002161:	str     	r1, [sp]
0x002163:	str     	r1, [sp, #4]
0x002165:	movs    	r1, #0xe1
0x002167:	movs    	r2, #0xed
0x002169:	movs    	r3, #0
0x00216b:	movs    	r0, #0xf1
0x00216d:	lsls    	r0, r0, #9
0x00216f:	bl      	#0x4c2d
; block 0x2173
0x002173:	cmp     	r0, #0
0x002175:	ble     	#0x2141
; block 0x2177
0x002177:	movs    	r1, #0
0x002179:	str     	r1, [sp]
0x00217b:	str     	r1, [sp, #4]
0x00217d:	movs    	r1, #0xff
0x00217f:	movs    	r2, #0
0x002181:	adds    	r1, #0x25
0x002183:	movs    	r3, #0
0x002185:	adds    	r0, r6, #0
0x002187:	str     	r2, [sp, #8]
0x002189:	bl      	#0x4c2d
; block 0x218d
0x00218d:	movs    	r2, #0
0x00218f:	movs    	r1, #0
0x002191:	movs    	r0, #0
0x002193:	bl      	#0x4bdd
; block 0x2197
0x002197:	ldr     	r0, [pc, #0x354]
0x002199:	add     	r0, sb
0x00219b:	ldr     	r0, [r0, #0x3c]
0x00219d:	cmp     	r0, #0
0x00219f:	bne     	#0x21b7
; block 0x21a1
0x0021a1:	movs    	r1, #0
0x0021a3:	movs    	r2, #0
0x0021a5:	str     	r2, [sp, #8]
0x0021a7:	str     	r1, [sp]
0x0021a9:	str     	r1, [sp, #4]
0x0021ab:	movs    	r1, #0x9c
0x0021ad:	movs    	r2, #0x14
0x0021af:	movs    	r3, #0
0x0021b1:	adds    	r0, r6, #0
0x0021b3:	bl      	#0x4c2d
; block 0x21b7
0x0021b7:	movs    	r1, #0
0x0021b9:	str     	r1, [sp]
0x0021bb:	str     	r1, [sp, #4]
0x0021bd:	movs    	r2, #0
0x0021bf:	movs    	r1, #0x1d
0x0021c1:	movs    	r3, #0
0x0021c3:	movs    	r0, #0xf1
0x0021c5:	lsls    	r0, r0, #9
0x0021c7:	str     	r2, [sp, #8]
0x0021c9:	bl      	#0x4c2d
; block 0x21cd
0x0021cd:	movs    	r1, #0xff
0x0021cf:	adds    	r1, #0x2d
0x0021d1:	cmp     	r0, r1
0x0021d3:	blt     	#0x21d7
; block 0x21d5
0x0021d5:	movs    	r4, #0x64
0x0021d7:	movs    	r1, #0
0x0021d9:	str     	r1, [sp]
0x0021db:	str     	r1, [sp, #4]
0x0021dd:	movs    	r2, #0
0x0021df:	movs    	r6, #0
0x0021e1:	adds    	r3, r6, #0
0x0021e3:	movs    	r1, #0x1c
0x0021e5:	movs    	r0, #0xf1
0x0021e7:	lsls    	r0, r0, #9
0x0021e9:	str     	r2, [sp, #8]
0x0021eb:	bl      	#0x4c2d
; block 0x21d7
0x0021d7:	movs    	r1, #0
0x0021d9:	str     	r1, [sp]
0x0021db:	str     	r1, [sp, #4]
0x0021dd:	movs    	r2, #0
0x0021df:	movs    	r6, #0
0x0021e1:	adds    	r3, r6, #0
0x0021e3:	movs    	r1, #0x1c
0x0021e5:	movs    	r0, #0xf1
0x0021e7:	lsls    	r0, r0, #9
0x0021e9:	str     	r2, [sp, #8]
0x0021eb:	bl      	#0x4c2d
; block 0x21ef
0x0021ef:	movs    	r2, #0
0x0021f1:	str     	r2, [sp, #8]
0x0021f3:	str     	r0, [sp]
0x0021f5:	movs    	r0, #0xf1
0x0021f7:	adds    	r2, r6, #0
0x0021f9:	movs    	r1, #0x32
0x0021fb:	lsls    	r0, r0, #9
0x0021fd:	str     	r7, [sp, #4]
0x0021ff:	ldr     	r3, [sp, #0x30]
0x002201:	bl      	#0x4c2d
; block 0x2205
0x002205:	adds    	r3, r7, #0
0x002207:	movs    	r2, #0x1c
0x002209:	adds    	r1, r5, #0
0x00220b:	adds    	r0, r6, #0
0x00220d:	bl      	#0xea1
; block 0x2211
0x002211:	movs    	r1, #0
0x002213:	movs    	r0, #0x36
0x002215:	str     	r0, [sp, #0x30]
0x002217:	str     	r1, [sp]
0x002219:	str     	r1, [sp, #4]
0x00221b:	movs    	r2, #0
0x00221d:	movs    	r1, #0x1d
0x00221f:	movs    	r0, #0xf1
0x002221:	adds    	r3, r6, #0
0x002223:	lsls    	r0, r0, #9
0x002225:	str     	r2, [sp, #8]
0x002227:	bl      	#0x4c2d
; block 0x222b
0x00222b:	subs    	r3, r0, r4
0x00222d:	movs    	r2, #0
0x00222f:	str     	r2, [sp, #8]
0x002231:	adds    	r2, r6, #0
0x002233:	movs    	r0, #0xf1
0x002235:	movs    	r1, #0x31
0x002237:	lsls    	r0, r0, #9
0x002239:	str     	r5, [sp]
0x00223b:	str     	r4, [sp, #4]
0x00223d:	bl      	#0x4c2d
; block 0x2241
0x002241:	movs    	r1, #1
0x002243:	movs    	r2, #1
0x002245:	str     	r2, [sp, #8]
0x002247:	str     	r1, [sp]
0x002249:	str     	r1, [sp, #4]
0x00224b:	movs    	r1, #0x55
0x00224d:	movs    	r2, #0
0x00224f:	adds    	r3, r6, #0
0x002251:	movs    	r0, #0xf1
0x002253:	lsls    	r0, r0, #9
0x002255:	bl      	#0x4c2d
; block 0x2259
0x002259:	movs    	r1, #0
0x00225b:	str     	r1, [sp]
0x00225d:	str     	r1, [sp, #4]
0x00225f:	movs    	r2, #0
0x002261:	movs    	r1, #0x1d
0x002263:	adds    	r3, r6, #0
0x002265:	movs    	r0, #0xf1
0x002267:	lsls    	r0, r0, #9
0x002269:	str     	r2, [sp, #8]
0x00226b:	bl      	#0x4c2d
; block 0x226f
0x00226f:	subs    	r0, #0x36
0x002271:	movs    	r1, #0
0x002273:	subs    	r7, r0, r4
0x002275:	str     	r1, [sp]
0x002277:	str     	r1, [sp, #4]
0x002279:	movs    	r2, #0
0x00227b:	movs    	r1, #0x1c
0x00227d:	movs    	r0, #0xf1
0x00227f:	adds    	r3, r6, #0
0x002281:	lsls    	r0, r0, #9
0x002283:	str     	r2, [sp, #8]
0x002285:	bl      	#0x4c2d
; block 0x2289
0x002289:	movs    	r1, #0x10
0x00228b:	ldr     	r6, [pc, #0x260]
0x00228d:	movs    	r2, #0
0x00228f:	str     	r2, [sp, #0x14]
0x002291:	str     	r1, [sp, #0xc]
0x002293:	str     	r1, [sp, #0x10]
0x002295:	adds    	r3, r0, #0
0x002297:	add     	r6, sb
0x002299:	ldr     	r0, [r6, #0x3c]
0x00229b:	movs    	r2, #1
0x00229d:	cmp     	r0, #1
0x00229f:	beq     	#0x22a3
; block 0x22a1
0x0022a1:	movs    	r2, #0
0x0022a3:	ldr     	r1, [pc, #0x248]
0x0022a5:	ldr     	r6, [pc, #0x244]
0x0022a7:	add     	r1, sb
0x0022a9:	adds    	r1, #0x70
0x0022ab:	str     	r1, [sp, #4]
0x0022ad:	str     	r7, [sp]
0x0022af:	str     	r2, [sp, #8]
0x0022b1:	add     	r6, sb
0x0022b3:	ldr     	r0, [r6, #0x38]
0x0022b5:	ldr     	r1, [r6, #0x6c]
0x0022b7:	ldr     	r0, [r0]
0x0022b9:	lsls    	r1, r1, #2
0x0022bb:	ldr     	r0, [r0, r1]
0x0022bd:	movs    	r1, #0
0x0022bf:	ldr     	r0, [r0, #0xc]
0x0022c1:	ldr     	r2, [sp, #0x30]
0x0022c3:	bl      	#0xbb5
; block 0x22a3
0x0022a3:	ldr     	r1, [pc, #0x248]
0x0022a5:	ldr     	r6, [pc, #0x244]
0x0022a7:	add     	r1, sb
0x0022a9:	adds    	r1, #0x70
0x0022ab:	str     	r1, [sp, #4]
0x0022ad:	str     	r7, [sp]
0x0022af:	str     	r2, [sp, #8]
0x0022b1:	add     	r6, sb
0x0022b3:	ldr     	r0, [r6, #0x38]
0x0022b5:	ldr     	r1, [r6, #0x6c]
0x0022b7:	ldr     	r0, [r0]
0x0022b9:	lsls    	r1, r1, #2
0x0022bb:	ldr     	r0, [r0, r1]
0x0022bd:	movs    	r1, #0
0x0022bf:	ldr     	r0, [r0, #0xc]
0x0022c1:	ldr     	r2, [sp, #0x30]
0x0022c3:	bl      	#0xbb5
; block 0x22c7
0x0022c7:	ldr     	r0, [r6, #0x3c]
0x0022c9:	cmp     	r0, #0
0x0022cb:	bne     	#0x23b1
; block 0x22cd
0x0022cd:	ldr     	r0, [r6, #0x38]
0x0022cf:	ldr     	r1, [r6, #0x6c]
0x0022d1:	ldr     	r0, [r0]
0x0022d3:	lsls    	r1, r1, #2
0x0022d5:	ldr     	r0, [r0, r1]
0x0022d7:	ldr     	r5, [pc, #0x218]
0x0022d9:	add     	r5, pc
0x0022db:	ldr     	r3, [r0, #4]
0x0022dd:	movs    	r1, #0
0x0022df:	movs    	r2, #0
0x0022e1:	str     	r2, [sp, #8]
0x0022e3:	str     	r1, [sp]
0x0022e5:	str     	r1, [sp, #4]
0x0022e7:	movs    	r1, #0x2d
0x0022e9:	adds    	r2, r5, #0
0x0022eb:	movs    	r0, #0xf1
0x0022ed:	lsls    	r0, r0, #9
0x0022ef:	bl      	#0x4c2d
; block 0x22f3
0x0022f3:	movs    	r1, #0
0x0022f5:	adds    	r5, r0, #0
0x0022f7:	movs    	r2, #0
0x0022f9:	str     	r2, [sp, #8]
0x0022fb:	str     	r1, [sp]
0x0022fd:	str     	r1, [sp, #4]
0x0022ff:	movs    	r6, #0
0x002301:	adds    	r3, r6, #0
0x002303:	movs    	r1, #0xe1
0x002305:	movs    	r2, #0x28
0x002307:	movs    	r0, #0xf1
0x002309:	lsls    	r0, r0, #9
0x00230b:	bl      	#0x4c2d
; block 0x230f
0x00230f:	movs    	r1, #0
0x002311:	adds    	r7, r0, #0
0x002313:	movs    	r2, #0
0x002315:	str     	r2, [sp, #8]
0x002317:	str     	r1, [sp]
0x002319:	str     	r1, [sp, #4]
0x00231b:	movs    	r1, #0xe1
0x00231d:	movs    	r2, #0x29
0x00231f:	movs    	r0, #0xf1
0x002321:	adds    	r3, r6, #0
0x002323:	lsls    	r0, r0, #9
0x002325:	bl      	#0x4c2d
; block 0x2329
0x002329:	adds    	r3, r0, #0
0x00232b:	add     	r2, sp, #0x34
0x00232d:	add     	r1, sp, #0x38
0x00232f:	str     	r1, [sp, #4]
0x002331:	str     	r2, [sp, #8]
0x002333:	adds    	r2, r5, #0
0x002335:	movs    	r1, #0x2a
0x002337:	movs    	r0, #0xf1
0x002339:	lsls    	r0, r0, #9
0x00233b:	str     	r7, [sp]
0x00233d:	bl      	#0x4c2d
; block 0x2341
0x002341:	movs    	r1, #0
0x002343:	str     	r1, [sp]
0x002345:	str     	r1, [sp, #4]
0x002347:	movs    	r2, #0
0x002349:	movs    	r1, #0x1c
0x00234b:	adds    	r3, r6, #0
0x00234d:	movs    	r0, #0xf1
0x00234f:	lsls    	r0, r0, #9
0x002351:	str     	r2, [sp, #8]
0x002353:	str     	r5, [sp, #0x10]
0x002355:	bl      	#0x4c2d
; block 0x2359
0x002359:	ldr     	r1, [sp, #0x38]
0x00235b:	movs    	r2, #0
0x00235d:	subs    	r0, r0, r1
0x00235f:	movs    	r1, #0
0x002361:	asrs    	r0, r0, #1
0x002363:	str     	r0, [sp, #0x14]
0x002365:	str     	r1, [sp]
0x002367:	str     	r1, [sp, #4]
0x002369:	movs    	r1, #0x1d
0x00236b:	movs    	r0, #0xf1
0x00236d:	adds    	r3, r6, #0
0x00236f:	lsls    	r0, r0, #9
0x002371:	str     	r2, [sp, #8]
0x002373:	bl      	#0x4c2d
; block 0x2377
0x002377:	ldr     	r1, [sp, #0x34]
0x002379:	movs    	r2, #0
0x00237b:	subs    	r0, r0, r1
0x00237d:	subs    	r1, r4, r1
0x00237f:	asrs    	r1, r1, #1
0x002381:	subs    	r0, r0, r1
0x002383:	str     	r0, [sp, #0x18]
0x002385:	movs    	r0, #0xff
0x002387:	str     	r0, [sp, #0x20]
0x002389:	str     	r0, [sp, #0x1c]
0x00238b:	movs    	r0, #0xc8
0x00238d:	str     	r0, [sp, #0x24]
0x00238f:	movs    	r1, #0
0x002391:	str     	r1, [sp]
0x002393:	str     	r1, [sp, #4]
0x002395:	str     	r2, [sp, #8]
0x002397:	movs    	r2, #0x29
0x002399:	movs    	r1, #0xe1
0x00239b:	movs    	r0, #0xf1
0x00239d:	adds    	r3, r6, #0
0x00239f:	lsls    	r0, r0, #9
0x0023a1:	bl      	#0x4c2d
; block 0x23a5
0x0023a5:	movs    	r2, #0
0x0023a7:	movs    	r1, #0
0x0023a9:	str     	r1, [sp]
0x0023ab:	str     	r1, [sp, #4]
0x0023ad:	str     	r0, [sp, #0x28]
0x0023af:	b       	#0x23b3
; block 0x23b1
0x0023b1:	b       	#0x23df
; block 0x23b3
0x0023b3:	str     	r2, [sp, #8]
0x0023b5:	movs    	r2, #0x28
0x0023b7:	adds    	r3, r6, #0
0x0023b9:	movs    	r1, #0xe1
0x0023bb:	movs    	r0, #0xf1
0x0023bd:	lsls    	r0, r0, #9
0x0023bf:	bl      	#0x4c2d
; block 0x23c3
0x0023c3:	movs    	r1, #0
0x0023c5:	movs    	r2, #0
0x0023c7:	str     	r1, [sp]
0x0023c9:	str     	r1, [sp, #4]
0x0023cb:	str     	r0, [sp, #0x2c]
0x0023cd:	movs    	r0, #0xf1
0x0023cf:	movs    	r1, #0x56
0x0023d1:	str     	r2, [sp, #8]
0x0023d3:	adds    	r3, r6, #0
0x0023d5:	lsls    	r0, r0, #9
0x0023d7:	add     	r2, sp, #0x10
0x0023d9:	bl      	#0x4c2d
; block 0x23dd
0x0023dd:	b       	#0x24d3
; block 0x23df
0x0023df:	movs    	r1, #0
0x0023e1:	movs    	r2, #0
0x0023e3:	str     	r2, [sp, #8]
0x0023e5:	str     	r1, [sp]
0x0023e7:	str     	r1, [sp, #4]
0x0023e9:	movs    	r6, #0
0x0023eb:	movs    	r7, #0xf1
0x0023ed:	lsls    	r7, r7, #9
0x0023ef:	adds    	r3, r6, #0
0x0023f1:	movs    	r1, #0xe1
0x0023f3:	movs    	r2, #0x58
0x0023f5:	adds    	r0, r7, #0
0x0023f7:	bl      	#0x4c2d
; block 0x23fb
0x0023fb:	cmp     	r0, #0
0x0023fd:	bne     	#0x245b
; block 0x23ff
0x0023ff:	ldr     	r0, [pc, #0xec]
0x002401:	adds    	r3, r5, #0
0x002403:	add     	r0, sb
0x002405:	ldr     	r1, [r0, #0x38]
0x002407:	ldr     	r2, [r0, #0x6c]
0x002409:	ldr     	r1, [r1]
0x00240b:	lsls    	r2, r2, #2
0x00240d:	ldr     	r1, [r1, r2]
0x00240f:	ldr     	r0, [r0, #0x70]
0x002411:	ldr     	r1, [r1, #0xc]
0x002413:	lsls    	r0, r0, #2
0x002415:	ldr     	r0, [r1, r0]
0x002417:	movs    	r1, #0
0x002419:	ldr     	r0, [r0, #0x10]
0x00241b:	movs    	r2, #0
0x00241d:	str     	r2, [sp, #8]
0x00241f:	str     	r1, [sp]
0x002421:	str     	r1, [sp, #4]
0x002423:	movs    	r1, #0x42
0x002425:	adds    	r2, r0, #0
0x002427:	subs    	r3, #0x14
0x002429:	adds    	r0, r7, #0
0x00242b:	bl      	#0x4c2d
; block 0x242f
0x00242f:	movs    	r1, #0
0x002431:	movs    	r2, #0
0x002433:	str     	r2, [sp, #8]
0x002435:	str     	r1, [sp]
0x002437:	str     	r1, [sp, #4]
0x002439:	movs    	r1, #0x14
0x00243b:	movs    	r2, #0x58
0x00243d:	adds    	r3, r0, #0
0x00243f:	adds    	r0, r7, #0
0x002441:	bl      	#0x4c2d
; block 0x2445
0x002445:	movs    	r1, #0
0x002447:	movs    	r2, #0
0x002449:	str     	r2, [sp, #8]
0x00244b:	str     	r1, [sp]
0x00244d:	str     	r1, [sp, #4]
0x00244f:	movs    	r1, #0x14
0x002451:	movs    	r2, #0x7b
0x002453:	adds    	r3, r6, #0
0x002455:	adds    	r0, r7, #0
0x002457:	bl      	#0x4c2d
; block 0x245b
0x00245b:	movs    	r1, #0
0x00245d:	movs    	r2, #0
0x00245f:	str     	r2, [sp, #8]
0x002461:	str     	r1, [sp]
0x002463:	str     	r1, [sp, #4]
0x002465:	movs    	r1, #0xe1
0x002467:	movs    	r2, #0x58
0x002469:	adds    	r3, r6, #0
0x00246b:	adds    	r0, r7, #0
0x00246d:	bl      	#0x4c2d
; block 0x2471
0x002471:	movs    	r1, #0
0x002473:	movs    	r2, #0
0x002475:	str     	r2, [sp, #8]
0x002477:	str     	r1, [sp]
0x002479:	str     	r1, [sp, #4]
0x00247b:	str     	r0, [sp, #0x14]
0x00247d:	movs    	r0, #0xf1
0x00247f:	movs    	r1, #0xe1
0x002481:	movs    	r2, #0x7b
0x002483:	adds    	r3, r6, #0
0x002485:	lsls    	r0, r0, #9
0x002487:	bl      	#0x4c2d
; block 0x248b
0x00248b:	str     	r0, [sp, #0x18]
0x00248d:	movs    	r1, #0
0x00248f:	movs    	r0, #5
0x002491:	str     	r0, [sp, #0x1c]
0x002493:	str     	r1, [sp]
0x002495:	str     	r1, [sp, #4]
0x002497:	movs    	r2, #0
0x002499:	movs    	r1, #0x1d
0x00249b:	movs    	r0, #0xf1
0x00249d:	adds    	r3, r6, #0
0x00249f:	lsls    	r0, r0, #9
0x0024a1:	str     	r2, [sp, #8]
0x0024a3:	bl      	#0x4c2d
; block 0x24a7
0x0024a7:	subs    	r0, r0, r4
0x0024a9:	str     	r0, [sp, #0x20]
0x0024ab:	subs    	r4, #0xa
0x0024ad:	subs    	r5, #0x14
0x0024af:	str     	r5, [sp, #0x24]
0x0024b1:	str     	r4, [sp, #0x28]
0x0024b3:	add     	r3, sp, #0x20
0x0024b5:	strb    	r6, [r3, #0xc]
0x0024b7:	movs    	r0, #1
0x0024b9:	strb    	r0, [r3, #0xd]
0x0024bb:	movs    	r1, #0
0x0024bd:	movs    	r2, #0
0x0024bf:	str     	r1, [sp]
0x0024c1:	str     	r1, [sp, #4]
0x0024c3:	movs    	r1, #0x43
0x0024c5:	str     	r2, [sp, #8]
0x0024c7:	movs    	r0, #0xf1
0x0024c9:	adds    	r3, r6, #0
0x0024cb:	lsls    	r0, r0, #9
0x0024cd:	add     	r2, sp, #0x14
0x0024cf:	bl      	#0x4c2d
; block 0x24d3
0x0024d3:	movs    	r1, #0
0x0024d5:	movs    	r2, #0
0x0024d7:	str     	r2, [sp, #8]
0x0024d9:	str     	r1, [sp]
0x0024db:	str     	r1, [sp, #4]
0x0024dd:	movs    	r1, #0x24
0x0024df:	movs    	r2, #1
0x0024e1:	movs    	r3, #1
0x0024e3:	movs    	r0, #0xf1
0x0024e5:	lsls    	r0, r0, #9
0x0024e7:	bl      	#0x4c2d
; block 0x24eb
0x0024eb:	b       	#0x2141

; ===== sub_24ed @ 0x24ed offset=0x24ec size=8 blocks=1 cc=1 =====
; block 0x24ed
0x0024ed:	movs    	r4, r0
0x0024ef:	movs    	r0, r0
0x0024f1:	subs    	r0, #0x98
0x0024f3:	movs    	r0, r0
0x0024f5:	push    	{r4, r5, r6, r7, lr}
0x0024f7:	sub     	sp, #0x3c
0x0024f9:	movs    	r1, #0
0x0024fb:	str     	r1, [sp]
0x0024fd:	str     	r1, [sp, #4]
0x0024ff:	movs    	r7, #0xf1
0x002501:	movs    	r6, #0
0x002503:	movs    	r2, #0
0x002505:	adds    	r3, r6, #0
0x002507:	lsls    	r7, r7, #9
0x002509:	movs    	r1, #0x1c
0x00250b:	adds    	r0, r7, #0
0x00250d:	str     	r2, [sp, #8]
0x00250f:	bl      	#0x4c2d

; ===== sub_24f5 @ 0x24f5 offset=0x24f4 size=948 blocks=46 cc=37 =====
; block 0x24f5
0x0024f5:	push    	{r4, r5, r6, r7, lr}
0x0024f7:	sub     	sp, #0x3c
0x0024f9:	movs    	r1, #0
0x0024fb:	str     	r1, [sp]
0x0024fd:	str     	r1, [sp, #4]
0x0024ff:	movs    	r7, #0xf1
0x002501:	movs    	r6, #0
0x002503:	movs    	r2, #0
0x002505:	adds    	r3, r6, #0
0x002507:	lsls    	r7, r7, #9
0x002509:	movs    	r1, #0x1c
0x00250b:	adds    	r0, r7, #0
0x00250d:	str     	r2, [sp, #8]
0x00250f:	bl      	#0x4c2d
; block 0x2513
0x002513:	adds    	r5, r0, #0
0x002515:	movs    	r0, #0x1a
0x002517:	str     	r0, [sp, #0x2c]
0x002519:	ldr     	r0, [pc, #0x38c]
0x00251b:	movs    	r4, #0x3c
0x00251d:	add     	r0, sb
0x00251f:	ldr     	r0, [r0, #0x38]
0x002521:	cmp     	r0, #0
0x002523:	bne     	#0x253f
; block 0x2525
0x002525:	movs    	r1, #0
0x002527:	movs    	r2, #0
0x002529:	str     	r2, [sp, #8]
0x00252b:	str     	r1, [sp]
0x00252d:	str     	r1, [sp, #4]
0x00252f:	movs    	r1, #0x9c
0x002531:	movs    	r2, #0x12
0x002533:	adds    	r3, r6, #0
0x002535:	adds    	r0, r7, #0
0x002537:	bl      	#0x4c2d
; block 0x253b
0x00253b:	add     	sp, #0x3c
0x00253d:	pop     	{r4, r5, r6, r7, pc}
; block 0x253f
0x00253f:	movs    	r1, #0
0x002541:	str     	r1, [sp]
0x002543:	str     	r1, [sp, #4]
0x002545:	movs    	r1, #0xff
0x002547:	movs    	r2, #0
0x002549:	adds    	r1, #0x26
0x00254b:	adds    	r3, r6, #0
0x00254d:	adds    	r0, r7, #0
0x00254f:	str     	r2, [sp, #8]
0x002551:	bl      	#0x4c2d
; block 0x2555
0x002555:	movs    	r1, #0
0x002557:	movs    	r2, #0
0x002559:	str     	r2, [sp, #8]
0x00255b:	str     	r1, [sp]
0x00255d:	str     	r1, [sp, #4]
0x00255f:	movs    	r1, #0xe1
0x002561:	movs    	r2, #0xed
0x002563:	adds    	r3, r6, #0
0x002565:	movs    	r0, #0xf1
0x002567:	lsls    	r0, r0, #9
0x002569:	bl      	#0x4c2d
; block 0x256d
0x00256d:	cmp     	r0, #0
0x00256f:	ble     	#0x253b
; block 0x2571
0x002571:	movs    	r1, #0
0x002573:	str     	r1, [sp]
0x002575:	str     	r1, [sp, #4]
0x002577:	movs    	r1, #0xff
0x002579:	movs    	r2, #0
0x00257b:	adds    	r1, #0x25
0x00257d:	adds    	r3, r6, #0
0x00257f:	adds    	r0, r7, #0
0x002581:	str     	r2, [sp, #8]
0x002583:	bl      	#0x4c2d
; block 0x2587
0x002587:	movs    	r2, #0
0x002589:	movs    	r1, #0
0x00258b:	movs    	r0, #0
0x00258d:	bl      	#0x4bdd
; block 0x2591
0x002591:	ldr     	r0, [pc, #0x314]
0x002593:	add     	r0, sb
0x002595:	ldr     	r0, [r0, #0x3c]
0x002597:	cmp     	r0, #0
0x002599:	bne     	#0x25b1
; block 0x259b
0x00259b:	movs    	r1, #0
0x00259d:	movs    	r2, #0
0x00259f:	str     	r2, [sp, #8]
0x0025a1:	str     	r1, [sp]
0x0025a3:	str     	r1, [sp, #4]
0x0025a5:	movs    	r1, #0x9c
0x0025a7:	movs    	r2, #0x14
0x0025a9:	adds    	r3, r6, #0
0x0025ab:	adds    	r0, r7, #0
0x0025ad:	bl      	#0x4c2d
; block 0x25b1
0x0025b1:	movs    	r1, #0
0x0025b3:	str     	r1, [sp]
0x0025b5:	str     	r1, [sp, #4]
0x0025b7:	movs    	r2, #0
0x0025b9:	movs    	r1, #0x1d
0x0025bb:	movs    	r3, #0
0x0025bd:	adds    	r6, r7, #0
0x0025bf:	adds    	r0, r7, #0
0x0025c1:	str     	r2, [sp, #8]
0x0025c3:	bl      	#0x4c2d
; block 0x25c7
0x0025c7:	movs    	r1, #0xff
0x0025c9:	adds    	r1, #0x2d
0x0025cb:	cmp     	r0, r1
0x0025cd:	blt     	#0x25d1
; block 0x25cf
0x0025cf:	movs    	r4, #0x64
0x0025d1:	movs    	r1, #0
0x0025d3:	str     	r1, [sp]
0x0025d5:	str     	r1, [sp, #4]
0x0025d7:	movs    	r2, #0
0x0025d9:	movs    	r7, #0
0x0025db:	adds    	r3, r7, #0
0x0025dd:	movs    	r1, #0x1d
0x0025df:	adds    	r0, r6, #0
0x0025e1:	str     	r2, [sp, #8]
0x0025e3:	bl      	#0x4c2d
; block 0x25d1
0x0025d1:	movs    	r1, #0
0x0025d3:	str     	r1, [sp]
0x0025d5:	str     	r1, [sp, #4]
0x0025d7:	movs    	r2, #0
0x0025d9:	movs    	r7, #0
0x0025db:	adds    	r3, r7, #0
0x0025dd:	movs    	r1, #0x1d
0x0025df:	adds    	r0, r6, #0
0x0025e1:	str     	r2, [sp, #8]
0x0025e3:	bl      	#0x4c2d
; block 0x25e7
0x0025e7:	subs    	r3, r0, r4
0x0025e9:	movs    	r2, #0
0x0025eb:	str     	r2, [sp, #8]
0x0025ed:	adds    	r2, r7, #0
0x0025ef:	movs    	r0, #0xf1
0x0025f1:	movs    	r1, #0x31
0x0025f3:	lsls    	r0, r0, #9
0x0025f5:	str     	r5, [sp]
0x0025f7:	str     	r4, [sp, #4]
0x0025f9:	bl      	#0x4c2d
; block 0x25fd
0x0025fd:	movs    	r1, #1
0x0025ff:	movs    	r2, #1
0x002601:	str     	r2, [sp, #8]
0x002603:	str     	r1, [sp]
0x002605:	str     	r1, [sp, #4]
0x002607:	movs    	r1, #0x55
0x002609:	movs    	r2, #0
0x00260b:	adds    	r3, r7, #0
0x00260d:	movs    	r0, #0xf1
0x00260f:	lsls    	r0, r0, #9
0x002611:	bl      	#0x4c2d
; block 0x2615
0x002615:	movs    	r1, #0
0x002617:	str     	r1, [sp]
0x002619:	str     	r1, [sp, #4]
0x00261b:	movs    	r2, #0
0x00261d:	movs    	r1, #0x1d
0x00261f:	adds    	r3, r7, #0
0x002621:	movs    	r0, #0xf1
0x002623:	lsls    	r0, r0, #9
0x002625:	str     	r2, [sp, #8]
0x002627:	bl      	#0x4c2d
; block 0x262b
0x00262b:	subs    	r0, #0x1c
0x00262d:	subs    	r0, r0, r4
0x00262f:	movs    	r1, #0
0x002631:	str     	r1, [sp]
0x002633:	str     	r1, [sp, #4]
0x002635:	str     	r0, [sp, #0x38]
0x002637:	movs    	r2, #0
0x002639:	movs    	r0, #0xf1
0x00263b:	movs    	r1, #0x1c
0x00263d:	adds    	r3, r7, #0
0x00263f:	lsls    	r0, r0, #9
0x002641:	str     	r2, [sp, #8]
0x002643:	bl      	#0x4c2d
; block 0x2647
0x002647:	movs    	r1, #0x10
0x002649:	ldr     	r7, [pc, #0x25c]
0x00264b:	movs    	r2, #1
0x00264d:	str     	r2, [sp, #0x14]
0x00264f:	str     	r1, [sp, #0xc]
0x002651:	str     	r1, [sp, #0x10]
0x002653:	adds    	r3, r0, #0
0x002655:	add     	r7, sb
0x002657:	ldr     	r0, [r7, #0x3c]
0x002659:	cmp     	r0, #1
0x00265b:	beq     	#0x265f
; block 0x265d
0x00265d:	movs    	r2, #0
0x00265f:	ldr     	r1, [pc, #0x248]
0x002661:	ldr     	r0, [sp, #0x38]
0x002663:	ldr     	r7, [pc, #0x244]
0x002665:	add     	r1, sb
0x002667:	adds    	r1, #0x70
0x002669:	str     	r1, [sp, #4]
0x00266b:	str     	r2, [sp, #8]
0x00266d:	str     	r0, [sp]
0x00266f:	add     	r7, sb
0x002671:	ldr     	r0, [r7, #0x38]
0x002673:	ldr     	r1, [r7, #0x6c]
0x002675:	ldr     	r0, [r0]
0x002677:	lsls    	r1, r1, #2
0x002679:	ldr     	r0, [r0, r1]
0x00267b:	movs    	r1, #0
0x00267d:	ldr     	r0, [r0, #0xc]
0x00267f:	ldr     	r2, [sp, #0x2c]
0x002681:	bl      	#0xbb5
; block 0x265f
0x00265f:	ldr     	r1, [pc, #0x248]
0x002661:	ldr     	r0, [sp, #0x38]
0x002663:	ldr     	r7, [pc, #0x244]
0x002665:	add     	r1, sb
0x002667:	adds    	r1, #0x70
0x002669:	str     	r1, [sp, #4]
0x00266b:	str     	r2, [sp, #8]
0x00266d:	str     	r0, [sp]
0x00266f:	add     	r7, sb
0x002671:	ldr     	r0, [r7, #0x38]
0x002673:	ldr     	r1, [r7, #0x6c]
0x002675:	ldr     	r0, [r0]
0x002677:	lsls    	r1, r1, #2
0x002679:	ldr     	r0, [r0, r1]
0x00267b:	movs    	r1, #0
0x00267d:	ldr     	r0, [r0, #0xc]
0x00267f:	ldr     	r2, [sp, #0x2c]
0x002681:	bl      	#0xbb5
; block 0x2685
0x002685:	ldr     	r0, [r7, #0x3c]
0x002687:	cmp     	r0, #0
0x002689:	bne     	#0x276f
; block 0x268b
0x00268b:	ldr     	r0, [r7, #0x38]
0x00268d:	ldr     	r1, [r7, #0x6c]
0x00268f:	ldr     	r0, [r0]
0x002691:	lsls    	r1, r1, #2
0x002693:	ldr     	r0, [r0, r1]
0x002695:	ldr     	r5, [pc, #0x214]
0x002697:	add     	r5, pc
0x002699:	ldr     	r3, [r0, #4]
0x00269b:	movs    	r1, #0
0x00269d:	movs    	r2, #0
0x00269f:	str     	r2, [sp, #8]
0x0026a1:	str     	r1, [sp]
0x0026a3:	str     	r1, [sp, #4]
0x0026a5:	movs    	r1, #0x2d
0x0026a7:	adds    	r2, r5, #0
0x0026a9:	adds    	r0, r6, #0
0x0026ab:	bl      	#0x4c2d
; block 0x26af
0x0026af:	movs    	r1, #0
0x0026b1:	adds    	r5, r0, #0
0x0026b3:	movs    	r2, #0
0x0026b5:	str     	r2, [sp, #8]
0x0026b7:	str     	r1, [sp]
0x0026b9:	str     	r1, [sp, #4]
0x0026bb:	movs    	r7, #0
0x0026bd:	adds    	r3, r7, #0
0x0026bf:	movs    	r1, #0xe1
0x0026c1:	movs    	r2, #0x28
0x0026c3:	movs    	r0, #0xf1
0x0026c5:	lsls    	r0, r0, #9
0x0026c7:	bl      	#0x4c2d
; block 0x26cb
0x0026cb:	str     	r0, [sp, #0x28]
0x0026cd:	movs    	r1, #0
0x0026cf:	movs    	r2, #0
0x0026d1:	str     	r2, [sp, #8]
0x0026d3:	str     	r1, [sp]
0x0026d5:	str     	r1, [sp, #4]
0x0026d7:	movs    	r1, #0xe1
0x0026d9:	movs    	r2, #0x29
0x0026db:	movs    	r0, #0xf1
0x0026dd:	adds    	r3, r7, #0
0x0026df:	lsls    	r0, r0, #9
0x0026e1:	bl      	#0x4c2d
; block 0x26e5
0x0026e5:	adds    	r3, r0, #0
0x0026e7:	ldr     	r0, [sp, #0x28]
0x0026e9:	add     	r2, sp, #0x30
0x0026eb:	add     	r1, sp, #0x34
0x0026ed:	str     	r1, [sp, #4]
0x0026ef:	str     	r2, [sp, #8]
0x0026f1:	str     	r0, [sp]
0x0026f3:	movs    	r0, #0xf1
0x0026f5:	adds    	r2, r5, #0
0x0026f7:	movs    	r1, #0x2a
0x0026f9:	lsls    	r0, r0, #9
0x0026fb:	bl      	#0x4c2d
; block 0x26ff
0x0026ff:	movs    	r1, #0
0x002701:	str     	r1, [sp]
0x002703:	str     	r1, [sp, #4]
0x002705:	movs    	r2, #0
0x002707:	movs    	r1, #0x1c
0x002709:	adds    	r3, r7, #0
0x00270b:	movs    	r0, #0xf1
0x00270d:	lsls    	r0, r0, #9
0x00270f:	str     	r2, [sp, #8]
0x002711:	str     	r5, [sp, #0xc]
0x002713:	bl      	#0x4c2d
; block 0x2717
0x002717:	ldr     	r1, [sp, #0x34]
0x002719:	movs    	r2, #0
0x00271b:	subs    	r0, r0, r1
0x00271d:	movs    	r1, #0
0x00271f:	asrs    	r0, r0, #1
0x002721:	str     	r0, [sp, #0x10]
0x002723:	str     	r1, [sp]
0x002725:	str     	r1, [sp, #4]
0x002727:	movs    	r1, #0x1d
0x002729:	movs    	r0, #0xf1
0x00272b:	adds    	r3, r7, #0
0x00272d:	lsls    	r0, r0, #9
0x00272f:	str     	r2, [sp, #8]
0x002731:	bl      	#0x4c2d
; block 0x2735
0x002735:	ldr     	r1, [sp, #0x30]
0x002737:	movs    	r2, #0
0x002739:	subs    	r0, r0, r1
0x00273b:	subs    	r1, r4, r1
0x00273d:	asrs    	r1, r1, #1
0x00273f:	subs    	r0, r0, r1
0x002741:	str     	r0, [sp, #0x14]
0x002743:	movs    	r0, #0xff
0x002745:	str     	r0, [sp, #0x18]
0x002747:	str     	r0, [sp, #0x1c]
0x002749:	movs    	r0, #0xc8
0x00274b:	str     	r0, [sp, #0x20]
0x00274d:	movs    	r1, #0
0x00274f:	str     	r1, [sp]
0x002751:	str     	r1, [sp, #4]
0x002753:	str     	r2, [sp, #8]
0x002755:	movs    	r2, #0x29
0x002757:	movs    	r1, #0xe1
0x002759:	movs    	r0, #0xf1
0x00275b:	adds    	r3, r7, #0
0x00275d:	lsls    	r0, r0, #9
0x00275f:	bl      	#0x4c2d
; block 0x2763
0x002763:	movs    	r2, #0
0x002765:	movs    	r1, #0
0x002767:	str     	r0, [sp, #0x24]
0x002769:	str     	r1, [sp, #4]
0x00276b:	str     	r1, [sp]
0x00276d:	b       	#0x2771
; block 0x276f
0x00276f:	b       	#0x279d
; block 0x2771
0x002771:	str     	r2, [sp, #8]
0x002773:	movs    	r2, #0x28
0x002775:	adds    	r3, r7, #0
0x002777:	movs    	r1, #0xe1
0x002779:	movs    	r0, #0xf1
0x00277b:	lsls    	r0, r0, #9
0x00277d:	bl      	#0x4c2d
; block 0x2781
0x002781:	str     	r0, [sp, #0x28]
0x002783:	movs    	r1, #0
0x002785:	movs    	r2, #0
0x002787:	str     	r1, [sp]
0x002789:	str     	r1, [sp, #4]
0x00278b:	movs    	r1, #0x56
0x00278d:	str     	r2, [sp, #8]
0x00278f:	movs    	r0, #0xf1
0x002791:	adds    	r3, r7, #0
0x002793:	lsls    	r0, r0, #9
0x002795:	add     	r2, sp, #0xc
0x002797:	bl      	#0x4c2d
; block 0x279b
0x00279b:	b       	#0x2891
; block 0x279d
0x00279d:	movs    	r1, #0
0x00279f:	movs    	r2, #0
0x0027a1:	str     	r2, [sp, #8]
0x0027a3:	str     	r1, [sp]
0x0027a5:	str     	r1, [sp, #4]
0x0027a7:	movs    	r7, #0
0x0027a9:	adds    	r3, r7, #0
0x0027ab:	movs    	r1, #0xe1
0x0027ad:	movs    	r2, #0x58
0x0027af:	adds    	r0, r6, #0
0x0027b1:	bl      	#0x4c2d
; block 0x27b5
0x0027b5:	cmp     	r0, #0
0x0027b7:	bne     	#0x2819
; block 0x27b9
0x0027b9:	ldr     	r0, [pc, #0xec]
0x0027bb:	adds    	r3, r5, #0
0x0027bd:	add     	r0, sb
0x0027bf:	ldr     	r1, [r0, #0x38]
0x0027c1:	ldr     	r2, [r0, #0x6c]
0x0027c3:	ldr     	r1, [r1]
0x0027c5:	lsls    	r2, r2, #2
0x0027c7:	ldr     	r1, [r1, r2]
0x0027c9:	ldr     	r0, [r0, #0x70]
0x0027cb:	ldr     	r1, [r1, #0xc]
0x0027cd:	lsls    	r0, r0, #2
0x0027cf:	ldr     	r0, [r1, r0]
0x0027d1:	movs    	r1, #0
0x0027d3:	ldr     	r0, [r0, #0x10]
0x0027d5:	movs    	r2, #0
0x0027d7:	str     	r2, [sp, #8]
0x0027d9:	str     	r1, [sp]
0x0027db:	str     	r1, [sp, #4]
0x0027dd:	movs    	r1, #0x42
0x0027df:	adds    	r2, r0, #0
0x0027e1:	subs    	r3, #0x14
0x0027e3:	adds    	r0, r6, #0
0x0027e5:	bl      	#0x4c2d
; block 0x27e9
0x0027e9:	movs    	r1, #0
0x0027eb:	movs    	r2, #0
0x0027ed:	str     	r2, [sp, #8]
0x0027ef:	str     	r1, [sp]
0x0027f1:	str     	r1, [sp, #4]
0x0027f3:	adds    	r3, r0, #0
0x0027f5:	movs    	r0, #0xf1
0x0027f7:	movs    	r1, #0x14
0x0027f9:	movs    	r2, #0x58
0x0027fb:	lsls    	r0, r0, #9
0x0027fd:	bl      	#0x4c2d
; block 0x2801
0x002801:	movs    	r1, #0
0x002803:	movs    	r2, #0
0x002805:	str     	r2, [sp, #8]
0x002807:	str     	r1, [sp]
0x002809:	str     	r1, [sp, #4]
0x00280b:	movs    	r1, #0x14
0x00280d:	movs    	r2, #0x7b
0x00280f:	adds    	r3, r7, #0
0x002811:	movs    	r0, #0xf1
0x002813:	lsls    	r0, r0, #9
0x002815:	bl      	#0x4c2d
; block 0x2819
0x002819:	movs    	r1, #0
0x00281b:	movs    	r2, #0
0x00281d:	str     	r2, [sp, #8]
0x00281f:	str     	r1, [sp]
0x002821:	str     	r1, [sp, #4]
0x002823:	movs    	r1, #0xe1
0x002825:	movs    	r2, #0x58
0x002827:	adds    	r3, r7, #0
0x002829:	adds    	r0, r6, #0
0x00282b:	bl      	#0x4c2d
; block 0x282f
0x00282f:	movs    	r1, #0
0x002831:	movs    	r2, #0
0x002833:	str     	r2, [sp, #8]
0x002835:	str     	r1, [sp]
0x002837:	str     	r1, [sp, #4]
0x002839:	str     	r0, [sp, #0x10]
0x00283b:	movs    	r0, #0xf1
0x00283d:	movs    	r1, #0xe1
0x00283f:	movs    	r2, #0x7b
0x002841:	adds    	r3, r7, #0
0x002843:	lsls    	r0, r0, #9
0x002845:	bl      	#0x4c2d
; block 0x2849
0x002849:	str     	r0, [sp, #0x14]
0x00284b:	movs    	r1, #0
0x00284d:	movs    	r0, #5
0x00284f:	str     	r0, [sp, #0x18]
0x002851:	str     	r1, [sp]
0x002853:	str     	r1, [sp, #4]
0x002855:	movs    	r2, #0
0x002857:	movs    	r1, #0x1d
0x002859:	movs    	r0, #0xf1
0x00285b:	adds    	r3, r7, #0
0x00285d:	lsls    	r0, r0, #9
0x00285f:	str     	r2, [sp, #8]
0x002861:	bl      	#0x4c2d
; block 0x2865
0x002865:	subs    	r0, r0, r4
0x002867:	str     	r0, [sp, #0x1c]
0x002869:	subs    	r4, #0xa
0x00286b:	subs    	r5, #0x14
0x00286d:	str     	r5, [sp, #0x20]
0x00286f:	str     	r4, [sp, #0x24]
0x002871:	add     	r3, sp, #0x20
0x002873:	strb    	r7, [r3, #8]
0x002875:	movs    	r0, #1
0x002877:	strb    	r0, [r3, #9]
0x002879:	movs    	r1, #0
0x00287b:	movs    	r2, #0
0x00287d:	str     	r1, [sp]
0x00287f:	str     	r1, [sp, #4]
0x002881:	movs    	r1, #0x43
0x002883:	str     	r2, [sp, #8]
0x002885:	movs    	r0, #0xf1
0x002887:	adds    	r3, r7, #0
0x002889:	lsls    	r0, r0, #9
0x00288b:	add     	r2, sp, #0x10
0x00288d:	bl      	#0x4c2d
; block 0x2891
0x002891:	movs    	r1, #0
0x002893:	movs    	r2, #0
0x002895:	str     	r2, [sp, #8]
0x002897:	str     	r1, [sp]
0x002899:	str     	r1, [sp, #4]
0x00289b:	movs    	r1, #0x24
0x00289d:	movs    	r2, #1
0x00289f:	movs    	r3, #1
0x0028a1:	adds    	r0, r6, #0
0x0028a3:	bl      	#0x4c2d
; block 0x28a7
0x0028a7:	b       	#0x253b

; ===== sub_28a9 @ 0x28a9 offset=0x28a8 size=8 blocks=1 cc=1 =====
; block 0x28a9
0x0028a9:	movs    	r4, r0
0x0028ab:	movs    	r0, r0
0x0028ad:	adds    	r4, #0xda
0x0028af:	movs    	r0, r0
0x0028b1:	push    	{r4, r5, r6, r7, lr}
0x0028b3:	sub     	sp, #0x54
0x0028b5:	movs    	r1, #0
0x0028b7:	str     	r1, [sp]
0x0028b9:	str     	r1, [sp, #4]
0x0028bb:	movs    	r6, #0xf1
0x0028bd:	movs    	r7, #0
0x0028bf:	movs    	r2, #0
0x0028c1:	adds    	r3, r7, #0
0x0028c3:	lsls    	r6, r6, #9
0x0028c5:	movs    	r1, #0x1c
0x0028c7:	adds    	r0, r6, #0
0x0028c9:	str     	r2, [sp, #8]
0x0028cb:	bl      	#0x4c2d

; ===== sub_28b1 @ 0x28b1 offset=0x28b0 size=3380 blocks=176 cc=137 =====
; block 0x28b1
0x0028b1:	push    	{r4, r5, r6, r7, lr}
0x0028b3:	sub     	sp, #0x54
0x0028b5:	movs    	r1, #0
0x0028b7:	str     	r1, [sp]
0x0028b9:	str     	r1, [sp, #4]
0x0028bb:	movs    	r6, #0xf1
0x0028bd:	movs    	r7, #0
0x0028bf:	movs    	r2, #0
0x0028c1:	adds    	r3, r7, #0
0x0028c3:	lsls    	r6, r6, #9
0x0028c5:	movs    	r1, #0x1c
0x0028c7:	adds    	r0, r6, #0
0x0028c9:	str     	r2, [sp, #8]
0x0028cb:	bl      	#0x4c2d
; block 0x28cf
0x0028cf:	adds    	r4, r0, #0
0x0028d1:	movs    	r0, #0x19
0x0028d3:	str     	r0, [sp, #0x44]
0x0028d5:	movs    	r1, #0
0x0028d7:	movs    	r0, #0x46
0x0028d9:	str     	r0, [sp, #0x3c]
0x0028db:	str     	r1, [sp]
0x0028dd:	str     	r1, [sp, #4]
0x0028df:	movs    	r1, #0xff
0x0028e1:	movs    	r0, #0x19
0x0028e3:	movs    	r2, #0
0x0028e5:	str     	r0, [sp, #0x34]
0x0028e7:	adds    	r1, #0x26
0x0028e9:	movs    	r5, #0x11
0x0028eb:	adds    	r3, r7, #0
0x0028ed:	adds    	r0, r6, #0
0x0028ef:	str     	r2, [sp, #8]
0x0028f1:	bl      	#0x4c2d
; block 0x28f5
0x0028f5:	movs    	r1, #0
0x0028f7:	movs    	r2, #0
0x0028f9:	str     	r2, [sp, #8]
0x0028fb:	str     	r1, [sp]
0x0028fd:	str     	r1, [sp, #4]
0x0028ff:	movs    	r1, #0xe1
0x002901:	movs    	r2, #0xed
0x002903:	adds    	r3, r7, #0
0x002905:	adds    	r0, r6, #0
0x002907:	bl      	#0x4c2d
; block 0x290b
0x00290b:	cmp     	r0, #0
0x00290d:	ble     	#0x29f3
; block 0x290f
0x00290f:	movs    	r1, #0
0x002911:	str     	r1, [sp]
0x002913:	str     	r1, [sp, #4]
0x002915:	movs    	r1, #0xff
0x002917:	movs    	r2, #0
0x002919:	adds    	r1, #0x25
0x00291b:	adds    	r3, r7, #0
0x00291d:	adds    	r0, r6, #0
0x00291f:	str     	r2, [sp, #8]
0x002921:	bl      	#0x4c2d
; block 0x2925
0x002925:	movs    	r2, #0
0x002927:	movs    	r1, #0
0x002929:	movs    	r0, #0
0x00292b:	bl      	#0x4bdd
; block 0x292f
0x00292f:	movs    	r1, #0
0x002931:	str     	r1, [sp]
0x002933:	str     	r1, [sp, #4]
0x002935:	movs    	r2, #0
0x002937:	movs    	r1, #0x1c
0x002939:	adds    	r3, r7, #0
0x00293b:	adds    	r0, r6, #0
0x00293d:	str     	r2, [sp, #8]
0x00293f:	bl      	#0x4c2d
; block 0x2943
0x002943:	ldr     	r1, [sp, #0x44]
0x002945:	movs    	r2, #0
0x002947:	str     	r2, [sp, #8]
0x002949:	str     	r1, [sp, #4]
0x00294b:	movs    	r1, #0x32
0x00294d:	adds    	r2, r7, #0
0x00294f:	str     	r0, [sp]
0x002951:	adds    	r3, r7, #0
0x002953:	adds    	r0, r6, #0
0x002955:	bl      	#0x4c2d
; block 0x2959
0x002959:	movs    	r2, #0
0x00295b:	str     	r2, [sp, #8]
0x00295d:	movs    	r1, #0
0x00295f:	ldr     	r0, [pc, #0x3e0]
0x002961:	ldr     	r2, [pc, #0x3e0]
0x002963:	str     	r1, [sp]
0x002965:	str     	r1, [sp, #4]
0x002967:	add     	r0, sb
0x002969:	add     	r2, pc
0x00296b:	movs    	r1, #0x2d
0x00296d:	ldr     	r3, [r0, #0x5c]
0x00296f:	adds    	r0, r6, #0
0x002971:	bl      	#0x4c2d
; block 0x2975
0x002975:	movs    	r1, #0
0x002977:	str     	r0, [sp, #0x40]
0x002979:	movs    	r2, #0
0x00297b:	str     	r2, [sp, #8]
0x00297d:	str     	r1, [sp]
0x00297f:	str     	r1, [sp, #4]
0x002981:	movs    	r1, #0xe1
0x002983:	movs    	r2, #0x28
0x002985:	adds    	r3, r7, #0
0x002987:	adds    	r0, r6, #0
0x002989:	bl      	#0x4c2d
; block 0x298d
0x00298d:	movs    	r1, #0
0x00298f:	movs    	r2, #0
0x002991:	str     	r2, [sp, #8]
0x002993:	str     	r1, [sp]
0x002995:	str     	r1, [sp, #4]
0x002997:	movs    	r1, #0xe1
0x002999:	movs    	r2, #0x29
0x00299b:	str     	r0, [sp, #0x2c]
0x00299d:	adds    	r3, r7, #0
0x00299f:	adds    	r0, r6, #0
0x0029a1:	bl      	#0x4c2d
; block 0x29a5
0x0029a5:	adds    	r3, r0, #0
0x0029a7:	ldr     	r0, [sp, #0x2c]
0x0029a9:	add     	r1, sp, #0x50
0x0029ab:	str     	r1, [sp, #4]
0x0029ad:	add     	r2, sp, #0x4c
0x0029af:	str     	r0, [sp]
0x0029b1:	str     	r2, [sp, #8]
0x0029b3:	movs    	r1, #0x2a
0x0029b5:	adds    	r0, r6, #0
0x0029b7:	ldr     	r2, [sp, #0x40]
0x0029b9:	bl      	#0x4c2d
; block 0x29bd
0x0029bd:	ldr     	r0, [sp, #0x40]
0x0029bf:	movs    	r1, #0
0x0029c1:	str     	r1, [sp]
0x0029c3:	str     	r1, [sp, #4]
0x0029c5:	movs    	r2, #0
0x0029c7:	movs    	r1, #0x1c
0x0029c9:	adds    	r3, r7, #0
0x0029cb:	str     	r0, [sp, #0x10]
0x0029cd:	adds    	r0, r6, #0
0x0029cf:	str     	r2, [sp, #8]
0x0029d1:	bl      	#0x4c2d
; block 0x29d5
0x0029d5:	ldr     	r1, [sp, #0x50]
0x0029d7:	subs    	r0, r0, r1
0x0029d9:	asrs    	r0, r0, #1
0x0029db:	str     	r0, [sp, #0x14]
0x0029dd:	ldr     	r0, [sp, #0x44]
0x0029df:	ldr     	r1, [sp, #0x4c]
0x0029e1:	subs    	r0, r0, r1
0x0029e3:	asrs    	r0, r0, #1
0x0029e5:	str     	r0, [sp, #0x18]
0x0029e7:	movs    	r0, #0xff
0x0029e9:	str     	r0, [sp, #0x1c]
0x0029eb:	str     	r0, [sp, #0x20]
0x0029ed:	movs    	r0, #0xc8
0x0029ef:	str     	r0, [sp, #0x24]
0x0029f1:	b       	#0x29f5
; block 0x29f3
0x0029f3:	b       	#0x3123
; block 0x29f5
0x0029f5:	movs    	r1, #0
0x0029f7:	movs    	r2, #0
0x0029f9:	str     	r2, [sp, #8]
0x0029fb:	str     	r1, [sp]
0x0029fd:	str     	r1, [sp, #4]
0x0029ff:	movs    	r1, #0xe1
0x002a01:	movs    	r2, #0x29
0x002a03:	adds    	r3, r7, #0
0x002a05:	adds    	r0, r6, #0
0x002a07:	bl      	#0x4c2d
; block 0x2a0b
0x002a0b:	movs    	r1, #0
0x002a0d:	str     	r0, [sp, #0x28]
0x002a0f:	movs    	r2, #0
0x002a11:	str     	r2, [sp, #8]
0x002a13:	str     	r1, [sp]
0x002a15:	str     	r1, [sp, #4]
0x002a17:	movs    	r1, #0xe1
0x002a19:	movs    	r2, #0x28
0x002a1b:	adds    	r3, r7, #0
0x002a1d:	adds    	r0, r6, #0
0x002a1f:	bl      	#0x4c2d
; block 0x2a23
0x002a23:	movs    	r1, #0
0x002a25:	movs    	r2, #0
0x002a27:	str     	r1, [sp]
0x002a29:	str     	r1, [sp, #4]
0x002a2b:	movs    	r1, #0x56
0x002a2d:	str     	r2, [sp, #8]
0x002a2f:	str     	r0, [sp, #0x2c]
0x002a31:	adds    	r3, r7, #0
0x002a33:	adds    	r0, r6, #0
0x002a35:	add     	r2, sp, #0x10
0x002a37:	bl      	#0x4c2d
; block 0x2a3b
0x002a3b:	movs    	r3, #0x19
0x002a3d:	ldr     	r1, [sp, #0x3c]
0x002a3f:	str     	r3, [sp, #0x48]
0x002a41:	movs    	r2, #0
0x002a43:	str     	r2, [sp, #8]
0x002a45:	str     	r1, [sp, #4]
0x002a47:	movs    	r1, #0x2e
0x002a49:	adds    	r2, r7, #0
0x002a4b:	adds    	r0, r6, #0
0x002a4d:	str     	r4, [sp]
0x002a4f:	bl      	#0x4c2d
; block 0x2a53
0x002a53:	movs    	r1, #0
0x002a55:	movs    	r2, #0
0x002a57:	str     	r2, [sp, #8]
0x002a59:	str     	r1, [sp]
0x002a5b:	str     	r1, [sp, #4]
0x002a5d:	movs    	r1, #0xe1
0x002a5f:	movs    	r2, #0x58
0x002a61:	adds    	r3, r7, #0
0x002a63:	adds    	r0, r6, #0
0x002a65:	bl      	#0x4c2d
; block 0x2a69
0x002a69:	cmp     	r0, #0
0x002a6b:	bne     	#0x2ab7
; block 0x2a6d
0x002a6d:	ldr     	r0, [pc, #0x2d0]
0x002a6f:	movs    	r1, #0
0x002a71:	add     	r0, sb
0x002a73:	ldr     	r0, [r0, #0x60]
0x002a75:	movs    	r2, #0
0x002a77:	str     	r2, [sp, #8]
0x002a79:	str     	r1, [sp]
0x002a7b:	str     	r1, [sp, #4]
0x002a7d:	adds    	r3, r4, #0
0x002a7f:	subs    	r3, #0x14
0x002a81:	movs    	r1, #0x42
0x002a83:	adds    	r2, r0, #0
0x002a85:	adds    	r0, r6, #0
0x002a87:	bl      	#0x4c2d
; block 0x2a8b
0x002a8b:	movs    	r1, #0
0x002a8d:	movs    	r2, #0
0x002a8f:	str     	r2, [sp, #8]
0x002a91:	str     	r1, [sp]
0x002a93:	str     	r1, [sp, #4]
0x002a95:	movs    	r1, #0x14
0x002a97:	movs    	r2, #0x58
0x002a99:	adds    	r3, r0, #0
0x002a9b:	adds    	r0, r6, #0
0x002a9d:	bl      	#0x4c2d
; block 0x2aa1
0x002aa1:	movs    	r1, #0
0x002aa3:	movs    	r2, #0
0x002aa5:	str     	r2, [sp, #8]
0x002aa7:	str     	r1, [sp]
0x002aa9:	str     	r1, [sp, #4]
0x002aab:	movs    	r1, #0x14
0x002aad:	movs    	r2, #0x7b
0x002aaf:	adds    	r3, r7, #0
0x002ab1:	adds    	r0, r6, #0
0x002ab3:	bl      	#0x4c2d
; block 0x2ab7
0x002ab7:	movs    	r1, #0
0x002ab9:	movs    	r2, #0
0x002abb:	str     	r2, [sp, #8]
0x002abd:	str     	r1, [sp]
0x002abf:	str     	r1, [sp, #4]
0x002ac1:	movs    	r1, #0xe1
0x002ac3:	movs    	r2, #0x58
0x002ac5:	adds    	r3, r7, #0
0x002ac7:	adds    	r0, r6, #0
0x002ac9:	bl      	#0x4c2d
; block 0x2acd
0x002acd:	movs    	r1, #0
0x002acf:	movs    	r2, #0
0x002ad1:	str     	r2, [sp, #8]
0x002ad3:	str     	r1, [sp]
0x002ad5:	str     	r1, [sp, #4]
0x002ad7:	str     	r0, [sp, #0x14]
0x002ad9:	movs    	r0, #0xf1
0x002adb:	movs    	r1, #0xe1
0x002add:	movs    	r2, #0x7b
0x002adf:	adds    	r3, r7, #0
0x002ae1:	lsls    	r0, r0, #9
0x002ae3:	bl      	#0x4c2d
; block 0x2ae7
0x002ae7:	str     	r0, [sp, #0x18]
0x002ae9:	movs    	r0, #5
0x002aeb:	str     	r0, [sp, #0x1c]
0x002aed:	adds    	r0, r4, #0
0x002aef:	subs    	r0, #0x14
0x002af1:	ldr     	r3, [sp, #0x48]
0x002af3:	str     	r0, [sp, #0x24]
0x002af5:	movs    	r0, #0x3c
0x002af7:	str     	r0, [sp, #0x28]
0x002af9:	str     	r3, [sp, #0x20]
0x002afb:	add     	r3, sp, #0x20
0x002afd:	strb    	r7, [r3, #0xc]
0x002aff:	movs    	r0, #1
0x002b01:	strb    	r0, [r3, #0xd]
0x002b03:	movs    	r1, #0
0x002b05:	movs    	r2, #0
0x002b07:	str     	r1, [sp]
0x002b09:	str     	r1, [sp, #4]
0x002b0b:	movs    	r1, #0x43
0x002b0d:	str     	r2, [sp, #8]
0x002b0f:	movs    	r0, #0xf1
0x002b11:	adds    	r3, r7, #0
0x002b13:	lsls    	r0, r0, #9
0x002b15:	add     	r2, sp, #0x14
0x002b17:	bl      	#0x4c2d
; block 0x2b1b
0x002b1b:	ldr     	r1, [sp, #0x34]
0x002b1d:	movs    	r2, #0
0x002b1f:	str     	r2, [sp, #8]
0x002b21:	str     	r1, [sp, #4]
0x002b23:	movs    	r1, #0x31
0x002b25:	adds    	r2, r7, #0
0x002b27:	movs    	r3, #0x5f
0x002b29:	movs    	r0, #0xf1
0x002b2b:	lsls    	r0, r0, #9
0x002b2d:	str     	r4, [sp]
0x002b2f:	bl      	#0x4c2d
; block 0x2b33
0x002b33:	ldr     	r4, [pc, #0x214]
0x002b35:	add     	r4, pc
0x002b37:	movs    	r1, #0
0x002b39:	movs    	r2, #0
0x002b3b:	str     	r2, [sp, #8]
0x002b3d:	str     	r1, [sp]
0x002b3f:	str     	r1, [sp, #4]
0x002b41:	movs    	r1, #0xe1
0x002b43:	movs    	r2, #0x28
0x002b45:	adds    	r3, r7, #0
0x002b47:	movs    	r0, #0xf1
0x002b49:	lsls    	r0, r0, #9
0x002b4b:	bl      	#0x4c2d
; block 0x2b4f
0x002b4f:	movs    	r1, #0
0x002b51:	movs    	r2, #0
0x002b53:	str     	r2, [sp, #8]
0x002b55:	str     	r1, [sp]
0x002b57:	str     	r1, [sp, #4]
0x002b59:	str     	r0, [sp, #0x2c]
0x002b5b:	movs    	r0, #0xf1
0x002b5d:	movs    	r1, #0xe1
0x002b5f:	movs    	r2, #0x29
0x002b61:	adds    	r3, r7, #0
0x002b63:	lsls    	r0, r0, #9
0x002b65:	bl      	#0x4c2d
; block 0x2b69
0x002b69:	adds    	r3, r0, #0
0x002b6b:	ldr     	r0, [sp, #0x2c]
0x002b6d:	add     	r2, sp, #0x4c
0x002b6f:	add     	r1, sp, #0x50
0x002b71:	str     	r1, [sp, #4]
0x002b73:	str     	r2, [sp, #8]
0x002b75:	str     	r0, [sp]
0x002b77:	movs    	r0, #0xf1
0x002b79:	adds    	r2, r4, #0
0x002b7b:	movs    	r1, #0x2a
0x002b7d:	lsls    	r0, r0, #9
0x002b7f:	bl      	#0x4c2d
; block 0x2b83
0x002b83:	movs    	r1, #0
0x002b85:	str     	r1, [sp]
0x002b87:	str     	r1, [sp, #4]
0x002b89:	movs    	r2, #0
0x002b8b:	movs    	r1, #0x1c
0x002b8d:	adds    	r3, r7, #0
0x002b8f:	movs    	r0, #0xf1
0x002b91:	lsls    	r0, r0, #9
0x002b93:	str     	r2, [sp, #8]
0x002b95:	str     	r4, [sp, #0x10]
0x002b97:	bl      	#0x4c2d
; block 0x2b9b
0x002b9b:	ldr     	r1, [sp, #0x50]
0x002b9d:	movs    	r2, #0
0x002b9f:	subs    	r0, r0, r1
0x002ba1:	asrs    	r0, r0, #1
0x002ba3:	str     	r0, [sp, #0x14]
0x002ba5:	ldr     	r0, [sp, #0x34]
0x002ba7:	ldr     	r1, [sp, #0x4c]
0x002ba9:	str     	r2, [sp, #8]
0x002bab:	subs    	r0, r0, r1
0x002bad:	asrs    	r0, r0, #1
0x002baf:	adds    	r0, #0x5f
0x002bb1:	str     	r0, [sp, #0x18]
0x002bb3:	movs    	r0, #0xff
0x002bb5:	str     	r0, [sp, #0x20]
0x002bb7:	str     	r0, [sp, #0x1c]
0x002bb9:	movs    	r0, #0xc8
0x002bbb:	str     	r0, [sp, #0x24]
0x002bbd:	movs    	r1, #0
0x002bbf:	str     	r1, [sp]
0x002bc1:	str     	r1, [sp, #4]
0x002bc3:	movs    	r1, #0xe1
0x002bc5:	movs    	r0, #0xf1
0x002bc7:	adds    	r3, r7, #0
0x002bc9:	movs    	r2, #0x29
0x002bcb:	lsls    	r0, r0, #9
0x002bcd:	bl      	#0x4c2d
; block 0x2bd1
0x002bd1:	str     	r0, [sp, #0x28]
0x002bd3:	movs    	r1, #0
0x002bd5:	movs    	r2, #0
0x002bd7:	str     	r2, [sp, #8]
0x002bd9:	str     	r1, [sp]
0x002bdb:	str     	r1, [sp, #4]
0x002bdd:	movs    	r1, #0xe1
0x002bdf:	movs    	r2, #0x28
0x002be1:	movs    	r0, #0xf1
0x002be3:	adds    	r3, r7, #0
0x002be5:	lsls    	r0, r0, #9
0x002be7:	bl      	#0x4c2d
; block 0x2beb
0x002beb:	movs    	r1, #0
0x002bed:	movs    	r2, #0
0x002bef:	str     	r1, [sp]
0x002bf1:	str     	r1, [sp, #4]
0x002bf3:	str     	r0, [sp, #0x2c]
0x002bf5:	movs    	r0, #0xf1
0x002bf7:	movs    	r1, #0x56
0x002bf9:	str     	r2, [sp, #8]
0x002bfb:	adds    	r3, r7, #0
0x002bfd:	lsls    	r0, r0, #9
0x002bff:	add     	r2, sp, #0x10
0x002c01:	bl      	#0x4c2d
; block 0x2c05
0x002c05:	movs    	r1, #0
0x002c07:	str     	r1, [sp]
0x002c09:	str     	r1, [sp, #4]
0x002c0b:	movs    	r2, #0
0x002c0d:	movs    	r1, #0x1d
0x002c0f:	movs    	r4, #0x78
0x002c11:	adds    	r3, r7, #0
0x002c13:	movs    	r0, #0xf1
0x002c15:	lsls    	r0, r0, #9
0x002c17:	str     	r2, [sp, #8]
0x002c19:	bl      	#0x4c2d
; block 0x2c1d
0x002c1d:	subs    	r0, #0x78
0x002c1f:	movs    	r1, #0
0x002c21:	str     	r1, [sp]
0x002c23:	str     	r1, [sp, #4]
0x002c25:	str     	r0, [sp, #0x38]
0x002c27:	movs    	r2, #0
0x002c29:	movs    	r0, #0xf1
0x002c2b:	movs    	r1, #0x1c
0x002c2d:	adds    	r3, r7, #0
0x002c2f:	lsls    	r0, r0, #9
0x002c31:	str     	r2, [sp, #8]
0x002c33:	bl      	#0x4c2d
; block 0x2c37
0x002c37:	ldr     	r1, [sp, #0x38]
0x002c39:	movs    	r2, #0
0x002c3b:	str     	r2, [sp, #8]
0x002c3d:	str     	r0, [sp]
0x002c3f:	adds    	r3, r4, #0
0x002c41:	str     	r1, [sp, #4]
0x002c43:	movs    	r1, #0x32
0x002c45:	adds    	r2, r7, #0
0x002c47:	movs    	r0, #0xf1
0x002c49:	lsls    	r0, r0, #9
0x002c4b:	bl      	#0x4c2d
; block 0x2c4f
0x002c4f:	ldr     	r1, [pc, #0xf0]
0x002c51:	movs    	r3, #0x7d
0x002c53:	str     	r3, [sp, #0x48]
0x002c55:	movs    	r0, #1
0x002c57:	add     	r1, sb
0x002c59:	strb    	r0, [r1]
0x002c5b:	adds    	r0, r1, #0
0x002c5d:	ldr     	r4, [r0, #0x48]
0x002c5f:	cmp     	r4, #0
0x002c61:	beq     	#0x2cff
; block 0x2c63
0x002c63:	ldr     	r0, [pc, #0xe8]
0x002c65:	add     	r0, pc
0x002c67:	movs    	r1, #0
0x002c69:	movs    	r2, #0
0x002c6b:	str     	r2, [sp, #8]
0x002c6d:	str     	r1, [sp]
0x002c6f:	str     	r1, [sp, #4]
0x002c71:	str     	r0, [sp, #0x2c]
0x002c73:	movs    	r1, #0xb1
0x002c75:	adds    	r2, r4, #0
0x002c77:	adds    	r0, r6, #0
0x002c79:	ldr     	r3, [r4, #4]
0x002c7b:	bl      	#0x4c2d
; block 0x2c7f
0x002c7f:	movs    	r1, #0
0x002c81:	movs    	r2, #0
0x002c83:	str     	r1, [sp]
0x002c85:	str     	r1, [sp, #4]
0x002c87:	adds    	r3, r0, #0
0x002c89:	movs    	r0, #0xf1
0x002c8b:	movs    	r1, #0x2d
0x002c8d:	str     	r2, [sp, #8]
0x002c8f:	ldr     	r2, [sp, #0x2c]
0x002c91:	lsls    	r0, r0, #9
0x002c93:	bl      	#0x4c2d
; block 0x2c97
0x002c97:	movs    	r2, #0
0x002c99:	movs    	r1, #0
0x002c9b:	ldr     	r3, [pc, #0xb4]
0x002c9d:	str     	r1, [sp]
0x002c9f:	str     	r1, [sp, #4]
0x002ca1:	str     	r2, [sp, #8]
0x002ca3:	add     	r3, pc
0x002ca5:	adds    	r2, r0, #0
0x002ca7:	movs    	r0, #0xf1
0x002ca9:	movs    	r1, #0x2d
0x002cab:	lsls    	r0, r0, #9
0x002cad:	bl      	#0x4c2d
; block 0x2cb1
0x002cb1:	adds    	r4, r0, #0
0x002cb3:	ldr     	r0, [pc, #0x8c]
0x002cb5:	add     	r0, sb
0x002cb7:	ldr     	r0, [r0, #0x64]
0x002cb9:	adds    	r3, r0, #1
0x002cbb:	bne     	#0x2da3
; block 0x2cbd
0x002cbd:	ldr     	r1, [pc, #0x80]
0x002cbf:	movs    	r2, #0
0x002cc1:	add     	r1, sb
0x002cc3:	ldr     	r0, [r1, #0x38]
0x002cc5:	ldr     	r1, [r1, #0x6c]
0x002cc7:	ldr     	r0, [r0]
0x002cc9:	lsls    	r1, r1, #2
0x002ccb:	ldr     	r0, [r0, r1]
0x002ccd:	ldr     	r1, [pc, #0x70]
0x002ccf:	ldr     	r0, [r0, #0xc]
0x002cd1:	add     	r1, sb
0x002cd3:	ldr     	r1, [r1, #0x70]
0x002cd5:	adds    	r3, r7, #0
0x002cd7:	lsls    	r1, r1, #2
0x002cd9:	ldr     	r0, [r0, r1]
0x002cdb:	movs    	r1, #0
0x002cdd:	str     	r1, [sp]
0x002cdf:	str     	r1, [sp, #4]
0x002ce1:	str     	r0, [sp, #0x28]
0x002ce3:	movs    	r1, #0x34
0x002ce5:	adds    	r0, r6, #0
0x002ce7:	str     	r2, [sp, #8]
0x002ce9:	bl      	#0x4c2d
; block 0x2ced
0x002ced:	ldr     	r0, [sp, #0x28]
0x002cef:	ldr     	r1, [r0]
0x002cf1:	ldr     	r0, [pc, #0x4c]
0x002cf3:	add     	r0, sb
0x002cf5:	ldr     	r0, [r0, #0x48]
0x002cf7:	ldr     	r0, [r0]
0x002cf9:	bl      	#0x58cd
; block 0x2cfd
0x002cfd:	b       	#0x2da3
; block 0x2cff
0x002cff:	ldr     	r0, [pc, #0x54]
0x002d01:	add     	r0, pc
0x002d03:	str     	r0, [sp, #0x2c]
0x002d05:	movs    	r1, #0
0x002d07:	ldr     	r0, [pc, #0x38]
0x002d09:	str     	r1, [sp]
0x002d0b:	str     	r1, [sp, #4]
0x002d0d:	movs    	r2, #0
0x002d0f:	str     	r2, [sp, #8]
0x002d11:	movs    	r3, #4
0x002d13:	add     	r0, sb
0x002d15:	ldrsb   	r2, [r0, r3]
0x002d17:	adds    	r0, r6, #0
0x002d19:	movs    	r1, #0x3f
0x002d1b:	adds    	r3, r7, #0
0x002d1d:	bl      	#0x4c2d
; block 0x2d21
0x002d21:	movs    	r1, #0
0x002d23:	adds    	r4, r0, #0
0x002d25:	movs    	r2, #0
0x002d27:	adds    	r3, r0, #0
0x002d29:	str     	r1, [sp]
0x002d2b:	str     	r1, [sp, #4]
0x002d2d:	movs    	r1, #0x2d
0x002d2f:	movs    	r0, #0xf1
0x002d31:	str     	r2, [sp, #8]
0x002d33:	ldr     	r2, [sp, #0x2c]
0x002d35:	lsls    	r0, r0, #9
0x002d37:	bl      	#0x4c2d
; block 0x2d3b
0x002d3b:	movs    	r2, #0
0x002d3d:	movs    	r1, #0
0x002d3f:	b       	#0x2d59
; block 0x2d59
0x002d59:	ldr     	r3, [pc, #0x3c8]
0x002d5b:	str     	r1, [sp]
0x002d5d:	str     	r1, [sp, #4]
0x002d5f:	str     	r2, [sp, #8]
0x002d61:	add     	r3, pc
0x002d63:	adds    	r2, r0, #0
0x002d65:	movs    	r0, #0xf1
0x002d67:	movs    	r1, #0x2d
0x002d69:	lsls    	r0, r0, #9
0x002d6b:	bl      	#0x4c2d
; block 0x2d6f
0x002d6f:	movs    	r1, #0
0x002d71:	movs    	r2, #0
0x002d73:	str     	r2, [sp, #8]
0x002d75:	str     	r1, [sp]
0x002d77:	str     	r1, [sp, #4]
0x002d79:	str     	r0, [sp, #0x30]
0x002d7b:	adds    	r3, r7, #0
0x002d7d:	adds    	r2, r4, #0
0x002d7f:	movs    	r0, #0xf1
0x002d81:	movs    	r1, #9
0x002d83:	lsls    	r0, r0, #9
0x002d85:	bl      	#0x4c2d
; block 0x2d89
0x002d89:	movs    	r1, #0
0x002d8b:	ldr     	r0, [pc, #0x39c]
0x002d8d:	str     	r1, [sp]
0x002d8f:	str     	r1, [sp, #4]
0x002d91:	movs    	r2, #0
0x002d93:	str     	r2, [sp, #8]
0x002d95:	movs    	r3, #5
0x002d97:	add     	r0, sb
0x002d99:	ldrsb   	r2, [r0, r3]
0x002d9b:	movs    	r0, #0xf1
0x002d9d:	movs    	r1, #0x3f
0x002d9f:	lsls    	r0, r0, #9
0x002da1:	b       	#0x2da5
; block 0x2da3
0x002da3:	b       	#0x2dfb
; block 0x2da5
0x002da5:	adds    	r3, r7, #0
0x002da7:	bl      	#0x4c2d
; block 0x2dab
0x002dab:	movs    	r1, #0
0x002dad:	adds    	r4, r0, #0
0x002daf:	movs    	r2, #0
0x002db1:	adds    	r3, r0, #0
0x002db3:	str     	r1, [sp]
0x002db5:	str     	r1, [sp, #4]
0x002db7:	movs    	r1, #0x2d
0x002db9:	movs    	r0, #0xf1
0x002dbb:	str     	r2, [sp, #8]
0x002dbd:	ldr     	r2, [sp, #0x30]
0x002dbf:	lsls    	r0, r0, #9
0x002dc1:	bl      	#0x4c2d
; block 0x2dc5
0x002dc5:	movs    	r1, #0
0x002dc7:	movs    	r2, #0
0x002dc9:	str     	r2, [sp, #8]
0x002dcb:	str     	r1, [sp]
0x002dcd:	str     	r1, [sp, #4]
0x002dcf:	str     	r0, [sp, #0x30]
0x002dd1:	adds    	r3, r7, #0
0x002dd3:	adds    	r2, r4, #0
0x002dd5:	movs    	r0, #0xf1
0x002dd7:	movs    	r1, #9
0x002dd9:	lsls    	r0, r0, #9
0x002ddb:	bl      	#0x4c2d
; block 0x2ddf
0x002ddf:	movs    	r2, #0
0x002de1:	movs    	r1, #0
0x002de3:	ldr     	r3, [pc, #0x348]
0x002de5:	str     	r1, [sp]
0x002de7:	str     	r1, [sp, #4]
0x002de9:	str     	r2, [sp, #8]
0x002deb:	add     	r3, pc
0x002ded:	movs    	r1, #0x2d
0x002def:	movs    	r0, #0xf1
0x002df1:	lsls    	r0, r0, #9
0x002df3:	ldr     	r2, [sp, #0x30]
0x002df5:	bl      	#0x4c2d
; block 0x2df9
0x002df9:	adds    	r4, r0, #0
0x002dfb:	movs    	r1, #0
0x002dfd:	str     	r1, [sp]
0x002dff:	str     	r1, [sp, #4]
0x002e01:	movs    	r2, #0
0x002e03:	movs    	r1, #0x1c
0x002e05:	movs    	r3, #0
0x002e07:	adds    	r0, r6, #0
0x002e09:	str     	r2, [sp, #8]
0x002e0b:	bl      	#0x4c2d
; block 0x2dfb
0x002dfb:	movs    	r1, #0
0x002dfd:	str     	r1, [sp]
0x002dff:	str     	r1, [sp, #4]
0x002e01:	movs    	r2, #0
0x002e03:	movs    	r1, #0x1c
0x002e05:	movs    	r3, #0
0x002e07:	adds    	r0, r6, #0
0x002e09:	str     	r2, [sp, #8]
0x002e0b:	bl      	#0x4c2d
; block 0x2e0f
0x002e0f:	movs    	r2, #0
0x002e11:	str     	r0, [sp]
0x002e13:	movs    	r0, #0xf1
0x002e15:	str     	r2, [sp, #8]
0x002e17:	movs    	r1, #0x2f
0x002e19:	lsls    	r0, r0, #9
0x002e1b:	ldr     	r3, [sp, #0x48]
0x002e1d:	str     	r5, [sp, #4]
0x002e1f:	bl      	#0x4c2d
; block 0x2e23
0x002e23:	cmp     	r0, #1
0x002e25:	bne     	#0x2e45
; block 0x2e27
0x002e27:	ldr     	r0, [pc, #0x300]
0x002e29:	add     	r0, sb
0x002e2b:	ldr     	r1, [r0, #0x24]
0x002e2d:	cmp     	r1, #0
0x002e2f:	bne     	#0x2f17
; block 0x2e31
0x002e31:	movs    	r2, #0
0x002e33:	str     	r2, [sp, #8]
0x002e35:	str     	r1, [sp]
0x002e37:	str     	r1, [sp, #4]
0x002e39:	movs    	r1, #0x9c
0x002e3b:	movs    	r2, #0x11
0x002e3d:	movs    	r3, #0
0x002e3f:	adds    	r0, r6, #0
0x002e41:	bl      	#0x4c2d
; block 0x2e45
0x002e45:	ldr     	r0, [pc, #0x2e0]
0x002e47:	add     	r0, sb
0x002e49:	ldr     	r0, [r0, #0x24]
0x002e4b:	cmp     	r0, #0
0x002e4d:	bne     	#0x2e77
; block 0x2e4f
0x002e4f:	movs    	r1, #0
0x002e51:	str     	r1, [sp]
0x002e53:	str     	r1, [sp, #4]
0x002e55:	movs    	r2, #0
0x002e57:	movs    	r1, #0x1c
0x002e59:	movs    	r3, #0
0x002e5b:	adds    	r0, r6, #0
0x002e5d:	str     	r2, [sp, #8]
0x002e5f:	bl      	#0x4c2d
; block 0x2e63
0x002e63:	movs    	r2, #0
0x002e65:	str     	r0, [sp]
0x002e67:	movs    	r0, #0xf1
0x002e69:	str     	r2, [sp, #8]
0x002e6b:	movs    	r1, #0x30
0x002e6d:	lsls    	r0, r0, #9
0x002e6f:	ldr     	r3, [sp, #0x48]
0x002e71:	str     	r5, [sp, #4]
0x002e73:	bl      	#0x4c2d
; block 0x2e77
0x002e77:	movs    	r1, #0
0x002e79:	movs    	r2, #0
0x002e7b:	str     	r2, [sp, #8]
0x002e7d:	str     	r1, [sp]
0x002e7f:	str     	r1, [sp, #4]
0x002e81:	movs    	r1, #0xe1
0x002e83:	movs    	r2, #0x28
0x002e85:	movs    	r3, #0
0x002e87:	movs    	r0, #0xf1
0x002e89:	lsls    	r0, r0, #9
0x002e8b:	bl      	#0x4c2d
; block 0x2e8f
0x002e8f:	movs    	r1, #0
0x002e91:	movs    	r2, #0
0x002e93:	str     	r2, [sp, #8]
0x002e95:	str     	r1, [sp]
0x002e97:	str     	r1, [sp, #4]
0x002e99:	adds    	r6, r0, #0
0x002e9b:	movs    	r0, #0xf1
0x002e9d:	movs    	r1, #0xe1
0x002e9f:	movs    	r2, #0x29
0x002ea1:	movs    	r3, #0
0x002ea3:	lsls    	r0, r0, #9
0x002ea5:	bl      	#0x4c2d
; block 0x2ea9
0x002ea9:	adds    	r3, r0, #0
0x002eab:	add     	r2, sp, #0x4c
0x002ead:	add     	r1, sp, #0x50
0x002eaf:	str     	r1, [sp, #4]
0x002eb1:	str     	r2, [sp, #8]
0x002eb3:	adds    	r2, r4, #0
0x002eb5:	movs    	r1, #0x2a
0x002eb7:	movs    	r0, #0xf1
0x002eb9:	lsls    	r0, r0, #9
0x002ebb:	str     	r6, [sp]
0x002ebd:	bl      	#0x4c2d
; block 0x2ec1
0x002ec1:	ldr     	r0, [sp, #0x4c]
0x002ec3:	movs    	r2, #0
0x002ec5:	subs    	r0, r5, r0
0x002ec7:	asrs    	r0, r0, #1
0x002ec9:	adds    	r0, #0x7d
0x002ecb:	movs    	r1, #0
0x002ecd:	str     	r1, [sp, #4]
0x002ecf:	str     	r2, [sp, #8]
0x002ed1:	adds    	r2, r4, #0
0x002ed3:	movs    	r1, #0xff
0x002ed5:	str     	r0, [sp]
0x002ed7:	movs    	r0, #0xf1
0x002ed9:	adds    	r1, #0x38
0x002edb:	movs    	r3, #0xa
0x002edd:	lsls    	r0, r0, #9
0x002edf:	bl      	#0x4c2d
; block 0x2ee3
0x002ee3:	ldr     	r0, [pc, #0x244]
0x002ee5:	movs    	r4, #0x8e
0x002ee7:	add     	r0, sb
0x002ee9:	ldr     	r0, [r0, #0x1c]
0x002eeb:	cmp     	r0, #0
0x002eed:	beq     	#0x2fc5
; block 0x2eef
0x002eef:	ldr     	r3, [pc, #0x238]
0x002ef1:	add     	r3, sb
0x002ef3:	ldr     	r7, [r3, #0x14]
0x002ef5:	cmp     	r7, #0
0x002ef7:	beq     	#0x2f55
; block 0x2ef9
0x002ef9:	ldr     	r6, [pc, #0x234]
0x002efb:	add     	r6, pc
0x002efd:	movs    	r1, #0
0x002eff:	movs    	r2, #0
0x002f01:	str     	r2, [sp, #8]
0x002f03:	str     	r1, [sp]
0x002f05:	str     	r1, [sp, #4]
0x002f07:	movs    	r1, #0xb1
0x002f09:	adds    	r2, r7, #0
0x002f0b:	movs    	r0, #0xf1
0x002f0d:	lsls    	r0, r0, #9
0x002f0f:	ldr     	r3, [r7, #4]
0x002f11:	bl      	#0x4c2d
; block 0x2f15
0x002f15:	b       	#0x2f19
; block 0x2f17
0x002f17:	b       	#0x2f4f
; block 0x2f19
0x002f19:	movs    	r1, #0
0x002f1b:	adds    	r3, r0, #0
0x002f1d:	movs    	r2, #0
0x002f1f:	str     	r2, [sp, #8]
0x002f21:	str     	r1, [sp]
0x002f23:	str     	r1, [sp, #4]
0x002f25:	movs    	r1, #0x2d
0x002f27:	adds    	r2, r6, #0
0x002f29:	movs    	r0, #0xf1
0x002f2b:	lsls    	r0, r0, #9
0x002f2d:	bl      	#0x4c2d
; block 0x2f31
0x002f31:	movs    	r2, #0
0x002f33:	movs    	r1, #0
0x002f35:	ldr     	r3, [pc, #0x1fc]
0x002f37:	str     	r1, [sp]
0x002f39:	str     	r1, [sp, #4]
0x002f3b:	str     	r2, [sp, #8]
0x002f3d:	add     	r3, pc
0x002f3f:	adds    	r2, r0, #0
0x002f41:	movs    	r0, #0xf1
0x002f43:	movs    	r1, #0x2d
0x002f45:	lsls    	r0, r0, #9
0x002f47:	bl      	#0x4c2d
; block 0x2f4b
0x002f4b:	adds    	r6, r0, #0
0x002f4d:	b       	#0x2f59
; block 0x2f4f
0x002f4f:	movs    	r3, #0
0x002f51:	str     	r3, [r0, #0x24]
0x002f53:	b       	#0x2e4f
; block 0x2f55
0x002f55:	ldr     	r6, [pc, #0x1e0]
0x002f57:	add     	r6, pc
0x002f59:	movs    	r1, #0
0x002f5b:	str     	r1, [sp]
0x002f5d:	str     	r1, [sp, #4]
0x002f5f:	movs    	r2, #0
0x002f61:	movs    	r7, #0xf1
0x002f63:	lsls    	r7, r7, #9
0x002f65:	movs    	r1, #0x1c
0x002f67:	movs    	r3, #0
0x002f69:	adds    	r0, r7, #0
0x002f6b:	str     	r2, [sp, #8]
0x002f6d:	bl      	#0x4c2d
; block 0x2f59
0x002f59:	movs    	r1, #0
0x002f5b:	str     	r1, [sp]
0x002f5d:	str     	r1, [sp, #4]
0x002f5f:	movs    	r2, #0
0x002f61:	movs    	r7, #0xf1
0x002f63:	lsls    	r7, r7, #9
0x002f65:	movs    	r1, #0x1c
0x002f67:	movs    	r3, #0
0x002f69:	adds    	r0, r7, #0
0x002f6b:	str     	r2, [sp, #8]
0x002f6d:	bl      	#0x4c2d
; block 0x2f71
0x002f71:	movs    	r2, #0
0x002f73:	str     	r0, [sp]
0x002f75:	adds    	r3, r4, #0
0x002f77:	movs    	r1, #0x2f
0x002f79:	adds    	r0, r7, #0
0x002f7b:	str     	r2, [sp, #8]
0x002f7d:	str     	r5, [sp, #4]
0x002f7f:	bl      	#0x4c2d
; block 0x2f83
0x002f83:	cmp     	r0, #1
0x002f85:	bne     	#0x2fb7
; block 0x2f87
0x002f87:	ldr     	r3, [pc, #0x1a0]
0x002f89:	add     	r3, sb
0x002f8b:	ldr     	r1, [r3, #0x1c]
0x002f8d:	cmp     	r1, #0
0x002f8f:	bne     	#0x2f95
; block 0x2f91
0x002f91:	rsbs    	r0, r0, #0
0x002f93:	b       	#0x2f97
; block 0x2f95
0x002f95:	movs    	r0, #1
0x002f97:	ldr     	r2, [r3, #0x24]
0x002f99:	cmp     	r0, r2
0x002f9b:	bne     	#0x2fb5
; block 0x2f97
0x002f97:	ldr     	r2, [r3, #0x24]
0x002f99:	cmp     	r0, r2
0x002f9b:	bne     	#0x2fb5
; block 0x2f9d
0x002f9d:	movs    	r1, #0
0x002f9f:	movs    	r2, #0
0x002fa1:	str     	r2, [sp, #8]
0x002fa3:	str     	r1, [sp]
0x002fa5:	str     	r1, [sp, #4]
0x002fa7:	movs    	r1, #0x9c
0x002fa9:	movs    	r2, #0x11
0x002fab:	movs    	r3, #0
0x002fad:	adds    	r0, r7, #0
0x002faf:	bl      	#0x4c2d
; block 0x2fb3
0x002fb3:	b       	#0x2fb7
; block 0x2fb5
0x002fb5:	str     	r0, [r3, #0x24]
0x002fb7:	ldr     	r3, [pc, #0x170]
0x002fb9:	add     	r3, sb
0x002fbb:	ldr     	r0, [r3, #0x1c]
0x002fbd:	cmp     	r0, #0
0x002fbf:	bne     	#0x2fc7
; block 0x2fb7
0x002fb7:	ldr     	r3, [pc, #0x170]
0x002fb9:	add     	r3, sb
0x002fbb:	ldr     	r0, [r3, #0x1c]
0x002fbd:	cmp     	r0, #0
0x002fbf:	bne     	#0x2fc7
; block 0x2fc1
0x002fc1:	mvns    	r0, r0
0x002fc3:	b       	#0x2fc9
; block 0x2fc5
0x002fc5:	b       	#0x3063
; block 0x2fc7
0x002fc7:	movs    	r0, #1
0x002fc9:	ldr     	r1, [r3, #0x24]
0x002fcb:	cmp     	r0, r1
0x002fcd:	bne     	#0x2ff7
; block 0x2fc9
0x002fc9:	ldr     	r1, [r3, #0x24]
0x002fcb:	cmp     	r0, r1
0x002fcd:	bne     	#0x2ff7
; block 0x2fcf
0x002fcf:	movs    	r1, #0
0x002fd1:	str     	r1, [sp]
0x002fd3:	str     	r1, [sp, #4]
0x002fd5:	movs    	r2, #0
0x002fd7:	movs    	r1, #0x1c
0x002fd9:	movs    	r3, #0
0x002fdb:	adds    	r0, r7, #0
0x002fdd:	str     	r2, [sp, #8]
0x002fdf:	bl      	#0x4c2d
; block 0x2fe3
0x002fe3:	movs    	r2, #0
0x002fe5:	str     	r0, [sp]
0x002fe7:	movs    	r0, #0xf1
0x002fe9:	adds    	r3, r4, #0
0x002feb:	movs    	r1, #0x30
0x002fed:	lsls    	r0, r0, #9
0x002fef:	str     	r2, [sp, #8]
0x002ff1:	str     	r5, [sp, #4]
0x002ff3:	bl      	#0x4c2d
; block 0x2ff7
0x002ff7:	movs    	r1, #0
0x002ff9:	movs    	r2, #0
0x002ffb:	str     	r2, [sp, #8]
0x002ffd:	str     	r1, [sp]
0x002fff:	str     	r1, [sp, #4]
0x003001:	movs    	r1, #0xe1
0x003003:	movs    	r2, #0x28
0x003005:	movs    	r3, #0
0x003007:	adds    	r0, r7, #0
0x003009:	bl      	#0x4c2d
; block 0x300d
0x00300d:	movs    	r1, #0
0x00300f:	movs    	r2, #0
0x003011:	str     	r2, [sp, #8]
0x003013:	str     	r1, [sp]
0x003015:	str     	r1, [sp, #4]
0x003017:	adds    	r4, r0, #0
0x003019:	movs    	r0, #0xf1
0x00301b:	movs    	r1, #0xe1
0x00301d:	movs    	r2, #0x29
0x00301f:	movs    	r3, #0
0x003021:	lsls    	r0, r0, #9
0x003023:	bl      	#0x4c2d
; block 0x3027
0x003027:	adds    	r3, r0, #0
0x003029:	add     	r2, sp, #0x4c
0x00302b:	add     	r1, sp, #0x50
0x00302d:	str     	r1, [sp, #4]
0x00302f:	str     	r2, [sp, #8]
0x003031:	adds    	r2, r6, #0
0x003033:	movs    	r1, #0x2a
0x003035:	movs    	r0, #0xf1
0x003037:	lsls    	r0, r0, #9
0x003039:	str     	r4, [sp]
0x00303b:	bl      	#0x4c2d
; block 0x303f
0x00303f:	ldr     	r0, [sp, #0x4c]
0x003041:	movs    	r2, #0
0x003043:	subs    	r0, r5, r0
0x003045:	asrs    	r0, r0, #1
0x003047:	adds    	r0, #0x8e
0x003049:	movs    	r1, #0
0x00304b:	str     	r1, [sp, #4]
0x00304d:	str     	r2, [sp, #8]
0x00304f:	adds    	r2, r6, #0
0x003051:	movs    	r1, #0xff
0x003053:	str     	r0, [sp]
0x003055:	movs    	r0, #0xf1
0x003057:	adds    	r1, #0x38
0x003059:	movs    	r3, #0xa
0x00305b:	lsls    	r0, r0, #9
0x00305d:	bl      	#0x4c2d
; block 0x3061
0x003061:	movs    	r4, #0x9f
0x003063:	ldr     	r0, [pc, #0xc4]
0x003065:	add     	r0, sb
0x003067:	ldr     	r0, [r0, #0x20]
0x003069:	cmp     	r0, #0
0x00306b:	beq     	#0x3121
; block 0x3063
0x003063:	ldr     	r0, [pc, #0xc4]
0x003065:	add     	r0, sb
0x003067:	ldr     	r0, [r0, #0x20]
0x003069:	cmp     	r0, #0
0x00306b:	beq     	#0x3121
; block 0x306d
0x00306d:	ldr     	r2, [pc, #0xb8]
0x00306f:	add     	r2, sb
0x003071:	ldr     	r7, [r2, #0x18]
0x003073:	cmp     	r7, #0
0x003075:	beq     	#0x30c9
; block 0x3077
0x003077:	ldr     	r6, [pc, #0xc4]
0x003079:	add     	r6, pc
0x00307b:	movs    	r1, #0
0x00307d:	movs    	r2, #0
0x00307f:	str     	r2, [sp, #8]
0x003081:	str     	r1, [sp]
0x003083:	str     	r1, [sp, #4]
0x003085:	movs    	r1, #0xb1
0x003087:	adds    	r2, r7, #0
0x003089:	movs    	r0, #0xf1
0x00308b:	lsls    	r0, r0, #9
0x00308d:	ldr     	r3, [r7, #4]
0x00308f:	bl      	#0x4c2d
; block 0x3093
0x003093:	movs    	r1, #0
0x003095:	adds    	r3, r0, #0
0x003097:	movs    	r2, #0
0x003099:	str     	r2, [sp, #8]
0x00309b:	str     	r1, [sp]
0x00309d:	str     	r1, [sp, #4]
0x00309f:	movs    	r1, #0x2d
0x0030a1:	adds    	r2, r6, #0
0x0030a3:	movs    	r0, #0xf1
0x0030a5:	lsls    	r0, r0, #9
0x0030a7:	bl      	#0x4c2d
; block 0x30ab
0x0030ab:	movs    	r2, #0
0x0030ad:	movs    	r1, #0
0x0030af:	ldr     	r3, [pc, #0x90]
0x0030b1:	str     	r1, [sp]
0x0030b3:	str     	r1, [sp, #4]
0x0030b5:	str     	r2, [sp, #8]
0x0030b7:	add     	r3, pc
0x0030b9:	adds    	r2, r0, #0
0x0030bb:	movs    	r0, #0xf1
0x0030bd:	movs    	r1, #0x2d
0x0030bf:	lsls    	r0, r0, #9
0x0030c1:	bl      	#0x4c2d
; block 0x30c5
0x0030c5:	adds    	r6, r0, #0
0x0030c7:	b       	#0x30cd
; block 0x30c9
0x0030c9:	ldr     	r6, [pc, #0x78]
0x0030cb:	add     	r6, pc
0x0030cd:	movs    	r1, #0
0x0030cf:	str     	r1, [sp]
0x0030d1:	str     	r1, [sp, #4]
0x0030d3:	movs    	r2, #0
0x0030d5:	movs    	r7, #0xf1
0x0030d7:	lsls    	r7, r7, #9
0x0030d9:	movs    	r1, #0x1c
0x0030db:	movs    	r3, #0
0x0030dd:	adds    	r0, r7, #0
0x0030df:	str     	r2, [sp, #8]
0x0030e1:	bl      	#0x4c2d
; block 0x30cd
0x0030cd:	movs    	r1, #0
0x0030cf:	str     	r1, [sp]
0x0030d1:	str     	r1, [sp, #4]
0x0030d3:	movs    	r2, #0
0x0030d5:	movs    	r7, #0xf1
0x0030d7:	lsls    	r7, r7, #9
0x0030d9:	movs    	r1, #0x1c
0x0030db:	movs    	r3, #0
0x0030dd:	adds    	r0, r7, #0
0x0030df:	str     	r2, [sp, #8]
0x0030e1:	bl      	#0x4c2d
; block 0x30e5
0x0030e5:	movs    	r2, #0
0x0030e7:	str     	r0, [sp]
0x0030e9:	adds    	r3, r4, #0
0x0030eb:	movs    	r1, #0x2f
0x0030ed:	adds    	r0, r7, #0
0x0030ef:	str     	r2, [sp, #8]
0x0030f1:	str     	r5, [sp, #4]
0x0030f3:	bl      	#0x4c2d
; block 0x30f7
0x0030f7:	cmp     	r0, #1
0x0030f9:	bne     	#0x314f
; block 0x30fb
0x0030fb:	bl      	#0x3635
; block 0x30ff
0x0030ff:	ldr     	r2, [pc, #0x28]
0x003101:	add     	r2, sb
0x003103:	ldr     	r1, [r2, #0x24]
0x003105:	cmp     	r0, r1
0x003107:	bne     	#0x3149
; block 0x3109
0x003109:	movs    	r1, #0
0x00310b:	movs    	r2, #0
0x00310d:	str     	r2, [sp, #8]
0x00310f:	str     	r1, [sp]
0x003111:	str     	r1, [sp, #4]
0x003113:	movs    	r1, #0x9c
0x003115:	movs    	r2, #0x11
0x003117:	movs    	r3, #0
0x003119:	adds    	r0, r7, #0
0x00311b:	bl      	#0x4c2d
; block 0x311f
0x00311f:	b       	#0x314f
; block 0x3121
0x003121:	b       	#0x31f1
; block 0x3123
0x003123:	b       	#0x3631
; block 0x3149
0x003149:	bl      	#0x3635
; block 0x314d
0x00314d:	str     	r0, [r2, #0x24]
0x00314f:	bl      	#0x3635
; block 0x314f
0x00314f:	bl      	#0x3635
; block 0x3153
0x003153:	ldr     	r2, [pc, #0x3dc]
0x003155:	add     	r2, sb
0x003157:	ldr     	r1, [r2, #0x24]
0x003159:	cmp     	r0, r1
0x00315b:	bne     	#0x3185
; block 0x315d
0x00315d:	movs    	r1, #0
0x00315f:	str     	r1, [sp]
0x003161:	str     	r1, [sp, #4]
0x003163:	movs    	r2, #0
0x003165:	movs    	r1, #0x1c
0x003167:	movs    	r3, #0
0x003169:	adds    	r0, r7, #0
0x00316b:	str     	r2, [sp, #8]
0x00316d:	bl      	#0x4c2d
; block 0x3171
0x003171:	movs    	r2, #0
0x003173:	str     	r0, [sp]
0x003175:	movs    	r0, #0xf1
0x003177:	adds    	r3, r4, #0
0x003179:	movs    	r1, #0x30
0x00317b:	lsls    	r0, r0, #9
0x00317d:	str     	r2, [sp, #8]
0x00317f:	str     	r5, [sp, #4]
0x003181:	bl      	#0x4c2d
; block 0x3185
0x003185:	movs    	r1, #0
0x003187:	movs    	r2, #0
0x003189:	str     	r2, [sp, #8]
0x00318b:	str     	r1, [sp]
0x00318d:	str     	r1, [sp, #4]
0x00318f:	movs    	r1, #0xe1
0x003191:	movs    	r2, #0x28
0x003193:	movs    	r3, #0
0x003195:	adds    	r0, r7, #0
0x003197:	bl      	#0x4c2d
; block 0x319b
0x00319b:	movs    	r1, #0
0x00319d:	movs    	r2, #0
0x00319f:	str     	r2, [sp, #8]
0x0031a1:	str     	r1, [sp]
0x0031a3:	str     	r1, [sp, #4]
0x0031a5:	adds    	r7, r0, #0
0x0031a7:	movs    	r0, #0xf1
0x0031a9:	movs    	r1, #0xe1
0x0031ab:	movs    	r2, #0x29
0x0031ad:	movs    	r3, #0
0x0031af:	lsls    	r0, r0, #9
0x0031b1:	bl      	#0x4c2d
; block 0x31b5
0x0031b5:	adds    	r3, r0, #0
0x0031b7:	add     	r2, sp, #0x4c
0x0031b9:	add     	r1, sp, #0x50
0x0031bb:	str     	r1, [sp, #4]
0x0031bd:	str     	r2, [sp, #8]
0x0031bf:	adds    	r2, r6, #0
0x0031c1:	movs    	r1, #0x2a
0x0031c3:	movs    	r0, #0xf1
0x0031c5:	lsls    	r0, r0, #9
0x0031c7:	str     	r7, [sp]
0x0031c9:	bl      	#0x4c2d
; block 0x31cd
0x0031cd:	ldr     	r0, [sp, #0x4c]
0x0031cf:	movs    	r2, #0
0x0031d1:	subs    	r0, r5, r0
0x0031d3:	asrs    	r0, r0, #1
0x0031d5:	adds    	r0, r0, r4
0x0031d7:	movs    	r1, #0
0x0031d9:	str     	r1, [sp, #4]
0x0031db:	str     	r2, [sp, #8]
0x0031dd:	adds    	r2, r6, #0
0x0031df:	movs    	r1, #0xff
0x0031e1:	str     	r0, [sp]
0x0031e3:	movs    	r0, #0xf1
0x0031e5:	adds    	r1, #0x38
0x0031e7:	movs    	r3, #0xa
0x0031e9:	lsls    	r0, r0, #9
0x0031eb:	bl      	#0x4c2d
; block 0x31ef
0x0031ef:	adds    	r4, #0x11
0x0031f1:	ldr     	r1, [pc, #0x33c]
0x0031f3:	add     	r1, sb
0x0031f5:	ldr     	r6, [r1, #0x34]
0x0031f7:	cmp     	r6, #0
0x0031f9:	beq     	#0x32e1
; block 0x31f1
0x0031f1:	ldr     	r1, [pc, #0x33c]
0x0031f3:	add     	r1, sb
0x0031f5:	ldr     	r6, [r1, #0x34]
0x0031f7:	cmp     	r6, #0
0x0031f9:	beq     	#0x32e1
; block 0x31fb
0x0031fb:	movs    	r1, #0
0x0031fd:	movs    	r2, #0
0x0031ff:	str     	r2, [sp, #8]
0x003201:	str     	r1, [sp]
0x003203:	str     	r1, [sp, #4]
0x003205:	movs    	r7, #0xf1
0x003207:	lsls    	r7, r7, #9
0x003209:	movs    	r1, #0x11
0x00320b:	adds    	r2, r6, #0
0x00320d:	movs    	r3, #4
0x00320f:	adds    	r0, r7, #0
0x003211:	bl      	#0x4c2d
; block 0x3215
0x003215:	movs    	r6, #0
0x003217:	cmp     	r0, #0
0x003219:	str     	r0, [sp, #0x2c]
0x00321b:	ble     	#0x32e1
; block 0x321d
0x00321d:	ldr     	r1, [pc, #0x310]
0x00321f:	lsls    	r0, r6, #2
0x003221:	add     	r1, sb
0x003223:	ldr     	r1, [r1, #0x34]
0x003225:	ldr     	r0, [r1, r0]
0x003227:	bl      	#0x36dd
; block 0x322b
0x00322b:	movs    	r1, #0
0x00322d:	movs    	r2, #0
0x00322f:	str     	r2, [sp, #8]
0x003231:	str     	r1, [sp]
0x003233:	str     	r1, [sp, #4]
0x003235:	adds    	r7, r0, #0
0x003237:	movs    	r0, #0xf1
0x003239:	movs    	r1, #0xe1
0x00323b:	movs    	r2, #0x28
0x00323d:	movs    	r3, #0
0x00323f:	lsls    	r0, r0, #9
0x003241:	bl      	#0x4c2d
; block 0x3245
0x003245:	str     	r0, [sp, #0x28]
0x003247:	movs    	r1, #0
0x003249:	movs    	r2, #0
0x00324b:	str     	r2, [sp, #8]
0x00324d:	str     	r1, [sp]
0x00324f:	str     	r1, [sp, #4]
0x003251:	movs    	r1, #0xe1
0x003253:	movs    	r2, #0x29
0x003255:	movs    	r0, #0xf1
0x003257:	movs    	r3, #0
0x003259:	lsls    	r0, r0, #9
0x00325b:	bl      	#0x4c2d
; block 0x325f
0x00325f:	adds    	r3, r0, #0
0x003261:	ldr     	r0, [sp, #0x28]
0x003263:	add     	r2, sp, #0x4c
0x003265:	add     	r1, sp, #0x50
0x003267:	str     	r1, [sp, #4]
0x003269:	str     	r2, [sp, #8]
0x00326b:	str     	r0, [sp]
0x00326d:	movs    	r0, #0xf1
0x00326f:	adds    	r2, r7, #0
0x003271:	movs    	r1, #0x2a
0x003273:	lsls    	r0, r0, #9
0x003275:	bl      	#0x4c2d
; block 0x3279
0x003279:	movs    	r0, #0xa
0x00327b:	str     	r0, [sp, #0x10]
0x00327d:	str     	r7, [sp, #0xc]
0x00327f:	ldr     	r0, [sp, #0x4c]
0x003281:	movs    	r1, #0
0x003283:	subs    	r0, r5, r0
0x003285:	asrs    	r0, r0, #1
0x003287:	adds    	r0, r0, r4
0x003289:	str     	r0, [sp, #0x14]
0x00328b:	movs    	r0, #0xff
0x00328d:	str     	r0, [sp, #0x18]
0x00328f:	str     	r0, [sp, #0x1c]
0x003291:	movs    	r0, #0xc8
0x003293:	str     	r0, [sp, #0x20]
0x003295:	movs    	r2, #0
0x003297:	str     	r2, [sp, #8]
0x003299:	str     	r1, [sp]
0x00329b:	str     	r1, [sp, #4]
0x00329d:	movs    	r1, #0xe1
0x00329f:	movs    	r2, #0x29
0x0032a1:	movs    	r0, #0xf1
0x0032a3:	movs    	r3, #0
0x0032a5:	lsls    	r0, r0, #9
0x0032a7:	bl      	#0x4c2d
; block 0x32ab
0x0032ab:	str     	r0, [sp, #0x24]
0x0032ad:	movs    	r1, #0
0x0032af:	movs    	r2, #0
0x0032b1:	str     	r2, [sp, #8]
0x0032b3:	str     	r1, [sp]
0x0032b5:	str     	r1, [sp, #4]
0x0032b7:	movs    	r1, #0xe1
0x0032b9:	movs    	r2, #0x28
0x0032bb:	movs    	r0, #0xf1
0x0032bd:	movs    	r3, #0
0x0032bf:	lsls    	r0, r0, #9
0x0032c1:	bl      	#0x4c2d
; block 0x32c5
0x0032c5:	str     	r0, [sp, #0x28]
0x0032c7:	movs    	r1, #0
0x0032c9:	movs    	r2, #0
0x0032cb:	str     	r1, [sp]
0x0032cd:	str     	r1, [sp, #4]
0x0032cf:	movs    	r1, #0x56
0x0032d1:	str     	r2, [sp, #8]
0x0032d3:	movs    	r0, #0xf1
0x0032d5:	movs    	r3, #0
0x0032d7:	lsls    	r0, r0, #9
0x0032d9:	add     	r2, sp, #0xc
0x0032db:	bl      	#0x4c2d
; block 0x32df
0x0032df:	b       	#0x32e3
; block 0x32e1
0x0032e1:	b       	#0x32ed
; block 0x32e3
0x0032e3:	ldr     	r0, [sp, #0x2c]
0x0032e5:	adds    	r4, r4, r5
0x0032e7:	adds    	r6, #1
0x0032e9:	cmp     	r6, r0
0x0032eb:	blt     	#0x321d
; block 0x32ed
0x0032ed:	ldr     	r1, [pc, #0x240]
0x0032ef:	add     	r1, sb
0x0032f1:	ldr     	r0, [r1, #0x64]
0x0032f3:	adds    	r3, r0, #1
0x0032f5:	beq     	#0x33db
; block 0x32f7
0x0032f7:	bl      	#0x3931
; block 0x32fb
0x0032fb:	movs    	r2, #0
0x0032fd:	adds    	r3, r0, #0
0x0032ff:	movs    	r1, #0
0x003301:	str     	r2, [sp, #8]
0x003303:	ldr     	r2, [pc, #0x230]
0x003305:	str     	r1, [sp]
0x003307:	str     	r1, [sp, #4]
0x003309:	add     	r2, pc
0x00330b:	movs    	r1, #0x2d
0x00330d:	movs    	r0, #0xf1
0x00330f:	lsls    	r0, r0, #9
0x003311:	bl      	#0x4c2d
; block 0x3315
0x003315:	movs    	r1, #0
0x003317:	str     	r1, [sp]
0x003319:	str     	r1, [sp, #4]
0x00331b:	ldr     	r1, [pc, #0x214]
0x00331d:	movs    	r2, #0
0x00331f:	str     	r2, [sp, #8]
0x003321:	adds    	r6, r0, #0
0x003323:	add     	r1, sb
0x003325:	ldr     	r2, [r1, #0x68]
0x003327:	movs    	r7, #0
0x003329:	adds    	r3, r7, #0
0x00332b:	movs    	r1, #0x3f
0x00332d:	movs    	r0, #0xf1
0x00332f:	lsls    	r0, r0, #9
0x003331:	bl      	#0x4c2d
; block 0x3335
0x003335:	movs    	r2, #0
0x003337:	movs    	r1, #0
0x003339:	ldr     	r3, [pc, #0x1fc]
0x00333b:	str     	r1, [sp]
0x00333d:	str     	r1, [sp, #4]
0x00333f:	str     	r2, [sp, #8]
0x003341:	str     	r0, [sp, #0x2c]
0x003343:	add     	r3, pc
0x003345:	adds    	r2, r6, #0
0x003347:	movs    	r1, #0x2d
0x003349:	movs    	r0, #0xf1
0x00334b:	lsls    	r0, r0, #9
0x00334d:	bl      	#0x4c2d
; block 0x3351
0x003351:	movs    	r2, #0
0x003353:	movs    	r1, #0
0x003355:	str     	r2, [sp, #8]
0x003357:	adds    	r2, r0, #0
0x003359:	str     	r1, [sp]
0x00335b:	str     	r1, [sp, #4]
0x00335d:	movs    	r1, #0x2d
0x00335f:	movs    	r0, #0xf1
0x003361:	lsls    	r0, r0, #9
0x003363:	ldr     	r3, [sp, #0x2c]
0x003365:	bl      	#0x4c2d
; block 0x3369
0x003369:	movs    	r1, #0
0x00336b:	adds    	r6, r0, #0
0x00336d:	movs    	r2, #0
0x00336f:	str     	r1, [sp]
0x003371:	str     	r1, [sp, #4]
0x003373:	movs    	r1, #9
0x003375:	str     	r2, [sp, #8]
0x003377:	movs    	r0, #0xf1
0x003379:	adds    	r3, r7, #0
0x00337b:	lsls    	r0, r0, #9
0x00337d:	ldr     	r2, [sp, #0x2c]
0x00337f:	bl      	#0x4c2d
; block 0x3383
0x003383:	movs    	r1, #0
0x003385:	movs    	r2, #0
0x003387:	str     	r2, [sp, #8]
0x003389:	str     	r1, [sp]
0x00338b:	str     	r1, [sp, #4]
0x00338d:	movs    	r1, #0xe1
0x00338f:	movs    	r2, #0x28
0x003391:	adds    	r3, r7, #0
0x003393:	movs    	r0, #0xf1
0x003395:	lsls    	r0, r0, #9
0x003397:	bl      	#0x4c2d
; block 0x339b
0x00339b:	str     	r0, [sp, #0x28]
0x00339d:	movs    	r1, #0
0x00339f:	movs    	r2, #0
0x0033a1:	str     	r2, [sp, #8]
0x0033a3:	str     	r1, [sp]
0x0033a5:	str     	r1, [sp, #4]
0x0033a7:	movs    	r1, #0xe1
0x0033a9:	movs    	r2, #0x29
0x0033ab:	movs    	r0, #0xf1
0x0033ad:	adds    	r3, r7, #0
0x0033af:	lsls    	r0, r0, #9
0x0033b1:	bl      	#0x4c2d
; block 0x33b5
0x0033b5:	adds    	r3, r0, #0
0x0033b7:	ldr     	r0, [sp, #0x28]
0x0033b9:	add     	r2, sp, #0x4c
0x0033bb:	add     	r1, sp, #0x50
0x0033bd:	str     	r1, [sp, #4]
0x0033bf:	str     	r2, [sp, #8]
0x0033c1:	str     	r0, [sp]
0x0033c3:	movs    	r0, #0xf1
0x0033c5:	adds    	r2, r6, #0
0x0033c7:	movs    	r1, #0x2a
0x0033c9:	lsls    	r0, r0, #9
0x0033cb:	bl      	#0x4c2d
; block 0x33cf
0x0033cf:	movs    	r0, #0xa
0x0033d1:	str     	r0, [sp, #0x10]
0x0033d3:	str     	r6, [sp, #0xc]
0x0033d5:	ldr     	r0, [sp, #0x4c]
0x0033d7:	subs    	r0, r5, r0
0x0033d9:	b       	#0x33dd
; block 0x33db
0x0033db:	b       	#0x3439
; block 0x33dd
0x0033dd:	asrs    	r0, r0, #1
0x0033df:	adds    	r0, r0, r4
0x0033e1:	str     	r0, [sp, #0x14]
0x0033e3:	movs    	r0, #0xff
0x0033e5:	str     	r0, [sp, #0x18]
0x0033e7:	str     	r0, [sp, #0x1c]
0x0033e9:	movs    	r0, #0xc8
0x0033eb:	str     	r0, [sp, #0x20]
0x0033ed:	movs    	r1, #0
0x0033ef:	movs    	r2, #0
0x0033f1:	str     	r2, [sp, #8]
0x0033f3:	str     	r1, [sp]
0x0033f5:	str     	r1, [sp, #4]
0x0033f7:	movs    	r1, #0xe1
0x0033f9:	movs    	r2, #0x29
0x0033fb:	movs    	r0, #0xf1
0x0033fd:	adds    	r3, r7, #0
0x0033ff:	lsls    	r0, r0, #9
0x003401:	bl      	#0x4c2d
; block 0x3405
0x003405:	str     	r0, [sp, #0x24]
0x003407:	movs    	r1, #0
0x003409:	movs    	r2, #0
0x00340b:	str     	r2, [sp, #8]
0x00340d:	str     	r1, [sp]
0x00340f:	str     	r1, [sp, #4]
0x003411:	movs    	r1, #0xe1
0x003413:	movs    	r2, #0x28
0x003415:	movs    	r0, #0xf1
0x003417:	adds    	r3, r7, #0
0x003419:	lsls    	r0, r0, #9
0x00341b:	bl      	#0x4c2d
; block 0x341f
0x00341f:	str     	r0, [sp, #0x28]
0x003421:	movs    	r1, #0
0x003423:	movs    	r2, #0
0x003425:	str     	r1, [sp]
0x003427:	str     	r1, [sp, #4]
0x003429:	movs    	r1, #0x56
0x00342b:	str     	r2, [sp, #8]
0x00342d:	movs    	r0, #0xf1
0x00342f:	adds    	r3, r7, #0
0x003431:	lsls    	r0, r0, #9
0x003433:	add     	r2, sp, #0xc
0x003435:	bl      	#0x4c2d
; block 0x3439
0x003439:	bl      	#0x3979
; block 0x343d
0x00343d:	str     	r0, [sp, #0x1c]
0x00343f:	movs    	r0, #0xc8
0x003441:	movs    	r7, #0
0x003443:	str     	r0, [sp, #0x20]
0x003445:	movs    	r0, #1
0x003447:	str     	r7, [sp, #0x24]
0x003449:	str     	r7, [sp, #0x28]
0x00344b:	add     	r3, sp, #0x20
0x00344d:	strb    	r0, [r3, #0xc]
0x00344f:	strb    	r7, [r3, #0xd]
0x003451:	movs    	r1, #0
0x003453:	movs    	r2, #0
0x003455:	str     	r1, [sp]
0x003457:	str     	r1, [sp, #4]
0x003459:	movs    	r1, #0x41
0x00345b:	str     	r2, [sp, #8]
0x00345d:	adds    	r3, r7, #0
0x00345f:	movs    	r0, #0xf1
0x003461:	lsls    	r0, r0, #9
0x003463:	add     	r2, sp, #0x1c
0x003465:	bl      	#0x4c2d
; block 0x3469
0x003469:	ldr     	r0, [pc, #0xd0]
0x00346b:	add     	r0, pc
0x00346d:	str     	r0, [sp, #0x1c]
0x00346f:	movs    	r0, #0xc8
0x003471:	str     	r0, [sp, #0x20]
0x003473:	str     	r7, [sp, #0x24]
0x003475:	str     	r7, [sp, #0x28]
0x003477:	add     	r3, sp, #0x20
0x003479:	strb    	r7, [r3, #0xc]
0x00347b:	strb    	r7, [r3, #0xd]
0x00347d:	movs    	r1, #0
0x00347f:	movs    	r2, #0
0x003481:	str     	r1, [sp]
0x003483:	str     	r1, [sp, #4]
0x003485:	movs    	r1, #0x41
0x003487:	str     	r2, [sp, #8]
0x003489:	adds    	r3, r7, #0
0x00348b:	movs    	r0, #0xf1
0x00348d:	lsls    	r0, r0, #9
0x00348f:	add     	r2, sp, #0x1c
0x003491:	bl      	#0x4c2d
; block 0x3495
0x003495:	ldr     	r4, [pc, #0xa8]
0x003497:	add     	r4, pc
0x003499:	movs    	r1, #0
0x00349b:	movs    	r2, #0
0x00349d:	str     	r2, [sp, #8]
0x00349f:	str     	r1, [sp]
0x0034a1:	str     	r1, [sp, #4]
0x0034a3:	movs    	r1, #0xe1
0x0034a5:	movs    	r2, #0x28
0x0034a7:	adds    	r3, r7, #0
0x0034a9:	movs    	r0, #0xf1
0x0034ab:	lsls    	r0, r0, #9
0x0034ad:	bl      	#0x4c2d
; block 0x34b1
0x0034b1:	movs    	r1, #0
0x0034b3:	adds    	r5, r0, #0
0x0034b5:	movs    	r2, #0
0x0034b7:	str     	r2, [sp, #8]
0x0034b9:	str     	r1, [sp]
0x0034bb:	str     	r1, [sp, #4]
0x0034bd:	movs    	r1, #0xe1
0x0034bf:	movs    	r2, #0x29
0x0034c1:	movs    	r0, #0xf1
0x0034c3:	adds    	r3, r7, #0
0x0034c5:	lsls    	r0, r0, #9
0x0034c7:	bl      	#0x4c2d
; block 0x34cb
0x0034cb:	adds    	r3, r0, #0
0x0034cd:	add     	r2, sp, #0x4c
0x0034cf:	add     	r1, sp, #0x50
0x0034d1:	str     	r1, [sp, #4]
0x0034d3:	str     	r2, [sp, #8]
0x0034d5:	adds    	r2, r4, #0
0x0034d7:	movs    	r1, #0x2a
0x0034d9:	movs    	r0, #0xf1
0x0034db:	lsls    	r0, r0, #9
0x0034dd:	str     	r5, [sp]
0x0034df:	bl      	#0x4c2d
; block 0x34e3
0x0034e3:	ldr     	r5, [sp, #0x50]
0x0034e5:	ldr     	r6, [sp, #0x4c]
0x0034e7:	movs    	r1, #0
0x0034e9:	str     	r1, [sp]
0x0034eb:	str     	r1, [sp, #4]
0x0034ed:	movs    	r2, #0
0x0034ef:	adds    	r5, #0xa
0x0034f1:	adds    	r6, #6
0x0034f3:	adds    	r3, r7, #0
0x0034f5:	movs    	r1, #0x1d
0x0034f7:	movs    	r0, #0xf1
0x0034f9:	lsls    	r0, r0, #9
0x0034fb:	str     	r2, [sp, #8]
0x0034fd:	bl      	#0x4c2d
; block 0x3501
0x003501:	subs    	r0, r0, r6
0x003503:	movs    	r1, #0
0x003505:	str     	r1, [sp]
0x003507:	str     	r1, [sp, #4]
0x003509:	str     	r0, [sp, #0x2c]
0x00350b:	movs    	r2, #0
0x00350d:	movs    	r0, #0xf1
0x00350f:	movs    	r1, #0x1c
0x003511:	adds    	r3, r7, #0
0x003513:	lsls    	r0, r0, #9
0x003515:	str     	r2, [sp, #8]
0x003517:	bl      	#0x4c2d
; block 0x351b
0x00351b:	subs    	r0, r0, r5
0x00351d:	lsrs    	r1, r0, #0x1f
0x00351f:	adds    	r0, r1, r0
0x003521:	asrs    	r3, r0, #1
0x003523:	ldr     	r0, [sp, #0x2c]
0x003525:	movs    	r2, #4
0x003527:	movs    	r1, #0x23
0x003529:	str     	r5, [sp, #4]
0x00352b:	str     	r6, [sp, #8]
0x00352d:	str     	r0, [sp]
0x00352f:	b       	#0x3545
; block 0x3545
0x003545:	movs    	r0, #0xf1
0x003547:	lsls    	r0, r0, #9
0x003549:	bl      	#0x4c2d
; block 0x354d
0x00354d:	movs    	r1, #0
0x00354f:	str     	r1, [sp]
0x003551:	str     	r1, [sp, #4]
0x003553:	movs    	r2, #0
0x003555:	movs    	r1, #0x1d
0x003557:	adds    	r3, r7, #0
0x003559:	movs    	r0, #0xf1
0x00355b:	lsls    	r0, r0, #9
0x00355d:	str     	r2, [sp, #8]
0x00355f:	bl      	#0x4c2d
; block 0x3563
0x003563:	subs    	r3, r0, r6
0x003565:	movs    	r1, #0
0x003567:	str     	r1, [sp]
0x003569:	str     	r1, [sp, #4]
0x00356b:	str     	r3, [sp, #0x2c]
0x00356d:	movs    	r2, #0
0x00356f:	adds    	r3, r7, #0
0x003571:	movs    	r1, #0x1c
0x003573:	movs    	r0, #0xf1
0x003575:	lsls    	r0, r0, #9
0x003577:	str     	r2, [sp, #8]
0x003579:	bl      	#0x4c2d
; block 0x357d
0x00357d:	subs    	r0, r0, r5
0x00357f:	lsrs    	r1, r0, #0x1f
0x003581:	adds    	r0, r1, r0
0x003583:	movs    	r2, #0
0x003585:	str     	r2, [sp, #8]
0x003587:	asrs    	r0, r0, #1
0x003589:	adds    	r2, r0, #0
0x00358b:	movs    	r0, #0xf1
0x00358d:	movs    	r1, #0x30
0x00358f:	lsls    	r0, r0, #9
0x003591:	str     	r5, [sp]
0x003593:	str     	r6, [sp, #4]
0x003595:	ldr     	r3, [sp, #0x2c]
0x003597:	bl      	#0x4c2d
; block 0x359b
0x00359b:	movs    	r1, #0
0x00359d:	str     	r1, [sp]
0x00359f:	str     	r1, [sp, #4]
0x0035a1:	movs    	r2, #0
0x0035a3:	movs    	r1, #0x1c
0x0035a5:	adds    	r3, r7, #0
0x0035a7:	movs    	r0, #0xf1
0x0035a9:	lsls    	r0, r0, #9
0x0035ab:	str     	r2, [sp, #8]
0x0035ad:	str     	r4, [sp, #0x10]
0x0035af:	bl      	#0x4c2d
; block 0x35b3
0x0035b3:	subs    	r0, r0, r5
0x0035b5:	lsrs    	r1, r0, #0x1f
0x0035b7:	adds    	r0, r1, r0
0x0035b9:	asrs    	r0, r0, #1
0x0035bb:	adds    	r0, #5
0x0035bd:	movs    	r1, #0
0x0035bf:	str     	r1, [sp]
0x0035c1:	str     	r1, [sp, #4]
0x0035c3:	str     	r0, [sp, #0x14]
0x0035c5:	movs    	r2, #0
0x0035c7:	movs    	r0, #0xf1
0x0035c9:	movs    	r1, #0x1d
0x0035cb:	adds    	r3, r7, #0
0x0035cd:	lsls    	r0, r0, #9
0x0035cf:	str     	r2, [sp, #8]
0x0035d1:	bl      	#0x4c2d
; block 0x35d5
0x0035d5:	subs    	r0, r0, r6
0x0035d7:	adds    	r0, #3
0x0035d9:	str     	r0, [sp, #0x18]
0x0035db:	movs    	r0, #0xff
0x0035dd:	str     	r0, [sp, #0x20]
0x0035df:	str     	r0, [sp, #0x1c]
0x0035e1:	movs    	r0, #0xc8
0x0035e3:	str     	r0, [sp, #0x24]
0x0035e5:	movs    	r1, #0
0x0035e7:	movs    	r2, #0
0x0035e9:	str     	r2, [sp, #8]
0x0035eb:	str     	r1, [sp]
0x0035ed:	str     	r1, [sp, #4]
0x0035ef:	movs    	r1, #0xe1
0x0035f1:	movs    	r2, #0x29
0x0035f3:	movs    	r0, #0xf1
0x0035f5:	adds    	r3, r7, #0
0x0035f7:	lsls    	r0, r0, #9
0x0035f9:	bl      	#0x4c2d
; block 0x35fd
0x0035fd:	str     	r0, [sp, #0x28]
0x0035ff:	movs    	r1, #0
0x003601:	movs    	r2, #0
0x003603:	str     	r2, [sp, #8]
0x003605:	str     	r1, [sp]
0x003607:	str     	r1, [sp, #4]
0x003609:	movs    	r1, #0xe1
0x00360b:	movs    	r2, #0x28
0x00360d:	movs    	r0, #0xf1
0x00360f:	adds    	r3, r7, #0
0x003611:	lsls    	r0, r0, #9
0x003613:	bl      	#0x4c2d
; block 0x3617
0x003617:	movs    	r1, #0
0x003619:	movs    	r2, #0
0x00361b:	str     	r1, [sp]
0x00361d:	str     	r1, [sp, #4]
0x00361f:	str     	r0, [sp, #0x2c]
0x003621:	movs    	r0, #0xf1
0x003623:	movs    	r1, #0x56
0x003625:	str     	r2, [sp, #8]
0x003627:	adds    	r3, r7, #0
0x003629:	lsls    	r0, r0, #9
0x00362b:	add     	r2, sp, #0x10
0x00362d:	bl      	#0x4c2d
; block 0x3631
0x003631:	add     	sp, #0x54
0x003633:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_3635 @ 0x3635 offset=0x3634 size=28 blocks=5 cc=1 =====
; block 0x3635
0x003635:	ldr     	r0, [pc, #0x18]
0x003637:	add     	r0, sb
0x003639:	ldr     	r1, [r0, #0x20]
0x00363b:	cmp     	r1, #0
0x00363d:	bne     	#0x3643
; block 0x363f
0x00363f:	mvns    	r0, r1
0x003641:	bx      	lr
; block 0x3643
0x003643:	ldr     	r0, [r0, #0x1c]
0x003645:	cmp     	r0, #0
0x003647:	beq     	#0x364d
; block 0x3649
0x003649:	movs    	r0, #2
0x00364b:	bx      	lr
; block 0x364d
0x00364d:	movs    	r0, #1
0x00364f:	bx      	lr

; ===== sub_3651 @ 0x3651 offset=0x3650 size=4 blocks=1 cc=1 =====
; block 0x3651
0x003651:	movs    	r4, r0
0x003653:	movs    	r0, r0
0x003655:	push    	{r3, r4, r5, r6, r7, lr}
0x003657:	movs    	r4, #0
0x003659:	bl      	#0x3979

; ===== sub_3655 @ 0x3655 offset=0x3654 size=118 blocks=21 cc=11 =====
; block 0x3655
0x003655:	push    	{r3, r4, r5, r6, r7, lr}
0x003657:	movs    	r4, #0
0x003659:	bl      	#0x3979
; block 0x365d
0x00365d:	ldr     	r1, [pc, #0x6c]
0x00365f:	adds    	r5, r0, #0
0x003661:	add     	r1, pc
0x003663:	ldr     	r6, [pc, #0x6c]
0x003665:	add     	r6, sb
0x003667:	ldr     	r2, [r6]
0x003669:	blx     	r2
; block 0x366b
0x00366b:	mvns    	r7, r4
0x00366d:	cmp     	r0, #0
0x00366f:	bne     	#0x368b
; block 0x3671
0x003671:	bl      	#0x3635
; block 0x3675
0x003675:	adds    	r4, r0, #0
0x003677:	cmp     	r0, r7
0x003679:	bne     	#0x368b
; block 0x367b
0x00367b:	ldr     	r0, [pc, #0x58]
0x00367d:	add     	r0, sb
0x00367f:	ldr     	r0, [r0, #0x1c]
0x003681:	cmp     	r0, #0
0x003683:	bne     	#0x3689
; block 0x3685
0x003685:	adds    	r4, r7, #0
0x003687:	b       	#0x368b
; block 0x3689
0x003689:	movs    	r4, #1
0x00368b:	ldr     	r1, [pc, #0x4c]
0x00368d:	add     	r1, pc
0x00368f:	ldr     	r2, [r6]
0x003691:	adds    	r0, r5, #0
0x003693:	blx     	r2
; block 0x368b
0x00368b:	ldr     	r1, [pc, #0x4c]
0x00368d:	add     	r1, pc
0x00368f:	ldr     	r2, [r6]
0x003691:	adds    	r0, r5, #0
0x003693:	blx     	r2
; block 0x3695
0x003695:	cmp     	r0, #0
0x003697:	bne     	#0x369b
; block 0x3699
0x003699:	movs    	r4, #0
0x00369b:	ldr     	r1, [pc, #0x3c]
0x00369d:	add     	r1, pc
0x00369f:	ldr     	r2, [r6]
0x0036a1:	adds    	r0, r5, #0
0x0036a3:	blx     	r2
; block 0x369b
0x00369b:	ldr     	r1, [pc, #0x3c]
0x00369d:	add     	r1, pc
0x00369f:	ldr     	r2, [r6]
0x0036a1:	adds    	r0, r5, #0
0x0036a3:	blx     	r2
; block 0x36a5
0x0036a5:	cmp     	r0, #0
0x0036a7:	bne     	#0x36c1
; block 0x36a9
0x0036a9:	ldr     	r0, [pc, #0x28]
0x0036ab:	add     	r0, sb
0x0036ad:	ldr     	r0, [r0, #0x1c]
0x0036af:	cmp     	r0, #0
0x0036b1:	bne     	#0x36b7
; block 0x36b3
0x0036b3:	adds    	r4, r7, #0
0x0036b5:	b       	#0x36b9
; block 0x36b7
0x0036b7:	movs    	r4, #1
0x0036b9:	adds    	r3, r4, #1
0x0036bb:	bne     	#0x36c7
; block 0x36b9
0x0036b9:	adds    	r3, r4, #1
0x0036bb:	bne     	#0x36c7
; block 0x36bd
0x0036bd:	movs    	r4, #0
0x0036bf:	b       	#0x36c7
; block 0x36c1
0x0036c1:	adds    	r3, r4, #1
0x0036c3:	bne     	#0x36c7
; block 0x36c5
0x0036c5:	movs    	r4, #0
0x0036c7:	adds    	r0, r4, #0
0x0036c9:	pop     	{r3, r4, r5, r6, r7, pc}
; block 0x36c7
0x0036c7:	adds    	r0, r4, #0
0x0036c9:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== sub_36dd @ 0x36dd offset=0x36dc size=440 blocks=21 cc=18 =====
; block 0x36dd
0x0036dd:	push    	{r4, r5, r6, r7, lr}
0x0036df:	sub     	sp, #0xc
0x0036e1:	movs    	r1, #0
0x0036e3:	str     	r1, [sp]
0x0036e5:	str     	r1, [sp, #4]
0x0036e7:	movs    	r2, #0
0x0036e9:	str     	r2, [sp, #8]
0x0036eb:	movs    	r6, #0xf1
0x0036ed:	lsls    	r6, r6, #9
0x0036ef:	ldr     	r3, [r0]
0x0036f1:	movs    	r1, #0xb1
0x0036f3:	adds    	r4, r0, #0
0x0036f5:	adds    	r0, r6, #0
0x0036f7:	bl      	#0x4c2d
; block 0x36fb
0x0036fb:	movs    	r1, #0
0x0036fd:	str     	r1, [sp]
0x0036ff:	str     	r1, [sp, #4]
0x003701:	movs    	r2, #0
0x003703:	movs    	r1, #0xff
0x003705:	movs    	r7, #0
0x003707:	adds    	r3, r7, #0
0x003709:	adds    	r1, #0x53
0x00370b:	str     	r2, [sp, #8]
0x00370d:	adds    	r5, r0, #0
0x00370f:	adds    	r0, r6, #0
0x003711:	ldr     	r2, [r4]
0x003713:	bl      	#0x4c2d
; block 0x3717
0x003717:	cmp     	r0, #0
0x003719:	bne     	#0x3765
; block 0x371b
0x00371b:	movs    	r2, #0
0x00371d:	movs    	r1, #0
0x00371f:	ldr     	r3, [pc, #0x174]
0x003721:	str     	r1, [sp]
0x003723:	str     	r1, [sp, #4]
0x003725:	str     	r2, [sp, #8]
0x003727:	add     	r3, pc
0x003729:	adds    	r2, r5, #0
0x00372b:	movs    	r1, #0x2d
0x00372d:	adds    	r0, r6, #0
0x00372f:	bl      	#0x4c2d
; block 0x3733
0x003733:	movs    	r1, #0
0x003735:	str     	r1, [sp]
0x003737:	str     	r1, [sp, #4]
0x003739:	movs    	r2, #0
0x00373b:	movs    	r1, #0xff
0x00373d:	adds    	r1, #0x52
0x00373f:	str     	r2, [sp, #8]
0x003741:	adds    	r5, r0, #0
0x003743:	adds    	r3, r7, #0
0x003745:	adds    	r0, r6, #0
0x003747:	ldr     	r2, [r4, #4]
0x003749:	bl      	#0x4c2d
; block 0x374d
0x00374d:	movs    	r1, #0
0x00374f:	movs    	r2, #0
0x003751:	str     	r2, [sp, #8]
0x003753:	str     	r1, [sp]
0x003755:	str     	r1, [sp, #4]
0x003757:	movs    	r1, #0x2d
0x003759:	adds    	r2, r5, #0
0x00375b:	adds    	r3, r0, #0
0x00375d:	adds    	r0, r6, #0
0x00375f:	bl      	#0x4c2d
; block 0x3763
0x003763:	adds    	r5, r0, #0
0x003765:	movs    	r1, #0
0x003767:	str     	r1, [sp]
0x003769:	str     	r1, [sp, #4]
0x00376b:	movs    	r2, #0
0x00376d:	str     	r2, [sp, #8]
0x00376f:	movs    	r1, #0x3f
0x003771:	adds    	r3, r7, #0
0x003773:	movs    	r0, #0xf1
0x003775:	lsls    	r0, r0, #9
0x003777:	ldr     	r2, [r4, #8]
0x003779:	bl      	#0x4c2d
; block 0x3765
0x003765:	movs    	r1, #0
0x003767:	str     	r1, [sp]
0x003769:	str     	r1, [sp, #4]
0x00376b:	movs    	r2, #0
0x00376d:	str     	r2, [sp, #8]
0x00376f:	movs    	r1, #0x3f
0x003771:	adds    	r3, r7, #0
0x003773:	movs    	r0, #0xf1
0x003775:	lsls    	r0, r0, #9
0x003777:	ldr     	r2, [r4, #8]
0x003779:	bl      	#0x4c2d
; block 0x377d
0x00377d:	movs    	r2, #0
0x00377f:	adds    	r6, r0, #0
0x003781:	movs    	r1, #0
0x003783:	ldr     	r3, [pc, #0x114]
0x003785:	str     	r1, [sp]
0x003787:	str     	r1, [sp, #4]
0x003789:	str     	r2, [sp, #8]
0x00378b:	add     	r3, pc
0x00378d:	adds    	r2, r5, #0
0x00378f:	movs    	r1, #0x2d
0x003791:	movs    	r0, #0xf1
0x003793:	lsls    	r0, r0, #9
0x003795:	bl      	#0x4c2d
; block 0x3799
0x003799:	movs    	r2, #0
0x00379b:	movs    	r1, #0
0x00379d:	str     	r2, [sp, #8]
0x00379f:	adds    	r3, r6, #0
0x0037a1:	adds    	r2, r0, #0
0x0037a3:	str     	r1, [sp]
0x0037a5:	str     	r1, [sp, #4]
0x0037a7:	movs    	r1, #0x2d
0x0037a9:	movs    	r0, #0xf1
0x0037ab:	lsls    	r0, r0, #9
0x0037ad:	bl      	#0x4c2d
; block 0x37b1
0x0037b1:	movs    	r1, #0
0x0037b3:	adds    	r5, r0, #0
0x0037b5:	movs    	r2, #0
0x0037b7:	str     	r2, [sp, #8]
0x0037b9:	str     	r1, [sp]
0x0037bb:	str     	r1, [sp, #4]
0x0037bd:	adds    	r3, r7, #0
0x0037bf:	adds    	r2, r6, #0
0x0037c1:	movs    	r1, #9
0x0037c3:	movs    	r0, #0xf1
0x0037c5:	lsls    	r0, r0, #9
0x0037c7:	bl      	#0x4c2d
; block 0x37cb
0x0037cb:	movs    	r1, #0
0x0037cd:	str     	r1, [sp]
0x0037cf:	str     	r1, [sp, #4]
0x0037d1:	movs    	r2, #0
0x0037d3:	str     	r2, [sp, #8]
0x0037d5:	movs    	r1, #0x3f
0x0037d7:	adds    	r3, r7, #0
0x0037d9:	movs    	r0, #0xf1
0x0037db:	lsls    	r0, r0, #9
0x0037dd:	ldr     	r2, [r4, #0xc]
0x0037df:	bl      	#0x4c2d
; block 0x37e3
0x0037e3:	movs    	r2, #0
0x0037e5:	adds    	r6, r0, #0
0x0037e7:	movs    	r1, #0
0x0037e9:	ldr     	r3, [pc, #0xb0]
0x0037eb:	str     	r1, [sp]
0x0037ed:	str     	r1, [sp, #4]
0x0037ef:	str     	r2, [sp, #8]
0x0037f1:	add     	r3, pc
0x0037f3:	adds    	r2, r5, #0
0x0037f5:	movs    	r1, #0x2d
0x0037f7:	movs    	r0, #0xf1
0x0037f9:	lsls    	r0, r0, #9
0x0037fb:	bl      	#0x4c2d
; block 0x37ff
0x0037ff:	movs    	r2, #0
0x003801:	movs    	r1, #0
0x003803:	str     	r2, [sp, #8]
0x003805:	adds    	r3, r6, #0
0x003807:	adds    	r2, r0, #0
0x003809:	str     	r1, [sp]
0x00380b:	str     	r1, [sp, #4]
0x00380d:	movs    	r1, #0x2d
0x00380f:	movs    	r0, #0xf1
0x003811:	lsls    	r0, r0, #9
0x003813:	bl      	#0x4c2d
; block 0x3817
0x003817:	movs    	r1, #0
0x003819:	adds    	r5, r0, #0
0x00381b:	movs    	r2, #0
0x00381d:	str     	r2, [sp, #8]
0x00381f:	str     	r1, [sp]
0x003821:	str     	r1, [sp, #4]
0x003823:	adds    	r3, r7, #0
0x003825:	adds    	r2, r6, #0
0x003827:	movs    	r1, #9
0x003829:	movs    	r0, #0xf1
0x00382b:	lsls    	r0, r0, #9
0x00382d:	bl      	#0x4c2d
; block 0x3831
0x003831:	movs    	r2, #0
0x003833:	movs    	r1, #0
0x003835:	ldr     	r3, [pc, #0x68]
0x003837:	str     	r1, [sp]
0x003839:	str     	r1, [sp, #4]
0x00383b:	str     	r2, [sp, #8]
0x00383d:	add     	r3, pc
0x00383f:	adds    	r2, r5, #0
0x003841:	movs    	r1, #0x2d
0x003843:	movs    	r0, #0xf1
0x003845:	lsls    	r0, r0, #9
0x003847:	bl      	#0x4c2d
; block 0x384b
0x00384b:	adds    	r5, r0, #0
0x00384d:	ldr     	r0, [r4, #8]
0x00384f:	ldr     	r1, [r4, #0xc]
0x003851:	cmp     	r0, r1
0x003853:	blt     	#0x3873
; block 0x3855
0x003855:	movs    	r2, #0
0x003857:	movs    	r1, #0
0x003859:	ldr     	r3, [pc, #0x48]
0x00385b:	str     	r1, [sp]
0x00385d:	str     	r1, [sp, #4]
0x00385f:	str     	r2, [sp, #8]
0x003861:	add     	r3, pc
0x003863:	adds    	r2, r5, #0
0x003865:	movs    	r1, #0x2d
0x003867:	movs    	r0, #0xf1
0x003869:	lsls    	r0, r0, #9
0x00386b:	bl      	#0x4c2d
; block 0x386f
0x00386f:	add     	sp, #0xc
0x003871:	pop     	{r4, r5, r6, r7, pc}
; block 0x3873
0x003873:	movs    	r2, #0
0x003875:	movs    	r1, #0
0x003877:	ldr     	r3, [pc, #0x30]
0x003879:	str     	r1, [sp]
0x00387b:	str     	r1, [sp, #4]
0x00387d:	str     	r2, [sp, #8]
0x00387f:	add     	r3, pc
0x003881:	adds    	r2, r5, #0
0x003883:	movs    	r1, #0x2d
0x003885:	movs    	r0, #0xf1
0x003887:	lsls    	r0, r0, #9
0x003889:	bl      	#0x4c2d
; block 0x388d
0x00388d:	ldr     	r1, [pc, #0x1c]
0x00388f:	add     	r1, sb
0x003891:	strb    	r7, [r1]
0x003893:	b       	#0x386f

; ===== sub_38b1 @ 0x38b1 offset=0x38b0 size=106 blocks=20 cc=11 =====
; block 0x38b1
0x0038b1:	push    	{r4, r5, r6, lr}
0x0038b3:	movs    	r4, #0
0x0038b5:	bl      	#0x3979
; block 0x38b9
0x0038b9:	ldr     	r1, [pc, #0x60]
0x0038bb:	adds    	r5, r0, #0
0x0038bd:	add     	r1, pc
0x0038bf:	ldr     	r6, [pc, #0x60]
0x0038c1:	add     	r6, sb
0x0038c3:	ldr     	r2, [r6]
0x0038c5:	blx     	r2
; block 0x38c7
0x0038c7:	cmp     	r0, #0
0x0038c9:	bne     	#0x38e5
; block 0x38cb
0x0038cb:	ldr     	r0, [pc, #0x58]
0x0038cd:	add     	r0, sb
0x0038cf:	ldr     	r0, [r0, #0x1c]
0x0038d1:	cmp     	r0, #0
0x0038d3:	bne     	#0x38d9
; block 0x38d5
0x0038d5:	mvns    	r4, r0
0x0038d7:	b       	#0x38db
; block 0x38d9
0x0038d9:	movs    	r4, #1
0x0038db:	adds    	r3, r4, #1
0x0038dd:	bne     	#0x38e5
; block 0x38db
0x0038db:	adds    	r3, r4, #1
0x0038dd:	bne     	#0x38e5
; block 0x38df
0x0038df:	bl      	#0x3635
; block 0x38e3
0x0038e3:	adds    	r4, r0, #0
0x0038e5:	ldr     	r1, [pc, #0x40]
0x0038e7:	add     	r1, pc
0x0038e9:	ldr     	r2, [r6]
0x0038eb:	adds    	r0, r5, #0
0x0038ed:	blx     	r2
; block 0x38e5
0x0038e5:	ldr     	r1, [pc, #0x40]
0x0038e7:	add     	r1, pc
0x0038e9:	ldr     	r2, [r6]
0x0038eb:	adds    	r0, r5, #0
0x0038ed:	blx     	r2
; block 0x38ef
0x0038ef:	cmp     	r0, #0
0x0038f1:	bne     	#0x38ff
; block 0x38f3
0x0038f3:	bl      	#0x3635
; block 0x38f7
0x0038f7:	adds    	r4, r0, #0
0x0038f9:	adds    	r3, r0, #1
0x0038fb:	bne     	#0x38ff
; block 0x38fd
0x0038fd:	movs    	r4, #0
0x0038ff:	ldr     	r1, [pc, #0x2c]
0x003901:	add     	r1, pc
0x003903:	ldr     	r2, [r6]
0x003905:	adds    	r0, r5, #0
0x003907:	blx     	r2
; block 0x38ff
0x0038ff:	ldr     	r1, [pc, #0x2c]
0x003901:	add     	r1, pc
0x003903:	ldr     	r2, [r6]
0x003905:	adds    	r0, r5, #0
0x003907:	blx     	r2
; block 0x3909
0x003909:	cmp     	r0, #0
0x00390b:	bne     	#0x3911
; block 0x390d
0x00390d:	movs    	r4, #0
0x00390f:	b       	#0x3917
; block 0x3911
0x003911:	adds    	r3, r4, #1
0x003913:	bne     	#0x3917
; block 0x3915
0x003915:	movs    	r4, #0
0x003917:	adds    	r0, r4, #0
0x003919:	pop     	{r4, r5, r6, pc}
; block 0x3917
0x003917:	adds    	r0, r4, #0
0x003919:	pop     	{r4, r5, r6, pc}

; ===== sub_3931 @ 0x3931 offset=0x3930 size=46 blocks=8 cc=2 =====
; block 0x3931
0x003931:	adds    	r1, r0, #0
0x003933:	movs    	r0, #0
0x003935:	cmp     	r1, #5
0x003937:	bhs     	#0x394b
; block 0x3939
0x003939:	adr     	r3, #4
0x00393b:	ldrb    	r3, [r3, r1]
0x00393d:	lsls    	r3, r3, #1
0x00393f:	add     	pc, r3
; block 0x3947
0x003947:	ldr     	r0, [pc, #0x1c]
0x003949:	add     	r0, pc
0x00394b:	bx      	lr
; block 0x394b
0x00394b:	bx      	lr
; block 0x394d
0x00394d:	ldr     	r0, [pc, #0x18]
0x00394f:	add     	r0, pc
0x003951:	bx      	lr
; block 0x3953
0x003953:	ldr     	r0, [pc, #0x18]
0x003955:	add     	r0, pc
0x003957:	bx      	lr
; block 0x3959
0x003959:	ldr     	r0, [pc, #0x14]
0x00395b:	add     	r0, pc
0x00395d:	bx      	lr
; block 0x395f
0x00395f:	ldr     	r0, [pc, #0x14]
0x003961:	add     	r0, pc
0x003963:	bx      	lr

; ===== sub_3979 @ 0x3979 offset=0x3978 size=62 blocks=11 cc=2 =====
; block 0x3979
0x003979:	ldr     	r2, [pc, #0x3c]
0x00397b:	push    	{lr}
0x00397d:	add     	r2, sb
0x00397f:	ldr     	r1, [r2, #0x24]
0x003981:	cmp     	r1, #0
0x003983:	bne     	#0x398b
; block 0x3985
0x003985:	ldr     	r0, [pc, #0x34]
0x003987:	add     	r0, pc
0x003989:	pop     	{pc}
; block 0x398b
0x00398b:	ldr     	r0, [r2, #0x1c]
0x00398d:	cmp     	r0, #0
0x00398f:	bne     	#0x3995
; block 0x3991
0x003991:	mvns    	r0, r0
0x003993:	b       	#0x3997
; block 0x3995
0x003995:	movs    	r0, #1
0x003997:	cmp     	r0, r1
0x003999:	bne     	#0x39a1
; block 0x3997
0x003997:	cmp     	r0, r1
0x003999:	bne     	#0x39a1
; block 0x399b
0x00399b:	ldr     	r0, [pc, #0x24]
0x00399d:	add     	r0, pc
0x00399f:	pop     	{pc}
; block 0x39a1
0x0039a1:	bl      	#0x3635
; block 0x39a5
0x0039a5:	ldr     	r1, [r2, #0x24]
0x0039a7:	cmp     	r0, r1
0x0039a9:	bne     	#0x39b1
; block 0x39ab
0x0039ab:	ldr     	r0, [pc, #0x14]
0x0039ad:	add     	r0, pc
0x0039af:	pop     	{pc}
; block 0x39b1
0x0039b1:	ldr     	r0, [pc, #8]
0x0039b3:	add     	r0, pc
0x0039b5:	pop     	{pc}

; ===== sub_39b9 @ 0x39b9 offset=0x39b8 size=12 blocks=1 cc=1 =====
; block 0x39b9
0x0039b9:	movs    	r4, r0
0x0039bb:	movs    	r0, r0
0x0039bd:	movs    	r3, #0x86
0x0039bf:	movs    	r0, r0
0x0039c1:	movs    	r3, #0x7c
0x0039c3:	movs    	r0, r0
0x0039c5:	push    	{r4, lr}
0x0039c7:	sub     	sp, #0x10
0x0039c9:	movs    	r1, #0
0x0039cb:	str     	r1, [sp]
0x0039cd:	str     	r1, [sp, #4]
0x0039cf:	movs    	r4, #0
0x0039d1:	movs    	r2, #0
0x0039d3:	adds    	r3, r4, #0
0x0039d5:	movs    	r1, #0x34
0x0039d7:	movs    	r0, #0xf1
0x0039d9:	lsls    	r0, r0, #9
0x0039db:	str     	r2, [sp, #8]
0x0039dd:	bl      	#0x4c2d

; ===== sub_39c5 @ 0x39c5 offset=0x39c4 size=118 blocks=5 cc=4 =====
; block 0x39c5
0x0039c5:	push    	{r4, lr}
0x0039c7:	sub     	sp, #0x10
0x0039c9:	movs    	r1, #0
0x0039cb:	str     	r1, [sp]
0x0039cd:	str     	r1, [sp, #4]
0x0039cf:	movs    	r4, #0
0x0039d1:	movs    	r2, #0
0x0039d3:	adds    	r3, r4, #0
0x0039d5:	movs    	r1, #0x34
0x0039d7:	movs    	r0, #0xf1
0x0039d9:	lsls    	r0, r0, #9
0x0039db:	str     	r2, [sp, #8]
0x0039dd:	bl      	#0x4c2d
; block 0x39e1
0x0039e1:	movs    	r1, #0
0x0039e3:	movs    	r2, #0
0x0039e5:	str     	r2, [sp, #8]
0x0039e7:	str     	r1, [sp]
0x0039e9:	str     	r1, [sp, #4]
0x0039eb:	movs    	r3, #0xff
0x0039ed:	adds    	r3, #0x40
0x0039ef:	movs    	r1, #0x14
0x0039f1:	movs    	r2, #0x17
0x0039f3:	movs    	r0, #0xf1
0x0039f5:	lsls    	r0, r0, #9
0x0039f7:	bl      	#0x4c2d
; block 0x39fb
0x0039fb:	movs    	r1, #0
0x0039fd:	movs    	r2, #0
0x0039ff:	str     	r2, [sp, #8]
0x003a01:	str     	r1, [sp]
0x003a03:	str     	r1, [sp, #4]
0x003a05:	movs    	r1, #0xe1
0x003a07:	movs    	r2, #0x74
0x003a09:	adds    	r3, r4, #0
0x003a0b:	movs    	r0, #0xf1
0x003a0d:	lsls    	r0, r0, #9
0x003a0f:	bl      	#0x4c2d
; block 0x3a13
0x003a13:	ldr     	r1, [pc, #0x28]
0x003a15:	movs    	r2, #0
0x003a17:	add     	r1, sb
0x003a19:	str     	r0, [r1, #0xc]
0x003a1b:	movs    	r0, #1
0x003a1d:	strb    	r0, [r1, #2]
0x003a1f:	str     	r4, [r1, #0x10]
0x003a21:	movs    	r1, #0
0x003a23:	str     	r1, [sp]
0x003a25:	str     	r1, [sp, #4]
0x003a27:	str     	r2, [sp, #8]
0x003a29:	movs    	r2, #0x74
0x003a2b:	movs    	r1, #0x14
0x003a2d:	movs    	r0, #0xf1
0x003a2f:	adds    	r3, r4, #0
0x003a31:	lsls    	r0, r0, #9
0x003a33:	bl      	#0x4c2d
; block 0x3a37
0x003a37:	add     	sp, #0x10
0x003a39:	pop     	{r4, pc}

; ===== sub_3a3d @ 0x3a3d offset=0x3a3c size=4 blocks=1 cc=1 =====
; block 0x3a3d
0x003a3d:	movs    	r4, r0
0x003a3f:	movs    	r0, r0
0x003a41:	push    	{r4, lr}
0x003a43:	sub     	sp, #0x10
0x003a45:	movs    	r1, #0
0x003a47:	str     	r1, [sp]
0x003a49:	str     	r1, [sp, #4]
0x003a4b:	movs    	r4, #0
0x003a4d:	movs    	r2, #0
0x003a4f:	adds    	r3, r4, #0
0x003a51:	movs    	r1, #0x34
0x003a53:	movs    	r0, #0xf1
0x003a55:	lsls    	r0, r0, #9
0x003a57:	str     	r2, [sp, #8]
0x003a59:	bl      	#0x4c2d

; ===== sub_3a41 @ 0x3a41 offset=0x3a40 size=86 blocks=4 cc=3 =====
; block 0x3a41
0x003a41:	push    	{r4, lr}
0x003a43:	sub     	sp, #0x10
0x003a45:	movs    	r1, #0
0x003a47:	str     	r1, [sp]
0x003a49:	str     	r1, [sp, #4]
0x003a4b:	movs    	r4, #0
0x003a4d:	movs    	r2, #0
0x003a4f:	adds    	r3, r4, #0
0x003a51:	movs    	r1, #0x34
0x003a53:	movs    	r0, #0xf1
0x003a55:	lsls    	r0, r0, #9
0x003a57:	str     	r2, [sp, #8]
0x003a59:	bl      	#0x4c2d
; block 0x3a5d
0x003a5d:	movs    	r1, #0
0x003a5f:	movs    	r2, #0
0x003a61:	str     	r2, [sp, #8]
0x003a63:	str     	r1, [sp]
0x003a65:	str     	r1, [sp, #4]
0x003a67:	movs    	r3, #0xff
0x003a69:	adds    	r3, #0x3d
0x003a6b:	movs    	r1, #0x14
0x003a6d:	movs    	r2, #0x17
0x003a6f:	movs    	r0, #0xf1
0x003a71:	lsls    	r0, r0, #9
0x003a73:	bl      	#0x4c2d
; block 0x3a77
0x003a77:	ldr     	r0, [pc, #0x20]
0x003a79:	movs    	r1, #0
0x003a7b:	add     	r0, sb
0x003a7d:	str     	r4, [r0, #0x30]
0x003a7f:	str     	r1, [sp]
0x003a81:	str     	r1, [sp, #4]
0x003a83:	movs    	r2, #0
0x003a85:	movs    	r1, #0xba
0x003a87:	movs    	r0, #0xf1
0x003a89:	adds    	r3, r4, #0
0x003a8b:	lsls    	r0, r0, #9
0x003a8d:	str     	r2, [sp, #8]
0x003a8f:	bl      	#0x4c2d
; block 0x3a93
0x003a93:	add     	sp, #0x10
0x003a95:	pop     	{r4, pc}

; ===== sub_3a99 @ 0x3a99 offset=0x3a98 size=4 blocks=1 cc=1 =====
; block 0x3a99
0x003a99:	movs    	r4, r0
0x003a9b:	movs    	r0, r0
0x003a9d:	push    	{r4, r5, lr}
0x003a9f:	sub     	sp, #0xc
0x003aa1:	movs    	r1, #0
0x003aa3:	adds    	r5, r0, #0
0x003aa5:	str     	r1, [sp]
0x003aa7:	str     	r1, [sp, #4]
0x003aa9:	movs    	r4, #0
0x003aab:	movs    	r2, #0
0x003aad:	adds    	r3, r4, #0
0x003aaf:	movs    	r1, #0x34
0x003ab1:	movs    	r0, #0xf1
0x003ab3:	lsls    	r0, r0, #9
0x003ab5:	str     	r2, [sp, #8]
0x003ab7:	bl      	#0x4c2d

; ===== sub_3a9d @ 0x3a9d offset=0x3a9c size=150 blocks=6 cc=5 =====
; block 0x3a9d
0x003a9d:	push    	{r4, r5, lr}
0x003a9f:	sub     	sp, #0xc
0x003aa1:	movs    	r1, #0
0x003aa3:	adds    	r5, r0, #0
0x003aa5:	str     	r1, [sp]
0x003aa7:	str     	r1, [sp, #4]
0x003aa9:	movs    	r4, #0
0x003aab:	movs    	r2, #0
0x003aad:	adds    	r3, r4, #0
0x003aaf:	movs    	r1, #0x34
0x003ab1:	movs    	r0, #0xf1
0x003ab3:	lsls    	r0, r0, #9
0x003ab5:	str     	r2, [sp, #8]
0x003ab7:	bl      	#0x4c2d
; block 0x3abb
0x003abb:	movs    	r1, #0
0x003abd:	str     	r1, [sp]
0x003abf:	str     	r1, [sp, #4]
0x003ac1:	movs    	r2, #0
0x003ac3:	movs    	r1, #0xba
0x003ac5:	adds    	r3, r4, #0
0x003ac7:	movs    	r0, #0xf1
0x003ac9:	lsls    	r0, r0, #9
0x003acb:	str     	r2, [sp, #8]
0x003acd:	bl      	#0x4c2d
; block 0x3ad1
0x003ad1:	movs    	r1, #0
0x003ad3:	movs    	r2, #0
0x003ad5:	str     	r2, [sp, #8]
0x003ad7:	str     	r1, [sp]
0x003ad9:	str     	r1, [sp, #4]
0x003adb:	movs    	r3, #0xff
0x003add:	adds    	r3, #0x3c
0x003adf:	movs    	r1, #0x14
0x003ae1:	movs    	r2, #0x17
0x003ae3:	movs    	r0, #0xf1
0x003ae5:	lsls    	r0, r0, #9
0x003ae7:	bl      	#0x4c2d
; block 0x3aeb
0x003aeb:	adds    	r0, r5, #0
0x003aed:	ldr     	r5, [pc, #0x44]
0x003aef:	movs    	r1, #0
0x003af1:	add     	r5, sb
0x003af3:	str     	r0, [r5, #0x38]
0x003af5:	str     	r4, [r5, #0x3c]
0x003af7:	str     	r4, [r5, #0x6c]
0x003af9:	str     	r4, [r5, #0x70]
0x003afb:	str     	r4, [r5, #0x4c]
0x003afd:	str     	r4, [r5, #0x34]
0x003aff:	movs    	r2, #0
0x003b01:	str     	r2, [sp, #8]
0x003b03:	str     	r1, [sp]
0x003b05:	str     	r1, [sp, #4]
0x003b07:	movs    	r1, #0xe1
0x003b09:	movs    	r2, #0x74
0x003b0b:	movs    	r0, #0xf1
0x003b0d:	adds    	r3, r4, #0
0x003b0f:	lsls    	r0, r0, #9
0x003b11:	bl      	#0x4c2d
; block 0x3b15
0x003b15:	str     	r0, [r5, #0xc]
0x003b17:	movs    	r1, #0
0x003b19:	movs    	r2, #0
0x003b1b:	str     	r2, [sp, #8]
0x003b1d:	str     	r1, [sp]
0x003b1f:	str     	r1, [sp, #4]
0x003b21:	movs    	r1, #0x14
0x003b23:	movs    	r2, #0x74
0x003b25:	movs    	r0, #0xf1
0x003b27:	adds    	r3, r4, #0
0x003b29:	lsls    	r0, r0, #9
0x003b2b:	bl      	#0x4c2d
; block 0x3b2f
0x003b2f:	add     	sp, #0xc
0x003b31:	pop     	{r4, r5, pc}

; ===== sub_3b35 @ 0x3b35 offset=0x3b34 size=4 blocks=1 cc=1 =====
; block 0x3b35
0x003b35:	movs    	r4, r0
0x003b37:	movs    	r0, r0
0x003b39:	push    	{r4, r5, lr}
0x003b3b:	sub     	sp, #0xc
0x003b3d:	movs    	r1, #0
0x003b3f:	str     	r1, [sp]
0x003b41:	str     	r1, [sp, #4]
0x003b43:	movs    	r4, #0
0x003b45:	movs    	r2, #0
0x003b47:	adds    	r3, r4, #0
0x003b49:	movs    	r1, #0x34
0x003b4b:	movs    	r0, #0xf1
0x003b4d:	lsls    	r0, r0, #9
0x003b4f:	str     	r2, [sp, #8]
0x003b51:	bl      	#0x4c2d

; ===== sub_3b39 @ 0x3b39 offset=0x3b38 size=100 blocks=4 cc=3 =====
; block 0x3b39
0x003b39:	push    	{r4, r5, lr}
0x003b3b:	sub     	sp, #0xc
0x003b3d:	movs    	r1, #0
0x003b3f:	str     	r1, [sp]
0x003b41:	str     	r1, [sp, #4]
0x003b43:	movs    	r4, #0
0x003b45:	movs    	r2, #0
0x003b47:	adds    	r3, r4, #0
0x003b49:	movs    	r1, #0x34
0x003b4b:	movs    	r0, #0xf1
0x003b4d:	lsls    	r0, r0, #9
0x003b4f:	str     	r2, [sp, #8]
0x003b51:	bl      	#0x4c2d
; block 0x3b55
0x003b55:	movs    	r1, #0
0x003b57:	movs    	r2, #0
0x003b59:	str     	r2, [sp, #8]
0x003b5b:	str     	r1, [sp]
0x003b5d:	str     	r1, [sp, #4]
0x003b5f:	movs    	r3, #0xff
0x003b61:	adds    	r3, #0x45
0x003b63:	movs    	r1, #0x14
0x003b65:	movs    	r2, #0x17
0x003b67:	movs    	r0, #0xf1
0x003b69:	lsls    	r0, r0, #9
0x003b6b:	bl      	#0x4c2d
; block 0x3b6f
0x003b6f:	ldr     	r5, [pc, #0x2c]
0x003b71:	movs    	r1, #0
0x003b73:	add     	r5, sb
0x003b75:	str     	r4, [r5, #0x30]
0x003b77:	str     	r4, [r5, #0x48]
0x003b79:	str     	r4, [r5, #0x24]
0x003b7b:	str     	r4, [r5, #0x14]
0x003b7d:	str     	r4, [r5, #0x18]
0x003b7f:	str     	r1, [sp]
0x003b81:	str     	r1, [sp, #4]
0x003b83:	movs    	r2, #0
0x003b85:	movs    	r1, #0xba
0x003b87:	adds    	r3, r4, #0
0x003b89:	movs    	r0, #0xf1
0x003b8b:	lsls    	r0, r0, #9
0x003b8d:	str     	r2, [sp, #8]
0x003b8f:	bl      	#0x4c2d
; block 0x3b93
0x003b93:	mvns    	r0, r4
0x003b95:	str     	r0, [r5, #0x64]
0x003b97:	str     	r0, [r5, #0x68]
0x003b99:	add     	sp, #0xc
0x003b9b:	pop     	{r4, r5, pc}

; ===== sub_3b9d @ 0x3b9d offset=0x3b9c size=4 blocks=1 cc=1 =====
; block 0x3b9d
0x003b9d:	movs    	r4, r0
0x003b9f:	movs    	r0, r0
0x003ba1:	push    	{r4, lr}
0x003ba3:	sub     	sp, #0x10
0x003ba5:	movs    	r1, #0
0x003ba7:	str     	r1, [sp]
0x003ba9:	str     	r1, [sp, #4]
0x003bab:	movs    	r4, #0
0x003bad:	movs    	r2, #0
0x003baf:	adds    	r3, r4, #0
0x003bb1:	movs    	r1, #0x34
0x003bb3:	movs    	r0, #0xf1
0x003bb5:	lsls    	r0, r0, #9
0x003bb7:	str     	r2, [sp, #8]
0x003bb9:	bl      	#0x4c2d

; ===== sub_3ba1 @ 0x3ba1 offset=0x3ba0 size=86 blocks=4 cc=3 =====
; block 0x3ba1
0x003ba1:	push    	{r4, lr}
0x003ba3:	sub     	sp, #0x10
0x003ba5:	movs    	r1, #0
0x003ba7:	str     	r1, [sp]
0x003ba9:	str     	r1, [sp, #4]
0x003bab:	movs    	r4, #0
0x003bad:	movs    	r2, #0
0x003baf:	adds    	r3, r4, #0
0x003bb1:	movs    	r1, #0x34
0x003bb3:	movs    	r0, #0xf1
0x003bb5:	lsls    	r0, r0, #9
0x003bb7:	str     	r2, [sp, #8]
0x003bb9:	bl      	#0x4c2d
; block 0x3bbd
0x003bbd:	movs    	r1, #0
0x003bbf:	movs    	r2, #0
0x003bc1:	str     	r2, [sp, #8]
0x003bc3:	str     	r1, [sp]
0x003bc5:	str     	r1, [sp, #4]
0x003bc7:	movs    	r3, #0xff
0x003bc9:	adds    	r3, #0x3f
0x003bcb:	movs    	r1, #0x14
0x003bcd:	movs    	r2, #0x17
0x003bcf:	movs    	r0, #0xf1
0x003bd1:	lsls    	r0, r0, #9
0x003bd3:	bl      	#0x4c2d
; block 0x3bd7
0x003bd7:	ldr     	r0, [pc, #0x20]
0x003bd9:	movs    	r1, #0
0x003bdb:	add     	r0, sb
0x003bdd:	str     	r4, [r0, #0x30]
0x003bdf:	str     	r1, [sp]
0x003be1:	str     	r1, [sp, #4]
0x003be3:	movs    	r2, #0
0x003be5:	movs    	r1, #0xba
0x003be7:	movs    	r0, #0xf1
0x003be9:	adds    	r3, r4, #0
0x003beb:	lsls    	r0, r0, #9
0x003bed:	str     	r2, [sp, #8]
0x003bef:	bl      	#0x4c2d
; block 0x3bf3
0x003bf3:	add     	sp, #0x10
0x003bf5:	pop     	{r4, pc}

; ===== sub_3bf9 @ 0x3bf9 offset=0x3bf8 size=4 blocks=1 cc=1 =====
; block 0x3bf9
0x003bf9:	movs    	r4, r0
0x003bfb:	movs    	r0, r0
0x003bfd:	push    	{r4, r5, lr}
0x003bff:	sub     	sp, #0xc
0x003c01:	movs    	r1, #0
0x003c03:	adds    	r5, r0, #0
0x003c05:	str     	r1, [sp]
0x003c07:	str     	r1, [sp, #4]
0x003c09:	movs    	r4, #0
0x003c0b:	movs    	r2, #0
0x003c0d:	adds    	r3, r4, #0
0x003c0f:	movs    	r1, #0x34
0x003c11:	movs    	r0, #0xf1
0x003c13:	lsls    	r0, r0, #9
0x003c15:	str     	r2, [sp, #8]
0x003c17:	bl      	#0x4c2d

; ===== sub_3bfd @ 0x3bfd offset=0x3bfc size=150 blocks=6 cc=5 =====
; block 0x3bfd
0x003bfd:	push    	{r4, r5, lr}
0x003bff:	sub     	sp, #0xc
0x003c01:	movs    	r1, #0
0x003c03:	adds    	r5, r0, #0
0x003c05:	str     	r1, [sp]
0x003c07:	str     	r1, [sp, #4]
0x003c09:	movs    	r4, #0
0x003c0b:	movs    	r2, #0
0x003c0d:	adds    	r3, r4, #0
0x003c0f:	movs    	r1, #0x34
0x003c11:	movs    	r0, #0xf1
0x003c13:	lsls    	r0, r0, #9
0x003c15:	str     	r2, [sp, #8]
0x003c17:	bl      	#0x4c2d
; block 0x3c1b
0x003c1b:	movs    	r1, #0
0x003c1d:	str     	r1, [sp]
0x003c1f:	str     	r1, [sp, #4]
0x003c21:	movs    	r2, #0
0x003c23:	movs    	r1, #0xba
0x003c25:	adds    	r3, r4, #0
0x003c27:	movs    	r0, #0xf1
0x003c29:	lsls    	r0, r0, #9
0x003c2b:	str     	r2, [sp, #8]
0x003c2d:	bl      	#0x4c2d
; block 0x3c31
0x003c31:	movs    	r1, #0
0x003c33:	movs    	r2, #0
0x003c35:	str     	r2, [sp, #8]
0x003c37:	str     	r1, [sp]
0x003c39:	str     	r1, [sp, #4]
0x003c3b:	movs    	r3, #0xff
0x003c3d:	adds    	r3, #0x3e
0x003c3f:	movs    	r1, #0x14
0x003c41:	movs    	r2, #0x17
0x003c43:	movs    	r0, #0xf1
0x003c45:	lsls    	r0, r0, #9
0x003c47:	bl      	#0x4c2d
; block 0x3c4b
0x003c4b:	adds    	r0, r5, #0
0x003c4d:	ldr     	r5, [pc, #0x44]
0x003c4f:	movs    	r1, #0
0x003c51:	add     	r5, sb
0x003c53:	str     	r0, [r5, #0x38]
0x003c55:	str     	r4, [r5, #0x3c]
0x003c57:	str     	r4, [r5, #0x6c]
0x003c59:	str     	r4, [r5, #0x70]
0x003c5b:	str     	r4, [r5, #0x4c]
0x003c5d:	str     	r4, [r5, #0x34]
0x003c5f:	movs    	r2, #0
0x003c61:	str     	r2, [sp, #8]
0x003c63:	str     	r1, [sp]
0x003c65:	str     	r1, [sp, #4]
0x003c67:	movs    	r1, #0xe1
0x003c69:	movs    	r2, #0x74
0x003c6b:	movs    	r0, #0xf1
0x003c6d:	adds    	r3, r4, #0
0x003c6f:	lsls    	r0, r0, #9
0x003c71:	bl      	#0x4c2d
; block 0x3c75
0x003c75:	str     	r0, [r5, #0xc]
0x003c77:	movs    	r1, #0
0x003c79:	movs    	r2, #0
0x003c7b:	str     	r2, [sp, #8]
0x003c7d:	str     	r1, [sp]
0x003c7f:	str     	r1, [sp, #4]
0x003c81:	movs    	r1, #0x14
0x003c83:	movs    	r2, #0x74
0x003c85:	movs    	r0, #0xf1
0x003c87:	adds    	r3, r4, #0
0x003c89:	lsls    	r0, r0, #9
0x003c8b:	bl      	#0x4c2d
; block 0x3c8f
0x003c8f:	add     	sp, #0xc
0x003c91:	pop     	{r4, r5, pc}

; ===== sub_3c95 @ 0x3c95 offset=0x3c94 size=96 blocks=8 cc=3 =====
; block 0x3c95
0x003c95:	movs    	r4, r0
0x003c97:	movs    	r0, r0
0x003c99:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x003c9b:	sub     	sp, #0xc
0x003c9d:	adds    	r4, r1, #0
0x003c9f:	movs    	r1, #0
0x003ca1:	movs    	r7, #0xff
0x003ca3:	movs    	r2, #0
0x003ca5:	str     	r2, [sp, #8]
0x003ca7:	adds    	r7, #0x23
0x003ca9:	str     	r1, [sp]
0x003cab:	str     	r1, [sp, #4]
0x003cad:	movs    	r5, #0xf1
0x003caf:	lsls    	r5, r5, #9
0x003cb1:	movs    	r1, #0xe1
0x003cb3:	adds    	r2, r7, #0
0x003cb5:	movs    	r3, #0
0x003cb7:	adds    	r0, r5, #0
0x003cb9:	bl      	#0x4c2d
; block 0x3cbd
0x003cbd:	movs    	r6, #1
0x003cbf:	cmp     	r0, #0
0x003cc1:	bne     	#0x3cd9
; block 0x3cc3
0x003cc3:	movs    	r1, #0
0x003cc5:	movs    	r2, #0
0x003cc7:	str     	r2, [sp, #8]
0x003cc9:	str     	r1, [sp]
0x003ccb:	str     	r1, [sp, #4]
0x003ccd:	movs    	r1, #0x14
0x003ccf:	adds    	r2, r7, #0
0x003cd1:	adds    	r3, r6, #0
0x003cd3:	adds    	r0, r5, #0
0x003cd5:	bl      	#0x4c2d
; block 0x3cd9
0x003cd9:	ldr     	r0, [sp, #0xc]
0x003cdb:	cmp     	r0, #0x1c
0x003cdd:	bhs     	#0x3ce9
; block 0x3cdf
0x003cdf:	adr     	r3, #0xc
0x003ce1:	adds    	r3, r3, r0
0x003ce3:	ldrh    	r3, [r3, r0]
0x003ce5:	lsls    	r3, r3, #1
0x003ce7:	add     	pc, r3
; block 0x3ce9
0x003ce9:	b       	#0x3ea3
; block 0x3d2d
0x003d2d:	add     	sp, #0x1c
0x003d2f:	pop     	{r4, r5, r6, r7, pc}
; block 0x3ea3
0x003ea3:	movs    	r0, #2
0x003ea5:	mvns    	r0, r0
0x003ea7:	b       	#0x3d2d

; ===== sub_3ced @ 0x3ced offset=0x3cec size=64 blocks=2 cc=1 =====
; block 0x3ced
0x003ced:	lsls    	r6, r0, #3
0x003cef:	lsls    	r1, r2, #3
0x003cf1:	lsls    	r7, r7, #2
0x003cf3:	lsls    	r2, r0, #3
0x003cf5:	lsls    	r5, r7, #2
0x003cf7:	lsls    	r7, r4, #2
0x003cf9:	lsls    	r3, r4, #2
0x003cfb:	lsls    	r6, r3, #2
0x003cfd:	lsls    	r1, r3, #2
0x003cff:	lsls    	r5, r2, #2
0x003d01:	lsls    	r0, r2, #2
0x003d03:	lsls    	r4, r1, #2
0x003d05:	lsls    	r6, r6, #1
0x003d07:	lsls    	r2, r6, #1
0x003d09:	lsls    	r5, r5, #1
0x003d0b:	lsls    	r0, r5, #1
0x003d0d:	lsls    	r4, r4, #1
0x003d0f:	lsls    	r7, r3, #1
0x003d11:	lsls    	r2, r3, #1
0x003d13:	lsls    	r5, r0, #1
0x003d15:	lsls    	r0, r0, #1
0x003d17:	movs    	r3, r7
0x003d19:	movs    	r7, r6
0x003d1b:	movs    	r2, r6
0x003d1d:	movs    	r5, r5
0x003d1f:	movs    	r0, r5
0x003d21:	movs    	r3, r4
0x003d23:	movs    	r5, r3
0x003d25:	adds    	r0, r4, #0
0x003d27:	bl      	#0x60d
; block 0x3d2b
0x003d2b:	movs    	r0, #0
0x003d2d:	add     	sp, #0x1c
0x003d2f:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_3d31 @ 0x3d31 offset=0x3d30 size=10 blocks=2 cc=1 =====
; block 0x3d31
0x003d31:	adds    	r0, r4, #0
0x003d33:	bl      	#0x50d
; block 0x3d37
0x003d37:	movs    	r0, #0
0x003d39:	b       	#0x3d2d

; ===== sub_3d3b @ 0x3d3b offset=0x3d3a size=10 blocks=1 cc=1 =====
; block 0x3d3b
0x003d3b:	ldr     	r0, [pc, #0x16c]
0x003d3d:	add     	r0, sb
0x003d3f:	str     	r4, [r0, #0x14]
0x003d41:	movs    	r0, #0
0x003d43:	b       	#0x3d2d

; ===== sub_3d45 @ 0x3d45 offset=0x3d44 size=10 blocks=1 cc=1 =====
; block 0x3d45
0x003d45:	ldr     	r0, [pc, #0x160]
0x003d47:	add     	r0, sb
0x003d49:	str     	r4, [r0, #0x18]
0x003d4b:	movs    	r0, #0
0x003d4d:	b       	#0x3d2d

; ===== sub_3d4f @ 0x3d4f offset=0x3d4e size=10 blocks=2 cc=1 =====
; block 0x3d4f
0x003d4f:	adds    	r0, r4, #0
0x003d51:	bl      	#0x5a3d
; block 0x3d55
0x003d55:	movs    	r0, #0
0x003d57:	b       	#0x3d2d

; ===== sub_3d59 @ 0x3d59 offset=0x3d58 size=8 blocks=2 cc=1 =====
; block 0x3d59
0x003d59:	bl      	#0x28b1
; block 0x3d5d
0x003d5d:	movs    	r0, #0
0x003d5f:	b       	#0x3d2d

; ===== sub_3d61 @ 0x3d61 offset=0x3d60 size=10 blocks=2 cc=1 =====
; block 0x3d61
0x003d61:	adds    	r0, r4, #0
0x003d63:	bl      	#0x4755
; block 0x3d67
0x003d67:	movs    	r0, #0
0x003d69:	b       	#0x3d2d

; ===== sub_3d6b @ 0x3d6b offset=0x3d6a size=10 blocks=2 cc=1 =====
; block 0x3d6b
0x003d6b:	adds    	r0, r4, #0
0x003d6d:	bl      	#0x965
; block 0x3d71
0x003d71:	movs    	r0, #0
0x003d73:	b       	#0x3d2d

; ===== sub_3d75 @ 0x3d75 offset=0x3d74 size=42 blocks=4 cc=1 =====
; block 0x3d75
0x003d75:	movs    	r1, #0
0x003d77:	movs    	r2, #0
0x003d79:	str     	r2, [sp, #8]
0x003d7b:	str     	r1, [sp]
0x003d7d:	str     	r1, [sp, #4]
0x003d7f:	movs    	r1, #0x44
0x003d81:	adds    	r2, r4, #0
0x003d83:	movs    	r3, #0
0x003d85:	adds    	r0, r5, #0
0x003d87:	bl      	#0x4c2d
; block 0x3d8b
0x003d8b:	ldr     	r0, [pc, #0x11c]
0x003d8d:	add     	r0, sb
0x003d8f:	strb    	r6, [r0, #3]
0x003d91:	adds    	r0, r4, #0
0x003d93:	bl      	#0x513d
; block 0x3d97
0x003d97:	bl      	#0x3a9d
; block 0x3d9b
0x003d9b:	movs    	r0, #0
0x003d9d:	b       	#0x3d2d

; ===== sub_3d9f @ 0x3d9f offset=0x3d9e size=10 blocks=2 cc=1 =====
; block 0x3d9f
0x003d9f:	adds    	r0, r4, #0
0x003da1:	bl      	#0x3f1
; block 0x3da5
0x003da5:	movs    	r0, #0
0x003da7:	b       	#0x3d2d

; ===== sub_3da9 @ 0x3da9 offset=0x3da8 size=10 blocks=2 cc=1 =====
; block 0x3da9
0x003da9:	adds    	r0, r4, #0
0x003dab:	bl      	#0x3eb9
; block 0x3daf
0x003daf:	movs    	r0, #0
0x003db1:	b       	#0x3d2d

; ===== sub_3db3 @ 0x3db3 offset=0x3db2 size=8 blocks=2 cc=1 =====
; block 0x3db3
0x003db3:	bl      	#0x1281
; block 0x3db7
0x003db7:	movs    	r0, #0
0x003db9:	b       	#0x3d2d

; ===== sub_3dbb @ 0x3dbb offset=0x3dba size=10 blocks=2 cc=1 =====
; block 0x3dbb
0x003dbb:	adds    	r0, r4, #0
0x003dbd:	bl      	#0x685
; block 0x3dc1
0x003dc1:	movs    	r0, #0
0x003dc3:	b       	#0x3d2d

; ===== sub_3dc5 @ 0x3dc5 offset=0x3dc4 size=10 blocks=2 cc=1 =====
; block 0x3dc5
0x003dc5:	adds    	r0, r4, #0
0x003dc7:	bl      	#0x4431
; block 0x3dcb
0x003dcb:	movs    	r0, #0
0x003dcd:	b       	#0x3d2d

; ===== sub_3dcf @ 0x3dcf offset=0x3dce size=8 blocks=2 cc=1 =====
; block 0x3dcf
0x003dcf:	bl      	#0x24f5
; block 0x3dd3
0x003dd3:	movs    	r0, #0
0x003dd5:	b       	#0x3d2d

; ===== sub_3dd7 @ 0x3dd7 offset=0x3dd6 size=44 blocks=4 cc=1 =====
; block 0x3dd7
0x003dd7:	movs    	r1, #0
0x003dd9:	movs    	r2, #0
0x003ddb:	str     	r2, [sp, #8]
0x003ddd:	str     	r1, [sp]
0x003ddf:	str     	r1, [sp, #4]
0x003de1:	movs    	r6, #0
0x003de3:	adds    	r3, r6, #0
0x003de5:	movs    	r1, #0x44
0x003de7:	adds    	r2, r4, #0
0x003de9:	adds    	r0, r5, #0
0x003deb:	bl      	#0x4c2d
; block 0x3def
0x003def:	ldr     	r0, [pc, #0xb8]
0x003df1:	add     	r0, sb
0x003df3:	strb    	r6, [r0, #3]
0x003df5:	adds    	r0, r4, #0
0x003df7:	bl      	#0x513d
; block 0x3dfb
0x003dfb:	bl      	#0x3bfd
; block 0x3dff
0x003dff:	movs    	r0, #0
0x003e01:	b       	#0x3d2d

; ===== sub_3e03 @ 0x3e03 offset=0x3e02 size=8 blocks=2 cc=1 =====
; block 0x3e03
0x003e03:	adds    	r0, r4, #0
0x003e05:	bl      	#0x599d
; block 0x3e09
0x003e09:	b       	#0x3d2d

; ===== sub_3e0b @ 0x3e0b offset=0x3e0a size=10 blocks=2 cc=1 =====
; block 0x3e0b
0x003e0b:	adds    	r0, r4, #0
0x003e0d:	bl      	#0x41ad
; block 0x3e11
0x003e11:	movs    	r0, #0
0x003e13:	b       	#0x3d2d

; ===== sub_3e15 @ 0x3e15 offset=0x3e14 size=8 blocks=2 cc=1 =====
; block 0x3e15
0x003e15:	bl      	#0x1951
; block 0x3e19
0x003e19:	movs    	r0, #0
0x003e1b:	b       	#0x3d2d

; ===== sub_3e1d @ 0x3e1d offset=0x3e1c size=10 blocks=2 cc=1 =====
; block 0x3e1d
0x003e1d:	adds    	r0, r4, #0
0x003e1f:	bl      	#0x7b9
; block 0x3e23
0x003e23:	movs    	r0, #0
0x003e25:	b       	#0x3d2d

; ===== sub_3e27 @ 0x3e27 offset=0x3e26 size=10 blocks=2 cc=1 =====
; block 0x3e27
0x003e27:	adds    	r0, r4, #0
0x003e29:	bl      	#0x4431
; block 0x3e2d
0x003e2d:	movs    	r0, #0
0x003e2f:	b       	#0x3d2d

; ===== sub_3e31 @ 0x3e31 offset=0x3e30 size=8 blocks=2 cc=1 =====
; block 0x3e31
0x003e31:	bl      	#0x20fd
; block 0x3e35
0x003e35:	movs    	r0, #0
0x003e37:	b       	#0x3d2d

; ===== sub_3e39 @ 0x3e39 offset=0x3e38 size=44 blocks=4 cc=1 =====
; block 0x3e39
0x003e39:	movs    	r1, #0
0x003e3b:	movs    	r2, #0
0x003e3d:	str     	r2, [sp, #8]
0x003e3f:	str     	r1, [sp]
0x003e41:	str     	r1, [sp, #4]
0x003e43:	movs    	r6, #0
0x003e45:	adds    	r3, r6, #0
0x003e47:	movs    	r1, #0x44
0x003e49:	adds    	r2, r4, #0
0x003e4b:	adds    	r0, r5, #0
0x003e4d:	bl      	#0x4c2d
; block 0x3e51
0x003e51:	ldr     	r0, [pc, #0x54]
0x003e53:	add     	r0, sb
0x003e55:	strb    	r6, [r0, #3]
0x003e57:	adds    	r0, r4, #0
0x003e59:	bl      	#0x513d
; block 0x3e5d
0x003e5d:	bl      	#0x3a9d
; block 0x3e61
0x003e61:	movs    	r0, #0
0x003e63:	b       	#0x3d2d

; ===== sub_3e65 @ 0x3e65 offset=0x3e64 size=4 blocks=1 cc=1 =====
; block 0x3e65
0x003e65:	movs    	r0, #0
0x003e67:	b       	#0x3d2d

; ===== sub_3e69 @ 0x3e69 offset=0x3e68 size=6 blocks=1 cc=1 =====
; block 0x3e69
0x003e69:	movs    	r0, #0
0x003e6b:	ldr     	r0, [r0]
0x003e6d:	b       	#0x3d2d

; ===== sub_3e6f @ 0x3e6f offset=0x3e6e size=8 blocks=1 cc=1 =====
; block 0x3e6f
0x003e6f:	ldr     	r1, [sp, #0x14]
0x003e71:	movs    	r0, #0
0x003e73:	str     	r1, [r0]
0x003e75:	b       	#0x3d2d

; ===== sub_3e77 @ 0x3e77 offset=0x3e76 size=22 blocks=2 cc=1 =====
; block 0x3e77
0x003e77:	movs    	r1, #0
0x003e79:	movs    	r2, #0
0x003e7b:	str     	r1, [sp]
0x003e7d:	str     	r1, [sp, #4]
0x003e7f:	ldr     	r1, [pc, #0x2c]
0x003e81:	str     	r2, [sp, #8]
0x003e83:	movs    	r3, #0
0x003e85:	ldr     	r0, [pc, #0x28]
0x003e87:	bl      	#0x4c2d
; block 0x3e8b
0x003e8b:	b       	#0x3d2d

; ===== sub_3e8d @ 0x3e8d offset=0x3e8c size=22 blocks=2 cc=1 =====
; block 0x3e8d
0x003e8d:	movs    	r1, #0
0x003e8f:	movs    	r2, #0
0x003e91:	str     	r1, [sp]
0x003e93:	str     	r1, [sp, #4]
0x003e95:	ldr     	r1, [pc, #0x14]
0x003e97:	str     	r2, [sp, #8]
0x003e99:	movs    	r3, #0
0x003e9b:	ldr     	r0, [pc, #0x18]
0x003e9d:	bl      	#0x4c2d
; block 0x3ea1
0x003ea1:	b       	#0x3d2d

; ===== sub_3ea9 @ 0x3ea9 offset=0x3ea8 size=16 blocks=1 cc=1 =====
; block 0x3ea9
0x003ea9:	movs    	r4, r0
0x003eab:	movs    	r0, r0
0x003ead:	adds    	r2, #1
0x003eaf:	movs    	r6, r1
0x003eb1:	lsls    	r6, r0, #4
0x003eb3:	movs    	r1, r0
0x003eb5:	lsls    	r7, r0, #4
0x003eb7:	movs    	r1, r0
0x003eb9:	push    	{r4, r5, r6, r7, lr}
0x003ebb:	sub     	sp, #0xc
0x003ebd:	adds    	r4, r0, #0
0x003ebf:	movs    	r1, #0
0x003ec1:	ldr     	r0, [pc, #0x2cc]
0x003ec3:	str     	r1, [sp]
0x003ec5:	str     	r1, [sp, #4]
0x003ec7:	movs    	r2, #0
0x003ec9:	str     	r2, [sp, #8]
0x003ecb:	add     	r0, sb
0x003ecd:	ldr     	r2, [r0, #0x28]
0x003ecf:	movs    	r0, #0xf1
0x003ed1:	movs    	r1, #0x11
0x003ed3:	movs    	r3, #4
0x003ed5:	lsls    	r0, r0, #9
0x003ed7:	bl      	#0x4c2d

; ===== sub_3eb9 @ 0x3eb9 offset=0x3eb8 size=706 blocks=52 cc=41 =====
; block 0x3eb9
0x003eb9:	push    	{r4, r5, r6, r7, lr}
0x003ebb:	sub     	sp, #0xc
0x003ebd:	adds    	r4, r0, #0
0x003ebf:	movs    	r1, #0
0x003ec1:	ldr     	r0, [pc, #0x2cc]
0x003ec3:	str     	r1, [sp]
0x003ec5:	str     	r1, [sp, #4]
0x003ec7:	movs    	r2, #0
0x003ec9:	str     	r2, [sp, #8]
0x003ecb:	add     	r0, sb
0x003ecd:	ldr     	r2, [r0, #0x28]
0x003ecf:	movs    	r0, #0xf1
0x003ed1:	movs    	r1, #0x11
0x003ed3:	movs    	r3, #4
0x003ed5:	lsls    	r0, r0, #9
0x003ed7:	bl      	#0x4c2d
; block 0x3edb
0x003edb:	subs    	r4, #2
0x003edd:	cmp     	r4, #0x13
0x003edf:	bhs     	#0x3f69
; block 0x3ee1
0x003ee1:	adr     	r3, #4
0x003ee3:	ldrb    	r3, [r3, r4]
0x003ee5:	lsls    	r3, r3, #1
0x003ee7:	add     	pc, r3
; block 0x3efd
0x003efd:	bl      	#0x5575
; block 0x3f01
0x003f01:	ldr     	r0, [pc, #0x28c]
0x003f03:	add     	r0, sb
0x003f05:	ldr     	r5, [r0, #0xc]
0x003f07:	cmp     	r5, #0
0x003f09:	bne     	#0x3f23
; block 0x3f0b
0x003f0b:	movs    	r1, #0
0x003f0d:	str     	r1, [sp]
0x003f0f:	str     	r1, [sp, #4]
0x003f11:	movs    	r2, #0
0x003f13:	movs    	r1, #0x2c
0x003f15:	movs    	r3, #0
0x003f17:	movs    	r0, #0xf1
0x003f19:	lsls    	r0, r0, #9
0x003f1b:	str     	r2, [sp, #8]
0x003f1d:	bl      	#0x4c2d
; block 0x3f21
0x003f21:	b       	#0x3f53
; block 0x3f23
0x003f23:	movs    	r1, #0
0x003f25:	movs    	r2, #0
0x003f27:	movs    	r4, #0
0x003f29:	adds    	r3, r4, #0
0x003f2b:	str     	r2, [sp, #8]
0x003f2d:	str     	r1, [sp]
0x003f2f:	str     	r1, [sp, #4]
0x003f31:	movs    	r1, #0xbe
0x003f33:	adds    	r2, r5, #0
0x003f35:	movs    	r0, #0xf1
0x003f37:	lsls    	r0, r0, #9
0x003f39:	bl      	#0x4c2d
; block 0x3f3d
0x003f3d:	movs    	r1, #0
0x003f3f:	str     	r1, [sp]
0x003f41:	str     	r1, [sp, #4]
0x003f43:	movs    	r2, #0
0x003f45:	movs    	r1, #0xbf
0x003f47:	adds    	r3, r4, #0
0x003f49:	movs    	r0, #0xf1
0x003f4b:	lsls    	r0, r0, #9
0x003f4d:	str     	r2, [sp, #8]
0x003f4f:	bl      	#0x4c2d
; block 0x3f53
0x003f53:	movs    	r1, #0
0x003f55:	str     	r1, [sp]
0x003f57:	str     	r1, [sp, #4]
0x003f59:	movs    	r2, #0
0x003f5b:	movs    	r1, #0x7d
0x003f5d:	movs    	r3, #0
0x003f5f:	movs    	r0, #0xf1
0x003f61:	lsls    	r0, r0, #9
0x003f63:	str     	r2, [sp, #8]
0x003f65:	bl      	#0x4c2d
; block 0x3f69
0x003f69:	add     	sp, #0xc
0x003f6b:	pop     	{r4, r5, r6, r7, pc}
; block 0x3f6d
0x003f6d:	ldr     	r1, [pc, #0x220]
0x003f6f:	add     	r1, sb
0x003f71:	ldr     	r0, [r1, #0x10]
0x003f73:	ldr     	r2, [r1, #0x40]
0x003f75:	subs    	r0, r0, r2
0x003f77:	str     	r0, [r1, #0x10]
0x003f79:	bpl     	#0x3f69
; block 0x3f7b
0x003f7b:	movs    	r0, #0
0x003f7d:	str     	r0, [r1, #0x10]
0x003f7f:	b       	#0x3f69
; block 0x3f81
0x003f81:	ldr     	r2, [pc, #0x20c]
0x003f83:	add     	r2, sb
0x003f85:	ldr     	r1, [r2, #0x10]
0x003f87:	ldr     	r3, [r2, #0x40]
0x003f89:	adds    	r1, r1, r3
0x003f8b:	str     	r1, [r2, #0x10]
0x003f8d:	cmp     	r1, r0
0x003f8f:	blt     	#0x3f69
; block 0x3f91
0x003f91:	subs    	r0, #1
0x003f93:	str     	r0, [r2, #0x10]
0x003f95:	b       	#0x3f69
; block 0x3f97
0x003f97:	ldr     	r1, [pc, #0x1f8]
0x003f99:	add     	r1, sb
0x003f9b:	ldr     	r0, [r1, #0x10]
0x003f9d:	subs    	r0, #1
0x003f9f:	str     	r0, [r1, #0x10]
0x003fa1:	bpl     	#0x3f69
; block 0x3fa3
0x003fa3:	movs    	r0, #0
0x003fa5:	str     	r0, [r1, #0x10]
0x003fa7:	b       	#0x3f69
; block 0x3fa9
0x003fa9:	ldr     	r2, [pc, #0x1e4]
0x003fab:	add     	r2, sb
0x003fad:	ldr     	r1, [r2, #0x10]
0x003faf:	adds    	r1, #1
0x003fb1:	str     	r1, [r2, #0x10]
0x003fb3:	cmp     	r1, r0
0x003fb5:	blt     	#0x3f69
; block 0x3fb7
0x003fb7:	subs    	r0, #1
0x003fb9:	str     	r0, [r2, #0x10]
0x003fbb:	b       	#0x3f69
; block 0x3fbd
0x003fbd:	ldr     	r7, [pc, #0x1d0]
0x003fbf:	movs    	r3, #2
0x003fc1:	add     	r7, sb
0x003fc3:	ldrsb   	r0, [r7, r3]
0x003fc5:	cmp     	r0, #1
0x003fc7:	bne     	#0x3fcf
; block 0x3fc9
0x003fc9:	movs    	r0, #0
0x003fcb:	strb    	r0, [r7, #2]
0x003fcd:	b       	#0x3f69
; block 0x3fcf
0x003fcf:	movs    	r3, #7
0x003fd1:	ldrsb   	r0, [r7, r3]
0x003fd3:	adds    	r3, r0, #1
0x003fd5:	bne     	#0x3ff1
; block 0x3fd7
0x003fd7:	movs    	r2, #0
0x003fd9:	str     	r2, [sp, #8]
0x003fdb:	movs    	r1, #0
0x003fdd:	ldr     	r2, [pc, #0x1b4]
0x003fdf:	str     	r1, [sp]
0x003fe1:	str     	r1, [sp, #4]
0x003fe3:	add     	r2, pc
0x003fe5:	movs    	r1, #0x33
0x003fe7:	movs    	r0, #0xf1
0x003fe9:	lsls    	r0, r0, #9
0x003feb:	bl      	#0x4c2d
; block 0x3fef
0x003fef:	b       	#0x3f69
; block 0x3ff1
0x003ff1:	ldr     	r1, [r7, #0x10]
0x003ff3:	ldr     	r2, [r7, #0x28]
0x003ff5:	lsls    	r1, r1, #2
0x003ff7:	ldr     	r1, [r2, r1]
0x003ff9:	cmp     	r1, #0
0x003ffb:	bne     	#0x4017
; block 0x3ffd
0x003ffd:	movs    	r2, #0
0x003fff:	str     	r2, [sp, #8]
0x004001:	ldr     	r2, [pc, #0x194]
0x004003:	movs    	r3, #0
0x004005:	str     	r1, [sp]
0x004007:	str     	r1, [sp, #4]
0x004009:	add     	r2, pc
0x00400b:	movs    	r1, #0x33
0x00400d:	movs    	r0, #0xf1
0x00400f:	lsls    	r0, r0, #9
0x004011:	bl      	#0x4c2d
; block 0x4015
0x004015:	b       	#0x3f69
; block 0x4017
0x004017:	movs    	r3, #1
0x004019:	ldrsb   	r1, [r7, r3]
0x00401b:	cmp     	r1, #0
0x00401d:	ble     	#0x4025
; block 0x401f
0x00401f:	ldr     	r4, [pc, #0x17c]
0x004021:	add     	r4, pc
0x004023:	b       	#0x4093
; block 0x4025
0x004025:	bl      	#0x3931
; block 0x4029
0x004029:	movs    	r1, #0
0x00402b:	str     	r1, [sp]
0x00402d:	str     	r1, [sp, #4]
0x00402f:	adds    	r4, r0, #0
0x004031:	movs    	r2, #0
0x004033:	movs    	r6, #0
0x004035:	adds    	r3, r6, #0
0x004037:	str     	r2, [sp, #8]
0x004039:	movs    	r0, #0xf1
0x00403b:	movs    	r1, #0x3f
0x00403d:	lsls    	r0, r0, #9
0x00403f:	ldr     	r2, [r7, #0x54]
0x004041:	bl      	#0x4c2d
; block 0x4045
0x004045:	movs    	r2, #0
0x004047:	movs    	r1, #0
0x004049:	str     	r2, [sp, #8]
0x00404b:	ldr     	r2, [pc, #0x154]
0x00404d:	adds    	r5, r0, #0
0x00404f:	adds    	r3, r4, #0
0x004051:	str     	r1, [sp]
0x004053:	str     	r1, [sp, #4]
0x004055:	add     	r2, pc
0x004057:	movs    	r1, #0x2d
0x004059:	movs    	r0, #0xf1
0x00405b:	lsls    	r0, r0, #9
0x00405d:	bl      	#0x4c2d
; block 0x4061
0x004061:	movs    	r2, #0
0x004063:	movs    	r1, #0
0x004065:	str     	r2, [sp, #8]
0x004067:	adds    	r3, r5, #0
0x004069:	adds    	r2, r0, #0
0x00406b:	str     	r1, [sp]
0x00406d:	str     	r1, [sp, #4]
0x00406f:	movs    	r1, #0x2d
0x004071:	movs    	r0, #0xf1
0x004073:	lsls    	r0, r0, #9
0x004075:	bl      	#0x4c2d
; block 0x4079
0x004079:	movs    	r1, #0
0x00407b:	adds    	r4, r0, #0
0x00407d:	movs    	r2, #0
0x00407f:	str     	r2, [sp, #8]
0x004081:	str     	r1, [sp]
0x004083:	str     	r1, [sp, #4]
0x004085:	adds    	r3, r6, #0
0x004087:	adds    	r2, r5, #0
0x004089:	movs    	r1, #9
0x00408b:	movs    	r0, #0xf1
0x00408d:	lsls    	r0, r0, #9
0x00408f:	bl      	#0x4c2d
; block 0x4093
0x004093:	movs    	r1, #0
0x004095:	movs    	r2, #0
0x004097:	str     	r2, [sp, #8]
0x004099:	str     	r1, [sp]
0x00409b:	str     	r1, [sp, #4]
0x00409d:	movs    	r5, #0
0x00409f:	movs    	r6, #0xf1
0x0040a1:	lsls    	r6, r6, #9
0x0040a3:	adds    	r3, r5, #0
0x0040a5:	movs    	r1, #0xe1
0x0040a7:	movs    	r2, #0x20
0x0040a9:	adds    	r0, r6, #0
0x0040ab:	bl      	#0x4c2d
; block 0x40af
0x0040af:	cmp     	r0, #0
0x0040b1:	bne     	#0x40cb
; block 0x40b3
0x0040b3:	movs    	r1, #0
0x0040b5:	movs    	r2, #0
0x0040b7:	str     	r2, [sp, #8]
0x0040b9:	str     	r1, [sp]
0x0040bb:	str     	r1, [sp, #4]
0x0040bd:	movs    	r1, #0x51
0x0040bf:	adds    	r2, r4, #0
0x0040c1:	adds    	r3, r5, #0
0x0040c3:	adds    	r0, r6, #0
0x0040c5:	bl      	#0x4c2d
; block 0x40c9
0x0040c9:	b       	#0x3f69
; block 0x40cb
0x0040cb:	movs    	r3, #7
0x0040cd:	ldrsb   	r0, [r7, r3]
0x0040cf:	cmp     	r0, #0
0x0040d1:	bne     	#0x4109
; block 0x40d3
0x0040d3:	movs    	r1, #0
0x0040d5:	movs    	r2, #0
0x0040d7:	str     	r2, [sp, #8]
0x0040d9:	str     	r1, [sp]
0x0040db:	str     	r1, [sp, #4]
0x0040dd:	movs    	r1, #0xe1
0x0040df:	movs    	r2, #0x69
0x0040e1:	adds    	r3, r5, #0
0x0040e3:	adds    	r0, r6, #0
0x0040e5:	bl      	#0x4c2d
; block 0x40e9
0x0040e9:	ldr     	r1, [r7, #0x54]
0x0040eb:	cmp     	r0, r1
0x0040ed:	bge     	#0x4109
; block 0x40ef
0x0040ef:	movs    	r2, #0
0x0040f1:	movs    	r1, #0
0x0040f3:	str     	r2, [sp, #8]
0x0040f5:	ldr     	r2, [pc, #0xac]
0x0040f7:	str     	r1, [sp]
0x0040f9:	str     	r1, [sp, #4]
0x0040fb:	adds    	r3, r5, #0
0x0040fd:	add     	r2, pc
0x0040ff:	movs    	r1, #0x33
0x004101:	adds    	r0, r6, #0
0x004103:	bl      	#0x4c2d
; block 0x4107
0x004107:	b       	#0x3f69
; block 0x4109
0x004109:	movs    	r3, #7
0x00410b:	ldrsb   	r0, [r7, r3]
0x00410d:	cmp     	r0, #1
0x00410f:	bne     	#0x4147
; block 0x4111
0x004111:	movs    	r1, #0
0x004113:	movs    	r2, #0
0x004115:	str     	r2, [sp, #8]
0x004117:	str     	r1, [sp]
0x004119:	str     	r1, [sp, #4]
0x00411b:	movs    	r1, #0xe1
0x00411d:	movs    	r2, #0x1c
0x00411f:	adds    	r3, r5, #0
0x004121:	adds    	r0, r6, #0
0x004123:	bl      	#0x4c2d
; block 0x4127
0x004127:	ldr     	r1, [r7, #0x54]
0x004129:	cmp     	r0, r1
0x00412b:	bge     	#0x4147
; block 0x412d
0x00412d:	movs    	r2, #0
0x00412f:	movs    	r1, #0
0x004131:	str     	r2, [sp, #8]
0x004133:	ldr     	r2, [pc, #0x74]
0x004135:	str     	r1, [sp]
0x004137:	str     	r1, [sp, #4]
0x004139:	adds    	r3, r5, #0
0x00413b:	add     	r2, pc
0x00413d:	movs    	r1, #0x33
0x00413f:	adds    	r0, r6, #0
0x004141:	bl      	#0x4c2d
; block 0x4145
0x004145:	b       	#0x3f69
; block 0x4147
0x004147:	movs    	r1, #0
0x004149:	str     	r1, [sp]
0x00414b:	str     	r1, [sp, #4]
0x00414d:	movs    	r2, #0
0x00414f:	movs    	r1, #0x34
0x004151:	adds    	r3, r5, #0
0x004153:	adds    	r0, r6, #0
0x004155:	str     	r2, [sp, #8]
0x004157:	bl      	#0x4c2d
; block 0x415b
0x00415b:	movs    	r1, #0
0x00415d:	movs    	r2, #0
0x00415f:	str     	r2, [sp, #8]
0x004161:	str     	r1, [sp]
0x004163:	str     	r1, [sp, #4]
0x004165:	movs    	r1, #0x14
0x004167:	movs    	r2, #0x20
0x004169:	adds    	r3, r5, #0
0x00416b:	movs    	r0, #0xf1
0x00416d:	lsls    	r0, r0, #9
0x00416f:	bl      	#0x4c2d
; block 0x4173
0x004173:	movs    	r2, #0
0x004175:	movs    	r1, #0
0x004177:	str     	r2, [sp, #8]
0x004179:	str     	r1, [sp]
0x00417b:	str     	r1, [sp, #4]
0x00417d:	movs    	r2, #0xff
0x00417f:	adds    	r2, #0x9c
0x004181:	movs    	r1, #0x50
0x004183:	movs    	r0, #0xf1
0x004185:	lsls    	r0, r0, #9
0x004187:	ldr     	r3, [r7, #0x10]
0x004189:	bl      	#0x4c2d
; block 0x418d
0x00418d:	b       	#0x3f69

; ===== sub_41ad @ 0x41ad offset=0x41ac size=622 blocks=44 cc=34 =====
; block 0x41ad
0x0041ad:	push    	{r4, r5, r6, r7, lr}
0x0041af:	movs    	r7, #0xf1
0x0041b1:	lsls    	r7, r7, #9
0x0041b3:	movs    	r6, #0
0x0041b5:	cmp     	r0, #5
0x0041b7:	sub     	sp, #0xc
0x0041b9:	beq     	#0x41c7
; block 0x41bb
0x0041bb:	cmp     	r0, #0x11
0x0041bd:	beq     	#0x41c7
; block 0x41bf
0x0041bf:	cmp     	r0, #0x12
0x0041c1:	beq     	#0x423f
; block 0x41c3
0x0041c3:	cmp     	r0, #0x14
0x0041c5:	bne     	#0x423b
; block 0x41c7
0x0041c7:	ldr     	r4, [pc, #0x254]
0x0041c9:	add     	r4, sb
0x0041cb:	ldr     	r0, [r4, #0x4c]
0x0041cd:	cmp     	r0, #0
0x0041cf:	beq     	#0x426f
; block 0x41d1
0x0041d1:	ldr     	r0, [r4, #0x30]
0x0041d3:	cmp     	r0, #0
0x0041d5:	bne     	#0x426f
; block 0x41d7
0x0041d7:	movs    	r1, #0
0x0041d9:	str     	r1, [sp]
0x0041db:	str     	r1, [sp, #4]
0x0041dd:	movs    	r2, #0
0x0041df:	movs    	r1, #0x34
0x0041e1:	adds    	r3, r6, #0
0x0041e3:	adds    	r0, r7, #0
0x0041e5:	str     	r2, [sp, #8]
0x0041e7:	bl      	#0x4c2d
; block 0x41eb
0x0041eb:	movs    	r2, #0
0x0041ed:	movs    	r1, #0
0x0041ef:	str     	r2, [sp, #8]
0x0041f1:	str     	r1, [sp]
0x0041f3:	str     	r1, [sp, #4]
0x0041f5:	ldr     	r0, [r4, #0x4c]
0x0041f7:	movs    	r2, #0xff
0x0041f9:	ldr     	r3, [r0]
0x0041fb:	movs    	r0, #0xf1
0x0041fd:	adds    	r2, #0x24
0x0041ff:	movs    	r1, #0x14
0x004201:	lsls    	r0, r0, #9
0x004203:	bl      	#0x4c2d
; block 0x4207
0x004207:	movs    	r2, #0
0x004209:	movs    	r1, #0
0x00420b:	str     	r2, [sp, #8]
0x00420d:	str     	r1, [sp]
0x00420f:	str     	r1, [sp, #4]
0x004211:	ldr     	r0, [r4, #0x4c]
0x004213:	movs    	r2, #0xff
0x004215:	ldr     	r3, [r0, #4]
0x004217:	movs    	r0, #0xf1
0x004219:	adds    	r2, #0x25
0x00421b:	movs    	r1, #0x14
0x00421d:	lsls    	r0, r0, #9
0x00421f:	bl      	#0x4c2d
; block 0x4223
0x004223:	movs    	r1, #0
0x004225:	movs    	r2, #0
0x004227:	str     	r2, [sp, #8]
0x004229:	subs    	r2, r1, #3
0x00422b:	str     	r1, [sp]
0x00422d:	str     	r1, [sp, #4]
0x00422f:	movs    	r1, #0xa1
0x004231:	movs    	r3, #0xa
0x004233:	movs    	r0, #0xf1
0x004235:	lsls    	r0, r0, #9
0x004237:	bl      	#0x4c2d
; block 0x423b
0x00423b:	add     	sp, #0xc
0x00423d:	pop     	{r4, r5, r6, r7, pc}
; block 0x423f
0x00423f:	movs    	r1, #0
0x004241:	str     	r1, [sp]
0x004243:	str     	r1, [sp, #4]
0x004245:	movs    	r2, #0
0x004247:	movs    	r1, #0xe6
0x004249:	adds    	r3, r6, #0
0x00424b:	adds    	r0, r7, #0
0x00424d:	str     	r2, [sp, #8]
0x00424f:	bl      	#0x4c2d
; block 0x4253
0x004253:	bl      	#0x5491
; block 0x4257
0x004257:	movs    	r1, #0
0x004259:	str     	r1, [sp]
0x00425b:	str     	r1, [sp, #4]
0x00425d:	movs    	r2, #0
0x00425f:	movs    	r1, #0x2c
0x004261:	adds    	r3, r6, #0
0x004263:	movs    	r0, #0xf1
0x004265:	lsls    	r0, r0, #9
0x004267:	str     	r2, [sp, #8]
0x004269:	bl      	#0x4c2d
; block 0x426d
0x00426d:	b       	#0x423b
; block 0x426f
0x00426f:	movs    	r3, #0
0x004271:	ldrsb   	r0, [r4, r3]
0x004273:	cmp     	r0, #0
0x004275:	bne     	#0x4291
; block 0x4277
0x004277:	movs    	r2, #0
0x004279:	movs    	r1, #0
0x00427b:	str     	r2, [sp, #8]
0x00427d:	ldr     	r2, [pc, #0x1a0]
0x00427f:	str     	r1, [sp]
0x004281:	str     	r1, [sp, #4]
0x004283:	adds    	r3, r6, #0
0x004285:	add     	r2, pc
0x004287:	movs    	r1, #0x33
0x004289:	adds    	r0, r7, #0
0x00428b:	bl      	#0x4c2d
; block 0x428f
0x00428f:	b       	#0x423b
; block 0x4291
0x004291:	movs    	r3, #6
0x004293:	ldrsb   	r0, [r4, r3]
0x004295:	cmp     	r0, #0
0x004297:	bne     	#0x42cf
; block 0x4299
0x004299:	movs    	r1, #0
0x00429b:	movs    	r2, #0
0x00429d:	str     	r2, [sp, #8]
0x00429f:	str     	r1, [sp]
0x0042a1:	str     	r1, [sp, #4]
0x0042a3:	movs    	r1, #0xe1
0x0042a5:	movs    	r2, #0x69
0x0042a7:	adds    	r3, r6, #0
0x0042a9:	adds    	r0, r7, #0
0x0042ab:	bl      	#0x4c2d
; block 0x42af
0x0042af:	ldr     	r1, [r4, #0x50]
0x0042b1:	cmp     	r0, r1
0x0042b3:	bge     	#0x42cf
; block 0x42b5
0x0042b5:	movs    	r2, #0
0x0042b7:	movs    	r1, #0
0x0042b9:	str     	r2, [sp, #8]
0x0042bb:	ldr     	r2, [pc, #0x168]
0x0042bd:	str     	r1, [sp]
0x0042bf:	str     	r1, [sp, #4]
0x0042c1:	adds    	r3, r6, #0
0x0042c3:	add     	r2, pc
0x0042c5:	movs    	r1, #0x33
0x0042c7:	adds    	r0, r7, #0
0x0042c9:	bl      	#0x4c2d
; block 0x42cd
0x0042cd:	b       	#0x423b
; block 0x42cf
0x0042cf:	movs    	r3, #6
0x0042d1:	ldrsb   	r0, [r4, r3]
0x0042d3:	cmp     	r0, #1
0x0042d5:	bne     	#0x430d
; block 0x42d7
0x0042d7:	movs    	r1, #0
0x0042d9:	movs    	r2, #0
0x0042db:	str     	r2, [sp, #8]
0x0042dd:	str     	r1, [sp]
0x0042df:	str     	r1, [sp, #4]
0x0042e1:	movs    	r1, #0xe1
0x0042e3:	movs    	r2, #0x1c
0x0042e5:	adds    	r3, r6, #0
0x0042e7:	adds    	r0, r7, #0
0x0042e9:	bl      	#0x4c2d
; block 0x42ed
0x0042ed:	ldr     	r1, [r4, #0x50]
0x0042ef:	cmp     	r0, r1
0x0042f1:	bge     	#0x430d
; block 0x42f3
0x0042f3:	movs    	r2, #0
0x0042f5:	movs    	r1, #0
0x0042f7:	str     	r2, [sp, #8]
0x0042f9:	ldr     	r2, [pc, #0x12c]
0x0042fb:	str     	r1, [sp]
0x0042fd:	str     	r1, [sp, #4]
0x0042ff:	adds    	r3, r6, #0
0x004301:	add     	r2, pc
0x004303:	movs    	r1, #0x33
0x004305:	adds    	r0, r7, #0
0x004307:	bl      	#0x4c2d
; block 0x430b
0x00430b:	b       	#0x423b
; block 0x430d
0x00430d:	movs    	r1, #0
0x00430f:	movs    	r2, #0
0x004311:	str     	r2, [sp, #8]
0x004313:	str     	r1, [sp]
0x004315:	str     	r1, [sp, #4]
0x004317:	movs    	r1, #0xe1
0x004319:	movs    	r2, #0x20
0x00431b:	adds    	r3, r6, #0
0x00431d:	adds    	r0, r7, #0
0x00431f:	bl      	#0x4c2d
; block 0x4323
0x004323:	cmp     	r0, #0
0x004325:	bne     	#0x435b
; block 0x4327
0x004327:	ldr     	r5, [pc, #0x104]
0x004329:	add     	r5, pc
0x00432b:	movs    	r1, #0
0x00432d:	movs    	r2, #0
0x00432f:	str     	r2, [sp, #8]
0x004331:	str     	r1, [sp]
0x004333:	str     	r1, [sp, #4]
0x004335:	movs    	r1, #0x2d
0x004337:	adds    	r2, r5, #0
0x004339:	adds    	r0, r7, #0
0x00433b:	ldr     	r3, [r4, #0x5c]
0x00433d:	bl      	#0x4c2d
; block 0x4341
0x004341:	movs    	r2, #0
0x004343:	movs    	r1, #0
0x004345:	str     	r2, [sp, #8]
0x004347:	adds    	r3, r6, #0
0x004349:	adds    	r2, r0, #0
0x00434b:	str     	r1, [sp]
0x00434d:	str     	r1, [sp, #4]
0x00434f:	movs    	r1, #0x51
0x004351:	movs    	r0, #0xf1
0x004353:	lsls    	r0, r0, #9
0x004355:	bl      	#0x4c2d
; block 0x4359
0x004359:	b       	#0x423b
; block 0x435b
0x00435b:	ldr     	r1, [r4, #0x38]
0x00435d:	ldr     	r2, [r4, #0x6c]
0x00435f:	ldr     	r1, [r1]
0x004361:	lsls    	r2, r2, #2
0x004363:	ldr     	r1, [r1, r2]
0x004365:	ldr     	r2, [r4, #0x70]
0x004367:	ldr     	r1, [r1, #0xc]
0x004369:	lsls    	r2, r2, #2
0x00436b:	ldr     	r1, [r1, r2]
0x00436d:	adds    	r0, r4, #0
0x00436f:	ldr     	r4, [r1]
0x004371:	ldr     	r0, [r0, #0x30]
0x004373:	movs    	r5, #0
0x004375:	mvns    	r5, r5
0x004377:	cmp     	r0, #0
0x004379:	beq     	#0x437d
; block 0x437b
0x00437b:	ldr     	r5, [r0]
0x00437d:	movs    	r1, #0
0x00437f:	movs    	r2, #0
0x004381:	str     	r2, [sp, #8]
0x004383:	str     	r1, [sp]
0x004385:	str     	r1, [sp, #4]
0x004387:	movs    	r1, #0x9c
0x004389:	movs    	r2, #0x12
0x00438b:	adds    	r3, r6, #0
0x00438d:	adds    	r0, r7, #0
0x00438f:	bl      	#0x4c2d
; block 0x437d
0x00437d:	movs    	r1, #0
0x00437f:	movs    	r2, #0
0x004381:	str     	r2, [sp, #8]
0x004383:	str     	r1, [sp]
0x004385:	str     	r1, [sp, #4]
0x004387:	movs    	r1, #0x9c
0x004389:	movs    	r2, #0x12
0x00438b:	adds    	r3, r6, #0
0x00438d:	adds    	r0, r7, #0
0x00438f:	bl      	#0x4c2d
; block 0x4393
0x004393:	movs    	r1, #0
0x004395:	str     	r1, [sp]
0x004397:	str     	r1, [sp, #4]
0x004399:	movs    	r2, #0
0x00439b:	movs    	r1, #0x34
0x00439d:	adds    	r3, r6, #0
0x00439f:	movs    	r0, #0xf1
0x0043a1:	lsls    	r0, r0, #9
0x0043a3:	str     	r2, [sp, #8]
0x0043a5:	bl      	#0x4c2d
; block 0x43a9
0x0043a9:	movs    	r1, #0
0x0043ab:	movs    	r2, #0
0x0043ad:	str     	r2, [sp, #8]
0x0043af:	str     	r1, [sp]
0x0043b1:	str     	r1, [sp, #4]
0x0043b3:	movs    	r1, #0x14
0x0043b5:	movs    	r2, #0x20
0x0043b7:	adds    	r3, r6, #0
0x0043b9:	movs    	r0, #0xf1
0x0043bb:	lsls    	r0, r0, #9
0x0043bd:	bl      	#0x4c2d
; block 0x43c1
0x0043c1:	movs    	r1, #0
0x0043c3:	movs    	r2, #0
0x0043c5:	str     	r2, [sp, #8]
0x0043c7:	str     	r1, [sp]
0x0043c9:	str     	r1, [sp, #4]
0x0043cb:	movs    	r1, #0xe1
0x0043cd:	movs    	r2, #0x17
0x0043cf:	adds    	r3, r6, #0
0x0043d1:	movs    	r0, #0xf1
0x0043d3:	lsls    	r0, r0, #9
0x0043d5:	bl      	#0x4c2d
; block 0x43d9
0x0043d9:	subs    	r0, #0xff
0x0043db:	movs    	r6, #0xff
0x0043dd:	adds    	r6, #0x1d
0x0043df:	subs    	r0, #0x3c
0x0043e1:	cmp     	r0, #0
0x0043e3:	bne     	#0x43ff
; block 0x43e5
0x0043e5:	movs    	r2, #0
0x0043e7:	str     	r2, [sp, #8]
0x0043e9:	movs    	r1, #0
0x0043eb:	str     	r1, [sp, #4]
0x0043ed:	movs    	r2, #0xff
0x0043ef:	adds    	r2, #0x96
0x0043f1:	adds    	r1, r6, #0
0x0043f3:	adds    	r3, r4, #0
0x0043f5:	adds    	r0, r7, #0
0x0043f7:	str     	r5, [sp]
0x0043f9:	bl      	#0x4c2d
; block 0x43fd
0x0043fd:	b       	#0x423b
; block 0x43ff
0x0043ff:	movs    	r1, #0
0x004401:	movs    	r2, #0
0x004403:	str     	r2, [sp, #8]
0x004405:	mvns    	r0, r1
0x004407:	movs    	r2, #0xff
0x004409:	str     	r1, [sp, #4]
0x00440b:	adds    	r1, r6, #0
0x00440d:	adds    	r2, #0x99
0x00440f:	str     	r0, [sp]
0x004411:	adds    	r3, r4, #0
0x004413:	adds    	r0, r7, #0
0x004415:	bl      	#0x4c2d
; block 0x4419
0x004419:	b       	#0x423b

; ===== sub_4431 @ 0x4431 offset=0x4430 size=24 blocks=3 cc=1 =====
; block 0x4431
0x004431:	push    	{r4, r5, r6, r7, lr}
0x004433:	subs    	r0, #2
0x004435:	cmp     	r0, #0x13
0x004437:	sub     	sp, #0xc
0x004439:	bhs     	#0x4445
; block 0x443b
0x00443b:	adr     	r3, #0xc
0x00443d:	adds    	r3, r3, r0
0x00443f:	ldrh    	r3, [r3, r0]
0x004441:	lsls    	r3, r3, #1
0x004443:	add     	pc, r3
; block 0x4445
0x004445:	add     	sp, #0xc
0x004447:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_4449 @ 0x4449 offset=0x4448 size=38 blocks=1 cc=1 =====
; block 0x4449
0x004449:	lsls    	r5, r4, #3
0x00444b:	movs    	r4, r2
0x00444d:	lsls    	r6, r2, #1
0x00444f:	lsls    	r0, r3, #4
0x004451:	lsls    	r4, r0, #2
0x004453:	movs    	r4, r2
0x004455:	lsls    	r2, r6, #2
0x004457:	movs    	r4, r2
0x004459:	movs    	r4, r2
0x00445b:	movs    	r4, r2
0x00445d:	lsls    	r5, r4, #3
0x00445f:	lsls    	r2, r6, #2
0x004461:	lsls    	r6, r2, #1
0x004463:	lsls    	r4, r0, #2
0x004465:	movs    	r4, r2
0x004467:	lsls    	r0, r3, #4
0x004469:	movs    	r5, r2
0x00446b:	movs    	r4, r2
0x00446d:	lsls    	r0, r3, #4
0x00446f:	b       	#0x4445

; ===== sub_446f @ 0x446f offset=0x446e size=2 blocks=1 cc=1 =====
; block 0x446f
0x00446f:	b       	#0x4445

; ===== sub_4471 @ 0x4471 offset=0x4470 size=128 blocks=8 cc=6 =====
; block 0x4471
0x004471:	movs    	r1, #0
0x004473:	str     	r1, [sp]
0x004475:	str     	r1, [sp, #4]
0x004477:	movs    	r2, #0
0x004479:	movs    	r4, #0
0x00447b:	movs    	r5, #0xf1
0x00447d:	lsls    	r5, r5, #9
0x00447f:	adds    	r3, r4, #0
0x004481:	movs    	r1, #0xe6
0x004483:	adds    	r0, r5, #0
0x004485:	str     	r2, [sp, #8]
0x004487:	bl      	#0x4c2d
; block 0x448b
0x00448b:	ldr     	r6, [pc, #0x2c4]
0x00448d:	add     	r6, sb
0x00448f:	ldr     	r0, [r6, #0x38]
0x004491:	bl      	#0x575d
; block 0x4495
0x004495:	ldr     	r6, [r6, #0xc]
0x004497:	cmp     	r6, #0
0x004499:	bne     	#0x44b1
; block 0x449b
0x00449b:	movs    	r1, #0
0x00449d:	str     	r1, [sp]
0x00449f:	str     	r1, [sp, #4]
0x0044a1:	movs    	r2, #0
0x0044a3:	movs    	r1, #0x2c
0x0044a5:	adds    	r3, r4, #0
0x0044a7:	adds    	r0, r5, #0
0x0044a9:	str     	r2, [sp, #8]
0x0044ab:	bl      	#0x4c2d
; block 0x44af
0x0044af:	b       	#0x44dd
; block 0x44b1
0x0044b1:	movs    	r1, #0
0x0044b3:	movs    	r2, #0
0x0044b5:	str     	r2, [sp, #8]
0x0044b7:	str     	r1, [sp]
0x0044b9:	str     	r1, [sp, #4]
0x0044bb:	movs    	r1, #0xbe
0x0044bd:	adds    	r2, r6, #0
0x0044bf:	adds    	r3, r4, #0
0x0044c1:	adds    	r0, r5, #0
0x0044c3:	bl      	#0x4c2d
; block 0x44c7
0x0044c7:	movs    	r1, #0
0x0044c9:	str     	r1, [sp]
0x0044cb:	str     	r1, [sp, #4]
0x0044cd:	movs    	r2, #0
0x0044cf:	movs    	r1, #0xbf
0x0044d1:	adds    	r3, r4, #0
0x0044d3:	movs    	r0, #0xf1
0x0044d5:	lsls    	r0, r0, #9
0x0044d7:	str     	r2, [sp, #8]
0x0044d9:	bl      	#0x4c2d
; block 0x44dd
0x0044dd:	movs    	r1, #0
0x0044df:	str     	r1, [sp]
0x0044e1:	str     	r1, [sp, #4]
0x0044e3:	movs    	r2, #0
0x0044e5:	movs    	r1, #0x7d
0x0044e7:	adds    	r3, r4, #0
0x0044e9:	adds    	r0, r5, #0
0x0044eb:	str     	r2, [sp, #8]
0x0044ed:	bl      	#0x4c2d

; ===== sub_44f3 @ 0x44f3 offset=0x44f2 size=90 blocks=3 cc=3 =====
; block 0x44f3
0x0044f3:	ldr     	r5, [pc, #0x25c]
0x0044f5:	movs    	r4, #0
0x0044f7:	add     	r5, sb
0x0044f9:	str     	r4, [r5, #0x3c]
0x0044fb:	str     	r4, [r5, #0x70]
0x0044fd:	movs    	r1, #0
0x0044ff:	str     	r1, [sp]
0x004501:	str     	r1, [sp, #4]
0x004503:	movs    	r2, #0
0x004505:	movs    	r1, #0xe6
0x004507:	adds    	r3, r4, #0
0x004509:	movs    	r0, #0xf1
0x00450b:	lsls    	r0, r0, #9
0x00450d:	str     	r2, [sp, #8]
0x00450f:	bl      	#0x4c2d
; block 0x4513
0x004513:	movs    	r1, #0
0x004515:	movs    	r2, #0
0x004517:	str     	r2, [sp, #8]
0x004519:	str     	r1, [sp]
0x00451b:	str     	r1, [sp, #4]
0x00451d:	ldr     	r0, [r5, #0x38]
0x00451f:	movs    	r1, #0x11
0x004521:	ldr     	r2, [r0]
0x004523:	movs    	r0, #0xf1
0x004525:	movs    	r3, #4
0x004527:	lsls    	r0, r0, #9
0x004529:	bl      	#0x4c2d
; block 0x452d
0x00452d:	adds    	r5, r0, #0
0x00452f:	ldr     	r0, [pc, #0x220]
0x004531:	movs    	r2, #0
0x004533:	add     	r0, sb
0x004535:	adds    	r0, #0x6c
0x004537:	movs    	r1, #0
0x004539:	str     	r1, [sp, #4]
0x00453b:	str     	r0, [sp]
0x00453d:	str     	r2, [sp, #8]
0x00453f:	adds    	r3, r4, #0
0x004541:	adds    	r2, r5, #0
0x004543:	movs    	r0, #0xf1
0x004545:	movs    	r1, #0x29
0x004547:	lsls    	r0, r0, #9
0x004549:	bl      	#0x4c2d

; ===== sub_454f @ 0x454f offset=0x454e size=92 blocks=4 cc=3 =====
; block 0x454f
0x00454f:	ldr     	r5, [pc, #0x200]
0x004551:	movs    	r4, #0
0x004553:	add     	r5, sb
0x004555:	str     	r4, [r5, #0x3c]
0x004557:	str     	r4, [r5, #0x70]
0x004559:	movs    	r1, #0
0x00455b:	str     	r1, [sp]
0x00455d:	str     	r1, [sp, #4]
0x00455f:	movs    	r2, #0
0x004561:	movs    	r1, #0xe6
0x004563:	adds    	r3, r4, #0
0x004565:	movs    	r0, #0xf1
0x004567:	lsls    	r0, r0, #9
0x004569:	str     	r2, [sp, #8]
0x00456b:	bl      	#0x4c2d
; block 0x456f
0x00456f:	movs    	r1, #0
0x004571:	movs    	r2, #0
0x004573:	str     	r2, [sp, #8]
0x004575:	str     	r1, [sp]
0x004577:	str     	r1, [sp, #4]
0x004579:	ldr     	r0, [r5, #0x38]
0x00457b:	movs    	r1, #0x11
0x00457d:	ldr     	r2, [r0]
0x00457f:	movs    	r0, #0xf1
0x004581:	movs    	r3, #4
0x004583:	lsls    	r0, r0, #9
0x004585:	bl      	#0x4c2d
; block 0x4589
0x004589:	adds    	r5, r0, #0
0x00458b:	ldr     	r0, [pc, #0x1c4]
0x00458d:	movs    	r2, #0
0x00458f:	add     	r0, sb
0x004591:	adds    	r0, #0x6c
0x004593:	movs    	r1, #1
0x004595:	str     	r1, [sp, #4]
0x004597:	str     	r0, [sp]
0x004599:	str     	r2, [sp, #8]
0x00459b:	adds    	r3, r4, #0
0x00459d:	adds    	r2, r5, #0
0x00459f:	movs    	r0, #0xf1
0x0045a1:	movs    	r1, #0x29
0x0045a3:	lsls    	r0, r0, #9
0x0045a5:	bl      	#0x4c2d
; block 0x45a9
0x0045a9:	b       	#0x4445

; ===== sub_45ab @ 0x45ab offset=0x45aa size=102 blocks=5 cc=3 =====
; block 0x44f1
0x0044f1:	b       	#0x4445
; block 0x45ab
0x0045ab:	ldr     	r4, [pc, #0x1a4]
0x0045ad:	add     	r4, sb
0x0045af:	ldr     	r0, [r4, #0x3c]
0x0045b1:	cmp     	r0, #1
0x0045b3:	bne     	#0x44f1
; block 0x45b5
0x0045b5:	movs    	r1, #0
0x0045b7:	str     	r1, [sp]
0x0045b9:	str     	r1, [sp, #4]
0x0045bb:	movs    	r2, #0
0x0045bd:	movs    	r5, #0
0x0045bf:	adds    	r3, r5, #0
0x0045c1:	movs    	r1, #0xe6
0x0045c3:	movs    	r0, #0xf1
0x0045c5:	lsls    	r0, r0, #9
0x0045c7:	str     	r2, [sp, #8]
0x0045c9:	bl      	#0x4c2d
; block 0x45cd
0x0045cd:	movs    	r1, #0
0x0045cf:	movs    	r2, #0
0x0045d1:	str     	r2, [sp, #8]
0x0045d3:	str     	r1, [sp]
0x0045d5:	str     	r1, [sp, #4]
0x0045d7:	ldr     	r0, [r4, #0x38]
0x0045d9:	ldr     	r1, [r4, #0x6c]
0x0045db:	ldr     	r0, [r0]
0x0045dd:	lsls    	r1, r1, #2
0x0045df:	ldr     	r0, [r0, r1]
0x0045e1:	movs    	r1, #0x11
0x0045e3:	ldr     	r2, [r0, #0xc]
0x0045e5:	movs    	r0, #0xf1
0x0045e7:	movs    	r3, #4
0x0045e9:	lsls    	r0, r0, #9
0x0045eb:	bl      	#0x4c2d
; block 0x45ef
0x0045ef:	adds    	r4, r0, #0
0x0045f1:	ldr     	r0, [pc, #0x15c]
0x0045f3:	movs    	r2, #0
0x0045f5:	add     	r0, sb
0x0045f7:	adds    	r0, #0x70
0x0045f9:	movs    	r1, #1
0x0045fb:	str     	r1, [sp, #4]
0x0045fd:	str     	r0, [sp]
0x0045ff:	str     	r2, [sp, #8]
0x004601:	adds    	r3, r5, #0
0x004603:	adds    	r2, r4, #0
0x004605:	movs    	r0, #0xf1
0x004607:	movs    	r1, #0x29
0x004609:	lsls    	r0, r0, #9
0x00460b:	bl      	#0x4c2d

; ===== sub_4611 @ 0x4611 offset=0x4610 size=104 blocks=6 cc=4 =====
; block 0x454d
0x00454d:	b       	#0x4445
; block 0x4611
0x004611:	ldr     	r4, [pc, #0x13c]
0x004613:	add     	r4, sb
0x004615:	ldr     	r0, [r4, #0x3c]
0x004617:	cmp     	r0, #1
0x004619:	bne     	#0x454d
; block 0x461b
0x00461b:	movs    	r1, #0
0x00461d:	str     	r1, [sp]
0x00461f:	str     	r1, [sp, #4]
0x004621:	movs    	r2, #0
0x004623:	movs    	r5, #0
0x004625:	adds    	r3, r5, #0
0x004627:	movs    	r1, #0xe6
0x004629:	movs    	r0, #0xf1
0x00462b:	lsls    	r0, r0, #9
0x00462d:	str     	r2, [sp, #8]
0x00462f:	bl      	#0x4c2d
; block 0x4633
0x004633:	movs    	r1, #0
0x004635:	movs    	r2, #0
0x004637:	str     	r2, [sp, #8]
0x004639:	str     	r1, [sp]
0x00463b:	str     	r1, [sp, #4]
0x00463d:	ldr     	r0, [r4, #0x38]
0x00463f:	ldr     	r1, [r4, #0x6c]
0x004641:	ldr     	r0, [r0]
0x004643:	lsls    	r1, r1, #2
0x004645:	ldr     	r0, [r0, r1]
0x004647:	movs    	r1, #0x11
0x004649:	ldr     	r2, [r0, #0xc]
0x00464b:	movs    	r0, #0xf1
0x00464d:	movs    	r3, #4
0x00464f:	lsls    	r0, r0, #9
0x004651:	bl      	#0x4c2d
; block 0x4655
0x004655:	adds    	r4, r0, #0
0x004657:	ldr     	r0, [pc, #0xf8]
0x004659:	movs    	r2, #0
0x00465b:	add     	r0, sb
0x00465d:	adds    	r0, #0x70
0x00465f:	movs    	r1, #0
0x004661:	str     	r1, [sp, #4]
0x004663:	str     	r0, [sp]
0x004665:	str     	r2, [sp, #8]
0x004667:	adds    	r3, r5, #0
0x004669:	adds    	r2, r4, #0
0x00466b:	movs    	r0, #0xf1
0x00466d:	movs    	r1, #0x29
0x00466f:	lsls    	r0, r0, #9
0x004671:	bl      	#0x4c2d
; block 0x4675
0x004675:	b       	#0x4445

; ===== sub_4677 @ 0x4677 offset=0x4676 size=220 blocks=15 cc=10 =====
; block 0x460f
0x00460f:	b       	#0x4445
; block 0x4677
0x004677:	ldr     	r6, [pc, #0xd8]
0x004679:	add     	r6, sb
0x00467b:	ldr     	r0, [r6, #0x3c]
0x00467d:	cmp     	r0, #0
0x00467f:	bne     	#0x46b1
; block 0x4681
0x004681:	movs    	r1, #0
0x004683:	movs    	r2, #0
0x004685:	str     	r2, [sp, #8]
0x004687:	str     	r1, [sp]
0x004689:	str     	r1, [sp, #4]
0x00468b:	ldr     	r0, [r6, #0x38]
0x00468d:	ldr     	r1, [r6, #0x6c]
0x00468f:	ldr     	r0, [r0]
0x004691:	lsls    	r1, r1, #2
0x004693:	ldr     	r0, [r0, r1]
0x004695:	movs    	r1, #0x11
0x004697:	ldr     	r2, [r0, #0xc]
0x004699:	movs    	r0, #0xf1
0x00469b:	movs    	r3, #4
0x00469d:	lsls    	r0, r0, #9
0x00469f:	bl      	#0x4c2d
; block 0x46a3
0x0046a3:	cmp     	r0, #0
0x0046a5:	beq     	#0x460f
; block 0x46a7
0x0046a7:	movs    	r0, #1
0x0046a9:	str     	r0, [r6, #0x3c]
0x0046ab:	movs    	r0, #0
0x0046ad:	str     	r0, [r6, #0x70]
0x0046af:	b       	#0x4445
; block 0x46b1
0x0046b1:	ldr     	r0, [r6, #0x38]
0x0046b3:	ldr     	r1, [r6, #0x6c]
0x0046b5:	ldr     	r0, [r0]
0x0046b7:	lsls    	r1, r1, #2
0x0046b9:	ldr     	r0, [r0, r1]
0x0046bb:	ldr     	r1, [r6, #0x70]
0x0046bd:	ldr     	r0, [r0, #0xc]
0x0046bf:	lsls    	r1, r1, #2
0x0046c1:	ldr     	r0, [r0, r1]
0x0046c3:	movs    	r1, #0
0x0046c5:	ldr     	r4, [r0]
0x0046c7:	str     	r1, [sp]
0x0046c9:	str     	r1, [sp, #4]
0x0046cb:	movs    	r2, #0
0x0046cd:	movs    	r7, #0
0x0046cf:	movs    	r5, #0xf1
0x0046d1:	lsls    	r5, r5, #9
0x0046d3:	adds    	r3, r7, #0
0x0046d5:	movs    	r1, #0x34
0x0046d7:	adds    	r0, r5, #0
0x0046d9:	str     	r2, [sp, #8]
0x0046db:	bl      	#0x4c2d
; block 0x46df
0x0046df:	movs    	r1, #0
0x0046e1:	movs    	r2, #0
0x0046e3:	str     	r2, [sp, #8]
0x0046e5:	str     	r1, [sp]
0x0046e7:	str     	r1, [sp, #4]
0x0046e9:	movs    	r1, #0xe1
0x0046eb:	movs    	r2, #0x17
0x0046ed:	adds    	r3, r7, #0
0x0046ef:	adds    	r0, r5, #0
0x0046f1:	bl      	#0x4c2d
; block 0x46f5
0x0046f5:	subs    	r0, #0xff
0x0046f7:	subs    	r0, #0x3c
0x0046f9:	bne     	#0x4737
; block 0x46fb
0x0046fb:	movs    	r3, #3
0x0046fd:	ldrsb   	r0, [r6, r3]
0x0046ff:	cmp     	r0, #0
0x004701:	beq     	#0x471d
; block 0x4703
0x004703:	movs    	r2, #0
0x004705:	movs    	r1, #0
0x004707:	str     	r2, [sp, #8]
0x004709:	movs    	r2, #0xff
0x00470b:	str     	r1, [sp]
0x00470d:	str     	r1, [sp, #4]
0x00470f:	movs    	r1, #0x50
0x004711:	adds    	r2, #0xa6
0x004713:	adds    	r3, r4, #0
0x004715:	adds    	r0, r5, #0
0x004717:	bl      	#0x4c2d
; block 0x471b
0x00471b:	b       	#0x4445
; block 0x471d
0x00471d:	movs    	r2, #0
0x00471f:	movs    	r1, #0
0x004721:	str     	r2, [sp, #8]
0x004723:	movs    	r2, #0xff
0x004725:	str     	r1, [sp]
0x004727:	str     	r1, [sp, #4]
0x004729:	movs    	r1, #0x50
0x00472b:	adds    	r2, #0x95
0x00472d:	adds    	r3, r4, #0
0x00472f:	adds    	r0, r5, #0
0x004731:	bl      	#0x4c2d
; block 0x4735
0x004735:	b       	#0x4445
; block 0x4737
0x004737:	movs    	r2, #0
0x004739:	movs    	r1, #0
0x00473b:	str     	r2, [sp, #8]
0x00473d:	movs    	r2, #0xff
0x00473f:	str     	r1, [sp]
0x004741:	str     	r1, [sp, #4]
0x004743:	movs    	r1, #0x50
0x004745:	adds    	r2, #0x98
0x004747:	adds    	r3, r4, #0
0x004749:	adds    	r0, r5, #0
0x00474b:	bl      	#0x4c2d
; block 0x474f
0x00474f:	b       	#0x4445

; ===== sub_4751 @ 0x4751 offset=0x4750 size=4 blocks=1 cc=1 =====
; block 0x4751
0x004751:	movs    	r4, r0
0x004753:	movs    	r0, r0
0x004755:	push    	{r4, r5, r6, r7, lr}
0x004757:	sub     	sp, #0x14
0x004759:	movs    	r1, #0
0x00475b:	movs    	r2, #0
0x00475d:	str     	r2, [sp, #8]
0x00475f:	str     	r1, [sp]
0x004761:	str     	r1, [sp, #4]
0x004763:	movs    	r7, #0xf1
0x004765:	movs    	r6, #0
0x004767:	adds    	r3, r6, #0
0x004769:	lsls    	r7, r7, #9
0x00476b:	movs    	r1, #0xe1
0x00476d:	movs    	r2, #0x20
0x00476f:	adds    	r4, r0, #0
0x004771:	adds    	r0, r7, #0
0x004773:	bl      	#0x4c2d

; ===== sub_4755 @ 0x4755 offset=0x4754 size=984 blocks=82 cc=56 =====
; block 0x4755
0x004755:	push    	{r4, r5, r6, r7, lr}
0x004757:	sub     	sp, #0x14
0x004759:	movs    	r1, #0
0x00475b:	movs    	r2, #0
0x00475d:	str     	r2, [sp, #8]
0x00475f:	str     	r1, [sp]
0x004761:	str     	r1, [sp, #4]
0x004763:	movs    	r7, #0xf1
0x004765:	movs    	r6, #0
0x004767:	adds    	r3, r6, #0
0x004769:	lsls    	r7, r7, #9
0x00476b:	movs    	r1, #0xe1
0x00476d:	movs    	r2, #0x20
0x00476f:	adds    	r4, r0, #0
0x004771:	adds    	r0, r7, #0
0x004773:	bl      	#0x4c2d
; block 0x4777
0x004777:	cmp     	r0, #1
0x004779:	bne     	#0x4781
; block 0x477b
0x00477b:	cmp     	r4, #0x11
0x00477d:	bne     	#0x4781
; block 0x477f
0x00477f:	movs    	r4, #0x14
0x004781:	ldr     	r5, [pc, #0x3a0]
0x004783:	cmp     	r4, #0xd
0x004785:	add     	r5, sb
0x004787:	beq     	#0x4859
; block 0x4781
0x004781:	ldr     	r5, [pc, #0x3a0]
0x004783:	cmp     	r4, #0xd
0x004785:	add     	r5, sb
0x004787:	beq     	#0x4859
; block 0x4789
0x004789:	bgt     	#0x47a5
; block 0x478b
0x00478b:	cmp     	r4, #2
0x00478d:	beq     	#0x479b
; block 0x478f
0x00478f:	cmp     	r4, #5
0x004791:	beq     	#0x47b1
; block 0x4793
0x004793:	cmp     	r4, #8
0x004795:	beq     	#0x4859
; block 0x4797
0x004797:	cmp     	r4, #0xc
0x004799:	bne     	#0x47a1
; block 0x479b
0x00479b:	bl      	#0x3655
; block 0x479f
0x00479f:	str     	r0, [r5, #0x24]
0x0047a1:	add     	sp, #0x14
0x0047a3:	pop     	{r4, r5, r6, r7, pc}
; block 0x47a1
0x0047a1:	add     	sp, #0x14
0x0047a3:	pop     	{r4, r5, r6, r7, pc}
; block 0x47a5
0x0047a5:	cmp     	r4, #0x11
0x0047a7:	beq     	#0x487f
; block 0x47a9
0x0047a9:	cmp     	r4, #0x12
0x0047ab:	beq     	#0x47ed
; block 0x47ad
0x0047ad:	cmp     	r4, #0x14
0x0047af:	bne     	#0x47a1
; block 0x47b1
0x0047b1:	ldr     	r0, [r5, #0x48]
0x0047b3:	cmp     	r0, #0
0x0047b5:	bne     	#0x485b
; block 0x47b7
0x0047b7:	str     	r6, [r5, #0x24]
0x0047b9:	movs    	r1, #0
0x0047bb:	movs    	r2, #0
0x0047bd:	str     	r2, [sp, #8]
0x0047bf:	str     	r1, [sp]
0x0047c1:	str     	r1, [sp, #4]
0x0047c3:	movs    	r1, #0x9c
0x0047c5:	movs    	r2, #0x11
0x0047c7:	adds    	r3, r6, #0
0x0047c9:	adds    	r0, r7, #0
0x0047cb:	bl      	#0x4c2d
; block 0x47cf
0x0047cf:	movs    	r2, #0
0x0047d1:	movs    	r1, #0
0x0047d3:	str     	r2, [sp, #8]
0x0047d5:	ldr     	r2, [pc, #0x350]
0x0047d7:	str     	r1, [sp]
0x0047d9:	str     	r1, [sp, #4]
0x0047db:	adds    	r3, r6, #0
0x0047dd:	add     	r2, pc
0x0047df:	movs    	r1, #0x33
0x0047e1:	movs    	r0, #0xf1
0x0047e3:	lsls    	r0, r0, #9
0x0047e5:	bl      	#0x4c2d
; block 0x47e9
0x0047e9:	str     	r6, [r5, #0x24]
0x0047eb:	b       	#0x47a1
; block 0x47ed
0x0047ed:	ldr     	r4, [r5, #0x20]
0x0047ef:	cmp     	r4, #0
0x0047f1:	beq     	#0x480b
; block 0x47f3
0x0047f3:	movs    	r1, #0
0x0047f5:	movs    	r2, #0
0x0047f7:	str     	r2, [sp, #8]
0x0047f9:	str     	r1, [sp]
0x0047fb:	str     	r1, [sp, #4]
0x0047fd:	movs    	r1, #9
0x0047ff:	adds    	r2, r4, #0
0x004801:	adds    	r3, r6, #0
0x004803:	adds    	r0, r7, #0
0x004805:	bl      	#0x4c2d
; block 0x4809
0x004809:	str     	r6, [r5, #0x20]
0x00480b:	ldr     	r4, [r5, #0x1c]
0x00480d:	cmp     	r4, #0
0x00480f:	beq     	#0x4829
; block 0x480b
0x00480b:	ldr     	r4, [r5, #0x1c]
0x00480d:	cmp     	r4, #0
0x00480f:	beq     	#0x4829
; block 0x4811
0x004811:	movs    	r1, #0
0x004813:	movs    	r2, #0
0x004815:	str     	r2, [sp, #8]
0x004817:	str     	r1, [sp]
0x004819:	str     	r1, [sp, #4]
0x00481b:	movs    	r1, #9
0x00481d:	adds    	r2, r4, #0
0x00481f:	adds    	r3, r6, #0
0x004821:	adds    	r0, r7, #0
0x004823:	bl      	#0x4c2d
; block 0x4827
0x004827:	str     	r6, [r5, #0x1c]
0x004829:	movs    	r1, #0
0x00482b:	str     	r1, [sp]
0x00482d:	str     	r1, [sp, #4]
0x00482f:	movs    	r2, #0
0x004831:	movs    	r1, #0xe6
0x004833:	adds    	r3, r6, #0
0x004835:	adds    	r0, r7, #0
0x004837:	str     	r2, [sp, #8]
0x004839:	bl      	#0x4c2d
; block 0x4829
0x004829:	movs    	r1, #0
0x00482b:	str     	r1, [sp]
0x00482d:	str     	r1, [sp, #4]
0x00482f:	movs    	r2, #0
0x004831:	movs    	r1, #0xe6
0x004833:	adds    	r3, r6, #0
0x004835:	adds    	r0, r7, #0
0x004837:	str     	r2, [sp, #8]
0x004839:	bl      	#0x4c2d
; block 0x483d
0x00483d:	bl      	#0x5491
; block 0x4841
0x004841:	movs    	r1, #0
0x004843:	str     	r1, [sp]
0x004845:	str     	r1, [sp, #4]
0x004847:	movs    	r2, #0
0x004849:	movs    	r1, #0x2c
0x00484b:	adds    	r3, r6, #0
0x00484d:	movs    	r0, #0xf1
0x00484f:	lsls    	r0, r0, #9
0x004851:	str     	r2, [sp, #8]
0x004853:	bl      	#0x4c2d
; block 0x4857
0x004857:	b       	#0x47a1
; block 0x4859
0x004859:	b       	#0x4b4d
; block 0x485b
0x00485b:	movs    	r3, #0
0x00485d:	ldrsb   	r0, [r5, r3]
0x00485f:	adds    	r4, r5, #0
0x004861:	cmp     	r0, #0
0x004863:	bne     	#0x4881
; block 0x4865
0x004865:	movs    	r2, #0
0x004867:	movs    	r1, #0
0x004869:	str     	r2, [sp, #8]
0x00486b:	ldr     	r2, [pc, #0x2c0]
0x00486d:	str     	r1, [sp]
0x00486f:	str     	r1, [sp, #4]
0x004871:	adds    	r3, r6, #0
0x004873:	add     	r2, pc
0x004875:	movs    	r1, #0x33
0x004877:	adds    	r0, r7, #0
0x004879:	bl      	#0x4c2d
; block 0x487d
0x00487d:	b       	#0x47a1
; block 0x487f
0x00487f:	b       	#0x49e9
; block 0x4881
0x004881:	ldr     	r0, [r4, #0x64]
0x004883:	cmp     	r0, #0
0x004885:	bne     	#0x48bd
; block 0x4887
0x004887:	movs    	r1, #0
0x004889:	movs    	r2, #0
0x00488b:	str     	r2, [sp, #8]
0x00488d:	str     	r1, [sp]
0x00488f:	str     	r1, [sp, #4]
0x004891:	movs    	r1, #0xe1
0x004893:	movs    	r2, #0x69
0x004895:	adds    	r3, r6, #0
0x004897:	adds    	r0, r7, #0
0x004899:	bl      	#0x4c2d
; block 0x489d
0x00489d:	ldr     	r1, [r4, #0x68]
0x00489f:	cmp     	r0, r1
0x0048a1:	bge     	#0x48bd
; block 0x48a3
0x0048a3:	movs    	r2, #0
0x0048a5:	movs    	r1, #0
0x0048a7:	str     	r2, [sp, #8]
0x0048a9:	ldr     	r2, [pc, #0x284]
0x0048ab:	str     	r1, [sp]
0x0048ad:	str     	r1, [sp, #4]
0x0048af:	adds    	r3, r6, #0
0x0048b1:	add     	r2, pc
0x0048b3:	movs    	r1, #0x33
0x0048b5:	adds    	r0, r7, #0
0x0048b7:	bl      	#0x4c2d
; block 0x48bb
0x0048bb:	b       	#0x47a1
; block 0x48bd
0x0048bd:	ldr     	r0, [r4, #0x64]
0x0048bf:	cmp     	r0, #1
0x0048c1:	bne     	#0x48f9
; block 0x48c3
0x0048c3:	movs    	r1, #0
0x0048c5:	movs    	r2, #0
0x0048c7:	str     	r2, [sp, #8]
0x0048c9:	str     	r1, [sp]
0x0048cb:	str     	r1, [sp, #4]
0x0048cd:	movs    	r1, #0xe1
0x0048cf:	movs    	r2, #0x1c
0x0048d1:	adds    	r3, r6, #0
0x0048d3:	adds    	r0, r7, #0
0x0048d5:	bl      	#0x4c2d
; block 0x48d9
0x0048d9:	ldr     	r1, [r4, #0x68]
0x0048db:	cmp     	r0, r1
0x0048dd:	bge     	#0x48f9
; block 0x48df
0x0048df:	movs    	r2, #0
0x0048e1:	movs    	r1, #0
0x0048e3:	str     	r2, [sp, #8]
0x0048e5:	ldr     	r2, [pc, #0x24c]
0x0048e7:	str     	r1, [sp]
0x0048e9:	str     	r1, [sp, #4]
0x0048eb:	adds    	r3, r6, #0
0x0048ed:	add     	r2, pc
0x0048ef:	movs    	r1, #0x33
0x0048f1:	adds    	r0, r7, #0
0x0048f3:	bl      	#0x4c2d
; block 0x48f7
0x0048f7:	b       	#0x47a1
; block 0x48f9
0x0048f9:	movs    	r1, #0
0x0048fb:	movs    	r2, #0
0x0048fd:	str     	r2, [sp, #8]
0x0048ff:	str     	r1, [sp]
0x004901:	str     	r1, [sp, #4]
0x004903:	movs    	r1, #0xe1
0x004905:	movs    	r2, #0x20
0x004907:	adds    	r3, r6, #0
0x004909:	adds    	r0, r7, #0
0x00490b:	bl      	#0x4c2d
; block 0x490f
0x00490f:	cmp     	r0, #0
0x004911:	bne     	#0x495f
; block 0x4913
0x004913:	ldr     	r5, [pc, #0x224]
0x004915:	add     	r5, pc
0x004917:	movs    	r1, #0
0x004919:	str     	r1, [sp]
0x00491b:	str     	r1, [sp, #4]
0x00491d:	movs    	r2, #0
0x00491f:	str     	r2, [sp, #8]
0x004921:	ldr     	r2, [r4, #0x48]
0x004923:	movs    	r1, #0xb1
0x004925:	adds    	r0, r7, #0
0x004927:	ldr     	r3, [r2, #4]
0x004929:	bl      	#0x4c2d
; block 0x492d
0x00492d:	movs    	r1, #0
0x00492f:	adds    	r3, r0, #0
0x004931:	movs    	r2, #0
0x004933:	str     	r2, [sp, #8]
0x004935:	str     	r1, [sp]
0x004937:	str     	r1, [sp, #4]
0x004939:	movs    	r1, #0x2d
0x00493b:	adds    	r2, r5, #0
0x00493d:	movs    	r0, #0xf1
0x00493f:	lsls    	r0, r0, #9
0x004941:	bl      	#0x4c2d
; block 0x4945
0x004945:	movs    	r2, #0
0x004947:	movs    	r1, #0
0x004949:	str     	r2, [sp, #8]
0x00494b:	adds    	r3, r6, #0
0x00494d:	adds    	r2, r0, #0
0x00494f:	str     	r1, [sp]
0x004951:	str     	r1, [sp, #4]
0x004953:	movs    	r1, #0x51
0x004955:	movs    	r0, #0xf1
0x004957:	lsls    	r0, r0, #9
0x004959:	bl      	#0x4c2d
; block 0x495d
0x00495d:	b       	#0x47a1
; block 0x495f
0x00495f:	ldr     	r1, [r4, #0x38]
0x004961:	ldr     	r2, [r4, #0x6c]
0x004963:	ldr     	r1, [r1]
0x004965:	lsls    	r2, r2, #2
0x004967:	ldr     	r1, [r1, r2]
0x004969:	ldr     	r2, [r4, #0x70]
0x00496b:	ldr     	r1, [r1, #0xc]
0x00496d:	lsls    	r2, r2, #2
0x00496f:	ldr     	r1, [r1, r2]
0x004971:	adds    	r0, r4, #0
0x004973:	ldr     	r1, [r1]
0x004975:	movs    	r4, #0
0x004977:	str     	r1, [sp, #0x10]
0x004979:	ldr     	r1, [r0, #0x14]
0x00497b:	mvns    	r4, r4
0x00497d:	adds    	r5, r4, #0
0x00497f:	cmp     	r1, #0
0x004981:	beq     	#0x4985
; block 0x4983
0x004983:	ldr     	r4, [r1]
0x004985:	ldr     	r0, [pc, #0x19c]
0x004987:	add     	r0, sb
0x004989:	ldr     	r0, [r0, #0x18]
0x00498b:	cmp     	r0, #0
0x00498d:	beq     	#0x4991
; block 0x4985
0x004985:	ldr     	r0, [pc, #0x19c]
0x004987:	add     	r0, sb
0x004989:	ldr     	r0, [r0, #0x18]
0x00498b:	cmp     	r0, #0
0x00498d:	beq     	#0x4991
; block 0x498f
0x00498f:	ldr     	r5, [r0]
0x004991:	movs    	r1, #0
0x004993:	movs    	r2, #0
0x004995:	str     	r2, [sp, #8]
0x004997:	str     	r1, [sp]
0x004999:	str     	r1, [sp, #4]
0x00499b:	movs    	r1, #0x9c
0x00499d:	movs    	r2, #0x12
0x00499f:	adds    	r3, r6, #0
0x0049a1:	adds    	r0, r7, #0
0x0049a3:	bl      	#0x4c2d
; block 0x4991
0x004991:	movs    	r1, #0
0x004993:	movs    	r2, #0
0x004995:	str     	r2, [sp, #8]
0x004997:	str     	r1, [sp]
0x004999:	str     	r1, [sp, #4]
0x00499b:	movs    	r1, #0x9c
0x00499d:	movs    	r2, #0x12
0x00499f:	adds    	r3, r6, #0
0x0049a1:	adds    	r0, r7, #0
0x0049a3:	bl      	#0x4c2d
; block 0x49a7
0x0049a7:	movs    	r1, #0
0x0049a9:	str     	r1, [sp]
0x0049ab:	str     	r1, [sp, #4]
0x0049ad:	movs    	r2, #0
0x0049af:	movs    	r1, #0x34
0x0049b1:	adds    	r3, r6, #0
0x0049b3:	movs    	r0, #0xf1
0x0049b5:	lsls    	r0, r0, #9
0x0049b7:	str     	r2, [sp, #8]
0x0049b9:	bl      	#0x4c2d
; block 0x49bd
0x0049bd:	movs    	r1, #0
0x0049bf:	movs    	r2, #0
0x0049c1:	str     	r2, [sp, #8]
0x0049c3:	str     	r1, [sp]
0x0049c5:	str     	r1, [sp, #4]
0x0049c7:	movs    	r1, #0x14
0x0049c9:	movs    	r2, #0x20
0x0049cb:	adds    	r3, r6, #0
0x0049cd:	movs    	r0, #0xf1
0x0049cf:	lsls    	r0, r0, #9
0x0049d1:	bl      	#0x4c2d
; block 0x49d5
0x0049d5:	ldr     	r0, [pc, #0x14c]
0x0049d7:	adds    	r3, r5, #0
0x0049d9:	add     	r0, sb
0x0049db:	ldr     	r0, [r0, #0x48]
0x0049dd:	adds    	r2, r4, #0
0x0049df:	ldr     	r1, [r0]
0x0049e1:	ldr     	r0, [sp, #0x10]
0x0049e3:	bl      	#0x57cd
; block 0x49e7
0x0049e7:	b       	#0x47a1
; block 0x49e9
0x0049e9:	bl      	#0x3979
; block 0x49ed
0x0049ed:	ldr     	r1, [pc, #0x14c]
0x0049ef:	adds    	r4, r0, #0
0x0049f1:	add     	r1, pc
0x0049f3:	ldr     	r2, [pc, #0x14c]
0x0049f5:	add     	r2, sb
0x0049f7:	ldr     	r2, [r2]
0x0049f9:	blx     	r2
; block 0x49fb
0x0049fb:	cmp     	r0, #0
0x0049fd:	bne     	#0x4a71
; block 0x49ff
0x0049ff:	movs    	r1, #0
0x004a01:	str     	r1, [sp]
0x004a03:	str     	r1, [sp, #4]
0x004a05:	movs    	r2, #0
0x004a07:	movs    	r1, #0x34
0x004a09:	adds    	r3, r6, #0
0x004a0b:	adds    	r0, r7, #0
0x004a0d:	str     	r2, [sp, #8]
0x004a0f:	bl      	#0x4c2d
; block 0x4a13
0x004a13:	movs    	r1, #0
0x004a15:	movs    	r2, #0
0x004a17:	str     	r2, [sp, #8]
0x004a19:	str     	r1, [sp]
0x004a1b:	str     	r1, [sp, #4]
0x004a1d:	movs    	r3, #4
0x004a1f:	ldrsb   	r0, [r5, r3]
0x004a21:	movs    	r2, #0xff
0x004a23:	movs    	r1, #0x14
0x004a25:	adds    	r3, r0, #0
0x004a27:	movs    	r0, #0xf1
0x004a29:	adds    	r2, #0x27
0x004a2b:	lsls    	r0, r0, #9
0x004a2d:	bl      	#0x4c2d
; block 0x4a31
0x004a31:	movs    	r1, #0
0x004a33:	movs    	r2, #0
0x004a35:	str     	r2, [sp, #8]
0x004a37:	str     	r1, [sp]
0x004a39:	str     	r1, [sp, #4]
0x004a3b:	movs    	r3, #5
0x004a3d:	ldrsb   	r0, [r5, r3]
0x004a3f:	movs    	r2, #0xff
0x004a41:	movs    	r1, #0x14
0x004a43:	adds    	r3, r0, #0
0x004a45:	movs    	r0, #0xf1
0x004a47:	adds    	r2, #0x28
0x004a49:	lsls    	r0, r0, #9
0x004a4b:	bl      	#0x4c2d
; block 0x4a4f
0x004a4f:	movs    	r1, #0
0x004a51:	movs    	r2, #0
0x004a53:	str     	r2, [sp, #8]
0x004a55:	subs    	r2, r1, #5
0x004a57:	str     	r1, [sp]
0x004a59:	str     	r1, [sp, #4]
0x004a5b:	movs    	r1, #0xa1
0x004a5d:	movs    	r3, #0xb
0x004a5f:	movs    	r0, #0xf1
0x004a61:	lsls    	r0, r0, #9
0x004a63:	bl      	#0x4c2d
; block 0x4a67
0x004a67:	movs    	r0, #0
0x004a69:	mvns    	r0, r0
0x004a6b:	str     	r0, [r5, #0x64]
0x004a6d:	str     	r0, [r5, #0x68]
0x004a6f:	b       	#0x47a1
; block 0x4a71
0x004a71:	ldr     	r1, [pc, #0xd0]
0x004a73:	add     	r1, pc
0x004a75:	ldr     	r2, [pc, #0xc8]
0x004a77:	adds    	r0, r4, #0
0x004a79:	add     	r2, sb
0x004a7b:	ldr     	r2, [r2]
0x004a7d:	blx     	r2
; block 0x4a7f
0x004a7f:	cmp     	r0, #0
0x004a81:	bne     	#0x4acb
; block 0x4a83
0x004a83:	movs    	r1, #0
0x004a85:	str     	r1, [sp]
0x004a87:	str     	r1, [sp, #4]
0x004a89:	movs    	r2, #0
0x004a8b:	movs    	r1, #0x34
0x004a8d:	adds    	r3, r6, #0
0x004a8f:	adds    	r0, r7, #0
0x004a91:	str     	r2, [sp, #8]
0x004a93:	bl      	#0x4c2d
; block 0x4a97
0x004a97:	movs    	r2, #0
0x004a99:	movs    	r1, #0
0x004a9b:	str     	r2, [sp, #8]
0x004a9d:	str     	r1, [sp]
0x004a9f:	str     	r1, [sp, #4]
0x004aa1:	movs    	r2, #0xff
0x004aa3:	adds    	r2, #0x29
0x004aa5:	movs    	r1, #0x14
0x004aa7:	movs    	r0, #0xf1
0x004aa9:	lsls    	r0, r0, #9
0x004aab:	ldr     	r3, [r5, #0x1c]
0x004aad:	bl      	#0x4c2d
; block 0x4ab1
0x004ab1:	movs    	r1, #0
0x004ab3:	movs    	r2, #0
0x004ab5:	str     	r2, [sp, #8]
0x004ab7:	subs    	r2, r1, #6
0x004ab9:	str     	r1, [sp]
0x004abb:	str     	r1, [sp, #4]
0x004abd:	movs    	r1, #0xa1
0x004abf:	movs    	r3, #0xc
0x004ac1:	movs    	r0, #0xf1
0x004ac3:	lsls    	r0, r0, #9
0x004ac5:	bl      	#0x4c2d
; block 0x4ac9
0x004ac9:	b       	#0x47a1
; block 0x4acb
0x004acb:	ldr     	r1, [pc, #0x7c]
0x004acd:	add     	r1, pc
0x004acf:	ldr     	r2, [pc, #0x70]
0x004ad1:	adds    	r0, r4, #0
0x004ad3:	add     	r2, sb
0x004ad5:	ldr     	r2, [r2]
0x004ad7:	blx     	r2
; block 0x4ad9
0x004ad9:	cmp     	r0, #0
0x004adb:	bne     	#0x49e7
; block 0x4add
0x004add:	movs    	r1, #0
0x004adf:	str     	r1, [sp]
0x004ae1:	str     	r1, [sp, #4]
0x004ae3:	movs    	r2, #0
0x004ae5:	movs    	r1, #0x34
0x004ae7:	adds    	r3, r6, #0
0x004ae9:	adds    	r0, r7, #0
0x004aeb:	str     	r2, [sp, #8]
0x004aed:	bl      	#0x4c2d
; block 0x4af1
0x004af1:	movs    	r2, #0
0x004af3:	movs    	r1, #0
0x004af5:	str     	r2, [sp, #8]
0x004af7:	str     	r1, [sp]
0x004af9:	str     	r1, [sp, #4]
0x004afb:	movs    	r2, #0xff
0x004afd:	adds    	r2, #0x2a
0x004aff:	movs    	r1, #0x14
0x004b01:	movs    	r0, #0xf1
0x004b03:	lsls    	r0, r0, #9
0x004b05:	ldr     	r3, [r5, #0x20]
0x004b07:	bl      	#0x4c2d
; block 0x4b0b
0x004b0b:	movs    	r1, #0
0x004b0d:	movs    	r2, #0
0x004b0f:	str     	r2, [sp, #8]
0x004b11:	subs    	r2, r1, #7
0x004b13:	str     	r1, [sp]
0x004b15:	str     	r1, [sp, #4]
0x004b17:	movs    	r1, #0xa1
0x004b19:	movs    	r3, #0xd
0x004b1b:	movs    	r0, #0xf1
0x004b1d:	lsls    	r0, r0, #9
0x004b1f:	bl      	#0x4c2d
; block 0x4b23
0x004b23:	b       	#0x47a1
; block 0x4b4d
0x004b4d:	bl      	#0x38b1
; block 0x4b51
0x004b51:	str     	r0, [r5, #0x24]
0x004b53:	b       	#0x47a1

; ===== sub_4b55 @ 0x4b55 offset=0x4b54 size=118 blocks=12 cc=6 =====
; block 0x4b55
0x004b55:	push    	{r3, r4, r5, lr}
0x004b57:	ldr     	r4, [pc, #0x74]
0x004b59:	add     	r4, pc
0x004b5b:	ldr     	r0, [r4, #0x38]
0x004b5d:	movs    	r1, #0x14
0x004b5f:	ldr     	r2, [r0, #0x64]
0x004b61:	ldr     	r0, [pc, #0x6c]
0x004b63:	add     	r0, pc
0x004b65:	blx     	r2
; block 0x4b67
0x004b67:	movs    	r5, #0
0x004b69:	mvns    	r5, r5
0x004b6b:	cmp     	r0, r5
0x004b6d:	bne     	#0x4b73
; block 0x4b6f
0x004b6f:	adds    	r0, r5, #0
0x004b71:	pop     	{r3, r4, r5, pc}
; block 0x4b71
0x004b71:	pop     	{r3, r4, r5, pc}
; block 0x4b73
0x004b73:	ldr     	r1, [r4, #0x3c]
0x004b75:	movs    	r0, #1
0x004b77:	str     	r0, [r1, #8]
0x004b79:	ldr     	r0, [pc, #0x58]
0x004b7b:	add     	r0, pc
0x004b7d:	ldr     	r1, [r4, #0x38]
0x004b7f:	str     	r0, [r1, #0x7c]
0x004b81:	ldr     	r0, [pc, #0x54]
0x004b83:	add     	r0, pc
0x004b85:	ldr     	r1, [r4, #0x38]
0x004b87:	adds    	r1, #0x80
0x004b89:	str     	r0, [r1]
0x004b8b:	blx     	#0x2c8
; block 0x4b8f
0x004b8f:	ldr     	r1, [r4, #0x3c]
0x004b91:	str     	r0, [r1, #4]
0x004b93:	ldr     	r1, [r4, #0x38]
0x004b95:	adds    	r0, #4
0x004b97:	ldr     	r1, [r1]
0x004b99:	blx     	r1
; block 0x4b9b
0x004b9b:	ldr     	r1, [r4, #0x3c]
0x004b9d:	cmp     	r0, #0
0x004b9f:	str     	r0, [r1]
0x004ba1:	ldr     	r1, [r4, #0x3c]
0x004ba3:	beq     	#0x4bb1
; block 0x4ba5
0x004ba5:	ldr     	r1, [r1, #4]
0x004ba7:	str     	r1, [r0]
0x004ba9:	ldr     	r0, [r4, #0x3c]
0x004bab:	ldr     	r1, [r0]
0x004bad:	adds    	r1, #4
0x004baf:	str     	r1, [r0]
0x004bb1:	ldr     	r1, [r4, #0x3c]
0x004bb3:	ldr     	r0, [r1]
0x004bb5:	cmp     	r0, #0
0x004bb7:	beq     	#0x4bc7
; block 0x4bb1
0x004bb1:	ldr     	r1, [r4, #0x3c]
0x004bb3:	ldr     	r0, [r1]
0x004bb5:	cmp     	r0, #0
0x004bb7:	beq     	#0x4bc7
; block 0x4bb9
0x004bb9:	ldr     	r2, [r1, #4]
0x004bbb:	ldr     	r1, [r4, #0x38]
0x004bbd:	ldr     	r3, [r1, #0x38]
0x004bbf:	movs    	r1, #0
0x004bc1:	blx     	r3
; block 0x4bc3
0x004bc3:	movs    	r0, #0
0x004bc5:	b       	#0x4b71
; block 0x4bc7
0x004bc7:	adds    	r0, r5, #0
0x004bc9:	b       	#0x4b71

; ===== sub_4bd1 @ 0x4bd1 offset=0x4bd0 size=12 blocks=1 cc=1 =====
; block 0x4bd1
0x004bd1:	lsls    	r3, r1, #7
0x004bd3:	movs    	r0, r0
0x004bd5:	lsls    	r7, r4, #3
0x004bd7:	movs    	r0, r0
0x004bd9:	lsls    	r7, r0, #4
0x004bdb:	movs    	r0, r0
0x004bdd:	push    	{r4, lr}
0x004bdf:	sub     	sp, #0x10
0x004be1:	lsls    	r0, r0, #0x18
0x004be3:	lsrs    	r0, r0, #0x18
0x004be5:	str     	r0, [sp]
0x004be7:	ldr     	r0, [pc, #0x38]
0x004be9:	lsls    	r2, r2, #0x18
0x004beb:	lsls    	r1, r1, #0x18
0x004bed:	lsrs    	r1, r1, #0x18
0x004bef:	lsrs    	r2, r2, #0x18
0x004bf1:	str     	r2, [sp, #8]
0x004bf3:	str     	r1, [sp, #4]
0x004bf5:	add     	r0, pc
0x004bf7:	ldr     	r0, [r0, #0x38]
0x004bf9:	adds    	r1, r0, #0
0x004bfb:	adds    	r1, #0xff
0x004bfd:	adds    	r1, #0x41
0x004bff:	ldr     	r2, [r1, #0x34]
0x004c01:	ldr     	r1, [r1, #0x30]
0x004c03:	ldr     	r2, [r2]
0x004c05:	ldr     	r1, [r1]
0x004c07:	lsls    	r3, r2, #0x10
0x004c09:	lsls    	r2, r1, #0x10
0x004c0b:	asrs    	r2, r2, #0x10
0x004c0d:	asrs    	r3, r3, #0x10
0x004c0f:	adds    	r0, #0xff
0x004c11:	adds    	r0, #0xc1
0x004c13:	ldr     	r4, [r0, #0x28]
0x004c15:	movs    	r1, #0
0x004c17:	movs    	r0, #0
0x004c19:	blx     	r4

; ===== sub_4bdd @ 0x4bdd offset=0x4bdc size=66 blocks=2 cc=1 =====
; block 0x4bdd
0x004bdd:	push    	{r4, lr}
0x004bdf:	sub     	sp, #0x10
0x004be1:	lsls    	r0, r0, #0x18
0x004be3:	lsrs    	r0, r0, #0x18
0x004be5:	str     	r0, [sp]
0x004be7:	ldr     	r0, [pc, #0x38]
0x004be9:	lsls    	r2, r2, #0x18
0x004beb:	lsls    	r1, r1, #0x18
0x004bed:	lsrs    	r1, r1, #0x18
0x004bef:	lsrs    	r2, r2, #0x18
0x004bf1:	str     	r2, [sp, #8]
0x004bf3:	str     	r1, [sp, #4]
0x004bf5:	add     	r0, pc
0x004bf7:	ldr     	r0, [r0, #0x38]
0x004bf9:	adds    	r1, r0, #0
0x004bfb:	adds    	r1, #0xff
0x004bfd:	adds    	r1, #0x41
0x004bff:	ldr     	r2, [r1, #0x34]
0x004c01:	ldr     	r1, [r1, #0x30]
0x004c03:	ldr     	r2, [r2]
0x004c05:	ldr     	r1, [r1]
0x004c07:	lsls    	r3, r2, #0x10
0x004c09:	lsls    	r2, r1, #0x10
0x004c0b:	asrs    	r2, r2, #0x10
0x004c0d:	asrs    	r3, r3, #0x10
0x004c0f:	adds    	r0, #0xff
0x004c11:	adds    	r0, #0xc1
0x004c13:	ldr     	r4, [r0, #0x28]
0x004c15:	movs    	r1, #0
0x004c17:	movs    	r0, #0
0x004c19:	blx     	r4
; block 0x4c1b
0x004c1b:	add     	sp, #0x10
0x004c1d:	pop     	{r4, pc}

; ===== sub_4c25 @ 0x4c25 offset=0x4c24 size=4 blocks=1 cc=1 =====
; block 0x4c25
0x004c25:	movs    	r0, #0
0x004c27:	bx      	lr

; ===== sub_4c29 @ 0x4c29 offset=0x4c28 size=4 blocks=1 cc=1 =====
; block 0x4c29
0x004c29:	movs    	r0, #0
0x004c2b:	bx      	lr

; ===== sub_4c2d @ 0x4c2d offset=0x4c2c size=52 blocks=2 cc=1 =====
; block 0x4c2d
0x004c2d:	push    	{r4, r5, r6, r7, lr}
0x004c2f:	adds    	r5, r1, #0
0x004c31:	adds    	r4, r0, #0
0x004c33:	adds    	r6, r2, #0
0x004c35:	ldr     	r2, [pc, #0x28]
0x004c37:	sub     	sp, #0x14
0x004c39:	mov     	ip, r3
0x004c3b:	add     	r2, pc
0x004c3d:	ldr     	r0, [sp, #0x2c]
0x004c3f:	ldr     	r1, [sp, #0x30]
0x004c41:	ldr     	r7, [sp, #0x28]
0x004c43:	ldr     	r3, [r2, #0x3c]
0x004c45:	movs    	r2, #2
0x004c47:	str     	r2, [sp, #0xc]
0x004c49:	str     	r1, [sp, #8]
0x004c4b:	str     	r0, [sp, #4]
0x004c4d:	str     	r7, [sp]
0x004c4f:	ldr     	r0, [r3, #0xc]
0x004c51:	adds    	r1, r5, #0
0x004c53:	adds    	r2, r6, #0
0x004c55:	ldr     	r7, [r0, #0x28]
0x004c57:	adds    	r0, r4, #0
0x004c59:	mov     	r3, ip
0x004c5b:	blx     	r7
; block 0x4c5d
0x004c5d:	add     	sp, #0x14
0x004c5f:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_4c63 @ 0x4c63 offset=0x4c62 size=10 blocks=2 cc=1 =====
; block 0x4c63
0x004c63:	vdup.8  	d17, d3[7]
0x004c67:	ldr     	r0, [pc, #0x20]
0x004c69:	push    	{r4, lr}
0x004c6b:	movs    	r2, #0
0x004c6d:	add     	r0, pc
0x004c6f:	ldr     	r4, [r0, #0x3c]
0x004c71:	sub     	sp, #0x10
0x004c73:	movs    	r1, #0
0x004c75:	str     	r1, [sp, #4]
0x004c77:	str     	r1, [sp, #8]
0x004c79:	str     	r2, [sp, #0xc]
0x004c7b:	str     	r2, [sp]
0x004c7d:	ldr     	r0, [r4, #0xc]
0x004c7f:	ldr     	r2, [r0, #0x24]
0x004c81:	ldr     	r4, [r0, #0x28]
0x004c83:	blx     	r4
; block 0x4c68
0x004c68:	andhs   	fp, r0, #16, #10
0x004c6c:	blvs    	#0xff115e54

; ===== sub_4c6c @ 0x4c6c offset=0x4c6c size=4 blocks=1 cc=1 =====
; block 0x4c6c
0x004c6c:	blvs    	#0xff115e54

; ===== sub_4c78 @ 0x4c78 offset=0x4c78 size=8 blocks=1 cc=1 =====
; block 0x4c78
0x004c78:	andls   	sb, r0, #0x30000000
0x004c7c:	bvs     	#0x109f004

; ===== sub_4c8b @ 0x4c8b offset=0x4c8a size=40 blocks=3 cc=1 =====
; block 0x4c8b
0x004c8b:	vsli.32 	d27, d0, #0x1f
0x004c8f:	ldr     	r0, [pc, #0x24]
0x004c91:	sub     	sp, #0x10
0x004c93:	add     	r0, pc
0x004c95:	ldr     	r3, [r0, #0x3c]
0x004c97:	movs    	r2, #0
0x004c99:	movs    	r1, #0
0x004c9b:	str     	r1, [sp, #4]
0x004c9d:	str     	r1, [sp, #8]
0x004c9f:	str     	r2, [sp, #0xc]
0x004ca1:	str     	r2, [sp]
0x004ca3:	ldr     	r0, [r3, #0xc]
0x004ca5:	movs    	r3, #0
0x004ca7:	ldr     	r2, [r0, #0x24]
0x004ca9:	ldr     	r4, [r0, #0x28]
0x004cab:	movs    	r1, #1
0x004cad:	blx     	r4
; block 0x4c99
0x004c99:	movs    	r1, #0
0x004c9b:	str     	r1, [sp, #4]
0x004c9d:	str     	r1, [sp, #8]
0x004c9f:	str     	r2, [sp, #0xc]
0x004ca1:	str     	r2, [sp]
0x004ca3:	ldr     	r0, [r3, #0xc]
0x004ca5:	movs    	r3, #0
0x004ca7:	ldr     	r2, [r0, #0x24]
0x004ca9:	ldr     	r4, [r0, #0x28]
0x004cab:	movs    	r1, #1
0x004cad:	blx     	r4
; block 0x4caf
0x004caf:	add     	sp, #0x10
0x004cb1:	pop     	{r4, pc}

; ===== sub_4cb9 @ 0x4cb9 offset=0x4cb8 size=14 blocks=1 cc=1 =====
; block 0x4cb9
0x004cb9:	ldr     	r0, [pc, #0xc]
0x004cbb:	add     	r0, pc
0x004cbd:	ldr     	r0, [r0, #0x38]
0x004cbf:	adds    	r0, #0xff
0x004cc1:	adds    	r0, #0x81
0x004cc3:	ldr     	r0, [r0, #0x10]
0x004cc5:	bx      	lr

; ===== sub_4ccd @ 0x4ccd offset=0x4ccc size=70 blocks=6 cc=2 =====
; block 0x4ccd
0x004ccd:	push    	{r4, lr}
0x004ccf:	sub     	sp, #0x10
0x004cd1:	movs    	r2, #0
0x004cd3:	movs    	r1, #0
0x004cd5:	str     	r2, [sp, #8]
0x004cd7:	ldr     	r2, [pc, #0x3c]
0x004cd9:	str     	r1, [sp]
0x004cdb:	str     	r1, [sp, #4]
0x004cdd:	movs    	r3, #0
0x004cdf:	add     	r2, pc
0x004ce1:	ldr     	r1, [pc, #0x34]
0x004ce3:	ldr     	r0, [pc, #0x38]
0x004ce5:	bl      	#0x4c2d
; block 0x4ce9
0x004ce9:	ldr     	r3, [pc, #0x38]
0x004ceb:	ldr     	r4, [pc, #0x34]
0x004ced:	add     	r3, sb
0x004cef:	ldr     	r3, [r3]
0x004cf1:	movs    	r2, #0x41
0x004cf3:	movs    	r1, #0
0x004cf5:	add     	r4, sb
0x004cf7:	adds    	r0, r4, #0
0x004cf9:	blx     	r3
; block 0x4cfb
0x004cfb:	bl      	#0x4cb9
; block 0x4cff
0x004cff:	ldr     	r3, [pc, #0x28]
0x004d01:	adds    	r1, r0, #0
0x004d03:	add     	r3, sb
0x004d05:	ldr     	r3, [r3]
0x004d07:	movs    	r2, #0x41
0x004d09:	adds    	r0, r4, #0
0x004d0b:	blx     	r3
; block 0x4d05
0x004d05:	ldr     	r3, [r3]
0x004d07:	movs    	r2, #0x41
0x004d09:	adds    	r0, r4, #0
0x004d0b:	blx     	r3
; block 0x4d0d
0x004d0d:	movs    	r0, #0
0x004d0f:	add     	sp, #0x10
0x004d11:	pop     	{r4, pc}

; ===== sub_4d19 @ 0x4d19 offset=0x4d18 size=20 blocks=1 cc=1 =====
; block 0x4d19
0x004d19:	adds    	r2, #1
0x004d1b:	movs    	r7, r1
0x004d1d:	lsls    	r2, r0, #4
0x004d1f:	movs    	r1, r0
0x004d21:	lsls    	r0, r7, #1
0x004d23:	movs    	r0, r0
0x004d25:	lsls    	r0, r3, #4
0x004d27:	movs    	r0, r0
0x004d29:	lsls    	r0, r7, #3
0x004d2b:	movs    	r0, r0
0x004d2d:	movs    	r0, #0
0x004d2f:	bx      	lr

; ===== sub_4d2d @ 0x4d2d offset=0x4d2c size=4 blocks=1 cc=1 =====
; block 0x4d2d
0x004d2d:	movs    	r0, #0
0x004d2f:	bx      	lr

; ===== sub_4d31 @ 0x4d31 offset=0x4d30 size=126 blocks=20 cc=11 =====
; block 0x4d31
0x004d31:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x004d33:	adds    	r7, r3, #0
0x004d35:	adds    	r6, r2, #0
0x004d37:	adds    	r5, r0, #0
0x004d39:	ldr     	r0, [r0]
0x004d3b:	sub     	sp, #4
0x004d3d:	mov     	r1, sb
0x004d3f:	str     	r1, [sp]
0x004d41:	movs    	r4, #0
0x004d43:	blx     	#0x2e0
; block 0x4d47
0x004d47:	ldr     	r0, [sp, #8]
0x004d49:	cmp     	r0, #0xb
0x004d4b:	bhs     	#0x4db9
; block 0x4d4d
0x004d4d:	adr     	r3, #4
0x004d4f:	ldrb    	r3, [r3, r0]
0x004d51:	lsls    	r3, r3, #1
0x004d53:	add     	pc, r3
; block 0x4d61
0x004d61:	ldr     	r1, [pc, #0x60]
0x004d63:	ldr     	r0, [r5, #0xc]
0x004d65:	add     	r1, sb
0x004d67:	str     	r0, [r1, #0x14]
0x004d69:	bl      	#0x329
; block 0x4d75
0x004d75:	ldr     	r0, [r6]
0x004d77:	cmp     	r0, #8
0x004d79:	bne     	#0x4d83
; block 0x4d7b
0x004d7b:	bl      	#0x4c29
; block 0x4d7f
0x004d7f:	adds    	r4, r0, #0
0x004d81:	b       	#0x4db9
; block 0x4d83
0x004d83:	ldr     	r1, [r6, #4]
0x004d85:	ldr     	r2, [r6, #8]
0x004d87:	bl      	#0x4c25
; block 0x4d8b
0x004d8b:	adds    	r4, r0, #0
0x004d8d:	b       	#0x4db9
; block 0x4d8f
0x004d8f:	bl      	#0x4fc1
; block 0x4d93
0x004d93:	b       	#0x4db9
; block 0x4d95
0x004d95:	str     	r7, [r5, #0xc]
0x004d97:	b       	#0x4db9
; block 0x4d99
0x004d99:	bl      	#0x4d2d
; block 0x4d9d
0x004d9d:	b       	#0x4db9
; block 0x4d9f
0x004d9f:	bl      	#0x4dfd
; block 0x4da3
0x004da3:	b       	#0x4db9
; block 0x4da5
0x004da5:	ldr     	r0, [pc, #0x1c]
0x004da7:	add     	r0, sb
0x004da9:	str     	r7, [r0, #0x1c]
0x004dab:	b       	#0x4db9
; block 0x4dad
0x004dad:	ldr     	r0, [pc, #0x14]
0x004daf:	add     	r0, sb
0x004db1:	str     	r6, [r0, #0x20]
0x004db3:	b       	#0x4db9
; block 0x4db5
0x004db5:	ldr     	r4, [pc, #0x10]
0x004db7:	add     	r4, pc
0x004db9:	ldr     	r1, [sp]
0x004dbb:	add     	sp, #0x14
0x004dbd:	adds    	r0, r4, #0
0x004dbf:	mov     	sb, r1
0x004dc1:	pop     	{r4, r5, r6, r7, pc}
; block 0x4db9
0x004db9:	ldr     	r1, [sp]
0x004dbb:	add     	sp, #0x14
0x004dbd:	adds    	r0, r4, #0
0x004dbf:	mov     	sb, r1
0x004dc1:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_4d6d @ 0x4d6d offset=0x4d6c size=8 blocks=2 cc=1 =====
; block 0x4d6d
0x004d6d:	bl      	#0x4ccd
; block 0x4d71
0x004d71:	adds    	r4, r0, #0
0x004d73:	b       	#0x4db9

; ===== sub_4dc5 @ 0x4dc5 offset=0x4dc4 size=54 blocks=5 cc=2 =====
; block 0x4dc5
0x004dc5:	lsls    	r4, r7, #2
0x004dc7:	movs    	r0, r0
0x004dc9:	movs    	r3, r2
0x004dcb:	movs    	r0, r0
0x004dcd:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x004dcf:	sub     	sp, #0xc
0x004dd1:	ldr     	r0, [sp, #0x38]
0x004dd3:	ldr     	r4, [sp, #0x3c]
0x004dd5:	ldr     	r6, [sp, #0x34]
0x004dd7:	ldr     	r0, [r0]
0x004dd9:	mov     	r7, sb
0x004ddb:	movs    	r5, #0
0x004ddd:	blx     	#0x2e0
; block 0x4de1
0x004de1:	cmp     	r4, #0
0x004de3:	beq     	#0x4df3
; block 0x4de5
0x004de5:	ldr     	r1, [sp, #0x30]
0x004de7:	str     	r6, [sp, #4]
0x004de9:	add     	r3, sp, #0xc
0x004deb:	str     	r1, [sp]
0x004ded:	ldm     	r3, {r0, r1, r2, r3}
0x004def:	blx     	r4
; block 0x4df1
0x004df1:	adds    	r5, r0, #0
0x004df3:	mov     	sb, r7
0x004df5:	adds    	r0, r5, #0
0x004df7:	add     	sp, #0x1c
0x004df9:	pop     	{r4, r5, r6, r7, pc}
; block 0x4df3
0x004df3:	mov     	sb, r7
0x004df5:	adds    	r0, r5, #0
0x004df7:	add     	sp, #0x1c
0x004df9:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_4dfd @ 0x4dfd offset=0x4dfc size=4 blocks=1 cc=1 =====
; block 0x4dfd
0x004dfd:	movs    	r0, #0
0x004dff:	bx      	lr

; ===== sub_4e01 @ 0x4e01 offset=0x4e00 size=90 blocks=17 cc=10 =====
; block 0x4e01
0x004e01:	adds    	r1, r0, #0
0x004e03:	beq     	#0x4e3f
; block 0x4e05
0x004e05:	ldr     	r3, [pc, #0x54]
0x004e07:	add     	r3, sb
0x004e09:	ldr     	r2, [r3, #8]
0x004e0b:	cmp     	r2, r1
0x004e0d:	bne     	#0x4e15
; block 0x4e0f
0x004e0f:	ldr     	r0, [r1, #0x18]
0x004e11:	str     	r0, [r3, #8]
0x004e13:	b       	#0x4e31
; block 0x4e15
0x004e15:	cmp     	r2, #0
0x004e17:	beq     	#0x4e31
; block 0x4e19
0x004e19:	ldr     	r0, [r2, #0x18]
0x004e1b:	cmp     	r0, #0
0x004e1d:	beq     	#0x4e31
; block 0x4e1f
0x004e1f:	cmp     	r0, r1
0x004e21:	bne     	#0x4e29
; block 0x4e23
0x004e23:	ldr     	r0, [r0, #0x18]
0x004e25:	str     	r0, [r2, #0x18]
0x004e27:	b       	#0x4e31
; block 0x4e29
0x004e29:	adds    	r2, r0, #0
0x004e2b:	ldr     	r0, [r0, #0x18]
0x004e2d:	cmp     	r0, #0
0x004e2f:	bne     	#0x4e1f
; block 0x4e31
0x004e31:	ldr     	r2, [r3, #0xc]
0x004e33:	cmp     	r2, #0
0x004e35:	beq     	#0x4e3f
; block 0x4e37
0x004e37:	cmp     	r2, r1
0x004e39:	bne     	#0x4e41
; block 0x4e3b
0x004e3b:	ldr     	r0, [r2, #0x1c]
0x004e3d:	str     	r0, [r3, #0xc]
0x004e3f:	bx      	lr
; block 0x4e3f
0x004e3f:	bx      	lr
; block 0x4e41
0x004e41:	ldr     	r0, [r2, #0x1c]
0x004e43:	cmp     	r0, #0
0x004e45:	beq     	#0x4e3f
; block 0x4e47
0x004e47:	cmp     	r0, r1
0x004e49:	bne     	#0x4e51
; block 0x4e4b
0x004e4b:	ldr     	r0, [r0, #0x1c]
0x004e4d:	str     	r0, [r2, #0x1c]
0x004e4f:	bx      	lr
; block 0x4e51
0x004e51:	adds    	r2, r0, #0
0x004e53:	ldr     	r0, [r0, #0x1c]
0x004e55:	cmp     	r0, #0
0x004e57:	bne     	#0x4e47
; block 0x4e59
0x004e59:	bx      	lr

; ===== sub_4e5d @ 0x4e5d offset=0x4e5c size=4 blocks=1 cc=1 =====
; block 0x4e5d
0x004e5d:	lsls    	r4, r7, #4
0x004e5f:	movs    	r0, r0
0x004e61:	push    	{r3, r4, r5, r6, r7, lr}
0x004e63:	adds    	r4, r0, #0
0x004e65:	ldr     	r0, [pc, #0x10c]
0x004e67:	movs    	r5, #0
0x004e69:	mvns    	r5, r5
0x004e6b:	mov     	ip, r2
0x004e6d:	add     	r0, pc
0x004e6f:	ldr     	r2, [r0, #0x38]
0x004e71:	cmp     	r4, #0
0x004e73:	bne     	#0x4e85

; ===== sub_4e61 @ 0x4e61 offset=0x4e60 size=276 blocks=45 cc=24 =====
; block 0x4e61
0x004e61:	push    	{r3, r4, r5, r6, r7, lr}
0x004e63:	adds    	r4, r0, #0
0x004e65:	ldr     	r0, [pc, #0x10c]
0x004e67:	movs    	r5, #0
0x004e69:	mvns    	r5, r5
0x004e6b:	mov     	ip, r2
0x004e6d:	add     	r0, pc
0x004e6f:	ldr     	r2, [r0, #0x38]
0x004e71:	cmp     	r4, #0
0x004e73:	bne     	#0x4e85
; block 0x4e75
0x004e75:	ldr     	r0, [pc, #0x100]
0x004e77:	ldr     	r2, [r2, #0x68]
0x004e79:	movs    	r1, #0x7d
0x004e7b:	lsls    	r1, r1, #3
0x004e7d:	add     	r0, pc
0x004e7f:	blx     	r2
; block 0x4e81
0x004e81:	adds    	r0, r5, #0
0x004e83:	pop     	{r3, r4, r5, r6, r7, pc}
; block 0x4e83
0x004e83:	pop     	{r3, r4, r5, r6, r7, pc}
; block 0x4e85
0x004e85:	ldr     	r6, [r2, #0x5c]
0x004e87:	ldr     	r6, [r6, #8]
0x004e89:	ldr     	r6, [r6]
0x004e8b:	cmp     	r6, #3
0x004e8d:	beq     	#0x4e93
; block 0x4e8f
0x004e8f:	cmp     	r6, #4
0x004e91:	bne     	#0x4e97
; block 0x4e93
0x004e93:	adds    	r0, r5, #0
0x004e95:	b       	#0x4e83
; block 0x4e97
0x004e97:	ldr     	r7, [pc, #0xe4]
0x004e99:	ldr     	r6, [r4]
0x004e9b:	cmp     	r6, r7
0x004e9d:	beq     	#0x4ead
; block 0x4e9f
0x004e9f:	ldr     	r0, [pc, #0xe4]
0x004ea1:	ldr     	r2, [r2, #0x68]
0x004ea3:	ldr     	r1, [pc, #0xdc]
0x004ea5:	add     	r0, pc
0x004ea7:	blx     	r2
; block 0x4ea9
0x004ea9:	adds    	r0, r5, #0
0x004eab:	b       	#0x4e83
; block 0x4ead
0x004ead:	cmp     	r1, #0
0x004eaf:	beq     	#0x4eb3
; block 0x4eb1
0x004eb1:	str     	r1, [r4, #4]
0x004eb3:	movs    	r6, #0
0x004eb5:	mov     	r2, ip
0x004eb7:	str     	r2, [r4, #0x10]
0x004eb9:	str     	r6, [r4, #8]
0x004ebb:	cmp     	r3, #0
0x004ebd:	beq     	#0x4ec1
; block 0x4eb3
0x004eb3:	movs    	r6, #0
0x004eb5:	mov     	r2, ip
0x004eb7:	str     	r2, [r4, #0x10]
0x004eb9:	str     	r6, [r4, #8]
0x004ebb:	cmp     	r3, #0
0x004ebd:	beq     	#0x4ec1
; block 0x4ebf
0x004ebf:	str     	r3, [r4, #0xc]
0x004ec1:	ldr     	r1, [sp, #0x18]
0x004ec3:	str     	r1, [r4, #0x14]
0x004ec5:	ldr     	r1, [r4, #4]
0x004ec7:	cmp     	r1, #0
0x004ec9:	bgt     	#0x4ecf
; block 0x4ec1
0x004ec1:	ldr     	r1, [sp, #0x18]
0x004ec3:	str     	r1, [r4, #0x14]
0x004ec5:	ldr     	r1, [r4, #4]
0x004ec7:	cmp     	r1, #0
0x004ec9:	bgt     	#0x4ecf
; block 0x4ecb
0x004ecb:	adds    	r0, r5, #0
0x004ecd:	b       	#0x4e83
; block 0x4ecf
0x004ecf:	cmp     	r1, #0xa
0x004ed1:	bge     	#0x4ed7
; block 0x4ed3
0x004ed3:	movs    	r1, #0xa
0x004ed5:	str     	r1, [r4, #4]
0x004ed7:	ldr     	r1, [r4, #4]
0x004ed9:	ldr     	r7, [pc, #0xac]
0x004edb:	str     	r1, [r4, #8]
0x004edd:	add     	r7, sb
0x004edf:	ldr     	r1, [r7, #0x10]
0x004ee1:	cmp     	r1, #0
0x004ee3:	beq     	#0x4ef3
; block 0x4ed7
0x004ed7:	ldr     	r1, [r4, #4]
0x004ed9:	ldr     	r7, [pc, #0xac]
0x004edb:	str     	r1, [r4, #8]
0x004edd:	add     	r7, sb
0x004edf:	ldr     	r1, [r7, #0x10]
0x004ee1:	cmp     	r1, #0
0x004ee3:	beq     	#0x4ef3
; block 0x4ee5
0x004ee5:	ldr     	r0, [r0, #0x38]
0x004ee7:	adds    	r0, #0x80
0x004ee9:	ldr     	r0, [r0, #4]
0x004eeb:	blx     	r0
; block 0x4eed
0x004eed:	ldr     	r1, [r7, #0x10]
0x004eef:	subs    	r5, r1, r0
0x004ef1:	b       	#0x4ef5
; block 0x4ef3
0x004ef3:	movs    	r5, #0
0x004ef5:	ldr     	r0, [r7, #8]
0x004ef7:	cmp     	r0, #0
0x004ef9:	beq     	#0x4f01
; block 0x4ef5
0x004ef5:	ldr     	r0, [r7, #8]
0x004ef7:	cmp     	r0, #0
0x004ef9:	beq     	#0x4f01
; block 0x4efb
0x004efb:	cmp     	r5, #0
0x004efd:	bge     	#0x4f01
; block 0x4eff
0x004eff:	movs    	r5, #0
0x004f01:	cmp     	r0, #0
0x004f03:	beq     	#0x4f0f
; block 0x4f01
0x004f01:	cmp     	r0, #0
0x004f03:	beq     	#0x4f0f
; block 0x4f05
0x004f05:	ldr     	r0, [r0, #4]
0x004f07:	adds    	r1, r0, #5
0x004f09:	cmp     	r1, r5
0x004f0b:	bge     	#0x4f0f
; block 0x4f0d
0x004f0d:	adds    	r5, r0, #0
0x004f0f:	adds    	r0, r4, #0
0x004f11:	bl      	#0x4e01
; block 0x4f0f
0x004f0f:	adds    	r0, r4, #0
0x004f11:	bl      	#0x4e01
; block 0x4f15
0x004f15:	ldr     	r1, [r7, #8]
0x004f17:	cmp     	r1, #0
0x004f19:	beq     	#0x4f27
; block 0x4f1b
0x004f1b:	ldr     	r0, [r4, #8]
0x004f1d:	cmp     	r0, r5
0x004f1f:	blt     	#0x4f27
; block 0x4f21
0x004f21:	subs    	r0, r0, r5
0x004f23:	str     	r0, [r4, #8]
0x004f25:	b       	#0x4f41
; block 0x4f27
0x004f27:	ldr     	r0, [r4, #8]
0x004f29:	str     	r6, [r4, #8]
0x004f2b:	subs    	r2, r5, r0
0x004f2d:	cmp     	r1, #0
0x004f2f:	beq     	#0x4f3d
; block 0x4f31
0x004f31:	ldr     	r3, [r1, #8]
0x004f33:	adds    	r3, r3, r2
0x004f35:	str     	r3, [r1, #8]
0x004f37:	ldr     	r1, [r1, #0x18]
0x004f39:	cmp     	r1, #0
0x004f3b:	bne     	#0x4f31
; block 0x4f3d
0x004f3d:	bl      	#0x4f8d
; block 0x4f41
0x004f41:	ldr     	r1, [r7, #8]
0x004f43:	cmp     	r1, #0
0x004f45:	bne     	#0x4f4d
; block 0x4f47
0x004f47:	str     	r4, [r7, #8]
0x004f49:	str     	r6, [r4, #0x18]
0x004f4b:	b       	#0x4f71
; block 0x4f4d
0x004f4d:	ldr     	r2, [r4, #8]
0x004f4f:	ldr     	r0, [r1, #8]
0x004f51:	cmp     	r2, r0
0x004f53:	bge     	#0x4f5b
; block 0x4f55
0x004f55:	str     	r1, [r4, #0x18]
0x004f57:	str     	r4, [r7, #8]
0x004f59:	b       	#0x4f71
; block 0x4f5b
0x004f5b:	ldr     	r0, [r1, #0x18]
0x004f5d:	b       	#0x4f63
; block 0x4f5f
0x004f5f:	adds    	r1, r0, #0
0x004f61:	ldr     	r0, [r0, #0x18]
0x004f63:	cmp     	r0, #0
0x004f65:	beq     	#0x4f6d
; block 0x4f63
0x004f63:	cmp     	r0, #0
0x004f65:	beq     	#0x4f6d
; block 0x4f67
0x004f67:	ldr     	r3, [r0, #8]
0x004f69:	cmp     	r2, r3
0x004f6b:	bge     	#0x4f5f
; block 0x4f6d
0x004f6d:	str     	r4, [r1, #0x18]
0x004f6f:	str     	r0, [r4, #0x18]
0x004f71:	movs    	r0, #0
0x004f73:	b       	#0x4e83
; block 0x4f71
0x004f71:	movs    	r0, #0
0x004f73:	b       	#0x4e83

; ===== sub_4f8d @ 0x4f8d offset=0x4f8c size=44 blocks=4 cc=3 =====
; block 0x4f8d
0x004f8d:	push    	{r3, r4, r5, lr}
0x004f8f:	ldr     	r4, [pc, #0x28]
0x004f91:	adds    	r5, r0, #0
0x004f93:	add     	r4, pc
0x004f95:	ldr     	r0, [r4, #0x38]
0x004f97:	adds    	r0, #0x80
0x004f99:	ldr     	r0, [r0, #4]
0x004f9b:	blx     	r0
; block 0x4f9d
0x004f9d:	adds    	r0, r0, r5
0x004f9f:	ldr     	r1, [pc, #0x1c]
0x004fa1:	add     	r1, sb
0x004fa3:	str     	r0, [r1, #0x10]
0x004fa5:	ldr     	r0, [r4, #0x38]
0x004fa7:	adds    	r0, #0x80
0x004fa9:	ldr     	r0, [r0]
0x004fab:	blx     	r0
; block 0x4fad
0x004fad:	ldr     	r0, [r4, #0x38]
0x004faf:	ldr     	r1, [r0, #0x7c]
0x004fb1:	lsls    	r0, r5, #0x10
0x004fb3:	lsrs    	r0, r0, #0x10
0x004fb5:	blx     	r1
; block 0x4fb7
0x004fb7:	pop     	{r3, r4, r5, pc}

; ===== sub_4fb9 @ 0x4fb9 offset=0x4fb8 size=8 blocks=1 cc=1 =====
; block 0x4fb9
0x004fb9:	add     	sp, #0xc8
0x004fbb:	vsra.u32	d16, d28, #1
0x004fbf:	movs    	r0, r0
0x004fc1:	ldr     	r0, [pc, #0xd4]
0x004fc3:	push    	{r3, r4, r5, r6, r7, lr}
0x004fc5:	add     	r0, pc
0x004fc7:	ldr     	r0, [r0, #0x38]
0x004fc9:	adds    	r0, #0x80
0x004fcb:	ldr     	r0, [r0, #4]
0x004fcd:	blx     	r0

; ===== sub_4fc1 @ 0x4fc1 offset=0x4fc0 size=216 blocks=32 cc=18 =====
; block 0x4fc1
0x004fc1:	ldr     	r0, [pc, #0xd4]
0x004fc3:	push    	{r3, r4, r5, r6, r7, lr}
0x004fc5:	add     	r0, pc
0x004fc7:	ldr     	r0, [r0, #0x38]
0x004fc9:	adds    	r0, #0x80
0x004fcb:	ldr     	r0, [r0, #4]
0x004fcd:	blx     	r0
; block 0x4fcf
0x004fcf:	movs    	r5, #0
0x004fd1:	ldr     	r6, [pc, #0xc8]
0x004fd3:	add     	r6, sb
0x004fd5:	ldr     	r1, [r6, #0x10]
0x004fd7:	str     	r5, [r6, #0x10]
0x004fd9:	subs    	r1, r0, r1
0x004fdb:	ldr     	r0, [r6, #8]
0x004fdd:	adds    	r3, r1, #0
0x004fdf:	cmp     	r0, #0
0x004fe1:	beq     	#0x5097
; block 0x4fe3
0x004fe3:	ldr     	r2, [r0, #8]
0x004fe5:	cmp     	r2, #0
0x004fe7:	bne     	#0x5047
; block 0x4fe9
0x004fe9:	mvns    	r7, r2
0x004feb:	str     	r7, [r0, #8]
0x004fed:	ldr     	r2, [r0, #0x18]
0x004fef:	adds    	r4, r0, #0
0x004ff1:	cmp     	r1, #0x32
0x004ff3:	str     	r2, [r6, #8]
0x004ff5:	bge     	#0x4ffb
; block 0x4ff7
0x004ff7:	movs    	r1, #0x32
0x004ff9:	b       	#0x5017
; block 0x4ffb
0x004ffb:	movs    	r2, #0x7d
0x004ffd:	lsls    	r2, r2, #4
0x004fff:	cmp     	r1, r2
0x005001:	ble     	#0x5017
; block 0x5003
0x005003:	adds    	r1, r2, #0
0x005005:	b       	#0x5017
; block 0x5007
0x005007:	movs    	r7, #0
0x005009:	mvns    	r7, r7
0x00500b:	str     	r7, [r2, #8]
0x00500d:	ldr     	r2, [r0, #0x18]
0x00500f:	str     	r2, [r0, #0x1c]
0x005011:	ldr     	r0, [r2, #0x18]
0x005013:	str     	r0, [r6, #8]
0x005015:	adds    	r0, r2, #0
0x005017:	ldr     	r2, [r0, #0x18]
0x005019:	cmp     	r2, #0
0x00501b:	beq     	#0x5023
; block 0x5017
0x005017:	ldr     	r2, [r0, #0x18]
0x005019:	cmp     	r2, #0
0x00501b:	beq     	#0x5023
; block 0x501d
0x00501d:	ldr     	r7, [r2, #8]
0x00501f:	cmp     	r7, r1
0x005021:	blt     	#0x5007
; block 0x5023
0x005023:	str     	r5, [r0, #0x1c]
0x005025:	ldr     	r0, [r6, #8]
0x005027:	cmp     	r0, #0
0x005029:	beq     	#0x508b
; block 0x502b
0x00502b:	cmp     	r3, #0
0x00502d:	bge     	#0x5031
; block 0x502f
0x00502f:	movs    	r3, #0
0x005031:	ldr     	r0, [r6, #8]
0x005033:	ldr     	r1, [r0, #8]
0x005035:	cmp     	r1, #0
0x005037:	bge     	#0x503d
; block 0x5031
0x005031:	ldr     	r0, [r6, #8]
0x005033:	ldr     	r1, [r0, #8]
0x005035:	cmp     	r1, #0
0x005037:	bge     	#0x503d
; block 0x5039
0x005039:	movs    	r1, #0
0x00503b:	str     	r5, [r0, #8]
0x00503d:	ldr     	r2, [pc, #0x60]
0x00503f:	cmp     	r1, r2
0x005041:	ble     	#0x504b
; block 0x503d
0x00503d:	ldr     	r2, [pc, #0x60]
0x00503f:	cmp     	r1, r2
0x005041:	ble     	#0x504b
; block 0x5043
0x005043:	adds    	r1, r2, #0
0x005045:	b       	#0x504b
; block 0x5047
0x005047:	movs    	r4, #0
0x005049:	b       	#0x502b
; block 0x504b
0x00504b:	ldr     	r2, [r0, #8]
0x00504d:	subs    	r2, r2, r1
0x00504f:	str     	r2, [r0, #8]
0x005051:	ldr     	r0, [r0, #0x18]
0x005053:	cmp     	r0, #0
0x005055:	bne     	#0x504b
; block 0x5057
0x005057:	subs    	r0, r1, r3
0x005059:	cmp     	r0, #0
0x00505b:	bgt     	#0x505f
; block 0x505d
0x00505d:	movs    	r0, #0xa
0x00505f:	bl      	#0x4f8d
; block 0x505f
0x00505f:	bl      	#0x4f8d
; block 0x5063
0x005063:	b       	#0x508b
; block 0x5065
0x005065:	str     	r5, [r4, #8]
0x005067:	ldr     	r0, [r4, #0x1c]
0x005069:	adds    	r3, r5, #0
0x00506b:	str     	r0, [r6, #0xc]
0x00506d:	ldr     	r0, [r4, #0x14]
0x00506f:	cmp     	r0, #0
0x005071:	beq     	#0x507f
; block 0x5073
0x005073:	str     	r0, [sp]
0x005075:	movs    	r1, #0
0x005077:	adds    	r0, r4, #0
0x005079:	ldr     	r2, [r4, #0x10]
0x00507b:	bl      	#0x4e61
; block 0x507f
0x00507f:	ldr     	r1, [r4, #0xc]
0x005081:	cmp     	r1, #0
0x005083:	beq     	#0x5089
; block 0x5085
0x005085:	ldr     	r0, [r4, #0x10]
0x005087:	blx     	r1
; block 0x5089
0x005089:	ldr     	r4, [r6, #0xc]
0x00508b:	cmp     	r4, #0
0x00508d:	beq     	#0x5095
; block 0x508b
0x00508b:	cmp     	r4, #0
0x00508d:	beq     	#0x5095
; block 0x508f
0x00508f:	ldr     	r0, [r4, #8]
0x005091:	cmp     	r0, #0
0x005093:	blt     	#0x5065
; block 0x5095
0x005095:	str     	r5, [r6, #0xc]
0x005097:	pop     	{r3, r4, r5, r6, r7, pc}
; block 0x5097
0x005097:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== sub_50a3 @ 0x50a3 offset=0x50a2 size=2 blocks=1 cc=1 =====
; block 0x50a3
0x0050a3:	movs    	r0, r0
0x0050a5:	push    	{r4, r5, r6, r7, lr}
0x0050a7:	sub     	sp, #0x14
0x0050a9:	movs    	r1, #0
0x0050ab:	str     	r1, [sp]
0x0050ad:	str     	r1, [sp, #4]
0x0050af:	movs    	r2, #0
0x0050b1:	str     	r2, [sp, #8]
0x0050b3:	adds    	r4, r0, #0
0x0050b5:	ldr     	r2, [r0, #8]
0x0050b7:	movs    	r5, #0
0x0050b9:	adds    	r3, r5, #0
0x0050bb:	movs    	r0, #0xf1
0x0050bd:	movs    	r1, #0x45
0x0050bf:	lsls    	r0, r0, #9
0x0050c1:	bl      	#0x4c2d

; ===== sub_50a5 @ 0x50a5 offset=0x50a4 size=150 blocks=6 cc=5 =====
; block 0x50a5
0x0050a5:	push    	{r4, r5, r6, r7, lr}
0x0050a7:	sub     	sp, #0x14
0x0050a9:	movs    	r1, #0
0x0050ab:	str     	r1, [sp]
0x0050ad:	str     	r1, [sp, #4]
0x0050af:	movs    	r2, #0
0x0050b1:	str     	r2, [sp, #8]
0x0050b3:	adds    	r4, r0, #0
0x0050b5:	ldr     	r2, [r0, #8]
0x0050b7:	movs    	r5, #0
0x0050b9:	adds    	r3, r5, #0
0x0050bb:	movs    	r0, #0xf1
0x0050bd:	movs    	r1, #0x45
0x0050bf:	lsls    	r0, r0, #9
0x0050c1:	bl      	#0x4c2d
; block 0x50c5
0x0050c5:	movs    	r1, #0
0x0050c7:	str     	r1, [sp]
0x0050c9:	str     	r1, [sp, #4]
0x0050cb:	str     	r0, [sp, #0x10]
0x0050cd:	movs    	r2, #0
0x0050cf:	str     	r2, [sp, #8]
0x0050d1:	movs    	r0, #0xf1
0x0050d3:	movs    	r1, #0x46
0x0050d5:	adds    	r3, r5, #0
0x0050d7:	lsls    	r0, r0, #9
0x0050d9:	ldr     	r2, [r4, #8]
0x0050db:	bl      	#0x4c2d
; block 0x50df
0x0050df:	movs    	r1, #0
0x0050e1:	str     	r1, [sp]
0x0050e3:	str     	r1, [sp, #4]
0x0050e5:	lsls    	r6, r0, #0x18
0x0050e7:	movs    	r2, #0
0x0050e9:	str     	r2, [sp, #8]
0x0050eb:	asrs    	r6, r6, #0x18
0x0050ed:	movs    	r0, #0xf1
0x0050ef:	movs    	r1, #0x45
0x0050f1:	adds    	r3, r5, #0
0x0050f3:	lsls    	r0, r0, #9
0x0050f5:	ldr     	r2, [r4, #8]
0x0050f7:	bl      	#0x4c2d
; block 0x50fb
0x0050fb:	movs    	r1, #0
0x0050fd:	str     	r1, [sp]
0x0050ff:	str     	r1, [sp, #4]
0x005101:	adds    	r7, r0, #0
0x005103:	movs    	r2, #0
0x005105:	str     	r2, [sp, #8]
0x005107:	movs    	r0, #0xf1
0x005109:	adds    	r3, r5, #0
0x00510b:	movs    	r1, #0x45
0x00510d:	lsls    	r0, r0, #9
0x00510f:	ldr     	r2, [r4, #8]
0x005111:	bl      	#0x4c2d
; block 0x5115
0x005115:	movs    	r1, #0
0x005117:	adds    	r4, r0, #0
0x005119:	movs    	r2, #0
0x00511b:	str     	r2, [sp, #8]
0x00511d:	str     	r1, [sp]
0x00511f:	str     	r1, [sp, #4]
0x005121:	movs    	r1, #0xf
0x005123:	movs    	r2, #0x10
0x005125:	movs    	r0, #0xf1
0x005127:	adds    	r3, r5, #0
0x005129:	lsls    	r0, r0, #9
0x00512b:	bl      	#0x4c2d
; block 0x512f
0x00512f:	ldr     	r1, [sp, #0x10]
0x005131:	stm     	r0!, {r1, r6, r7}
0x005133:	subs    	r0, #0xc
0x005135:	str     	r4, [r0, #0xc]
0x005137:	add     	sp, #0x14
0x005139:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_513d @ 0x513d offset=0x513c size=112 blocks=7 cc=5 =====
; block 0x513d
0x00513d:	push    	{r4, r5, r6, r7, lr}
0x00513f:	sub     	sp, #0xc
0x005141:	movs    	r1, #0
0x005143:	str     	r1, [sp]
0x005145:	str     	r1, [sp, #4]
0x005147:	movs    	r2, #0
0x005149:	str     	r2, [sp, #8]
0x00514b:	ldr     	r2, [r0, #8]
0x00514d:	adds    	r7, r0, #0
0x00514f:	movs    	r0, #0xf1
0x005151:	movs    	r1, #0x46
0x005153:	movs    	r3, #0
0x005155:	lsls    	r0, r0, #9
0x005157:	bl      	#0x4c2d
; block 0x515b
0x00515b:	lsls    	r5, r0, #0x18
0x00515d:	movs    	r1, #0
0x00515f:	movs    	r2, #0
0x005161:	str     	r2, [sp, #8]
0x005163:	str     	r1, [sp]
0x005165:	str     	r1, [sp, #4]
0x005167:	asrs    	r5, r5, #0x18
0x005169:	adds    	r2, r5, #0
0x00516b:	movs    	r1, #0xa
0x00516d:	movs    	r0, #0xf1
0x00516f:	movs    	r3, #4
0x005171:	lsls    	r0, r0, #9
0x005173:	bl      	#0x4c2d
; block 0x5177
0x005177:	adds    	r6, r0, #0
0x005179:	movs    	r4, #0
0x00517b:	cmp     	r5, #0
0x00517d:	ble     	#0x518f
; block 0x517f
0x00517f:	adds    	r0, r7, #0
0x005181:	bl      	#0x52a5
; block 0x5185
0x005185:	lsls    	r1, r4, #2
0x005187:	adds    	r4, #1
0x005189:	cmp     	r4, r5
0x00518b:	str     	r0, [r6, r1]
0x00518d:	blt     	#0x517f
; block 0x518f
0x00518f:	movs    	r1, #0
0x005191:	movs    	r2, #0
0x005193:	str     	r2, [sp, #8]
0x005195:	str     	r1, [sp]
0x005197:	str     	r1, [sp, #4]
0x005199:	movs    	r1, #0xf
0x00519b:	movs    	r2, #4
0x00519d:	movs    	r3, #0
0x00519f:	movs    	r0, #0xf1
0x0051a1:	lsls    	r0, r0, #9
0x0051a3:	bl      	#0x4c2d
; block 0x51a7
0x0051a7:	str     	r6, [r0]
0x0051a9:	add     	sp, #0xc
0x0051ab:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_51ad @ 0x51ad offset=0x51ac size=248 blocks=9 cc=8 =====
; block 0x51ad
0x0051ad:	push    	{r4, r5, r6, r7, lr}
0x0051af:	sub     	sp, #0x24
0x0051b1:	movs    	r1, #0
0x0051b3:	str     	r1, [sp]
0x0051b5:	str     	r1, [sp, #4]
0x0051b7:	movs    	r2, #0
0x0051b9:	str     	r2, [sp, #8]
0x0051bb:	adds    	r5, r0, #0
0x0051bd:	ldr     	r2, [r0, #8]
0x0051bf:	movs    	r4, #0
0x0051c1:	adds    	r3, r4, #0
0x0051c3:	movs    	r0, #0xf1
0x0051c5:	movs    	r1, #0x45
0x0051c7:	lsls    	r0, r0, #9
0x0051c9:	bl      	#0x4c2d
; block 0x51cd
0x0051cd:	str     	r0, [sp, #0x20]
0x0051cf:	movs    	r1, #0
0x0051d1:	str     	r1, [sp]
0x0051d3:	str     	r1, [sp, #4]
0x0051d5:	movs    	r2, #0
0x0051d7:	str     	r2, [sp, #8]
0x0051d9:	movs    	r1, #0x45
0x0051db:	movs    	r0, #0xf1
0x0051dd:	adds    	r3, r4, #0
0x0051df:	lsls    	r0, r0, #9
0x0051e1:	ldr     	r2, [r5, #8]
0x0051e3:	bl      	#0x4c2d
; block 0x51e7
0x0051e7:	movs    	r1, #0
0x0051e9:	str     	r1, [sp]
0x0051eb:	str     	r1, [sp, #4]
0x0051ed:	str     	r0, [sp, #0x1c]
0x0051ef:	movs    	r2, #0
0x0051f1:	str     	r2, [sp, #8]
0x0051f3:	movs    	r0, #0xf1
0x0051f5:	movs    	r1, #0x47
0x0051f7:	adds    	r3, r4, #0
0x0051f9:	lsls    	r0, r0, #9
0x0051fb:	ldr     	r2, [r5, #8]
0x0051fd:	bl      	#0x4c2d
; block 0x5201
0x005201:	movs    	r1, #0
0x005203:	str     	r1, [sp]
0x005205:	str     	r1, [sp, #4]
0x005207:	str     	r0, [sp, #0x18]
0x005209:	movs    	r2, #0
0x00520b:	str     	r2, [sp, #8]
0x00520d:	movs    	r0, #0xf1
0x00520f:	movs    	r1, #0x47
0x005211:	adds    	r3, r4, #0
0x005213:	lsls    	r0, r0, #9
0x005215:	ldr     	r2, [r5, #8]
0x005217:	bl      	#0x4c2d
; block 0x521b
0x00521b:	movs    	r1, #0
0x00521d:	str     	r1, [sp]
0x00521f:	str     	r1, [sp, #4]
0x005221:	str     	r0, [sp, #0x14]
0x005223:	movs    	r2, #0
0x005225:	str     	r2, [sp, #8]
0x005227:	movs    	r0, #0xf1
0x005229:	movs    	r1, #0x46
0x00522b:	adds    	r3, r4, #0
0x00522d:	lsls    	r0, r0, #9
0x00522f:	ldr     	r2, [r5, #8]
0x005231:	bl      	#0x4c2d
; block 0x5235
0x005235:	movs    	r1, #0
0x005237:	str     	r1, [sp]
0x005239:	str     	r1, [sp, #4]
0x00523b:	str     	r0, [sp, #0x10]
0x00523d:	movs    	r2, #0
0x00523f:	str     	r2, [sp, #8]
0x005241:	movs    	r0, #0xf1
0x005243:	movs    	r1, #0x45
0x005245:	adds    	r3, r4, #0
0x005247:	lsls    	r0, r0, #9
0x005249:	ldr     	r2, [r5, #8]
0x00524b:	bl      	#0x4c2d
; block 0x524f
0x00524f:	movs    	r1, #0
0x005251:	str     	r1, [sp]
0x005253:	str     	r1, [sp, #4]
0x005255:	adds    	r7, r0, #0
0x005257:	movs    	r2, #0
0x005259:	str     	r2, [sp, #8]
0x00525b:	movs    	r0, #0xf1
0x00525d:	adds    	r3, r4, #0
0x00525f:	movs    	r1, #0x46
0x005261:	lsls    	r0, r0, #9
0x005263:	ldr     	r2, [r5, #8]
0x005265:	bl      	#0x4c2d
; block 0x5269
0x005269:	movs    	r1, #0
0x00526b:	adds    	r6, r0, #0
0x00526d:	movs    	r2, #0
0x00526f:	str     	r2, [sp, #8]
0x005271:	str     	r1, [sp]
0x005273:	str     	r1, [sp, #4]
0x005275:	movs    	r1, #0xf
0x005277:	movs    	r2, #0x1c
0x005279:	movs    	r0, #0xf1
0x00527b:	adds    	r3, r4, #0
0x00527d:	mvns    	r5, r4
0x00527f:	lsls    	r0, r0, #9
0x005281:	bl      	#0x4c2d
; block 0x5285
0x005285:	ldr     	r1, [sp, #0x20]
0x005287:	str     	r1, [r0]
0x005289:	ldr     	r1, [sp, #0x1c]
0x00528b:	str     	r1, [r0, #0x14]
0x00528d:	ldr     	r1, [sp, #0x18]
0x00528f:	str     	r1, [r0, #0xc]
0x005291:	ldr     	r1, [sp, #0x14]
0x005293:	str     	r1, [r0, #0x10]
0x005295:	ldr     	r1, [sp, #0x10]
0x005297:	strb    	r1, [r0, #8]
0x005299:	str     	r7, [r0, #4]
0x00529b:	strb    	r6, [r0, #0x18]
0x00529d:	strb    	r5, [r0, #0x19]
0x00529f:	strb    	r5, [r0, #0x1a]
0x0052a1:	add     	sp, #0x24
0x0052a3:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_52a5 @ 0x52a5 offset=0x52a4 size=234 blocks=14 cc=9 =====
; block 0x52a5
0x0052a5:	push    	{r4, r5, r6, r7, lr}
0x0052a7:	sub     	sp, #0x1c
0x0052a9:	movs    	r1, #0
0x0052ab:	str     	r1, [sp]
0x0052ad:	str     	r1, [sp, #4]
0x0052af:	movs    	r2, #0
0x0052b1:	str     	r2, [sp, #8]
0x0052b3:	adds    	r5, r0, #0
0x0052b5:	ldr     	r2, [r0, #8]
0x0052b7:	movs    	r4, #0
0x0052b9:	adds    	r3, r4, #0
0x0052bb:	movs    	r0, #0xf1
0x0052bd:	movs    	r1, #0x46
0x0052bf:	lsls    	r0, r0, #9
0x0052c1:	bl      	#0x4c2d
; block 0x52c5
0x0052c5:	lsls    	r1, r0, #0x18
0x0052c7:	asrs    	r1, r1, #0x18
0x0052c9:	str     	r1, [sp, #0x18]
0x0052cb:	movs    	r1, #0
0x0052cd:	str     	r1, [sp]
0x0052cf:	str     	r1, [sp, #4]
0x0052d1:	movs    	r2, #0
0x0052d3:	str     	r2, [sp, #8]
0x0052d5:	movs    	r1, #0x46
0x0052d7:	movs    	r0, #0xf1
0x0052d9:	adds    	r3, r4, #0
0x0052db:	lsls    	r0, r0, #9
0x0052dd:	ldr     	r2, [r5, #8]
0x0052df:	bl      	#0x4c2d
; block 0x52e3
0x0052e3:	lsls    	r0, r0, #0x18
0x0052e5:	movs    	r1, #0
0x0052e7:	asrs    	r0, r0, #0x18
0x0052e9:	str     	r0, [sp, #0x14]
0x0052eb:	str     	r1, [sp]
0x0052ed:	str     	r1, [sp, #4]
0x0052ef:	movs    	r2, #0
0x0052f1:	str     	r2, [sp, #8]
0x0052f3:	movs    	r1, #0x47
0x0052f5:	movs    	r0, #0xf1
0x0052f7:	adds    	r3, r4, #0
0x0052f9:	lsls    	r0, r0, #9
0x0052fb:	ldr     	r2, [r5, #8]
0x0052fd:	bl      	#0x4c2d
; block 0x5301
0x005301:	movs    	r1, #0
0x005303:	str     	r1, [sp]
0x005305:	str     	r1, [sp, #4]
0x005307:	str     	r0, [sp, #0x10]
0x005309:	movs    	r2, #0
0x00530b:	str     	r2, [sp, #8]
0x00530d:	movs    	r0, #0xf1
0x00530f:	movs    	r1, #0x46
0x005311:	adds    	r3, r4, #0
0x005313:	lsls    	r0, r0, #9
0x005315:	ldr     	r2, [r5, #8]
0x005317:	bl      	#0x4c2d
; block 0x531b
0x00531b:	lsls    	r7, r0, #0x18
0x00531d:	movs    	r1, #0
0x00531f:	movs    	r2, #0
0x005321:	str     	r2, [sp, #8]
0x005323:	str     	r1, [sp]
0x005325:	str     	r1, [sp, #4]
0x005327:	asrs    	r7, r7, #0x18
0x005329:	adds    	r2, r7, #0
0x00532b:	movs    	r1, #0xa
0x00532d:	movs    	r0, #0xf1
0x00532f:	movs    	r3, #4
0x005331:	lsls    	r0, r0, #9
0x005333:	bl      	#0x4c2d
; block 0x5337
0x005337:	adds    	r6, r0, #0
0x005339:	cmp     	r7, #0
0x00533b:	ble     	#0x5365
; block 0x533d
0x00533d:	ldr     	r0, [pc, #0x50]
0x00533f:	movs    	r3, #3
0x005341:	add     	r0, sb
0x005343:	ldrsb   	r0, [r0, r3]
0x005345:	cmp     	r0, #1
0x005347:	bne     	#0x5355
; block 0x5349
0x005349:	adds    	r0, r5, #0
0x00534b:	bl      	#0x5395
; block 0x534f
0x00534f:	lsls    	r1, r4, #2
0x005351:	str     	r0, [r6, r1]
0x005353:	b       	#0x535f
; block 0x5355
0x005355:	adds    	r0, r5, #0
0x005357:	bl      	#0x51ad
; block 0x535b
0x00535b:	lsls    	r1, r4, #2
0x00535d:	str     	r0, [r6, r1]
0x00535f:	adds    	r4, #1
0x005361:	cmp     	r4, r7
0x005363:	blt     	#0x533d
; block 0x535f
0x00535f:	adds    	r4, #1
0x005361:	cmp     	r4, r7
0x005363:	blt     	#0x533d
; block 0x5365
0x005365:	movs    	r1, #0
0x005367:	movs    	r2, #0
0x005369:	str     	r2, [sp, #8]
0x00536b:	str     	r1, [sp]
0x00536d:	str     	r1, [sp, #4]
0x00536f:	movs    	r1, #0xf
0x005371:	movs    	r2, #0x10
0x005373:	movs    	r3, #0
0x005375:	movs    	r0, #0xf1
0x005377:	lsls    	r0, r0, #9
0x005379:	bl      	#0x4c2d
; block 0x537d
0x00537d:	ldr     	r1, [sp, #0x18]
0x00537f:	strb    	r1, [r0]
0x005381:	ldr     	r1, [sp, #0x10]
0x005383:	str     	r1, [r0, #4]
0x005385:	ldr     	r1, [sp, #0x14]
0x005387:	strb    	r1, [r0, #8]
0x005389:	str     	r6, [r0, #0xc]
0x00538b:	add     	sp, #0x1c
0x00538d:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_5391 @ 0x5391 offset=0x5390 size=4 blocks=1 cc=1 =====
; block 0x5391
0x005391:	movs    	r4, r0
0x005393:	movs    	r0, r0
0x005395:	push    	{r4, r5, r6, r7, lr}
0x005397:	sub     	sp, #0x24
0x005399:	movs    	r1, #0
0x00539b:	str     	r1, [sp]
0x00539d:	str     	r1, [sp, #4]
0x00539f:	movs    	r2, #0
0x0053a1:	str     	r2, [sp, #8]
0x0053a3:	adds    	r5, r0, #0
0x0053a5:	ldr     	r2, [r0, #8]
0x0053a7:	movs    	r6, #0
0x0053a9:	adds    	r3, r6, #0
0x0053ab:	movs    	r0, #0xf1
0x0053ad:	movs    	r1, #0x45
0x0053af:	lsls    	r0, r0, #9
0x0053b1:	bl      	#0x4c2d

; ===== sub_5395 @ 0x5395 offset=0x5394 size=250 blocks=9 cc=8 =====
; block 0x5395
0x005395:	push    	{r4, r5, r6, r7, lr}
0x005397:	sub     	sp, #0x24
0x005399:	movs    	r1, #0
0x00539b:	str     	r1, [sp]
0x00539d:	str     	r1, [sp, #4]
0x00539f:	movs    	r2, #0
0x0053a1:	str     	r2, [sp, #8]
0x0053a3:	adds    	r5, r0, #0
0x0053a5:	ldr     	r2, [r0, #8]
0x0053a7:	movs    	r6, #0
0x0053a9:	adds    	r3, r6, #0
0x0053ab:	movs    	r0, #0xf1
0x0053ad:	movs    	r1, #0x45
0x0053af:	lsls    	r0, r0, #9
0x0053b1:	bl      	#0x4c2d
; block 0x53b5
0x0053b5:	str     	r0, [sp, #0x20]
0x0053b7:	movs    	r1, #0
0x0053b9:	str     	r1, [sp]
0x0053bb:	str     	r1, [sp, #4]
0x0053bd:	movs    	r2, #0
0x0053bf:	str     	r2, [sp, #8]
0x0053c1:	movs    	r1, #0x47
0x0053c3:	movs    	r0, #0xf1
0x0053c5:	adds    	r3, r6, #0
0x0053c7:	lsls    	r0, r0, #9
0x0053c9:	ldr     	r2, [r5, #8]
0x0053cb:	bl      	#0x4c2d
; block 0x53cf
0x0053cf:	movs    	r1, #0
0x0053d1:	str     	r1, [sp]
0x0053d3:	str     	r1, [sp, #4]
0x0053d5:	str     	r0, [sp, #0x1c]
0x0053d7:	movs    	r2, #0
0x0053d9:	str     	r2, [sp, #8]
0x0053db:	movs    	r0, #0xf1
0x0053dd:	movs    	r1, #0x47
0x0053df:	adds    	r3, r6, #0
0x0053e1:	lsls    	r0, r0, #9
0x0053e3:	ldr     	r2, [r5, #8]
0x0053e5:	bl      	#0x4c2d
; block 0x53e9
0x0053e9:	movs    	r1, #0
0x0053eb:	str     	r1, [sp]
0x0053ed:	str     	r1, [sp, #4]
0x0053ef:	str     	r0, [sp, #0x18]
0x0053f1:	movs    	r2, #0
0x0053f3:	str     	r2, [sp, #8]
0x0053f5:	movs    	r0, #0xf1
0x0053f7:	movs    	r1, #0x46
0x0053f9:	adds    	r3, r6, #0
0x0053fb:	lsls    	r0, r0, #9
0x0053fd:	ldr     	r2, [r5, #8]
0x0053ff:	bl      	#0x4c2d
; block 0x5403
0x005403:	movs    	r1, #0
0x005405:	str     	r1, [sp]
0x005407:	str     	r1, [sp, #4]
0x005409:	str     	r0, [sp, #0x14]
0x00540b:	movs    	r2, #0
0x00540d:	str     	r2, [sp, #8]
0x00540f:	movs    	r0, #0xf1
0x005411:	movs    	r1, #0x45
0x005413:	adds    	r3, r6, #0
0x005415:	lsls    	r0, r0, #9
0x005417:	ldr     	r2, [r5, #8]
0x005419:	bl      	#0x4c2d
; block 0x541d
0x00541d:	movs    	r1, #0
0x00541f:	movs    	r2, #0
0x005421:	str     	r2, [sp, #8]
0x005423:	str     	r1, [sp]
0x005425:	str     	r1, [sp, #4]
0x005427:	str     	r0, [sp, #0x10]
0x005429:	movs    	r0, #0xf1
0x00542b:	movs    	r1, #0xf
0x00542d:	movs    	r2, #0x1c
0x00542f:	adds    	r3, r6, #0
0x005431:	lsls    	r0, r0, #9
0x005433:	bl      	#0x4c2d
; block 0x5437
0x005437:	movs    	r1, #0
0x005439:	str     	r1, [sp]
0x00543b:	str     	r1, [sp, #4]
0x00543d:	adds    	r4, r0, #0
0x00543f:	movs    	r2, #0
0x005441:	str     	r2, [sp, #8]
0x005443:	movs    	r0, #0xf1
0x005445:	adds    	r3, r6, #0
0x005447:	movs    	r1, #0x46
0x005449:	lsls    	r0, r0, #9
0x00544b:	ldr     	r2, [r5, #8]
0x00544d:	bl      	#0x4c2d
; block 0x5451
0x005451:	movs    	r1, #0
0x005453:	str     	r1, [sp]
0x005455:	str     	r1, [sp, #4]
0x005457:	adds    	r7, r0, #0
0x005459:	movs    	r2, #0
0x00545b:	str     	r2, [sp, #8]
0x00545d:	movs    	r0, #0xf1
0x00545f:	adds    	r3, r6, #0
0x005461:	movs    	r1, #0x46
0x005463:	lsls    	r0, r0, #9
0x005465:	ldr     	r2, [r5, #8]
0x005467:	bl      	#0x4c2d
; block 0x546b
0x00546b:	ldr     	r2, [sp, #0x20]
0x00546d:	adds    	r1, r0, #0
0x00546f:	str     	r2, [r4]
0x005471:	mvns    	r2, r6
0x005473:	str     	r2, [r4, #0x14]
0x005475:	ldr     	r2, [sp, #0x1c]
0x005477:	str     	r2, [r4, #0xc]
0x005479:	ldr     	r2, [sp, #0x18]
0x00547b:	str     	r2, [r4, #0x10]
0x00547d:	ldr     	r0, [sp, #0x14]
0x00547f:	strb    	r0, [r4, #8]
0x005481:	ldr     	r0, [sp, #0x10]
0x005483:	str     	r0, [r4, #4]
0x005485:	strb    	r7, [r4, #0x19]
0x005487:	strb    	r1, [r4, #0x1a]
0x005489:	add     	sp, #0x24
0x00548b:	adds    	r0, r4, #0
0x00548d:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_5491 @ 0x5491 offset=0x5490 size=222 blocks=15 cc=13 =====
; block 0x5491
0x005491:	push    	{r4, r5, r6, r7, lr}
0x005493:	ldr     	r4, [pc, #0xdc]
0x005495:	movs    	r7, #0xf1
0x005497:	add     	r4, sb
0x005499:	ldr     	r5, [r4, #0x4c]
0x00549b:	lsls    	r7, r7, #9
0x00549d:	movs    	r6, #0
0x00549f:	cmp     	r5, #0
0x0054a1:	sub     	sp, #0xc
0x0054a3:	beq     	#0x54bb
; block 0x54a5
0x0054a5:	movs    	r1, #0
0x0054a7:	movs    	r2, #0
0x0054a9:	str     	r2, [sp, #8]
0x0054ab:	str     	r1, [sp]
0x0054ad:	str     	r1, [sp, #4]
0x0054af:	movs    	r1, #9
0x0054b1:	adds    	r2, r5, #0
0x0054b3:	adds    	r3, r6, #0
0x0054b5:	adds    	r0, r7, #0
0x0054b7:	bl      	#0x4c2d
; block 0x54bb
0x0054bb:	ldr     	r4, [pc, #0xb4]
0x0054bd:	add     	r4, sb
0x0054bf:	str     	r6, [r4, #0x4c]
0x0054c1:	ldr     	r4, [r4, #0x34]
0x0054c3:	cmp     	r4, #0
0x0054c5:	beq     	#0x552b
; block 0x54c7
0x0054c7:	movs    	r1, #0
0x0054c9:	movs    	r2, #0
0x0054cb:	str     	r2, [sp, #8]
0x0054cd:	str     	r1, [sp]
0x0054cf:	str     	r1, [sp, #4]
0x0054d1:	movs    	r1, #0x11
0x0054d3:	adds    	r2, r4, #0
0x0054d5:	movs    	r3, #4
0x0054d7:	adds    	r0, r7, #0
0x0054d9:	bl      	#0x4c2d
; block 0x54dd
0x0054dd:	adds    	r5, r0, #0
0x0054df:	movs    	r4, #0
0x0054e1:	cmp     	r0, #0
0x0054e3:	ble     	#0x550f
; block 0x54e5
0x0054e5:	ldr     	r1, [pc, #0x88]
0x0054e7:	lsls    	r0, r4, #2
0x0054e9:	add     	r1, sb
0x0054eb:	ldr     	r1, [r1, #0x34]
0x0054ed:	ldr     	r3, [r1, r0]
0x0054ef:	cmp     	r3, #0
0x0054f1:	beq     	#0x5509
; block 0x54f3
0x0054f3:	movs    	r2, #0
0x0054f5:	movs    	r1, #0
0x0054f7:	str     	r2, [sp, #8]
0x0054f9:	adds    	r2, r3, #0
0x0054fb:	str     	r1, [sp]
0x0054fd:	str     	r1, [sp, #4]
0x0054ff:	movs    	r1, #9
0x005501:	adds    	r3, r6, #0
0x005503:	adds    	r0, r7, #0
0x005505:	bl      	#0x4c2d
; block 0x5509
0x005509:	adds    	r4, #1
0x00550b:	cmp     	r4, r5
0x00550d:	blt     	#0x54e5
; block 0x550f
0x00550f:	movs    	r1, #0
0x005511:	str     	r1, [sp]
0x005513:	str     	r1, [sp, #4]
0x005515:	movs    	r2, #0
0x005517:	ldr     	r4, [pc, #0x58]
0x005519:	str     	r2, [sp, #8]
0x00551b:	movs    	r1, #9
0x00551d:	adds    	r3, r6, #0
0x00551f:	add     	r4, sb
0x005521:	ldr     	r2, [r4, #0x34]
0x005523:	adds    	r0, r7, #0
0x005525:	bl      	#0x4c2d
; block 0x5529
0x005529:	str     	r6, [r4, #0x34]
0x00552b:	ldr     	r4, [pc, #0x44]
0x00552d:	add     	r4, sb
0x00552f:	ldr     	r5, [r4, #0x5c]
0x005531:	cmp     	r5, #0
0x005533:	beq     	#0x554b
; block 0x552b
0x00552b:	ldr     	r4, [pc, #0x44]
0x00552d:	add     	r4, sb
0x00552f:	ldr     	r5, [r4, #0x5c]
0x005531:	cmp     	r5, #0
0x005533:	beq     	#0x554b
; block 0x5535
0x005535:	movs    	r1, #0
0x005537:	movs    	r2, #0
0x005539:	str     	r2, [sp, #8]
0x00553b:	str     	r1, [sp]
0x00553d:	str     	r1, [sp, #4]
0x00553f:	movs    	r1, #9
0x005541:	adds    	r2, r5, #0
0x005543:	adds    	r3, r6, #0
0x005545:	adds    	r0, r7, #0
0x005547:	bl      	#0x4c2d
; block 0x554b
0x00554b:	ldr     	r5, [r4, #0x60]
0x00554d:	cmp     	r5, #0
0x00554f:	beq     	#0x5567
; block 0x5551
0x005551:	movs    	r1, #0
0x005553:	movs    	r2, #0
0x005555:	str     	r2, [sp, #8]
0x005557:	str     	r1, [sp]
0x005559:	str     	r1, [sp, #4]
0x00555b:	movs    	r1, #9
0x00555d:	adds    	r2, r5, #0
0x00555f:	adds    	r3, r6, #0
0x005561:	adds    	r0, r7, #0
0x005563:	bl      	#0x4c2d
; block 0x5567
0x005567:	str     	r6, [r4, #0x60]
0x005569:	str     	r6, [r4, #0x5c]
0x00556b:	add     	sp, #0xc
0x00556d:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_5571 @ 0x5571 offset=0x5570 size=4 blocks=1 cc=1 =====
; block 0x5571
0x005571:	movs    	r4, r0
0x005573:	movs    	r0, r0
0x005575:	push    	{r4, r5, r6, r7, lr}
0x005577:	ldr     	r0, [pc, #0xec]
0x005579:	movs    	r7, #0xf1
0x00557b:	add     	r0, sb
0x00557d:	ldr     	r5, [r0, #0x28]
0x00557f:	lsls    	r7, r7, #9
0x005581:	movs    	r6, #0
0x005583:	cmp     	r5, #0
0x005585:	sub     	sp, #0xc
0x005587:	beq     	#0x55eb

; ===== sub_5575 @ 0x5575 offset=0x5574 size=238 blocks=16 cc=13 =====
; block 0x5575
0x005575:	push    	{r4, r5, r6, r7, lr}
0x005577:	ldr     	r0, [pc, #0xec]
0x005579:	movs    	r7, #0xf1
0x00557b:	add     	r0, sb
0x00557d:	ldr     	r5, [r0, #0x28]
0x00557f:	lsls    	r7, r7, #9
0x005581:	movs    	r6, #0
0x005583:	cmp     	r5, #0
0x005585:	sub     	sp, #0xc
0x005587:	beq     	#0x55eb
; block 0x5589
0x005589:	movs    	r1, #0
0x00558b:	movs    	r2, #0
0x00558d:	str     	r2, [sp, #8]
0x00558f:	str     	r1, [sp]
0x005591:	str     	r1, [sp, #4]
0x005593:	movs    	r1, #0x11
0x005595:	adds    	r2, r5, #0
0x005597:	movs    	r4, #0
0x005599:	movs    	r3, #4
0x00559b:	adds    	r0, r7, #0
0x00559d:	bl      	#0x4c2d
; block 0x559f
0x00559f:	smlsd   	ip, r6, r5, r1
0x0055a3:	cmp     	r0, #0
0x0055a5:	ble     	#0x55d1
; block 0x55a1
0x0055a1:	adds    	r5, r0, #0
0x0055a3:	cmp     	r0, #0
0x0055a5:	ble     	#0x55d1
; block 0x55a7
0x0055a7:	ldr     	r1, [pc, #0xbc]
0x0055a9:	lsls    	r0, r4, #2
0x0055ab:	add     	r1, sb
0x0055ad:	ldr     	r1, [r1, #0x28]
0x0055af:	ldr     	r3, [r1, r0]
0x0055b1:	cmp     	r3, #0
0x0055b3:	beq     	#0x55cb
; block 0x55b5
0x0055b5:	movs    	r2, #0
0x0055b7:	movs    	r1, #0
0x0055b9:	str     	r2, [sp, #8]
0x0055bb:	adds    	r2, r3, #0
0x0055bd:	str     	r1, [sp]
0x0055bf:	str     	r1, [sp, #4]
0x0055c1:	movs    	r1, #9
0x0055c3:	adds    	r3, r6, #0
0x0055c5:	adds    	r0, r7, #0
0x0055c7:	bl      	#0x4c2d
; block 0x55cb
0x0055cb:	adds    	r4, #1
0x0055cd:	cmp     	r4, r5
0x0055cf:	blt     	#0x55a7
; block 0x55d1
0x0055d1:	movs    	r1, #0
0x0055d3:	ldr     	r0, [pc, #0x90]
0x0055d5:	str     	r1, [sp]
0x0055d7:	str     	r1, [sp, #4]
0x0055d9:	movs    	r2, #0
0x0055db:	str     	r2, [sp, #8]
0x0055dd:	add     	r0, sb
0x0055df:	ldr     	r2, [r0, #0x28]
0x0055e1:	movs    	r1, #9
0x0055e3:	adds    	r3, r6, #0
0x0055e5:	adds    	r0, r7, #0
0x0055e7:	bl      	#0x4c2d
; block 0x55eb
0x0055eb:	ldr     	r0, [pc, #0x78]
0x0055ed:	add     	r0, sb
0x0055ef:	str     	r6, [r0, #0x28]
0x0055f1:	ldr     	r4, [r0, #0x2c]
0x0055f3:	cmp     	r4, #0
0x0055f5:	beq     	#0x5659
; block 0x55f7
0x0055f7:	movs    	r1, #0
0x0055f9:	movs    	r2, #0
0x0055fb:	str     	r2, [sp, #8]
0x0055fd:	str     	r1, [sp]
0x0055ff:	str     	r1, [sp, #4]
0x005601:	movs    	r1, #0x11
0x005603:	adds    	r2, r4, #0
0x005605:	movs    	r3, #4
0x005607:	adds    	r0, r7, #0
0x005609:	bl      	#0x4c2d
; block 0x560d
0x00560d:	adds    	r5, r0, #0
0x00560f:	movs    	r4, #0
0x005611:	cmp     	r0, #0
0x005613:	ble     	#0x563f
; block 0x5615
0x005615:	ldr     	r1, [pc, #0x4c]
0x005617:	lsls    	r0, r4, #2
0x005619:	add     	r1, sb
0x00561b:	ldr     	r1, [r1, #0x2c]
0x00561d:	ldr     	r3, [r1, r0]
0x00561f:	cmp     	r3, #0
0x005621:	beq     	#0x5639
; block 0x5623
0x005623:	movs    	r1, #0
0x005625:	movs    	r2, #0
0x005627:	str     	r2, [sp, #8]
0x005629:	str     	r1, [sp]
0x00562b:	str     	r1, [sp, #4]
0x00562d:	movs    	r1, #0x12
0x00562f:	adds    	r2, r3, #0
0x005631:	adds    	r0, r7, #0
0x005633:	adds    	r3, r6, #0
0x005635:	bl      	#0x4c2d
; block 0x5639
0x005639:	adds    	r4, #1
0x00563b:	cmp     	r4, r5
0x00563d:	blt     	#0x5615
; block 0x563f
0x00563f:	movs    	r1, #0
0x005641:	ldr     	r0, [pc, #0x20]
0x005643:	str     	r1, [sp]
0x005645:	str     	r1, [sp, #4]
0x005647:	movs    	r2, #0
0x005649:	str     	r2, [sp, #8]
0x00564b:	add     	r0, sb
0x00564d:	ldr     	r2, [r0, #0x2c]
0x00564f:	movs    	r1, #9
0x005651:	adds    	r3, r6, #0
0x005653:	adds    	r0, r7, #0
0x005655:	bl      	#0x4c2d
; block 0x5659
0x005659:	ldr     	r0, [pc, #8]
0x00565b:	add     	r0, sb
0x00565d:	str     	r6, [r0, #0x2c]
0x00565f:	add     	sp, #0xc
0x005661:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_5665 @ 0x5665 offset=0x5664 size=4 blocks=1 cc=1 =====
; block 0x5665
0x005665:	movs    	r4, r0
0x005667:	movs    	r0, r0
0x005669:	push    	{r4, r5, r6, lr}
0x00566b:	sub     	sp, #0x10
0x00566d:	adds    	r4, r0, #0
0x00566f:	beq     	#0x56c5

; ===== sub_5669 @ 0x5669 offset=0x5668 size=96 blocks=7 cc=6 =====
; block 0x5669
0x005669:	push    	{r4, r5, r6, lr}
0x00566b:	sub     	sp, #0x10
0x00566d:	adds    	r4, r0, #0
0x00566f:	beq     	#0x56c5
; block 0x5671
0x005671:	movs    	r6, #0xf1
0x005673:	ldr     	r3, [r4, #0xc]
0x005675:	lsls    	r6, r6, #9
0x005677:	movs    	r5, #0
0x005679:	cmp     	r3, #0
0x00567b:	beq     	#0x5693
; block 0x567d
0x00567d:	movs    	r2, #0
0x00567f:	movs    	r1, #0
0x005681:	str     	r2, [sp, #8]
0x005683:	adds    	r2, r3, #0
0x005685:	str     	r1, [sp]
0x005687:	str     	r1, [sp, #4]
0x005689:	movs    	r1, #9
0x00568b:	adds    	r3, r5, #0
0x00568d:	adds    	r0, r6, #0
0x00568f:	bl      	#0x4c2d
; block 0x5693
0x005693:	ldr     	r3, [r4, #0x10]
0x005695:	cmp     	r3, #0
0x005697:	beq     	#0x56af
; block 0x5699
0x005699:	movs    	r2, #0
0x00569b:	movs    	r1, #0
0x00569d:	str     	r2, [sp, #8]
0x00569f:	adds    	r2, r3, #0
0x0056a1:	str     	r1, [sp]
0x0056a3:	str     	r1, [sp, #4]
0x0056a5:	movs    	r1, #9
0x0056a7:	adds    	r3, r5, #0
0x0056a9:	adds    	r0, r6, #0
0x0056ab:	bl      	#0x4c2d
; block 0x56af
0x0056af:	movs    	r1, #0
0x0056b1:	movs    	r2, #0
0x0056b3:	str     	r2, [sp, #8]
0x0056b5:	str     	r1, [sp]
0x0056b7:	str     	r1, [sp, #4]
0x0056b9:	movs    	r1, #9
0x0056bb:	adds    	r2, r4, #0
0x0056bd:	adds    	r3, r5, #0
0x0056bf:	adds    	r0, r6, #0
0x0056c1:	bl      	#0x4c2d
; block 0x56c5
0x0056c5:	add     	sp, #0x10
0x0056c7:	pop     	{r4, r5, r6, pc}

; ===== sub_56c9 @ 0x56c9 offset=0x56c8 size=146 blocks=11 cc=9 =====
; block 0x56c9
0x0056c9:	push    	{r4, r5, r6, r7, lr}
0x0056cb:	sub     	sp, #0xc
0x0056cd:	adds    	r5, r0, #0
0x0056cf:	beq     	#0x5757
; block 0x56d1
0x0056d1:	ldr     	r3, [r5, #4]
0x0056d3:	movs    	r7, #0
0x0056d5:	cmp     	r3, #0
0x0056d7:	beq     	#0x56f1
; block 0x56d9
0x0056d9:	movs    	r2, #0
0x0056db:	movs    	r1, #0
0x0056dd:	str     	r2, [sp, #8]
0x0056df:	adds    	r2, r3, #0
0x0056e1:	str     	r1, [sp]
0x0056e3:	str     	r1, [sp, #4]
0x0056e5:	movs    	r1, #9
0x0056e7:	adds    	r3, r7, #0
0x0056e9:	movs    	r0, #0xf1
0x0056eb:	lsls    	r0, r0, #9
0x0056ed:	bl      	#0x4c2d
; block 0x56f1
0x0056f1:	ldr     	r3, [r5, #0xc]
0x0056f3:	cmp     	r3, #0
0x0056f5:	beq     	#0x573f
; block 0x56f7
0x0056f7:	movs    	r2, #0
0x0056f9:	movs    	r1, #0
0x0056fb:	str     	r2, [sp, #8]
0x0056fd:	adds    	r2, r3, #0
0x0056ff:	str     	r1, [sp]
0x005701:	str     	r1, [sp, #4]
0x005703:	movs    	r1, #0x11
0x005705:	movs    	r3, #4
0x005707:	movs    	r0, #0xf1
0x005709:	lsls    	r0, r0, #9
0x00570b:	bl      	#0x4c2d
; block 0x570f
0x00570f:	adds    	r6, r0, #0
0x005711:	movs    	r4, #0
0x005713:	cmp     	r0, #0
0x005715:	ble     	#0x5727
; block 0x5717
0x005717:	ldr     	r0, [r5, #0xc]
0x005719:	lsls    	r1, r4, #2
0x00571b:	ldr     	r0, [r0, r1]
0x00571d:	bl      	#0x5669
; block 0x5721
0x005721:	adds    	r4, #1
0x005723:	cmp     	r4, r6
0x005725:	blt     	#0x5717
; block 0x5727
0x005727:	movs    	r1, #0
0x005729:	str     	r1, [sp]
0x00572b:	str     	r1, [sp, #4]
0x00572d:	movs    	r2, #0
0x00572f:	str     	r2, [sp, #8]
0x005731:	movs    	r1, #9
0x005733:	adds    	r3, r7, #0
0x005735:	movs    	r0, #0xf1
0x005737:	lsls    	r0, r0, #9
0x005739:	ldr     	r2, [r5, #0xc]
0x00573b:	bl      	#0x4c2d
; block 0x573f
0x00573f:	movs    	r1, #0
0x005741:	movs    	r2, #0
0x005743:	str     	r2, [sp, #8]
0x005745:	str     	r1, [sp]
0x005747:	str     	r1, [sp, #4]
0x005749:	adds    	r3, r7, #0
0x00574b:	adds    	r2, r5, #0
0x00574d:	movs    	r1, #9
0x00574f:	movs    	r0, #0xf1
0x005751:	lsls    	r0, r0, #9
0x005753:	bl      	#0x4c2d
; block 0x5757
0x005757:	add     	sp, #0xc
0x005759:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_575d @ 0x575d offset=0x575c size=110 blocks=8 cc=6 =====
; block 0x575d
0x00575d:	push    	{r4, r5, r6, r7, lr}
0x00575f:	sub     	sp, #0xc
0x005761:	adds    	r5, r0, #0
0x005763:	beq     	#0x57c7
; block 0x5765
0x005765:	movs    	r1, #0
0x005767:	str     	r1, [sp]
0x005769:	str     	r1, [sp, #4]
0x00576b:	movs    	r2, #0
0x00576d:	movs    	r7, #0xf1
0x00576f:	lsls    	r7, r7, #9
0x005771:	str     	r2, [sp, #8]
0x005773:	movs    	r1, #0x11
0x005775:	movs    	r3, #4
0x005777:	adds    	r0, r7, #0
0x005779:	ldr     	r2, [r5]
0x00577b:	bl      	#0x4c2d
; block 0x577f
0x00577f:	adds    	r6, r0, #0
0x005781:	movs    	r4, #0
0x005783:	cmp     	r0, #0
0x005785:	ble     	#0x5797
; block 0x5787
0x005787:	ldr     	r0, [r5]
0x005789:	lsls    	r1, r4, #2
0x00578b:	ldr     	r0, [r0, r1]
0x00578d:	bl      	#0x56c9
; block 0x5791
0x005791:	adds    	r4, #1
0x005793:	cmp     	r4, r6
0x005795:	blt     	#0x5787
; block 0x5797
0x005797:	movs    	r1, #0
0x005799:	str     	r1, [sp]
0x00579b:	str     	r1, [sp, #4]
0x00579d:	movs    	r2, #0
0x00579f:	movs    	r4, #0
0x0057a1:	adds    	r3, r4, #0
0x0057a3:	str     	r2, [sp, #8]
0x0057a5:	movs    	r1, #9
0x0057a7:	adds    	r0, r7, #0
0x0057a9:	ldr     	r2, [r5]
0x0057ab:	bl      	#0x4c2d
; block 0x57af
0x0057af:	movs    	r1, #0
0x0057b1:	movs    	r2, #0
0x0057b3:	str     	r2, [sp, #8]
0x0057b5:	str     	r1, [sp]
0x0057b7:	str     	r1, [sp, #4]
0x0057b9:	adds    	r3, r4, #0
0x0057bb:	adds    	r2, r5, #0
0x0057bd:	movs    	r1, #9
0x0057bf:	movs    	r0, #0xf1
0x0057c1:	lsls    	r0, r0, #9
0x0057c3:	bl      	#0x4c2d
; block 0x57c7
0x0057c7:	add     	sp, #0xc
0x0057c9:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_57cd @ 0x57cd offset=0x57cc size=256 blocks=11 cc=10 =====
; block 0x57cd
0x0057cd:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0057cf:	sub     	sp, #0xc
0x0057d1:	movs    	r1, #0
0x0057d3:	movs    	r5, #0xff
0x0057d5:	movs    	r2, #0
0x0057d7:	movs    	r4, #0
0x0057d9:	adds    	r3, r4, #0
0x0057db:	str     	r2, [sp, #8]
0x0057dd:	adds    	r5, #0xa7
0x0057df:	str     	r1, [sp]
0x0057e1:	str     	r1, [sp, #4]
0x0057e3:	movs    	r1, #0x17
0x0057e5:	adds    	r2, r5, #0
0x0057e7:	movs    	r0, #0xf1
0x0057e9:	lsls    	r0, r0, #9
0x0057eb:	bl      	#0x4c2d
; block 0x57ef
0x0057ef:	movs    	r1, #0
0x0057f1:	movs    	r2, #0
0x0057f3:	str     	r2, [sp, #8]
0x0057f5:	str     	r1, [sp]
0x0057f7:	str     	r1, [sp, #4]
0x0057f9:	movs    	r1, #0xe1
0x0057fb:	movs    	r2, #0x1d
0x0057fd:	adds    	r3, r4, #0
0x0057ff:	movs    	r0, #0xf1
0x005801:	lsls    	r0, r0, #9
0x005803:	bl      	#0x4c2d
; block 0x5807
0x005807:	movs    	r1, #0
0x005809:	adds    	r6, r0, #0
0x00580b:	movs    	r2, #0
0x00580d:	str     	r2, [sp, #8]
0x00580f:	str     	r1, [sp]
0x005811:	str     	r1, [sp, #4]
0x005813:	movs    	r1, #0xe1
0x005815:	movs    	r2, #0x18
0x005817:	movs    	r0, #0xf1
0x005819:	adds    	r3, r4, #0
0x00581b:	lsls    	r0, r0, #9
0x00581d:	bl      	#0x4c2d
; block 0x5821
0x005821:	ldr     	r7, [r0, #0xc]
0x005823:	movs    	r1, #0
0x005825:	movs    	r2, #0
0x005827:	str     	r2, [sp, #8]
0x005829:	str     	r1, [sp]
0x00582b:	str     	r1, [sp, #4]
0x00582d:	movs    	r1, #0xe1
0x00582f:	movs    	r2, #0x18
0x005831:	movs    	r0, #0xf1
0x005833:	adds    	r3, r4, #0
0x005835:	lsls    	r0, r0, #9
0x005837:	bl      	#0x4c2d
; block 0x583b
0x00583b:	ldr     	r3, [r0, #8]
0x00583d:	movs    	r2, #0
0x00583f:	str     	r2, [sp, #8]
0x005841:	adds    	r2, r5, #0
0x005843:	movs    	r0, #0xf1
0x005845:	movs    	r1, #0x52
0x005847:	lsls    	r0, r0, #9
0x005849:	str     	r7, [sp]
0x00584b:	str     	r6, [sp, #4]
0x00584d:	bl      	#0x4c2d
; block 0x5851
0x005851:	movs    	r1, #0
0x005853:	movs    	r2, #0
0x005855:	str     	r1, [sp]
0x005857:	str     	r1, [sp, #4]
0x005859:	movs    	r1, #0x19
0x00585b:	str     	r2, [sp, #8]
0x00585d:	adds    	r3, r4, #0
0x00585f:	movs    	r0, #0xf1
0x005861:	lsls    	r0, r0, #9
0x005863:	ldr     	r2, [sp, #0xc]
0x005865:	bl      	#0x4c2d
; block 0x5869
0x005869:	movs    	r1, #0
0x00586b:	movs    	r2, #0
0x00586d:	str     	r1, [sp]
0x00586f:	str     	r1, [sp, #4]
0x005871:	movs    	r1, #0x19
0x005873:	str     	r2, [sp, #8]
0x005875:	adds    	r3, r4, #0
0x005877:	movs    	r0, #0xf1
0x005879:	lsls    	r0, r0, #9
0x00587b:	ldr     	r2, [sp, #0x10]
0x00587d:	bl      	#0x4c2d
; block 0x5881
0x005881:	movs    	r1, #0
0x005883:	movs    	r2, #0
0x005885:	str     	r1, [sp]
0x005887:	str     	r1, [sp, #4]
0x005889:	movs    	r1, #0x19
0x00588b:	str     	r2, [sp, #8]
0x00588d:	adds    	r3, r4, #0
0x00588f:	movs    	r0, #0xf1
0x005891:	lsls    	r0, r0, #9
0x005893:	ldr     	r2, [sp, #0x14]
0x005895:	bl      	#0x4c2d
; block 0x5899
0x005899:	movs    	r1, #0
0x00589b:	movs    	r2, #0
0x00589d:	str     	r1, [sp]
0x00589f:	str     	r1, [sp, #4]
0x0058a1:	movs    	r1, #0x19
0x0058a3:	str     	r2, [sp, #8]
0x0058a5:	adds    	r3, r4, #0
0x0058a7:	movs    	r0, #0xf1
0x0058a9:	lsls    	r0, r0, #9
0x0058ab:	ldr     	r2, [sp, #0x18]
0x0058ad:	bl      	#0x4c2d
; block 0x58b1
0x0058b1:	movs    	r1, #0
0x0058b3:	movs    	r2, #0
0x0058b5:	str     	r2, [sp, #8]
0x0058b7:	str     	r1, [sp]
0x0058b9:	str     	r1, [sp, #4]
0x0058bb:	movs    	r1, #0x1b
0x0058bd:	movs    	r2, #1
0x0058bf:	adds    	r3, r4, #0
0x0058c1:	movs    	r0, #0xf1
0x0058c3:	lsls    	r0, r0, #9
0x0058c5:	bl      	#0x4c2d
; block 0x58c9
0x0058c9:	add     	sp, #0x1c
0x0058cb:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_58cd @ 0x58cd offset=0x58cc size=208 blocks=9 cc=8 =====
; block 0x58cd
0x0058cd:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x0058cf:	sub     	sp, #0xc
0x0058d1:	movs    	r1, #0
0x0058d3:	movs    	r5, #0xff
0x0058d5:	movs    	r4, #0
0x0058d7:	movs    	r2, #0
0x0058d9:	str     	r2, [sp, #8]
0x0058db:	adds    	r3, r4, #0
0x0058dd:	adds    	r5, #0xb3
0x0058df:	str     	r1, [sp]
0x0058e1:	str     	r1, [sp, #4]
0x0058e3:	movs    	r1, #0x17
0x0058e5:	adds    	r2, r5, #0
0x0058e7:	movs    	r0, #0xf1
0x0058e9:	lsls    	r0, r0, #9
0x0058eb:	bl      	#0x4c2d
; block 0x58ef
0x0058ef:	movs    	r1, #0
0x0058f1:	movs    	r2, #0
0x0058f3:	str     	r2, [sp, #8]
0x0058f5:	str     	r1, [sp]
0x0058f7:	str     	r1, [sp, #4]
0x0058f9:	movs    	r1, #0xe1
0x0058fb:	movs    	r2, #0x1d
0x0058fd:	adds    	r3, r4, #0
0x0058ff:	movs    	r0, #0xf1
0x005901:	lsls    	r0, r0, #9
0x005903:	bl      	#0x4c2d
; block 0x5907
0x005907:	movs    	r1, #0
0x005909:	adds    	r6, r0, #0
0x00590b:	movs    	r2, #0
0x00590d:	str     	r2, [sp, #8]
0x00590f:	str     	r1, [sp]
0x005911:	str     	r1, [sp, #4]
0x005913:	movs    	r1, #0xe1
0x005915:	movs    	r2, #0x18
0x005917:	movs    	r0, #0xf1
0x005919:	adds    	r3, r4, #0
0x00591b:	lsls    	r0, r0, #9
0x00591d:	bl      	#0x4c2d
; block 0x5921
0x005921:	ldr     	r7, [r0, #0xc]
0x005923:	movs    	r1, #0
0x005925:	movs    	r2, #0
0x005927:	str     	r2, [sp, #8]
0x005929:	str     	r1, [sp]
0x00592b:	str     	r1, [sp, #4]
0x00592d:	movs    	r1, #0xe1
0x00592f:	movs    	r2, #0x18
0x005931:	movs    	r0, #0xf1
0x005933:	adds    	r3, r4, #0
0x005935:	lsls    	r0, r0, #9
0x005937:	bl      	#0x4c2d
; block 0x593b
0x00593b:	ldr     	r3, [r0, #8]
0x00593d:	movs    	r2, #0
0x00593f:	str     	r2, [sp, #8]
0x005941:	adds    	r2, r5, #0
0x005943:	movs    	r0, #0xf1
0x005945:	movs    	r1, #0x52
0x005947:	lsls    	r0, r0, #9
0x005949:	str     	r7, [sp]
0x00594b:	str     	r6, [sp, #4]
0x00594d:	bl      	#0x4c2d
; block 0x5951
0x005951:	movs    	r1, #0
0x005953:	movs    	r2, #0
0x005955:	str     	r1, [sp]
0x005957:	str     	r1, [sp, #4]
0x005959:	movs    	r1, #0x19
0x00595b:	str     	r2, [sp, #8]
0x00595d:	adds    	r3, r4, #0
0x00595f:	movs    	r0, #0xf1
0x005961:	lsls    	r0, r0, #9
0x005963:	ldr     	r2, [sp, #0xc]
0x005965:	bl      	#0x4c2d
; block 0x5969
0x005969:	movs    	r1, #0
0x00596b:	movs    	r2, #0
0x00596d:	str     	r1, [sp]
0x00596f:	str     	r1, [sp, #4]
0x005971:	movs    	r1, #0x19
0x005973:	str     	r2, [sp, #8]
0x005975:	adds    	r3, r4, #0
0x005977:	movs    	r0, #0xf1
0x005979:	lsls    	r0, r0, #9
0x00597b:	ldr     	r2, [sp, #0x10]
0x00597d:	bl      	#0x4c2d
; block 0x5981
0x005981:	movs    	r1, #0
0x005983:	movs    	r2, #0
0x005985:	str     	r2, [sp, #8]
0x005987:	str     	r1, [sp]
0x005989:	str     	r1, [sp, #4]
0x00598b:	movs    	r1, #0x1b
0x00598d:	movs    	r2, #1
0x00598f:	adds    	r3, r4, #0
0x005991:	movs    	r0, #0xf1
0x005993:	lsls    	r0, r0, #9
0x005995:	bl      	#0x4c2d
; block 0x5999
0x005999:	add     	sp, #0x14
0x00599b:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_599d @ 0x599d offset=0x599c size=148 blocks=11 cc=6 =====
; block 0x599d
0x00599d:	push    	{r4, r5, lr}
0x00599f:	ldr     	r5, [pc, #0x90]
0x0059a1:	ldr     	r2, [r0, #4]
0x0059a3:	add     	r5, sb
0x0059a5:	ldr     	r1, [r5, #0x4c]
0x0059a7:	movs    	r4, #0xf1
0x0059a9:	ldr     	r3, [r1]
0x0059ab:	lsls    	r4, r4, #9
0x0059ad:	cmp     	r2, r3
0x0059af:	sub     	sp, #0xc
0x0059b1:	beq     	#0x59e1
; block 0x59b3
0x0059b3:	movs    	r1, #0
0x0059b5:	str     	r1, [sp]
0x0059b7:	str     	r1, [sp, #4]
0x0059b9:	movs    	r2, #0
0x0059bb:	movs    	r1, #0xb1
0x0059bd:	adds    	r0, r4, #0
0x0059bf:	str     	r2, [sp, #8]
0x0059c1:	bl      	#0x4c2d
; block 0x59c5
0x0059c5:	movs    	r2, #0
0x0059c7:	adds    	r3, r0, #0
0x0059c9:	movs    	r1, #0
0x0059cb:	str     	r2, [sp, #8]
0x0059cd:	ldr     	r2, [pc, #0x64]
0x0059cf:	str     	r1, [sp]
0x0059d1:	str     	r1, [sp, #4]
0x0059d3:	add     	r2, pc
0x0059d5:	movs    	r1, #0x2d
0x0059d7:	adds    	r0, r4, #0
0x0059d9:	bl      	#0x4c2d
; block 0x59dd
0x0059dd:	add     	sp, #0xc
0x0059df:	pop     	{r4, r5, pc}
; block 0x59e1
0x0059e1:	movs    	r2, #0x24
0x0059e3:	ldrsb   	r2, [r2, r0]
0x0059e5:	adds    	r3, r5, #0
0x0059e7:	ldr     	r5, [r1, #4]
0x0059e9:	cmp     	r2, r5
0x0059eb:	beq     	#0x5a21
; block 0x59ed
0x0059ed:	movs    	r1, #0
0x0059ef:	str     	r1, [sp]
0x0059f1:	str     	r1, [sp, #4]
0x0059f3:	movs    	r2, #0
0x0059f5:	str     	r2, [sp, #8]
0x0059f7:	movs    	r1, #0xff
0x0059f9:	adds    	r1, #0x52
0x0059fb:	adds    	r2, r5, #0
0x0059fd:	movs    	r3, #0
0x0059ff:	adds    	r0, r4, #0
0x005a01:	bl      	#0x4c2d
; block 0x5a05
0x005a05:	movs    	r2, #0
0x005a07:	adds    	r3, r0, #0
0x005a09:	movs    	r1, #0
0x005a0b:	str     	r2, [sp, #8]
0x005a0d:	ldr     	r2, [pc, #0x28]
0x005a0f:	str     	r1, [sp]
0x005a11:	str     	r1, [sp, #4]
0x005a13:	add     	r2, pc
0x005a15:	movs    	r1, #0x2d
0x005a17:	movs    	r0, #0xf1
0x005a19:	lsls    	r0, r0, #9
0x005a1b:	bl      	#0x4c2d
; block 0x5a1f
0x005a1f:	b       	#0x59dd
; block 0x5a21
0x005a21:	str     	r0, [r3, #0x30]
0x005a23:	cmp     	r1, #0
0x005a25:	beq     	#0x5a2d
; block 0x5a27
0x005a27:	ldr     	r0, [r1, #8]
0x005a29:	adds    	r0, #1
0x005a2b:	str     	r0, [r1, #8]
0x005a2d:	movs    	r0, #0
0x005a2f:	b       	#0x59dd
; block 0x5a2d
0x005a2d:	movs    	r0, #0
0x005a2f:	b       	#0x59dd

; ===== sub_5a30 @ 0x5a30 offset=0x5a30 size=16 blocks=1 cc=1 =====
; block 0x5a30
0x005a30:	andeq   	r0, r0, r4
0x005a34:	andeq   	r0, r0, r6, lsl #5
0x005a38:	andeq   	r0, r0, r2, asr r2
0x005a3c:	svcmi   	#0x3fb5f0

; ===== sub_5a4c @ 0x5a4c offset=0x5a4c size=4 blocks=1 cc=1 =====
; block 0x5a4c
0x005a4c:	blle    	#0xd64d8

; ===== sub_5a6e @ 0x5a6e offset=0x5a6e size=4 blocks=1 cc=1 =====
; block 0x5a6e

; ===== sub_5b2a @ 0x5b2a offset=0x5b2a size=4 blocks=1 cc=1 =====
; block 0x5b2a

; ===== sub_5b54 @ 0x5b54 offset=0x5b54 size=4 blocks=1 cc=1 =====
; block 0x5b54
0x005b54:	svclt   	#0xc1dcc4

; ===== sub_5b5b @ 0x5b5b offset=0x5b5a size=4 blocks=1 cc=1 =====
; block 0x5b5b
0x005b5b:	movs    	r0, r0
0x005b5d:	b       	#0x62cb

; ===== sub_5b5f @ 0x5b5f offset=0x5b5e size=8 blocks=1 cc=1 =====
; block 0x5b5f
0x005b5f:	add     	r7, sp, #0x320
0x005b61:	movs    	r0, r0
0x005b63:	movs    	r0, r0
0x005b65:	pop     	{r0, r2, r4, r6, r7, pc}

; ===== sub_5b67 @ 0x5b67 offset=0x5b66 size=10 blocks=1 cc=1 =====
; block 0x5b67
0x005b67:	add     	r0, sp, #0x2f0
0x005b69:	movs    	r0, r0
0x005b6b:	movs    	r0, r0
0x005b6d:	cbz     	r1, #0x5b9f
0x005b6f:	bvc     	#0x5b11

; ===== sub_5b71 @ 0x5b71 offset=0x5b70 size=20 blocks=1 cc=1 =====
; block 0x5b71
0x005b71:	push    	{r1, r2, r4, r6, r7, lr}
0x005b73:	movs    	r0, r0
0x005b75:	ldm     	r7, {r1, r3, r4, r5, r7}
0x005b77:	ldm     	r1, {r0, r1, r4, r5, r7}
0x005b79:	movs    	r0, r4
0x005b7b:	movs    	r0, r0
0x005b7d:	movs    	r0, r0
0x005b7f:	movs    	r0, r0
0x005b81:	stm     	r6!, {r5}
0x005b83:	bvs     	#0x5af5

; ===== sub_5ba3 @ 0x5ba3 offset=0x5ba2 size=4 blocks=1 cc=1 =====
; block 0x5ba3
0x005ba3:	blx     	#0x9bdb18

; ===== sub_5bbc @ 0x5bbc offset=0x5bbc size=8 blocks=1 cc=1 =====
; block 0x5bbc
0x005bbc:	andeq   	r2, r0, sl, lsr r0
0x005bc0:	bge     	#0xff4bff08

; ===== sub_5bc9 @ 0x5bc9 offset=0x5bc8 size=2 blocks=1 cc=1 =====
; block 0x5bc9
0x005bc9:	adr     	r1, #0x344
0x005bcb:	blx     	#0x9dab40

; ===== sub_5bcb @ 0x5bcb offset=0x5bca size=4 blocks=1 cc=1 =====
; block 0x5bcb
0x005bcb:	blx     	#0x9dab40

; ===== sub_5bef @ 0x5bef offset=0x5bee size=12 blocks=1 cc=1 =====
; block 0x5bef
0x005bef:	ldm     	r7, {r0, r6, r7}
0x005bf1:	cbnz    	r2, #0x5c61
0x005bf3:	cbnz    	r1, #0x5c65
0x005bf5:	add     	r4, sp, #0x28c
0x005bf7:	cbnz    	r2, #0x5c67
0x005bf9:	bgt     	#0x5b85

; ===== sub_5c08 @ 0x5c08 offset=0x5c08 size=12 blocks=2 cc=1 =====
; block 0x5c08
0x005c08:	bllt    	#0xfee74ad8
; block 0x5c0c
0x005c0c:	strbgt  	fp, [sb, r1, lsr #30]
0x005c10:	ldmibgt 	sb!, {r4, r5, r7, r8, sl, fp, lr, pc} ^

; ===== sub_5c24 @ 0x5c24 offset=0x5c24 size=4 blocks=1 cc=1 =====
; block 0x5c24
0x005c24:	svclt   	#0xc1dcc4

; ===== sub_5c2d @ 0x5c2d offset=0x5c2c size=4 blocks=1 cc=1 =====
; block 0x5c2d
0x005c2d:	cbnz    	r1, #0x5c9f
0x005c2f:	adr     	r1, #0x28c

; ===== sub_5c33 @ 0x5c33 offset=0x5c32 size=4 blocks=1 cc=1 =====
; block 0x5c33
0x005c33:	ldm     	r0, {r0, r1, r2, r3, r6, r7}
0x005c35:	b       	#0x559f

; ===== sub_5c3f @ 0x5c3f offset=0x5c3e size=4 blocks=1 cc=1 =====
; block 0x5c3f
0x005c3f:	b.w     	#0x5bdbd3

; ===== sub_5c43 @ 0x5c43 offset=0x5c42 size=66 blocks=2 cc=1 =====
; block 0x5c43
0x005c43:	add     	r0, sp, #0x2d8
0x005c45:	stm     	r3!, {r2, r6, r7}
0x005c47:	b       	#0x61f5
; block 0x61f5
0x0061f5:	str     	r1, [r5, #0x74]
0x0061f7:	str     	r6, [r5, #0x14]
0x0061f9:	movs    	r0, #0x6c
0x0061fb:	movs    	r2, r6
0x0061fd:	str     	r0, [r0, r0]
0x0061ff:	strb    	r5, [r6, #9]
0x006201:	movs    	r0, #0x65
0x006203:	ldr     	r6, [r6, #0x14]
0x006205:	strb    	r2, [r6, #0x11]
0x006207:	str     	r5, [r6, #0x14]
0x006209:	movs    	r0, #0x6c
0x00620b:	ldr     	r6, [r4, #0x64]
0x00620d:	str     	r0, [r4, #0x30]
0x00620f:	ldr     	r1, [r4, #0x44]
0x006211:	str     	r4, [r5, #0x54]
0x006213:	lsls    	r4, r4, #1
0x006215:	cmp     	r3, #0x43
0x006217:	movs    	r0, #0x2b
0x006219:	ldr     	r4, [r5, #0x14]
0x00621b:	strb    	r2, [r4, #9]
0x00621d:	strb    	r1, [r4, #9]
0x00621f:	movs    	r0, #0x79
0x006221:	ldrb    	r5, [r4, #1]
0x006223:	str     	r3, [r4, #0x54]
0x006225:	strb    	r0, [r6, #0x11]
0x006227:	ldr     	r1, [r5, #0x74]
0x006229:	lsls    	r6, r5, #1
0x00622b:	movs    	r0, r0
0x00622d:	movs    	r0, r0
0x00622f:	movs    	r0, r0

; ===== sub_5c4f @ 0x5c4f offset=0x5c4e size=16 blocks=1 cc=1 =====
; block 0x5c4f
0x005c4f:	ldrh.w  	sp, [sp, #0xd0]
0x005c53:	ldm     	r7, {r1, r3, r4, r5, r7}
0x005c55:	ldm     	r1, {r0, r1, r4, r5, r7}
0x005c57:	cmp     	r5, #0x2d
0x005c59:	movs    	r5, r5
0x005c5b:	movs    	r0, r0
0x005c5d:	cbnz    	r2, #0x5ccd

; ===== sub_5c65 @ 0x5c65 offset=0x5c64 size=6 blocks=1 cc=1 =====
; block 0x5c65
0x005c65:	movs    	r0, r4
0x005c67:	movs    	r0, r0
0x005c69:	cbnz    	r2, #0x5cd9

; ===== UnresolvableJumpTarget @ 0x100014 offset=0x100014 size=0 blocks=1 cc=1 =====
; block 0x100014
0x100014:	andeq   	r0, r0, r0

; ===== UnresolvableCallTarget @ 0x100018 offset=0x100018 size=0 blocks=1 cc=1 =====
; block 0x100018
0x100018:	andeq   	r0, r0, r0
0x10001c:	andeq   	r0, r0, r0
0x100020:	andeq   	r0, r0, r0
0x100024:	andeq   	r0, r0, r0
0x100028:	andeq   	r0, r0, r0
0x10002c:	andeq   	r0, r0, r0
0x100030:	andeq   	r0, r0, r0
0x100034:	andeq   	r0, r0, r0
0x100038:	andeq   	r0, r0, r0
0x10003c:	andeq   	r0, r0, r0
0x100040:	andeq   	r0, r0, r0
0x100044:	andeq   	r0, r0, r0
0x100048:	andeq   	r0, r0, r0
0x10004c:	andeq   	r0, r0, r0
0x100050:	andeq   	r0, r0, r0
0x100054:	andeq   	r0, r0, r0
0x100058:	andeq   	r0, r0, r0
0x10005c:	andeq   	r0, r0, r0
0x100060:	andeq   	r0, r0, r0
0x100064:	andeq   	r0, r0, r0
0x100068:	andeq   	r0, r0, r0
0x10006c:	andeq   	r0, r0, r0
0x100070:	andeq   	r0, r0, r0
0x100074:	andeq   	r0, r0, r0
0x100078:	andeq   	r0, r0, r0
0x10007c:	andeq   	r0, r0, r0
0x100080:	andeq   	r0, r0, r0
0x100084:	andeq   	r0, r0, r0
0x100088:	andeq   	r0, r0, r0
0x10008c:	andeq   	r0, r0, r0
0x100090:	andeq   	r0, r0, r0
0x100094:	andeq   	r0, r0, r0
0x100098:	andeq   	r0, r0, r0
0x10009c:	andeq   	r0, r0, r0
0x1000a0:	andeq   	r0, r0, r0
0x1000a4:	andeq   	r0, r0, r0
0x1000a8:	andeq   	r0, r0, r0
0x1000ac:	andeq   	r0, r0, r0
0x1000b0:	andeq   	r0, r0, r0
0x1000b4:	andeq   	r0, r0, r0
0x1000b8:	andeq   	r0, r0, r0
0x1000bc:	andeq   	r0, r0, r0
0x1000c0:	andeq   	r0, r0, r0
0x1000c4:	andeq   	r0, r0, r0
0x1000c8:	andeq   	r0, r0, r0
0x1000cc:	andeq   	r0, r0, r0
0x1000d0:	andeq   	r0, r0, r0
0x1000d4:	andeq   	r0, r0, r0
0x1000d8:	andeq   	r0, r0, r0
0x1000dc:	andeq   	r0, r0, r0
0x1000e0:	andeq   	r0, r0, r0
0x1000e4:	andeq   	r0, r0, r0
0x1000e8:	andeq   	r0, r0, r0
0x1000ec:	andeq   	r0, r0, r0
0x1000f0:	andeq   	r0, r0, r0
0x1000f4:	andeq   	r0, r0, r0
0x1000f8:	andeq   	r0, r0, r0
0x1000fc:	andeq   	r0, r0, r0
0x100100:	andeq   	r0, r0, r0
0x100104:	andeq   	r0, r0, r0
0x100108:	andeq   	r0, r0, r0
0x10010c:	andeq   	r0, r0, r0
0x100110:	andeq   	r0, r0, r0
0x100114:	andeq   	r0, r0, r0
0x100118:	andeq   	r0, r0, r0
0x10011c:	andeq   	r0, r0, r0
0x100120:	andeq   	r0, r0, r0
0x100124:	andeq   	r0, r0, r0
0x100128:	andeq   	r0, r0, r0
0x10012c:	andeq   	r0, r0, r0
0x100130:	andeq   	r0, r0, r0
0x100134:	andeq   	r0, r0, r0
0x100138:	andeq   	r0, r0, r0
0x10013c:	andeq   	r0, r0, r0
0x100140:	andeq   	r0, r0, r0
0x100144:	andeq   	r0, r0, r0
0x100148:	andeq   	r0, r0, r0
0x10014c:	andeq   	r0, r0, r0
0x100150:	andeq   	r0, r0, r0
0x100154:	andeq   	r0, r0, r0
0x100158:	andeq   	r0, r0, r0
0x10015c:	andeq   	r0, r0, r0
0x100160:	andeq   	r0, r0, r0
0x100164:	andeq   	r0, r0, r0
0x100168:	andeq   	r0, r0, r0
0x10016c:	andeq   	r0, r0, r0
0x100170:	andeq   	r0, r0, r0
0x100174:	andeq   	r0, r0, r0
0x100178:	andeq   	r0, r0, r0
0x10017c:	andeq   	r0, r0, r0
0x100180:	andeq   	r0, r0, r0
0x100184:	andeq   	r0, r0, r0
0x100188:	andeq   	r0, r0, r0
0x10018c:	andeq   	r0, r0, r0
0x100190:	andeq   	r0, r0, r0
0x100194:	andeq   	r0, r0, r0
0x100198:	andeq   	r0, r0, r0
0x10019c:	andeq   	r0, r0, r0
0x1001a0:	andeq   	r0, r0, r0
