; fallback candidate disassembly from Thumb prologues; true code is ARM entry + Thumb functions.

; ARM entry
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0x904c
0x000018:	pop     	{r4, pc}
0x00001c:	andeq   	r4, r0, r8, ror r7
0x000020:	ands    	r2, r0, #128, #8
0x000024:	rsbmi   	r0, r0, #0
0x000028:	eors    	r3, r2, r1, asr #32
0x00002c:	rsbhs   	r1, r1, #0
0x000030:	rsbs    	ip, r0, r1, lsr #3
0x000034:	blo     	#0xbc
0x000038:	rsbs    	ip, r0, r1, lsr #8
0x00003c:	blo     	#0x80
0x000040:	lsl     	r0, r0, #8
0x000044:	orr     	r2, r2, #0xff000000
0x000048:	rsbs    	ip, r0, r1, lsr #4
0x00004c:	blo     	#0xb0
0x000050:	rsbs    	ip, r0, r1, lsr #8
0x000054:	blo     	#0x80
0x000058:	lsl     	r0, r0, #8
0x00005c:	orr     	r2, r2, #0xff0000
0x000060:	rsbs    	ip, r0, r1, lsr #8
0x000064:	lslhs   	r0, r0, #8
0x000068:	orrhs   	r2, r2, #0xff00
0x00006c:	rsbs    	ip, r0, r1, lsr #4
0x000070:	blo     	#0xb0
0x000074:	rsbs    	ip, r0, #0
0x000078:	bhs     	#0xf8
0x00007c:	lsrhs   	r0, r0, #8
0x000080:	rsbs    	ip, r0, r1, lsr #7
0x000084:	subhs   	r1, r1, r0, lsl #7
0x000088:	adc     	r2, r2, r2
0x00008c:	rsbs    	ip, r0, r1, lsr #6
0x000090:	subhs   	r1, r1, r0, lsl #6
0x000094:	adc     	r2, r2, r2
0x000098:	rsbs    	ip, r0, r1, lsr #5
0x00009c:	subhs   	r1, r1, r0, lsl #5
0x0000a0:	adc     	r2, r2, r2
0x0000a4:	rsbs    	ip, r0, r1, lsr #4
0x0000a8:	subhs   	r1, r1, r0, lsl #4
0x0000ac:	adc     	r2, r2, r2
0x0000b0:	rsbs    	ip, r0, r1, lsr #3
0x0000b4:	subhs   	r1, r1, r0, lsl #3
0x0000b8:	adc     	r2, r2, r2
0x0000bc:	rsbs    	ip, r0, r1, lsr #2
0x0000c0:	subhs   	r1, r1, r0, lsl #2
0x0000c4:	adc     	r2, r2, r2
0x0000c8:	rsbs    	ip, r0, r1, lsr #1
0x0000cc:	subhs   	r1, r1, r0, lsl #1
0x0000d0:	adc     	r2, r2, r2
0x0000d4:	rsbs    	ip, r0, r1
0x0000d8:	subhs   	r1, r1, r0
0x0000dc:	adcs    	r2, r2, r2
0x0000e0:	bhs     	#0x7c
0x0000e4:	eors    	r0, r2, r3, asr #31
0x0000e8:	add     	r0, r0, r3, lsr #31
0x0000ec:	rsbhs   	r1, r1, #0
0x0000f0:	bx      	lr
0x0000f4:	andeq   	r4, r0, r8, ror r7
0x0000f8:	mov     	r0, #2
0x0000fc:	mov     	r1, #2
0x000100:	b       	#0x118
0x000104:	strmi   	r4, [r8, -r0, lsl #14]

; ===== candidate_000008 =====
0x000008:	ands    	r0, r2
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	movs    	r4, #0xc

; ===== candidate_00000a =====
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	movs    	r4, #0xc

; ===== candidate_00011a =====
0x00011a:	stmdb   	sp!, {r2}

; ===== candidate_000134 =====
0x000134:	push    	{r4, r5, r6, lr}
0x000136:	ldr     	r6, [pc, #0x38]
0x000138:	adds    	r5, r1, #0
0x00013a:	adds    	r1, r0, #0
0x00013c:	adds    	r4, r0, #0
0x00013e:	add     	r6, pc
0x000140:	adds    	r0, r6, #0
0x000142:	bl      	#0x146
0x000146:	adds    	r2, r0, #0
0x000148:	cmp     	r0, r6
0x00014a:	bne     	#0x15a
0x00014c:	adds    	r1, r5, #0
0x00014e:	adds    	r0, r4, #0
0x000150:	bl      	#0x194
0x000154:	pop     	{r4, r5, r6}
0x000156:	pop     	{r3}
0x000158:	bx      	r3
0x00015a:	ldr     	r0, [pc, #0x18]
0x00015c:	add     	r0, pc
0x00015e:	cmp     	r2, r0
0x000160:	beq     	#0x16a
0x000162:	adds    	r1, r5, #0
0x000164:	adds    	r0, r4, #0
0x000166:	bl      	#0x108
0x00016a:	movs    	r0, #0
0x00016c:	b       	#0x154
0x00016e:	movs    	r0, r0
0x000170:	mcr2    	p15, #6, pc, c5, c7, #7
0x000174:	mcr2    	p15, #5, pc, c5, c7, #7
0x000178:	bx      	pc

; ===== candidate_000194 =====
0x000194:	push    	{r3, r4, r5, lr}
0x000196:	subs    	r2, r0, #1
0x000198:	cmp     	r2, #0xd
0x00019a:	adr     	r4, #0x90
0x00019c:	bhs     	#0x1ec
0x00019e:	movs    	r2, #0x17
0x0001a0:	ldr     	r3, [pc, #0x8c]
0x0001a2:	muls    	r2, r0, r2
0x0001a4:	add     	r3, pc
0x0001a6:	adds    	r5, r2, r3
0x0001a8:	subs    	r5, #0x17
0x0001aa:	cmp     	r0, #2
0x0001ac:	bne     	#0x1d8
0x0001ae:	lsls    	r0, r1, #5
0x0001b0:	bpl     	#0x1b6
0x0001b2:	adr     	r4, #0x80
0x0001b4:	b       	#0x1ee
0x0001b6:	ldr     	r0, [pc, #0x90]
0x0001b8:	ands    	r0, r1
0x0001ba:	beq     	#0x1c0
0x0001bc:	adr     	r4, #0x8c
0x0001be:	b       	#0x1ee
0x0001c0:	lsls    	r0, r1, #3
0x0001c2:	bpl     	#0x1c8
0x0001c4:	adr     	r4, #0x94
0x0001c6:	b       	#0x1ee
0x0001c8:	lsls    	r0, r1, #2
0x0001ca:	bpl     	#0x1d0
0x0001cc:	adr     	r4, #0x98
0x0001ce:	b       	#0x1ee
0x0001d0:	lsls    	r0, r1, #1
0x0001d2:	bpl     	#0x1ee
0x0001d4:	adr     	r4, #0x9c
0x0001d6:	b       	#0x1ee
0x0001d8:	cmp     	r0, #8
0x0001da:	bne     	#0x1e0
0x0001dc:	adds    	r4, r1, #0
0x0001de:	b       	#0x1ee
0x0001e0:	cmp     	r0, #9
0x0001e2:	bne     	#0x1ee
0x0001e4:	cmp     	r1, #1
0x0001e6:	bne     	#0x1ee
0x0001e8:	adr     	r5, #0x98
0x0001ea:	b       	#0x1ee
0x0001ec:	adr     	r5, #0xac
0x0001ee:	movs    	r0, #0xa
0x0001f0:	bl      	#0x2b4
0x0001f4:	ldrb    	r0, [r5]
0x0001f6:	cmp     	r0, #0
0x0001f8:	beq     	#0x208
0x0001fa:	ldrb    	r0, [r5]
0x0001fc:	adds    	r5, #1
0x0001fe:	bl      	#0x2b4
0x000202:	ldrb    	r0, [r5]
0x000204:	cmp     	r0, #0
0x000206:	bne     	#0x1fa
0x000208:	ldrb    	r0, [r4]
0x00020a:	cmp     	r0, #0
0x00020c:	beq     	#0x21c
0x00020e:	ldrb    	r0, [r4]
0x000210:	adds    	r4, #1
0x000212:	bl      	#0x2b4
0x000216:	ldrb    	r0, [r4]
0x000218:	cmp     	r0, #0
0x00021a:	bne     	#0x20e
0x00021c:	movs    	r0, #0xa
0x00021e:	bl      	#0x2b4
0x000222:	pop     	{r3, r4, r5}
0x000224:	pop     	{r3}
0x000226:	movs    	r0, #1
0x000228:	bx      	r3
0x00022a:	movs    	r0, r0
0x00022c:	movs    	r0, r0
0x00022e:	movs    	r0, r0
0x000230:	cbz     	r0, #0x296
0x000232:	movs    	r0, r0
0x000234:	ldr     	r1, [r1, #0x64]
0x000236:	str     	r6, [r6, #0x14]
0x000238:	ldr     	r4, [r5, #0x14]
0x00023a:	movs    	r0, #0x64
0x00023c:	strb    	r7, [r1, #1]
0x00023e:	strb    	r5, [r4, #9]
0x000240:	strb    	r1, [r4, #0x11]
0x000242:	ldr     	r1, [r5, #0x74]
0x000244:	lsls    	r6, r5, #1
0x000246:	movs    	r0, r0
0x000248:	movs    	r2, r0
0x00024a:	lsrs    	r0, r0, #0x20
0x00024c:	ldr     	r4, [r0, #0x14]
0x00024e:	ldr     	r6, [r6, #0x14]
0x000250:	str     	r4, [r4, #0x54]
0x000252:	tst     	r0, r4
0x000254:	movs    	r0, #0x79
0x000256:	str     	r2, [r3, #0x54]
0x000258:	ldr     	r2, [r6, #0x74]
0x00025a:	movs    	r0, r0
0x00025c:	strb    	r7, [r1, #0x19]
0x00025e:	strb    	r5, [r4, #9]
0x000260:	ldr     	r6, [r4, #0x44]
0x000262:	strb    	r7, [r5, #0x1d]
0x000264:	movs    	r0, r0
0x000266:	movs    	r0, r0
0x000268:	ldr     	r5, [r2, #0x64]
0x00026a:	str     	r4, [r4, #0x54]
0x00026c:	str     	r2, [r6, #0x64]
0x00026e:	ldr     	r4, [r5, #0x74]
0x000270:	lsls    	r7, r6, #1
0x000272:	movs    	r0, r0
0x000274:	ldr     	r1, [r1, #0x64]
0x000276:	ldrb    	r5, [r4, #1]
0x000278:	str     	r1, [r4, #0x34]
0x00027a:	movs    	r0, #0x74
0x00027c:	str     	r2, [r2, #0x54]
0x00027e:	strb    	r3, [r6, #0x15]
0x000280:	strb    	r4, [r5, #0x11]
0x000282:	movs    	r0, r0
0x000284:	movs    	r0, #0x3a
0x000286:	str     	r0, [r1, #0x54]
0x000288:	strb    	r1, [r4, #1]
0x00028a:	ldr     	r0, [r4, #0x50]
0x00028c:	ldr     	r5, [r4, #0x54]
0x00028e:	strb    	r7, [r5, #9]
0x000290:	movs    	r0, #0x79
0x000292:	ldr     	r3, [r4, #0x74]
0x000294:	strb    	r2, [r6, #9]
0x000296:	strb    	r5, [r6, #1]
0x000298:	str     	r4, [r6, #0x54]
0x00029a:	lsls    	r4, r4, #1
0x00029c:	ldr     	r5, [r2, #0x64]
0x00029e:	ldr     	r3, [r5, #0x64]
0x0002a0:	strb    	r7, [r5, #0x1d]
0x0002a2:	movs    	r0, #0x6e
0x0002a4:	ldr     	r3, [r6, #0x14]
0x0002a6:	ldr     	r7, [r4, #0x64]
0x0002a8:	ldr     	r1, [r4, #0x44]
0x0002aa:	movs    	r0, r0
0x0002ac:	bx      	pc

; ===== candidate_0002b4 =====
0x0002b4:	push    	{r3, lr}
0x0002b6:	add     	r3, sp, #0
0x0002b8:	strb    	r0, [r3]
0x0002ba:	movs    	r0, #3
0x0002bc:	mov     	r1, sp
0x0002be:	svc     	#0xab
0x0002c0:	add     	sp, #4
0x0002c2:	pop     	{r3}
0x0002c4:	bx      	r3
0x0002c6:	movs    	r0, r0
0x0002c8:	movs    	r0, r1
0x0002ca:	b       	#0xfffffe0c
0x0002cc:	asrs    	r0, r1, #0x20
0x0002ce:	b       	#0xfffffe10
0x0002d0:	movs    	r1, r0
0x0002d2:	b       	#0x3d6
0x0002d4:	vrhadd.u16	d14, d14, d31
0x0002d8:	movs    	r0, r3
0x0002da:	movs    	r0, r0
0x0002dc:	lsls    	r4, r5, #8
0x0002de:	movs    	r0, r0
0x0002e0:	str     	r0, [sp]
0x0002e2:	b       	#0x626
0x0002e4:	vrhadd.u16	d14, d14, d31
0x0002e8:	adds    	r0, #0x14
0x0002ea:	b       	#0xfffffe2c
0x0002ec:	cmp     	r7, #0xc0
0x0002ee:	b       	#0x632
0x0002f0:	stm     	r0!, {r0, r1, r4, r7}
0x0002f2:	b       	#0x478
0x0002f4:	adds    	r0, #2
0x0002f6:	b       	#0xaba
0x0002f8:	asrs    	r1, r0, #0x20
0x0002fa:	b       	#0x3c2
0x0002fc:	lsls    	r3, r2, #6
0x0002fe:	b       	#0x342
0x000300:	vrhadd.u16	d14, d14, d31
0x000304:	strb    	r6, [r2, r5]
0x000306:	strb    	r5, [r2, r5]
0x000308:	adds    	r0, #0x14
0x00030a:	b       	#0xfffffe4c
0x00030c:	cmp     	r7, #0xc0
0x00030e:	b       	#0x652
0x000310:	stm     	r0!, {r0, r1, r4, r7}
0x000312:	b       	#0x498
0x000314:	adds    	r0, #5
0x000316:	b       	#0xada
0x000318:	asrs    	r1, r0, #0x20
0x00031a:	b       	#0x3e2
0x00031c:	lsls    	r3, r2, #6
0x00031e:	b       	#0x362
0x000320:	vrhadd.u16	d14, d14, d31
0x000324:	add     	r2, sp, #0x2ac
0x000326:	cmp     	r2, #0xaa
0x000328:	push    	{r4, r5, lr}
0x00032a:	ldr     	r4, [pc, #0xb4]
0x00032c:	movs    	r2, #0x1c
0x00032e:	add     	r4, pc
0x000330:	ldr     	r0, [r4, #0x38]
0x000332:	movs    	r1, #0
0x000334:	ldr     	r3, [r0, #0x38]
0x000336:	ldr     	r0, [pc, #0xac]
0x000338:	sub     	sp, #0xc
0x00033a:	add     	r0, sb
0x00033c:	blx     	r3
0x00033e:	movs    	r2, #0
0x000340:	movs    	r0, #0
0x000342:	str     	r0, [sp]
0x000344:	ldr     	r1, [pc, #0x9c]
0x000346:	movs    	r3, #0
0x000348:	add     	r1, sb
0x00034a:	str     	r1, [sp, #4]
0x00034c:	movs    	r1, #0x64
0x00034e:	movs    	r0, #1
0x000350:	str     	r2, [sp, #8]
0x000352:	bl      	#0x9124
0x000356:	ldr     	r1, [pc, #0x8c]
0x000358:	movs    	r0, #0
0x00035a:	add     	r1, sb
0x00035c:	subs    	r1, #0x7c
0x00035e:	str     	r0, [r1, #8]
0x000360:	ldr     	r5, [pc, #0x80]
0x000362:	str     	r0, [r1, #0x10]
0x000364:	str     	r0, [r1, #0xc]
0x000366:	add     	r5, sb
0x000368:	subs    	r5, #0xfc
0x00036a:	movs    	r0, #1
0x00036c:	str     	r0, [r5, #0x18]
0x00036e:	ldr     	r0, [r4, #0x38]
0x000370:	ldr     	r2, [pc, #0x74]
0x000372:	ldr     	r1, [r0, #0x68]
0x000374:	add     	r2, sb
0x000376:	str     	r1, [r5, #0x2c]
0x000378:	ldr     	r1, [r0, #0xc]
0x00037a:	ldr     	r4, [pc, #0x70]
0x00037c:	str     	r1, [r5, #0x30]
0x00037e:	ldr     	r1, [r0, #0x10]
0x000380:	str     	r1, [r5, #0x34]
0x000382:	ldr     	r1, [r0, #0x14]
0x000384:	str     	r1, [r5, #0x38]
0x000386:	ldr     	r1, [r0, #0x18]
0x000388:	str     	r1, [r5, #0x3c]
0x00038a:	ldr     	r1, [r0, #0x1c]
0x00038c:	str     	r1, [r5, #0x40]
0x00038e:	ldr     	r1, [r0, #0x20]
0x000390:	str     	r1, [r5, #0x44]
0x000392:	ldr     	r1, [r0, #0x24]
0x000394:	str     	r1, [r5, #0x48]
0x000396:	ldr     	r1, [r0, #0x28]
0x000398:	str     	r1, [r5, #0x4c]
0x00039a:	ldr     	r1, [r0, #0x2c]
0x00039c:	str     	r1, [r5, #0x50]
0x00039e:	ldr     	r1, [r0, #0x30]
0x0003a0:	str     	r1, [r5, #0x54]
0x0003a2:	ldr     	r1, [r0, #0x34]
0x0003a4:	str     	r1, [r5, #0x58]
0x0003a6:	ldr     	r1, [r0, #0x38]
0x0003a8:	str     	r1, [r5, #0x5c]
0x0003aa:	ldr     	r1, [r0, #0x3c]
0x0003ac:	str     	r1, [r5, #0x60]
0x0003ae:	ldr     	r1, [r0, #0x40]
0x0003b0:	str     	r1, [r5, #0x64]
0x0003b2:	ldr     	r1, [r0, #0x44]
0x0003b4:	str     	r1, [r5, #0x68]
0x0003b6:	ldr     	r1, [r0, #0x48]
0x0003b8:	str     	r1, [r5, #0x6c]
0x0003ba:	ldr     	r1, [r0, #0x4c]
0x0003bc:	str     	r1, [r5, #0x70]
0x0003be:	movs    	r1, #0
0x0003c0:	str     	r1, [r2]
0x0003c2:	movs    	r1, #1
0x0003c4:	lsls    	r1, r1, #9
0x0003c6:	adds    	r0, r0, r1
0x0003c8:	ldr     	r3, [r0, #8]
0x0003ca:	movs    	r1, #7
0x0003cc:	adds    	r2, r4, #0
0x0003ce:	movs    	r0, #0
0x0003d0:	blx     	r3
0x0003d2:	cmp     	r0, r4
0x0003d4:	bne     	#0x3da
0x0003d6:	subs    	r0, #2

; ===== candidate_000328 =====
0x000328:	push    	{r4, r5, lr}
0x00032a:	ldr     	r4, [pc, #0xb4]
0x00032c:	movs    	r2, #0x1c
0x00032e:	add     	r4, pc
0x000330:	ldr     	r0, [r4, #0x38]
0x000332:	movs    	r1, #0
0x000334:	ldr     	r3, [r0, #0x38]
0x000336:	ldr     	r0, [pc, #0xac]
0x000338:	sub     	sp, #0xc
0x00033a:	add     	r0, sb
0x00033c:	blx     	r3
0x00033e:	movs    	r2, #0
0x000340:	movs    	r0, #0
0x000342:	str     	r0, [sp]
0x000344:	ldr     	r1, [pc, #0x9c]
0x000346:	movs    	r3, #0
0x000348:	add     	r1, sb
0x00034a:	str     	r1, [sp, #4]
0x00034c:	movs    	r1, #0x64
0x00034e:	movs    	r0, #1
0x000350:	str     	r2, [sp, #8]
0x000352:	bl      	#0x9124
0x000356:	ldr     	r1, [pc, #0x8c]
0x000358:	movs    	r0, #0
0x00035a:	add     	r1, sb
0x00035c:	subs    	r1, #0x7c
0x00035e:	str     	r0, [r1, #8]
0x000360:	ldr     	r5, [pc, #0x80]
0x000362:	str     	r0, [r1, #0x10]
0x000364:	str     	r0, [r1, #0xc]
0x000366:	add     	r5, sb
0x000368:	subs    	r5, #0xfc
0x00036a:	movs    	r0, #1
0x00036c:	str     	r0, [r5, #0x18]
0x00036e:	ldr     	r0, [r4, #0x38]
0x000370:	ldr     	r2, [pc, #0x74]
0x000372:	ldr     	r1, [r0, #0x68]
0x000374:	add     	r2, sb
0x000376:	str     	r1, [r5, #0x2c]
0x000378:	ldr     	r1, [r0, #0xc]
0x00037a:	ldr     	r4, [pc, #0x70]
0x00037c:	str     	r1, [r5, #0x30]
0x00037e:	ldr     	r1, [r0, #0x10]
0x000380:	str     	r1, [r5, #0x34]
0x000382:	ldr     	r1, [r0, #0x14]
0x000384:	str     	r1, [r5, #0x38]
0x000386:	ldr     	r1, [r0, #0x18]
0x000388:	str     	r1, [r5, #0x3c]
0x00038a:	ldr     	r1, [r0, #0x1c]
0x00038c:	str     	r1, [r5, #0x40]
0x00038e:	ldr     	r1, [r0, #0x20]
0x000390:	str     	r1, [r5, #0x44]
0x000392:	ldr     	r1, [r0, #0x24]
0x000394:	str     	r1, [r5, #0x48]
0x000396:	ldr     	r1, [r0, #0x28]
0x000398:	str     	r1, [r5, #0x4c]
0x00039a:	ldr     	r1, [r0, #0x2c]
0x00039c:	str     	r1, [r5, #0x50]
0x00039e:	ldr     	r1, [r0, #0x30]
0x0003a0:	str     	r1, [r5, #0x54]
0x0003a2:	ldr     	r1, [r0, #0x34]
0x0003a4:	str     	r1, [r5, #0x58]
0x0003a6:	ldr     	r1, [r0, #0x38]
0x0003a8:	str     	r1, [r5, #0x5c]
0x0003aa:	ldr     	r1, [r0, #0x3c]
0x0003ac:	str     	r1, [r5, #0x60]
0x0003ae:	ldr     	r1, [r0, #0x40]
0x0003b0:	str     	r1, [r5, #0x64]
0x0003b2:	ldr     	r1, [r0, #0x44]
0x0003b4:	str     	r1, [r5, #0x68]
0x0003b6:	ldr     	r1, [r0, #0x48]
0x0003b8:	str     	r1, [r5, #0x6c]
0x0003ba:	ldr     	r1, [r0, #0x4c]
0x0003bc:	str     	r1, [r5, #0x70]
0x0003be:	movs    	r1, #0
0x0003c0:	str     	r1, [r2]
0x0003c2:	movs    	r1, #1
0x0003c4:	lsls    	r1, r1, #9
0x0003c6:	adds    	r0, r0, r1
0x0003c8:	ldr     	r3, [r0, #8]
0x0003ca:	movs    	r1, #7
0x0003cc:	adds    	r2, r4, #0
0x0003ce:	movs    	r0, #0
0x0003d0:	blx     	r3
0x0003d2:	cmp     	r0, r4
0x0003d4:	bne     	#0x3da
0x0003d6:	subs    	r0, #2
0x0003d8:	str     	r0, [r5, #0x28]
0x0003da:	add     	sp, #0xc
0x0003dc:	pop     	{r4, r5, pc}

; ===== candidate_0003f0 =====
0x0003f0:	push    	{r4, r5, r6, r7, lr}
0x0003f2:	ldr     	r6, [pc, #0x48]
0x0003f4:	movs    	r5, #0xf1
0x0003f6:	add     	r6, sb
0x0003f8:	ldr     	r7, [r6, #0x44]
0x0003fa:	lsls    	r5, r5, #9
0x0003fc:	movs    	r4, #0
0x0003fe:	cmp     	r7, #0
0x000400:	sub     	sp, #0xc
0x000402:	beq     	#0x41e
0x000404:	movs    	r1, #0
0x000406:	str     	r1, [sp]
0x000408:	str     	r1, [sp, #4]
0x00040a:	movs    	r2, #0
0x00040c:	str     	r2, [sp, #8]
0x00040e:	movs    	r1, #0xff
0x000410:	adds    	r1, #0xc
0x000412:	adds    	r2, r7, #0
0x000414:	adds    	r3, r4, #0
0x000416:	adds    	r0, r5, #0
0x000418:	bl      	#0x9124
0x00041c:	str     	r4, [r6, #0x44]
0x00041e:	movs    	r2, #0
0x000420:	movs    	r1, #0
0x000422:	str     	r2, [sp, #8]
0x000424:	ldr     	r2, [pc, #0x18]
0x000426:	str     	r1, [sp]
0x000428:	str     	r1, [sp, #4]
0x00042a:	adds    	r3, r4, #0
0x00042c:	add     	r2, pc
0x00042e:	movs    	r1, #0x33
0x000430:	adds    	r0, r5, #0
0x000432:	bl      	#0x9124
0x000436:	add     	sp, #0xc
0x000438:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000444 =====
0x000444:	push    	{r4, r5, r6, r7, lr}
0x000446:	ldr     	r5, [pc, #0xac]
0x000448:	movs    	r7, #0xf1
0x00044a:	add     	r5, sb
0x00044c:	ldr     	r4, [r5, #0x48]
0x00044e:	lsls    	r7, r7, #9
0x000450:	movs    	r6, #0
0x000452:	cmp     	r4, #0
0x000454:	sub     	sp, #0xc
0x000456:	beq     	#0x4d6
0x000458:	movs    	r1, #0
0x00045a:	ldr     	r0, [pc, #0x98]
0x00045c:	movs    	r2, #0
0x00045e:	str     	r2, [sp, #8]
0x000460:	str     	r1, [sp]
0x000462:	str     	r1, [sp, #4]
0x000464:	add     	r0, sb
0x000466:	subs    	r0, #0x80
0x000468:	ldr     	r3, [r0, #0x54]
0x00046a:	movs    	r1, #0x27
0x00046c:	adds    	r2, r4, #0
0x00046e:	adds    	r0, r7, #0
0x000470:	bl      	#0x9124
0x000474:	movs    	r1, #0
0x000476:	str     	r1, [sp]
0x000478:	str     	r1, [sp, #4]
0x00047a:	movs    	r2, #0
0x00047c:	str     	r2, [sp, #8]
0x00047e:	movs    	r1, #0xff
0x000480:	adds    	r1, #0xc
0x000482:	adds    	r2, r0, #0
0x000484:	adds    	r4, r0, #0
0x000486:	adds    	r3, r6, #0
0x000488:	adds    	r0, r7, #0
0x00048a:	bl      	#0x9124
0x00048e:	movs    	r1, #0
0x000490:	str     	r1, [sp]
0x000492:	str     	r1, [sp, #4]
0x000494:	movs    	r2, #0
0x000496:	str     	r2, [sp, #8]
0x000498:	movs    	r1, #0x8d
0x00049a:	adds    	r3, r4, #0
0x00049c:	adds    	r0, r7, #0
0x00049e:	ldr     	r2, [r5, #0x48]
0x0004a0:	bl      	#0x9124
0x0004a4:	movs    	r1, #0
0x0004a6:	str     	r1, [sp]
0x0004a8:	str     	r1, [sp, #4]
0x0004aa:	movs    	r2, #0
0x0004ac:	str     	r2, [sp, #8]
0x0004ae:	movs    	r1, #0x26
0x0004b0:	adds    	r3, r6, #0
0x0004b2:	adds    	r0, r7, #0
0x0004b4:	ldr     	r2, [r5, #0x48]
0x0004b6:	bl      	#0x9124
0x0004ba:	cmp     	r0, #0
0x0004bc:	bgt     	#0x4d6
0x0004be:	movs    	r1, #0
0x0004c0:	str     	r1, [sp]
0x0004c2:	str     	r1, [sp, #4]
0x0004c4:	movs    	r2, #0
0x0004c6:	str     	r2, [sp, #8]
0x0004c8:	movs    	r1, #9
0x0004ca:	adds    	r3, r6, #0
0x0004cc:	adds    	r0, r7, #0
0x0004ce:	ldr     	r2, [r5, #0x48]
0x0004d0:	bl      	#0x9124
0x0004d4:	str     	r6, [r5, #0x48]
0x0004d6:	movs    	r2, #0
0x0004d8:	movs    	r1, #0
0x0004da:	str     	r2, [sp, #8]
0x0004dc:	ldr     	r2, [pc, #0x18]
0x0004de:	str     	r1, [sp]
0x0004e0:	str     	r1, [sp, #4]
0x0004e2:	adds    	r3, r6, #0
0x0004e4:	add     	r2, pc
0x0004e6:	movs    	r1, #0x33
0x0004e8:	adds    	r0, r7, #0
0x0004ea:	bl      	#0x9124
0x0004ee:	add     	sp, #0xc
0x0004f0:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0004fc =====
0x0004fc:	push    	{r4, r5, r6, r7, lr}
0x0004fe:	sub     	sp, #0x14
0x000500:	movs    	r6, #0
0x000502:	movs    	r2, #0
0x000504:	movs    	r1, #0
0x000506:	str     	r2, [sp, #8]
0x000508:	adds    	r3, r6, #0
0x00050a:	adds    	r5, r0, #0
0x00050c:	adds    	r2, r0, #0
0x00050e:	str     	r1, [sp]
0x000510:	str     	r1, [sp, #4]
0x000512:	movs    	r1, #0x44
0x000514:	movs    	r0, #0xf1
0x000516:	movs    	r4, #0
0x000518:	lsls    	r0, r0, #9
0x00051a:	bl      	#0x9124
0x00051e:	movs    	r1, #0
0x000520:	str     	r1, [sp]
0x000522:	str     	r1, [sp, #4]
0x000524:	movs    	r2, #0
0x000526:	str     	r2, [sp, #8]
0x000528:	movs    	r1, #0x45
0x00052a:	adds    	r3, r6, #0
0x00052c:	movs    	r0, #0xf1
0x00052e:	lsls    	r0, r0, #9
0x000530:	ldr     	r2, [r5, #8]
0x000532:	bl      	#0x9124
0x000536:	movs    	r1, #0
0x000538:	str     	r1, [sp]
0x00053a:	str     	r1, [sp, #4]
0x00053c:	str     	r0, [sp, #0x10]
0x00053e:	movs    	r2, #0
0x000540:	str     	r2, [sp, #8]
0x000542:	movs    	r0, #0xf1
0x000544:	movs    	r1, #0x45
0x000546:	adds    	r3, r6, #0
0x000548:	lsls    	r0, r0, #9
0x00054a:	ldr     	r2, [r5, #8]
0x00054c:	bl      	#0x9124
0x000550:	movs    	r1, #0
0x000552:	str     	r1, [sp]
0x000554:	str     	r1, [sp, #4]
0x000556:	str     	r0, [sp, #0xc]
0x000558:	movs    	r2, #0
0x00055a:	str     	r2, [sp, #8]
0x00055c:	movs    	r0, #0xf1
0x00055e:	movs    	r1, #0x45
0x000560:	adds    	r3, r6, #0
0x000562:	lsls    	r0, r0, #9
0x000564:	ldr     	r2, [r5, #8]
0x000566:	bl      	#0x9124
0x00056a:	movs    	r2, #0
0x00056c:	movs    	r1, #0
0x00056e:	str     	r2, [sp, #8]
0x000570:	adds    	r6, r0, #0
0x000572:	adds    	r2, r0, #0
0x000574:	str     	r1, [sp]
0x000576:	str     	r1, [sp, #4]
0x000578:	movs    	r1, #0xa
0x00057a:	movs    	r0, #0xf1
0x00057c:	movs    	r3, #4
0x00057e:	lsls    	r0, r0, #9
0x000580:	bl      	#0x9124
0x000584:	adds    	r7, r0, #0
0x000586:	cmp     	r6, #0
0x000588:	ble     	#0x59a
0x00058a:	adds    	r0, r5, #0
0x00058c:	bl      	#0x9d74
0x000590:	lsls    	r1, r4, #2
0x000592:	adds    	r4, #1
0x000594:	cmp     	r4, r6
0x000596:	str     	r0, [r7, r1]
0x000598:	blt     	#0x58a
0x00059a:	ldr     	r0, [pc, #0x2c]
0x00059c:	ldr     	r1, [sp, #0x10]
0x00059e:	add     	r0, sb
0x0005a0:	str     	r1, [r0, #0x14]
0x0005a2:	ldr     	r1, [sp, #0xc]
0x0005a4:	movs    	r2, #0
0x0005a6:	str     	r1, [r0, #0x10]
0x0005a8:	str     	r7, [r0, #8]
0x0005aa:	movs    	r1, #0
0x0005ac:	str     	r1, [sp]
0x0005ae:	str     	r1, [sp, #4]
0x0005b0:	movs    	r1, #0x2c
0x0005b2:	movs    	r0, #0xf1
0x0005b4:	movs    	r3, #0
0x0005b6:	lsls    	r0, r0, #9
0x0005b8:	str     	r2, [sp, #8]
0x0005ba:	bl      	#0x9124
0x0005be:	bl      	#0x73e4
0x0005c2:	add     	sp, #0x14
0x0005c4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0005cc =====
0x0005cc:	push    	{r4, r5, r6, r7, lr}
0x0005ce:	sub     	sp, #0xc
0x0005d0:	movs    	r1, #0
0x0005d2:	movs    	r2, #0
0x0005d4:	str     	r2, [sp, #8]
0x0005d6:	str     	r1, [sp]
0x0005d8:	str     	r1, [sp, #4]
0x0005da:	movs    	r7, #0xf1
0x0005dc:	movs    	r5, #0
0x0005de:	adds    	r3, r5, #0
0x0005e0:	lsls    	r7, r7, #9
0x0005e2:	movs    	r1, #0x44
0x0005e4:	adds    	r2, r0, #0
0x0005e6:	adds    	r4, r0, #0
0x0005e8:	adds    	r0, r7, #0
0x0005ea:	bl      	#0x9124
0x0005ee:	ldr     	r6, [pc, #0xcc]
0x0005f0:	movs    	r1, #0
0x0005f2:	add     	r6, sb
0x0005f4:	str     	r5, [r6, #0xc]
0x0005f6:	str     	r5, [r6, #0x18]
0x0005f8:	str     	r1, [sp]
0x0005fa:	str     	r1, [sp, #4]
0x0005fc:	movs    	r2, #0
0x0005fe:	str     	r2, [sp, #8]
0x000600:	movs    	r1, #0x45
0x000602:	adds    	r3, r5, #0
0x000604:	adds    	r0, r7, #0
0x000606:	ldr     	r2, [r4, #8]
0x000608:	bl      	#0x9124
0x00060c:	ldr     	r1, [pc, #0xb0]
0x00060e:	movs    	r2, #0
0x000610:	add     	r1, sb
0x000612:	str     	r0, [r1, #4]
0x000614:	movs    	r1, #0
0x000616:	str     	r1, [sp]
0x000618:	str     	r1, [sp, #4]
0x00061a:	movs    	r1, #0x45
0x00061c:	str     	r2, [sp, #8]
0x00061e:	adds    	r3, r5, #0
0x000620:	adds    	r0, r7, #0
0x000622:	ldr     	r2, [r4, #8]
0x000624:	bl      	#0x9124
0x000628:	str     	r0, [r6, #0x14]
0x00062a:	movs    	r1, #0
0x00062c:	str     	r1, [sp]
0x00062e:	str     	r1, [sp, #4]
0x000630:	movs    	r2, #0
0x000632:	str     	r2, [sp, #8]
0x000634:	movs    	r1, #0x45
0x000636:	adds    	r3, r5, #0
0x000638:	adds    	r0, r7, #0
0x00063a:	ldr     	r2, [r4, #8]
0x00063c:	bl      	#0x9124
0x000640:	str     	r0, [r6, #0x10]
0x000642:	movs    	r1, #0
0x000644:	str     	r1, [sp]
0x000646:	str     	r1, [sp, #4]
0x000648:	movs    	r2, #0
0x00064a:	str     	r2, [sp, #8]
0x00064c:	movs    	r1, #0x46
0x00064e:	adds    	r3, r5, #0
0x000650:	adds    	r0, r7, #0
0x000652:	ldr     	r2, [r4, #8]
0x000654:	bl      	#0x9124
0x000658:	lsls    	r0, r0, #0x18
0x00065a:	asrs    	r0, r0, #0x18
0x00065c:	adds    	r3, r0, #1
0x00065e:	beq     	#0x668
0x000660:	adds    	r0, r4, #0
0x000662:	bl      	#0x9d74
0x000666:	str     	r0, [r6, #0xc]
0x000668:	movs    	r1, #0
0x00066a:	str     	r1, [sp]
0x00066c:	str     	r1, [sp, #4]
0x00066e:	movs    	r2, #0
0x000670:	str     	r2, [sp, #8]
0x000672:	movs    	r1, #0x46
0x000674:	adds    	r3, r5, #0
0x000676:	adds    	r0, r7, #0
0x000678:	ldr     	r2, [r4, #8]
0x00067a:	bl      	#0x9124
0x00067e:	lsls    	r0, r0, #0x18
0x000680:	asrs    	r0, r0, #0x18
0x000682:	adds    	r3, r0, #1
0x000684:	beq     	#0x692
0x000686:	adds    	r0, r4, #0
0x000688:	bl      	#0x9d74
0x00068c:	str     	r0, [r6, #0x18]
0x00068e:	strb    	r5, [r6, #1]
0x000690:	b       	#0x69e
0x000692:	movs    	r0, #1
0x000694:	strb    	r0, [r6, #1]
0x000696:	adds    	r0, r4, #0
0x000698:	bl      	#0x9d74
0x00069c:	str     	r0, [r6, #0x18]
0x00069e:	movs    	r1, #0
0x0006a0:	str     	r1, [sp]
0x0006a2:	str     	r1, [sp, #4]
0x0006a4:	movs    	r2, #0
0x0006a6:	movs    	r1, #0x2c
0x0006a8:	adds    	r3, r5, #0
0x0006aa:	adds    	r0, r7, #0
0x0006ac:	str     	r2, [sp, #8]
0x0006ae:	bl      	#0x9124
0x0006b2:	bl      	#0x74b0
0x0006b6:	add     	sp, #0xc
0x0006b8:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0006c4 =====
0x0006c4:	push    	{r4, r5, lr}
0x0006c6:	sub     	sp, #0xc
0x0006c8:	movs    	r5, #0
0x0006ca:	movs    	r2, #0
0x0006cc:	movs    	r1, #0
0x0006ce:	str     	r2, [sp, #8]
0x0006d0:	adds    	r3, r5, #0
0x0006d2:	adds    	r4, r0, #0
0x0006d4:	adds    	r2, r0, #0
0x0006d6:	str     	r1, [sp]
0x0006d8:	str     	r1, [sp, #4]
0x0006da:	movs    	r1, #0x44
0x0006dc:	movs    	r0, #0xf1
0x0006de:	lsls    	r0, r0, #9
0x0006e0:	bl      	#0x9124
0x0006e4:	movs    	r1, #0
0x0006e6:	str     	r1, [sp]
0x0006e8:	str     	r1, [sp, #4]
0x0006ea:	movs    	r2, #0
0x0006ec:	str     	r2, [sp, #8]
0x0006ee:	movs    	r1, #0x47
0x0006f0:	adds    	r3, r5, #0
0x0006f2:	movs    	r0, #0xf1
0x0006f4:	lsls    	r0, r0, #9
0x0006f6:	ldr     	r2, [r4, #8]
0x0006f8:	bl      	#0x9124
0x0006fc:	ldr     	r1, [pc, #0x20]
0x0006fe:	movs    	r2, #0
0x000700:	add     	r1, sb
0x000702:	str     	r0, [r1, #0x1c]
0x000704:	movs    	r1, #0
0x000706:	str     	r1, [sp]
0x000708:	str     	r1, [sp, #4]
0x00070a:	movs    	r1, #0x2c
0x00070c:	movs    	r0, #0xf1
0x00070e:	adds    	r3, r5, #0
0x000710:	lsls    	r0, r0, #9
0x000712:	str     	r2, [sp, #8]
0x000714:	bl      	#0x9124
0x000718:	bl      	#0x7524
0x00071c:	add     	sp, #0xc
0x00071e:	pop     	{r4, r5, pc}

; ===== candidate_000724 =====
0x000724:	push    	{r4, r5, r6, r7, lr}
0x000726:	sub     	sp, #0x24
0x000728:	movs    	r6, #0
0x00072a:	movs    	r2, #0
0x00072c:	movs    	r1, #0
0x00072e:	str     	r2, [sp, #8]
0x000730:	adds    	r3, r6, #0
0x000732:	adds    	r4, r0, #0
0x000734:	adds    	r2, r0, #0
0x000736:	str     	r1, [sp]
0x000738:	str     	r1, [sp, #4]
0x00073a:	movs    	r1, #0x44
0x00073c:	movs    	r0, #0xf1
0x00073e:	movs    	r5, #0
0x000740:	lsls    	r0, r0, #9
0x000742:	bl      	#0x9124
0x000746:	movs    	r1, #0
0x000748:	str     	r1, [sp]
0x00074a:	str     	r1, [sp, #4]
0x00074c:	movs    	r2, #0
0x00074e:	str     	r2, [sp, #8]
0x000750:	movs    	r1, #0x45
0x000752:	adds    	r3, r6, #0
0x000754:	movs    	r0, #0xf1
0x000756:	lsls    	r0, r0, #9
0x000758:	ldr     	r2, [r4, #8]
0x00075a:	bl      	#0x9124
0x00075e:	movs    	r2, #0
0x000760:	movs    	r1, #0
0x000762:	str     	r2, [sp, #8]
0x000764:	adds    	r7, r0, #0
0x000766:	adds    	r2, r0, #0
0x000768:	str     	r1, [sp]
0x00076a:	str     	r1, [sp, #4]
0x00076c:	movs    	r1, #0xa
0x00076e:	movs    	r0, #0xf1
0x000770:	movs    	r3, #4
0x000772:	lsls    	r0, r0, #9
0x000774:	bl      	#0x9124
0x000778:	ldr     	r2, [pc, #0xfc]
0x00077a:	cmp     	r7, #0
0x00077c:	add     	r2, sb
0x00077e:	str     	r0, [r2, #0x34]
0x000780:	ble     	#0x85e
0x000782:	movs    	r1, #0
0x000784:	str     	r1, [sp]
0x000786:	str     	r1, [sp, #4]
0x000788:	movs    	r2, #0
0x00078a:	str     	r2, [sp, #8]
0x00078c:	movs    	r1, #0x45
0x00078e:	adds    	r3, r6, #0
0x000790:	movs    	r0, #0xf1
0x000792:	lsls    	r0, r0, #9
0x000794:	ldr     	r2, [r4, #8]
0x000796:	bl      	#0x9124
0x00079a:	str     	r0, [sp, #0x20]
0x00079c:	movs    	r1, #0
0x00079e:	str     	r1, [sp]
0x0007a0:	str     	r1, [sp, #4]
0x0007a2:	movs    	r2, #0
0x0007a4:	str     	r2, [sp, #8]
0x0007a6:	movs    	r1, #0x47
0x0007a8:	movs    	r0, #0xf1
0x0007aa:	adds    	r3, r6, #0
0x0007ac:	lsls    	r0, r0, #9
0x0007ae:	ldr     	r2, [r4, #8]
0x0007b0:	bl      	#0x9124
0x0007b4:	movs    	r1, #0
0x0007b6:	str     	r1, [sp]
0x0007b8:	str     	r1, [sp, #4]
0x0007ba:	str     	r0, [sp, #0x1c]
0x0007bc:	movs    	r2, #0
0x0007be:	str     	r2, [sp, #8]
0x0007c0:	movs    	r0, #0xf1
0x0007c2:	movs    	r1, #0x45
0x0007c4:	adds    	r3, r6, #0
0x0007c6:	lsls    	r0, r0, #9
0x0007c8:	ldr     	r2, [r4, #8]
0x0007ca:	bl      	#0x9124
0x0007ce:	movs    	r1, #0
0x0007d0:	str     	r1, [sp]
0x0007d2:	str     	r1, [sp, #4]
0x0007d4:	str     	r0, [sp, #0x18]
0x0007d6:	movs    	r2, #0
0x0007d8:	str     	r2, [sp, #8]
0x0007da:	movs    	r0, #0xf1
0x0007dc:	movs    	r1, #0x45
0x0007de:	adds    	r3, r6, #0
0x0007e0:	lsls    	r0, r0, #9
0x0007e2:	ldr     	r2, [r4, #8]
0x0007e4:	bl      	#0x9124
0x0007e8:	movs    	r1, #0
0x0007ea:	str     	r1, [sp]
0x0007ec:	str     	r1, [sp, #4]
0x0007ee:	str     	r0, [sp, #0x14]
0x0007f0:	movs    	r2, #0
0x0007f2:	str     	r2, [sp, #8]
0x0007f4:	movs    	r0, #0xf1
0x0007f6:	movs    	r1, #0x45
0x0007f8:	adds    	r3, r6, #0
0x0007fa:	lsls    	r0, r0, #9
0x0007fc:	ldr     	r2, [r4, #8]
0x0007fe:	bl      	#0x9124
0x000802:	movs    	r1, #0
0x000804:	str     	r1, [sp]
0x000806:	str     	r1, [sp, #4]
0x000808:	str     	r0, [sp, #0x10]
0x00080a:	movs    	r2, #0
0x00080c:	str     	r2, [sp, #8]
0x00080e:	movs    	r0, #0xf1
0x000810:	movs    	r1, #0x45
0x000812:	adds    	r3, r6, #0
0x000814:	lsls    	r0, r0, #9
0x000816:	ldr     	r2, [r4, #8]
0x000818:	bl      	#0x9124
0x00081c:	movs    	r1, #0
0x00081e:	movs    	r2, #0
0x000820:	str     	r2, [sp, #8]
0x000822:	str     	r1, [sp]
0x000824:	str     	r1, [sp, #4]
0x000826:	str     	r0, [sp, #0xc]
0x000828:	movs    	r0, #0xf1
0x00082a:	movs    	r1, #0xf
0x00082c:	movs    	r2, #0x18
0x00082e:	adds    	r3, r6, #0
0x000830:	lsls    	r0, r0, #9
0x000832:	bl      	#0x9124
0x000836:	ldr     	r1, [sp, #0x20]
0x000838:	ldr     	r2, [pc, #0x3c]
0x00083a:	str     	r1, [r0, #4]
0x00083c:	ldr     	r1, [sp, #0x1c]
0x00083e:	add     	r2, sb
0x000840:	str     	r1, [r0]
0x000842:	ldr     	r1, [sp, #0x18]
0x000844:	str     	r1, [r0, #8]
0x000846:	ldr     	r1, [sp, #0x14]
0x000848:	str     	r1, [r0, #0xc]
0x00084a:	ldr     	r1, [sp, #0x10]
0x00084c:	str     	r1, [r0, #0x10]
0x00084e:	ldr     	r1, [sp, #0xc]
0x000850:	str     	r1, [r0, #0x14]

; ===== candidate_00087c =====
0x00087c:	push    	{r4, r5, r6, r7, lr}
0x00087e:	sub     	sp, #0x1c
0x000880:	movs    	r4, #0
0x000882:	movs    	r2, #0
0x000884:	movs    	r1, #0
0x000886:	str     	r2, [sp, #8]
0x000888:	adds    	r3, r4, #0
0x00088a:	adds    	r5, r0, #0
0x00088c:	adds    	r2, r0, #0
0x00088e:	str     	r1, [sp]
0x000890:	str     	r1, [sp, #4]
0x000892:	movs    	r1, #0x44
0x000894:	movs    	r0, #0xf1
0x000896:	movs    	r7, #0
0x000898:	lsls    	r0, r0, #9
0x00089a:	bl      	#0x9124
0x00089e:	movs    	r1, #0
0x0008a0:	str     	r1, [sp]
0x0008a2:	str     	r1, [sp, #4]
0x0008a4:	movs    	r2, #0
0x0008a6:	str     	r2, [sp, #8]
0x0008a8:	movs    	r1, #0x45
0x0008aa:	adds    	r3, r4, #0
0x0008ac:	movs    	r0, #0xf1
0x0008ae:	lsls    	r0, r0, #9
0x0008b0:	ldr     	r2, [r5, #8]
0x0008b2:	bl      	#0x9124
0x0008b6:	movs    	r2, #0
0x0008b8:	movs    	r1, #0
0x0008ba:	movs    	r4, #4
0x0008bc:	adds    	r3, r4, #0
0x0008be:	str     	r2, [sp, #8]
0x0008c0:	adds    	r2, r0, #0
0x0008c2:	str     	r1, [sp]
0x0008c4:	str     	r1, [sp, #4]
0x0008c6:	str     	r0, [sp, #0x18]
0x0008c8:	movs    	r0, #0xf1
0x0008ca:	movs    	r1, #0xa
0x0008cc:	lsls    	r0, r0, #9
0x0008ce:	bl      	#0x9124
0x0008d2:	ldr     	r2, [pc, #0xdc]
0x0008d4:	add     	r2, sb
0x0008d6:	str     	r0, [r2, #0x30]
0x0008d8:	ldr     	r0, [sp, #0x18]
0x0008da:	cmp     	r0, #0
0x0008dc:	ble     	#0x992
0x0008de:	movs    	r1, #0
0x0008e0:	str     	r1, [sp]
0x0008e2:	str     	r1, [sp, #4]
0x0008e4:	movs    	r2, #0
0x0008e6:	movs    	r4, #0
0x0008e8:	adds    	r3, r4, #0
0x0008ea:	str     	r2, [sp, #8]
0x0008ec:	movs    	r1, #0x47
0x0008ee:	movs    	r0, #0xf1
0x0008f0:	lsls    	r0, r0, #9
0x0008f2:	ldr     	r2, [r5, #8]
0x0008f4:	bl      	#0x9124
0x0008f8:	movs    	r1, #0
0x0008fa:	movs    	r2, #0
0x0008fc:	str     	r2, [sp, #8]
0x0008fe:	str     	r1, [sp]
0x000900:	str     	r1, [sp, #4]
0x000902:	str     	r0, [sp, #0x14]
0x000904:	movs    	r0, #0xf1
0x000906:	movs    	r1, #0xf
0x000908:	movs    	r2, #8
0x00090a:	adds    	r3, r4, #0
0x00090c:	lsls    	r0, r0, #9
0x00090e:	bl      	#0x9124
0x000912:	movs    	r1, #0
0x000914:	str     	r1, [sp]
0x000916:	str     	r1, [sp, #4]
0x000918:	str     	r0, [sp, #0x10]
0x00091a:	movs    	r2, #0
0x00091c:	str     	r2, [sp, #8]
0x00091e:	movs    	r0, #0xf1
0x000920:	movs    	r1, #0x46
0x000922:	adds    	r3, r4, #0
0x000924:	lsls    	r0, r0, #9
0x000926:	ldr     	r2, [r5, #8]
0x000928:	bl      	#0x9124
0x00092c:	lsls    	r6, r0, #0x18
0x00092e:	movs    	r1, #0
0x000930:	movs    	r2, #0
0x000932:	str     	r2, [sp, #8]
0x000934:	str     	r1, [sp]
0x000936:	str     	r1, [sp, #4]
0x000938:	asrs    	r6, r6, #0x18
0x00093a:	adds    	r2, r6, #0
0x00093c:	movs    	r1, #0xa
0x00093e:	movs    	r0, #0xf1
0x000940:	movs    	r3, #4
0x000942:	lsls    	r0, r0, #9
0x000944:	bl      	#0x9124
0x000948:	str     	r0, [sp, #0xc]
0x00094a:	cmp     	r6, #0
0x00094c:	ble     	#0x972
0x00094e:	movs    	r1, #0
0x000950:	str     	r1, [sp]
0x000952:	str     	r1, [sp, #4]
0x000954:	movs    	r2, #0
0x000956:	str     	r2, [sp, #8]
0x000958:	movs    	r1, #0x47
0x00095a:	movs    	r3, #0
0x00095c:	movs    	r0, #0xf1
0x00095e:	lsls    	r0, r0, #9
0x000960:	ldr     	r2, [r5, #8]
0x000962:	bl      	#0x9124
0x000966:	lsls    	r1, r4, #2
0x000968:	ldr     	r2, [sp, #0xc]
0x00096a:	adds    	r4, #1
0x00096c:	cmp     	r4, r6
0x00096e:	str     	r0, [r2, r1]
0x000970:	blt     	#0x94e
0x000972:	ldr     	r0, [sp, #0x14]
0x000974:	ldr     	r1, [sp, #0x10]
0x000976:	ldr     	r2, [pc, #0x38]
0x000978:	str     	r0, [r1]
0x00097a:	ldr     	r0, [sp, #0xc]
0x00097c:	ldr     	r1, [sp, #0x10]
0x00097e:	add     	r2, sb
0x000980:	str     	r0, [r1, #4]
0x000982:	ldr     	r0, [sp, #0x10]
0x000984:	ldr     	r2, [r2, #0x30]
0x000986:	lsls    	r1, r7, #2
0x000988:	str     	r0, [r2, r1]
0x00098a:	ldr     	r0, [sp, #0x18]
0x00098c:	adds    	r7, #1
0x00098e:	cmp     	r7, r0
0x000990:	blt     	#0x8de
0x000992:	movs    	r1, #0
0x000994:	str     	r1, [sp]
0x000996:	str     	r1, [sp, #4]
0x000998:	movs    	r2, #0
0x00099a:	movs    	r1, #0x2c
0x00099c:	movs    	r3, #0
0x00099e:	movs    	r0, #0xf1
0x0009a0:	lsls    	r0, r0, #9
0x0009a2:	str     	r2, [sp, #8]
0x0009a4:	bl      	#0x9124

; ===== candidate_0009b4 =====
0x0009b4:	push    	{r4, r5, r6, r7, lr}
0x0009b6:	sub     	sp, #0x2c
0x0009b8:	movs    	r1, #0
0x0009ba:	movs    	r2, #0
0x0009bc:	str     	r2, [sp, #8]
0x0009be:	str     	r1, [sp]
0x0009c0:	str     	r1, [sp, #4]
0x0009c2:	movs    	r6, #0xf1
0x0009c4:	movs    	r7, #0
0x0009c6:	adds    	r3, r7, #0
0x0009c8:	lsls    	r6, r6, #9
0x0009ca:	movs    	r1, #0x44
0x0009cc:	adds    	r2, r0, #0
0x0009ce:	movs    	r5, #0
0x0009d0:	adds    	r4, r0, #0
0x0009d2:	adds    	r0, r6, #0
0x0009d4:	bl      	#0x9124
0x0009d8:	movs    	r1, #0
0x0009da:	str     	r1, [sp]
0x0009dc:	str     	r1, [sp, #4]
0x0009de:	movs    	r2, #0
0x0009e0:	str     	r2, [sp, #8]
0x0009e2:	movs    	r1, #0x47
0x0009e4:	adds    	r3, r7, #0
0x0009e6:	adds    	r0, r6, #0
0x0009e8:	ldr     	r2, [r4, #8]
0x0009ea:	bl      	#0x9124
0x0009ee:	movs    	r1, #0
0x0009f0:	str     	r0, [sp, #0x24]
0x0009f2:	str     	r1, [sp, #4]
0x0009f4:	str     	r1, [sp]
0x0009f6:	movs    	r2, #0
0x0009f8:	str     	r2, [sp, #8]
0x0009fa:	movs    	r1, #0x45
0x0009fc:	adds    	r3, r7, #0
0x0009fe:	adds    	r0, r6, #0
0x000a00:	ldr     	r2, [r4, #8]
0x000a02:	bl      	#0x9124
0x000a06:	movs    	r1, #0
0x000a08:	movs    	r2, #0
0x000a0a:	str     	r2, [sp, #8]
0x000a0c:	str     	r1, [sp]
0x000a0e:	str     	r1, [sp, #4]
0x000a10:	movs    	r1, #0xa
0x000a12:	adds    	r2, r0, #0
0x000a14:	adds    	r7, r0, #0
0x000a16:	movs    	r3, #4
0x000a18:	adds    	r0, r6, #0
0x000a1a:	bl      	#0x9124
0x000a1e:	str     	r0, [sp, #0x28]
0x000a20:	cmp     	r7, #0
0x000a22:	ble     	#0xb0a
0x000a24:	movs    	r6, #0
0x000a26:	movs    	r1, #0
0x000a28:	str     	r1, [sp]
0x000a2a:	str     	r1, [sp, #4]
0x000a2c:	movs    	r2, #0
0x000a2e:	str     	r2, [sp, #8]
0x000a30:	movs    	r1, #0x46
0x000a32:	adds    	r3, r6, #0
0x000a34:	movs    	r0, #0xf1
0x000a36:	lsls    	r0, r0, #9
0x000a38:	ldr     	r2, [r4, #8]
0x000a3a:	bl      	#0x9124
0x000a3e:	lsls    	r0, r0, #0x18
0x000a40:	asrs    	r0, r0, #0x18
0x000a42:	adds    	r3, r0, #1
0x000a44:	beq     	#0xb0a
0x000a46:	movs    	r1, #0
0x000a48:	str     	r1, [sp]
0x000a4a:	str     	r1, [sp, #4]
0x000a4c:	movs    	r2, #0
0x000a4e:	str     	r2, [sp, #8]
0x000a50:	movs    	r1, #0x45
0x000a52:	adds    	r3, r6, #0
0x000a54:	movs    	r0, #0xf1
0x000a56:	lsls    	r0, r0, #9
0x000a58:	ldr     	r2, [r4, #8]
0x000a5a:	bl      	#0x9124
0x000a5e:	str     	r0, [sp, #0x20]
0x000a60:	movs    	r1, #0
0x000a62:	str     	r1, [sp]
0x000a64:	str     	r1, [sp, #4]
0x000a66:	movs    	r2, #0
0x000a68:	str     	r2, [sp, #8]
0x000a6a:	movs    	r1, #0x45
0x000a6c:	movs    	r0, #0xf1
0x000a6e:	adds    	r3, r6, #0
0x000a70:	lsls    	r0, r0, #9
0x000a72:	ldr     	r2, [r4, #8]
0x000a74:	bl      	#0x9124
0x000a78:	movs    	r1, #0
0x000a7a:	str     	r1, [sp]
0x000a7c:	str     	r1, [sp, #4]
0x000a7e:	str     	r0, [sp, #0x1c]
0x000a80:	movs    	r2, #0
0x000a82:	str     	r2, [sp, #8]
0x000a84:	movs    	r0, #0xf1
0x000a86:	movs    	r1, #0x45
0x000a88:	adds    	r3, r6, #0
0x000a8a:	lsls    	r0, r0, #9
0x000a8c:	ldr     	r2, [r4, #8]
0x000a8e:	bl      	#0x9124
0x000a92:	movs    	r1, #0
0x000a94:	str     	r1, [sp]
0x000a96:	str     	r1, [sp, #4]
0x000a98:	str     	r0, [sp, #0x10]
0x000a9a:	movs    	r2, #0
0x000a9c:	str     	r2, [sp, #8]
0x000a9e:	movs    	r0, #0xf1
0x000aa0:	movs    	r1, #0x47
0x000aa2:	adds    	r3, r6, #0
0x000aa4:	lsls    	r0, r0, #9
0x000aa6:	ldr     	r2, [r4, #8]
0x000aa8:	bl      	#0x9124
0x000aac:	movs    	r1, #0
0x000aae:	str     	r1, [sp]
0x000ab0:	str     	r1, [sp, #4]
0x000ab2:	str     	r0, [sp, #0x18]
0x000ab4:	movs    	r2, #0
0x000ab6:	str     	r2, [sp, #8]
0x000ab8:	movs    	r0, #0xf1
0x000aba:	movs    	r1, #0x46
0x000abc:	adds    	r3, r6, #0
0x000abe:	lsls    	r0, r0, #9
0x000ac0:	ldr     	r2, [r4, #8]
0x000ac2:	bl      	#0x9124
0x000ac6:	movs    	r1, #0
0x000ac8:	str     	r1, [sp]
0x000aca:	str     	r1, [sp, #4]
0x000acc:	str     	r0, [sp, #0x14]
0x000ace:	movs    	r2, #0
0x000ad0:	str     	r2, [sp, #8]
0x000ad2:	movs    	r0, #0xf1
0x000ad4:	movs    	r1, #0x46
0x000ad6:	adds    	r3, r6, #0
0x000ad8:	lsls    	r0, r0, #9
0x000ada:	ldr     	r2, [r4, #8]
0x000adc:	bl      	#0x9124
0x000ae0:	lsls    	r0, r0, #0x18
0x000ae2:	movs    	r1, #0

; ===== candidate_000b54 =====
0x000b54:	push    	{r4, r5, r6, r7, lr}
0x000b56:	sub     	sp, #0x24
0x000b58:	movs    	r6, #0
0x000b5a:	movs    	r2, #0
0x000b5c:	movs    	r1, #0
0x000b5e:	str     	r2, [sp, #8]
0x000b60:	adds    	r3, r6, #0
0x000b62:	adds    	r4, r0, #0
0x000b64:	adds    	r2, r0, #0
0x000b66:	str     	r1, [sp]
0x000b68:	str     	r1, [sp, #4]
0x000b6a:	movs    	r1, #0x44
0x000b6c:	movs    	r0, #0xf1
0x000b6e:	movs    	r5, #0
0x000b70:	lsls    	r0, r0, #9
0x000b72:	bl      	#0x9124
0x000b76:	movs    	r1, #0
0x000b78:	str     	r1, [sp]
0x000b7a:	str     	r1, [sp, #4]
0x000b7c:	movs    	r2, #0
0x000b7e:	str     	r2, [sp, #8]
0x000b80:	movs    	r1, #0x45
0x000b82:	adds    	r3, r6, #0
0x000b84:	movs    	r0, #0xf1
0x000b86:	lsls    	r0, r0, #9
0x000b88:	ldr     	r2, [r4, #8]
0x000b8a:	bl      	#0x9124
0x000b8e:	ldr     	r7, [pc, #0x114]
0x000b90:	movs    	r1, #0
0x000b92:	add     	r7, sb
0x000b94:	str     	r0, [r7, #0x28]
0x000b96:	str     	r1, [sp]
0x000b98:	str     	r1, [sp, #4]
0x000b9a:	movs    	r2, #0
0x000b9c:	str     	r2, [sp, #8]
0x000b9e:	movs    	r1, #0x45
0x000ba0:	movs    	r0, #0xf1
0x000ba2:	adds    	r3, r6, #0
0x000ba4:	lsls    	r0, r0, #9
0x000ba6:	ldr     	r2, [r4, #8]
0x000ba8:	bl      	#0x9124
0x000bac:	str     	r0, [r7, #0x24]
0x000bae:	movs    	r1, #0
0x000bb0:	str     	r1, [sp]
0x000bb2:	str     	r1, [sp, #4]
0x000bb4:	movs    	r2, #0
0x000bb6:	str     	r2, [sp, #8]
0x000bb8:	movs    	r1, #0x45
0x000bba:	movs    	r0, #0xf1
0x000bbc:	adds    	r3, r6, #0
0x000bbe:	lsls    	r0, r0, #9
0x000bc0:	ldr     	r2, [r4, #8]
0x000bc2:	bl      	#0x9124
0x000bc6:	movs    	r2, #0
0x000bc8:	movs    	r1, #0
0x000bca:	str     	r2, [sp, #8]
0x000bcc:	adds    	r7, r0, #0
0x000bce:	adds    	r2, r0, #0
0x000bd0:	str     	r1, [sp]
0x000bd2:	str     	r1, [sp, #4]
0x000bd4:	movs    	r1, #0xa
0x000bd6:	movs    	r0, #0xf1
0x000bd8:	movs    	r3, #4
0x000bda:	lsls    	r0, r0, #9
0x000bdc:	bl      	#0x9124
0x000be0:	str     	r0, [sp, #0x20]
0x000be2:	cmp     	r7, #0
0x000be4:	ble     	#0xc82
0x000be6:	movs    	r1, #0
0x000be8:	str     	r1, [sp]
0x000bea:	str     	r1, [sp, #4]
0x000bec:	movs    	r2, #0
0x000bee:	str     	r2, [sp, #8]
0x000bf0:	movs    	r1, #0x45
0x000bf2:	adds    	r3, r6, #0
0x000bf4:	movs    	r0, #0xf1
0x000bf6:	lsls    	r0, r0, #9
0x000bf8:	ldr     	r2, [r4, #8]
0x000bfa:	bl      	#0x9124
0x000bfe:	movs    	r1, #0
0x000c00:	str     	r1, [sp]
0x000c02:	str     	r1, [sp, #4]
0x000c04:	str     	r0, [sp, #0x1c]
0x000c06:	movs    	r2, #0
0x000c08:	str     	r2, [sp, #8]
0x000c0a:	movs    	r0, #0xf1
0x000c0c:	movs    	r1, #0x45
0x000c0e:	adds    	r3, r6, #0
0x000c10:	lsls    	r0, r0, #9
0x000c12:	ldr     	r2, [r4, #8]
0x000c14:	bl      	#0x9124
0x000c18:	movs    	r1, #0
0x000c1a:	str     	r1, [sp]
0x000c1c:	str     	r1, [sp, #4]
0x000c1e:	str     	r0, [sp, #0x18]
0x000c20:	movs    	r2, #0
0x000c22:	str     	r2, [sp, #8]
0x000c24:	movs    	r0, #0xf1
0x000c26:	movs    	r1, #0x47
0x000c28:	adds    	r3, r6, #0
0x000c2a:	lsls    	r0, r0, #9
0x000c2c:	ldr     	r2, [r4, #8]
0x000c2e:	bl      	#0x9124
0x000c32:	movs    	r1, #0
0x000c34:	str     	r1, [sp]
0x000c36:	str     	r1, [sp, #4]
0x000c38:	str     	r0, [sp, #0x14]
0x000c3a:	movs    	r2, #0
0x000c3c:	str     	r2, [sp, #8]
0x000c3e:	movs    	r0, #0xf1
0x000c40:	movs    	r1, #0x45
0x000c42:	adds    	r3, r6, #0
0x000c44:	lsls    	r0, r0, #9
0x000c46:	ldr     	r2, [r4, #8]
0x000c48:	bl      	#0x9124
0x000c4c:	movs    	r1, #0
0x000c4e:	movs    	r2, #0
0x000c50:	str     	r2, [sp, #8]
0x000c52:	str     	r1, [sp]
0x000c54:	str     	r1, [sp, #4]
0x000c56:	str     	r0, [sp, #0x10]
0x000c58:	movs    	r0, #0xf1
0x000c5a:	movs    	r1, #0xf
0x000c5c:	movs    	r2, #0x10
0x000c5e:	adds    	r3, r6, #0
0x000c60:	lsls    	r0, r0, #9
0x000c62:	bl      	#0x9124
0x000c66:	ldr     	r1, [sp, #0x1c]
0x000c68:	str     	r1, [r0]
0x000c6a:	ldr     	r1, [sp, #0x18]
0x000c6c:	str     	r1, [r0, #4]
0x000c6e:	ldr     	r1, [sp, #0x14]
0x000c70:	str     	r1, [r0, #8]
0x000c72:	ldr     	r1, [sp, #0x10]
0x000c74:	str     	r1, [r0, #0xc]
0x000c76:	lsls    	r1, r5, #2
0x000c78:	ldr     	r2, [sp, #0x20]
0x000c7a:	adds    	r5, #1
0x000c7c:	cmp     	r5, r7
0x000c7e:	str     	r0, [r2, r1]
0x000c80:	blt     	#0xbe6

; ===== candidate_000ca8 =====
0x000ca8:	push    	{r4, r5, r6, r7, lr}
0x000caa:	sub     	sp, #0x2c
0x000cac:	movs    	r6, #0
0x000cae:	movs    	r1, #0
0x000cb0:	adds    	r4, r0, #0
0x000cb2:	movs    	r2, #0
0x000cb4:	str     	r2, [sp, #8]
0x000cb6:	str     	r1, [sp]
0x000cb8:	str     	r1, [sp, #4]
0x000cba:	adds    	r5, r6, #0
0x000cbc:	adds    	r3, r6, #0
0x000cbe:	adds    	r2, r4, #0
0x000cc0:	movs    	r1, #0x44
0x000cc2:	movs    	r0, #0xf1
0x000cc4:	movs    	r7, #0
0x000cc6:	lsls    	r0, r0, #9
0x000cc8:	bl      	#0x9124
0x000ccc:	movs    	r1, #0
0x000cce:	str     	r1, [sp]
0x000cd0:	str     	r1, [sp, #4]
0x000cd2:	movs    	r2, #0
0x000cd4:	str     	r2, [sp, #8]
0x000cd6:	movs    	r1, #0x45
0x000cd8:	adds    	r3, r5, #0
0x000cda:	movs    	r0, #0xf1
0x000cdc:	lsls    	r0, r0, #9
0x000cde:	ldr     	r2, [r4, #8]
0x000ce0:	bl      	#0x9124
0x000ce4:	str     	r0, [sp, #0x24]
0x000ce6:	movs    	r2, #0
0x000ce8:	movs    	r1, #0
0x000cea:	str     	r2, [sp, #8]
0x000cec:	adds    	r2, r0, #0
0x000cee:	str     	r1, [sp]
0x000cf0:	str     	r1, [sp, #4]
0x000cf2:	movs    	r1, #0xa
0x000cf4:	movs    	r0, #0xf1
0x000cf6:	movs    	r3, #4
0x000cf8:	lsls    	r0, r0, #9
0x000cfa:	bl      	#0x9124
0x000cfe:	str     	r0, [sp, #0x20]
0x000d00:	ldr     	r0, [sp, #0x24]
0x000d02:	cmp     	r0, #0
0x000d04:	ble     	#0xdec
0x000d06:	movs    	r1, #0
0x000d08:	str     	r1, [sp]
0x000d0a:	str     	r1, [sp, #4]
0x000d0c:	movs    	r2, #0
0x000d0e:	str     	r2, [sp, #8]
0x000d10:	movs    	r1, #0x45
0x000d12:	adds    	r3, r6, #0
0x000d14:	movs    	r0, #0xf1
0x000d16:	lsls    	r0, r0, #9
0x000d18:	ldr     	r2, [r4, #8]
0x000d1a:	bl      	#0x9124
0x000d1e:	movs    	r1, #0
0x000d20:	str     	r1, [sp]
0x000d22:	str     	r1, [sp, #4]
0x000d24:	str     	r0, [sp, #0x1c]
0x000d26:	movs    	r2, #0
0x000d28:	str     	r2, [sp, #8]
0x000d2a:	movs    	r0, #0xf1
0x000d2c:	movs    	r1, #0x47
0x000d2e:	adds    	r3, r6, #0
0x000d30:	lsls    	r0, r0, #9
0x000d32:	ldr     	r2, [r4, #8]
0x000d34:	bl      	#0x9124
0x000d38:	movs    	r1, #0
0x000d3a:	str     	r1, [sp]
0x000d3c:	str     	r1, [sp, #4]
0x000d3e:	str     	r0, [sp, #0x18]
0x000d40:	movs    	r2, #0
0x000d42:	str     	r2, [sp, #8]
0x000d44:	movs    	r0, #0xf1
0x000d46:	movs    	r1, #0x46
0x000d48:	adds    	r3, r6, #0
0x000d4a:	lsls    	r0, r0, #9
0x000d4c:	ldr     	r2, [r4, #8]
0x000d4e:	bl      	#0x9124
0x000d52:	movs    	r1, #0
0x000d54:	str     	r1, [sp]
0x000d56:	str     	r1, [sp, #4]
0x000d58:	str     	r0, [sp, #0x14]
0x000d5a:	movs    	r2, #0
0x000d5c:	str     	r2, [sp, #8]
0x000d5e:	movs    	r0, #0xf1
0x000d60:	movs    	r1, #0xe2
0x000d62:	adds    	r3, r6, #0
0x000d64:	lsls    	r0, r0, #9
0x000d66:	ldr     	r2, [r4, #8]
0x000d68:	bl      	#0x9124
0x000d6c:	movs    	r1, #0
0x000d6e:	str     	r1, [sp]
0x000d70:	str     	r1, [sp, #4]
0x000d72:	str     	r0, [sp, #0x10]
0x000d74:	movs    	r2, #0
0x000d76:	str     	r2, [sp, #8]
0x000d78:	movs    	r0, #0xf1
0x000d7a:	movs    	r1, #0x46
0x000d7c:	adds    	r3, r6, #0
0x000d7e:	lsls    	r0, r0, #9
0x000d80:	ldr     	r2, [r4, #8]
0x000d82:	bl      	#0x9124
0x000d86:	movs    	r1, #0
0x000d88:	movs    	r2, #0
0x000d8a:	str     	r2, [sp, #8]
0x000d8c:	str     	r1, [sp]
0x000d8e:	str     	r1, [sp, #4]
0x000d90:	str     	r0, [sp, #0xc]
0x000d92:	movs    	r0, #0xf1
0x000d94:	movs    	r1, #0xf
0x000d96:	movs    	r2, #0x2c
0x000d98:	adds    	r3, r6, #0
0x000d9a:	lsls    	r0, r0, #9
0x000d9c:	bl      	#0x9124
0x000da0:	adds    	r5, r0, #0
0x000da2:	ldr     	r0, [sp, #0x1c]
0x000da4:	movs    	r2, #0
0x000da6:	str     	r0, [r5]
0x000da8:	ldr     	r1, [sp, #0x10]
0x000daa:	adds    	r3, r6, #0
0x000dac:	strh    	r1, [r5, #8]
0x000dae:	ldr     	r1, [sp, #0x18]
0x000db0:	str     	r1, [r5, #4]
0x000db2:	ldr     	r0, [sp, #0xc]
0x000db4:	movs    	r1, #0
0x000db6:	strb    	r0, [r5, #0xa]
0x000db8:	str     	r1, [sp]
0x000dba:	str     	r1, [sp, #4]
0x000dbc:	movs    	r1, #0x45
0x000dbe:	str     	r2, [sp, #8]
0x000dc0:	movs    	r0, #0xf1
0x000dc2:	lsls    	r0, r0, #9
0x000dc4:	ldr     	r2, [r4, #8]
0x000dc6:	bl      	#0x9124
0x000dca:	str     	r0, [r5, #0xc]
0x000dcc:	movs    	r1, #0
0x000dce:	str     	r1, [sp]
0x000dd0:	str     	r1, [sp, #4]
0x000dd2:	movs    	r2, #0
0x000dd4:	str     	r2, [sp, #8]

; ===== candidate_000f14 =====
0x000f14:	push    	{r4, r5, r6, r7, lr}
0x000f16:	sub     	sp, #0x14
0x000f18:	movs    	r6, #0
0x000f1a:	movs    	r2, #0
0x000f1c:	movs    	r1, #0
0x000f1e:	str     	r2, [sp, #8]
0x000f20:	adds    	r3, r6, #0
0x000f22:	adds    	r5, r0, #0
0x000f24:	adds    	r2, r0, #0
0x000f26:	str     	r1, [sp]
0x000f28:	str     	r1, [sp, #4]
0x000f2a:	movs    	r1, #0x44
0x000f2c:	movs    	r0, #0xf1
0x000f2e:	movs    	r4, #0
0x000f30:	lsls    	r0, r0, #9
0x000f32:	bl      	#0x9124
0x000f36:	movs    	r1, #0
0x000f38:	str     	r1, [sp]
0x000f3a:	str     	r1, [sp, #4]
0x000f3c:	movs    	r2, #0
0x000f3e:	str     	r2, [sp, #8]
0x000f40:	movs    	r1, #0x45
0x000f42:	adds    	r3, r6, #0
0x000f44:	movs    	r0, #0xf1
0x000f46:	lsls    	r0, r0, #9
0x000f48:	ldr     	r2, [r5, #8]
0x000f4a:	bl      	#0x9124
0x000f4e:	ldr     	r7, [pc, #0x9c]
0x000f50:	str     	r0, [sp, #0x10]
0x000f52:	add     	r7, sb
0x000f54:	str     	r0, [r7, #0x28]
0x000f56:	movs    	r1, #0
0x000f58:	str     	r1, [sp]
0x000f5a:	str     	r1, [sp, #4]
0x000f5c:	movs    	r2, #0
0x000f5e:	str     	r2, [sp, #8]
0x000f60:	movs    	r1, #0x45
0x000f62:	movs    	r0, #0xf1
0x000f64:	adds    	r3, r6, #0
0x000f66:	lsls    	r0, r0, #9
0x000f68:	ldr     	r2, [r5, #8]
0x000f6a:	bl      	#0x9124
0x000f6e:	str     	r0, [sp, #0xc]
0x000f70:	str     	r0, [r7, #0x24]
0x000f72:	movs    	r1, #0
0x000f74:	str     	r1, [sp]
0x000f76:	str     	r1, [sp, #4]
0x000f78:	movs    	r2, #0
0x000f7a:	str     	r2, [sp, #8]
0x000f7c:	movs    	r1, #0x45
0x000f7e:	movs    	r0, #0xf1
0x000f80:	adds    	r3, r6, #0
0x000f82:	lsls    	r0, r0, #9
0x000f84:	ldr     	r2, [r5, #8]
0x000f86:	bl      	#0x9124
0x000f8a:	movs    	r2, #0
0x000f8c:	movs    	r1, #0
0x000f8e:	str     	r2, [sp, #8]
0x000f90:	adds    	r6, r0, #0
0x000f92:	adds    	r2, r0, #0
0x000f94:	str     	r1, [sp]
0x000f96:	str     	r1, [sp, #4]
0x000f98:	movs    	r1, #0xa
0x000f9a:	movs    	r0, #0xf1
0x000f9c:	movs    	r3, #4
0x000f9e:	lsls    	r0, r0, #9
0x000fa0:	bl      	#0x9124
0x000fa4:	adds    	r7, r0, #0
0x000fa6:	cmp     	r6, #0
0x000fa8:	ble     	#0xfba
0x000faa:	adds    	r0, r5, #0
0x000fac:	bl      	#0x9994
0x000fb0:	lsls    	r1, r4, #2
0x000fb2:	adds    	r4, #1
0x000fb4:	cmp     	r4, r6
0x000fb6:	str     	r0, [r7, r1]
0x000fb8:	blt     	#0xfaa
0x000fba:	movs    	r1, #0
0x000fbc:	str     	r1, [sp]
0x000fbe:	str     	r1, [sp, #4]
0x000fc0:	movs    	r2, #0
0x000fc2:	movs    	r1, #0x2c
0x000fc4:	movs    	r3, #0
0x000fc6:	movs    	r0, #0xf1
0x000fc8:	lsls    	r0, r0, #9
0x000fca:	str     	r2, [sp, #8]
0x000fcc:	bl      	#0x9124
0x000fd0:	ldr     	r1, [pc, #0x1c]
0x000fd2:	ldr     	r0, [sp, #0xc]
0x000fd4:	add     	r1, sb
0x000fd6:	str     	r0, [r1, #0x10]
0x000fd8:	ldr     	r1, [pc, #0x10]
0x000fda:	ldr     	r0, [sp, #0x10]
0x000fdc:	add     	r1, sb
0x000fde:	str     	r0, [r1, #0x40]
0x000fe0:	adds    	r0, r7, #0
0x000fe2:	bl      	#0x6a60
0x000fe6:	add     	sp, #0x14
0x000fe8:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000ff4 =====
0x000ff4:	push    	{r4, r5, lr}
0x000ff6:	sub     	sp, #0xc
0x000ff8:	movs    	r1, #0
0x000ffa:	str     	r1, [sp]
0x000ffc:	str     	r1, [sp, #4]
0x000ffe:	movs    	r4, #0
0x001000:	adds    	r3, r4, #0
0x001002:	movs    	r1, #0xff
0x001004:	movs    	r2, #0
0x001006:	adds    	r1, #0x3e
0x001008:	movs    	r0, #0xf1
0x00100a:	lsls    	r0, r0, #9
0x00100c:	str     	r2, [sp, #8]
0x00100e:	bl      	#0x9124
0x001012:	movs    	r1, #0
0x001014:	str     	r1, [sp]
0x001016:	str     	r1, [sp, #4]
0x001018:	movs    	r2, #0
0x00101a:	movs    	r1, #0x2c
0x00101c:	adds    	r3, r4, #0
0x00101e:	movs    	r0, #0xf1
0x001020:	lsls    	r0, r0, #9
0x001022:	str     	r2, [sp, #8]
0x001024:	bl      	#0x9124
0x001028:	movs    	r1, #0
0x00102a:	str     	r1, [sp]
0x00102c:	str     	r1, [sp, #4]
0x00102e:	movs    	r2, #0
0x001030:	ldr     	r5, [pc, #0x48]
0x001032:	movs    	r1, #0xff
0x001034:	adds    	r3, r4, #0
0x001036:	adds    	r1, #0xb
0x001038:	str     	r2, [sp, #8]
0x00103a:	movs    	r0, #0xf1
0x00103c:	add     	r5, sb
0x00103e:	ldr     	r2, [r5, #0x78]
0x001040:	lsls    	r0, r0, #9
0x001042:	bl      	#0x9124
0x001046:	str     	r4, [r5, #0x78]
0x001048:	movs    	r1, #0
0x00104a:	str     	r1, [sp]
0x00104c:	str     	r1, [sp, #4]
0x00104e:	movs    	r2, #0
0x001050:	movs    	r1, #0x2c
0x001052:	adds    	r3, r4, #0
0x001054:	movs    	r0, #0xf1
0x001056:	lsls    	r0, r0, #9
0x001058:	str     	r2, [sp, #8]
0x00105a:	bl      	#0x9124
0x00105e:	movs    	r2, #0
0x001060:	movs    	r1, #0
0x001062:	str     	r2, [sp, #8]
0x001064:	ldr     	r2, [pc, #0x18]
0x001066:	str     	r1, [sp]
0x001068:	str     	r1, [sp, #4]
0x00106a:	adds    	r3, r4, #0
0x00106c:	add     	r2, pc
0x00106e:	movs    	r1, #0x33
0x001070:	movs    	r0, #0xf1
0x001072:	lsls    	r0, r0, #9
0x001074:	bl      	#0x9124
0x001078:	add     	sp, #0xc
0x00107a:	pop     	{r4, r5, pc}

; ===== candidate_001084 =====
0x001084:	push    	{r4, r5, r6, r7, lr}
0x001086:	sub     	sp, #0x14
0x001088:	movs    	r6, #0
0x00108a:	movs    	r2, #0
0x00108c:	movs    	r1, #0
0x00108e:	str     	r2, [sp, #8]
0x001090:	adds    	r3, r6, #0
0x001092:	adds    	r4, r0, #0
0x001094:	adds    	r2, r0, #0
0x001096:	str     	r1, [sp]
0x001098:	str     	r1, [sp, #4]
0x00109a:	movs    	r1, #0x44
0x00109c:	movs    	r0, #0xf1
0x00109e:	movs    	r5, #0
0x0010a0:	lsls    	r0, r0, #9
0x0010a2:	bl      	#0x9124
0x0010a6:	movs    	r1, #0
0x0010a8:	str     	r1, [sp]
0x0010aa:	str     	r1, [sp, #4]
0x0010ac:	movs    	r2, #0
0x0010ae:	str     	r2, [sp, #8]
0x0010b0:	movs    	r1, #0x45
0x0010b2:	adds    	r3, r6, #0
0x0010b4:	movs    	r0, #0xf1
0x0010b6:	lsls    	r0, r0, #9
0x0010b8:	ldr     	r2, [r4, #8]
0x0010ba:	bl      	#0x9124
0x0010be:	movs    	r1, #0
0x0010c0:	str     	r1, [sp]
0x0010c2:	str     	r1, [sp, #4]
0x0010c4:	str     	r0, [sp, #0x10]
0x0010c6:	movs    	r2, #0
0x0010c8:	str     	r2, [sp, #8]
0x0010ca:	movs    	r0, #0xf1
0x0010cc:	movs    	r1, #0x45
0x0010ce:	adds    	r3, r6, #0
0x0010d0:	lsls    	r0, r0, #9
0x0010d2:	ldr     	r2, [r4, #8]
0x0010d4:	bl      	#0x9124
0x0010d8:	movs    	r1, #0
0x0010da:	str     	r1, [sp]
0x0010dc:	str     	r1, [sp, #4]
0x0010de:	str     	r0, [sp, #0xc]
0x0010e0:	movs    	r2, #0
0x0010e2:	str     	r2, [sp, #8]
0x0010e4:	movs    	r0, #0xf1
0x0010e6:	movs    	r1, #0x45
0x0010e8:	adds    	r3, r6, #0
0x0010ea:	lsls    	r0, r0, #9
0x0010ec:	ldr     	r2, [r4, #8]
0x0010ee:	bl      	#0x9124
0x0010f2:	movs    	r2, #0
0x0010f4:	movs    	r1, #0
0x0010f6:	str     	r2, [sp, #8]
0x0010f8:	adds    	r6, r0, #0
0x0010fa:	adds    	r2, r0, #0
0x0010fc:	str     	r1, [sp]
0x0010fe:	str     	r1, [sp, #4]
0x001100:	movs    	r1, #0xa
0x001102:	movs    	r0, #0xf1
0x001104:	movs    	r3, #4
0x001106:	lsls    	r0, r0, #9
0x001108:	bl      	#0x9124
0x00110c:	adds    	r7, r0, #0
0x00110e:	cmp     	r6, #0
0x001110:	ble     	#0x1122
0x001112:	adds    	r0, r4, #0
0x001114:	bl      	#0x9994
0x001118:	lsls    	r1, r5, #2
0x00111a:	adds    	r5, #1
0x00111c:	cmp     	r5, r6
0x00111e:	str     	r0, [r7, r1]
0x001120:	blt     	#0x1112
0x001122:	movs    	r1, #0
0x001124:	str     	r1, [sp]
0x001126:	str     	r1, [sp, #4]
0x001128:	movs    	r2, #0
0x00112a:	str     	r2, [sp, #8]
0x00112c:	movs    	r1, #0x46
0x00112e:	movs    	r3, #0
0x001130:	movs    	r0, #0xf1
0x001132:	lsls    	r0, r0, #9
0x001134:	ldr     	r2, [r4, #8]
0x001136:	bl      	#0x9124
0x00113a:	lsls    	r0, r0, #0x18
0x00113c:	asrs    	r0, r0, #0x18
0x00113e:	adds    	r3, r0, #1
0x001140:	beq     	#0x11b4
0x001142:	adds    	r0, #1
0x001144:	lsls    	r6, r0, #0x18
0x001146:	movs    	r1, #0
0x001148:	movs    	r2, #0
0x00114a:	str     	r2, [sp, #8]
0x00114c:	str     	r1, [sp]
0x00114e:	str     	r1, [sp, #4]
0x001150:	asrs    	r6, r6, #0x18
0x001152:	adds    	r2, r6, #0
0x001154:	movs    	r1, #0xa
0x001156:	movs    	r0, #0xf1
0x001158:	movs    	r3, #4
0x00115a:	lsls    	r0, r0, #9
0x00115c:	bl      	#0x9124
0x001160:	ldr     	r5, [pc, #0x84]
0x001162:	movs    	r2, #0
0x001164:	add     	r5, sb
0x001166:	str     	r0, [r5, #0x28]
0x001168:	movs    	r1, #0
0x00116a:	ldr     	r3, [pc, #0x80]
0x00116c:	str     	r1, [sp]
0x00116e:	str     	r1, [sp, #4]
0x001170:	str     	r2, [sp, #8]
0x001172:	add     	r3, pc
0x001174:	ldr     	r2, [pc, #0x78]
0x001176:	add     	r2, pc
0x001178:	movs    	r1, #0x35
0x00117a:	movs    	r0, #0xf1
0x00117c:	lsls    	r0, r0, #9
0x00117e:	bl      	#0x9124
0x001182:	ldr     	r1, [r5, #0x28]
0x001184:	movs    	r5, #1
0x001186:	cmp     	r6, #1
0x001188:	str     	r0, [r1]
0x00118a:	ble     	#0x11b4
0x00118c:	movs    	r1, #0
0x00118e:	str     	r1, [sp]
0x001190:	str     	r1, [sp, #4]
0x001192:	movs    	r2, #0
0x001194:	str     	r2, [sp, #8]
0x001196:	movs    	r1, #0x47
0x001198:	movs    	r3, #0
0x00119a:	movs    	r0, #0xf1
0x00119c:	lsls    	r0, r0, #9
0x00119e:	ldr     	r2, [r4, #8]
0x0011a0:	bl      	#0x9124
0x0011a4:	ldr     	r2, [pc, #0x40]
0x0011a6:	lsls    	r1, r5, #2
0x0011a8:	add     	r2, sb
0x0011aa:	ldr     	r2, [r2, #0x28]
0x0011ac:	adds    	r5, #1
0x0011ae:	cmp     	r5, r6
0x0011b0:	str     	r0, [r2, r1]

; ===== candidate_0011f8 =====
0x0011f8:	push    	{r4, r5, r6, r7, lr}
0x0011fa:	sub     	sp, #0xc
0x0011fc:	movs    	r1, #0
0x0011fe:	movs    	r2, #0
0x001200:	str     	r2, [sp, #8]
0x001202:	str     	r1, [sp]
0x001204:	str     	r1, [sp, #4]
0x001206:	movs    	r7, #0xf1
0x001208:	movs    	r6, #0
0x00120a:	adds    	r3, r6, #0
0x00120c:	lsls    	r7, r7, #9
0x00120e:	movs    	r1, #0x44
0x001210:	adds    	r2, r0, #0
0x001212:	movs    	r5, #0
0x001214:	adds    	r4, r0, #0
0x001216:	adds    	r0, r7, #0
0x001218:	bl      	#0x9124
0x00121c:	ldr     	r0, [r4]
0x00121e:	cmp     	r0, #0x19
0x001220:	bne     	#0x1274
0x001222:	movs    	r1, #0
0x001224:	str     	r1, [sp]
0x001226:	str     	r1, [sp, #4]
0x001228:	movs    	r2, #0
0x00122a:	str     	r2, [sp, #8]
0x00122c:	movs    	r1, #0x45
0x00122e:	adds    	r3, r6, #0
0x001230:	adds    	r0, r7, #0
0x001232:	ldr     	r2, [r4, #8]
0x001234:	bl      	#0x9124
0x001238:	ldr     	r1, [pc, #0x9c]
0x00123a:	movs    	r2, #0
0x00123c:	add     	r1, sb
0x00123e:	str     	r0, [r1, #0x3c]
0x001240:	movs    	r1, #0
0x001242:	str     	r1, [sp]
0x001244:	str     	r1, [sp, #4]
0x001246:	movs    	r1, #0x45
0x001248:	str     	r2, [sp, #8]
0x00124a:	adds    	r3, r6, #0
0x00124c:	adds    	r0, r7, #0
0x00124e:	ldr     	r2, [r4, #8]
0x001250:	bl      	#0x9124
0x001254:	ldr     	r1, [pc, #0x84]
0x001256:	movs    	r2, #0
0x001258:	add     	r1, sb
0x00125a:	str     	r0, [r1, #0xc]
0x00125c:	movs    	r1, #0
0x00125e:	str     	r1, [sp]
0x001260:	str     	r1, [sp, #4]
0x001262:	movs    	r1, #0x45
0x001264:	str     	r2, [sp, #8]
0x001266:	adds    	r3, r6, #0
0x001268:	adds    	r0, r7, #0
0x00126a:	ldr     	r2, [r4, #8]
0x00126c:	bl      	#0x9124
0x001270:	adds    	r6, r0, #0
0x001272:	b       	#0x128c
0x001274:	movs    	r1, #0
0x001276:	str     	r1, [sp]
0x001278:	str     	r1, [sp, #4]
0x00127a:	movs    	r2, #0
0x00127c:	str     	r2, [sp, #8]
0x00127e:	movs    	r1, #0xe2
0x001280:	adds    	r3, r6, #0
0x001282:	adds    	r0, r7, #0
0x001284:	ldr     	r2, [r4, #8]
0x001286:	bl      	#0x9124
0x00128a:	adds    	r6, r0, #0
0x00128c:	movs    	r1, #0
0x00128e:	movs    	r2, #0
0x001290:	str     	r2, [sp, #8]
0x001292:	str     	r1, [sp]
0x001294:	str     	r1, [sp, #4]
0x001296:	movs    	r1, #0xa
0x001298:	adds    	r2, r6, #0
0x00129a:	movs    	r3, #4
0x00129c:	adds    	r0, r7, #0
0x00129e:	bl      	#0x9124
0x0012a2:	adds    	r7, r0, #0
0x0012a4:	cmp     	r6, #0
0x0012a6:	ble     	#0x12b8
0x0012a8:	adds    	r0, r4, #0
0x0012aa:	bl      	#0x9b2c
0x0012ae:	lsls    	r1, r5, #2
0x0012b0:	adds    	r5, #1
0x0012b2:	cmp     	r5, r6
0x0012b4:	str     	r0, [r7, r1]
0x0012b6:	blt     	#0x12a8
0x0012b8:	ldr     	r0, [r4]
0x0012ba:	cmp     	r0, #0x19
0x0012bc:	bne     	#0x12ca
0x0012be:	movs    	r1, #0xd0
0x0012c0:	adds    	r0, r7, #0
0x0012c2:	bl      	#0x760c
0x0012c6:	add     	sp, #0xc
0x0012c8:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0012e0 =====
0x0012e0:	push    	{r4, r5, r6, r7, lr}
0x0012e2:	ldr     	r1, [pc, #0x2c8]
0x0012e4:	sub     	sp, #0xc
0x0012e6:	adds    	r4, r0, #0
0x0012e8:	add     	r1, pc
0x0012ea:	ldr     	r5, [pc, #0x2c4]
0x0012ec:	add     	r5, sb
0x0012ee:	ldr     	r2, [r5]
0x0012f0:	blx     	r2
0x0012f2:	cmp     	r0, #0
0x0012f4:	bne     	#0x12fe
0x0012f6:	bl      	#0x9fe8
0x0012fa:	add     	sp, #0xc
0x0012fc:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0015d0 =====
0x0015d0:	push    	{r4, r5, r6, r7, lr}
0x0015d2:	adds    	r4, r0, #0
0x0015d4:	ldr     	r0, [pc, #0xb8]
0x0015d6:	sub     	sp, #0xc
0x0015d8:	add     	r0, sb
0x0015da:	ldr     	r0, [r0, #4]
0x0015dc:	cmp     	r0, #0
0x0015de:	bne     	#0x168a
0x0015e0:	movs    	r1, #0
0x0015e2:	movs    	r2, #0
0x0015e4:	str     	r2, [sp, #8]
0x0015e6:	str     	r1, [sp]
0x0015e8:	str     	r1, [sp, #4]
0x0015ea:	ldr     	r5, [pc, #0xa8]
0x0015ec:	movs    	r1, #3
0x0015ee:	movs    	r2, #0xd
0x0015f0:	adds    	r0, r5, #0
0x0015f2:	ldr     	r3, [r4, #4]
0x0015f4:	bl      	#0x9124
0x0015f8:	movs    	r1, #0
0x0015fa:	movs    	r2, #0
0x0015fc:	str     	r2, [sp, #8]
0x0015fe:	str     	r1, [sp]
0x001600:	str     	r1, [sp, #4]
0x001602:	movs    	r1, #3
0x001604:	movs    	r2, #0xe
0x001606:	adds    	r0, r5, #0
0x001608:	ldr     	r3, [r4, #8]
0x00160a:	bl      	#0x9124
0x00160e:	movs    	r1, #0
0x001610:	movs    	r2, #0
0x001612:	str     	r2, [sp, #8]
0x001614:	str     	r1, [sp]
0x001616:	str     	r1, [sp, #4]
0x001618:	movs    	r6, #0
0x00161a:	adds    	r3, r6, #0
0x00161c:	movs    	r1, #0x18
0x00161e:	movs    	r2, #0xf
0x001620:	adds    	r0, r5, #0
0x001622:	bl      	#0x9124
0x001626:	subs    	r7, r5, #2
0x001628:	cmp     	r0, #0
0x00162a:	beq     	#0x1658
0x00162c:	movs    	r1, #0
0x00162e:	movs    	r2, #0
0x001630:	str     	r2, [sp, #8]
0x001632:	str     	r1, [sp]
0x001634:	str     	r1, [sp, #4]
0x001636:	movs    	r1, #0x18
0x001638:	movs    	r2, #0xf
0x00163a:	adds    	r3, r6, #0
0x00163c:	adds    	r0, r5, #0
0x00163e:	bl      	#0x9124
0x001642:	movs    	r2, #0
0x001644:	movs    	r1, #0
0x001646:	str     	r2, [sp, #8]
0x001648:	adds    	r2, r0, #0
0x00164a:	str     	r1, [sp]
0x00164c:	str     	r1, [sp, #4]
0x00164e:	movs    	r1, #9
0x001650:	adds    	r0, r7, #0
0x001652:	adds    	r3, r6, #0
0x001654:	bl      	#0x9124
0x001658:	movs    	r2, #0
0x00165a:	movs    	r1, #0
0x00165c:	ldr     	r3, [pc, #0x38]
0x00165e:	str     	r1, [sp]
0x001660:	str     	r1, [sp, #4]
0x001662:	str     	r2, [sp, #8]
0x001664:	add     	r3, pc
0x001666:	movs    	r1, #0x35
0x001668:	adds    	r0, r7, #0
0x00166a:	ldr     	r2, [r4]
0x00166c:	bl      	#0x9124
0x001670:	movs    	r1, #0
0x001672:	movs    	r2, #0
0x001674:	str     	r2, [sp, #8]
0x001676:	str     	r1, [sp]
0x001678:	str     	r1, [sp, #4]
0x00167a:	movs    	r1, #3
0x00167c:	movs    	r2, #0xf
0x00167e:	adds    	r3, r0, #0
0x001680:	adds    	r0, r5, #0
0x001682:	bl      	#0x9124
0x001686:	bl      	#0x65ac
0x00168a:	add     	sp, #0xc
0x00168c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00169c =====
0x00169c:	push    	{r4, r5, r6, lr}
0x00169e:	sub     	sp, #0x10
0x0016a0:	movs    	r1, #0
0x0016a2:	movs    	r2, #0
0x0016a4:	str     	r2, [sp, #8]
0x0016a6:	str     	r1, [sp]
0x0016a8:	str     	r1, [sp, #4]
0x0016aa:	movs    	r6, #0xf1
0x0016ac:	movs    	r4, #0
0x0016ae:	adds    	r3, r4, #0
0x0016b0:	lsls    	r6, r6, #9
0x0016b2:	movs    	r1, #0x9c
0x0016b4:	movs    	r2, #0x12
0x0016b6:	adds    	r5, r0, #0
0x0016b8:	adds    	r0, r6, #0
0x0016ba:	bl      	#0x9124
0x0016be:	movs    	r1, #0
0x0016c0:	str     	r1, [sp]
0x0016c2:	str     	r1, [sp, #4]
0x0016c4:	movs    	r2, #0
0x0016c6:	movs    	r1, #0xbd
0x0016c8:	adds    	r3, r4, #0
0x0016ca:	adds    	r0, r6, #0
0x0016cc:	str     	r2, [sp, #8]
0x0016ce:	bl      	#0x9124
0x0016d2:	cmp     	r5, #0
0x0016d4:	bne     	#0x1788
0x0016d6:	movs    	r1, #0
0x0016d8:	str     	r1, [sp]
0x0016da:	str     	r1, [sp, #4]
0x0016dc:	movs    	r2, #0
0x0016de:	ldr     	r5, [pc, #0xe4]
0x0016e0:	str     	r2, [sp, #8]
0x0016e2:	movs    	r1, #0x11
0x0016e4:	movs    	r3, #4
0x0016e6:	add     	r5, sb
0x0016e8:	ldr     	r2, [r5, #8]
0x0016ea:	adds    	r0, r6, #0
0x0016ec:	bl      	#0x9124
0x0016f0:	cmp     	r0, #0
0x0016f2:	ble     	#0x1764
0x0016f4:	ldr     	r0, [r5, #0xc]
0x0016f6:	ldr     	r1, [r5, #8]
0x0016f8:	lsls    	r0, r0, #2
0x0016fa:	ldr     	r0, [r1, r0]
0x0016fc:	cmp     	r0, #0
0x0016fe:	beq     	#0x1764
0x001700:	movs    	r1, #0
0x001702:	movs    	r2, #0
0x001704:	str     	r2, [sp, #8]
0x001706:	str     	r1, [sp]
0x001708:	str     	r1, [sp, #4]
0x00170a:	movs    	r1, #0xe1
0x00170c:	movs    	r2, #0x18
0x00170e:	adds    	r3, r4, #0
0x001710:	adds    	r0, r6, #0
0x001712:	bl      	#0x9124
0x001716:	ldr     	r1, [r5, #0xc]
0x001718:	ldr     	r2, [r5, #8]
0x00171a:	lsls    	r1, r1, #2
0x00171c:	ldr     	r1, [r2, r1]
0x00171e:	ldr     	r0, [r0, #8]
0x001720:	ldr     	r1, [r1, #4]
0x001722:	cmp     	r0, r1
0x001724:	bne     	#0x1768
0x001726:	movs    	r1, #0
0x001728:	movs    	r2, #0
0x00172a:	str     	r2, [sp, #8]
0x00172c:	str     	r1, [sp]
0x00172e:	str     	r1, [sp, #4]
0x001730:	movs    	r1, #0xe1
0x001732:	movs    	r2, #0x18
0x001734:	adds    	r3, r4, #0
0x001736:	adds    	r0, r6, #0
0x001738:	bl      	#0x9124
0x00173c:	ldr     	r1, [r5, #0xc]
0x00173e:	ldr     	r2, [r5, #8]
0x001740:	lsls    	r1, r1, #2
0x001742:	ldr     	r1, [r2, r1]
0x001744:	ldr     	r0, [r0, #0xc]
0x001746:	ldr     	r1, [r1, #8]
0x001748:	cmp     	r0, r1
0x00174a:	bne     	#0x1768
0x00174c:	movs    	r2, #0
0x00174e:	movs    	r1, #0
0x001750:	str     	r2, [sp, #8]
0x001752:	ldr     	r2, [pc, #0x74]
0x001754:	str     	r1, [sp]
0x001756:	str     	r1, [sp, #4]
0x001758:	adds    	r3, r4, #0
0x00175a:	add     	r2, pc
0x00175c:	movs    	r1, #0x33
0x00175e:	adds    	r0, r6, #0
0x001760:	bl      	#0x9124
0x001764:	add     	sp, #0x10
0x001766:	pop     	{r4, r5, r6, pc}

; ===== candidate_0017cc =====
0x0017cc:	push    	{r4, r5, r6, r7, lr}
0x0017ce:	sub     	sp, #0x14
0x0017d0:	adds    	r5, r0, #0
0x0017d2:	movs    	r0, #0
0x0017d4:	movs    	r2, #0
0x0017d6:	movs    	r1, #0
0x0017d8:	str     	r1, [sp, #4]
0x0017da:	str     	r2, [sp, #8]
0x0017dc:	movs    	r4, #0xf1
0x0017de:	movs    	r7, #0
0x0017e0:	adds    	r3, r7, #0
0x0017e2:	lsls    	r4, r4, #9
0x0017e4:	adds    	r2, r5, #0
0x0017e6:	movs    	r1, #0x44
0x0017e8:	str     	r0, [sp, #0x10]
0x0017ea:	str     	r0, [sp]
0x0017ec:	movs    	r6, #0
0x0017ee:	adds    	r0, r4, #0
0x0017f0:	bl      	#0x9124
0x0017f4:	movs    	r1, #0
0x0017f6:	str     	r1, [sp]
0x0017f8:	str     	r1, [sp, #4]
0x0017fa:	movs    	r2, #0
0x0017fc:	str     	r2, [sp, #8]
0x0017fe:	movs    	r1, #0x46
0x001800:	adds    	r3, r7, #0
0x001802:	adds    	r0, r4, #0
0x001804:	ldr     	r2, [r5, #8]
0x001806:	bl      	#0x9124
0x00180a:	lsls    	r0, r0, #0x18
0x00180c:	asrs    	r0, r0, #0x18
0x00180e:	adds    	r3, r0, #1
0x001810:	beq     	#0x181a
0x001812:	adds    	r0, r5, #0
0x001814:	bl      	#0x9b2c
0x001818:	str     	r0, [sp, #0x10]
0x00181a:	movs    	r1, #0
0x00181c:	str     	r1, [sp]
0x00181e:	str     	r1, [sp, #4]
0x001820:	movs    	r2, #0
0x001822:	str     	r2, [sp, #8]
0x001824:	movs    	r1, #0x46
0x001826:	movs    	r3, #0
0x001828:	movs    	r0, #0xf1
0x00182a:	lsls    	r0, r0, #9
0x00182c:	ldr     	r2, [r5, #8]
0x00182e:	bl      	#0x9124
0x001832:	adds    	r7, r0, #0
0x001834:	cmp     	r0, #0
0x001836:	ble     	#0x1876
0x001838:	movs    	r1, #0
0x00183a:	str     	r1, [sp]
0x00183c:	str     	r1, [sp, #4]
0x00183e:	movs    	r2, #0
0x001840:	movs    	r1, #0x13
0x001842:	movs    	r4, #0
0x001844:	movs    	r3, #0
0x001846:	movs    	r0, #0xf1
0x001848:	lsls    	r0, r0, #9
0x00184a:	str     	r2, [sp, #8]
0x00184c:	bl      	#0x9124
0x001850:	adds    	r6, r0, #0
0x001852:	adds    	r0, r5, #0
0x001854:	bl      	#0x9b2c
0x001858:	movs    	r1, #0
0x00185a:	adds    	r3, r0, #0
0x00185c:	movs    	r2, #0
0x00185e:	str     	r2, [sp, #8]
0x001860:	str     	r1, [sp]
0x001862:	str     	r1, [sp, #4]
0x001864:	movs    	r1, #0x36
0x001866:	adds    	r2, r6, #0
0x001868:	movs    	r0, #0xf1
0x00186a:	lsls    	r0, r0, #9
0x00186c:	bl      	#0x9124
0x001870:	adds    	r4, #1
0x001872:	cmp     	r4, r7
0x001874:	blt     	#0x1852
0x001876:	movs    	r1, #0
0x001878:	str     	r1, [sp]
0x00187a:	str     	r1, [sp, #4]
0x00187c:	movs    	r2, #0
0x00187e:	movs    	r1, #0x2c
0x001880:	movs    	r3, #0
0x001882:	movs    	r0, #0xf1
0x001884:	lsls    	r0, r0, #9
0x001886:	str     	r2, [sp, #8]
0x001888:	bl      	#0x9124
0x00188c:	adds    	r1, r6, #0
0x00188e:	ldr     	r0, [sp, #0x10]
0x001890:	bl      	#0x7104
0x001894:	add     	sp, #0x14
0x001896:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_001898 =====
0x001898:	push    	{r4, r5, r6, r7, lr}
0x00189a:	sub     	sp, #0x9c
0x00189c:	movs    	r1, #0
0x00189e:	str     	r1, [sp]
0x0018a0:	str     	r1, [sp, #4]
0x0018a2:	movs    	r4, #0xf1
0x0018a4:	movs    	r6, #0
0x0018a6:	movs    	r2, #0
0x0018a8:	adds    	r3, r6, #0
0x0018aa:	lsls    	r4, r4, #9
0x0018ac:	movs    	r1, #0x1c
0x0018ae:	movs    	r5, #0x19
0x0018b0:	adds    	r0, r4, #0
0x0018b2:	str     	r2, [sp, #8]
0x0018b4:	bl      	#0x9124
0x0018b8:	movs    	r1, #0
0x0018ba:	movs    	r2, #0
0x0018bc:	str     	r2, [sp, #8]
0x0018be:	str     	r1, [sp]
0x0018c0:	str     	r1, [sp, #4]
0x0018c2:	adds    	r7, r0, #0
0x0018c4:	subs    	r7, #0xc
0x0018c6:	movs    	r1, #0xe1
0x0018c8:	movs    	r2, #0xed
0x0018ca:	adds    	r3, r6, #0
0x0018cc:	adds    	r0, r4, #0
0x0018ce:	bl      	#0x9124
0x0018d2:	cmp     	r0, #0
0x0018d4:	ble     	#0x19ba
0x0018d6:	movs    	r1, #0
0x0018d8:	str     	r1, [sp]
0x0018da:	str     	r1, [sp, #4]
0x0018dc:	movs    	r1, #0xff
0x0018de:	movs    	r2, #0
0x0018e0:	adds    	r1, #0x25
0x0018e2:	adds    	r3, r6, #0
0x0018e4:	adds    	r0, r4, #0
0x0018e6:	str     	r2, [sp, #8]
0x0018e8:	bl      	#0x9124
0x0018ec:	movs    	r1, #0
0x0018ee:	str     	r1, [sp]
0x0018f0:	str     	r1, [sp, #4]
0x0018f2:	movs    	r2, #0
0x0018f4:	movs    	r1, #0x40
0x0018f6:	adds    	r3, r6, #0
0x0018f8:	adds    	r0, r4, #0
0x0018fa:	str     	r2, [sp, #8]
0x0018fc:	bl      	#0x9124
0x001900:	ldr     	r0, [pc, #0x3dc]
0x001902:	add     	r0, pc
0x001904:	str     	r0, [sp, #0x54]
0x001906:	add     	r1, sp, #0x5c
0x001908:	str     	r1, [sp, #4]
0x00190a:	movs    	r0, #0
0x00190c:	add     	r2, sp, #0x58
0x00190e:	str     	r2, [sp, #8]
0x001910:	str     	r0, [sp]
0x001912:	movs    	r1, #0x2a
0x001914:	adds    	r3, r6, #0
0x001916:	adds    	r0, r4, #0
0x001918:	ldr     	r2, [sp, #0x54]
0x00191a:	bl      	#0x9124
0x00191e:	movs    	r1, #0
0x001920:	str     	r1, [sp]
0x001922:	str     	r1, [sp, #4]
0x001924:	movs    	r2, #0
0x001926:	movs    	r1, #0x1c
0x001928:	movs    	r4, #0x1a
0x00192a:	adds    	r3, r6, #0
0x00192c:	movs    	r0, #0xf1
0x00192e:	lsls    	r0, r0, #9
0x001930:	str     	r2, [sp, #8]
0x001932:	bl      	#0x9124
0x001936:	movs    	r2, #0
0x001938:	str     	r0, [sp]
0x00193a:	movs    	r0, #0xf1
0x00193c:	adds    	r3, r6, #0
0x00193e:	movs    	r1, #0x32
0x001940:	lsls    	r0, r0, #9
0x001942:	str     	r2, [sp, #8]
0x001944:	str     	r4, [sp, #4]
0x001946:	bl      	#0x9124
0x00194a:	movs    	r1, #0
0x00194c:	str     	r1, [sp]
0x00194e:	str     	r1, [sp, #4]
0x001950:	movs    	r2, #0
0x001952:	movs    	r1, #0x1c
0x001954:	adds    	r3, r6, #0
0x001956:	movs    	r0, #0xf1
0x001958:	lsls    	r0, r0, #9
0x00195a:	str     	r2, [sp, #8]
0x00195c:	bl      	#0x9124
0x001960:	lsrs    	r1, r0, #0x1f
0x001962:	adds    	r0, r1, r0
0x001964:	asrs    	r0, r0, #1
0x001966:	movs    	r1, #0x14
0x001968:	str     	r1, [sp, #4]
0x00196a:	str     	r0, [sp]
0x00196c:	movs    	r2, #0
0x00196e:	movs    	r0, #0xf1
0x001970:	movs    	r1, #0x2f
0x001972:	movs    	r3, #3
0x001974:	lsls    	r0, r0, #9
0x001976:	str     	r2, [sp, #8]
0x001978:	bl      	#0x9124
0x00197c:	cmp     	r0, #1
0x00197e:	bne     	#0x1988
0x001980:	ldr     	r0, [pc, #0x360]
0x001982:	add     	r0, sb
0x001984:	str     	r6, [r0, #0x14]
0x001986:	b       	#0x19ec
0x001988:	movs    	r1, #0
0x00198a:	str     	r1, [sp]
0x00198c:	str     	r1, [sp, #4]
0x00198e:	movs    	r2, #0
0x001990:	movs    	r1, #0x1c
0x001992:	adds    	r3, r6, #0
0x001994:	movs    	r0, #0xf1
0x001996:	lsls    	r0, r0, #9
0x001998:	str     	r2, [sp, #8]
0x00199a:	bl      	#0x9124
0x00199e:	lsrs    	r1, r0, #0x1f
0x0019a0:	adds    	r0, r1, r0
0x0019a2:	movs    	r1, #0
0x0019a4:	asrs    	r0, r0, #1
0x0019a6:	str     	r0, [sp, #0x98]
0x0019a8:	str     	r1, [sp]
0x0019aa:	str     	r1, [sp, #4]
0x0019ac:	movs    	r2, #0
0x0019ae:	movs    	r1, #0x1c
0x0019b0:	movs    	r0, #0xf1
0x0019b2:	adds    	r3, r6, #0
0x0019b4:	lsls    	r0, r0, #9
0x0019b6:	str     	r2, [sp, #8]
0x0019b8:	b       	#0x19bc
0x0019ba:	b       	#0x2118
0x0019bc:	bl      	#0x9124
0x0019c0:	lsrs    	r1, r0, #0x1f
0x0019c2:	adds    	r0, r1, r0
0x0019c4:	asrs    	r0, r0, #1
0x0019c6:	mov     	ip, r0

; ===== candidate_002290 =====
0x002290:	push    	{r4, r5, r6, r7, lr}
0x002292:	sub     	sp, #0x34
0x002294:	movs    	r1, #0
0x002296:	str     	r1, [sp]
0x002298:	str     	r1, [sp, #4]
0x00229a:	ldr     	r7, [pc, #0x150]
0x00229c:	movs    	r2, #0
0x00229e:	movs    	r1, #0xff
0x0022a0:	movs    	r4, #0xf1
0x0022a2:	movs    	r6, #0
0x0022a4:	adds    	r3, r6, #0
0x0022a6:	lsls    	r4, r4, #9
0x0022a8:	adds    	r1, #0x10
0x0022aa:	str     	r2, [sp, #8]
0x0022ac:	add     	r7, sb
0x0022ae:	ldr     	r2, [r7, #0x44]
0x0022b0:	adds    	r0, r4, #0
0x0022b2:	bl      	#0x9124
0x0022b6:	movs    	r1, #0
0x0022b8:	movs    	r2, #0
0x0022ba:	str     	r2, [sp, #8]
0x0022bc:	str     	r1, [sp]
0x0022be:	str     	r1, [sp, #4]
0x0022c0:	movs    	r1, #0xe1
0x0022c2:	movs    	r2, #0xed
0x0022c4:	adds    	r5, r0, #0
0x0022c6:	adds    	r3, r6, #0
0x0022c8:	adds    	r0, r4, #0
0x0022ca:	bl      	#0x9124
0x0022ce:	cmp     	r0, #0
0x0022d0:	ble     	#0x23b6
0x0022d2:	movs    	r1, #0
0x0022d4:	str     	r1, [sp]
0x0022d6:	str     	r1, [sp, #4]
0x0022d8:	movs    	r1, #0xff
0x0022da:	movs    	r2, #0
0x0022dc:	adds    	r1, #0x25
0x0022de:	adds    	r3, r6, #0
0x0022e0:	adds    	r0, r4, #0
0x0022e2:	str     	r2, [sp, #8]
0x0022e4:	bl      	#0x9124
0x0022e8:	add     	r2, sp, #0x2c
0x0022ea:	add     	r1, sp, #0x30
0x0022ec:	movs    	r0, #0
0x0022ee:	str     	r0, [sp]
0x0022f0:	str     	r1, [sp, #4]
0x0022f2:	str     	r2, [sp, #8]
0x0022f4:	ldr     	r1, [r7, #0x44]
0x0022f6:	lsls    	r0, r5, #2
0x0022f8:	ldr     	r2, [r1, r0]
0x0022fa:	movs    	r1, #0x2a
0x0022fc:	adds    	r3, r6, #0
0x0022fe:	adds    	r0, r4, #0
0x002300:	bl      	#0x9124
0x002304:	movs    	r1, #0
0x002306:	str     	r1, [sp]
0x002308:	str     	r1, [sp, #4]
0x00230a:	ldr     	r4, [sp, #0x30]
0x00230c:	movs    	r2, #0
0x00230e:	str     	r2, [sp, #8]
0x002310:	movs    	r1, #0x11
0x002312:	movs    	r3, #4
0x002314:	movs    	r0, #0xf1
0x002316:	adds    	r4, #0x28
0x002318:	lsls    	r0, r0, #9
0x00231a:	ldr     	r2, [r7, #0x44]
0x00231c:	bl      	#0x9124
0x002320:	ldr     	r1, [sp, #0x2c]
0x002322:	movs    	r2, #0
0x002324:	muls    	r0, r1, r0
0x002326:	movs    	r1, #0
0x002328:	adds    	r5, r0, #0
0x00232a:	adds    	r5, #0xa
0x00232c:	str     	r1, [sp]
0x00232e:	str     	r1, [sp, #4]
0x002330:	movs    	r1, #0x1c
0x002332:	adds    	r3, r6, #0
0x002334:	movs    	r0, #0xf1
0x002336:	lsls    	r0, r0, #9
0x002338:	str     	r2, [sp, #8]
0x00233a:	bl      	#0x9124
0x00233e:	subs    	r0, r0, r4
0x002340:	lsrs    	r1, r0, #0x1f
0x002342:	adds    	r0, r1, r0
0x002344:	asrs    	r0, r0, #1
0x002346:	str     	r0, [sp, #0x24]
0x002348:	movs    	r1, #0
0x00234a:	str     	r1, [sp]
0x00234c:	str     	r1, [sp, #4]
0x00234e:	movs    	r2, #0
0x002350:	movs    	r1, #0x1d
0x002352:	movs    	r0, #0xf1
0x002354:	adds    	r3, r6, #0
0x002356:	lsls    	r0, r0, #9
0x002358:	str     	r2, [sp, #8]
0x00235a:	bl      	#0x9124
0x00235e:	subs    	r0, r0, r5
0x002360:	lsrs    	r1, r0, #0x1f
0x002362:	adds    	r0, r1, r0
0x002364:	asrs    	r0, r0, #1
0x002366:	str     	r0, [sp, #0x28]
0x002368:	movs    	r1, #0
0x00236a:	movs    	r2, #0
0x00236c:	str     	r2, [sp, #8]
0x00236e:	str     	r1, [sp]
0x002370:	str     	r1, [sp, #4]
0x002372:	movs    	r1, #0x14
0x002374:	movs    	r2, #0xef
0x002376:	movs    	r0, #0xf1
0x002378:	adds    	r3, r6, #0
0x00237a:	lsls    	r0, r0, #9
0x00237c:	bl      	#0x9124
0x002380:	ldr     	r0, [r7, #0x44]
0x002382:	movs    	r1, #0
0x002384:	str     	r0, [sp, #0xc]
0x002386:	ldr     	r0, [sp, #0x24]
0x002388:	movs    	r2, #0
0x00238a:	str     	r0, [sp, #0x10]
0x00238c:	ldr     	r0, [sp, #0x28]
0x00238e:	str     	r1, [sp, #4]
0x002390:	str     	r0, [sp, #0x14]
0x002392:	ldr     	r0, [pc, #0x58]
0x002394:	str     	r2, [sp, #8]
0x002396:	add     	r0, sb
0x002398:	adds    	r0, #0x40
0x00239a:	str     	r0, [sp, #0x20]
0x00239c:	str     	r1, [sp]
0x00239e:	movs    	r1, #0x2b
0x0023a0:	movs    	r0, #0xf1
0x0023a2:	adds    	r3, r6, #0
0x0023a4:	lsls    	r0, r0, #9
0x0023a6:	add     	r2, sp, #0xc
0x0023a8:	str     	r4, [sp, #0x18]
0x0023aa:	str     	r5, [sp, #0x1c]
0x0023ac:	bl      	#0x9124
0x0023b0:	movs    	r2, #0
0x0023b2:	movs    	r1, #0
0x0023b4:	b       	#0x23b8
0x0023b6:	b       	#0x23e6
0x0023b8:	str     	r1, [sp]
0x0023ba:	str     	r1, [sp, #4]

; ===== candidate_0023f0 =====
0x0023f0:	push    	{r4, r5, r6, r7, lr}
0x0023f2:	sub     	sp, #0x3c
0x0023f4:	ldr     	r5, [r0]
0x0023f6:	str     	r1, [sp, #0x30]
0x0023f8:	adds    	r4, r0, #0
0x0023fa:	ldrb    	r0, [r0, #0x10]
0x0023fc:	adds    	r7, r2, #0
0x0023fe:	cmp     	r0, #1
0x002400:	bne     	#0x240a
0x002402:	movs    	r0, #0xf8
0x002404:	movs    	r1, #0xfc
0x002406:	movs    	r2, #0xc8
0x002408:	b       	#0x2410
0x00240a:	movs    	r0, #0x96
0x00240c:	movs    	r1, #0x96
0x00240e:	movs    	r2, #0x96
0x002410:	cmp     	r5, #0
0x002412:	bne     	#0x2418
0x002414:	ldr     	r3, [r4, #0x24]
0x002416:	ldr     	r5, [r3, #4]
0x002418:	movs    	r6, #0x7c
0x00241a:	ldrsb   	r6, [r6, r4]
0x00241c:	str     	r5, [sp, #0x10]
0x00241e:	ldr     	r3, [sp, #0x30]
0x002420:	str     	r2, [sp, #0x24]
0x002422:	str     	r3, [sp, #0x14]
0x002424:	movs    	r3, #0
0x002426:	str     	r1, [sp, #0x20]
0x002428:	movs    	r1, #0
0x00242a:	movs    	r2, #0
0x00242c:	str     	r1, [sp]
0x00242e:	str     	r1, [sp, #4]
0x002430:	str     	r3, [sp, #0x28]
0x002432:	str     	r0, [sp, #0x1c]
0x002434:	movs    	r0, #0xf1
0x002436:	str     	r2, [sp, #8]
0x002438:	movs    	r1, #0x56
0x00243a:	lsls    	r0, r0, #9
0x00243c:	add     	r2, sp, #0x10
0x00243e:	str     	r3, [sp, #0x2c]
0x002440:	str     	r7, [sp, #0x18]
0x002442:	bl      	#0x9124
0x002446:	add     	r2, sp, #0x34
0x002448:	add     	r1, sp, #0x38
0x00244a:	movs    	r0, #0
0x00244c:	str     	r0, [sp]
0x00244e:	str     	r1, [sp, #4]
0x002450:	str     	r2, [sp, #8]
0x002452:	adds    	r2, r5, #0
0x002454:	movs    	r1, #0x2a
0x002456:	movs    	r0, #0xf1
0x002458:	movs    	r3, #0
0x00245a:	lsls    	r0, r0, #9
0x00245c:	bl      	#0x9124
0x002460:	ldr     	r0, [sp, #0x38]
0x002462:	ldr     	r3, [sp, #0x30]
0x002464:	adds    	r5, r3, r0
0x002466:	cmp     	r6, #0
0x002468:	bne     	#0x2478
0x00246a:	ldr     	r0, [r4, #0x24]
0x00246c:	cmp     	r0, #0
0x00246e:	beq     	#0x24be
0x002470:	movs    	r3, #0xe4
0x002472:	ldrsb   	r6, [r0, r3]
0x002474:	cmp     	r6, #0
0x002476:	beq     	#0x24be
0x002478:	movs    	r2, #0
0x00247a:	movs    	r1, #0
0x00247c:	str     	r2, [sp, #8]
0x00247e:	movs    	r2, #0xff
0x002480:	str     	r1, [sp]
0x002482:	str     	r1, [sp, #4]
0x002484:	movs    	r1, #0xe1
0x002486:	adds    	r2, #0x12
0x002488:	movs    	r3, #0
0x00248a:	movs    	r0, #0xf1
0x00248c:	lsls    	r0, r0, #9
0x00248e:	bl      	#0x9124
0x002492:	str     	r0, [sp, #0x18]
0x002494:	movs    	r0, #0x11
0x002496:	str     	r0, [sp, #0x24]
0x002498:	movs    	r0, #0xc
0x00249a:	str     	r0, [sp, #0x28]
0x00249c:	movs    	r1, #0
0x00249e:	str     	r7, [sp, #0x20]
0x0024a0:	movs    	r2, #0
0x0024a2:	str     	r1, [sp]
0x0024a4:	str     	r1, [sp, #4]
0x0024a6:	subs    	r6, #1
0x0024a8:	movs    	r1, #0x22
0x0024aa:	str     	r2, [sp, #8]
0x0024ac:	movs    	r0, #0xf1
0x0024ae:	movs    	r3, #0
0x0024b0:	lsls    	r0, r0, #9
0x0024b2:	add     	r2, sp, #0x18
0x0024b4:	str     	r6, [sp, #0x2c]
0x0024b6:	str     	r5, [sp, #0x1c]
0x0024b8:	bl      	#0x9124
0x0024bc:	adds    	r5, #0x11
0x0024be:	movs    	r3, #0x10
0x0024c0:	ldrsb   	r1, [r4, r3]
0x0024c2:	movs    	r2, #0
0x0024c4:	str     	r2, [sp, #8]
0x0024c6:	str     	r1, [sp, #4]
0x0024c8:	str     	r7, [sp]
0x0024ca:	movs    	r3, #0x44
0x0024cc:	ldrsb   	r2, [r4, r3]
0x0024ce:	adds    	r5, #2
0x0024d0:	adds    	r3, r5, #0
0x0024d2:	movs    	r1, #0x3d
0x0024d4:	movs    	r0, #0xf1
0x0024d6:	lsls    	r0, r0, #9
0x0024d8:	bl      	#0x9124
0x0024dc:	adds    	r0, r5, #0
0x0024de:	adds    	r0, #0xf
0x0024e0:	add     	sp, #0x3c
0x0024e2:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0024e4 =====
0x0024e4:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0024e6:	adds    	r6, r1, #0
0x0024e8:	ldr     	r5, [pc, #0x35c]
0x0024ea:	adds    	r7, r3, #0
0x0024ec:	sub     	sp, #0x5c
0x0024ee:	add     	r5, pc
0x0024f0:	add     	r2, sp, #0x48
0x0024f2:	add     	r1, sp, #0x4c
0x0024f4:	movs    	r0, #0
0x0024f6:	movs    	r4, #0
0x0024f8:	adds    	r3, r4, #0
0x0024fa:	str     	r0, [sp]
0x0024fc:	str     	r1, [sp, #4]
0x0024fe:	str     	r2, [sp, #8]
0x002500:	adds    	r2, r5, #0
0x002502:	movs    	r1, #0x2a
0x002504:	movs    	r0, #0xf1
0x002506:	lsls    	r0, r0, #9
0x002508:	bl      	#0x9124
0x00250c:	movs    	r1, #0
0x00250e:	ldr     	r0, [pc, #0x33c]
0x002510:	str     	r1, [sp]
0x002512:	str     	r1, [sp, #4]
0x002514:	movs    	r2, #0
0x002516:	str     	r2, [sp, #8]
0x002518:	add     	r0, sb
0x00251a:	ldr     	r2, [r0, #8]
0x00251c:	movs    	r0, #0xf1
0x00251e:	movs    	r1, #0x11
0x002520:	movs    	r3, #4
0x002522:	lsls    	r0, r0, #9
0x002524:	bl      	#0x9124
0x002528:	movs    	r1, #0
0x00252a:	adds    	r5, r0, #0
0x00252c:	str     	r1, [sp]
0x00252e:	str     	r1, [sp, #4]
0x002530:	movs    	r2, #0
0x002532:	movs    	r1, #0x1c
0x002534:	movs    	r0, #0xf1
0x002536:	adds    	r3, r4, #0
0x002538:	lsls    	r0, r0, #9
0x00253a:	str     	r2, [sp, #8]
0x00253c:	bl      	#0x9124
0x002540:	movs    	r2, #0
0x002542:	str     	r0, [sp]
0x002544:	movs    	r0, #0xf1
0x002546:	str     	r2, [sp, #8]
0x002548:	adds    	r3, r6, #0
0x00254a:	movs    	r1, #0x31
0x00254c:	lsls    	r0, r0, #9
0x00254e:	ldr     	r2, [sp, #0x5c]
0x002550:	str     	r7, [sp, #4]
0x002552:	bl      	#0x9124
0x002556:	cmp     	r5, #0
0x002558:	ble     	#0x2632
0x00255a:	ldr     	r1, [sp, #0x64]
0x00255c:	ldr     	r0, [sp, #0x4c]
0x00255e:	subs    	r1, #0xa
0x002560:	adds    	r0, #0xa
0x002562:	blx     	#0x20
0x002566:	adds    	r4, r0, #0
0x002568:	ldr     	r0, [pc, #0x2e0]
0x00256a:	str     	r5, [sp, #0x40]
0x00256c:	ldr     	r5, [sp, #0x5c]
0x00256e:	ldr     	r1, [sp, #0x40]
0x002570:	add     	r0, sb
0x002572:	adds    	r0, #0x80
0x002574:	ldr     	r1, [r0, #0x34]
0x002576:	adds    	r5, #0xa
0x002578:	adds    	r0, r4, #0
0x00257a:	blx     	#0x20
0x00257e:	muls    	r0, r4, r0
0x002580:	str     	r0, [sp, #0x3c]
0x002582:	ldr     	r1, [sp, #0x3c]
0x002584:	ldr     	r0, [sp, #0x40]
0x002586:	adds    	r1, r1, r4
0x002588:	cmp     	r1, r0
0x00258a:	bge     	#0x258e
0x00258c:	adds    	r0, r1, #0
0x00258e:	ldr     	r4, [sp, #0x3c]
0x002590:	str     	r0, [sp, #0x38]
0x002592:	cmp     	r4, r0
0x002594:	bge     	#0x267a
0x002596:	add     	r1, sp, #0x2c
0x002598:	adds    	r0, r6, #6
0x00259a:	str     	r0, [sp, #0x54]
0x00259c:	str     	r1, [sp, #0x58]
0x00259e:	movs    	r2, #0
0x0025a0:	movs    	r1, #0
0x0025a2:	str     	r2, [sp, #8]
0x0025a4:	adds    	r2, r4, #1
0x0025a6:	str     	r1, [sp]
0x0025a8:	str     	r1, [sp, #4]
0x0025aa:	movs    	r1, #0x3f
0x0025ac:	movs    	r3, #0
0x0025ae:	movs    	r0, #0xf1
0x0025b0:	lsls    	r0, r0, #9
0x0025b2:	str     	r2, [sp, #0x50]
0x0025b4:	bl      	#0x9124
0x0025b8:	movs    	r2, #0
0x0025ba:	movs    	r1, #0
0x0025bc:	ldr     	r3, [pc, #0x290]
0x0025be:	str     	r1, [sp]
0x0025c0:	str     	r1, [sp, #4]
0x0025c2:	str     	r2, [sp, #8]
0x0025c4:	str     	r0, [sp, #0x34]
0x0025c6:	add     	r3, pc
0x0025c8:	adds    	r2, r0, #0
0x0025ca:	movs    	r0, #0xf1
0x0025cc:	movs    	r1, #0x2d
0x0025ce:	lsls    	r0, r0, #9
0x0025d0:	bl      	#0x9124
0x0025d4:	str     	r0, [sp, #0x44]
0x0025d6:	movs    	r1, #0
0x0025d8:	movs    	r2, #0
0x0025da:	str     	r1, [sp]
0x0025dc:	str     	r1, [sp, #4]
0x0025de:	movs    	r1, #9
0x0025e0:	str     	r2, [sp, #8]
0x0025e2:	movs    	r0, #0xf1
0x0025e4:	movs    	r3, #0
0x0025e6:	lsls    	r0, r0, #9
0x0025e8:	ldr     	r2, [sp, #0x34]
0x0025ea:	bl      	#0x9124
0x0025ee:	ldr     	r0, [sp, #0x4c]
0x0025f0:	movs    	r2, #0
0x0025f2:	adds    	r0, #0xa
0x0025f4:	str     	r0, [sp]
0x0025f6:	str     	r2, [sp, #8]
0x0025f8:	adds    	r3, r6, #0
0x0025fa:	adds    	r2, r5, #0
0x0025fc:	movs    	r0, #0xf1
0x0025fe:	movs    	r1, #0x2f
0x002600:	lsls    	r0, r0, #9
0x002602:	str     	r7, [sp, #4]
0x002604:	bl      	#0x9124
0x002608:	cmp     	r0, #1
0x00260a:	bne     	#0x2636
0x00260c:	ldr     	r1, [pc, #0x23c]
0x00260e:	add     	r1, sb
0x002610:	adds    	r1, #0x80

; ===== candidate_002854 =====
0x002854:	push    	{r4, r5, r6, r7, lr}
0x002856:	sub     	sp, #0x54
0x002858:	movs    	r3, #0x19
0x00285a:	movs    	r0, #0x50
0x00285c:	ldr     	r7, [pc, #0x3e4]
0x00285e:	movs    	r5, #0
0x002860:	movs    	r4, #0
0x002862:	str     	r0, [sp, #0x34]
0x002864:	str     	r3, [sp, #0x44]
0x002866:	add     	r7, pc
0x002868:	movs    	r1, #0
0x00286a:	movs    	r2, #0
0x00286c:	str     	r2, [sp, #8]
0x00286e:	str     	r1, [sp]
0x002870:	str     	r1, [sp, #4]
0x002872:	movs    	r6, #0
0x002874:	adds    	r3, r6, #0
0x002876:	movs    	r1, #0xe1
0x002878:	movs    	r2, #0xed
0x00287a:	movs    	r0, #0xf1
0x00287c:	lsls    	r0, r0, #9
0x00287e:	bl      	#0x9124
0x002882:	cmp     	r0, #0
0x002884:	ble     	#0x296a
0x002886:	movs    	r1, #0
0x002888:	str     	r1, [sp]
0x00288a:	str     	r1, [sp, #4]
0x00288c:	movs    	r1, #0xff
0x00288e:	movs    	r2, #0
0x002890:	adds    	r3, r6, #0
0x002892:	adds    	r1, #0x25
0x002894:	movs    	r0, #0xf1
0x002896:	lsls    	r0, r0, #9
0x002898:	str     	r2, [sp, #8]
0x00289a:	bl      	#0x9124
0x00289e:	movs    	r2, #0
0x0028a0:	movs    	r1, #0
0x0028a2:	str     	r2, [sp, #8]
0x0028a4:	movs    	r2, #0xff
0x0028a6:	str     	r1, [sp]
0x0028a8:	str     	r1, [sp, #4]
0x0028aa:	adds    	r3, r6, #0
0x0028ac:	adds    	r2, #7
0x0028ae:	movs    	r1, #0xe1
0x0028b0:	movs    	r0, #0xf1
0x0028b2:	lsls    	r0, r0, #9
0x0028b4:	bl      	#0x9124
0x0028b8:	cmp     	r0, #0
0x0028ba:	bne     	#0x28be
0x0028bc:	movs    	r5, #1
0x0028be:	movs    	r2, #0
0x0028c0:	movs    	r1, #0
0x0028c2:	movs    	r0, #0
0x0028c4:	bl      	#0x90d4
0x0028c8:	add     	r2, sp, #0x48
0x0028ca:	add     	r1, sp, #0x4c
0x0028cc:	movs    	r0, #0
0x0028ce:	movs    	r6, #0
0x0028d0:	adds    	r3, r6, #0
0x0028d2:	str     	r0, [sp]
0x0028d4:	str     	r1, [sp, #4]
0x0028d6:	str     	r2, [sp, #8]
0x0028d8:	adds    	r2, r7, #0
0x0028da:	movs    	r1, #0x2a
0x0028dc:	movs    	r0, #0xf1
0x0028de:	lsls    	r0, r0, #9
0x0028e0:	bl      	#0x9124
0x0028e4:	movs    	r1, #0
0x0028e6:	str     	r1, [sp]
0x0028e8:	str     	r1, [sp, #4]
0x0028ea:	movs    	r2, #0
0x0028ec:	movs    	r1, #0x1c
0x0028ee:	adds    	r3, r6, #0
0x0028f0:	movs    	r0, #0xf1
0x0028f2:	lsls    	r0, r0, #9
0x0028f4:	str     	r2, [sp, #8]
0x0028f6:	bl      	#0x9124
0x0028fa:	ldr     	r1, [sp, #0x44]
0x0028fc:	movs    	r2, #0
0x0028fe:	str     	r0, [sp]
0x002900:	str     	r1, [sp, #4]
0x002902:	movs    	r1, #0x32
0x002904:	movs    	r0, #0xf1
0x002906:	adds    	r3, r6, #0
0x002908:	lsls    	r0, r0, #9
0x00290a:	str     	r2, [sp, #8]
0x00290c:	bl      	#0x9124
0x002910:	movs    	r1, #0
0x002912:	str     	r1, [sp]
0x002914:	str     	r1, [sp, #4]
0x002916:	movs    	r2, #0
0x002918:	movs    	r1, #0x1c
0x00291a:	adds    	r3, r6, #0
0x00291c:	movs    	r0, #0xf1
0x00291e:	lsls    	r0, r0, #9
0x002920:	str     	r2, [sp, #8]
0x002922:	str     	r7, [sp, #0xc]
0x002924:	bl      	#0x9124
0x002928:	ldr     	r1, [sp, #0x4c]
0x00292a:	str     	r6, [sp, #0x24]
0x00292c:	subs    	r0, r0, r1
0x00292e:	lsrs    	r1, r0, #0x1f
0x002930:	adds    	r0, r1, r0
0x002932:	asrs    	r0, r0, #1
0x002934:	str     	r0, [sp, #0x10]
0x002936:	movs    	r0, #5
0x002938:	str     	r0, [sp, #0x14]
0x00293a:	movs    	r0, #0xff
0x00293c:	str     	r0, [sp, #0x20]
0x00293e:	movs    	r1, #0
0x002940:	movs    	r2, #0
0x002942:	str     	r1, [sp]
0x002944:	str     	r1, [sp, #4]
0x002946:	str     	r0, [sp, #0x18]
0x002948:	str     	r0, [sp, #0x1c]
0x00294a:	str     	r6, [sp, #0x28]
0x00294c:	str     	r2, [sp, #8]
0x00294e:	movs    	r0, #0xf1
0x002950:	movs    	r1, #0x56
0x002952:	adds    	r3, r6, #0
0x002954:	lsls    	r0, r0, #9
0x002956:	add     	r2, sp, #0xc
0x002958:	bl      	#0x9124
0x00295c:	movs    	r1, #0
0x00295e:	movs    	r2, #0
0x002960:	str     	r2, [sp, #8]
0x002962:	adds    	r3, r6, #0
0x002964:	str     	r1, [sp]
0x002966:	str     	r1, [sp, #4]
0x002968:	b       	#0x296c
0x00296a:	b       	#0x2c84
0x00296c:	movs    	r1, #0x1d
0x00296e:	movs    	r0, #0xf1
0x002970:	lsls    	r0, r0, #9
0x002972:	bl      	#0x9124
0x002976:	subs    	r0, #0x69
0x002978:	movs    	r1, #0
0x00297a:	ldr     	r7, [sp, #0x44]
0x00297c:	str     	r1, [sp, #4]
0x00297e:	str     	r1, [sp]
0x002980:	str     	r0, [sp, #0x30]

; ===== candidate_002c88 =====
0x002c88:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x002c8a:	sub     	sp, #0x44
0x002c8c:	ldr     	r0, [sp, #0x44]
0x002c8e:	movs    	r6, #0x14
0x002c90:	adds    	r4, r2, #0
0x002c92:	cmp     	r0, #0
0x002c94:	ldr     	r7, [sp, #0x68]
0x002c96:	beq     	#0x2d76
0x002c98:	movs    	r1, #0
0x002c9a:	str     	r1, [sp, #4]
0x002c9c:	ldr     	r0, [sp, #0x44]
0x002c9e:	str     	r1, [sp]
0x002ca0:	movs    	r2, #0
0x002ca2:	str     	r2, [sp, #8]
0x002ca4:	ldr     	r2, [r0, #8]
0x002ca6:	movs    	r0, #0xf1
0x002ca8:	movs    	r1, #0x11
0x002caa:	movs    	r3, #4
0x002cac:	lsls    	r0, r0, #9
0x002cae:	bl      	#0x9124
0x002cb2:	adds    	r5, r0, #0
0x002cb4:	cmp     	r0, #0
0x002cb6:	ble     	#0x2d76
0x002cb8:	subs    	r1, r7, #5
0x002cba:	adds    	r0, r6, #0
0x002cbc:	blx     	#0x20
0x002cc0:	str     	r0, [sp, #0x38]
0x002cc2:	ldr     	r0, [sp, #0x50]
0x002cc4:	movs    	r2, #0
0x002cc6:	subs    	r0, #0xc
0x002cc8:	str     	r0, [sp, #0x40]
0x002cca:	str     	r0, [sp]
0x002ccc:	movs    	r0, #0xf1
0x002cce:	adds    	r3, r4, #0
0x002cd0:	str     	r2, [sp, #8]
0x002cd2:	movs    	r1, #0x2e
0x002cd4:	lsls    	r0, r0, #9
0x002cd6:	ldr     	r2, [sp, #0x48]
0x002cd8:	str     	r7, [sp, #4]
0x002cda:	bl      	#0x9124
0x002cde:	ldr     	r0, [sp, #0x6c]
0x002ce0:	adds    	r3, r4, #0
0x002ce2:	ldr     	r2, [r0]
0x002ce4:	str     	r7, [sp]
0x002ce6:	movs    	r0, #0xf1
0x002ce8:	movs    	r1, #0x3b
0x002cea:	str     	r2, [sp, #8]
0x002cec:	ldr     	r2, [sp, #0x40]
0x002cee:	lsls    	r0, r0, #9
0x002cf0:	str     	r5, [sp, #4]
0x002cf2:	bl      	#0x9124
0x002cf6:	ldr     	r0, [sp, #0x6c]
0x002cf8:	ldr     	r7, [sp, #0x40]
0x002cfa:	ldr     	r1, [r0]
0x002cfc:	ldr     	r0, [sp, #0x38]
0x002cfe:	blx     	#0x20
0x002d02:	ldr     	r1, [sp, #0x38]
0x002d04:	muls    	r0, r1, r0
0x002d06:	adds    	r1, r0, r1
0x002d08:	cmp     	r1, r5
0x002d0a:	bge     	#0x2d0e
0x002d0c:	adds    	r5, r1, #0
0x002d0e:	str     	r5, [sp, #0x34]
0x002d10:	ldr     	r1, [sp, #0x34]
0x002d12:	adds    	r5, r0, #0
0x002d14:	adds    	r4, #5
0x002d16:	cmp     	r0, r1
0x002d18:	bge     	#0x2dfa
0x002d1a:	ldr     	r3, [sp, #0x48]
0x002d1c:	adds    	r3, #0xa
0x002d1e:	str     	r3, [sp, #0x3c]
0x002d20:	ldr     	r0, [sp, #0x44]
0x002d22:	lsls    	r1, r5, #2
0x002d24:	ldr     	r0, [r0, #8]
0x002d26:	movs    	r2, #0
0x002d28:	ldr     	r0, [r0, r1]
0x002d2a:	movs    	r1, #0x2f
0x002d2c:	str     	r0, [sp, #0x30]
0x002d2e:	movs    	r0, #0xf1
0x002d30:	adds    	r3, r4, #0
0x002d32:	lsls    	r0, r0, #9
0x002d34:	str     	r7, [sp]
0x002d36:	str     	r6, [sp, #4]
0x002d38:	str     	r2, [sp, #8]
0x002d3a:	bl      	#0x9124
0x002d3e:	cmp     	r0, #1
0x002d40:	bne     	#0x2da2
0x002d42:	movs    	r1, #0
0x002d44:	movs    	r2, #0
0x002d46:	str     	r2, [sp, #8]
0x002d48:	str     	r1, [sp]
0x002d4a:	str     	r1, [sp, #4]
0x002d4c:	movs    	r1, #0xe1
0x002d4e:	movs    	r2, #0x17
0x002d50:	movs    	r3, #0
0x002d52:	movs    	r0, #0xf1
0x002d54:	lsls    	r0, r0, #9
0x002d56:	bl      	#0x9124
0x002d5a:	subs    	r0, #0xff
0x002d5c:	subs    	r0, #0x39
0x002d5e:	beq     	#0x2d80
0x002d60:	ldr     	r1, [pc, #0x17c]
0x002d62:	ldr     	r0, [sp, #0x44]
0x002d64:	add     	r1, sb
0x002d66:	ldr     	r1, [r1, #0x18]
0x002d68:	cmp     	r0, r1
0x002d6a:	bne     	#0x2d78
0x002d6c:	ldr     	r0, [pc, #0x174]
0x002d6e:	movs    	r3, #0
0x002d70:	add     	r0, sb
0x002d72:	strb    	r3, [r0]
0x002d74:	b       	#0x2d80
0x002d76:	b       	#0x2e60
0x002d78:	ldr     	r1, [pc, #0x168]
0x002d7a:	movs    	r0, #1
0x002d7c:	add     	r1, sb
0x002d7e:	strb    	r0, [r1]
0x002d80:	ldr     	r0, [sp, #0x6c]
0x002d82:	ldr     	r0, [r0]
0x002d84:	cmp     	r0, r5
0x002d86:	bne     	#0x2d9e
0x002d88:	movs    	r3, #0
0x002d8a:	movs    	r2, #4
0x002d8c:	movs    	r1, #0x23
0x002d8e:	movs    	r0, #0xf1
0x002d90:	lsls    	r0, r0, #9
0x002d92:	str     	r4, [sp]
0x002d94:	str     	r7, [sp, #4]
0x002d96:	str     	r6, [sp, #8]
0x002d98:	bl      	#0x9124
0x002d9c:	b       	#0x2da2
0x002d9e:	ldr     	r0, [sp, #0x6c]
0x002da0:	str     	r5, [r0]
0x002da2:	ldr     	r0, [sp, #0x6c]
0x002da4:	ldr     	r0, [r0]
0x002da6:	cmp     	r0, r5
0x002da8:	bne     	#0x2e32
0x002daa:	movs    	r1, #0
0x002dac:	movs    	r2, #0
0x002dae:	str     	r2, [sp, #8]
0x002db0:	str     	r1, [sp]

; ===== candidate_002eec =====
0x002eec:	push    	{r4, r5, r6, r7, lr}
0x002eee:	ldr     	r4, [pc, #0xb0]
0x002ef0:	sub     	sp, #0x2c
0x002ef2:	add     	r4, pc
0x002ef4:	add     	r2, sp, #0x24
0x002ef6:	add     	r1, sp, #0x28
0x002ef8:	movs    	r0, #0
0x002efa:	movs    	r5, #0
0x002efc:	adds    	r3, r5, #0
0x002efe:	str     	r0, [sp]
0x002f00:	str     	r1, [sp, #4]
0x002f02:	str     	r2, [sp, #8]
0x002f04:	adds    	r2, r4, #0
0x002f06:	movs    	r1, #0x2a
0x002f08:	movs    	r0, #0xf1
0x002f0a:	lsls    	r0, r0, #9
0x002f0c:	bl      	#0x9124
0x002f10:	movs    	r1, #0
0x002f12:	str     	r1, [sp]
0x002f14:	str     	r1, [sp, #4]
0x002f16:	ldr     	r1, [pc, #0x8c]
0x002f18:	ldr     	r7, [sp, #0x28]
0x002f1a:	movs    	r2, #0
0x002f1c:	str     	r2, [sp, #8]
0x002f1e:	add     	r1, sb
0x002f20:	ldr     	r2, [r1, #0x60]
0x002f22:	movs    	r1, #0x11
0x002f24:	movs    	r3, #4
0x002f26:	movs    	r0, #0xf1
0x002f28:	adds    	r7, #0x28
0x002f2a:	lsls    	r0, r0, #9
0x002f2c:	bl      	#0x9124
0x002f30:	ldr     	r1, [sp, #0x24]
0x002f32:	movs    	r2, #0
0x002f34:	muls    	r0, r1, r0
0x002f36:	movs    	r1, #0
0x002f38:	adds    	r4, r0, #0
0x002f3a:	adds    	r4, #0xa
0x002f3c:	str     	r1, [sp]
0x002f3e:	str     	r1, [sp, #4]
0x002f40:	movs    	r1, #0x1d
0x002f42:	adds    	r3, r5, #0
0x002f44:	movs    	r0, #0xf1
0x002f46:	movs    	r6, #0
0x002f48:	lsls    	r0, r0, #9
0x002f4a:	str     	r2, [sp, #8]
0x002f4c:	bl      	#0x9124
0x002f50:	ldr     	r1, [pc, #0x50]
0x002f52:	subs    	r0, r0, r4
0x002f54:	add     	r1, sb
0x002f56:	ldr     	r1, [r1, #0x60]
0x002f58:	subs    	r0, #0x19
0x002f5a:	str     	r0, [sp, #0x14]
0x002f5c:	ldr     	r0, [pc, #0x44]
0x002f5e:	str     	r1, [sp, #0xc]
0x002f60:	add     	r0, sb
0x002f62:	adds    	r0, #0x5c
0x002f64:	str     	r0, [sp, #0x20]
0x002f66:	movs    	r1, #0
0x002f68:	movs    	r2, #0
0x002f6a:	str     	r1, [sp]
0x002f6c:	str     	r1, [sp, #4]
0x002f6e:	movs    	r1, #0x2b
0x002f70:	str     	r2, [sp, #8]
0x002f72:	movs    	r0, #0xf1
0x002f74:	adds    	r3, r5, #0
0x002f76:	lsls    	r0, r0, #9
0x002f78:	add     	r2, sp, #0xc
0x002f7a:	str     	r6, [sp, #0x10]
0x002f7c:	str     	r7, [sp, #0x18]
0x002f7e:	str     	r4, [sp, #0x1c]
0x002f80:	bl      	#0x9124
0x002f84:	movs    	r1, #0
0x002f86:	movs    	r2, #0
0x002f88:	str     	r2, [sp, #8]
0x002f8a:	str     	r1, [sp]
0x002f8c:	str     	r1, [sp, #4]
0x002f8e:	movs    	r1, #0x24
0x002f90:	movs    	r2, #1
0x002f92:	movs    	r3, #1
0x002f94:	movs    	r0, #0xf1
0x002f96:	lsls    	r0, r0, #9
0x002f98:	bl      	#0x9124
0x002f9c:	add     	sp, #0x2c
0x002f9e:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002fa8 =====
0x002fa8:	push    	{r4, r5, r6, r7, lr}
0x002faa:	sub     	sp, #0x6c
0x002fac:	movs    	r0, #0x1a
0x002fae:	movs    	r1, #0x64
0x002fb0:	str     	r1, [sp, #0x50]
0x002fb2:	str     	r0, [sp, #0x54]
0x002fb4:	movs    	r0, #0x32
0x002fb6:	movs    	r1, #0
0x002fb8:	str     	r0, [sp, #0x40]
0x002fba:	movs    	r2, #0
0x002fbc:	str     	r2, [sp, #8]
0x002fbe:	str     	r1, [sp]
0x002fc0:	str     	r1, [sp, #4]
0x002fc2:	movs    	r4, #0xf1
0x002fc4:	movs    	r7, #0
0x002fc6:	adds    	r3, r7, #0
0x002fc8:	lsls    	r4, r4, #9
0x002fca:	movs    	r1, #0xe1
0x002fcc:	movs    	r2, #0xed
0x002fce:	movs    	r6, #0x19
0x002fd0:	movs    	r5, #0
0x002fd2:	adds    	r0, r4, #0
0x002fd4:	bl      	#0x9124
0x002fd8:	cmp     	r0, #0
0x002fda:	ble     	#0x30c2
0x002fdc:	movs    	r1, #0
0x002fde:	str     	r1, [sp]
0x002fe0:	str     	r1, [sp, #4]
0x002fe2:	movs    	r1, #0xff
0x002fe4:	movs    	r2, #0
0x002fe6:	adds    	r1, #0x25
0x002fe8:	adds    	r3, r7, #0
0x002fea:	adds    	r0, r4, #0
0x002fec:	str     	r2, [sp, #8]
0x002fee:	bl      	#0x9124
0x002ff2:	movs    	r2, #0
0x002ff4:	movs    	r1, #0
0x002ff6:	movs    	r0, #0
0x002ff8:	bl      	#0x90d4
0x002ffc:	ldr     	r4, [pc, #0x3dc]
0x002ffe:	add     	r4, pc
0x003000:	add     	r2, sp, #0x58
0x003002:	add     	r1, sp, #0x5c
0x003004:	movs    	r0, #0
0x003006:	str     	r0, [sp]
0x003008:	str     	r1, [sp, #4]
0x00300a:	str     	r2, [sp, #8]
0x00300c:	adds    	r3, r7, #0
0x00300e:	adds    	r2, r4, #0
0x003010:	movs    	r1, #0x2a
0x003012:	movs    	r0, #0xf1
0x003014:	lsls    	r0, r0, #9
0x003016:	bl      	#0x9124
0x00301a:	movs    	r1, #0
0x00301c:	str     	r1, [sp]
0x00301e:	str     	r1, [sp, #4]
0x003020:	movs    	r2, #0
0x003022:	movs    	r1, #0x1c
0x003024:	adds    	r3, r7, #0
0x003026:	movs    	r0, #0xf1
0x003028:	lsls    	r0, r0, #9
0x00302a:	str     	r2, [sp, #8]
0x00302c:	bl      	#0x9124
0x003030:	ldr     	r1, [sp, #0x54]
0x003032:	movs    	r2, #0
0x003034:	str     	r2, [sp, #8]
0x003036:	str     	r0, [sp]
0x003038:	adds    	r3, r7, #0
0x00303a:	str     	r1, [sp, #4]
0x00303c:	movs    	r1, #0x32
0x00303e:	adds    	r2, r7, #0
0x003040:	movs    	r0, #0xf1
0x003042:	lsls    	r0, r0, #9
0x003044:	bl      	#0x9124
0x003048:	movs    	r1, #0
0x00304a:	str     	r4, [sp, #0x20]
0x00304c:	str     	r1, [sp]
0x00304e:	str     	r1, [sp, #4]
0x003050:	movs    	r2, #0
0x003052:	movs    	r1, #0x1c
0x003054:	adds    	r3, r7, #0
0x003056:	movs    	r0, #0xf1
0x003058:	lsls    	r0, r0, #9
0x00305a:	str     	r2, [sp, #8]
0x00305c:	bl      	#0x9124
0x003060:	ldr     	r1, [sp, #0x5c]
0x003062:	movs    	r2, #0
0x003064:	subs    	r0, r0, r1
0x003066:	asrs    	r0, r0, #1
0x003068:	str     	r0, [sp, #0x24]
0x00306a:	movs    	r0, #7
0x00306c:	str     	r0, [sp, #0x28]
0x00306e:	movs    	r0, #0xff
0x003070:	movs    	r1, #0
0x003072:	str     	r1, [sp]
0x003074:	str     	r1, [sp, #4]
0x003076:	str     	r0, [sp, #0x2c]
0x003078:	str     	r0, [sp, #0x30]
0x00307a:	str     	r0, [sp, #0x34]
0x00307c:	movs    	r0, #0xf1
0x00307e:	movs    	r1, #0x56
0x003080:	str     	r2, [sp, #8]
0x003082:	adds    	r3, r7, #0
0x003084:	lsls    	r0, r0, #9
0x003086:	add     	r2, sp, #0x20
0x003088:	str     	r7, [sp, #0x3c]
0x00308a:	str     	r7, [sp, #0x38]
0x00308c:	bl      	#0x9124
0x003090:	movs    	r1, #0
0x003092:	str     	r1, [sp]
0x003094:	str     	r1, [sp, #4]
0x003096:	movs    	r2, #0
0x003098:	movs    	r1, #0x1c
0x00309a:	movs    	r4, #0x1a
0x00309c:	adds    	r3, r7, #0
0x00309e:	movs    	r0, #0xf1
0x0030a0:	lsls    	r0, r0, #9
0x0030a2:	str     	r2, [sp, #8]
0x0030a4:	bl      	#0x9124
0x0030a8:	ldr     	r1, [sp, #0x40]
0x0030aa:	movs    	r2, #0
0x0030ac:	str     	r2, [sp, #8]
0x0030ae:	str     	r0, [sp]
0x0030b0:	adds    	r3, r4, #0
0x0030b2:	str     	r1, [sp, #4]
0x0030b4:	movs    	r1, #0x31
0x0030b6:	adds    	r2, r7, #0
0x0030b8:	movs    	r0, #0xf1
0x0030ba:	lsls    	r0, r0, #9
0x0030bc:	bl      	#0x9124
0x0030c0:	b       	#0x30c4
0x0030c2:	b       	#0x3686
0x0030c4:	ldr     	r0, [pc, #0x318]
0x0030c6:	add     	r0, sb
0x0030c8:	ldr     	r0, [r0, #0x44]
0x0030ca:	cmp     	r0, #0
0x0030cc:	bne     	#0x3138
0x0030ce:	ldr     	r4, [pc, #0x314]
0x0030d0:	add     	r4, pc
0x0030d2:	add     	r2, sp, #0x58
0x0030d4:	add     	r1, sp, #0x5c

; ===== candidate_003690 =====
0x003690:	push    	{r4, r5, r6, r7, lr}
0x003692:	ldr     	r4, [pc, #0x3dc]
0x003694:	sub     	sp, #0x8c
0x003696:	add     	r4, pc
0x003698:	movs    	r2, #0
0x00369a:	movs    	r1, #0
0x00369c:	str     	r2, [sp, #8]
0x00369e:	movs    	r0, #0x19
0x0036a0:	movs    	r6, #0
0x0036a2:	adds    	r3, r6, #0
0x0036a4:	str     	r0, [sp, #0x54]
0x0036a6:	movs    	r2, #0xff
0x0036a8:	str     	r1, [sp]
0x0036aa:	str     	r1, [sp, #4]
0x0036ac:	movs    	r1, #0xe1
0x0036ae:	adds    	r2, #9
0x0036b0:	movs    	r0, #0xf1
0x0036b2:	lsls    	r0, r0, #9
0x0036b4:	bl      	#0x9124
0x0036b8:	str     	r0, [sp, #0x48]
0x0036ba:	movs    	r2, #0
0x0036bc:	movs    	r1, #0
0x0036be:	str     	r2, [sp, #8]
0x0036c0:	movs    	r2, #0xff
0x0036c2:	str     	r1, [sp]
0x0036c4:	str     	r1, [sp, #4]
0x0036c6:	adds    	r3, r6, #0
0x0036c8:	adds    	r2, #0xc
0x0036ca:	movs    	r1, #0xe1
0x0036cc:	movs    	r0, #0xf1
0x0036ce:	movs    	r5, #0
0x0036d0:	lsls    	r0, r0, #9
0x0036d2:	bl      	#0x9124
0x0036d6:	movs    	r2, #0
0x0036d8:	movs    	r1, #0
0x0036da:	str     	r2, [sp, #8]
0x0036dc:	adds    	r2, r0, #0
0x0036de:	str     	r1, [sp]
0x0036e0:	str     	r1, [sp, #4]
0x0036e2:	movs    	r1, #0x11
0x0036e4:	movs    	r0, #0xf1
0x0036e6:	movs    	r3, #4
0x0036e8:	lsls    	r0, r0, #9
0x0036ea:	bl      	#0x9124
0x0036ee:	adds    	r0, #2
0x0036f0:	str     	r0, [sp, #0x44]
0x0036f2:	movs    	r1, #0
0x0036f4:	movs    	r2, #0
0x0036f6:	str     	r2, [sp, #8]
0x0036f8:	str     	r1, [sp]
0x0036fa:	str     	r1, [sp, #4]
0x0036fc:	movs    	r1, #0xe1
0x0036fe:	movs    	r2, #0xed
0x003700:	movs    	r0, #0xf1
0x003702:	adds    	r3, r6, #0
0x003704:	lsls    	r0, r0, #9
0x003706:	bl      	#0x9124
0x00370a:	cmp     	r0, #0
0x00370c:	ble     	#0x37f2
0x00370e:	movs    	r1, #0
0x003710:	str     	r1, [sp]
0x003712:	str     	r1, [sp, #4]
0x003714:	movs    	r1, #0xff
0x003716:	movs    	r2, #0
0x003718:	adds    	r1, #0x25
0x00371a:	movs    	r3, #0
0x00371c:	movs    	r0, #0xf1
0x00371e:	lsls    	r0, r0, #9
0x003720:	str     	r2, [sp, #8]
0x003722:	bl      	#0x9124
0x003726:	movs    	r1, #0
0x003728:	str     	r1, [sp]
0x00372a:	str     	r1, [sp, #4]
0x00372c:	movs    	r2, #0
0x00372e:	movs    	r1, #0x1c
0x003730:	adds    	r3, r6, #0
0x003732:	movs    	r0, #0xf1
0x003734:	lsls    	r0, r0, #9
0x003736:	str     	r2, [sp, #8]
0x003738:	bl      	#0x9124
0x00373c:	adds    	r1, r0, #0
0x00373e:	ldr     	r0, [sp, #0x44]
0x003740:	blx     	#0x20
0x003744:	adds    	r7, r0, #0
0x003746:	add     	r2, sp, #0x4c
0x003748:	str     	r2, [sp, #8]
0x00374a:	movs    	r0, #0
0x00374c:	ldr     	r2, [pc, #0x324]
0x00374e:	add     	r1, sp, #0x50
0x003750:	str     	r1, [sp, #4]
0x003752:	str     	r0, [sp]
0x003754:	adds    	r3, r6, #0
0x003756:	add     	r2, pc
0x003758:	movs    	r1, #0x2a
0x00375a:	movs    	r0, #0xf1
0x00375c:	lsls    	r0, r0, #9
0x00375e:	bl      	#0x9124
0x003762:	movs    	r2, #0
0x003764:	movs    	r1, #0
0x003766:	str     	r2, [sp, #8]
0x003768:	movs    	r2, #0xff
0x00376a:	str     	r1, [sp]
0x00376c:	str     	r1, [sp, #4]
0x00376e:	adds    	r3, r6, #0
0x003770:	adds    	r2, #0xa
0x003772:	movs    	r1, #0x14
0x003774:	movs    	r0, #0xf1
0x003776:	lsls    	r0, r0, #9
0x003778:	bl      	#0x9124
0x00377c:	movs    	r2, #0
0x00377e:	movs    	r1, #0
0x003780:	movs    	r0, #0
0x003782:	bl      	#0x90d4
0x003786:	add     	r2, sp, #0x68
0x003788:	add     	r1, sp, #0x64
0x00378a:	movs    	r0, #0
0x00378c:	str     	r0, [sp]
0x00378e:	str     	r1, [sp, #4]
0x003790:	str     	r2, [sp, #8]
0x003792:	adds    	r3, r6, #0
0x003794:	adds    	r2, r4, #0
0x003796:	movs    	r1, #0x2a
0x003798:	movs    	r0, #0xf1
0x00379a:	lsls    	r0, r0, #9
0x00379c:	bl      	#0x9124
0x0037a0:	movs    	r1, #0
0x0037a2:	movs    	r2, #0
0x0037a4:	str     	r2, [sp, #8]
0x0037a6:	str     	r1, [sp]
0x0037a8:	str     	r1, [sp, #4]
0x0037aa:	movs    	r1, #0xe1
0x0037ac:	movs    	r2, #0x2a
0x0037ae:	adds    	r3, r6, #0
0x0037b0:	movs    	r0, #0xf1
0x0037b2:	lsls    	r0, r0, #9
0x0037b4:	bl      	#0x9124
0x0037b8:	ldr     	r1, [sp, #0x4c]
0x0037ba:	movs    	r2, #0
0x0037bc:	adds    	r4, r0, r1
0x0037be:	movs    	r1, #0
0x0037c0:	str     	r1, [sp]

; ===== candidate_00402c =====
0x00402c:	push    	{r4, r5, r6, r7, lr}
0x00402e:	sub     	sp, #0x5c
0x004030:	movs    	r1, #0
0x004032:	str     	r1, [sp]
0x004034:	str     	r1, [sp, #4]
0x004036:	movs    	r7, #0xf1
0x004038:	movs    	r6, #0xb4
0x00403a:	movs    	r0, #0x78
0x00403c:	movs    	r2, #0
0x00403e:	str     	r0, [sp, #0x50]
0x004040:	lsls    	r7, r7, #9
0x004042:	movs    	r1, #0x1c
0x004044:	movs    	r3, #0
0x004046:	adds    	r0, r7, #0
0x004048:	str     	r2, [sp, #8]
0x00404a:	str     	r6, [sp, #0x4c]
0x00404c:	bl      	#0x9124
0x004050:	subs    	r0, #0xb4
0x004052:	lsrs    	r1, r0, #0x1f
0x004054:	adds    	r0, r1, r0
0x004056:	movs    	r1, #0
0x004058:	movs    	r2, #0
0x00405a:	str     	r2, [sp, #8]
0x00405c:	str     	r1, [sp]
0x00405e:	str     	r1, [sp, #4]
0x004060:	movs    	r1, #0xe1
0x004062:	movs    	r2, #0xed
0x004064:	asrs    	r4, r0, #1
0x004066:	movs    	r5, #0x32
0x004068:	movs    	r3, #0
0x00406a:	adds    	r0, r7, #0
0x00406c:	bl      	#0x9124
0x004070:	cmp     	r0, #0
0x004072:	ble     	#0x4158
0x004074:	movs    	r1, #0
0x004076:	str     	r1, [sp]
0x004078:	str     	r1, [sp, #4]
0x00407a:	movs    	r1, #0xff
0x00407c:	movs    	r2, #0
0x00407e:	adds    	r1, #0x25
0x004080:	movs    	r3, #0
0x004082:	adds    	r0, r7, #0
0x004084:	str     	r2, [sp, #8]
0x004086:	bl      	#0x9124
0x00408a:	movs    	r1, #0
0x00408c:	str     	r1, [sp]
0x00408e:	str     	r1, [sp, #4]
0x004090:	movs    	r2, #0
0x004092:	movs    	r7, #0
0x004094:	adds    	r3, r7, #0
0x004096:	movs    	r1, #0x5a
0x004098:	movs    	r0, #0xf1
0x00409a:	lsls    	r0, r0, #9
0x00409c:	str     	r2, [sp, #8]
0x00409e:	bl      	#0x9124
0x0040a2:	add     	r2, sp, #0x40
0x0040a4:	str     	r2, [sp, #8]
0x0040a6:	movs    	r0, #0
0x0040a8:	ldr     	r2, [pc, #0x3c8]
0x0040aa:	add     	r1, sp, #0x44
0x0040ac:	str     	r1, [sp, #4]
0x0040ae:	str     	r0, [sp]
0x0040b0:	adds    	r3, r7, #0
0x0040b2:	add     	r2, pc
0x0040b4:	movs    	r1, #0x2a
0x0040b6:	movs    	r0, #0xf1
0x0040b8:	lsls    	r0, r0, #9
0x0040ba:	bl      	#0x9124
0x0040be:	movs    	r0, #0x14
0x0040c0:	str     	r0, [sp, #0x48]
0x0040c2:	ldr     	r0, [sp, #0x50]
0x0040c4:	movs    	r1, #0
0x0040c6:	str     	r0, [sp, #0x1c]
0x0040c8:	ldr     	r0, [pc, #0x3ac]
0x0040ca:	str     	r4, [sp, #0x20]
0x0040cc:	add     	r0, sb
0x0040ce:	str     	r0, [sp, #0x28]
0x0040d0:	str     	r5, [sp, #0x24]
0x0040d2:	movs    	r2, #0
0x0040d4:	str     	r2, [sp, #8]
0x0040d6:	str     	r1, [sp, #4]
0x0040d8:	str     	r1, [sp]
0x0040da:	movs    	r1, #0xe1
0x0040dc:	movs    	r2, #0x3e
0x0040de:	movs    	r0, #0xf1
0x0040e0:	adds    	r3, r7, #0
0x0040e2:	lsls    	r0, r0, #9
0x0040e4:	str     	r6, [sp, #0x18]
0x0040e6:	bl      	#0x9124
0x0040ea:	ldr     	r1, [pc, #0x38c]
0x0040ec:	add     	r3, sp, #0x20
0x0040ee:	add     	r1, sb
0x0040f0:	subs    	r1, #0x50
0x0040f2:	ldr     	r1, [r1, #0x48]
0x0040f4:	movs    	r2, #0
0x0040f6:	lsls    	r1, r1, #2
0x0040f8:	ldr     	r0, [r0, r1]
0x0040fa:	movs    	r1, #0
0x0040fc:	ldr     	r0, [r0, #4]
0x0040fe:	str     	r0, [sp, #0x2c]
0x004100:	ldr     	r0, [pc, #0x374]
0x004102:	add     	r0, sb
0x004104:	subs    	r0, #4
0x004106:	str     	r0, [sp, #0x30]
0x004108:	movs    	r0, #1
0x00410a:	strb    	r0, [r3, #0x14]
0x00410c:	str     	r1, [sp]
0x00410e:	str     	r1, [sp, #4]
0x004110:	movs    	r1, #0x59
0x004112:	str     	r2, [sp, #8]
0x004114:	movs    	r0, #0xf1
0x004116:	adds    	r3, r7, #0
0x004118:	lsls    	r0, r0, #9
0x00411a:	add     	r2, sp, #0x18
0x00411c:	bl      	#0x9124
0x004120:	ldr     	r1, [sp, #0x48]
0x004122:	ldr     	r0, [sp, #0x4c]
0x004124:	movs    	r2, #0
0x004126:	str     	r2, [sp, #8]
0x004128:	str     	r1, [sp, #4]
0x00412a:	str     	r0, [sp]
0x00412c:	movs    	r0, #0xf1
0x00412e:	movs    	r1, #0x31
0x004130:	adds    	r2, r4, #0
0x004132:	movs    	r3, #0x1e
0x004134:	lsls    	r0, r0, #9
0x004136:	bl      	#0x9124
0x00413a:	movs    	r1, #0
0x00413c:	movs    	r2, #0
0x00413e:	str     	r2, [sp, #8]
0x004140:	str     	r1, [sp]
0x004142:	str     	r1, [sp, #4]
0x004144:	movs    	r1, #0xe1
0x004146:	movs    	r2, #0x3e
0x004148:	adds    	r3, r7, #0
0x00414a:	movs    	r0, #0xf1
0x00414c:	lsls    	r0, r0, #9
0x00414e:	bl      	#0x9124
0x004152:	movs    	r2, #0
0x004154:	movs    	r1, #0
0x004156:	b       	#0x415a

; ===== candidate_004480 =====
0x004480:	push    	{r4, r5, r6, r7, lr}
0x004482:	sub     	sp, #0x3c
0x004484:	movs    	r1, #0
0x004486:	movs    	r2, #0
0x004488:	str     	r2, [sp, #8]
0x00448a:	str     	r1, [sp]
0x00448c:	str     	r1, [sp, #4]
0x00448e:	movs    	r5, #0xf1
0x004490:	movs    	r4, #0
0x004492:	adds    	r3, r4, #0
0x004494:	lsls    	r5, r5, #9
0x004496:	movs    	r1, #0xe1
0x004498:	movs    	r2, #0xed
0x00449a:	movs    	r7, #0x19
0x00449c:	movs    	r6, #0x19
0x00449e:	adds    	r0, r5, #0
0x0044a0:	bl      	#0x9124
0x0044a4:	cmp     	r0, #0
0x0044a6:	ble     	#0x458c
0x0044a8:	movs    	r1, #0
0x0044aa:	str     	r1, [sp]
0x0044ac:	str     	r1, [sp, #4]
0x0044ae:	movs    	r1, #0xff
0x0044b0:	movs    	r2, #0
0x0044b2:	adds    	r1, #0x25
0x0044b4:	adds    	r3, r4, #0
0x0044b6:	adds    	r0, r5, #0
0x0044b8:	str     	r2, [sp, #8]
0x0044ba:	bl      	#0x9124
0x0044be:	movs    	r2, #0
0x0044c0:	movs    	r1, #0
0x0044c2:	movs    	r0, #0
0x0044c4:	bl      	#0x90d4
0x0044c8:	movs    	r1, #0
0x0044ca:	str     	r1, [sp]
0x0044cc:	str     	r1, [sp, #4]
0x0044ce:	movs    	r2, #0
0x0044d0:	movs    	r1, #0x1c
0x0044d2:	adds    	r3, r4, #0
0x0044d4:	adds    	r0, r5, #0
0x0044d6:	str     	r2, [sp, #8]
0x0044d8:	bl      	#0x9124
0x0044dc:	movs    	r2, #0
0x0044de:	str     	r2, [sp, #8]
0x0044e0:	adds    	r2, r4, #0
0x0044e2:	str     	r0, [sp]
0x0044e4:	adds    	r3, r4, #0
0x0044e6:	movs    	r1, #0x32
0x0044e8:	adds    	r0, r5, #0
0x0044ea:	str     	r6, [sp, #4]
0x0044ec:	bl      	#0x9124
0x0044f0:	ldr     	r6, [pc, #0x1b4]
0x0044f2:	add     	r6, pc
0x0044f4:	add     	r2, sp, #0x34
0x0044f6:	add     	r1, sp, #0x38
0x0044f8:	str     	r1, [sp, #4]
0x0044fa:	str     	r2, [sp, #8]
0x0044fc:	movs    	r0, #0
0x0044fe:	str     	r0, [sp]
0x004500:	adds    	r2, r6, #0
0x004502:	movs    	r1, #0x2a
0x004504:	adds    	r3, r4, #0
0x004506:	adds    	r0, r5, #0
0x004508:	bl      	#0x9124
0x00450c:	movs    	r1, #0
0x00450e:	str     	r1, [sp]
0x004510:	str     	r1, [sp, #4]
0x004512:	movs    	r2, #0
0x004514:	movs    	r1, #0x1c
0x004516:	adds    	r3, r4, #0
0x004518:	adds    	r0, r5, #0
0x00451a:	str     	r2, [sp, #8]
0x00451c:	str     	r6, [sp, #0xc]
0x00451e:	bl      	#0x9124
0x004522:	ldr     	r1, [sp, #0x38]
0x004524:	str     	r4, [sp, #0x18]
0x004526:	subs    	r0, r0, r1
0x004528:	lsrs    	r1, r0, #0x1f
0x00452a:	adds    	r0, r1, r0
0x00452c:	asrs    	r0, r0, #1
0x00452e:	str     	r0, [sp, #0x10]
0x004530:	movs    	r0, #6
0x004532:	str     	r0, [sp, #0x14]
0x004534:	movs    	r0, #0xff
0x004536:	str     	r0, [sp, #0x20]
0x004538:	str     	r0, [sp, #0x24]
0x00453a:	str     	r0, [sp, #0x28]
0x00453c:	movs    	r0, #1
0x00453e:	movs    	r1, #0x20
0x004540:	str     	r4, [sp, #0x1c]
0x004542:	add     	r6, sp, #0xc
0x004544:	strb    	r0, [r1, r6]
0x004546:	movs    	r1, #0
0x004548:	movs    	r2, #0
0x00454a:	str     	r2, [sp, #8]
0x00454c:	str     	r1, [sp]
0x00454e:	str     	r1, [sp, #4]
0x004550:	movs    	r1, #0x25
0x004552:	adds    	r2, r6, #0
0x004554:	str     	r0, [sp, #0x30]
0x004556:	adds    	r3, r4, #0
0x004558:	adds    	r0, r5, #0
0x00455a:	bl      	#0x9124
0x00455e:	movs    	r1, #0
0x004560:	str     	r1, [sp]
0x004562:	str     	r1, [sp, #4]
0x004564:	movs    	r2, #0
0x004566:	movs    	r1, #0x1c
0x004568:	movs    	r6, #0x19
0x00456a:	adds    	r3, r4, #0
0x00456c:	adds    	r0, r5, #0
0x00456e:	str     	r2, [sp, #8]
0x004570:	bl      	#0x9124
0x004574:	adds    	r2, r0, #0
0x004576:	adds    	r3, r7, #0
0x004578:	adds    	r1, r6, #0
0x00457a:	adds    	r0, r4, #0
0x00457c:	bl      	#0x24e4
0x004580:	movs    	r6, #0x32
0x004582:	movs    	r2, #0
0x004584:	movs    	r1, #0
0x004586:	str     	r1, [sp]
0x004588:	str     	r1, [sp, #4]
0x00458a:	b       	#0x458e
0x00458c:	b       	#0x46a2
0x00458e:	adds    	r3, r4, #0
0x004590:	movs    	r1, #0x1d
0x004592:	adds    	r0, r5, #0
0x004594:	str     	r2, [sp, #8]
0x004596:	bl      	#0x9124
0x00459a:	movs    	r1, #0
0x00459c:	str     	r1, [sp]
0x00459e:	str     	r1, [sp, #4]
0x0045a0:	movs    	r2, #0
0x0045a2:	movs    	r1, #0x1c
0x0045a4:	subs    	r7, r0, r6
0x0045a6:	adds    	r3, r4, #0
0x0045a8:	adds    	r0, r5, #0
0x0045aa:	str     	r2, [sp, #8]
0x0045ac:	bl      	#0x9124
0x0045b0:	adds    	r3, r0, #0

; ===== candidate_0046b8 =====
0x0046b8:	push    	{r4, r5, r6, r7, lr}
0x0046ba:	sub     	sp, #0x2c
0x0046bc:	movs    	r1, #0
0x0046be:	str     	r1, [sp]
0x0046c0:	str     	r1, [sp, #4]
0x0046c2:	ldr     	r7, [pc, #0xd8]
0x0046c4:	movs    	r6, #0
0x0046c6:	movs    	r2, #0
0x0046c8:	adds    	r3, r6, #0
0x0046ca:	movs    	r1, #0xff
0x0046cc:	adds    	r1, #0x10
0x0046ce:	str     	r2, [sp, #8]
0x0046d0:	movs    	r0, #0xf1
0x0046d2:	add     	r7, sb
0x0046d4:	ldr     	r2, [r7, #0x28]
0x0046d6:	lsls    	r0, r0, #9
0x0046d8:	bl      	#0x9124
0x0046dc:	movs    	r1, #0
0x0046de:	str     	r1, [sp]
0x0046e0:	str     	r1, [sp, #4]
0x0046e2:	movs    	r2, #0
0x0046e4:	adds    	r4, r0, #0
0x0046e6:	movs    	r0, #0xf1
0x0046e8:	str     	r2, [sp, #8]
0x0046ea:	movs    	r1, #0x11
0x0046ec:	movs    	r3, #4
0x0046ee:	lsls    	r0, r0, #9
0x0046f0:	ldr     	r2, [r7, #0x28]
0x0046f2:	bl      	#0x9124
0x0046f6:	adds    	r5, r0, #0
0x0046f8:	movs    	r0, #0
0x0046fa:	add     	r2, sp, #0x24
0x0046fc:	add     	r1, sp, #0x28
0x0046fe:	str     	r1, [sp, #4]
0x004700:	str     	r2, [sp, #8]
0x004702:	str     	r0, [sp]
0x004704:	ldr     	r1, [r7, #0x28]
0x004706:	lsls    	r0, r4, #2
0x004708:	ldr     	r2, [r1, r0]
0x00470a:	movs    	r0, #0xf1
0x00470c:	movs    	r1, #0x2a
0x00470e:	adds    	r3, r6, #0
0x004710:	lsls    	r0, r0, #9
0x004712:	bl      	#0x9124
0x004716:	ldr     	r0, [sp, #0x24]
0x004718:	ldr     	r4, [sp, #0x28]
0x00471a:	muls    	r5, r0, r5
0x00471c:	ldr     	r0, [r7, #0x28]
0x00471e:	movs    	r1, #0
0x004720:	str     	r1, [sp]
0x004722:	str     	r1, [sp, #4]
0x004724:	movs    	r2, #0
0x004726:	adds    	r4, #0x32
0x004728:	adds    	r5, #0xa
0x00472a:	str     	r0, [sp, #0xc]
0x00472c:	movs    	r0, #0xf1
0x00472e:	adds    	r3, r6, #0
0x004730:	movs    	r1, #0x1c
0x004732:	lsls    	r0, r0, #9
0x004734:	str     	r2, [sp, #8]
0x004736:	bl      	#0x9124
0x00473a:	subs    	r0, r0, r4
0x00473c:	movs    	r1, #0
0x00473e:	asrs    	r0, r0, #1
0x004740:	str     	r0, [sp, #0x10]
0x004742:	str     	r1, [sp]
0x004744:	str     	r1, [sp, #4]
0x004746:	movs    	r2, #0
0x004748:	movs    	r1, #0x1d
0x00474a:	movs    	r0, #0xf1
0x00474c:	adds    	r3, r6, #0
0x00474e:	lsls    	r0, r0, #9
0x004750:	str     	r2, [sp, #8]
0x004752:	bl      	#0x9124
0x004756:	subs    	r0, r0, r5
0x004758:	asrs    	r0, r0, #1
0x00475a:	str     	r0, [sp, #0x14]
0x00475c:	ldr     	r0, [pc, #0x40]
0x00475e:	movs    	r1, #0
0x004760:	add     	r0, sb
0x004762:	str     	r0, [sp, #0x20]
0x004764:	movs    	r2, #0
0x004766:	str     	r1, [sp]
0x004768:	str     	r1, [sp, #4]
0x00476a:	movs    	r1, #0x2b
0x00476c:	str     	r2, [sp, #8]
0x00476e:	movs    	r0, #0xf1
0x004770:	adds    	r3, r6, #0
0x004772:	lsls    	r0, r0, #9
0x004774:	add     	r2, sp, #0xc
0x004776:	str     	r4, [sp, #0x18]
0x004778:	str     	r5, [sp, #0x1c]
0x00477a:	bl      	#0x9124
0x00477e:	movs    	r1, #0
0x004780:	movs    	r2, #0
0x004782:	str     	r2, [sp, #8]
0x004784:	str     	r1, [sp]
0x004786:	str     	r1, [sp, #4]
0x004788:	movs    	r1, #0x24
0x00478a:	movs    	r2, #1
0x00478c:	movs    	r3, #1
0x00478e:	movs    	r0, #0xf1
0x004790:	lsls    	r0, r0, #9
0x004792:	bl      	#0x9124
0x004796:	add     	sp, #0x2c
0x004798:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0047a4 =====
0x0047a4:	push    	{r4, r5, r6, r7, lr}
0x0047a6:	sub     	sp, #0x64
0x0047a8:	movs    	r0, #0x14
0x0047aa:	str     	r0, [sp, #0x54]
0x0047ac:	movs    	r0, #0x37
0x0047ae:	str     	r0, [sp, #0x4c]
0x0047b0:	movs    	r0, #0x50
0x0047b2:	movs    	r1, #0
0x0047b4:	str     	r0, [sp, #0x48]
0x0047b6:	movs    	r2, #0
0x0047b8:	str     	r2, [sp, #8]
0x0047ba:	str     	r1, [sp]
0x0047bc:	str     	r1, [sp, #4]
0x0047be:	movs    	r4, #0xf1
0x0047c0:	movs    	r5, #0
0x0047c2:	adds    	r3, r5, #0
0x0047c4:	lsls    	r4, r4, #9
0x0047c6:	movs    	r1, #0xe1
0x0047c8:	movs    	r2, #0xed
0x0047ca:	adds    	r0, r4, #0
0x0047cc:	bl      	#0x9124
0x0047d0:	cmp     	r0, #0
0x0047d2:	ble     	#0x48ba
0x0047d4:	movs    	r1, #0
0x0047d6:	str     	r1, [sp]
0x0047d8:	str     	r1, [sp, #4]
0x0047da:	movs    	r1, #0xff
0x0047dc:	movs    	r2, #0
0x0047de:	adds    	r1, #0x25
0x0047e0:	adds    	r3, r5, #0
0x0047e2:	adds    	r0, r4, #0
0x0047e4:	str     	r2, [sp, #8]
0x0047e6:	bl      	#0x9124
0x0047ea:	add     	r2, sp, #0x60
0x0047ec:	str     	r2, [sp, #8]
0x0047ee:	movs    	r0, #0
0x0047f0:	ldr     	r2, [pc, #0x3e4]
0x0047f2:	add     	r1, sp, #0x5c
0x0047f4:	str     	r1, [sp, #4]
0x0047f6:	str     	r0, [sp]
0x0047f8:	adds    	r3, r5, #0
0x0047fa:	add     	r2, pc
0x0047fc:	movs    	r1, #0x2a
0x0047fe:	adds    	r0, r4, #0
0x004800:	bl      	#0x9124
0x004804:	movs    	r2, #0
0x004806:	movs    	r1, #0
0x004808:	movs    	r0, #0
0x00480a:	bl      	#0x90d4
0x00480e:	ldr     	r7, [pc, #0x3cc]
0x004810:	add     	r7, pc
0x004812:	add     	r2, sp, #0x60
0x004814:	add     	r1, sp, #0x5c
0x004816:	str     	r1, [sp, #4]
0x004818:	str     	r2, [sp, #8]
0x00481a:	movs    	r0, #0
0x00481c:	str     	r0, [sp]
0x00481e:	adds    	r2, r7, #0
0x004820:	movs    	r1, #0x2a
0x004822:	adds    	r3, r5, #0
0x004824:	adds    	r0, r4, #0
0x004826:	bl      	#0x9124
0x00482a:	movs    	r1, #0
0x00482c:	str     	r1, [sp]
0x00482e:	str     	r1, [sp, #4]
0x004830:	movs    	r2, #0
0x004832:	movs    	r1, #0x1c
0x004834:	adds    	r3, r5, #0
0x004836:	adds    	r0, r4, #0
0x004838:	str     	r2, [sp, #8]
0x00483a:	bl      	#0x9124
0x00483e:	str     	r0, [sp, #0x50]
0x004840:	ldr     	r0, [sp, #0x60]
0x004842:	movs    	r1, #0
0x004844:	lsls    	r4, r0, #1
0x004846:	str     	r4, [sp, #0x44]
0x004848:	str     	r4, [sp, #0x40]
0x00484a:	str     	r1, [sp]
0x00484c:	str     	r1, [sp, #4]
0x00484e:	movs    	r2, #0
0x004850:	movs    	r1, #0x1d
0x004852:	movs    	r0, #0xf1
0x004854:	adds    	r3, r5, #0
0x004856:	lsls    	r0, r0, #9
0x004858:	str     	r2, [sp, #8]
0x00485a:	bl      	#0x9124
0x00485e:	subs    	r0, r0, r4
0x004860:	ldr     	r4, [sp, #0x40]
0x004862:	subs    	r0, #0x4b
0x004864:	subs    	r6, r0, r4
0x004866:	ldr     	r0, [pc, #0x378]
0x004868:	add     	r0, sb
0x00486a:	ldr     	r0, [r0, #0x18]
0x00486c:	cmp     	r0, #0
0x00486e:	beq     	#0x4878
0x004870:	adds    	r0, r6, #0
0x004872:	ldr     	r1, [sp, #0x44]
0x004874:	subs    	r0, #0x50
0x004876:	subs    	r6, r0, r1
0x004878:	movs    	r1, #0
0x00487a:	str     	r1, [sp]
0x00487c:	str     	r1, [sp, #4]
0x00487e:	movs    	r2, #0
0x004880:	movs    	r5, #0
0x004882:	adds    	r3, r5, #0
0x004884:	movs    	r1, #0x1c
0x004886:	movs    	r0, #0xf1
0x004888:	lsls    	r0, r0, #9
0x00488a:	str     	r2, [sp, #8]
0x00488c:	bl      	#0x9124
0x004890:	movs    	r2, #0
0x004892:	str     	r0, [sp]
0x004894:	movs    	r0, #0xf1
0x004896:	adds    	r3, r5, #0
0x004898:	movs    	r1, #0x32
0x00489a:	lsls    	r0, r0, #9
0x00489c:	str     	r2, [sp, #8]
0x00489e:	str     	r4, [sp, #4]
0x0048a0:	bl      	#0x9124
0x0048a4:	str     	r7, [sp, #0x10]
0x0048a6:	ldr     	r0, [sp, #0x50]
0x0048a8:	ldr     	r1, [sp, #0x5c]
0x0048aa:	subs    	r0, r0, r1
0x0048ac:	lsrs    	r1, r0, #0x1f
0x0048ae:	adds    	r0, r1, r0
0x0048b0:	asrs    	r0, r0, #1
0x0048b2:	str     	r0, [sp, #0x14]
0x0048b4:	ldr     	r0, [sp, #0x60]
0x0048b6:	lsrs    	r1, r0, #0x1f
0x0048b8:	b       	#0x48bc
0x0048ba:	b       	#0x500a
0x0048bc:	adds    	r0, r1, r0
0x0048be:	asrs    	r0, r0, #1
0x0048c0:	adds    	r0, #2
0x0048c2:	str     	r0, [sp, #0x18]
0x0048c4:	movs    	r0, #0xff
0x0048c6:	str     	r0, [sp, #0x24]
0x0048c8:	str     	r0, [sp, #0x28]
0x0048ca:	str     	r0, [sp, #0x2c]
0x0048cc:	add     	r0, sp, #0x30
0x0048ce:	movs    	r1, #1

; ===== candidate_005040 =====
0x005040:	push    	{r4, r5, r6, r7, lr}
0x005042:	ldr     	r1, [pc, #0x2e4]
0x005044:	sub     	sp, #0x44
0x005046:	add     	r1, sb
0x005048:	ldr     	r0, [r1, #0x2c]
0x00504a:	ldr     	r1, [r1, #0x34]
0x00504c:	lsls    	r0, r0, #2
0x00504e:	ldr     	r1, [r1, r0]
0x005050:	add     	r2, sp, #0x3c
0x005052:	ldr     	r0, [r1, #8]
0x005054:	add     	r4, sp, #0x38
0x005056:	str     	r0, [sp, #0x40]
0x005058:	ldr     	r7, [r1]
0x00505a:	str     	r2, [sp, #8]
0x00505c:	movs    	r0, #0
0x00505e:	ldr     	r2, [pc, #0x2cc]
0x005060:	movs    	r6, #0
0x005062:	adds    	r3, r6, #0
0x005064:	str     	r0, [sp]
0x005066:	str     	r4, [sp, #4]
0x005068:	add     	r2, pc
0x00506a:	movs    	r1, #0x2a
0x00506c:	movs    	r0, #0xf1
0x00506e:	lsls    	r0, r0, #9
0x005070:	bl      	#0x9124
0x005074:	movs    	r1, #0
0x005076:	str     	r1, [sp]
0x005078:	str     	r1, [sp, #4]
0x00507a:	movs    	r2, #0
0x00507c:	movs    	r1, #0x40
0x00507e:	adds    	r3, r6, #0
0x005080:	movs    	r0, #0xf1
0x005082:	lsls    	r0, r0, #9
0x005084:	str     	r2, [sp, #8]
0x005086:	bl      	#0x9124
0x00508a:	add     	r2, sp, #0x3c
0x00508c:	movs    	r0, #0
0x00508e:	str     	r0, [sp]
0x005090:	str     	r2, [sp, #8]
0x005092:	adds    	r3, r6, #0
0x005094:	adds    	r2, r7, #0
0x005096:	movs    	r0, #0xf1
0x005098:	movs    	r1, #0x2a
0x00509a:	lsls    	r0, r0, #9
0x00509c:	str     	r4, [sp, #4]
0x00509e:	bl      	#0x9124
0x0050a2:	movs    	r1, #0
0x0050a4:	str     	r1, [sp]
0x0050a6:	str     	r1, [sp, #4]
0x0050a8:	movs    	r2, #0
0x0050aa:	movs    	r1, #0x1c
0x0050ac:	adds    	r3, r6, #0
0x0050ae:	movs    	r0, #0xf1
0x0050b0:	lsls    	r0, r0, #9
0x0050b2:	str     	r2, [sp, #8]
0x0050b4:	bl      	#0x9124
0x0050b8:	adds    	r5, r0, #0
0x0050ba:	ldr     	r0, [sp, #0x3c]
0x0050bc:	movs    	r2, #0
0x0050be:	lsls    	r4, r0, #1
0x0050c0:	movs    	r0, #0xf1
0x0050c2:	adds    	r3, r6, #0
0x0050c4:	movs    	r1, #0x32
0x0050c6:	lsls    	r0, r0, #9
0x0050c8:	str     	r4, [sp, #4]
0x0050ca:	str     	r2, [sp, #8]
0x0050cc:	str     	r5, [sp]
0x0050ce:	bl      	#0x9124
0x0050d2:	ldr     	r0, [sp, #0x38]
0x0050d4:	str     	r7, [sp, #0x10]
0x0050d6:	subs    	r0, r5, r0
0x0050d8:	lsrs    	r1, r0, #0x1f
0x0050da:	adds    	r0, r1, r0
0x0050dc:	asrs    	r0, r0, #1
0x0050de:	str     	r0, [sp, #0x14]
0x0050e0:	ldr     	r0, [sp, #0x3c]
0x0050e2:	str     	r6, [sp, #0x1c]
0x0050e4:	lsrs    	r1, r0, #0x1f
0x0050e6:	adds    	r0, r1, r0
0x0050e8:	asrs    	r0, r0, #1
0x0050ea:	adds    	r0, #2
0x0050ec:	str     	r0, [sp, #0x18]
0x0050ee:	movs    	r0, #0xff
0x0050f0:	str     	r0, [sp, #0x24]
0x0050f2:	str     	r0, [sp, #0x28]
0x0050f4:	str     	r0, [sp, #0x2c]
0x0050f6:	movs    	r0, #1
0x0050f8:	movs    	r1, #0x20
0x0050fa:	add     	r7, sp, #0x10
0x0050fc:	str     	r6, [sp, #0x20]
0x0050fe:	strb    	r0, [r1, r7]
0x005100:	movs    	r1, #0
0x005102:	movs    	r2, #0
0x005104:	str     	r2, [sp, #8]
0x005106:	str     	r1, [sp]
0x005108:	str     	r1, [sp, #4]
0x00510a:	str     	r0, [sp, #0x34]
0x00510c:	adds    	r3, r6, #0
0x00510e:	adds    	r2, r7, #0
0x005110:	movs    	r0, #0xf1
0x005112:	movs    	r1, #0x25
0x005114:	lsls    	r0, r0, #9
0x005116:	bl      	#0x9124
0x00511a:	movs    	r1, #0
0x00511c:	str     	r1, [sp]
0x00511e:	str     	r1, [sp, #4]
0x005120:	movs    	r2, #0
0x005122:	movs    	r1, #0x1c
0x005124:	adds    	r3, r6, #0
0x005126:	movs    	r0, #0xf1
0x005128:	lsls    	r0, r0, #9
0x00512a:	str     	r2, [sp, #8]
0x00512c:	bl      	#0x9124
0x005130:	movs    	r1, #0
0x005132:	adds    	r7, r0, #0
0x005134:	str     	r1, [sp]
0x005136:	str     	r1, [sp, #4]
0x005138:	movs    	r2, #0
0x00513a:	movs    	r1, #0x1d
0x00513c:	movs    	r0, #0xf1
0x00513e:	adds    	r3, r6, #0
0x005140:	lsls    	r0, r0, #9
0x005142:	str     	r2, [sp, #8]
0x005144:	bl      	#0x9124
0x005148:	subs    	r6, r0, r4
0x00514a:	ldr     	r0, [sp, #0x40]
0x00514c:	adds    	r3, r0, #1
0x00514e:	beq     	#0x5152
0x005150:	subs    	r6, r6, r4
0x005152:	movs    	r1, #0
0x005154:	str     	r1, [sp]
0x005156:	str     	r1, [sp, #4]
0x005158:	movs    	r2, #0
0x00515a:	movs    	r1, #0x1c
0x00515c:	movs    	r3, #0
0x00515e:	movs    	r0, #0xf1
0x005160:	lsls    	r0, r0, #9
0x005162:	str     	r2, [sp, #8]
0x005164:	bl      	#0x9124
0x005168:	subs    	r0, r0, r7
0x00516a:	asrs    	r0, r0, #1

; ===== candidate_005334 =====
0x005334:	push    	{r4, r5, r6, r7, lr}
0x005336:	sub     	sp, #0x4c
0x005338:	movs    	r3, #0x19
0x00533a:	movs    	r1, #0
0x00533c:	str     	r3, [sp, #0x48]
0x00533e:	str     	r1, [sp]
0x005340:	str     	r1, [sp, #4]
0x005342:	movs    	r5, #0
0x005344:	movs    	r2, #0
0x005346:	adds    	r3, r5, #0
0x005348:	movs    	r1, #0x1c
0x00534a:	movs    	r0, #0xf1
0x00534c:	lsls    	r0, r0, #9
0x00534e:	str     	r2, [sp, #8]
0x005350:	bl      	#0x9124
0x005354:	movs    	r1, #0
0x005356:	adds    	r7, r0, #0
0x005358:	str     	r1, [sp]
0x00535a:	str     	r1, [sp, #4]
0x00535c:	movs    	r2, #0
0x00535e:	movs    	r1, #0x1d
0x005360:	movs    	r0, #0xf1
0x005362:	adds    	r3, r5, #0
0x005364:	lsls    	r0, r0, #9
0x005366:	str     	r2, [sp, #8]
0x005368:	bl      	#0x9124
0x00536c:	ldr     	r4, [pc, #0x250]
0x00536e:	str     	r0, [sp, #0x3c]
0x005370:	movs    	r6, #0x19
0x005372:	add     	r4, pc
0x005374:	movs    	r1, #0
0x005376:	movs    	r2, #0
0x005378:	str     	r2, [sp, #8]
0x00537a:	str     	r1, [sp]
0x00537c:	str     	r1, [sp, #4]
0x00537e:	movs    	r1, #0xe1
0x005380:	movs    	r2, #0xed
0x005382:	adds    	r3, r5, #0
0x005384:	movs    	r0, #0xf1
0x005386:	lsls    	r0, r0, #9
0x005388:	bl      	#0x9124
0x00538c:	cmp     	r0, #0
0x00538e:	ble     	#0x5476
0x005390:	movs    	r1, #0
0x005392:	str     	r1, [sp]
0x005394:	str     	r1, [sp, #4]
0x005396:	movs    	r1, #0xff
0x005398:	movs    	r2, #0
0x00539a:	adds    	r1, #0x25
0x00539c:	movs    	r3, #0
0x00539e:	movs    	r0, #0xf1
0x0053a0:	lsls    	r0, r0, #9
0x0053a2:	str     	r2, [sp, #8]
0x0053a4:	bl      	#0x9124
0x0053a8:	movs    	r2, #0
0x0053aa:	movs    	r1, #0
0x0053ac:	movs    	r0, #0
0x0053ae:	bl      	#0x90d4
0x0053b2:	ldr     	r1, [sp, #0x48]
0x0053b4:	movs    	r2, #0
0x0053b6:	str     	r1, [sp, #4]
0x0053b8:	movs    	r1, #0x32
0x0053ba:	adds    	r3, r5, #0
0x0053bc:	movs    	r0, #0xf1
0x0053be:	lsls    	r0, r0, #9
0x0053c0:	str     	r2, [sp, #8]
0x0053c2:	str     	r7, [sp]
0x0053c4:	bl      	#0x9124
0x0053c8:	add     	r2, sp, #0x40
0x0053ca:	add     	r1, sp, #0x44
0x0053cc:	movs    	r0, #0
0x0053ce:	str     	r0, [sp]
0x0053d0:	str     	r1, [sp, #4]
0x0053d2:	str     	r2, [sp, #8]
0x0053d4:	adds    	r3, r5, #0
0x0053d6:	adds    	r2, r4, #0
0x0053d8:	movs    	r1, #0x2a
0x0053da:	movs    	r0, #0xf1
0x0053dc:	lsls    	r0, r0, #9
0x0053de:	bl      	#0x9124
0x0053e2:	ldr     	r0, [sp, #0x44]
0x0053e4:	movs    	r2, #0
0x0053e6:	subs    	r0, r7, r0
0x0053e8:	lsrs    	r1, r0, #0x1f
0x0053ea:	adds    	r0, r1, r0
0x0053ec:	asrs    	r0, r0, #1
0x0053ee:	str     	r0, [sp, #0x1c]
0x0053f0:	movs    	r0, #5
0x0053f2:	str     	r0, [sp, #0x20]
0x0053f4:	movs    	r0, #0xff
0x0053f6:	str     	r0, [sp, #0x24]
0x0053f8:	str     	r0, [sp, #0x28]
0x0053fa:	movs    	r1, #0
0x0053fc:	str     	r1, [sp]
0x0053fe:	str     	r1, [sp, #4]
0x005400:	str     	r0, [sp, #0x2c]
0x005402:	movs    	r0, #0xf1
0x005404:	movs    	r1, #0x56
0x005406:	str     	r2, [sp, #8]
0x005408:	adds    	r3, r5, #0
0x00540a:	lsls    	r0, r0, #9
0x00540c:	add     	r2, sp, #0x18
0x00540e:	str     	r4, [sp, #0x18]
0x005410:	str     	r5, [sp, #0x30]
0x005412:	str     	r5, [sp, #0x34]
0x005414:	bl      	#0x9124
0x005418:	ldr     	r0, [sp, #0x3c]
0x00541a:	movs    	r1, #0
0x00541c:	subs    	r0, #0x19
0x00541e:	str     	r0, [sp, #0x3c]
0x005420:	ldr     	r0, [pc, #0x1a0]
0x005422:	str     	r1, [sp]
0x005424:	str     	r1, [sp, #4]
0x005426:	movs    	r5, #0x19
0x005428:	movs    	r2, #0
0x00542a:	str     	r2, [sp, #8]
0x00542c:	str     	r5, [sp, #0x38]
0x00542e:	add     	r0, sb
0x005430:	ldr     	r2, [r0, #0x30]
0x005432:	movs    	r0, #0xf1
0x005434:	movs    	r1, #0x11
0x005436:	movs    	r3, #4
0x005438:	lsls    	r0, r0, #9
0x00543a:	bl      	#0x9124
0x00543e:	adds    	r5, r0, #0
0x005440:	cmp     	r0, #0
0x005442:	ble     	#0x5518
0x005444:	adds    	r0, r6, #0
0x005446:	ldr     	r1, [sp, #0x3c]
0x005448:	blx     	#0x20
0x00544c:	adds    	r4, r0, #0
0x00544e:	ldr     	r0, [pc, #0x174]
0x005450:	movs    	r1, #0x3b
0x005452:	add     	r0, sb
0x005454:	ldr     	r2, [r0, #0x38]
0x005456:	ldr     	r0, [sp, #0x3c]
0x005458:	str     	r2, [sp, #8]
0x00545a:	adds    	r2, r7, #0
0x00545c:	subs    	r2, #0xc
0x00545e:	str     	r0, [sp]
0x005460:	movs    	r0, #0xf1

; ===== candidate_0055cc =====
0x0055cc:	push    	{r4, r5, r6, r7, lr}
0x0055ce:	ldr     	r1, [pc, #0x118]
0x0055d0:	sub     	sp, #0x2c
0x0055d2:	add     	r1, sb
0x0055d4:	ldr     	r0, [r1, #0x38]
0x0055d6:	ldr     	r1, [r1, #0x30]
0x0055d8:	lsls    	r0, r0, #2
0x0055da:	ldr     	r4, [r1, r0]
0x0055dc:	movs    	r1, #0
0x0055de:	str     	r1, [sp]
0x0055e0:	str     	r1, [sp, #4]
0x0055e2:	movs    	r5, #0
0x0055e4:	movs    	r2, #0
0x0055e6:	adds    	r3, r5, #0
0x0055e8:	movs    	r1, #0xff
0x0055ea:	adds    	r1, #0x10
0x0055ec:	str     	r2, [sp, #8]
0x0055ee:	movs    	r0, #0xf1
0x0055f0:	lsls    	r0, r0, #9
0x0055f2:	ldr     	r2, [r4, #4]
0x0055f4:	bl      	#0x9124
0x0055f8:	movs    	r1, #0
0x0055fa:	str     	r1, [sp]
0x0055fc:	str     	r1, [sp, #4]
0x0055fe:	movs    	r2, #0
0x005600:	adds    	r6, r0, #0
0x005602:	movs    	r0, #0xf1
0x005604:	str     	r2, [sp, #8]
0x005606:	movs    	r1, #0x11
0x005608:	movs    	r3, #4
0x00560a:	lsls    	r0, r0, #9
0x00560c:	ldr     	r2, [r4, #4]
0x00560e:	bl      	#0x9124
0x005612:	adds    	r7, r0, #0
0x005614:	movs    	r0, #0
0x005616:	add     	r2, sp, #0x24
0x005618:	add     	r1, sp, #0x28
0x00561a:	str     	r1, [sp, #4]
0x00561c:	str     	r2, [sp, #8]
0x00561e:	str     	r0, [sp]
0x005620:	ldr     	r0, [r4, #4]
0x005622:	lsls    	r1, r6, #2
0x005624:	ldr     	r2, [r0, r1]
0x005626:	movs    	r0, #0xf1
0x005628:	movs    	r1, #0x2a
0x00562a:	adds    	r3, r5, #0
0x00562c:	lsls    	r0, r0, #9
0x00562e:	bl      	#0x9124
0x005632:	ldr     	r0, [sp, #0x24]
0x005634:	ldr     	r6, [sp, #0x28]
0x005636:	movs    	r1, #0
0x005638:	muls    	r7, r0, r7
0x00563a:	movs    	r2, #0
0x00563c:	str     	r2, [sp, #8]
0x00563e:	str     	r1, [sp]
0x005640:	str     	r1, [sp, #4]
0x005642:	adds    	r6, #0x32
0x005644:	adds    	r7, #0xa
0x005646:	adds    	r3, r5, #0
0x005648:	movs    	r1, #0x14
0x00564a:	movs    	r2, #0xef
0x00564c:	movs    	r0, #0xf1
0x00564e:	lsls    	r0, r0, #9
0x005650:	bl      	#0x9124
0x005654:	ldr     	r0, [r4, #4]
0x005656:	movs    	r1, #0
0x005658:	str     	r1, [sp]
0x00565a:	str     	r1, [sp, #4]
0x00565c:	movs    	r2, #0
0x00565e:	str     	r0, [sp, #0xc]
0x005660:	movs    	r0, #0xf1
0x005662:	movs    	r1, #0x1c
0x005664:	adds    	r3, r5, #0
0x005666:	lsls    	r0, r0, #9
0x005668:	str     	r2, [sp, #8]
0x00566a:	bl      	#0x9124
0x00566e:	subs    	r0, r0, r6
0x005670:	movs    	r1, #0
0x005672:	asrs    	r0, r0, #1
0x005674:	str     	r0, [sp, #0x10]
0x005676:	str     	r1, [sp]
0x005678:	str     	r1, [sp, #4]
0x00567a:	movs    	r2, #0
0x00567c:	movs    	r1, #0x1d
0x00567e:	movs    	r0, #0xf1
0x005680:	adds    	r3, r5, #0
0x005682:	lsls    	r0, r0, #9
0x005684:	str     	r2, [sp, #8]
0x005686:	bl      	#0x9124
0x00568a:	subs    	r0, r0, r7
0x00568c:	asrs    	r0, r0, #1
0x00568e:	str     	r0, [sp, #0x14]
0x005690:	ldr     	r0, [pc, #0x54]
0x005692:	movs    	r1, #0
0x005694:	add     	r0, sb
0x005696:	adds    	r0, #0x3c
0x005698:	str     	r0, [sp, #0x20]
0x00569a:	movs    	r2, #0
0x00569c:	str     	r1, [sp]
0x00569e:	str     	r1, [sp, #4]
0x0056a0:	movs    	r1, #0x2b
0x0056a2:	str     	r2, [sp, #8]
0x0056a4:	movs    	r0, #0xf1
0x0056a6:	adds    	r3, r5, #0
0x0056a8:	lsls    	r0, r0, #9
0x0056aa:	add     	r2, sp, #0xc
0x0056ac:	str     	r6, [sp, #0x18]
0x0056ae:	str     	r7, [sp, #0x1c]
0x0056b0:	bl      	#0x9124
0x0056b4:	movs    	r1, #0
0x0056b6:	movs    	r2, #0
0x0056b8:	str     	r2, [sp, #8]
0x0056ba:	str     	r1, [sp]
0x0056bc:	str     	r1, [sp, #4]
0x0056be:	movs    	r1, #0x14
0x0056c0:	movs    	r2, #0x30
0x0056c2:	movs    	r3, #0xc
0x0056c4:	movs    	r0, #0xf1
0x0056c6:	lsls    	r0, r0, #9
0x0056c8:	bl      	#0x9124
0x0056cc:	movs    	r1, #0
0x0056ce:	movs    	r2, #0
0x0056d0:	str     	r2, [sp, #8]
0x0056d2:	str     	r1, [sp]
0x0056d4:	str     	r1, [sp, #4]
0x0056d6:	movs    	r1, #0x24
0x0056d8:	movs    	r2, #1
0x0056da:	movs    	r3, #1
0x0056dc:	movs    	r0, #0xf1
0x0056de:	lsls    	r0, r0, #9
0x0056e0:	bl      	#0x9124
0x0056e4:	add     	sp, #0x2c
0x0056e6:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0056ec =====
0x0056ec:	push    	{r4, r5, r6, r7, lr}
0x0056ee:	ldr     	r7, [pc, #0x3e4]
0x0056f0:	movs    	r4, #0x19
0x0056f2:	movs    	r5, #0x19
0x0056f4:	sub     	sp, #0x5c
0x0056f6:	add     	r7, pc
0x0056f8:	movs    	r1, #0
0x0056fa:	movs    	r2, #0
0x0056fc:	str     	r2, [sp, #8]
0x0056fe:	str     	r1, [sp]
0x005700:	str     	r1, [sp, #4]
0x005702:	movs    	r6, #0
0x005704:	adds    	r3, r6, #0
0x005706:	movs    	r1, #0xe1
0x005708:	movs    	r2, #0xed
0x00570a:	movs    	r0, #0xf1
0x00570c:	lsls    	r0, r0, #9
0x00570e:	bl      	#0x9124
0x005712:	cmp     	r0, #0
0x005714:	ble     	#0x57fa
0x005716:	movs    	r1, #0
0x005718:	str     	r1, [sp]
0x00571a:	str     	r1, [sp, #4]
0x00571c:	movs    	r1, #0xff
0x00571e:	movs    	r2, #0
0x005720:	adds    	r3, r6, #0
0x005722:	adds    	r1, #0x25
0x005724:	movs    	r0, #0xf1
0x005726:	lsls    	r0, r0, #9
0x005728:	str     	r2, [sp, #8]
0x00572a:	bl      	#0x9124
0x00572e:	movs    	r2, #0
0x005730:	movs    	r1, #0
0x005732:	movs    	r0, #0
0x005734:	bl      	#0x90d4
0x005738:	movs    	r1, #0
0x00573a:	str     	r1, [sp]
0x00573c:	str     	r1, [sp, #4]
0x00573e:	movs    	r2, #0
0x005740:	movs    	r1, #0x1c
0x005742:	adds    	r3, r6, #0
0x005744:	movs    	r0, #0xf1
0x005746:	lsls    	r0, r0, #9
0x005748:	str     	r2, [sp, #8]
0x00574a:	bl      	#0x9124
0x00574e:	movs    	r2, #0
0x005750:	str     	r0, [sp]
0x005752:	movs    	r0, #0xf1
0x005754:	adds    	r3, r6, #0
0x005756:	movs    	r1, #0x32
0x005758:	lsls    	r0, r0, #9
0x00575a:	str     	r2, [sp, #8]
0x00575c:	str     	r4, [sp, #4]
0x00575e:	bl      	#0x9124
0x005762:	add     	r2, sp, #0x48
0x005764:	add     	r1, sp, #0x4c
0x005766:	movs    	r0, #0
0x005768:	str     	r0, [sp]
0x00576a:	str     	r1, [sp, #4]
0x00576c:	str     	r2, [sp, #8]
0x00576e:	adds    	r3, r6, #0
0x005770:	adds    	r2, r7, #0
0x005772:	movs    	r1, #0x2a
0x005774:	movs    	r0, #0xf1
0x005776:	lsls    	r0, r0, #9
0x005778:	bl      	#0x9124
0x00577c:	movs    	r1, #0
0x00577e:	str     	r1, [sp]
0x005780:	str     	r1, [sp, #4]
0x005782:	movs    	r2, #0
0x005784:	movs    	r1, #0x1c
0x005786:	adds    	r3, r6, #0
0x005788:	movs    	r0, #0xf1
0x00578a:	lsls    	r0, r0, #9
0x00578c:	str     	r2, [sp, #8]
0x00578e:	str     	r7, [sp, #0x18]
0x005790:	bl      	#0x9124
0x005794:	ldr     	r1, [sp, #0x4c]
0x005796:	movs    	r2, #0
0x005798:	subs    	r0, r0, r1
0x00579a:	lsrs    	r1, r0, #0x1f
0x00579c:	adds    	r0, r1, r0
0x00579e:	asrs    	r0, r0, #1
0x0057a0:	str     	r0, [sp, #0x1c]
0x0057a2:	movs    	r0, #6
0x0057a4:	str     	r0, [sp, #0x20]
0x0057a6:	movs    	r0, #0xff
0x0057a8:	str     	r0, [sp, #0x24]
0x0057aa:	str     	r0, [sp, #0x28]
0x0057ac:	movs    	r1, #0
0x0057ae:	str     	r1, [sp]
0x0057b0:	str     	r1, [sp, #4]
0x0057b2:	str     	r0, [sp, #0x2c]
0x0057b4:	movs    	r0, #0xf1
0x0057b6:	movs    	r1, #0x56
0x0057b8:	str     	r2, [sp, #8]
0x0057ba:	adds    	r3, r6, #0
0x0057bc:	lsls    	r0, r0, #9
0x0057be:	add     	r2, sp, #0x18
0x0057c0:	str     	r6, [sp, #0x30]
0x0057c2:	str     	r6, [sp, #0x34]
0x0057c4:	bl      	#0x9124
0x0057c8:	movs    	r1, #0
0x0057ca:	ldr     	r0, [pc, #0x30c]
0x0057cc:	str     	r1, [sp]
0x0057ce:	str     	r1, [sp, #4]
0x0057d0:	movs    	r2, #0
0x0057d2:	str     	r2, [sp, #8]
0x0057d4:	add     	r0, sb
0x0057d6:	ldr     	r2, [r0, #0x1c]
0x0057d8:	movs    	r0, #0xf1
0x0057da:	movs    	r1, #0x11
0x0057dc:	movs    	r3, #4
0x0057de:	lsls    	r0, r0, #9
0x0057e0:	bl      	#0x9124
0x0057e4:	adds    	r7, r0, #0
0x0057e6:	cmp     	r0, #0
0x0057e8:	ble     	#0x58ce
0x0057ea:	movs    	r1, #0
0x0057ec:	movs    	r2, #0
0x0057ee:	str     	r1, [sp]
0x0057f0:	str     	r1, [sp, #4]
0x0057f2:	adds    	r3, r6, #0
0x0057f4:	movs    	r1, #0x1d
0x0057f6:	str     	r2, [sp, #8]
0x0057f8:	b       	#0x57fc
0x0057fa:	b       	#0x5b1a
0x0057fc:	movs    	r0, #0xf1
0x0057fe:	lsls    	r0, r0, #9
0x005800:	bl      	#0x9124
0x005804:	subs    	r0, #0x32
0x005806:	str     	r0, [sp, #0x40]
0x005808:	movs    	r1, #0
0x00580a:	str     	r1, [sp]
0x00580c:	str     	r1, [sp, #4]
0x00580e:	movs    	r2, #0
0x005810:	movs    	r1, #0x1d
0x005812:	movs    	r0, #0xf1
0x005814:	adds    	r3, r6, #0
0x005816:	lsls    	r0, r0, #9
0x005818:	str     	r2, [sp, #8]

; ===== candidate_005b20 =====
0x005b20:	push    	{r4, r5, r6, r7, lr}
0x005b22:	sub     	sp, #0x6c
0x005b24:	movs    	r1, #0
0x005b26:	str     	r1, [sp, #0x48]
0x005b28:	movs    	r2, #0
0x005b2a:	str     	r1, [sp, #4]
0x005b2c:	movs    	r5, #0xf1
0x005b2e:	movs    	r4, #0
0x005b30:	adds    	r3, r4, #0
0x005b32:	lsls    	r5, r5, #9
0x005b34:	movs    	r1, #0x1c
0x005b36:	movs    	r7, #0x19
0x005b38:	adds    	r0, r5, #0
0x005b3a:	str     	r2, [sp]
0x005b3c:	str     	r2, [sp, #8]
0x005b3e:	bl      	#0x9124
0x005b42:	movs    	r1, #0
0x005b44:	str     	r0, [sp, #0x44]
0x005b46:	movs    	r2, #0
0x005b48:	str     	r2, [sp, #8]
0x005b4a:	str     	r1, [sp, #4]
0x005b4c:	str     	r1, [sp]
0x005b4e:	movs    	r1, #0xe1
0x005b50:	movs    	r2, #0x17
0x005b52:	movs    	r3, #0
0x005b54:	adds    	r0, r5, #0
0x005b56:	bl      	#0x9124
0x005b5a:	cmp     	r0, #0xe9
0x005b5c:	bne     	#0x5bd6
0x005b5e:	movs    	r1, #0
0x005b60:	movs    	r2, #0
0x005b62:	str     	r2, [sp, #8]
0x005b64:	str     	r1, [sp]
0x005b66:	str     	r1, [sp, #4]
0x005b68:	movs    	r1, #0xe1
0x005b6a:	movs    	r2, #0x32
0x005b6c:	adds    	r3, r4, #0
0x005b6e:	adds    	r0, r5, #0
0x005b70:	bl      	#0x9124
0x005b74:	cmp     	r0, #0
0x005b76:	bne     	#0x5b92
0x005b78:	movs    	r1, #0
0x005b7a:	movs    	r2, #0
0x005b7c:	str     	r2, [sp, #8]
0x005b7e:	str     	r1, [sp]
0x005b80:	str     	r1, [sp, #4]
0x005b82:	movs    	r1, #0x67
0x005b84:	movs    	r2, #0x14
0x005b86:	adds    	r3, r4, #0
0x005b88:	adds    	r0, r5, #0
0x005b8a:	bl      	#0x9124
0x005b8e:	add     	sp, #0x6c
0x005b90:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0065ac =====
0x0065ac:	push    	{r4, r5, r6, lr}
0x0065ae:	sub     	sp, #0x10
0x0065b0:	movs    	r1, #0
0x0065b2:	movs    	r2, #0
0x0065b4:	str     	r2, [sp, #8]
0x0065b6:	str     	r1, [sp]
0x0065b8:	str     	r1, [sp, #4]
0x0065ba:	movs    	r5, #0xf1
0x0065bc:	movs    	r4, #0
0x0065be:	adds    	r3, r4, #0
0x0065c0:	lsls    	r5, r5, #9
0x0065c2:	movs    	r1, #0xe1
0x0065c4:	movs    	r2, #0x17
0x0065c6:	adds    	r0, r5, #0
0x0065c8:	bl      	#0x9124
0x0065cc:	ldr     	r6, [pc, #0x50]
0x0065ce:	cmp     	r0, #0xe9
0x0065d0:	add     	r6, sb
0x0065d2:	bne     	#0x65ec
0x0065d4:	movs    	r1, #0
0x0065d6:	str     	r1, [sp]
0x0065d8:	str     	r1, [sp, #4]
0x0065da:	movs    	r2, #0
0x0065dc:	str     	r2, [sp, #8]
0x0065de:	movs    	r1, #9
0x0065e0:	adds    	r3, r4, #0
0x0065e2:	adds    	r0, r5, #0
0x0065e4:	ldr     	r2, [r6, #0x78]
0x0065e6:	bl      	#0x9124
0x0065ea:	b       	#0x6604
0x0065ec:	movs    	r1, #0
0x0065ee:	str     	r1, [sp]
0x0065f0:	str     	r1, [sp, #4]
0x0065f2:	movs    	r2, #0
0x0065f4:	movs    	r1, #0xff
0x0065f6:	adds    	r1, #0xb
0x0065f8:	str     	r2, [sp, #8]
0x0065fa:	adds    	r3, r4, #0
0x0065fc:	adds    	r0, r5, #0
0x0065fe:	ldr     	r2, [r6, #0x78]
0x006600:	bl      	#0x9124
0x006604:	str     	r4, [r6, #0x78]
0x006606:	movs    	r1, #0
0x006608:	str     	r1, [sp]
0x00660a:	str     	r1, [sp, #4]
0x00660c:	movs    	r2, #0
0x00660e:	movs    	r1, #0x2c
0x006610:	adds    	r3, r4, #0
0x006612:	adds    	r0, r5, #0
0x006614:	str     	r2, [sp, #8]
0x006616:	bl      	#0x9124
0x00661a:	add     	sp, #0x10
0x00661c:	pop     	{r4, r5, r6, pc}

; ===== candidate_006624 =====
0x006624:	push    	{r4, r5, r6, r7, lr}
0x006626:	sub     	sp, #0xc
0x006628:	movs    	r1, #0
0x00662a:	movs    	r2, #0
0x00662c:	str     	r2, [sp, #8]
0x00662e:	str     	r1, [sp]
0x006630:	str     	r1, [sp, #4]
0x006632:	movs    	r6, #0
0x006634:	adds    	r3, r6, #0
0x006636:	movs    	r1, #0xe1
0x006638:	movs    	r2, #0x3e
0x00663a:	movs    	r0, #0xf1
0x00663c:	lsls    	r0, r0, #9
0x00663e:	bl      	#0x9124
0x006642:	movs    	r2, #0
0x006644:	movs    	r1, #0
0x006646:	str     	r2, [sp, #8]
0x006648:	adds    	r2, r0, #0
0x00664a:	str     	r1, [sp]
0x00664c:	str     	r1, [sp, #4]
0x00664e:	movs    	r1, #0x11
0x006650:	movs    	r0, #0xf1
0x006652:	movs    	r3, #4
0x006654:	lsls    	r0, r0, #9
0x006656:	bl      	#0x9124
0x00665a:	adds    	r7, r0, #0
0x00665c:	movs    	r4, #0
0x00665e:	cmp     	r0, #0
0x006660:	ble     	#0x66cc
0x006662:	movs    	r1, #0
0x006664:	movs    	r2, #0
0x006666:	str     	r2, [sp, #8]
0x006668:	str     	r1, [sp]
0x00666a:	str     	r1, [sp, #4]
0x00666c:	movs    	r1, #0xe1
0x00666e:	movs    	r2, #0x3e
0x006670:	adds    	r3, r6, #0
0x006672:	movs    	r0, #0xf1
0x006674:	lsls    	r0, r0, #9
0x006676:	bl      	#0x9124
0x00667a:	lsls    	r1, r4, #2
0x00667c:	ldr     	r5, [r0, r1]
0x00667e:	movs    	r1, #0
0x006680:	str     	r1, [sp]
0x006682:	str     	r1, [sp, #4]
0x006684:	movs    	r2, #0
0x006686:	str     	r2, [sp, #8]
0x006688:	movs    	r1, #9
0x00668a:	movs    	r0, #0xf1
0x00668c:	adds    	r3, r6, #0
0x00668e:	lsls    	r0, r0, #9
0x006690:	ldr     	r2, [r5]
0x006692:	bl      	#0x9124
0x006696:	movs    	r1, #0
0x006698:	str     	r1, [sp]
0x00669a:	str     	r1, [sp, #4]
0x00669c:	movs    	r2, #0
0x00669e:	str     	r2, [sp, #8]
0x0066a0:	movs    	r1, #9
0x0066a2:	adds    	r3, r6, #0
0x0066a4:	movs    	r0, #0xf1
0x0066a6:	lsls    	r0, r0, #9
0x0066a8:	ldr     	r2, [r5, #4]
0x0066aa:	bl      	#0x9124
0x0066ae:	movs    	r1, #0
0x0066b0:	movs    	r2, #0
0x0066b2:	str     	r2, [sp, #8]
0x0066b4:	str     	r1, [sp]
0x0066b6:	str     	r1, [sp, #4]
0x0066b8:	adds    	r3, r6, #0
0x0066ba:	adds    	r2, r5, #0
0x0066bc:	movs    	r1, #9
0x0066be:	movs    	r0, #0xf1
0x0066c0:	lsls    	r0, r0, #9
0x0066c2:	bl      	#0x9124
0x0066c6:	adds    	r4, #1
0x0066c8:	cmp     	r4, r7
0x0066ca:	blt     	#0x6662
0x0066cc:	movs    	r1, #0
0x0066ce:	movs    	r2, #0
0x0066d0:	str     	r2, [sp, #8]
0x0066d2:	str     	r1, [sp]
0x0066d4:	str     	r1, [sp, #4]
0x0066d6:	movs    	r1, #0xe1
0x0066d8:	movs    	r2, #0x3e
0x0066da:	adds    	r3, r6, #0
0x0066dc:	movs    	r0, #0xf1
0x0066de:	lsls    	r0, r0, #9
0x0066e0:	bl      	#0x9124
0x0066e4:	movs    	r2, #0
0x0066e6:	movs    	r1, #0
0x0066e8:	str     	r2, [sp, #8]
0x0066ea:	adds    	r3, r6, #0
0x0066ec:	adds    	r2, r0, #0
0x0066ee:	str     	r1, [sp]
0x0066f0:	str     	r1, [sp, #4]
0x0066f2:	movs    	r1, #9
0x0066f4:	movs    	r0, #0xf1
0x0066f6:	lsls    	r0, r0, #9
0x0066f8:	bl      	#0x9124
0x0066fc:	movs    	r1, #0
0x0066fe:	movs    	r2, #0
0x006700:	str     	r2, [sp, #8]
0x006702:	str     	r1, [sp]
0x006704:	str     	r1, [sp, #4]
0x006706:	movs    	r1, #0x14
0x006708:	movs    	r2, #0x3e
0x00670a:	adds    	r3, r6, #0
0x00670c:	movs    	r0, #0xf1
0x00670e:	lsls    	r0, r0, #9
0x006710:	bl      	#0x9124
0x006714:	movs    	r1, #0
0x006716:	str     	r1, [sp]
0x006718:	str     	r1, [sp, #4]
0x00671a:	movs    	r2, #0
0x00671c:	ldr     	r4, [pc, #0x2c]
0x00671e:	str     	r2, [sp, #8]
0x006720:	movs    	r1, #0x12
0x006722:	adds    	r3, r6, #0
0x006724:	movs    	r0, #0xf1
0x006726:	add     	r4, sb
0x006728:	ldr     	r2, [r4, #0x50]
0x00672a:	lsls    	r0, r0, #9
0x00672c:	bl      	#0x9124
0x006730:	str     	r6, [r4, #0x50]
0x006732:	movs    	r1, #0
0x006734:	str     	r1, [sp]
0x006736:	str     	r1, [sp, #4]
0x006738:	movs    	r2, #0
0x00673a:	movs    	r1, #0x2c
0x00673c:	adds    	r3, r6, #0
0x00673e:	movs    	r0, #0xf1
0x006740:	lsls    	r0, r0, #9
0x006742:	str     	r2, [sp, #8]
0x006744:	bl      	#0x9124
0x006748:	add     	sp, #0xc
0x00674a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_006810 =====
0x006810:	push    	{r4, r5, lr}
0x006812:	sub     	sp, #0xc
0x006814:	cmp     	r0, #0xc
0x006816:	bhs     	#0x6822
0x006818:	adr     	r3, #8
0x00681a:	adds    	r3, r3, r0
0x00681c:	ldrh    	r3, [r3, r0]
0x00681e:	lsls    	r3, r3, #1
0x006820:	add     	pc, r3
0x006822:	b       	#0x69ee
0x006824:	lsls    	r5, r4, #3
0x006826:	movs    	r4, r1
0x006828:	movs    	r0, r7
0x00682a:	movs    	r0, r7
0x00682c:	lsls    	r4, r4, #1
0x00682e:	lsls    	r6, r1, #2
0x006830:	lsls    	r5, r4, #3
0x006832:	lsls    	r5, r4, #3
0x006834:	lsls    	r5, r4, #3
0x006836:	lsls    	r5, r4, #3
0x006838:	lsls    	r5, r4, #3
0x00683a:	lsls    	r2, r7, #2
0x00683c:	movs    	r1, #0
0x00683e:	movs    	r2, #0
0x006840:	str     	r2, [sp, #8]
0x006842:	str     	r1, [sp]
0x006844:	str     	r1, [sp, #4]
0x006846:	movs    	r4, #0
0x006848:	adds    	r3, r4, #0
0x00684a:	movs    	r1, #0xe1
0x00684c:	movs    	r2, #0x91
0x00684e:	movs    	r0, #0xf1
0x006850:	lsls    	r0, r0, #9
0x006852:	bl      	#0x9124
0x006856:	movs    	r1, #0xf8
0x006858:	str     	r1, [r0]
0x00685a:	movs    	r1, #0
0x00685c:	movs    	r2, #0
0x00685e:	str     	r2, [sp, #8]
0x006860:	str     	r1, [sp]
0x006862:	str     	r1, [sp, #4]
0x006864:	movs    	r1, #0xe1
0x006866:	movs    	r2, #0x91
0x006868:	movs    	r0, #0xf1
0x00686a:	adds    	r3, r4, #0
0x00686c:	lsls    	r0, r0, #9
0x00686e:	bl      	#0x9124
0x006872:	movs    	r1, #0xfc
0x006874:	str     	r1, [r0, #4]
0x006876:	movs    	r1, #0
0x006878:	movs    	r2, #0
0x00687a:	str     	r2, [sp, #8]
0x00687c:	str     	r1, [sp]
0x00687e:	str     	r1, [sp, #4]
0x006880:	movs    	r1, #0xe1
0x006882:	movs    	r2, #0x91
0x006884:	movs    	r0, #0xf1
0x006886:	adds    	r3, r4, #0
0x006888:	lsls    	r0, r0, #9
0x00688a:	bl      	#0x9124
0x00688e:	movs    	r1, #0xc8
0x006890:	str     	r1, [r0, #8]
0x006892:	b       	#0x6a44
0x006894:	movs    	r1, #0
0x006896:	movs    	r2, #0
0x006898:	str     	r2, [sp, #8]
0x00689a:	str     	r1, [sp]
0x00689c:	str     	r1, [sp, #4]
0x00689e:	movs    	r4, #0
0x0068a0:	adds    	r3, r4, #0
0x0068a2:	movs    	r1, #0xe1
0x0068a4:	movs    	r2, #0x91
0x0068a6:	movs    	r0, #0xf1
0x0068a8:	lsls    	r0, r0, #9
0x0068aa:	bl      	#0x9124
0x0068ae:	movs    	r1, #0x99
0x0068b0:	str     	r1, [r0]
0x0068b2:	movs    	r1, #0
0x0068b4:	movs    	r2, #0
0x0068b6:	str     	r2, [sp, #8]
0x0068b8:	str     	r1, [sp]
0x0068ba:	str     	r1, [sp, #4]
0x0068bc:	movs    	r1, #0xe1
0x0068be:	movs    	r2, #0x91
0x0068c0:	movs    	r0, #0xf1
0x0068c2:	adds    	r3, r4, #0
0x0068c4:	lsls    	r0, r0, #9
0x0068c6:	bl      	#0x9124
0x0068ca:	movs    	r1, #0x9a
0x0068cc:	str     	r1, [r0, #4]
0x0068ce:	movs    	r1, #0
0x0068d0:	movs    	r2, #0
0x0068d2:	str     	r2, [sp, #8]
0x0068d4:	str     	r1, [sp]
0x0068d6:	str     	r1, [sp, #4]
0x0068d8:	movs    	r1, #0xe1
0x0068da:	movs    	r2, #0x91
0x0068dc:	movs    	r0, #0xf1
0x0068de:	adds    	r3, r4, #0
0x0068e0:	lsls    	r0, r0, #9
0x0068e2:	bl      	#0x9124
0x0068e6:	movs    	r1, #0xf9
0x0068e8:	str     	r1, [r0, #8]
0x0068ea:	b       	#0x6a44
0x0068ec:	movs    	r1, #0
0x0068ee:	movs    	r2, #0
0x0068f0:	str     	r2, [sp, #8]
0x0068f2:	str     	r1, [sp]
0x0068f4:	str     	r1, [sp, #4]
0x0068f6:	movs    	r4, #0
0x0068f8:	adds    	r3, r4, #0
0x0068fa:	movs    	r1, #0xe1
0x0068fc:	movs    	r2, #0x91
0x0068fe:	movs    	r0, #0xf1
0x006900:	lsls    	r0, r0, #9
0x006902:	bl      	#0x9124
0x006906:	movs    	r5, #0xc0
0x006908:	str     	r5, [r0]
0x00690a:	movs    	r1, #0
0x00690c:	movs    	r2, #0
0x00690e:	str     	r2, [sp, #8]
0x006910:	str     	r1, [sp]
0x006912:	str     	r1, [sp, #4]
0x006914:	movs    	r1, #0xe1
0x006916:	movs    	r2, #0x91
0x006918:	movs    	r0, #0xf1
0x00691a:	adds    	r3, r4, #0
0x00691c:	lsls    	r0, r0, #9
0x00691e:	bl      	#0x9124
0x006922:	str     	r5, [r0, #4]
0x006924:	movs    	r1, #0
0x006926:	movs    	r2, #0
0x006928:	str     	r2, [sp, #8]
0x00692a:	str     	r1, [sp]
0x00692c:	str     	r1, [sp, #4]
0x00692e:	movs    	r1, #0xe1
0x006930:	movs    	r2, #0x91
0x006932:	movs    	r0, #0xf1
0x006934:	adds    	r3, r4, #0
0x006936:	lsls    	r0, r0, #9
0x006938:	bl      	#0x9124

; ===== candidate_006a60 =====
0x006a60:	push    	{r4, r5, r6, r7, lr}
0x006a62:	ldr     	r6, [pc, #0x7c]
0x006a64:	adds    	r7, r0, #0
0x006a66:	add     	r6, sb
0x006a68:	ldr     	r0, [r6, #8]
0x006a6a:	sub     	sp, #0xc
0x006a6c:	cmp     	r0, #0
0x006a6e:	beq     	#0x6a74
0x006a70:	bl      	#0x9ddc
0x006a74:	movs    	r1, #0
0x006a76:	movs    	r2, #0
0x006a78:	str     	r2, [sp, #8]
0x006a7a:	str     	r1, [sp]
0x006a7c:	str     	r1, [sp, #4]
0x006a7e:	movs    	r4, #0
0x006a80:	movs    	r5, #0xf1
0x006a82:	lsls    	r5, r5, #9
0x006a84:	adds    	r3, r4, #0
0x006a86:	movs    	r1, #0xe1
0x006a88:	movs    	r2, #0x17
0x006a8a:	adds    	r0, r5, #0
0x006a8c:	bl      	#0x9124
0x006a90:	cmp     	r0, #0xe8
0x006a92:	beq     	#0x6aa8
0x006a94:	movs    	r1, #0
0x006a96:	str     	r1, [sp]
0x006a98:	str     	r1, [sp, #4]
0x006a9a:	movs    	r2, #0
0x006a9c:	movs    	r1, #0x34
0x006a9e:	adds    	r3, r4, #0
0x006aa0:	adds    	r0, r5, #0
0x006aa2:	str     	r2, [sp, #8]
0x006aa4:	bl      	#0x9124
0x006aa8:	str     	r4, [r6, #0xc]
0x006aaa:	str     	r4, [r6, #0x18]
0x006aac:	str     	r7, [r6, #8]
0x006aae:	str     	r4, [r6, #0x14]
0x006ab0:	movs    	r1, #0
0x006ab2:	movs    	r2, #0
0x006ab4:	str     	r2, [sp, #8]
0x006ab6:	str     	r1, [sp]
0x006ab8:	str     	r1, [sp, #4]
0x006aba:	movs    	r1, #0x14
0x006abc:	movs    	r2, #0x17
0x006abe:	movs    	r3, #0xe8
0x006ac0:	adds    	r0, r5, #0
0x006ac2:	bl      	#0x9124
0x006ac6:	movs    	r1, #0
0x006ac8:	str     	r1, [sp]
0x006aca:	str     	r1, [sp, #4]
0x006acc:	movs    	r2, #0
0x006ace:	movs    	r1, #0xba
0x006ad0:	adds    	r3, r4, #0
0x006ad2:	movs    	r0, #0xf1
0x006ad4:	lsls    	r0, r0, #9
0x006ad6:	str     	r2, [sp, #8]
0x006ad8:	bl      	#0x9124
0x006adc:	add     	sp, #0xc
0x006ade:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_006ae4 =====
0x006ae4:	push    	{r4, r5, r6, r7, lr}
0x006ae6:	sub     	sp, #0xc
0x006ae8:	movs    	r1, #0
0x006aea:	str     	r1, [sp]
0x006aec:	str     	r1, [sp, #4]
0x006aee:	movs    	r7, #0xf1
0x006af0:	movs    	r6, #0
0x006af2:	movs    	r2, #0
0x006af4:	adds    	r3, r6, #0
0x006af6:	lsls    	r7, r7, #9
0x006af8:	movs    	r1, #0x13
0x006afa:	adds    	r5, r0, #0
0x006afc:	adds    	r0, r7, #0
0x006afe:	str     	r2, [sp, #8]
0x006b00:	bl      	#0x9124
0x006b04:	ldr     	r2, [pc, #0x334]
0x006b06:	movs    	r1, #0
0x006b08:	add     	r2, sb
0x006b0a:	str     	r5, [r2, #0x40]
0x006b0c:	str     	r1, [sp]
0x006b0e:	str     	r1, [sp, #4]
0x006b10:	movs    	r1, #0xff
0x006b12:	movs    	r2, #0
0x006b14:	adds    	r1, #0x29
0x006b16:	adds    	r4, r0, #0
0x006b18:	adds    	r3, r6, #0
0x006b1a:	adds    	r0, r7, #0
0x006b1c:	str     	r2, [sp, #8]
0x006b1e:	bl      	#0x9124
0x006b22:	movs    	r1, #0
0x006b24:	str     	r1, [sp]
0x006b26:	str     	r1, [sp, #4]
0x006b28:	movs    	r2, #0
0x006b2a:	movs    	r1, #0x34
0x006b2c:	adds    	r3, r6, #0
0x006b2e:	adds    	r0, r7, #0
0x006b30:	str     	r2, [sp, #8]
0x006b32:	bl      	#0x9124
0x006b36:	movs    	r2, #0
0x006b38:	movs    	r1, #0
0x006b3a:	ldr     	r5, [pc, #0x304]
0x006b3c:	str     	r1, [sp]
0x006b3e:	str     	r1, [sp, #4]
0x006b40:	str     	r2, [sp, #8]
0x006b42:	add     	r5, pc
0x006b44:	adds    	r2, r5, #0
0x006b46:	subs    	r2, #0x10
0x006b48:	adds    	r3, r5, #0
0x006b4a:	movs    	r1, #0x35
0x006b4c:	adds    	r0, r7, #0
0x006b4e:	bl      	#0x9124
0x006b52:	movs    	r1, #0
0x006b54:	movs    	r2, #0
0x006b56:	str     	r2, [sp, #8]
0x006b58:	str     	r1, [sp]
0x006b5a:	str     	r1, [sp, #4]
0x006b5c:	movs    	r1, #0x36
0x006b5e:	adds    	r2, r4, #0
0x006b60:	adds    	r3, r0, #0
0x006b62:	adds    	r0, r7, #0
0x006b64:	bl      	#0x9124
0x006b68:	movs    	r1, #0
0x006b6a:	movs    	r2, #0
0x006b6c:	str     	r2, [sp, #8]
0x006b6e:	str     	r1, [sp]
0x006b70:	str     	r1, [sp, #4]
0x006b72:	movs    	r1, #0xe1
0x006b74:	movs    	r2, #0xf0
0x006b76:	adds    	r3, r6, #0
0x006b78:	adds    	r0, r7, #0
0x006b7a:	bl      	#0x9124
0x006b7e:	adds    	r1, r5, #0
0x006b80:	subs    	r1, #0x10
0x006b82:	str     	r1, [r0, #0x40]
0x006b84:	movs    	r1, #0
0x006b86:	movs    	r2, #0
0x006b88:	str     	r2, [sp, #8]
0x006b8a:	movs    	r2, #0xff
0x006b8c:	str     	r1, [sp]
0x006b8e:	str     	r1, [sp, #4]
0x006b90:	movs    	r1, #0xe1
0x006b92:	adds    	r2, #1
0x006b94:	adds    	r3, r6, #0
0x006b96:	adds    	r0, r7, #0
0x006b98:	bl      	#0x9124
0x006b9c:	cmp     	r0, #1
0x006b9e:	bne     	#0x6be8
0x006ba0:	movs    	r1, #0
0x006ba2:	movs    	r2, #0
0x006ba4:	str     	r2, [sp, #8]
0x006ba6:	str     	r1, [sp]
0x006ba8:	str     	r1, [sp, #4]
0x006baa:	movs    	r1, #0x35
0x006bac:	adds    	r2, r5, #4
0x006bae:	adds    	r3, r5, #0
0x006bb0:	adds    	r0, r7, #0
0x006bb2:	bl      	#0x9124
0x006bb6:	movs    	r1, #0
0x006bb8:	movs    	r2, #0
0x006bba:	str     	r2, [sp, #8]
0x006bbc:	str     	r1, [sp]
0x006bbe:	str     	r1, [sp, #4]
0x006bc0:	movs    	r1, #0x36
0x006bc2:	adds    	r2, r4, #0
0x006bc4:	adds    	r3, r0, #0
0x006bc6:	adds    	r0, r7, #0
0x006bc8:	bl      	#0x9124
0x006bcc:	movs    	r1, #0
0x006bce:	movs    	r2, #0
0x006bd0:	str     	r2, [sp, #8]
0x006bd2:	str     	r1, [sp]
0x006bd4:	str     	r1, [sp, #4]
0x006bd6:	movs    	r1, #0xe1
0x006bd8:	movs    	r2, #0xf0
0x006bda:	adds    	r3, r6, #0
0x006bdc:	adds    	r0, r7, #0
0x006bde:	bl      	#0x9124
0x006be2:	adds    	r1, r5, #4
0x006be4:	str     	r1, [r0, #0x1c]
0x006be6:	b       	#0x6c36
0x006be8:	movs    	r2, #0
0x006bea:	movs    	r1, #0
0x006bec:	str     	r2, [sp, #8]
0x006bee:	ldr     	r2, [pc, #0x254]
0x006bf0:	str     	r1, [sp]
0x006bf2:	str     	r1, [sp, #4]
0x006bf4:	adds    	r3, r5, #0
0x006bf6:	add     	r2, pc
0x006bf8:	movs    	r1, #0x35
0x006bfa:	adds    	r0, r7, #0
0x006bfc:	bl      	#0x9124
0x006c00:	movs    	r1, #0
0x006c02:	adds    	r3, r0, #0
0x006c04:	movs    	r2, #0
0x006c06:	str     	r2, [sp, #8]
0x006c08:	str     	r1, [sp]
0x006c0a:	str     	r1, [sp, #4]
0x006c0c:	movs    	r1, #0x36
0x006c0e:	adds    	r2, r4, #0
0x006c10:	movs    	r0, #0xf1
0x006c12:	lsls    	r0, r0, #9

; ===== candidate_006e68 =====
0x006e68:	push    	{r4, r5, lr}
0x006e6a:	ldr     	r5, [pc, #0x58]
0x006e6c:	sub     	sp, #0xc
0x006e6e:	add     	r5, sb
0x006e70:	str     	r0, [r5, #0x64]
0x006e72:	movs    	r1, #0
0x006e74:	str     	r1, [sp]
0x006e76:	str     	r1, [sp, #4]
0x006e78:	movs    	r4, #0
0x006e7a:	movs    	r2, #0
0x006e7c:	adds    	r3, r4, #0
0x006e7e:	movs    	r1, #0xba
0x006e80:	movs    	r0, #0xf1
0x006e82:	lsls    	r0, r0, #9
0x006e84:	str     	r2, [sp, #8]
0x006e86:	bl      	#0x9124
0x006e8a:	movs    	r1, #0
0x006e8c:	str     	r1, [sp]
0x006e8e:	str     	r1, [sp, #4]
0x006e90:	movs    	r2, #0
0x006e92:	movs    	r1, #0x34
0x006e94:	adds    	r3, r4, #0
0x006e96:	movs    	r0, #0xf1
0x006e98:	lsls    	r0, r0, #9
0x006e9a:	str     	r2, [sp, #8]
0x006e9c:	bl      	#0x9124
0x006ea0:	str     	r4, [r5, #0x68]
0x006ea2:	str     	r4, [r5, #0x6c]
0x006ea4:	movs    	r1, #0
0x006ea6:	movs    	r2, #0
0x006ea8:	str     	r2, [sp, #8]
0x006eaa:	str     	r1, [sp]
0x006eac:	str     	r1, [sp, #4]
0x006eae:	movs    	r3, #0xff
0x006eb0:	adds    	r3, #0x17
0x006eb2:	movs    	r1, #0x14
0x006eb4:	movs    	r2, #0x17
0x006eb6:	movs    	r0, #0xf1
0x006eb8:	lsls    	r0, r0, #9
0x006eba:	bl      	#0x9124
0x006ebe:	add     	sp, #0xc
0x006ec0:	pop     	{r4, r5, pc}

; ===== candidate_006ec8 =====
0x006ec8:	push    	{r4, r5, r6, r7, lr}
0x006eca:	sub     	sp, #0xc
0x006ecc:	movs    	r1, #0
0x006ece:	str     	r1, [sp]
0x006ed0:	str     	r1, [sp, #4]
0x006ed2:	movs    	r7, #0xf1
0x006ed4:	movs    	r5, #0
0x006ed6:	movs    	r2, #0
0x006ed8:	adds    	r3, r5, #0
0x006eda:	lsls    	r7, r7, #9
0x006edc:	movs    	r1, #0x13
0x006ede:	adds    	r0, r7, #0
0x006ee0:	str     	r2, [sp, #8]
0x006ee2:	bl      	#0x9124
0x006ee6:	ldr     	r2, [pc, #0x204]
0x006ee8:	movs    	r1, #0
0x006eea:	add     	r2, sb
0x006eec:	str     	r5, [r2, #0x5c]
0x006eee:	str     	r1, [sp]
0x006ef0:	str     	r1, [sp, #4]
0x006ef2:	movs    	r2, #0
0x006ef4:	movs    	r1, #0x34
0x006ef6:	adds    	r4, r0, #0
0x006ef8:	adds    	r3, r5, #0
0x006efa:	adds    	r0, r7, #0
0x006efc:	str     	r2, [sp, #8]
0x006efe:	bl      	#0x9124
0x006f02:	ldr     	r6, [pc, #0x1e8]
0x006f04:	ldr     	r5, [pc, #0x1e8]
0x006f06:	add     	r6, sb
0x006f08:	adds    	r6, #0x80
0x006f0a:	add     	r5, pc
0x006f0c:	ldr     	r0, [r6, #0x44]
0x006f0e:	cmp     	r0, #0
0x006f10:	beq     	#0x6f6e
0x006f12:	movs    	r2, #0
0x006f14:	movs    	r1, #0
0x006f16:	str     	r2, [sp, #8]
0x006f18:	adds    	r2, r5, #0
0x006f1a:	str     	r1, [sp]
0x006f1c:	str     	r1, [sp, #4]
0x006f1e:	movs    	r1, #0x35
0x006f20:	adds    	r2, #0xb4
0x006f22:	adds    	r3, r5, #0
0x006f24:	adds    	r0, r7, #0
0x006f26:	bl      	#0x9124
0x006f2a:	movs    	r1, #0
0x006f2c:	movs    	r2, #0
0x006f2e:	str     	r2, [sp, #8]
0x006f30:	str     	r1, [sp]
0x006f32:	str     	r1, [sp, #4]
0x006f34:	movs    	r1, #0x36
0x006f36:	adds    	r2, r4, #0
0x006f38:	adds    	r3, r0, #0
0x006f3a:	adds    	r0, r7, #0
0x006f3c:	bl      	#0x9124
0x006f40:	movs    	r2, #0
0x006f42:	movs    	r1, #0
0x006f44:	str     	r2, [sp, #8]
0x006f46:	adds    	r2, r5, #0
0x006f48:	str     	r1, [sp]
0x006f4a:	str     	r1, [sp, #4]
0x006f4c:	movs    	r1, #0x35
0x006f4e:	adds    	r2, #0xa8
0x006f50:	adds    	r3, r5, #0
0x006f52:	adds    	r0, r7, #0
0x006f54:	bl      	#0x9124
0x006f58:	movs    	r1, #0
0x006f5a:	movs    	r2, #0
0x006f5c:	str     	r2, [sp, #8]
0x006f5e:	str     	r1, [sp]
0x006f60:	str     	r1, [sp, #4]
0x006f62:	movs    	r1, #0x36
0x006f64:	adds    	r2, r4, #0
0x006f66:	adds    	r3, r0, #0
0x006f68:	adds    	r0, r7, #0
0x006f6a:	bl      	#0x9124
0x006f6e:	ldr     	r0, [r6, #0x48]
0x006f70:	cmp     	r0, #0
0x006f72:	beq     	#0x7008
0x006f74:	movs    	r2, #0
0x006f76:	movs    	r1, #0
0x006f78:	str     	r2, [sp, #8]
0x006f7a:	ldr     	r2, [pc, #0x178]
0x006f7c:	str     	r1, [sp]
0x006f7e:	str     	r1, [sp, #4]
0x006f80:	adds    	r3, r5, #0
0x006f82:	add     	r2, pc
0x006f84:	movs    	r1, #0x35
0x006f86:	adds    	r0, r7, #0
0x006f88:	bl      	#0x9124
0x006f8c:	movs    	r1, #0
0x006f8e:	adds    	r3, r0, #0
0x006f90:	movs    	r2, #0
0x006f92:	str     	r2, [sp, #8]
0x006f94:	str     	r1, [sp]
0x006f96:	str     	r1, [sp, #4]
0x006f98:	movs    	r1, #0x36
0x006f9a:	adds    	r2, r4, #0
0x006f9c:	movs    	r0, #0xf1
0x006f9e:	lsls    	r0, r0, #9
0x006fa0:	bl      	#0x9124
0x006fa4:	movs    	r2, #0
0x006fa6:	movs    	r1, #0
0x006fa8:	str     	r2, [sp, #8]
0x006faa:	ldr     	r2, [pc, #0x14c]
0x006fac:	str     	r1, [sp]
0x006fae:	str     	r1, [sp, #4]
0x006fb0:	adds    	r3, r5, #0
0x006fb2:	add     	r2, pc
0x006fb4:	movs    	r1, #0x35
0x006fb6:	movs    	r0, #0xf1
0x006fb8:	lsls    	r0, r0, #9
0x006fba:	bl      	#0x9124
0x006fbe:	movs    	r1, #0
0x006fc0:	adds    	r3, r0, #0
0x006fc2:	movs    	r2, #0
0x006fc4:	str     	r2, [sp, #8]
0x006fc6:	str     	r1, [sp]
0x006fc8:	str     	r1, [sp, #4]
0x006fca:	movs    	r1, #0x36
0x006fcc:	adds    	r2, r4, #0
0x006fce:	movs    	r0, #0xf1
0x006fd0:	lsls    	r0, r0, #9
0x006fd2:	bl      	#0x9124
0x006fd6:	movs    	r2, #0
0x006fd8:	movs    	r1, #0
0x006fda:	str     	r2, [sp, #8]
0x006fdc:	ldr     	r2, [pc, #0x11c]
0x006fde:	str     	r1, [sp]
0x006fe0:	str     	r1, [sp, #4]
0x006fe2:	adds    	r3, r5, #0
0x006fe4:	add     	r2, pc
0x006fe6:	movs    	r1, #0x35
0x006fe8:	movs    	r0, #0xf1
0x006fea:	lsls    	r0, r0, #9
0x006fec:	bl      	#0x9124
0x006ff0:	movs    	r1, #0
0x006ff2:	adds    	r3, r0, #0
0x006ff4:	movs    	r2, #0
0x006ff6:	str     	r2, [sp, #8]

; ===== candidate_007104 =====
0x007104:	push    	{r4, lr}
0x007106:	ldr     	r2, [pc, #0x64]
0x007108:	sub     	sp, #0x10
0x00710a:	add     	r2, sb
0x00710c:	str     	r0, [r2, #0x44]
0x00710e:	str     	r1, [r2, #0x48]
0x007110:	movs    	r1, #0
0x007112:	str     	r1, [sp]
0x007114:	str     	r1, [sp, #4]
0x007116:	movs    	r2, #0
0x007118:	movs    	r4, #0
0x00711a:	adds    	r3, r4, #0
0x00711c:	movs    	r1, #0xba
0x00711e:	movs    	r0, #0xf1
0x007120:	lsls    	r0, r0, #9
0x007122:	str     	r2, [sp, #8]
0x007124:	bl      	#0x9124
0x007128:	movs    	r1, #0
0x00712a:	str     	r1, [sp]
0x00712c:	str     	r1, [sp, #4]
0x00712e:	movs    	r2, #0
0x007130:	movs    	r1, #0x34
0x007132:	adds    	r3, r4, #0
0x007134:	movs    	r0, #0xf1
0x007136:	lsls    	r0, r0, #9
0x007138:	str     	r2, [sp, #8]
0x00713a:	bl      	#0x9124
0x00713e:	movs    	r1, #0
0x007140:	movs    	r2, #0
0x007142:	str     	r2, [sp, #8]
0x007144:	str     	r1, [sp]
0x007146:	str     	r1, [sp, #4]
0x007148:	movs    	r3, #0xff
0x00714a:	adds    	r3, #0x14
0x00714c:	movs    	r1, #0x14
0x00714e:	movs    	r2, #0x17
0x007150:	movs    	r0, #0xf1
0x007152:	lsls    	r0, r0, #9
0x007154:	bl      	#0x9124
0x007158:	ldr     	r0, [pc, #0x10]
0x00715a:	ldr     	r1, [pc, #0x14]
0x00715c:	add     	r0, sb
0x00715e:	subs    	r0, #0x80
0x007160:	str     	r4, [r0, #0x54]
0x007162:	add     	r1, pc
0x007164:	str     	r1, [r0, #0x58]
0x007166:	str     	r4, [r0, #4]
0x007168:	add     	sp, #0x10
0x00716a:	pop     	{r4, pc}

; ===== candidate_007174 =====
0x007174:	push    	{r4, r5, lr}
0x007176:	sub     	sp, #0xc
0x007178:	movs    	r1, #0
0x00717a:	adds    	r5, r0, #0
0x00717c:	str     	r1, [sp]
0x00717e:	str     	r1, [sp, #4]
0x007180:	movs    	r4, #0
0x007182:	movs    	r2, #0
0x007184:	adds    	r3, r4, #0
0x007186:	movs    	r1, #0x34
0x007188:	movs    	r0, #0xf1
0x00718a:	lsls    	r0, r0, #9
0x00718c:	str     	r2, [sp, #8]
0x00718e:	bl      	#0x9124
0x007192:	ldr     	r0, [pc, #0x3c]
0x007194:	movs    	r1, #0
0x007196:	add     	r0, sb
0x007198:	str     	r5, [r0, #4]
0x00719a:	str     	r1, [sp]
0x00719c:	str     	r1, [sp, #4]
0x00719e:	movs    	r1, #0xff
0x0071a0:	movs    	r2, #0
0x0071a2:	adds    	r3, r4, #0
0x0071a4:	adds    	r1, #0x20
0x0071a6:	movs    	r0, #0xf1
0x0071a8:	lsls    	r0, r0, #9
0x0071aa:	str     	r2, [sp, #8]
0x0071ac:	bl      	#0x9124
0x0071b0:	movs    	r1, #0
0x0071b2:	str     	r1, [sp, #4]
0x0071b4:	mvns    	r3, r1
0x0071b6:	movs    	r2, #0
0x0071b8:	str     	r2, [sp, #8]
0x0071ba:	movs    	r1, #0xff
0x0071bc:	str     	r0, [sp]
0x0071be:	movs    	r0, #0xf1
0x0071c0:	adds    	r1, #0x3d
0x0071c2:	movs    	r2, #0x19
0x0071c4:	lsls    	r0, r0, #9
0x0071c6:	bl      	#0x9124
0x0071ca:	add     	sp, #0xc
0x0071cc:	pop     	{r4, r5, pc}

; ===== candidate_0071d4 =====
0x0071d4:	push    	{r4, r5, r6, r7, lr}
0x0071d6:	sub     	sp, #0xc
0x0071d8:	movs    	r1, #0
0x0071da:	str     	r1, [sp]
0x0071dc:	str     	r1, [sp, #4]
0x0071de:	movs    	r6, #0xf1
0x0071e0:	movs    	r4, #0
0x0071e2:	movs    	r2, #0
0x0071e4:	adds    	r3, r4, #0
0x0071e6:	lsls    	r6, r6, #9
0x0071e8:	movs    	r1, #0xba
0x0071ea:	adds    	r0, r6, #0
0x0071ec:	str     	r2, [sp, #8]
0x0071ee:	bl      	#0x9124
0x0071f2:	movs    	r1, #0
0x0071f4:	str     	r1, [sp]
0x0071f6:	str     	r1, [sp, #4]
0x0071f8:	movs    	r2, #0
0x0071fa:	movs    	r1, #0x34
0x0071fc:	adds    	r3, r4, #0
0x0071fe:	adds    	r0, r6, #0
0x007200:	str     	r2, [sp, #8]
0x007202:	bl      	#0x9124
0x007206:	ldr     	r5, [pc, #0x148]
0x007208:	movs    	r1, #0
0x00720a:	add     	r5, sb
0x00720c:	str     	r4, [r5, #0x74]
0x00720e:	str     	r4, [r5, #0x1c]
0x007210:	str     	r4, [r5, #0x20]
0x007212:	movs    	r2, #0
0x007214:	str     	r2, [sp, #8]
0x007216:	str     	r1, [sp]
0x007218:	str     	r1, [sp, #4]
0x00721a:	movs    	r1, #0x14
0x00721c:	movs    	r2, #0x17
0x00721e:	movs    	r3, #0x23
0x007220:	adds    	r0, r6, #0
0x007222:	bl      	#0x9124
0x007226:	str     	r4, [r5, #0x2c]
0x007228:	str     	r4, [r5, #0x70]
0x00722a:	str     	r4, [r5, #0x34]
0x00722c:	movs    	r2, #0
0x00722e:	movs    	r1, #0
0x007230:	str     	r2, [sp, #8]
0x007232:	movs    	r2, #0xff
0x007234:	str     	r1, [sp]
0x007236:	str     	r1, [sp, #4]
0x007238:	movs    	r1, #0xe1
0x00723a:	adds    	r2, #0xa
0x00723c:	adds    	r3, r4, #0
0x00723e:	adds    	r0, r6, #0
0x007240:	bl      	#0x9124
0x007244:	movs    	r7, #0xff
0x007246:	adds    	r7, #9
0x007248:	cmp     	r0, #0
0x00724a:	ble     	#0x72e6
0x00724c:	movs    	r1, #0
0x00724e:	movs    	r2, #0
0x007250:	str     	r2, [sp, #8]
0x007252:	str     	r1, [sp]
0x007254:	str     	r1, [sp, #4]
0x007256:	movs    	r1, #0xe1
0x007258:	adds    	r2, r7, #0
0x00725a:	adds    	r3, r4, #0
0x00725c:	adds    	r0, r6, #0
0x00725e:	bl      	#0x9124
0x007262:	movs    	r1, #0
0x007264:	movs    	r2, #0
0x007266:	str     	r2, [sp, #8]
0x007268:	str     	r1, [sp]
0x00726a:	str     	r1, [sp, #4]
0x00726c:	movs    	r1, #0x26
0x00726e:	adds    	r2, r0, #0
0x007270:	adds    	r3, r4, #0
0x007272:	adds    	r0, r6, #0
0x007274:	bl      	#0x9124
0x007278:	adds    	r5, r0, #0
0x00727a:	cmp     	r0, #0
0x00727c:	ble     	#0x72da
0x00727e:	movs    	r7, #0
0x007280:	movs    	r2, #0
0x007282:	movs    	r1, #0
0x007284:	str     	r2, [sp, #8]
0x007286:	movs    	r2, #0xff
0x007288:	str     	r1, [sp]
0x00728a:	str     	r1, [sp, #4]
0x00728c:	adds    	r3, r7, #0
0x00728e:	adds    	r2, #9
0x007290:	movs    	r1, #0xe1
0x007292:	movs    	r0, #0xf1
0x007294:	lsls    	r0, r0, #9
0x007296:	bl      	#0x9124
0x00729a:	movs    	r2, #0
0x00729c:	movs    	r1, #0
0x00729e:	str     	r2, [sp, #8]
0x0072a0:	adds    	r3, r4, #0
0x0072a2:	adds    	r2, r0, #0
0x0072a4:	str     	r1, [sp]
0x0072a6:	str     	r1, [sp, #4]
0x0072a8:	movs    	r1, #0x27
0x0072aa:	movs    	r0, #0xf1
0x0072ac:	lsls    	r0, r0, #9
0x0072ae:	bl      	#0x9124
0x0072b2:	movs    	r2, #0
0x0072b4:	movs    	r1, #0
0x0072b6:	str     	r2, [sp, #8]
0x0072b8:	adds    	r6, r0, #0
0x0072ba:	movs    	r2, #0xff
0x0072bc:	str     	r1, [sp]
0x0072be:	str     	r1, [sp, #4]
0x0072c0:	adds    	r3, r7, #0
0x0072c2:	adds    	r2, #0xb
0x0072c4:	movs    	r1, #0xe1
0x0072c6:	movs    	r0, #0xf1
0x0072c8:	lsls    	r0, r0, #9
0x0072ca:	bl      	#0x9124
0x0072ce:	ldr     	r1, [r6, #4]
0x0072d0:	cmp     	r0, r1
0x0072d2:	bne     	#0x72de
0x0072d4:	ldr     	r5, [pc, #0x78]
0x0072d6:	add     	r5, sb
0x0072d8:	str     	r4, [r5, #0x2c]
0x0072da:	add     	sp, #0xc
0x0072dc:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007354 =====
0x007354:	push    	{r4, r5, lr}
0x007356:	sub     	sp, #0xc
0x007358:	movs    	r1, #0
0x00735a:	movs    	r2, #0
0x00735c:	str     	r2, [sp, #8]
0x00735e:	str     	r1, [sp]
0x007360:	str     	r1, [sp, #4]
0x007362:	movs    	r5, #0xf1
0x007364:	movs    	r4, #0
0x007366:	adds    	r3, r4, #0
0x007368:	lsls    	r5, r5, #9
0x00736a:	movs    	r1, #0xe1
0x00736c:	movs    	r2, #0x7a
0x00736e:	adds    	r0, r5, #0
0x007370:	bl      	#0x9124
0x007374:	cmp     	r0, #0
0x007376:	bne     	#0x73dc
0x007378:	movs    	r1, #0
0x00737a:	str     	r1, [sp]
0x00737c:	str     	r1, [sp, #4]
0x00737e:	movs    	r2, #0
0x007380:	movs    	r1, #0x34
0x007382:	adds    	r3, r4, #0
0x007384:	adds    	r0, r5, #0
0x007386:	str     	r2, [sp, #8]
0x007388:	bl      	#0x9124
0x00738c:	ldr     	r5, [pc, #0x50]
0x00738e:	movs    	r1, #0
0x007390:	add     	r5, sb
0x007392:	str     	r4, [r5, #0x48]
0x007394:	str     	r4, [r5, #0x4c]
0x007396:	movs    	r2, #0
0x007398:	str     	r2, [sp, #8]
0x00739a:	str     	r1, [sp]
0x00739c:	str     	r1, [sp, #4]
0x00739e:	movs    	r1, #0x14
0x0073a0:	movs    	r2, #0x17
0x0073a2:	movs    	r3, #0xfc
0x0073a4:	movs    	r0, #0xf1
0x0073a6:	lsls    	r0, r0, #9
0x0073a8:	bl      	#0x9124
0x0073ac:	movs    	r1, #0
0x0073ae:	movs    	r2, #0
0x0073b0:	str     	r2, [sp, #8]
0x0073b2:	str     	r1, [sp]
0x0073b4:	str     	r1, [sp, #4]
0x0073b6:	movs    	r1, #0x14
0x0073b8:	movs    	r2, #0xf1
0x0073ba:	adds    	r3, r4, #0
0x0073bc:	lsls    	r0, r2, #9
0x0073be:	bl      	#0x9124
0x0073c2:	movs    	r1, #0
0x0073c4:	movs    	r2, #0
0x0073c6:	str     	r2, [sp, #8]
0x0073c8:	str     	r1, [sp]
0x0073ca:	str     	r1, [sp, #4]
0x0073cc:	movs    	r1, #0x14
0x0073ce:	movs    	r2, #0x4e
0x0073d0:	adds    	r3, r4, #0
0x0073d2:	movs    	r0, #0xf1
0x0073d4:	lsls    	r0, r0, #9
0x0073d6:	bl      	#0x9124
0x0073da:	str     	r4, [r5, #0x50]
0x0073dc:	add     	sp, #0xc
0x0073de:	pop     	{r4, r5, pc}

; ===== candidate_0073e4 =====
0x0073e4:	push    	{r4, r5, r6, lr}
0x0073e6:	sub     	sp, #0x10
0x0073e8:	movs    	r1, #0
0x0073ea:	str     	r1, [sp]
0x0073ec:	str     	r1, [sp, #4]
0x0073ee:	ldr     	r5, [pc, #0x6c]
0x0073f0:	movs    	r2, #0
0x0073f2:	movs    	r6, #0xf1
0x0073f4:	lsls    	r6, r6, #9
0x0073f6:	str     	r2, [sp, #8]
0x0073f8:	movs    	r1, #0x11
0x0073fa:	movs    	r3, #4
0x0073fc:	add     	r5, sb
0x0073fe:	ldr     	r2, [r5, #8]
0x007400:	adds    	r0, r6, #0
0x007402:	bl      	#0x9124
0x007406:	movs    	r1, #0
0x007408:	str     	r1, [sp]
0x00740a:	str     	r1, [sp, #4]
0x00740c:	movs    	r2, #0
0x00740e:	movs    	r1, #0x34
0x007410:	adds    	r4, r0, #0
0x007412:	movs    	r3, #0
0x007414:	adds    	r0, r6, #0
0x007416:	str     	r2, [sp, #8]
0x007418:	bl      	#0x9124
0x00741c:	ldr     	r0, [pc, #0x3c]
0x00741e:	movs    	r1, #0
0x007420:	add     	r0, sb
0x007422:	adds    	r0, #0x80
0x007424:	str     	r1, [r0, #0x38]
0x007426:	ldr     	r1, [r5, #0x10]
0x007428:	cmp     	r1, r4
0x00742a:	blt     	#0x7432
0x00742c:	subs    	r1, r4, #1
0x00742e:	str     	r1, [r0, #0x34]
0x007430:	b       	#0x7434
0x007432:	str     	r1, [r0, #0x34]
0x007434:	ldr     	r1, [r0, #0x34]
0x007436:	cmp     	r1, r4
0x007438:	blt     	#0x743e
0x00743a:	subs    	r4, #1
0x00743c:	str     	r4, [r0, #0x34]
0x00743e:	movs    	r1, #0
0x007440:	movs    	r2, #0
0x007442:	str     	r2, [sp, #8]
0x007444:	str     	r1, [sp]
0x007446:	str     	r1, [sp, #4]
0x007448:	movs    	r3, #0xff
0x00744a:	adds    	r3, #0x39
0x00744c:	movs    	r1, #0x14
0x00744e:	movs    	r2, #0x17
0x007450:	adds    	r0, r6, #0
0x007452:	bl      	#0x9124
0x007456:	add     	sp, #0x10
0x007458:	pop     	{r4, r5, r6, pc}

; ===== candidate_007462 =====
0x007462:	push    	{lr}
0x007464:	add     	r0, sb
0x007466:	ldr     	r0, [r0, #0x28]
0x007468:	sub     	sp, #0xc
0x00746a:	cmp     	r0, #0
0x00746c:	beq     	#0x74a4
0x00746e:	ldr     	r0, [pc, #0x3c]
0x007470:	movs    	r3, #0
0x007472:	add     	r0, sb
0x007474:	str     	r3, [r0, #8]
0x007476:	movs    	r1, #0
0x007478:	str     	r1, [sp]
0x00747a:	str     	r1, [sp, #4]
0x00747c:	movs    	r2, #0
0x00747e:	movs    	r1, #0x34
0x007480:	movs    	r0, #0xf1
0x007482:	lsls    	r0, r0, #9
0x007484:	str     	r2, [sp, #8]
0x007486:	bl      	#0x9124
0x00748a:	movs    	r1, #0
0x00748c:	movs    	r2, #0
0x00748e:	str     	r2, [sp, #8]
0x007490:	str     	r1, [sp]
0x007492:	str     	r1, [sp, #4]
0x007494:	movs    	r3, #0xff
0x007496:	adds    	r3, #0x35
0x007498:	movs    	r1, #0x14
0x00749a:	movs    	r2, #0x17
0x00749c:	movs    	r0, #0xf1
0x00749e:	lsls    	r0, r0, #9
0x0074a0:	bl      	#0x9124
0x0074a4:	add     	sp, #0xc
0x0074a6:	pop     	{pc}

; ===== candidate_0074b0 =====
0x0074b0:	push    	{r4, r5, lr}
0x0074b2:	sub     	sp, #0xc
0x0074b4:	movs    	r1, #0
0x0074b6:	str     	r1, [sp]
0x0074b8:	str     	r1, [sp, #4]
0x0074ba:	movs    	r5, #0xf1
0x0074bc:	movs    	r4, #0
0x0074be:	movs    	r2, #0
0x0074c0:	adds    	r3, r4, #0
0x0074c2:	lsls    	r5, r5, #9
0x0074c4:	movs    	r1, #0xba
0x0074c6:	adds    	r0, r5, #0
0x0074c8:	str     	r2, [sp, #8]
0x0074ca:	bl      	#0x9124
0x0074ce:	movs    	r1, #0
0x0074d0:	str     	r1, [sp]
0x0074d2:	str     	r1, [sp, #4]
0x0074d4:	movs    	r2, #0
0x0074d6:	movs    	r1, #0x34
0x0074d8:	adds    	r3, r4, #0
0x0074da:	adds    	r0, r5, #0
0x0074dc:	str     	r2, [sp, #8]
0x0074de:	bl      	#0x9124
0x0074e2:	ldr     	r0, [pc, #0x38]
0x0074e4:	ldr     	r1, [pc, #0x38]
0x0074e6:	add     	r0, sb
0x0074e8:	str     	r4, [r0, #0x2c]
0x0074ea:	str     	r4, [r0, #0x30]
0x0074ec:	movs    	r0, #1
0x0074ee:	add     	r1, sb
0x0074f0:	strb    	r0, [r1]
0x0074f2:	ldr     	r0, [pc, #0x28]
0x0074f4:	add     	r0, sb
0x0074f6:	subs    	r0, #0x80
0x0074f8:	ldr     	r0, [r0, #0x18]
0x0074fa:	cmp     	r0, #0
0x0074fc:	beq     	#0x7500
0x0074fe:	strb    	r4, [r1]
0x007500:	movs    	r1, #0
0x007502:	movs    	r2, #0
0x007504:	str     	r2, [sp, #8]
0x007506:	str     	r1, [sp]
0x007508:	str     	r1, [sp, #4]
0x00750a:	movs    	r3, #0xff
0x00750c:	adds    	r3, #0x38
0x00750e:	movs    	r1, #0x14
0x007510:	movs    	r2, #0x17
0x007512:	adds    	r0, r5, #0
0x007514:	bl      	#0x9124
0x007518:	add     	sp, #0xc
0x00751a:	pop     	{r4, r5, pc}

; ===== candidate_007524 =====
0x007524:	push    	{r4, lr}
0x007526:	sub     	sp, #0x10
0x007528:	movs    	r1, #0
0x00752a:	str     	r1, [sp]
0x00752c:	str     	r1, [sp, #4]
0x00752e:	movs    	r4, #0
0x007530:	movs    	r2, #0
0x007532:	adds    	r3, r4, #0
0x007534:	movs    	r1, #0x34
0x007536:	movs    	r0, #0xf1
0x007538:	lsls    	r0, r0, #9
0x00753a:	str     	r2, [sp, #8]
0x00753c:	bl      	#0x9124
0x007540:	ldr     	r0, [pc, #0x24]
0x007542:	movs    	r1, #0
0x007544:	add     	r0, sb
0x007546:	str     	r4, [r0, #0x20]
0x007548:	str     	r4, [r0, #0x24]
0x00754a:	movs    	r2, #0
0x00754c:	str     	r2, [sp, #8]
0x00754e:	str     	r1, [sp]
0x007550:	str     	r1, [sp, #4]
0x007552:	movs    	r3, #0xff
0x007554:	adds    	r3, #0x37
0x007556:	movs    	r1, #0x14
0x007558:	movs    	r2, #0x17
0x00755a:	movs    	r0, #0xf1
0x00755c:	lsls    	r0, r0, #9
0x00755e:	bl      	#0x9124
0x007562:	add     	sp, #0x10
0x007564:	pop     	{r4, pc}

; ===== candidate_00756e =====
0x00756e:	push    	{lr}
0x007570:	sub     	sp, #0xc
0x007572:	movs    	r3, #0
0x007574:	add     	r0, sb
0x007576:	str     	r3, [r0, #0x38]
0x007578:	movs    	r1, #0
0x00757a:	str     	r1, [sp]
0x00757c:	str     	r1, [sp, #4]
0x00757e:	movs    	r2, #0
0x007580:	movs    	r1, #0x34
0x007582:	movs    	r0, #0xf1
0x007584:	lsls    	r0, r0, #9
0x007586:	str     	r2, [sp, #8]
0x007588:	bl      	#0x9124
0x00758c:	movs    	r1, #0
0x00758e:	movs    	r2, #0
0x007590:	str     	r2, [sp, #8]
0x007592:	str     	r1, [sp]
0x007594:	str     	r1, [sp, #4]
0x007596:	movs    	r1, #0x14
0x007598:	movs    	r2, #0x17
0x00759a:	movs    	r3, #0xea
0x00759c:	movs    	r0, #0xf1
0x00759e:	lsls    	r0, r0, #9
0x0075a0:	bl      	#0x9124
0x0075a4:	add     	sp, #0xc
0x0075a6:	pop     	{pc}

; ===== candidate_0075ac =====
0x0075ac:	push    	{r4, lr}
0x0075ae:	adds    	r1, r0, #0
0x0075b0:	ldr     	r0, [pc, #0x54]
0x0075b2:	sub     	sp, #0x10
0x0075b4:	add     	r0, sb
0x0075b6:	str     	r1, [r0, #0x1c]
0x0075b8:	movs    	r4, #0
0x0075ba:	str     	r4, [r0, #0x20]
0x0075bc:	movs    	r1, #0
0x0075be:	str     	r1, [sp]
0x0075c0:	str     	r1, [sp, #4]
0x0075c2:	movs    	r2, #0
0x0075c4:	movs    	r1, #0x34
0x0075c6:	movs    	r0, #0xf1
0x0075c8:	adds    	r3, r4, #0
0x0075ca:	lsls    	r0, r0, #9
0x0075cc:	str     	r2, [sp, #8]
0x0075ce:	bl      	#0x9124
0x0075d2:	movs    	r1, #0
0x0075d4:	str     	r1, [sp]
0x0075d6:	str     	r1, [sp, #4]
0x0075d8:	movs    	r2, #0
0x0075da:	movs    	r1, #0xba
0x0075dc:	adds    	r3, r4, #0
0x0075de:	movs    	r0, #0xf1
0x0075e0:	lsls    	r0, r0, #9
0x0075e2:	str     	r2, [sp, #8]
0x0075e4:	bl      	#0x9124
0x0075e8:	movs    	r1, #0
0x0075ea:	movs    	r2, #0
0x0075ec:	str     	r2, [sp, #8]
0x0075ee:	str     	r1, [sp]
0x0075f0:	str     	r1, [sp, #4]
0x0075f2:	movs    	r3, #0xff
0x0075f4:	adds    	r3, #0x31
0x0075f6:	movs    	r1, #0x14
0x0075f8:	movs    	r2, #0x17
0x0075fa:	movs    	r0, #0xf1
0x0075fc:	lsls    	r0, r0, #9
0x0075fe:	bl      	#0x9124
0x007602:	add     	sp, #0x10
0x007604:	pop     	{r4, pc}

; ===== candidate_00760c =====
0x00760c:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x00760e:	sub     	sp, #0xc
0x007610:	adds    	r7, r1, #0
0x007612:	movs    	r1, #0
0x007614:	str     	r1, [sp]
0x007616:	str     	r1, [sp, #4]
0x007618:	movs    	r5, #0xf1
0x00761a:	movs    	r4, #0
0x00761c:	movs    	r2, #0
0x00761e:	adds    	r3, r4, #0
0x007620:	lsls    	r5, r5, #9
0x007622:	movs    	r1, #0x34
0x007624:	adds    	r0, r5, #0
0x007626:	str     	r2, [sp, #8]
0x007628:	bl      	#0x9124
0x00762c:	ldr     	r6, [pc, #0x8c]
0x00762e:	movs    	r1, #0
0x007630:	add     	r6, sb
0x007632:	str     	r4, [r6, #0x7c]
0x007634:	ldr     	r0, [sp, #0xc]
0x007636:	movs    	r2, #0
0x007638:	str     	r0, [r6, #0x78]
0x00763a:	ldr     	r0, [pc, #0x80]
0x00763c:	adds    	r3, r7, #0
0x00763e:	add     	r0, sb
0x007640:	adds    	r0, #0x80
0x007642:	str     	r4, [r0]
0x007644:	str     	r1, [sp]
0x007646:	str     	r1, [sp, #4]
0x007648:	str     	r2, [sp, #8]
0x00764a:	movs    	r2, #0x17
0x00764c:	movs    	r1, #0x14
0x00764e:	adds    	r0, r5, #0
0x007650:	bl      	#0x9124
0x007654:	movs    	r1, #0
0x007656:	movs    	r2, #0
0x007658:	str     	r2, [sp, #8]
0x00765a:	str     	r1, [sp]
0x00765c:	str     	r1, [sp, #4]
0x00765e:	movs    	r1, #0xe1
0x007660:	movs    	r2, #0xb5
0x007662:	adds    	r3, r4, #0
0x007664:	adds    	r0, r5, #0
0x007666:	bl      	#0x9124
0x00766a:	cmp     	r0, #1
0x00766c:	bne     	#0x7686
0x00766e:	movs    	r2, #0
0x007670:	movs    	r1, #0
0x007672:	str     	r2, [sp, #8]
0x007674:	ldr     	r2, [pc, #0x48]
0x007676:	str     	r1, [sp]
0x007678:	str     	r1, [sp, #4]
0x00767a:	adds    	r3, r4, #0
0x00767c:	add     	r2, pc
0x00767e:	movs    	r1, #0x33
0x007680:	adds    	r0, r5, #0
0x007682:	bl      	#0x9124
0x007686:	movs    	r1, #0
0x007688:	movs    	r2, #0
0x00768a:	str     	r2, [sp, #8]
0x00768c:	str     	r1, [sp]
0x00768e:	str     	r1, [sp, #4]
0x007690:	movs    	r1, #0xe1
0x007692:	movs    	r2, #0x17
0x007694:	adds    	r3, r4, #0
0x007696:	adds    	r0, r5, #0
0x007698:	bl      	#0x9124
0x00769c:	cmp     	r0, #0xe9
0x00769e:	bne     	#0x76a4
0x0076a0:	movs    	r0, #1
0x0076a2:	strb    	r0, [r6]
0x0076a4:	movs    	r1, #0
0x0076a6:	str     	r1, [sp]
0x0076a8:	str     	r1, [sp, #4]
0x0076aa:	movs    	r2, #0
0x0076ac:	movs    	r1, #0xba
0x0076ae:	adds    	r3, r4, #0
0x0076b0:	adds    	r0, r5, #0
0x0076b2:	str     	r2, [sp, #8]
0x0076b4:	bl      	#0x9124
0x0076b8:	add     	sp, #0x14
0x0076ba:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0076c4 =====
0x0076c4:	push    	{r4, r5, r6, r7, lr}
0x0076c6:	subs    	r0, #2
0x0076c8:	cmp     	r0, #0x13
0x0076ca:	sub     	sp, #0xc
0x0076cc:	bhs     	#0x76d8
0x0076ce:	adr     	r3, #0xc
0x0076d0:	adds    	r3, r3, r0
0x0076d2:	ldrh    	r3, [r3, r0]
0x0076d4:	lsls    	r3, r3, #1
0x0076d6:	add     	pc, r3
0x0076d8:	add     	sp, #0xc
0x0076da:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007b94 =====
0x007b94:	push    	{r4, r5, r6, r7, lr}
0x007b96:	sub     	sp, #0xc
0x007b98:	movs    	r1, #0
0x007b9a:	str     	r1, [sp]
0x007b9c:	str     	r1, [sp, #4]
0x007b9e:	ldr     	r4, [pc, #0xe8]
0x007ba0:	movs    	r2, #0
0x007ba2:	movs    	r6, #0xf1
0x007ba4:	lsls    	r6, r6, #9
0x007ba6:	str     	r2, [sp, #8]
0x007ba8:	movs    	r1, #0x11
0x007baa:	adds    	r7, r0, #0
0x007bac:	movs    	r3, #4
0x007bae:	add     	r4, sb
0x007bb0:	ldr     	r2, [r4, #0x44]
0x007bb2:	adds    	r0, r6, #0
0x007bb4:	bl      	#0x9124
0x007bb8:	movs    	r1, #0
0x007bba:	movs    	r2, #0
0x007bbc:	str     	r2, [sp, #8]
0x007bbe:	str     	r1, [sp]
0x007bc0:	str     	r1, [sp, #4]
0x007bc2:	movs    	r5, #0
0x007bc4:	adds    	r3, r5, #0
0x007bc6:	movs    	r1, #0x5f
0x007bc8:	adds    	r2, r7, #0
0x007bca:	adds    	r4, r0, #0
0x007bcc:	adds    	r0, r6, #0
0x007bce:	bl      	#0x9124
0x007bd2:	cmp     	r0, #1
0x007bd4:	beq     	#0x7c08
0x007bd6:	ldr     	r0, [pc, #0xb0]
0x007bd8:	add     	r0, sb
0x007bda:	adds    	r0, #0x40
0x007bdc:	cmp     	r7, #0xd
0x007bde:	beq     	#0x7c70
0x007be0:	bgt     	#0x7c0c
0x007be2:	cmp     	r7, #2
0x007be4:	beq     	#0x7bf2
0x007be6:	cmp     	r7, #5
0x007be8:	beq     	#0x7c18
0x007bea:	cmp     	r7, #8
0x007bec:	beq     	#0x7c70
0x007bee:	cmp     	r7, #0xc
0x007bf0:	bne     	#0x7c08
0x007bf2:	movs    	r2, #0
0x007bf4:	movs    	r1, #0
0x007bf6:	str     	r1, [sp, #4]
0x007bf8:	str     	r2, [sp, #8]
0x007bfa:	adds    	r2, r4, #0
0x007bfc:	movs    	r1, #0x29
0x007bfe:	str     	r0, [sp]
0x007c00:	adds    	r3, r5, #0
0x007c02:	adds    	r0, r6, #0
0x007c04:	bl      	#0x9124
0x007c08:	add     	sp, #0xc
0x007c0a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007c8c =====
0x007c8c:	push    	{r4, r5, r6, r7, lr}
0x007c8e:	sub     	sp, #0xc
0x007c90:	movs    	r1, #0
0x007c92:	str     	r1, [sp]
0x007c94:	str     	r1, [sp, #4]
0x007c96:	ldr     	r5, [pc, #0x88]
0x007c98:	movs    	r2, #0
0x007c9a:	movs    	r4, #0xf1
0x007c9c:	lsls    	r4, r4, #9
0x007c9e:	str     	r2, [sp, #8]
0x007ca0:	movs    	r1, #0x11
0x007ca2:	adds    	r6, r0, #0
0x007ca4:	movs    	r3, #4
0x007ca6:	add     	r5, sb
0x007ca8:	ldr     	r2, [r5, #0x60]
0x007caa:	adds    	r0, r4, #0
0x007cac:	bl      	#0x9124
0x007cb0:	adds    	r7, r0, #0
0x007cb2:	ldr     	r0, [pc, #0x6c]
0x007cb4:	movs    	r3, #0
0x007cb6:	add     	r0, sb
0x007cb8:	adds    	r0, #0x5c
0x007cba:	cmp     	r6, #0xd
0x007cbc:	beq     	#0x7d08
0x007cbe:	bgt     	#0x7ce8
0x007cc0:	cmp     	r6, #2
0x007cc2:	beq     	#0x7cd0
0x007cc4:	cmp     	r6, #5
0x007cc6:	beq     	#0x7cf4
0x007cc8:	cmp     	r6, #8
0x007cca:	beq     	#0x7d08
0x007ccc:	cmp     	r6, #0xc
0x007cce:	bne     	#0x7ce4
0x007cd0:	movs    	r2, #0
0x007cd2:	movs    	r1, #0
0x007cd4:	str     	r1, [sp, #4]
0x007cd6:	str     	r2, [sp, #8]
0x007cd8:	adds    	r2, r7, #0
0x007cda:	movs    	r1, #0x29
0x007cdc:	str     	r0, [sp]
0x007cde:	adds    	r0, r4, #0
0x007ce0:	bl      	#0x9124
0x007ce4:	add     	sp, #0xc
0x007ce6:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007d24 =====
0x007d24:	push    	{r4, r5, r6, r7, lr}
0x007d26:	ldr     	r1, [pc, #0xb8]
0x007d28:	ldr     	r5, [pc, #0xb4]
0x007d2a:	add     	r1, sb
0x007d2c:	adds    	r1, #0x2c
0x007d2e:	movs    	r7, #0xf1
0x007d30:	lsls    	r7, r7, #9
0x007d32:	movs    	r4, #0
0x007d34:	cmp     	r0, #0xd
0x007d36:	ldr     	r6, [r1, #0x48]
0x007d38:	sub     	sp, #0xc
0x007d3a:	add     	r5, sb
0x007d3c:	beq     	#0x7daa
0x007d3e:	bgt     	#0x7d86
0x007d40:	cmp     	r0, #2
0x007d42:	beq     	#0x7d50
0x007d44:	cmp     	r0, #5
0x007d46:	beq     	#0x7d92
0x007d48:	cmp     	r0, #8
0x007d4a:	beq     	#0x7daa
0x007d4c:	cmp     	r0, #0xc
0x007d4e:	bne     	#0x7d82
0x007d50:	cmp     	r6, #0
0x007d52:	beq     	#0x7d82
0x007d54:	movs    	r1, #0
0x007d56:	movs    	r2, #0
0x007d58:	str     	r2, [sp, #8]
0x007d5a:	str     	r1, [sp]
0x007d5c:	str     	r1, [sp, #4]
0x007d5e:	movs    	r1, #0x26
0x007d60:	adds    	r2, r6, #0
0x007d62:	adds    	r3, r4, #0
0x007d64:	adds    	r0, r7, #0
0x007d66:	bl      	#0x9124
0x007d6a:	movs    	r2, #0
0x007d6c:	str     	r2, [sp, #8]
0x007d6e:	movs    	r1, #0
0x007d70:	adds    	r3, r4, #0
0x007d72:	adds    	r2, r0, #0
0x007d74:	str     	r1, [sp, #4]
0x007d76:	movs    	r1, #0x29
0x007d78:	movs    	r0, #0xf1
0x007d7a:	lsls    	r0, r0, #9
0x007d7c:	str     	r5, [sp]
0x007d7e:	bl      	#0x9124
0x007d82:	add     	sp, #0xc
0x007d84:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007de4 =====
0x007de4:	push    	{r4, r5, r6, lr}
0x007de6:	sub     	sp, #0x10
0x007de8:	movs    	r1, #0
0x007dea:	movs    	r2, #0
0x007dec:	str     	r2, [sp, #8]
0x007dee:	str     	r1, [sp]
0x007df0:	str     	r1, [sp, #4]
0x007df2:	adds    	r4, r0, #0
0x007df4:	movs    	r0, #0xf1
0x007df6:	movs    	r1, #0xe1
0x007df8:	movs    	r2, #0x3e
0x007dfa:	movs    	r3, #0
0x007dfc:	lsls    	r0, r0, #9
0x007dfe:	bl      	#0x9124
0x007e02:	movs    	r2, #0
0x007e04:	movs    	r1, #0
0x007e06:	str     	r2, [sp, #8]
0x007e08:	adds    	r2, r0, #0
0x007e0a:	str     	r1, [sp]
0x007e0c:	str     	r1, [sp, #4]
0x007e0e:	movs    	r1, #0x11
0x007e10:	movs    	r0, #0xf1
0x007e12:	movs    	r3, #4
0x007e14:	lsls    	r0, r0, #9
0x007e16:	bl      	#0x9124
0x007e1a:	subs    	r4, #2
0x007e1c:	cmp     	r4, #0x13
0x007e1e:	bhs     	#0x7e40
0x007e20:	adr     	r3, #4
0x007e22:	ldrb    	r3, [r3, r4]
0x007e24:	lsls    	r3, r3, #1
0x007e26:	add     	pc, r3
0x007e28:	lsrs    	r5, r5, #0xd
0x007e2a:	lsrs    	r1, r5, #0x14
0x007e2c:	lsrs    	r3, r1, #0xd
0x007e2e:	lsrs    	r0, r1, #0xe
0x007e30:	lsrs    	r3, r1, #0xc
0x007e32:	ldrh    	r5, [r5, #2]
0x007e34:	ldr     	r3, [pc, #0xa4]
0x007e36:	lsrs    	r3, r1, #4
0x007e38:	lsrs    	r1, r1, #0xc
0x007e3a:	movs    	r5, r1
0x007e3c:	bl      	#0x6624
0x007e40:	add     	sp, #0x10
0x007e42:	pop     	{r4, r5, r6, pc}

; ===== candidate_007f78 =====
0x007f78:	push    	{r4, r5, lr}
0x007f7a:	sub     	sp, #0xc
0x007f7c:	movs    	r1, #0
0x007f7e:	str     	r1, [sp]
0x007f80:	str     	r1, [sp, #4]
0x007f82:	ldr     	r4, [pc, #0x10c]
0x007f84:	movs    	r2, #0
0x007f86:	adds    	r5, r0, #0
0x007f88:	movs    	r0, #0xf1
0x007f8a:	str     	r2, [sp, #8]
0x007f8c:	movs    	r1, #0x11
0x007f8e:	movs    	r3, #4
0x007f90:	add     	r4, sb
0x007f92:	ldr     	r2, [r4, #8]
0x007f94:	lsls    	r0, r0, #9
0x007f96:	bl      	#0x9124
0x007f9a:	ldr     	r2, [pc, #0xf4]
0x007f9c:	ldr     	r3, [r4, #8]
0x007f9e:	add     	r2, sb
0x007fa0:	adds    	r2, #0x80
0x007fa2:	ldr     	r1, [r2, #0x34]
0x007fa4:	ldr     	r2, [r2, #0x38]
0x007fa6:	lsls    	r1, r1, #2
0x007fa8:	ldr     	r1, [r3, r1]
0x007faa:	lsls    	r2, r2, #2
0x007fac:	ldr     	r1, [r1, #8]
0x007fae:	subs    	r5, #2
0x007fb0:	cmp     	r5, #0x13
0x007fb2:	ldr     	r4, [r1, r2]
0x007fb4:	bhs     	#0x7fd8
0x007fb6:	adr     	r3, #8
0x007fb8:	ldrb    	r3, [r3, r5]
0x007fba:	lsls    	r3, r3, #1
0x007fbc:	add     	pc, r3
0x007fbe:	movs    	r0, r0
0x007fc0:	lsrs    	r3, r2, #0x11
0x007fc2:	movs    	r7, #0xe
0x007fc4:	lsrs    	r2, r3, #0x10
0x007fc6:	lsrs    	r5, r3, #0x11
0x007fc8:	lsrs    	r4, r1, #0x10
0x007fca:	ldrb    	r3, [r2, r5]
0x007fcc:	subs    	r6, r1, r0
0x007fce:	lsrs    	r4, r1, #8
0x007fd0:	lsrs    	r2, r1, #0x10
0x007fd2:	movs    	r7, r4
0x007fd4:	bl      	#0xa3e8
0x007fd8:	add     	sp, #0xc
0x007fda:	pop     	{r4, r5, pc}

; ===== candidate_008094 =====
0x008094:	push    	{r4, r5, r6, lr}
0x008096:	sub     	sp, #0x10
0x008098:	adds    	r5, r0, #0
0x00809a:	movs    	r1, #0
0x00809c:	ldr     	r0, [pc, #0x98]
0x00809e:	str     	r1, [sp]
0x0080a0:	str     	r1, [sp, #4]
0x0080a2:	movs    	r2, #0
0x0080a4:	str     	r2, [sp, #8]
0x0080a6:	movs    	r4, #0xf1
0x0080a8:	add     	r0, sb
0x0080aa:	ldr     	r2, [r0, #0x28]
0x0080ac:	lsls    	r4, r4, #9
0x0080ae:	movs    	r1, #0x11
0x0080b0:	movs    	r3, #4
0x0080b2:	adds    	r0, r4, #0
0x0080b4:	bl      	#0x9124
0x0080b8:	adds    	r6, r0, #0
0x0080ba:	ldr     	r0, [pc, #0x84]
0x0080bc:	ldr     	r1, [pc, #0x7c]
0x0080be:	movs    	r3, #0
0x0080c0:	cmp     	r5, #0xd
0x0080c2:	add     	r0, sb
0x0080c4:	add     	r1, sb
0x0080c6:	beq     	#0x8106
0x0080c8:	bgt     	#0x80f2
0x0080ca:	cmp     	r5, #2
0x0080cc:	beq     	#0x80da
0x0080ce:	cmp     	r5, #5
0x0080d0:	beq     	#0x80fe
0x0080d2:	cmp     	r5, #8
0x0080d4:	beq     	#0x8106
0x0080d6:	cmp     	r5, #0xc
0x0080d8:	bne     	#0x80ee
0x0080da:	movs    	r2, #0
0x0080dc:	movs    	r1, #0
0x0080de:	str     	r1, [sp, #4]
0x0080e0:	str     	r2, [sp, #8]
0x0080e2:	adds    	r2, r6, #0
0x0080e4:	movs    	r1, #0x29
0x0080e6:	str     	r0, [sp]
0x0080e8:	adds    	r0, r4, #0
0x0080ea:	bl      	#0x9124
0x0080ee:	add     	sp, #0x10
0x0080f0:	pop     	{r4, r5, r6, pc}

; ===== candidate_008144 =====
0x008144:	push    	{r0, r4, r5, r6, r7, lr}
0x008146:	ldr     	r7, [pc, #0x1b8]
0x008148:	movs    	r6, #0xf1
0x00814a:	add     	r7, sb
0x00814c:	ldr     	r3, [r7, #0x18]
0x00814e:	lsls    	r6, r6, #9
0x008150:	movs    	r5, #0
0x008152:	movs    	r4, #0
0x008154:	cmp     	r3, #0
0x008156:	sub     	sp, #0x10
0x008158:	beq     	#0x8172
0x00815a:	movs    	r1, #0
0x00815c:	str     	r1, [sp]
0x00815e:	str     	r1, [sp, #4]
0x008160:	movs    	r2, #0
0x008162:	str     	r2, [sp, #8]
0x008164:	ldr     	r2, [r3, #8]
0x008166:	movs    	r3, #4
0x008168:	movs    	r1, #0x11
0x00816a:	adds    	r0, r6, #0
0x00816c:	bl      	#0x9124
0x008170:	adds    	r4, r0, #0
0x008172:	ldr     	r7, [pc, #0x18c]
0x008174:	add     	r7, sb
0x008176:	ldr     	r3, [r7, #0xc]
0x008178:	cmp     	r3, #0
0x00817a:	beq     	#0x8194
0x00817c:	movs    	r1, #0
0x00817e:	str     	r1, [sp]
0x008180:	str     	r1, [sp, #4]
0x008182:	movs    	r2, #0
0x008184:	str     	r2, [sp, #8]
0x008186:	ldr     	r2, [r3, #8]
0x008188:	movs    	r3, #4
0x00818a:	movs    	r1, #0x11
0x00818c:	adds    	r0, r6, #0
0x00818e:	bl      	#0x9124
0x008192:	adds    	r5, r0, #0
0x008194:	ldr     	r0, [pc, #0x168]
0x008196:	ldr     	r3, [pc, #0x16c]
0x008198:	ldr     	r2, [sp, #0x10]
0x00819a:	add     	r0, sb
0x00819c:	adds    	r0, #0x80
0x00819e:	movs    	r1, #1
0x0081a0:	movs    	r7, #0
0x0081a2:	cmp     	r2, #0xd
0x0081a4:	add     	r3, sb
0x0081a6:	beq     	#0x828c
0x0081a8:	bgt     	#0x81d6
0x0081aa:	cmp     	r2, #2
0x0081ac:	beq     	#0x81ba
0x0081ae:	cmp     	r2, #5
0x0081b0:	beq     	#0x81e2
0x0081b2:	cmp     	r2, #6
0x0081b4:	beq     	#0x828c
0x0081b6:	cmp     	r2, #0xc
0x0081b8:	bne     	#0x81d2
0x0081ba:	adds    	r2, r3, #0
0x0081bc:	movs    	r3, #0
0x0081be:	ldrsb   	r6, [r2, r3]
0x0081c0:	cmp     	r6, #0
0x0081c2:	beq     	#0x828e
0x0081c4:	cmp     	r6, #1
0x0081c6:	beq     	#0x82a2
0x0081c8:	cmp     	r6, #2
0x0081ca:	bne     	#0x81d2
0x0081cc:	strb    	r1, [r2]
0x0081ce:	subs    	r5, #1
0x0081d0:	str     	r5, [r0, #0x2c]
0x0081d2:	add     	sp, #0x14
0x0081d4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_008308 =====
0x008308:	push    	{r4, r5, r6, r7, lr}
0x00830a:	ldr     	r7, [pc, #0x210]
0x00830c:	adds    	r6, r0, #0
0x00830e:	add     	r7, sb
0x008310:	ldr     	r0, [r7, #0x2c]
0x008312:	ldr     	r1, [r7, #0x34]
0x008314:	lsls    	r0, r0, #2
0x008316:	ldr     	r4, [r1, r0]
0x008318:	ldr     	r0, [r7, #0x20]
0x00831a:	movs    	r5, #0xf1
0x00831c:	lsls    	r5, r5, #9
0x00831e:	movs    	r3, #0
0x008320:	cmp     	r0, #0
0x008322:	sub     	sp, #0xc
0x008324:	mov     	ip, r0
0x008326:	beq     	#0x8340
0x008328:	movs    	r1, #0
0x00832a:	movs    	r2, #0
0x00832c:	str     	r1, [sp]
0x00832e:	str     	r1, [sp, #4]
0x008330:	movs    	r1, #0x11
0x008332:	str     	r2, [sp, #8]
0x008334:	movs    	r3, #4
0x008336:	adds    	r0, r5, #0
0x008338:	mov     	r2, ip
0x00833a:	bl      	#0x9124
0x00833e:	adds    	r3, r0, #0
0x008340:	ldr     	r0, [pc, #0x1d8]
0x008342:	adds    	r1, r6, #0
0x008344:	add     	r0, sb
0x008346:	adds    	r0, #0x24
0x008348:	movs    	r6, #0
0x00834a:	cmp     	r1, #0xd
0x00834c:	beq     	#0x842e
0x00834e:	bgt     	#0x837a
0x008350:	cmp     	r1, #2
0x008352:	beq     	#0x8360
0x008354:	cmp     	r1, #5
0x008356:	beq     	#0x8386
0x008358:	cmp     	r1, #8
0x00835a:	beq     	#0x842e
0x00835c:	cmp     	r1, #0xc
0x00835e:	bne     	#0x8376
0x008360:	movs    	r2, #0
0x008362:	movs    	r1, #0
0x008364:	str     	r1, [sp, #4]
0x008366:	str     	r2, [sp, #8]
0x008368:	str     	r0, [sp]
0x00836a:	adds    	r0, r5, #0
0x00836c:	adds    	r2, r3, #0
0x00836e:	movs    	r1, #0x29
0x008370:	adds    	r3, r6, #0
0x008372:	bl      	#0x9124
0x008376:	add     	sp, #0xc
0x008378:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_008528 =====
0x008528:	push    	{r4, r5, r6, r7, lr}
0x00852a:	sub     	sp, #0xc
0x00852c:	adds    	r4, r0, #0
0x00852e:	movs    	r1, #0
0x008530:	ldr     	r0, [pc, #0x14c]
0x008532:	str     	r1, [sp]
0x008534:	str     	r1, [sp, #4]
0x008536:	movs    	r2, #0
0x008538:	str     	r2, [sp, #8]
0x00853a:	movs    	r5, #0xf1
0x00853c:	movs    	r7, #4
0x00853e:	add     	r0, sb
0x008540:	ldr     	r2, [r0, #0x30]
0x008542:	adds    	r3, r7, #0
0x008544:	lsls    	r5, r5, #9
0x008546:	movs    	r1, #0x11
0x008548:	adds    	r0, r5, #0
0x00854a:	bl      	#0x9124
0x00854e:	adds    	r6, r0, #0
0x008550:	ldr     	r0, [pc, #0x12c]
0x008552:	adds    	r1, r4, #0
0x008554:	add     	r0, sb
0x008556:	adds    	r0, #0x38
0x008558:	movs    	r4, #0
0x00855a:	cmp     	r1, #0xd
0x00855c:	beq     	#0x8634
0x00855e:	bgt     	#0x858a
0x008560:	cmp     	r1, #2
0x008562:	beq     	#0x8570
0x008564:	cmp     	r1, #5
0x008566:	beq     	#0x8596
0x008568:	cmp     	r1, #8
0x00856a:	beq     	#0x8634
0x00856c:	cmp     	r1, #0xc
0x00856e:	bne     	#0x8586
0x008570:	movs    	r2, #0
0x008572:	movs    	r1, #0
0x008574:	str     	r1, [sp, #4]
0x008576:	str     	r2, [sp, #8]
0x008578:	adds    	r2, r6, #0
0x00857a:	movs    	r1, #0x29
0x00857c:	str     	r0, [sp]
0x00857e:	adds    	r3, r4, #0
0x008580:	adds    	r0, r5, #0
0x008582:	bl      	#0x9124
0x008586:	add     	sp, #0xc
0x008588:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00868c =====
0x00868c:	push    	{r4, r5, r6, r7, lr}
0x00868e:	sub     	sp, #0xc
0x008690:	ldr     	r6, [pc, #0xe8]
0x008692:	movs    	r1, #0
0x008694:	str     	r1, [sp]
0x008696:	str     	r1, [sp, #4]
0x008698:	movs    	r2, #0
0x00869a:	add     	r6, sb
0x00869c:	str     	r2, [sp, #8]
0x00869e:	adds    	r5, r0, #0
0x0086a0:	ldr     	r0, [r6, #0x38]
0x0086a2:	adds    	r1, r6, #0
0x0086a4:	ldr     	r1, [r1, #0x30]
0x0086a6:	lsls    	r0, r0, #2
0x0086a8:	ldr     	r0, [r1, r0]
0x0086aa:	movs    	r4, #0xf1
0x0086ac:	lsls    	r4, r4, #9
0x0086ae:	movs    	r1, #0x11
0x0086b0:	movs    	r3, #4
0x0086b2:	ldr     	r2, [r0, #4]
0x0086b4:	adds    	r0, r4, #0
0x0086b6:	bl      	#0x9124
0x0086ba:	adds    	r7, r0, #0
0x0086bc:	ldr     	r0, [pc, #0xbc]
0x0086be:	adds    	r1, r5, #0
0x0086c0:	add     	r0, sb
0x0086c2:	adds    	r0, #0x3c
0x0086c4:	movs    	r5, #0
0x0086c6:	cmp     	r1, #0xd
0x0086c8:	beq     	#0x8762
0x0086ca:	bgt     	#0x86f6
0x0086cc:	cmp     	r1, #2
0x0086ce:	beq     	#0x86dc
0x0086d0:	cmp     	r1, #5
0x0086d2:	beq     	#0x8702
0x0086d4:	cmp     	r1, #8
0x0086d6:	beq     	#0x8762
0x0086d8:	cmp     	r1, #0xc
0x0086da:	bne     	#0x86f2
0x0086dc:	movs    	r2, #0
0x0086de:	movs    	r1, #0
0x0086e0:	str     	r1, [sp, #4]
0x0086e2:	str     	r2, [sp, #8]
0x0086e4:	adds    	r2, r7, #0
0x0086e6:	movs    	r1, #0x29
0x0086e8:	str     	r0, [sp]
0x0086ea:	adds    	r3, r5, #0
0x0086ec:	adds    	r0, r4, #0
0x0086ee:	bl      	#0x9124
0x0086f2:	add     	sp, #0xc
0x0086f4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_008780 =====
0x008780:	push    	{r4, lr}
0x008782:	sub     	sp, #0x10
0x008784:	adds    	r4, r0, #0
0x008786:	movs    	r1, #0
0x008788:	ldr     	r0, [pc, #0x144]
0x00878a:	str     	r1, [sp]
0x00878c:	str     	r1, [sp, #4]
0x00878e:	movs    	r2, #0
0x008790:	str     	r2, [sp, #8]
0x008792:	add     	r0, sb
0x008794:	ldr     	r2, [r0, #0x1c]
0x008796:	movs    	r0, #0xf1
0x008798:	movs    	r1, #0x11
0x00879a:	movs    	r3, #4
0x00879c:	lsls    	r0, r0, #9
0x00879e:	bl      	#0x9124
0x0087a2:	subs    	r4, #2
0x0087a4:	cmp     	r4, #0x13
0x0087a6:	bhs     	#0x880e
0x0087a8:	adr     	r3, #4
0x0087aa:	ldrb    	r3, [r3, r4]
0x0087ac:	lsls    	r3, r3, #1
0x0087ae:	add     	pc, r3
0x0087b0:	cmp     	r6, #0x4a
0x0087b2:	lsrs    	r5, r3, #5
0x0087b4:	cmp     	r6, #0x75
0x0087b6:	cmp     	r6, #0x53
0x0087b8:	cmp     	r6, #0x2e
0x0087ba:	strh    	r2, [r1, r5]
0x0087bc:	strb    	r5, [r3, #0x15]
0x0087be:	cmp     	r6, #0x2e
0x0087c0:	cmp     	r6, #0x30
0x0087c2:	movs    	r1, r1
0x0087c4:	cmp     	r0, #0
0x0087c6:	ble     	#0x880e
0x0087c8:	movs    	r1, #0
0x0087ca:	str     	r1, [sp]
0x0087cc:	str     	r1, [sp, #4]
0x0087ce:	movs    	r2, #0
0x0087d0:	movs    	r4, #0
0x0087d2:	adds    	r3, r4, #0
0x0087d4:	movs    	r1, #0x34
0x0087d6:	movs    	r0, #0xf1
0x0087d8:	lsls    	r0, r0, #9
0x0087da:	str     	r2, [sp, #8]
0x0087dc:	bl      	#0x9124
0x0087e0:	movs    	r1, #0
0x0087e2:	str     	r1, [sp]
0x0087e4:	str     	r1, [sp, #4]
0x0087e6:	movs    	r1, #0xff
0x0087e8:	movs    	r2, #0
0x0087ea:	adds    	r3, r4, #0
0x0087ec:	adds    	r1, #0x3f
0x0087ee:	movs    	r0, #0xf1
0x0087f0:	lsls    	r0, r0, #9
0x0087f2:	str     	r2, [sp, #8]
0x0087f4:	bl      	#0x9124
0x0087f8:	ldr     	r2, [pc, #0xd4]
0x0087fa:	adds    	r1, r0, #0
0x0087fc:	add     	r2, sb
0x0087fe:	ldr     	r0, [r2, #0x20]
0x008800:	ldr     	r2, [r2, #0x1c]
0x008802:	lsls    	r0, r0, #2
0x008804:	ldr     	r0, [r2, r0]
0x008806:	ldr     	r2, [r0]
0x008808:	mvns    	r0, r4
0x00880a:	bl      	#0xa6b8
0x00880e:	add     	sp, #0x10
0x008810:	pop     	{r4, pc}

; ===== candidate_0088d4 =====
0x0088d4:	push    	{r4, r5, r6, r7, lr}
0x0088d6:	sub     	sp, #0x14
0x0088d8:	movs    	r1, #0
0x0088da:	str     	r1, [sp]
0x0088dc:	str     	r1, [sp, #4]
0x0088de:	ldr     	r4, [pc, #0x2f0]
0x0088e0:	movs    	r2, #0
0x0088e2:	adds    	r5, r0, #0
0x0088e4:	movs    	r0, #0xf1
0x0088e6:	str     	r2, [sp, #8]
0x0088e8:	movs    	r1, #0x11
0x0088ea:	movs    	r3, #4
0x0088ec:	add     	r4, sb
0x0088ee:	ldr     	r2, [r4, #0x78]
0x0088f0:	lsls    	r0, r0, #9
0x0088f2:	bl      	#0x9124
0x0088f6:	movs    	r1, #0
0x0088f8:	movs    	r6, #0
0x0088fa:	cmp     	r0, #0
0x0088fc:	ble     	#0x8910
0x0088fe:	ldr     	r3, [r4, #0x78]
0x008900:	lsls    	r2, r1, #2
0x008902:	ldr     	r2, [r3, r2]
0x008904:	cmp     	r2, #0
0x008906:	beq     	#0x890a
0x008908:	adds    	r6, #1
0x00890a:	adds    	r1, #1
0x00890c:	cmp     	r1, r0
0x00890e:	blt     	#0x8900
0x008910:	subs    	r5, #2
0x008912:	cmp     	r5, #0x13
0x008914:	bhs     	#0x8990
0x008916:	adr     	r3, #8
0x008918:	ldrb    	r3, [r3, r5]
0x00891a:	lsls    	r3, r3, #1
0x00891c:	add     	pc, r3
0x00891e:	movs    	r0, r0
0x008920:	subs    	r0, #0x6e
0x008922:	str     	r1, [sp, #0x28]
0x008924:	subs    	r0, #0x3a
0x008926:	subs    	r0, #0x7e
0x008928:	subs    	r0, #0x38
0x00892a:	ldrb    	r6, [r5, #0x19]
0x00892c:	subs    	r2, #0xa
0x00892e:	str     	r1, [sp, #0xe0]
0x008930:	subs    	r0, #0x8e
0x008932:	lsls    	r1, r2, #2
0x008934:	movs    	r1, #0
0x008936:	movs    	r2, #0
0x008938:	str     	r2, [sp, #8]
0x00893a:	str     	r1, [sp]
0x00893c:	str     	r1, [sp, #4]
0x00893e:	movs    	r5, #0
0x008940:	movs    	r6, #0xf1
0x008942:	lsls    	r6, r6, #9
0x008944:	adds    	r3, r5, #0
0x008946:	movs    	r1, #0xe1
0x008948:	movs    	r2, #0x17
0x00894a:	adds    	r0, r6, #0
0x00894c:	bl      	#0x9124
0x008950:	cmp     	r0, #0xd0
0x008952:	bne     	#0x8990
0x008954:	ldr     	r4, [pc, #0x27c]
0x008956:	add     	r4, sb
0x008958:	ldr     	r0, [r4, #0xc]
0x00895a:	cmp     	r0, #0
0x00895c:	ble     	#0x8990
0x00895e:	subs    	r0, #1
0x008960:	str     	r0, [r4, #0xc]
0x008962:	movs    	r1, #0
0x008964:	str     	r1, [sp]
0x008966:	str     	r1, [sp, #4]
0x008968:	movs    	r1, #0xff
0x00896a:	movs    	r2, #0
0x00896c:	adds    	r1, #0x20
0x00896e:	adds    	r3, r5, #0
0x008970:	adds    	r0, r6, #0
0x008972:	str     	r2, [sp, #8]
0x008974:	bl      	#0x9124
0x008978:	movs    	r1, #0
0x00897a:	str     	r1, [sp, #4]
0x00897c:	movs    	r2, #0
0x00897e:	str     	r2, [sp, #8]
0x008980:	movs    	r1, #0xff
0x008982:	str     	r0, [sp]
0x008984:	adds    	r1, #0x3d
0x008986:	movs    	r2, #0x19
0x008988:	adds    	r0, r6, #0
0x00898a:	ldr     	r3, [r4, #0xc]
0x00898c:	bl      	#0x9124
0x008990:	add     	sp, #0x14
0x008992:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_008bdc =====
0x008bdc:	push    	{r4, r5, r6, r7, lr}
0x008bde:	sub     	sp, #0xc
0x008be0:	subs    	r0, #2
0x008be2:	cmp     	r0, #0x13
0x008be4:	bhs     	#0x8bf0
0x008be6:	adr     	r3, #0xc
0x008be8:	adds    	r3, r3, r0
0x008bea:	ldrh    	r3, [r3, r0]
0x008bec:	lsls    	r3, r3, #1
0x008bee:	add     	pc, r3
0x008bf0:	add     	sp, #0xc
0x008bf2:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00904c =====
0x00904c:	push    	{r3, r4, r5, lr}
0x00904e:	ldr     	r4, [pc, #0x74]
0x009050:	add     	r4, pc
0x009052:	ldr     	r0, [r4, #0x38]
0x009054:	movs    	r1, #0x14
0x009056:	ldr     	r2, [r0, #0x64]
0x009058:	ldr     	r0, [pc, #0x6c]
0x00905a:	add     	r0, pc
0x00905c:	blx     	r2
0x00905e:	movs    	r5, #0
0x009060:	mvns    	r5, r5
0x009062:	cmp     	r0, r5
0x009064:	bne     	#0x906a
0x009066:	adds    	r0, r5, #0
0x009068:	pop     	{r3, r4, r5, pc}

; ===== candidate_0090d4 =====
0x0090d4:	push    	{r4, lr}
0x0090d6:	sub     	sp, #0x10
0x0090d8:	lsls    	r0, r0, #0x18
0x0090da:	lsrs    	r0, r0, #0x18
0x0090dc:	str     	r0, [sp]
0x0090de:	ldr     	r0, [pc, #0x38]
0x0090e0:	lsls    	r2, r2, #0x18
0x0090e2:	lsls    	r1, r1, #0x18
0x0090e4:	lsrs    	r1, r1, #0x18
0x0090e6:	lsrs    	r2, r2, #0x18
0x0090e8:	str     	r2, [sp, #8]
0x0090ea:	str     	r1, [sp, #4]
0x0090ec:	add     	r0, pc
0x0090ee:	ldr     	r0, [r0, #0x38]
0x0090f0:	adds    	r1, r0, #0
0x0090f2:	adds    	r1, #0xff
0x0090f4:	adds    	r1, #0x41
0x0090f6:	ldr     	r2, [r1, #0x34]
0x0090f8:	ldr     	r1, [r1, #0x30]
0x0090fa:	ldr     	r2, [r2]
0x0090fc:	ldr     	r1, [r1]
0x0090fe:	lsls    	r3, r2, #0x10
0x009100:	lsls    	r2, r1, #0x10
0x009102:	asrs    	r2, r2, #0x10
0x009104:	asrs    	r3, r3, #0x10
0x009106:	adds    	r0, #0xff
0x009108:	adds    	r0, #0xc1
0x00910a:	ldr     	r4, [r0, #0x28]
0x00910c:	movs    	r1, #0
0x00910e:	movs    	r0, #0
0x009110:	blx     	r4
0x009112:	add     	sp, #0x10
0x009114:	pop     	{r4, pc}

; ===== candidate_009124 =====
0x009124:	push    	{r4, r5, r6, r7, lr}
0x009126:	adds    	r5, r1, #0
0x009128:	adds    	r4, r0, #0
0x00912a:	adds    	r6, r2, #0
0x00912c:	ldr     	r2, [pc, #0x28]
0x00912e:	sub     	sp, #0x14
0x009130:	mov     	ip, r3
0x009132:	add     	r2, pc
0x009134:	ldr     	r0, [sp, #0x2c]
0x009136:	ldr     	r1, [sp, #0x30]
0x009138:	ldr     	r7, [sp, #0x28]
0x00913a:	ldr     	r3, [r2, #0x3c]
0x00913c:	movs    	r2, #2
0x00913e:	str     	r2, [sp, #0xc]
0x009140:	str     	r1, [sp, #8]
0x009142:	str     	r0, [sp, #4]
0x009144:	str     	r7, [sp]
0x009146:	ldr     	r0, [r3, #0xc]
0x009148:	adds    	r1, r5, #0
0x00914a:	adds    	r2, r6, #0
0x00914c:	ldr     	r7, [r0, #0x28]
0x00914e:	adds    	r0, r4, #0
0x009150:	mov     	r3, ip
0x009152:	blx     	r7
0x009154:	add     	sp, #0x14
0x009156:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_009160 =====
0x009160:	push    	{r4, lr}
0x009162:	movs    	r2, #0
0x009164:	add     	r0, pc
0x009166:	ldr     	r4, [r0, #0x3c]
0x009168:	sub     	sp, #0x10
0x00916a:	movs    	r1, #0
0x00916c:	str     	r1, [sp, #4]
0x00916e:	str     	r1, [sp, #8]
0x009170:	str     	r2, [sp, #0xc]
0x009172:	str     	r2, [sp]
0x009174:	ldr     	r0, [r4, #0xc]
0x009176:	ldr     	r2, [r0, #0x24]
0x009178:	ldr     	r4, [r0, #0x28]
0x00917a:	blx     	r4
0x00917c:	add     	sp, #0x10
0x00917e:	pop     	{r4, pc}

; ===== candidate_009184 =====
0x009184:	push    	{r4, lr}
0x009186:	ldr     	r0, [pc, #0x24]
0x009188:	sub     	sp, #0x10
0x00918a:	add     	r0, pc
0x00918c:	ldr     	r3, [r0, #0x3c]
0x00918e:	movs    	r2, #0
0x009190:	movs    	r1, #0
0x009192:	str     	r1, [sp, #4]
0x009194:	str     	r1, [sp, #8]
0x009196:	str     	r2, [sp, #0xc]
0x009198:	str     	r2, [sp]
0x00919a:	ldr     	r0, [r3, #0xc]
0x00919c:	movs    	r3, #0
0x00919e:	ldr     	r2, [r0, #0x24]
0x0091a0:	ldr     	r4, [r0, #0x28]
0x0091a2:	movs    	r1, #1
0x0091a4:	blx     	r4
0x0091a6:	add     	sp, #0x10
0x0091a8:	pop     	{r4, pc}

; ===== candidate_0091c4 =====
0x0091c4:	push    	{r4, lr}
0x0091c6:	sub     	sp, #0x10
0x0091c8:	movs    	r2, #0
0x0091ca:	movs    	r1, #0
0x0091cc:	str     	r2, [sp, #8]
0x0091ce:	ldr     	r2, [pc, #0x3c]
0x0091d0:	str     	r1, [sp]
0x0091d2:	str     	r1, [sp, #4]
0x0091d4:	movs    	r3, #0
0x0091d6:	add     	r2, pc
0x0091d8:	ldr     	r1, [pc, #0x34]
0x0091da:	ldr     	r0, [pc, #0x38]
0x0091dc:	bl      	#0x9124
0x0091e0:	ldr     	r3, [pc, #0x38]
0x0091e2:	ldr     	r4, [pc, #0x34]
0x0091e4:	add     	r3, sb
0x0091e6:	ldr     	r3, [r3]
0x0091e8:	movs    	r2, #0x41
0x0091ea:	movs    	r1, #0
0x0091ec:	add     	r4, sb
0x0091ee:	adds    	r0, r4, #0
0x0091f0:	blx     	r3
0x0091f2:	bl      	#0x91b0
0x0091f6:	ldr     	r3, [pc, #0x28]
0x0091f8:	adds    	r1, r0, #0
0x0091fa:	add     	r3, sb
0x0091fc:	ldr     	r3, [r3]
0x0091fe:	movs    	r2, #0x41
0x009200:	adds    	r0, r4, #0
0x009202:	blx     	r3
0x009204:	movs    	r0, #0
0x009206:	add     	sp, #0x10
0x009208:	pop     	{r4, pc}

; ===== candidate_009228 =====
0x009228:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00922a:	adds    	r7, r3, #0
0x00922c:	adds    	r6, r2, #0
0x00922e:	adds    	r5, r0, #0
0x009230:	ldr     	r0, [r0]
0x009232:	sub     	sp, #4
0x009234:	mov     	r1, sb
0x009236:	str     	r1, [sp]
0x009238:	movs    	r4, #0
0x00923a:	blx     	#0x2e0
0x00923e:	ldr     	r0, [sp, #8]
0x009240:	cmp     	r0, #0xb
0x009242:	bhs     	#0x92b0
0x009244:	adr     	r3, #4
0x009246:	ldrb    	r3, [r3, r0]
0x009248:	lsls    	r3, r3, #1
0x00924a:	add     	pc, r3
0x00924c:	lsrs    	r5, r0, #0x1c
0x00924e:	subs    	r4, r3, #4
0x009250:	movs    	r4, #0x21
0x009252:	adds    	r1, #0x27
0x009254:	adds    	r1, #0x2b
0x009256:	movs    	r7, r5
0x009258:	ldr     	r1, [pc, #0x60]
0x00925a:	ldr     	r0, [r5, #0xc]
0x00925c:	add     	r1, sb
0x00925e:	str     	r0, [r1, #0x14]
0x009260:	bl      	#0x328
0x009264:	bl      	#0x91c4
0x009268:	adds    	r4, r0, #0
0x00926a:	b       	#0x92b0
0x00926c:	ldr     	r0, [r6]
0x00926e:	cmp     	r0, #8
0x009270:	bne     	#0x927a
0x009272:	bl      	#0x9120
0x009276:	adds    	r4, r0, #0
0x009278:	b       	#0x92b0
0x00927a:	ldr     	r1, [r6, #4]
0x00927c:	ldr     	r2, [r6, #8]
0x00927e:	bl      	#0x911c
0x009282:	adds    	r4, r0, #0
0x009284:	b       	#0x92b0
0x009286:	bl      	#0x94b8
0x00928a:	b       	#0x92b0
0x00928c:	str     	r7, [r5, #0xc]
0x00928e:	b       	#0x92b0
0x009290:	bl      	#0x9224
0x009294:	b       	#0x92b0
0x009296:	bl      	#0x92f4
0x00929a:	b       	#0x92b0
0x00929c:	ldr     	r0, [pc, #0x1c]
0x00929e:	add     	r0, sb
0x0092a0:	str     	r7, [r0, #0x1c]
0x0092a2:	b       	#0x92b0
0x0092a4:	ldr     	r0, [pc, #0x14]
0x0092a6:	add     	r0, sb
0x0092a8:	str     	r6, [r0, #0x20]
0x0092aa:	b       	#0x92b0
0x0092ac:	ldr     	r4, [pc, #0x10]
0x0092ae:	add     	r4, pc
0x0092b0:	ldr     	r1, [sp]
0x0092b2:	add     	sp, #0x14
0x0092b4:	adds    	r0, r4, #0
0x0092b6:	mov     	sb, r1
0x0092b8:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0092c4 =====
0x0092c4:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0092c6:	sub     	sp, #0xc
0x0092c8:	ldr     	r0, [sp, #0x38]
0x0092ca:	ldr     	r4, [sp, #0x3c]
0x0092cc:	ldr     	r6, [sp, #0x34]
0x0092ce:	ldr     	r0, [r0]
0x0092d0:	mov     	r7, sb
0x0092d2:	movs    	r5, #0
0x0092d4:	blx     	#0x2e0
0x0092d8:	cmp     	r4, #0
0x0092da:	beq     	#0x92ea
0x0092dc:	ldr     	r1, [sp, #0x30]
0x0092de:	str     	r6, [sp, #4]
0x0092e0:	add     	r3, sp, #0xc
0x0092e2:	str     	r1, [sp]
0x0092e4:	ldm     	r3, {r0, r1, r2, r3}
0x0092e6:	blx     	r4
0x0092e8:	adds    	r5, r0, #0
0x0092ea:	mov     	sb, r7
0x0092ec:	adds    	r0, r5, #0
0x0092ee:	add     	sp, #0x1c
0x0092f0:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_009358 =====
0x009358:	push    	{r3, r4, r5, r6, r7, lr}
0x00935a:	adds    	r4, r0, #0
0x00935c:	ldr     	r0, [pc, #0x10c]
0x00935e:	movs    	r5, #0
0x009360:	mvns    	r5, r5
0x009362:	mov     	ip, r2
0x009364:	add     	r0, pc
0x009366:	ldr     	r2, [r0, #0x38]
0x009368:	cmp     	r4, #0
0x00936a:	bne     	#0x937c
0x00936c:	ldr     	r0, [pc, #0x100]
0x00936e:	ldr     	r2, [r2, #0x68]
0x009370:	movs    	r1, #0x7d
0x009372:	lsls    	r1, r1, #3
0x009374:	add     	r0, pc
0x009376:	blx     	r2
0x009378:	adds    	r0, r5, #0
0x00937a:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_009484 =====
0x009484:	push    	{r3, r4, r5, lr}
0x009486:	ldr     	r4, [pc, #0x28]
0x009488:	adds    	r5, r0, #0
0x00948a:	add     	r4, pc
0x00948c:	ldr     	r0, [r4, #0x38]
0x00948e:	adds    	r0, #0x80
0x009490:	ldr     	r0, [r0, #4]
0x009492:	blx     	r0
0x009494:	adds    	r0, r0, r5
0x009496:	ldr     	r1, [pc, #0x1c]
0x009498:	add     	r1, sb
0x00949a:	str     	r0, [r1, #0x10]
0x00949c:	ldr     	r0, [r4, #0x38]
0x00949e:	adds    	r0, #0x80
0x0094a0:	ldr     	r0, [r0]
0x0094a2:	blx     	r0
0x0094a4:	ldr     	r0, [r4, #0x38]
0x0094a6:	ldr     	r1, [r0, #0x7c]
0x0094a8:	lsls    	r0, r5, #0x10
0x0094aa:	lsrs    	r0, r0, #0x10
0x0094ac:	blx     	r1
0x0094ae:	pop     	{r3, r4, r5, pc}

; ===== candidate_0094ba =====
0x0094ba:	push    	{r3, r4, r5, r6, r7, lr}
0x0094bc:	add     	r0, pc
0x0094be:	ldr     	r0, [r0, #0x38]
0x0094c0:	adds    	r0, #0x80
0x0094c2:	ldr     	r0, [r0, #4]
0x0094c4:	blx     	r0
0x0094c6:	movs    	r5, #0
0x0094c8:	ldr     	r6, [pc, #0xc8]
0x0094ca:	add     	r6, sb
0x0094cc:	ldr     	r1, [r6, #0x10]
0x0094ce:	str     	r5, [r6, #0x10]
0x0094d0:	subs    	r1, r0, r1
0x0094d2:	ldr     	r0, [r6, #8]
0x0094d4:	adds    	r3, r1, #0
0x0094d6:	cmp     	r0, #0
0x0094d8:	beq     	#0x958e
0x0094da:	ldr     	r2, [r0, #8]
0x0094dc:	cmp     	r2, #0
0x0094de:	bne     	#0x953e
0x0094e0:	mvns    	r7, r2
0x0094e2:	str     	r7, [r0, #8]
0x0094e4:	ldr     	r2, [r0, #0x18]
0x0094e6:	adds    	r4, r0, #0
0x0094e8:	cmp     	r1, #0x32
0x0094ea:	str     	r2, [r6, #8]
0x0094ec:	bge     	#0x94f2
0x0094ee:	movs    	r1, #0x32
0x0094f0:	b       	#0x950e
0x0094f2:	movs    	r2, #0x7d
0x0094f4:	lsls    	r2, r2, #4
0x0094f6:	cmp     	r1, r2
0x0094f8:	ble     	#0x950e
0x0094fa:	adds    	r1, r2, #0
0x0094fc:	b       	#0x950e
0x0094fe:	movs    	r7, #0
0x009500:	mvns    	r7, r7
0x009502:	str     	r7, [r2, #8]
0x009504:	ldr     	r2, [r0, #0x18]
0x009506:	str     	r2, [r0, #0x1c]
0x009508:	ldr     	r0, [r2, #0x18]
0x00950a:	str     	r0, [r6, #8]
0x00950c:	adds    	r0, r2, #0
0x00950e:	ldr     	r2, [r0, #0x18]
0x009510:	cmp     	r2, #0
0x009512:	beq     	#0x951a
0x009514:	ldr     	r7, [r2, #8]
0x009516:	cmp     	r7, r1
0x009518:	blt     	#0x94fe
0x00951a:	str     	r5, [r0, #0x1c]
0x00951c:	ldr     	r0, [r6, #8]
0x00951e:	cmp     	r0, #0
0x009520:	beq     	#0x9582
0x009522:	cmp     	r3, #0
0x009524:	bge     	#0x9528
0x009526:	movs    	r3, #0
0x009528:	ldr     	r0, [r6, #8]
0x00952a:	ldr     	r1, [r0, #8]
0x00952c:	cmp     	r1, #0
0x00952e:	bge     	#0x9534
0x009530:	movs    	r1, #0
0x009532:	str     	r5, [r0, #8]
0x009534:	ldr     	r2, [pc, #0x60]
0x009536:	cmp     	r1, r2
0x009538:	ble     	#0x9542
0x00953a:	adds    	r1, r2, #0
0x00953c:	b       	#0x9542
0x00953e:	movs    	r4, #0
0x009540:	b       	#0x9522
0x009542:	ldr     	r2, [r0, #8]
0x009544:	subs    	r2, r2, r1
0x009546:	str     	r2, [r0, #8]
0x009548:	ldr     	r0, [r0, #0x18]
0x00954a:	cmp     	r0, #0
0x00954c:	bne     	#0x9542
0x00954e:	subs    	r0, r1, r3
0x009550:	cmp     	r0, #0
0x009552:	bgt     	#0x9556
0x009554:	movs    	r0, #0xa
0x009556:	bl      	#0x9484
0x00955a:	b       	#0x9582
0x00955c:	str     	r5, [r4, #8]
0x00955e:	ldr     	r0, [r4, #0x1c]
0x009560:	adds    	r3, r5, #0
0x009562:	str     	r0, [r6, #0xc]
0x009564:	ldr     	r0, [r4, #0x14]
0x009566:	cmp     	r0, #0
0x009568:	beq     	#0x9576
0x00956a:	str     	r0, [sp]
0x00956c:	movs    	r1, #0
0x00956e:	adds    	r0, r4, #0
0x009570:	ldr     	r2, [r4, #0x10]
0x009572:	bl      	#0x9358
0x009576:	ldr     	r1, [r4, #0xc]
0x009578:	cmp     	r1, #0
0x00957a:	beq     	#0x9580
0x00957c:	ldr     	r0, [r4, #0x10]
0x00957e:	blx     	r1
0x009580:	ldr     	r4, [r6, #0xc]
0x009582:	cmp     	r4, #0
0x009584:	beq     	#0x958c
0x009586:	ldr     	r0, [r4, #8]
0x009588:	cmp     	r0, #0
0x00958a:	blt     	#0x955c
0x00958c:	str     	r5, [r6, #0xc]
0x00958e:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_00959c =====
0x00959c:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00959e:	sub     	sp, #0xc
0x0095a0:	adds    	r4, r1, #0
0x0095a2:	movs    	r1, #0
0x0095a4:	adds    	r5, r2, #0
0x0095a6:	movs    	r2, #0
0x0095a8:	str     	r2, [sp, #8]
0x0095aa:	str     	r1, [sp]
0x0095ac:	str     	r1, [sp, #4]
0x0095ae:	movs    	r6, #0xf1
0x0095b0:	adds    	r7, r3, #0
0x0095b2:	movs    	r3, #0
0x0095b4:	lsls    	r6, r6, #9
0x0095b6:	movs    	r1, #0xe1
0x0095b8:	movs    	r2, #0xff
0x0095ba:	adds    	r0, r6, #0
0x0095bc:	bl      	#0x9124
0x0095c0:	cmp     	r0, #0
0x0095c2:	bne     	#0x95da
0x0095c4:	movs    	r1, #0
0x0095c6:	movs    	r2, #0
0x0095c8:	str     	r2, [sp, #8]
0x0095ca:	str     	r1, [sp]
0x0095cc:	str     	r1, [sp, #4]
0x0095ce:	movs    	r1, #0x14
0x0095d0:	movs    	r2, #0xff
0x0095d2:	movs    	r3, #1
0x0095d4:	adds    	r0, r6, #0
0x0095d6:	bl      	#0x9124
0x0095da:	ldr     	r0, [sp, #0xc]
0x0095dc:	cmp     	r0, #0x44
0x0095de:	bhs     	#0x95ea
0x0095e0:	adr     	r3, #8
0x0095e2:	adds    	r3, r3, r0
0x0095e4:	ldrh    	r3, [r3, r0]
0x0095e6:	lsls    	r3, r3, #1
0x0095e8:	add     	pc, r3
0x0095ea:	b       	#0x997e
0x0095ec:	lsls    	r1, r4, #6
0x0095ee:	lsls    	r4, r5, #6
0x0095f0:	lsls    	r3, r1, #6
0x0095f2:	lsls    	r7, r6, #6
0x0095f4:	lsls    	r6, r0, #6
0x0095f6:	lsls    	r2, r0, #6
0x0095f8:	lsls    	r5, r7, #5
0x0095fa:	lsls    	r1, r7, #5
0x0095fc:	lsls    	r4, r6, #5
0x0095fe:	lsls    	r0, r6, #5
0x009600:	lsls    	r3, r5, #5
0x009602:	lsls    	r6, r4, #5
0x009604:	lsls    	r1, r4, #5
0x009606:	lsls    	r5, r3, #5
0x009608:	lsls    	r1, r3, #5
0x00960a:	lsls    	r5, r2, #5
0x00960c:	lsls    	r0, r2, #5
0x00960e:	lsls    	r4, r1, #5
0x009610:	lsls    	r7, r0, #5
0x009612:	lsls    	r1, r0, #5
0x009614:	lsls    	r4, r7, #4
0x009616:	lsls    	r7, r6, #4
0x009618:	lsls    	r2, r6, #4
0x00961a:	lsls    	r6, r5, #4
0x00961c:	lsls    	r1, r5, #4
0x00961e:	lsls    	r4, r4, #4
0x009620:	lsls    	r0, r4, #4
0x009622:	lsls    	r3, r3, #4
0x009624:	lsls    	r6, r2, #4
0x009626:	lsls    	r2, r2, #4
0x009628:	lsls    	r6, r1, #4
0x00962a:	lsls    	r1, r1, #4
0x00962c:	lsls    	r5, r0, #4
0x00962e:	lsls    	r0, r0, #4
0x009630:	lsls    	r2, r4, #3
0x009632:	lsls    	r6, r3, #3
0x009634:	lsls    	r0, r3, #3
0x009636:	lsls    	r3, r2, #3
0x009638:	lsls    	r6, r1, #3
0x00963a:	lsls    	r2, r1, #3
0x00963c:	lsls    	r5, r0, #3
0x00963e:	lsls    	r7, r7, #2
0x009640:	lsls    	r2, r7, #2
0x009642:	lsls    	r4, r6, #2
0x009644:	lsls    	r7, r5, #2
0x009646:	lsls    	r2, r5, #2
0x009648:	lsls    	r5, r4, #2
0x00964a:	lsls    	r7, r3, #2
0x00964c:	lsls    	r2, r3, #2
0x00964e:	lsls    	r5, r2, #2
0x009650:	lsls    	r1, r2, #2
0x009652:	lsls    	r5, r1, #2
0x009654:	lsls    	r6, r0, #2
0x009656:	lsls    	r1, r0, #2
0x009658:	lsls    	r5, r7, #1
0x00965a:	lsls    	r0, r7, #1
0x00965c:	lsls    	r3, r6, #1
0x00965e:	lsls    	r6, r5, #1
0x009660:	lsls    	r2, r5, #1
0x009662:	lsls    	r5, r4, #1
0x009664:	lsls    	r0, r4, #1
0x009666:	lsls    	r4, r3, #1
0x009668:	lsls    	r7, r2, #1
0x00966a:	lsls    	r5, r2, #1
0x00966c:	lsls    	r3, r2, #1
0x00966e:	lsls    	r6, r1, #1
0x009670:	lsls    	r2, r1, #1
0x009672:	lsls    	r4, r0, #1
0x009674:	adds    	r0, r4, #0
0x009676:	bl      	#0x7f78
0x00967a:	movs    	r0, #0
0x00967c:	add     	sp, #0x1c
0x00967e:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_009994 =====
0x009994:	push    	{r4, r5, r6, r7, lr}
0x009996:	sub     	sp, #0x34
0x009998:	movs    	r1, #0
0x00999a:	str     	r1, [sp]
0x00999c:	str     	r1, [sp, #4]
0x00999e:	movs    	r2, #0
0x0099a0:	str     	r2, [sp, #8]
0x0099a2:	movs    	r7, #0xf1
0x0099a4:	movs    	r6, #0
0x0099a6:	adds    	r3, r6, #0
0x0099a8:	lsls    	r7, r7, #9
0x0099aa:	ldr     	r2, [r0, #8]
0x0099ac:	movs    	r1, #0x45
0x0099ae:	adds    	r4, r0, #0
0x0099b0:	adds    	r0, r7, #0
0x0099b2:	bl      	#0x9124
0x0099b6:	movs    	r1, #0
0x0099b8:	str     	r1, [sp]
0x0099ba:	str     	r1, [sp, #4]
0x0099bc:	movs    	r2, #0
0x0099be:	str     	r0, [sp, #0x30]
0x0099c0:	str     	r2, [sp, #8]
0x0099c2:	movs    	r1, #0x45
0x0099c4:	adds    	r3, r6, #0
0x0099c6:	adds    	r0, r7, #0
0x0099c8:	ldr     	r2, [r4, #8]
0x0099ca:	bl      	#0x9124
0x0099ce:	movs    	r1, #0
0x0099d0:	str     	r1, [sp]
0x0099d2:	str     	r1, [sp, #4]
0x0099d4:	movs    	r2, #0
0x0099d6:	str     	r0, [sp, #0x2c]
0x0099d8:	str     	r2, [sp, #8]
0x0099da:	movs    	r1, #0x47
0x0099dc:	adds    	r3, r6, #0
0x0099de:	adds    	r0, r7, #0
0x0099e0:	ldr     	r2, [r4, #8]
0x0099e2:	bl      	#0x9124
0x0099e6:	movs    	r1, #0
0x0099e8:	str     	r1, [sp]
0x0099ea:	str     	r1, [sp, #4]
0x0099ec:	str     	r0, [sp, #0x28]
0x0099ee:	movs    	r2, #0
0x0099f0:	str     	r2, [sp, #8]
0x0099f2:	movs    	r1, #0x45
0x0099f4:	adds    	r3, r6, #0
0x0099f6:	adds    	r0, r7, #0
0x0099f8:	ldr     	r2, [r4, #8]
0x0099fa:	bl      	#0x9124
0x0099fe:	movs    	r1, #0
0x009a00:	str     	r0, [sp, #0x24]
0x009a02:	str     	r1, [sp, #4]
0x009a04:	str     	r1, [sp]
0x009a06:	movs    	r2, #0
0x009a08:	str     	r2, [sp, #8]
0x009a0a:	movs    	r1, #0x46
0x009a0c:	adds    	r3, r6, #0
0x009a0e:	adds    	r0, r7, #0
0x009a10:	ldr     	r2, [r4, #8]
0x009a12:	bl      	#0x9124
0x009a16:	lsls    	r1, r0, #0x18
0x009a18:	asrs    	r1, r1, #0x18
0x009a1a:	str     	r1, [sp, #0x20]
0x009a1c:	movs    	r1, #0
0x009a1e:	str     	r1, [sp]
0x009a20:	str     	r1, [sp, #4]
0x009a22:	movs    	r2, #0
0x009a24:	str     	r2, [sp, #8]
0x009a26:	movs    	r1, #0x46
0x009a28:	adds    	r3, r6, #0
0x009a2a:	adds    	r0, r7, #0
0x009a2c:	ldr     	r2, [r4, #8]
0x009a2e:	bl      	#0x9124
0x009a32:	movs    	r1, #0
0x009a34:	lsls    	r0, r0, #0x18
0x009a36:	asrs    	r0, r0, #0x18
0x009a38:	str     	r1, [sp]
0x009a3a:	str     	r1, [sp, #4]
0x009a3c:	movs    	r2, #0
0x009a3e:	str     	r0, [sp, #0x1c]
0x009a40:	str     	r2, [sp, #8]
0x009a42:	movs    	r1, #0x46
0x009a44:	adds    	r3, r6, #0
0x009a46:	adds    	r0, r7, #0
0x009a48:	ldr     	r2, [r4, #8]
0x009a4a:	bl      	#0x9124
0x009a4e:	movs    	r1, #0
0x009a50:	lsls    	r0, r0, #0x18
0x009a52:	asrs    	r0, r0, #0x18
0x009a54:	str     	r1, [sp]
0x009a56:	str     	r1, [sp, #4]
0x009a58:	movs    	r2, #0
0x009a5a:	str     	r0, [sp, #0x18]
0x009a5c:	str     	r2, [sp, #8]
0x009a5e:	movs    	r1, #0x46
0x009a60:	adds    	r3, r6, #0
0x009a62:	adds    	r0, r7, #0
0x009a64:	ldr     	r2, [r4, #8]
0x009a66:	bl      	#0x9124
0x009a6a:	movs    	r1, #0
0x009a6c:	lsls    	r0, r0, #0x18
0x009a6e:	asrs    	r0, r0, #0x18
0x009a70:	str     	r1, [sp]
0x009a72:	str     	r1, [sp, #4]
0x009a74:	movs    	r2, #0
0x009a76:	str     	r0, [sp, #0x14]
0x009a78:	str     	r2, [sp, #8]
0x009a7a:	movs    	r1, #0x46
0x009a7c:	adds    	r3, r6, #0
0x009a7e:	adds    	r0, r7, #0
0x009a80:	ldr     	r2, [r4, #8]
0x009a82:	bl      	#0x9124
0x009a86:	movs    	r1, #0
0x009a88:	lsls    	r0, r0, #0x18
0x009a8a:	asrs    	r0, r0, #0x18
0x009a8c:	str     	r1, [sp]
0x009a8e:	str     	r1, [sp, #4]
0x009a90:	movs    	r2, #0
0x009a92:	str     	r0, [sp, #0x10]
0x009a94:	str     	r2, [sp, #8]
0x009a96:	movs    	r1, #0x46
0x009a98:	adds    	r3, r6, #0
0x009a9a:	adds    	r0, r7, #0
0x009a9c:	ldr     	r2, [r4, #8]
0x009a9e:	bl      	#0x9124
0x009aa2:	lsls    	r0, r0, #0x18
0x009aa4:	asrs    	r0, r0, #0x18
0x009aa6:	movs    	r5, #0
0x009aa8:	cmp     	r0, #1
0x009aaa:	bne     	#0x9ac4
0x009aac:	movs    	r1, #0
0x009aae:	str     	r1, [sp]
0x009ab0:	str     	r1, [sp, #4]
0x009ab2:	movs    	r2, #0
0x009ab4:	str     	r2, [sp, #8]
0x009ab6:	movs    	r1, #0x47
0x009ab8:	adds    	r3, r6, #0
0x009aba:	adds    	r0, r7, #0
0x009abc:	ldr     	r2, [r4, #8]
0x009abe:	bl      	#0x9124
0x009ac2:	adds    	r5, r0, #0

; ===== candidate_009b2c =====
0x009b2c:	push    	{r4, r5, r6, r7, lr}
0x009b2e:	sub     	sp, #0x24
0x009b30:	movs    	r1, #0
0x009b32:	str     	r1, [sp]
0x009b34:	str     	r1, [sp, #4]
0x009b36:	movs    	r2, #0
0x009b38:	str     	r2, [sp, #8]
0x009b3a:	adds    	r5, r0, #0
0x009b3c:	ldr     	r2, [r0, #8]
0x009b3e:	movs    	r6, #0
0x009b40:	adds    	r3, r6, #0
0x009b42:	movs    	r0, #0xf1
0x009b44:	movs    	r1, #0x45
0x009b46:	lsls    	r0, r0, #9
0x009b48:	bl      	#0x9124
0x009b4c:	str     	r0, [sp, #0x20]
0x009b4e:	movs    	r1, #0
0x009b50:	str     	r1, [sp]
0x009b52:	str     	r1, [sp, #4]
0x009b54:	movs    	r2, #0
0x009b56:	str     	r2, [sp, #8]
0x009b58:	movs    	r1, #0x45
0x009b5a:	movs    	r0, #0xf1
0x009b5c:	adds    	r3, r6, #0
0x009b5e:	lsls    	r0, r0, #9
0x009b60:	ldr     	r2, [r5, #8]
0x009b62:	bl      	#0x9124
0x009b66:	movs    	r1, #0
0x009b68:	str     	r1, [sp]
0x009b6a:	str     	r1, [sp, #4]
0x009b6c:	str     	r0, [sp, #0x1c]
0x009b6e:	movs    	r2, #0
0x009b70:	str     	r2, [sp, #8]
0x009b72:	movs    	r0, #0xf1
0x009b74:	movs    	r1, #0x47
0x009b76:	adds    	r3, r6, #0
0x009b78:	lsls    	r0, r0, #9
0x009b7a:	ldr     	r2, [r5, #8]
0x009b7c:	bl      	#0x9124
0x009b80:	movs    	r1, #0
0x009b82:	str     	r1, [sp]
0x009b84:	str     	r1, [sp, #4]
0x009b86:	str     	r0, [sp, #0x18]
0x009b88:	movs    	r2, #0
0x009b8a:	str     	r2, [sp, #8]
0x009b8c:	movs    	r0, #0xf1
0x009b8e:	movs    	r1, #0x45
0x009b90:	adds    	r3, r6, #0
0x009b92:	lsls    	r0, r0, #9
0x009b94:	ldr     	r2, [r5, #8]
0x009b96:	bl      	#0x9124
0x009b9a:	movs    	r1, #0
0x009b9c:	str     	r1, [sp]
0x009b9e:	str     	r1, [sp, #4]
0x009ba0:	str     	r0, [sp, #0x10]
0x009ba2:	movs    	r2, #0
0x009ba4:	str     	r2, [sp, #8]
0x009ba6:	movs    	r0, #0xf1
0x009ba8:	movs    	r1, #0x45
0x009baa:	adds    	r3, r6, #0
0x009bac:	lsls    	r0, r0, #9
0x009bae:	ldr     	r2, [r5, #8]
0x009bb0:	bl      	#0x9124
0x009bb4:	movs    	r1, #0
0x009bb6:	str     	r1, [sp]
0x009bb8:	str     	r1, [sp, #4]
0x009bba:	str     	r0, [sp, #0xc]
0x009bbc:	movs    	r2, #0
0x009bbe:	str     	r2, [sp, #8]
0x009bc0:	movs    	r0, #0xf1
0x009bc2:	movs    	r1, #0x46
0x009bc4:	adds    	r3, r6, #0
0x009bc6:	lsls    	r0, r0, #9
0x009bc8:	ldr     	r2, [r5, #8]
0x009bca:	bl      	#0x9124
0x009bce:	movs    	r1, #0
0x009bd0:	str     	r1, [sp]
0x009bd2:	str     	r1, [sp, #4]
0x009bd4:	str     	r0, [sp, #0x14]
0x009bd6:	movs    	r2, #0
0x009bd8:	str     	r2, [sp, #8]
0x009bda:	movs    	r0, #0xf1
0x009bdc:	movs    	r1, #0x46
0x009bde:	adds    	r3, r6, #0
0x009be0:	lsls    	r0, r0, #9
0x009be2:	ldr     	r2, [r5, #8]
0x009be4:	bl      	#0x9124
0x009be8:	movs    	r1, #0
0x009bea:	adds    	r7, r0, #0
0x009bec:	str     	r1, [sp]
0x009bee:	str     	r1, [sp, #4]
0x009bf0:	movs    	r2, #0
0x009bf2:	movs    	r1, #0xad
0x009bf4:	movs    	r0, #0xf1
0x009bf6:	adds    	r3, r6, #0
0x009bf8:	lsls    	r0, r0, #9
0x009bfa:	str     	r2, [sp, #8]
0x009bfc:	bl      	#0x9124
0x009c00:	ldr     	r1, [sp, #0x10]
0x009c02:	adds    	r4, r0, #0
0x009c04:	str     	r1, [r0, #0x40]
0x009c06:	adds    	r0, #0x60
0x009c08:	strb    	r6, [r0, #0xe]
0x009c0a:	ldr     	r1, [sp, #0x20]
0x009c0c:	str     	r1, [r4, #4]
0x009c0e:	ldr     	r1, [sp, #0x1c]
0x009c10:	str     	r1, [r4, #8]
0x009c12:	ldr     	r1, [sp, #0x18]
0x009c14:	str     	r1, [r4]
0x009c16:	ldr     	r0, [sp, #0xc]
0x009c18:	movs    	r1, #0x44
0x009c1a:	str     	r0, [r4, #0x38]
0x009c1c:	strb    	r7, [r1, r4]
0x009c1e:	ldr     	r0, [sp, #0x14]
0x009c20:	cmp     	r0, #1
0x009c22:	bne     	#0x9c28
0x009c24:	strb    	r0, [r4, #0x10]
0x009c26:	b       	#0x9c2a
0x009c28:	strb    	r6, [r4, #0x10]
0x009c2a:	movs    	r1, #0
0x009c2c:	str     	r1, [sp]
0x009c2e:	str     	r1, [sp, #4]
0x009c30:	movs    	r2, #0
0x009c32:	movs    	r7, #0xf1
0x009c34:	lsls    	r7, r7, #9
0x009c36:	str     	r2, [sp, #8]
0x009c38:	movs    	r1, #0x46
0x009c3a:	adds    	r3, r6, #0
0x009c3c:	adds    	r0, r7, #0
0x009c3e:	ldr     	r2, [r5, #8]
0x009c40:	bl      	#0x9124
0x009c44:	lsls    	r0, r0, #0x18
0x009c46:	asrs    	r0, r0, #0x18
0x009c48:	adds    	r3, r0, #1
0x009c4a:	beq     	#0x9c64
0x009c4c:	movs    	r1, #0
0x009c4e:	str     	r1, [sp]
0x009c50:	str     	r1, [sp, #4]
0x009c52:	movs    	r2, #0
0x009c54:	str     	r2, [sp, #8]
0x009c56:	movs    	r1, #0x47

; ===== candidate_009c84 =====
0x009c84:	push    	{r4, r5, r6, r7, lr}
0x009c86:	sub     	sp, #0x1c
0x009c88:	movs    	r1, #0
0x009c8a:	str     	r1, [sp]
0x009c8c:	str     	r1, [sp, #4]
0x009c8e:	movs    	r2, #0
0x009c90:	str     	r2, [sp, #8]
0x009c92:	movs    	r7, #0xf1
0x009c94:	movs    	r6, #0
0x009c96:	adds    	r3, r6, #0
0x009c98:	lsls    	r7, r7, #9
0x009c9a:	ldr     	r2, [r0, #8]
0x009c9c:	movs    	r1, #0x46
0x009c9e:	adds    	r4, r0, #0
0x009ca0:	adds    	r0, r7, #0
0x009ca2:	bl      	#0x9124
0x009ca6:	lsls    	r0, r0, #0x18
0x009ca8:	movs    	r1, #0
0x009caa:	asrs    	r0, r0, #0x18
0x009cac:	movs    	r2, #0
0x009cae:	str     	r2, [sp, #8]
0x009cb0:	str     	r1, [sp]
0x009cb2:	str     	r1, [sp, #4]
0x009cb4:	movs    	r1, #0xa
0x009cb6:	adds    	r2, r0, #0
0x009cb8:	str     	r0, [sp, #0x14]
0x009cba:	movs    	r5, #0
0x009cbc:	movs    	r3, #4
0x009cbe:	adds    	r0, r7, #0
0x009cc0:	bl      	#0x9124
0x009cc4:	str     	r0, [sp, #0x18]
0x009cc6:	ldr     	r0, [sp, #0x14]
0x009cc8:	cmp     	r0, #0
0x009cca:	ble     	#0x9d6c
0x009ccc:	movs    	r1, #0
0x009cce:	str     	r1, [sp]
0x009cd0:	str     	r1, [sp, #4]
0x009cd2:	movs    	r2, #0
0x009cd4:	movs    	r6, #0
0x009cd6:	adds    	r3, r6, #0
0x009cd8:	str     	r2, [sp, #8]
0x009cda:	movs    	r1, #0x45
0x009cdc:	movs    	r0, #0xf1
0x009cde:	lsls    	r0, r0, #9
0x009ce0:	ldr     	r2, [r4, #8]
0x009ce2:	bl      	#0x9124
0x009ce6:	movs    	r1, #0
0x009ce8:	str     	r1, [sp]
0x009cea:	str     	r1, [sp, #4]
0x009cec:	adds    	r7, r0, #0
0x009cee:	movs    	r2, #0
0x009cf0:	str     	r2, [sp, #8]
0x009cf2:	movs    	r0, #0xf1
0x009cf4:	adds    	r3, r6, #0
0x009cf6:	movs    	r1, #0x45
0x009cf8:	lsls    	r0, r0, #9
0x009cfa:	ldr     	r2, [r4, #8]
0x009cfc:	bl      	#0x9124
0x009d00:	str     	r0, [sp, #0x10]
0x009d02:	cmp     	r7, #3
0x009d04:	bne     	#0x9d20
0x009d06:	movs    	r1, #0
0x009d08:	str     	r1, [sp]
0x009d0a:	str     	r1, [sp, #4]
0x009d0c:	movs    	r2, #0
0x009d0e:	str     	r2, [sp, #8]
0x009d10:	movs    	r1, #0x47
0x009d12:	movs    	r3, #0
0x009d14:	movs    	r0, #0xf1
0x009d16:	lsls    	r0, r0, #9
0x009d18:	ldr     	r2, [r4, #8]
0x009d1a:	bl      	#0x9124
0x009d1e:	adds    	r6, r0, #0
0x009d20:	movs    	r1, #0
0x009d22:	str     	r1, [sp]
0x009d24:	str     	r1, [sp, #4]
0x009d26:	movs    	r2, #0
0x009d28:	str     	r2, [sp, #8]
0x009d2a:	movs    	r1, #0x47
0x009d2c:	movs    	r3, #0
0x009d2e:	movs    	r0, #0xf1
0x009d30:	lsls    	r0, r0, #9
0x009d32:	ldr     	r2, [r4, #8]
0x009d34:	bl      	#0x9124
0x009d38:	movs    	r1, #0
0x009d3a:	movs    	r2, #0
0x009d3c:	str     	r2, [sp, #8]
0x009d3e:	str     	r1, [sp]
0x009d40:	str     	r1, [sp, #4]
0x009d42:	str     	r0, [sp, #0xc]
0x009d44:	movs    	r0, #0xf1
0x009d46:	movs    	r1, #0xf
0x009d48:	movs    	r2, #0x10
0x009d4a:	movs    	r3, #0
0x009d4c:	lsls    	r0, r0, #9
0x009d4e:	bl      	#0x9124
0x009d52:	str     	r7, [r0]
0x009d54:	ldr     	r1, [sp, #0x10]
0x009d56:	str     	r1, [r0, #4]
0x009d58:	ldr     	r1, [sp, #0xc]
0x009d5a:	str     	r1, [r0, #8]
0x009d5c:	str     	r6, [r0, #0xc]
0x009d5e:	ldr     	r2, [sp, #0x18]
0x009d60:	lsls    	r1, r5, #2
0x009d62:	str     	r0, [r2, r1]
0x009d64:	ldr     	r0, [sp, #0x14]
0x009d66:	adds    	r5, #1
0x009d68:	cmp     	r5, r0
0x009d6a:	blt     	#0x9ccc
0x009d6c:	ldr     	r0, [sp, #0x18]
0x009d6e:	add     	sp, #0x1c
0x009d70:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_009d74 =====
0x009d74:	push    	{r4, r5, r6, r7, lr}
0x009d76:	sub     	sp, #0xc
0x009d78:	movs    	r1, #0
0x009d7a:	str     	r1, [sp]
0x009d7c:	str     	r1, [sp, #4]
0x009d7e:	movs    	r2, #0
0x009d80:	str     	r2, [sp, #8]
0x009d82:	adds    	r4, r0, #0
0x009d84:	ldr     	r2, [r0, #8]
0x009d86:	movs    	r5, #0
0x009d88:	adds    	r3, r5, #0
0x009d8a:	movs    	r0, #0xf1
0x009d8c:	movs    	r1, #0x45
0x009d8e:	lsls    	r0, r0, #9
0x009d90:	bl      	#0x9124
0x009d94:	movs    	r1, #0
0x009d96:	str     	r1, [sp]
0x009d98:	str     	r1, [sp, #4]
0x009d9a:	adds    	r6, r0, #0
0x009d9c:	movs    	r2, #0
0x009d9e:	str     	r2, [sp, #8]
0x009da0:	movs    	r0, #0xf1
0x009da2:	adds    	r3, r5, #0
0x009da4:	movs    	r1, #0x45
0x009da6:	lsls    	r0, r0, #9
0x009da8:	ldr     	r2, [r4, #8]
0x009daa:	bl      	#0x9124
0x009dae:	adds    	r7, r0, #0
0x009db0:	adds    	r0, r4, #0
0x009db2:	bl      	#0x9c84
0x009db6:	movs    	r1, #0
0x009db8:	adds    	r4, r0, #0
0x009dba:	movs    	r2, #0
0x009dbc:	str     	r2, [sp, #8]
0x009dbe:	str     	r1, [sp]
0x009dc0:	str     	r1, [sp, #4]
0x009dc2:	movs    	r1, #0xf
0x009dc4:	movs    	r2, #0xc
0x009dc6:	movs    	r0, #0xf1
0x009dc8:	adds    	r3, r5, #0
0x009dca:	lsls    	r0, r0, #9
0x009dcc:	bl      	#0x9124
0x009dd0:	str     	r4, [r0, #8]
0x009dd2:	stm     	r0!, {r6, r7}
0x009dd4:	subs    	r0, #8
0x009dd6:	add     	sp, #0xc
0x009dd8:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_009ddc =====
0x009ddc:	push    	{r4, r5, r6, r7, lr}
0x009dde:	sub     	sp, #0x14
0x009de0:	movs    	r1, #0
0x009de2:	str     	r1, [sp]
0x009de4:	str     	r1, [sp, #4]
0x009de6:	ldr     	r4, [pc, #0x9c]
0x009de8:	movs    	r2, #0
0x009dea:	movs    	r7, #0xf1
0x009dec:	lsls    	r7, r7, #9
0x009dee:	str     	r2, [sp, #8]
0x009df0:	movs    	r1, #0x11
0x009df2:	movs    	r3, #4
0x009df4:	add     	r4, sb
0x009df6:	ldr     	r2, [r4, #8]
0x009df8:	adds    	r0, r7, #0
0x009dfa:	bl      	#0x9124
0x009dfe:	movs    	r4, #0
0x009e00:	movs    	r6, #0
0x009e02:	cmp     	r0, #0
0x009e04:	str     	r0, [sp, #0x10]
0x009e06:	ble     	#0x9e62
0x009e08:	ldr     	r1, [pc, #0x78]
0x009e0a:	lsls    	r0, r4, #2
0x009e0c:	add     	r1, sb
0x009e0e:	ldr     	r1, [r1, #8]
0x009e10:	movs    	r2, #0
0x009e12:	ldr     	r5, [r1, r0]
0x009e14:	movs    	r1, #0
0x009e16:	str     	r1, [sp]
0x009e18:	str     	r1, [sp, #4]
0x009e1a:	movs    	r1, #9
0x009e1c:	str     	r2, [sp, #8]
0x009e1e:	adds    	r3, r6, #0
0x009e20:	adds    	r0, r7, #0
0x009e22:	ldr     	r2, [r5]
0x009e24:	bl      	#0x9124
0x009e28:	ldr     	r3, [r5, #0x78]
0x009e2a:	cmp     	r3, #0
0x009e2c:	beq     	#0x9e44
0x009e2e:	movs    	r2, #0
0x009e30:	movs    	r1, #0
0x009e32:	str     	r2, [sp, #8]
0x009e34:	adds    	r2, r3, #0
0x009e36:	str     	r1, [sp]
0x009e38:	str     	r1, [sp, #4]
0x009e3a:	movs    	r1, #9
0x009e3c:	adds    	r3, r6, #0
0x009e3e:	adds    	r0, r7, #0
0x009e40:	bl      	#0x9124
0x009e44:	movs    	r1, #0
0x009e46:	movs    	r2, #0
0x009e48:	str     	r2, [sp, #8]
0x009e4a:	str     	r1, [sp]
0x009e4c:	str     	r1, [sp, #4]
0x009e4e:	movs    	r1, #9
0x009e50:	adds    	r2, r5, #0
0x009e52:	adds    	r3, r6, #0
0x009e54:	adds    	r0, r7, #0
0x009e56:	bl      	#0x9124
0x009e5a:	ldr     	r0, [sp, #0x10]
0x009e5c:	adds    	r4, #1
0x009e5e:	cmp     	r4, r0
0x009e60:	blt     	#0x9e08
0x009e62:	movs    	r1, #0
0x009e64:	str     	r1, [sp]
0x009e66:	str     	r1, [sp, #4]
0x009e68:	movs    	r2, #0
0x009e6a:	ldr     	r4, [pc, #0x18]
0x009e6c:	str     	r2, [sp, #8]
0x009e6e:	movs    	r1, #9
0x009e70:	adds    	r3, r6, #0
0x009e72:	add     	r4, sb
0x009e74:	ldr     	r2, [r4, #8]
0x009e76:	adds    	r0, r7, #0
0x009e78:	bl      	#0x9124
0x009e7c:	str     	r6, [r4, #8]
0x009e7e:	add     	sp, #0x14
0x009e80:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_009e88 =====
0x009e88:	push    	{r4, r5, r6, r7, lr}
0x009e8a:	ldr     	r0, [pc, #0x94]
0x009e8c:	movs    	r7, #0
0x009e8e:	add     	r0, sb
0x009e90:	ldr     	r4, [r0, #0x34]
0x009e92:	sub     	sp, #0xc
0x009e94:	cmp     	r4, #0
0x009e96:	beq     	#0x9f14
0x009e98:	movs    	r1, #0
0x009e9a:	movs    	r2, #0
0x009e9c:	str     	r2, [sp, #8]
0x009e9e:	str     	r1, [sp]
0x009ea0:	str     	r1, [sp, #4]
0x009ea2:	movs    	r1, #0x11
0x009ea4:	adds    	r2, r4, #0
0x009ea6:	movs    	r3, #4
0x009ea8:	movs    	r0, #0xf1
0x009eaa:	lsls    	r0, r0, #9
0x009eac:	bl      	#0x9124
0x009eb0:	adds    	r6, r0, #0
0x009eb2:	movs    	r4, #0
0x009eb4:	cmp     	r0, #0
0x009eb6:	ble     	#0x9ef8
0x009eb8:	ldr     	r1, [pc, #0x64]
0x009eba:	lsls    	r0, r4, #2
0x009ebc:	add     	r1, sb
0x009ebe:	ldr     	r1, [r1, #0x34]
0x009ec0:	movs    	r2, #0
0x009ec2:	ldr     	r5, [r1, r0]
0x009ec4:	movs    	r1, #0
0x009ec6:	str     	r1, [sp]
0x009ec8:	str     	r1, [sp, #4]
0x009eca:	movs    	r1, #9
0x009ecc:	str     	r2, [sp, #8]
0x009ece:	movs    	r0, #0xf1
0x009ed0:	adds    	r3, r7, #0
0x009ed2:	lsls    	r0, r0, #9
0x009ed4:	ldr     	r2, [r5]
0x009ed6:	bl      	#0x9124
0x009eda:	movs    	r1, #0
0x009edc:	movs    	r2, #0
0x009ede:	str     	r2, [sp, #8]
0x009ee0:	str     	r1, [sp]
0x009ee2:	str     	r1, [sp, #4]
0x009ee4:	adds    	r3, r7, #0
0x009ee6:	adds    	r2, r5, #0
0x009ee8:	movs    	r1, #9
0x009eea:	movs    	r0, #0xf1
0x009eec:	lsls    	r0, r0, #9
0x009eee:	bl      	#0x9124
0x009ef2:	adds    	r4, #1
0x009ef4:	cmp     	r4, r6
0x009ef6:	blt     	#0x9eb8
0x009ef8:	movs    	r1, #0
0x009efa:	ldr     	r0, [pc, #0x24]
0x009efc:	str     	r1, [sp]
0x009efe:	str     	r1, [sp, #4]
0x009f00:	movs    	r2, #0
0x009f02:	str     	r2, [sp, #8]
0x009f04:	add     	r0, sb
0x009f06:	ldr     	r2, [r0, #0x34]
0x009f08:	movs    	r0, #0xf1
0x009f0a:	movs    	r1, #9
0x009f0c:	adds    	r3, r7, #0
0x009f0e:	lsls    	r0, r0, #9
0x009f10:	bl      	#0x9124
0x009f14:	ldr     	r0, [pc, #8]
0x009f16:	add     	r0, sb
0x009f18:	str     	r7, [r0, #0x34]
0x009f1a:	add     	sp, #0xc
0x009f1c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_009f24 =====
0x009f24:	push    	{r4, r5, r6, r7, lr}
0x009f26:	sub     	sp, #0xc
0x009f28:	adds    	r6, r0, #0
0x009f2a:	beq     	#0x9fe2
0x009f2c:	ldr     	r3, [r6, #8]
0x009f2e:	cmp     	r3, #0
0x009f30:	beq     	#0x9fca
0x009f32:	movs    	r2, #0
0x009f34:	movs    	r1, #0
0x009f36:	str     	r2, [sp, #8]
0x009f38:	adds    	r2, r3, #0
0x009f3a:	str     	r1, [sp]
0x009f3c:	str     	r1, [sp, #4]
0x009f3e:	movs    	r1, #0x11
0x009f40:	movs    	r3, #4
0x009f42:	movs    	r0, #0xf1
0x009f44:	lsls    	r0, r0, #9
0x009f46:	bl      	#0x9124
0x009f4a:	adds    	r7, r0, #0
0x009f4c:	movs    	r4, #0
0x009f4e:	cmp     	r0, #0
0x009f50:	ble     	#0x9fb2
0x009f52:	ldr     	r0, [r6, #8]
0x009f54:	lsls    	r1, r4, #2
0x009f56:	ldr     	r5, [r0, r1]
0x009f58:	ldr     	r3, [r5, #8]
0x009f5a:	cmp     	r3, #0
0x009f5c:	beq     	#0x9f76
0x009f5e:	movs    	r2, #0
0x009f60:	movs    	r1, #0
0x009f62:	str     	r2, [sp, #8]
0x009f64:	adds    	r2, r3, #0
0x009f66:	str     	r1, [sp]
0x009f68:	str     	r1, [sp, #4]
0x009f6a:	movs    	r1, #9
0x009f6c:	movs    	r3, #0
0x009f6e:	movs    	r0, #0xf1
0x009f70:	lsls    	r0, r0, #9
0x009f72:	bl      	#0x9124
0x009f76:	ldr     	r3, [r5, #0xc]
0x009f78:	cmp     	r3, #0
0x009f7a:	beq     	#0x9f94
0x009f7c:	movs    	r2, #0
0x009f7e:	movs    	r1, #0
0x009f80:	str     	r2, [sp, #8]
0x009f82:	adds    	r2, r3, #0
0x009f84:	str     	r1, [sp]
0x009f86:	str     	r1, [sp, #4]
0x009f88:	movs    	r1, #9
0x009f8a:	movs    	r3, #0
0x009f8c:	movs    	r0, #0xf1
0x009f8e:	lsls    	r0, r0, #9
0x009f90:	bl      	#0x9124
0x009f94:	movs    	r1, #0
0x009f96:	movs    	r2, #0
0x009f98:	str     	r2, [sp, #8]
0x009f9a:	str     	r1, [sp]
0x009f9c:	str     	r1, [sp, #4]
0x009f9e:	movs    	r1, #9
0x009fa0:	adds    	r2, r5, #0
0x009fa2:	movs    	r3, #0
0x009fa4:	movs    	r0, #0xf1
0x009fa6:	lsls    	r0, r0, #9
0x009fa8:	bl      	#0x9124
0x009fac:	adds    	r4, #1
0x009fae:	cmp     	r4, r7
0x009fb0:	blt     	#0x9f52
0x009fb2:	movs    	r1, #0
0x009fb4:	str     	r1, [sp]
0x009fb6:	str     	r1, [sp, #4]
0x009fb8:	movs    	r2, #0
0x009fba:	str     	r2, [sp, #8]
0x009fbc:	movs    	r1, #9
0x009fbe:	movs    	r3, #0
0x009fc0:	movs    	r0, #0xf1
0x009fc2:	lsls    	r0, r0, #9
0x009fc4:	ldr     	r2, [r6, #8]
0x009fc6:	bl      	#0x9124
0x009fca:	movs    	r1, #0
0x009fcc:	movs    	r2, #0
0x009fce:	str     	r2, [sp, #8]
0x009fd0:	str     	r1, [sp]
0x009fd2:	str     	r1, [sp, #4]
0x009fd4:	movs    	r1, #9
0x009fd6:	adds    	r2, r6, #0
0x009fd8:	movs    	r3, #0
0x009fda:	movs    	r0, #0xf1
0x009fdc:	lsls    	r0, r0, #9
0x009fde:	bl      	#0x9124
0x009fe2:	add     	sp, #0xc
0x009fe4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_009fe8 =====
0x009fe8:	push    	{r4, r5, r6, r7, lr}
0x009fea:	ldr     	r6, [pc, #0x40]
0x009fec:	movs    	r5, #0xf1
0x009fee:	add     	r6, sb
0x009ff0:	ldr     	r7, [r6, #0x60]
0x009ff2:	lsls    	r5, r5, #9
0x009ff4:	movs    	r4, #0
0x009ff6:	cmp     	r7, #0
0x009ff8:	sub     	sp, #0xc
0x009ffa:	beq     	#0xa014
0x009ffc:	movs    	r1, #0
0x009ffe:	movs    	r2, #0
0x00a000:	str     	r2, [sp, #8]
0x00a002:	str     	r1, [sp]
0x00a004:	str     	r1, [sp, #4]
0x00a006:	movs    	r1, #0x12
0x00a008:	adds    	r2, r7, #0
0x00a00a:	adds    	r3, r4, #0
0x00a00c:	adds    	r0, r5, #0
0x00a00e:	bl      	#0x9124
0x00a012:	str     	r4, [r6, #0x60]
0x00a014:	movs    	r1, #0
0x00a016:	str     	r1, [sp]
0x00a018:	str     	r1, [sp, #4]
0x00a01a:	movs    	r2, #0
0x00a01c:	movs    	r1, #0x2c
0x00a01e:	adds    	r3, r4, #0
0x00a020:	adds    	r0, r5, #0
0x00a022:	str     	r2, [sp, #8]
0x00a024:	bl      	#0x9124
0x00a028:	add     	sp, #0xc
0x00a02a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a030 =====
0x00a030:	push    	{r4, r5, r6, r7, lr}
0x00a032:	ldr     	r4, [pc, #0xf8]
0x00a034:	movs    	r7, #0xf1
0x00a036:	add     	r4, sb
0x00a038:	ldr     	r5, [r4, #0x44]
0x00a03a:	lsls    	r7, r7, #9
0x00a03c:	movs    	r6, #0
0x00a03e:	cmp     	r5, #0
0x00a040:	sub     	sp, #0xc
0x00a042:	beq     	#0xa05e
0x00a044:	movs    	r1, #0
0x00a046:	str     	r1, [sp]
0x00a048:	str     	r1, [sp, #4]
0x00a04a:	movs    	r2, #0
0x00a04c:	str     	r2, [sp, #8]
0x00a04e:	movs    	r1, #0xff
0x00a050:	adds    	r1, #0xc
0x00a052:	adds    	r2, r5, #0
0x00a054:	adds    	r3, r6, #0
0x00a056:	adds    	r0, r7, #0
0x00a058:	bl      	#0x9124
0x00a05c:	str     	r6, [r4, #0x44]
0x00a05e:	ldr     	r5, [pc, #0xcc]
0x00a060:	add     	r5, sb
0x00a062:	subs    	r5, #0x80
0x00a064:	ldr     	r3, [r5, #4]
0x00a066:	cmp     	r3, #0
0x00a068:	beq     	#0xa082
0x00a06a:	movs    	r1, #0
0x00a06c:	movs    	r2, #0
0x00a06e:	str     	r2, [sp, #8]
0x00a070:	str     	r1, [sp]
0x00a072:	str     	r1, [sp, #4]
0x00a074:	movs    	r1, #0x12
0x00a076:	adds    	r2, r3, #0
0x00a078:	adds    	r0, r7, #0
0x00a07a:	adds    	r3, r6, #0
0x00a07c:	bl      	#0x9124
0x00a080:	str     	r6, [r5, #4]
0x00a082:	ldr     	r5, [r4, #0x48]
0x00a084:	cmp     	r5, #0
0x00a086:	beq     	#0xa114
0x00a088:	movs    	r1, #0
0x00a08a:	movs    	r2, #0
0x00a08c:	str     	r2, [sp, #8]
0x00a08e:	str     	r1, [sp]
0x00a090:	str     	r1, [sp, #4]
0x00a092:	movs    	r1, #0x26
0x00a094:	adds    	r2, r5, #0
0x00a096:	adds    	r3, r6, #0
0x00a098:	adds    	r0, r7, #0
0x00a09a:	bl      	#0x9124
0x00a09e:	adds    	r5, r0, #0
0x00a0a0:	movs    	r4, #0
0x00a0a2:	cmp     	r0, #0
0x00a0a4:	ble     	#0xa0e0
0x00a0a6:	movs    	r1, #0
0x00a0a8:	ldr     	r0, [pc, #0x80]
0x00a0aa:	str     	r1, [sp]
0x00a0ac:	str     	r1, [sp, #4]
0x00a0ae:	movs    	r2, #0
0x00a0b0:	str     	r2, [sp, #8]
0x00a0b2:	add     	r0, sb
0x00a0b4:	ldr     	r2, [r0, #0x48]
0x00a0b6:	movs    	r1, #0x27
0x00a0b8:	adds    	r3, r4, #0
0x00a0ba:	adds    	r0, r7, #0
0x00a0bc:	bl      	#0x9124
0x00a0c0:	movs    	r2, #0
0x00a0c2:	movs    	r1, #0
0x00a0c4:	str     	r2, [sp, #8]
0x00a0c6:	adds    	r2, r0, #0
0x00a0c8:	str     	r1, [sp]
0x00a0ca:	str     	r1, [sp, #4]
0x00a0cc:	movs    	r1, #0xff
0x00a0ce:	movs    	r0, #0xf1
0x00a0d0:	lsls    	r0, r0, #9
0x00a0d2:	adds    	r1, #0xc
0x00a0d4:	adds    	r3, r6, #0
0x00a0d6:	bl      	#0x9124
0x00a0da:	adds    	r4, #1
0x00a0dc:	cmp     	r4, r5
0x00a0de:	blt     	#0xa0a6
0x00a0e0:	movs    	r1, #0
0x00a0e2:	str     	r1, [sp]
0x00a0e4:	str     	r1, [sp, #4]
0x00a0e6:	movs    	r2, #0
0x00a0e8:	ldr     	r4, [pc, #0x40]
0x00a0ea:	str     	r2, [sp, #8]
0x00a0ec:	movs    	r1, #0x28
0x00a0ee:	adds    	r3, r6, #0
0x00a0f0:	add     	r4, sb
0x00a0f2:	ldr     	r2, [r4, #0x48]
0x00a0f4:	adds    	r0, r7, #0
0x00a0f6:	bl      	#0x9124
0x00a0fa:	movs    	r1, #0
0x00a0fc:	str     	r1, [sp]
0x00a0fe:	str     	r1, [sp, #4]
0x00a100:	movs    	r2, #0
0x00a102:	str     	r2, [sp, #8]
0x00a104:	movs    	r1, #9
0x00a106:	adds    	r3, r6, #0
0x00a108:	movs    	r0, #0xf1
0x00a10a:	lsls    	r0, r0, #9
0x00a10c:	ldr     	r2, [r4, #0x48]
0x00a10e:	bl      	#0x9124
0x00a112:	str     	r6, [r4, #0x48]
0x00a114:	movs    	r1, #0
0x00a116:	str     	r1, [sp]
0x00a118:	str     	r1, [sp, #4]
0x00a11a:	movs    	r2, #0
0x00a11c:	movs    	r1, #0x2c
0x00a11e:	adds    	r3, r6, #0
0x00a120:	adds    	r0, r7, #0
0x00a122:	str     	r2, [sp, #8]
0x00a124:	bl      	#0x9124
0x00a128:	add     	sp, #0xc
0x00a12a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a130 =====
0x00a130:	push    	{r4, r5, r6, r7, lr}
0x00a132:	ldr     	r5, [pc, #0x90]
0x00a134:	sub     	sp, #0xc
0x00a136:	add     	r5, sb
0x00a138:	ldr     	r4, [r5, #0x1c]
0x00a13a:	cmp     	r4, #0
0x00a13c:	beq     	#0xa1be
0x00a13e:	movs    	r1, #0
0x00a140:	movs    	r2, #0
0x00a142:	str     	r2, [sp, #8]
0x00a144:	str     	r1, [sp]
0x00a146:	str     	r1, [sp, #4]
0x00a148:	movs    	r1, #0x11
0x00a14a:	adds    	r2, r4, #0
0x00a14c:	movs    	r3, #4
0x00a14e:	movs    	r0, #0xf1
0x00a150:	lsls    	r0, r0, #9
0x00a152:	bl      	#0x9124
0x00a156:	adds    	r6, r0, #0
0x00a158:	movs    	r4, #0
0x00a15a:	movs    	r7, #0
0x00a15c:	cmp     	r0, #0
0x00a15e:	ble     	#0xa1a0
0x00a160:	ldr     	r1, [pc, #0x60]
0x00a162:	lsls    	r0, r4, #2
0x00a164:	add     	r1, sb
0x00a166:	ldr     	r1, [r1, #0x1c]
0x00a168:	movs    	r2, #0
0x00a16a:	ldr     	r5, [r1, r0]
0x00a16c:	movs    	r1, #0
0x00a16e:	str     	r1, [sp]
0x00a170:	str     	r1, [sp, #4]
0x00a172:	movs    	r1, #9
0x00a174:	str     	r2, [sp, #8]
0x00a176:	movs    	r0, #0xf1
0x00a178:	adds    	r3, r7, #0
0x00a17a:	lsls    	r0, r0, #9
0x00a17c:	ldr     	r2, [r5, #8]
0x00a17e:	bl      	#0x9124
0x00a182:	movs    	r1, #0
0x00a184:	movs    	r2, #0
0x00a186:	str     	r2, [sp, #8]
0x00a188:	str     	r1, [sp]
0x00a18a:	str     	r1, [sp, #4]
0x00a18c:	adds    	r3, r7, #0
0x00a18e:	adds    	r2, r5, #0
0x00a190:	movs    	r1, #9
0x00a192:	movs    	r0, #0xf1
0x00a194:	lsls    	r0, r0, #9
0x00a196:	bl      	#0x9124
0x00a19a:	adds    	r4, #1
0x00a19c:	cmp     	r4, r6
0x00a19e:	blt     	#0xa160
0x00a1a0:	movs    	r1, #0
0x00a1a2:	str     	r1, [sp]
0x00a1a4:	str     	r1, [sp, #4]
0x00a1a6:	movs    	r2, #0
0x00a1a8:	ldr     	r4, [pc, #0x18]
0x00a1aa:	str     	r2, [sp, #8]
0x00a1ac:	movs    	r1, #9
0x00a1ae:	adds    	r3, r7, #0
0x00a1b0:	movs    	r0, #0xf1
0x00a1b2:	add     	r4, sb
0x00a1b4:	ldr     	r2, [r4, #0x1c]
0x00a1b6:	lsls    	r0, r0, #9
0x00a1b8:	bl      	#0x9124
0x00a1bc:	str     	r7, [r4, #0x1c]
0x00a1be:	add     	sp, #0xc
0x00a1c0:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a1c8 =====
0x00a1c8:	push    	{r4, r5, r6, r7, lr}
0x00a1ca:	sub     	sp, #0x14
0x00a1cc:	movs    	r1, #0
0x00a1ce:	movs    	r4, #0xff
0x00a1d0:	movs    	r2, #0
0x00a1d2:	str     	r2, [sp, #8]
0x00a1d4:	adds    	r4, #0x14
0x00a1d6:	str     	r1, [sp]
0x00a1d8:	str     	r1, [sp, #4]
0x00a1da:	movs    	r7, #0xf1
0x00a1dc:	movs    	r6, #0
0x00a1de:	adds    	r3, r6, #0
0x00a1e0:	lsls    	r7, r7, #9
0x00a1e2:	movs    	r1, #0xe1
0x00a1e4:	adds    	r2, r4, #0
0x00a1e6:	adds    	r0, r7, #0
0x00a1e8:	bl      	#0x9124
0x00a1ec:	cmp     	r0, #0
0x00a1ee:	beq     	#0xa2d4
0x00a1f0:	movs    	r1, #0
0x00a1f2:	movs    	r2, #0
0x00a1f4:	str     	r2, [sp, #8]
0x00a1f6:	str     	r1, [sp]
0x00a1f8:	str     	r1, [sp, #4]
0x00a1fa:	movs    	r1, #0xe1
0x00a1fc:	adds    	r2, r4, #0
0x00a1fe:	adds    	r3, r6, #0
0x00a200:	adds    	r0, r7, #0
0x00a202:	bl      	#0x9124
0x00a206:	movs    	r1, #0
0x00a208:	movs    	r2, #0
0x00a20a:	str     	r2, [sp, #8]
0x00a20c:	str     	r1, [sp]
0x00a20e:	str     	r1, [sp, #4]
0x00a210:	movs    	r1, #0x11
0x00a212:	adds    	r2, r0, #0
0x00a214:	movs    	r3, #4
0x00a216:	adds    	r0, r7, #0
0x00a218:	bl      	#0x9124
0x00a21c:	movs    	r4, #0
0x00a21e:	cmp     	r0, #0
0x00a220:	str     	r0, [sp, #0x10]
0x00a222:	ble     	#0xa296
0x00a224:	movs    	r2, #0
0x00a226:	movs    	r1, #0
0x00a228:	str     	r2, [sp, #8]
0x00a22a:	movs    	r2, #0xff
0x00a22c:	str     	r1, [sp]
0x00a22e:	str     	r1, [sp, #4]
0x00a230:	movs    	r1, #0xe1
0x00a232:	adds    	r2, #0x14
0x00a234:	adds    	r3, r6, #0
0x00a236:	adds    	r0, r7, #0
0x00a238:	bl      	#0x9124
0x00a23c:	lsls    	r1, r4, #2
0x00a23e:	ldr     	r5, [r0, r1]
0x00a240:	ldr     	r3, [r5, #4]
0x00a242:	cmp     	r3, #0
0x00a244:	beq     	#0xa25c
0x00a246:	movs    	r2, #0
0x00a248:	movs    	r1, #0
0x00a24a:	str     	r2, [sp, #8]
0x00a24c:	adds    	r2, r3, #0
0x00a24e:	str     	r1, [sp]
0x00a250:	str     	r1, [sp, #4]
0x00a252:	movs    	r1, #9
0x00a254:	adds    	r3, r6, #0
0x00a256:	adds    	r0, r7, #0
0x00a258:	bl      	#0x9124
0x00a25c:	ldr     	r3, [r5, #0x24]
0x00a25e:	cmp     	r3, #0
0x00a260:	beq     	#0xa278
0x00a262:	movs    	r2, #0
0x00a264:	movs    	r1, #0
0x00a266:	str     	r2, [sp, #8]
0x00a268:	adds    	r2, r3, #0
0x00a26a:	str     	r1, [sp]
0x00a26c:	str     	r1, [sp, #4]
0x00a26e:	movs    	r1, #9
0x00a270:	adds    	r3, r6, #0
0x00a272:	adds    	r0, r7, #0
0x00a274:	bl      	#0x9124
0x00a278:	movs    	r1, #0
0x00a27a:	movs    	r2, #0
0x00a27c:	str     	r2, [sp, #8]
0x00a27e:	str     	r1, [sp]
0x00a280:	str     	r1, [sp, #4]
0x00a282:	movs    	r1, #9
0x00a284:	adds    	r2, r5, #0
0x00a286:	adds    	r3, r6, #0
0x00a288:	adds    	r0, r7, #0
0x00a28a:	bl      	#0x9124
0x00a28e:	ldr     	r0, [sp, #0x10]
0x00a290:	adds    	r4, #1
0x00a292:	cmp     	r4, r0
0x00a294:	blt     	#0xa224
0x00a296:	movs    	r2, #0
0x00a298:	movs    	r1, #0
0x00a29a:	str     	r2, [sp, #8]
0x00a29c:	movs    	r2, #0xff
0x00a29e:	str     	r1, [sp]
0x00a2a0:	str     	r1, [sp, #4]
0x00a2a2:	movs    	r1, #0xe1
0x00a2a4:	adds    	r2, #0x14
0x00a2a6:	adds    	r3, r6, #0
0x00a2a8:	adds    	r0, r7, #0
0x00a2aa:	bl      	#0x9124
0x00a2ae:	movs    	r2, #0
0x00a2b0:	movs    	r1, #0
0x00a2b2:	str     	r2, [sp, #8]
0x00a2b4:	adds    	r3, r6, #0
0x00a2b6:	adds    	r2, r0, #0
0x00a2b8:	str     	r1, [sp]
0x00a2ba:	str     	r1, [sp, #4]
0x00a2bc:	movs    	r1, #9
0x00a2be:	movs    	r0, #0xf1
0x00a2c0:	lsls    	r0, r0, #9
0x00a2c2:	bl      	#0x9124
0x00a2c6:	movs    	r1, #0
0x00a2c8:	movs    	r2, #0
0x00a2ca:	str     	r2, [sp, #8]
0x00a2cc:	adds    	r3, r6, #0
0x00a2ce:	str     	r1, [sp]
0x00a2d0:	str     	r1, [sp, #4]
0x00a2d2:	b       	#0xa2d6
0x00a2d4:	b       	#0xa2e4
0x00a2d6:	movs    	r2, #0xff
0x00a2d8:	adds    	r2, #0x14
0x00a2da:	movs    	r1, #0x14
0x00a2dc:	movs    	r0, #0xf1
0x00a2de:	lsls    	r0, r0, #9
0x00a2e0:	bl      	#0x9124
0x00a2e4:	add     	sp, #0x14
0x00a2e6:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a2e8 =====
0x00a2e8:	push    	{r4, r5, lr}
0x00a2ea:	ldr     	r4, [pc, #0x38]
0x00a2ec:	movs    	r5, #0
0x00a2ee:	add     	r4, sb
0x00a2f0:	ldr     	r0, [r4, #0xc]
0x00a2f2:	sub     	sp, #0xc
0x00a2f4:	cmp     	r0, #0
0x00a2f6:	beq     	#0xa2fe
0x00a2f8:	bl      	#0x9f24
0x00a2fc:	str     	r5, [r4, #0xc]
0x00a2fe:	ldr     	r0, [r4, #0x18]
0x00a300:	cmp     	r0, #0
0x00a302:	beq     	#0xa30a
0x00a304:	bl      	#0x9f24
0x00a308:	str     	r5, [r4, #0x18]
0x00a30a:	movs    	r1, #0
0x00a30c:	str     	r1, [sp]
0x00a30e:	str     	r1, [sp, #4]
0x00a310:	movs    	r2, #0
0x00a312:	movs    	r1, #0x2c
0x00a314:	adds    	r3, r5, #0
0x00a316:	movs    	r0, #0xf1
0x00a318:	lsls    	r0, r0, #9
0x00a31a:	str     	r2, [sp, #8]
0x00a31c:	bl      	#0x9124
0x00a320:	add     	sp, #0xc
0x00a322:	pop     	{r4, r5, pc}

; ===== candidate_00a328 =====
0x00a328:	push    	{r4, r5, r6, r7, lr}
0x00a32a:	ldr     	r0, [pc, #0xb8]
0x00a32c:	movs    	r7, #0
0x00a32e:	add     	r0, sb
0x00a330:	ldr     	r4, [r0, #0x30]
0x00a332:	sub     	sp, #0xc
0x00a334:	cmp     	r4, #0
0x00a336:	beq     	#0xa3d8
0x00a338:	movs    	r1, #0
0x00a33a:	movs    	r2, #0
0x00a33c:	str     	r2, [sp, #8]
0x00a33e:	str     	r1, [sp]
0x00a340:	str     	r1, [sp, #4]
0x00a342:	movs    	r1, #0x11
0x00a344:	adds    	r2, r4, #0
0x00a346:	movs    	r3, #4
0x00a348:	movs    	r0, #0xf1
0x00a34a:	lsls    	r0, r0, #9
0x00a34c:	bl      	#0x9124
0x00a350:	adds    	r6, r0, #0
0x00a352:	movs    	r4, #0
0x00a354:	cmp     	r0, #0
0x00a356:	ble     	#0xa3bc
0x00a358:	ldr     	r1, [pc, #0x88]
0x00a35a:	lsls    	r0, r4, #2
0x00a35c:	add     	r1, sb
0x00a35e:	ldr     	r1, [r1, #0x30]
0x00a360:	ldr     	r5, [r1, r0]
0x00a362:	ldr     	r3, [r5]
0x00a364:	cmp     	r3, #0
0x00a366:	beq     	#0xa380
0x00a368:	movs    	r2, #0
0x00a36a:	movs    	r1, #0
0x00a36c:	str     	r2, [sp, #8]
0x00a36e:	adds    	r2, r3, #0
0x00a370:	str     	r1, [sp]
0x00a372:	str     	r1, [sp, #4]
0x00a374:	movs    	r1, #9
0x00a376:	adds    	r3, r7, #0
0x00a378:	movs    	r0, #0xf1
0x00a37a:	lsls    	r0, r0, #9
0x00a37c:	bl      	#0x9124
0x00a380:	ldr     	r3, [r5, #4]
0x00a382:	cmp     	r3, #0
0x00a384:	beq     	#0xa39e
0x00a386:	movs    	r2, #0
0x00a388:	movs    	r1, #0
0x00a38a:	str     	r2, [sp, #8]
0x00a38c:	adds    	r2, r3, #0
0x00a38e:	str     	r1, [sp]
0x00a390:	str     	r1, [sp, #4]
0x00a392:	movs    	r1, #0x12
0x00a394:	adds    	r3, r7, #0
0x00a396:	movs    	r0, #0xf1
0x00a398:	lsls    	r0, r0, #9
0x00a39a:	bl      	#0x9124
0x00a39e:	movs    	r1, #0
0x00a3a0:	movs    	r2, #0
0x00a3a2:	str     	r2, [sp, #8]
0x00a3a4:	str     	r1, [sp]
0x00a3a6:	str     	r1, [sp, #4]
0x00a3a8:	adds    	r3, r7, #0
0x00a3aa:	adds    	r2, r5, #0
0x00a3ac:	movs    	r1, #9
0x00a3ae:	movs    	r0, #0xf1
0x00a3b0:	lsls    	r0, r0, #9
0x00a3b2:	bl      	#0x9124
0x00a3b6:	adds    	r4, #1
0x00a3b8:	cmp     	r4, r6
0x00a3ba:	blt     	#0xa358
0x00a3bc:	movs    	r1, #0
0x00a3be:	ldr     	r0, [pc, #0x24]
0x00a3c0:	str     	r1, [sp]
0x00a3c2:	str     	r1, [sp, #4]
0x00a3c4:	movs    	r2, #0
0x00a3c6:	str     	r2, [sp, #8]
0x00a3c8:	add     	r0, sb
0x00a3ca:	ldr     	r2, [r0, #0x30]
0x00a3cc:	movs    	r0, #0xf1
0x00a3ce:	movs    	r1, #9
0x00a3d0:	adds    	r3, r7, #0
0x00a3d2:	lsls    	r0, r0, #9
0x00a3d4:	bl      	#0x9124
0x00a3d8:	ldr     	r0, [pc, #8]
0x00a3da:	add     	r0, sb
0x00a3dc:	str     	r7, [r0, #0x30]
0x00a3de:	add     	sp, #0xc
0x00a3e0:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a3e8 =====
0x00a3e8:	push    	{r4, r5, r6, r7, lr}
0x00a3ea:	sub     	sp, #0xc
0x00a3ec:	movs    	r1, #0
0x00a3ee:	str     	r1, [sp]
0x00a3f0:	str     	r1, [sp, #4]
0x00a3f2:	ldr     	r6, [pc, #0x64]
0x00a3f4:	movs    	r2, #0
0x00a3f6:	movs    	r7, #0xf1
0x00a3f8:	lsls    	r7, r7, #9
0x00a3fa:	str     	r2, [sp, #8]
0x00a3fc:	movs    	r1, #0x11
0x00a3fe:	movs    	r3, #4
0x00a400:	add     	r6, sb
0x00a402:	ldr     	r2, [r6, #8]
0x00a404:	adds    	r0, r7, #0
0x00a406:	bl      	#0x9124
0x00a40a:	adds    	r5, r0, #0
0x00a40c:	movs    	r4, #0
0x00a40e:	cmp     	r0, #0
0x00a410:	ble     	#0xa422
0x00a412:	ldr     	r1, [r6, #8]
0x00a414:	lsls    	r0, r4, #2
0x00a416:	ldr     	r0, [r1, r0]
0x00a418:	bl      	#0x9f24
0x00a41c:	adds    	r4, #1
0x00a41e:	cmp     	r4, r5
0x00a420:	blt     	#0xa412
0x00a422:	movs    	r1, #0
0x00a424:	str     	r1, [sp]
0x00a426:	str     	r1, [sp, #4]
0x00a428:	movs    	r2, #0
0x00a42a:	movs    	r4, #0
0x00a42c:	adds    	r3, r4, #0
0x00a42e:	str     	r2, [sp, #8]
0x00a430:	movs    	r1, #9
0x00a432:	adds    	r0, r7, #0
0x00a434:	ldr     	r2, [r6, #8]
0x00a436:	bl      	#0x9124
0x00a43a:	str     	r4, [r6, #8]
0x00a43c:	movs    	r1, #0
0x00a43e:	str     	r1, [sp]
0x00a440:	str     	r1, [sp, #4]
0x00a442:	movs    	r2, #0
0x00a444:	movs    	r1, #0x2c
0x00a446:	adds    	r3, r4, #0
0x00a448:	movs    	r0, #0xf1
0x00a44a:	lsls    	r0, r0, #9
0x00a44c:	str     	r2, [sp, #8]
0x00a44e:	bl      	#0x9124
0x00a452:	add     	sp, #0xc
0x00a454:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a45c =====
0x00a45c:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x00a45e:	sub     	sp, #0xc
0x00a460:	movs    	r1, #0
0x00a462:	movs    	r4, #0
0x00a464:	movs    	r2, #0
0x00a466:	str     	r2, [sp, #8]
0x00a468:	adds    	r3, r4, #0
0x00a46a:	str     	r1, [sp]
0x00a46c:	str     	r1, [sp, #4]
0x00a46e:	movs    	r5, #0x1a
0x00a470:	adds    	r2, r5, #0
0x00a472:	movs    	r1, #0x17
0x00a474:	movs    	r0, #0xf1
0x00a476:	lsls    	r0, r0, #9
0x00a478:	bl      	#0x9124
0x00a47c:	movs    	r1, #0
0x00a47e:	movs    	r2, #0
0x00a480:	str     	r2, [sp, #8]
0x00a482:	str     	r1, [sp]
0x00a484:	str     	r1, [sp, #4]
0x00a486:	movs    	r1, #0xe1
0x00a488:	movs    	r2, #0x1d
0x00a48a:	adds    	r3, r4, #0
0x00a48c:	movs    	r0, #0xf1
0x00a48e:	lsls    	r0, r0, #9
0x00a490:	bl      	#0x9124
0x00a494:	movs    	r1, #0
0x00a496:	adds    	r6, r0, #0
0x00a498:	movs    	r2, #0
0x00a49a:	str     	r2, [sp, #8]
0x00a49c:	str     	r1, [sp]
0x00a49e:	str     	r1, [sp, #4]
0x00a4a0:	movs    	r1, #0xe1
0x00a4a2:	movs    	r2, #0x18
0x00a4a4:	movs    	r0, #0xf1
0x00a4a6:	adds    	r3, r4, #0
0x00a4a8:	lsls    	r0, r0, #9
0x00a4aa:	bl      	#0x9124
0x00a4ae:	ldr     	r7, [r0, #0xc]
0x00a4b0:	movs    	r1, #0
0x00a4b2:	movs    	r2, #0
0x00a4b4:	str     	r2, [sp, #8]
0x00a4b6:	str     	r1, [sp]
0x00a4b8:	str     	r1, [sp, #4]
0x00a4ba:	movs    	r1, #0xe1
0x00a4bc:	movs    	r2, #0x18
0x00a4be:	movs    	r0, #0xf1
0x00a4c0:	adds    	r3, r4, #0
0x00a4c2:	lsls    	r0, r0, #9
0x00a4c4:	bl      	#0x9124
0x00a4c8:	ldr     	r3, [r0, #8]
0x00a4ca:	movs    	r2, #0
0x00a4cc:	str     	r2, [sp, #8]
0x00a4ce:	adds    	r2, r5, #0
0x00a4d0:	movs    	r0, #0xf1
0x00a4d2:	movs    	r1, #0x52
0x00a4d4:	lsls    	r0, r0, #9
0x00a4d6:	str     	r7, [sp]
0x00a4d8:	str     	r6, [sp, #4]
0x00a4da:	bl      	#0x9124
0x00a4de:	movs    	r1, #0
0x00a4e0:	movs    	r2, #0
0x00a4e2:	str     	r1, [sp]
0x00a4e4:	str     	r1, [sp, #4]
0x00a4e6:	movs    	r1, #0x19
0x00a4e8:	str     	r2, [sp, #8]
0x00a4ea:	adds    	r3, r4, #0
0x00a4ec:	movs    	r0, #0xf1
0x00a4ee:	lsls    	r0, r0, #9
0x00a4f0:	ldr     	r2, [sp, #0xc]
0x00a4f2:	bl      	#0x9124
0x00a4f6:	movs    	r1, #0
0x00a4f8:	movs    	r2, #0
0x00a4fa:	str     	r1, [sp]
0x00a4fc:	str     	r1, [sp, #4]
0x00a4fe:	movs    	r1, #0x19
0x00a500:	str     	r2, [sp, #8]
0x00a502:	adds    	r3, r4, #0
0x00a504:	movs    	r0, #0xf1
0x00a506:	lsls    	r0, r0, #9
0x00a508:	ldr     	r2, [sp, #0x10]
0x00a50a:	bl      	#0x9124
0x00a50e:	movs    	r2, #0
0x00a510:	movs    	r1, #0
0x00a512:	ldr     	r3, [pc, #0x18]
0x00a514:	str     	r1, [sp]
0x00a516:	str     	r1, [sp, #4]
0x00a518:	str     	r2, [sp, #8]
0x00a51a:	add     	r3, pc
0x00a51c:	movs    	r2, #1
0x00a51e:	movs    	r1, #0x1b
0x00a520:	movs    	r0, #0xf1
0x00a522:	lsls    	r0, r0, #9
0x00a524:	bl      	#0x9124
0x00a528:	add     	sp, #0x14
0x00a52a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a530 =====
0x00a530:	push    	{r0, r4, r5, r6, r7, lr}
0x00a532:	sub     	sp, #0x10
0x00a534:	movs    	r1, #0
0x00a536:	movs    	r4, #0
0x00a538:	movs    	r2, #0
0x00a53a:	str     	r2, [sp, #8]
0x00a53c:	adds    	r3, r4, #0
0x00a53e:	str     	r1, [sp]
0x00a540:	str     	r1, [sp, #4]
0x00a542:	movs    	r5, #0xb2
0x00a544:	adds    	r2, r5, #0
0x00a546:	movs    	r1, #0x17
0x00a548:	movs    	r0, #0xf1
0x00a54a:	lsls    	r0, r0, #9
0x00a54c:	bl      	#0x9124
0x00a550:	movs    	r1, #0
0x00a552:	movs    	r2, #0
0x00a554:	str     	r2, [sp, #8]
0x00a556:	str     	r1, [sp]
0x00a558:	str     	r1, [sp, #4]
0x00a55a:	movs    	r1, #0xe1
0x00a55c:	movs    	r2, #0x1d
0x00a55e:	adds    	r3, r4, #0
0x00a560:	movs    	r0, #0xf1
0x00a562:	lsls    	r0, r0, #9
0x00a564:	bl      	#0x9124
0x00a568:	movs    	r1, #0
0x00a56a:	adds    	r6, r0, #0
0x00a56c:	movs    	r2, #0
0x00a56e:	str     	r2, [sp, #8]
0x00a570:	str     	r1, [sp]
0x00a572:	str     	r1, [sp, #4]
0x00a574:	movs    	r1, #0xe1
0x00a576:	movs    	r2, #0x18
0x00a578:	movs    	r0, #0xf1
0x00a57a:	adds    	r3, r4, #0
0x00a57c:	lsls    	r0, r0, #9
0x00a57e:	bl      	#0x9124
0x00a582:	ldr     	r7, [r0, #0xc]
0x00a584:	movs    	r1, #0
0x00a586:	movs    	r2, #0
0x00a588:	str     	r2, [sp, #8]
0x00a58a:	str     	r1, [sp]
0x00a58c:	str     	r1, [sp, #4]
0x00a58e:	movs    	r1, #0xe1
0x00a590:	movs    	r2, #0x18
0x00a592:	movs    	r0, #0xf1
0x00a594:	adds    	r3, r4, #0
0x00a596:	lsls    	r0, r0, #9
0x00a598:	bl      	#0x9124
0x00a59c:	ldr     	r3, [r0, #8]
0x00a59e:	movs    	r2, #0
0x00a5a0:	str     	r2, [sp, #8]
0x00a5a2:	adds    	r2, r5, #0
0x00a5a4:	movs    	r0, #0xf1
0x00a5a6:	movs    	r1, #0x52
0x00a5a8:	lsls    	r0, r0, #9
0x00a5aa:	str     	r7, [sp]
0x00a5ac:	str     	r6, [sp, #4]
0x00a5ae:	bl      	#0x9124
0x00a5b2:	movs    	r1, #0
0x00a5b4:	movs    	r2, #0
0x00a5b6:	str     	r1, [sp]
0x00a5b8:	str     	r1, [sp, #4]
0x00a5ba:	movs    	r1, #0x19
0x00a5bc:	str     	r2, [sp, #8]
0x00a5be:	adds    	r3, r4, #0
0x00a5c0:	movs    	r0, #0xf1
0x00a5c2:	lsls    	r0, r0, #9
0x00a5c4:	ldr     	r2, [sp, #0x10]
0x00a5c6:	bl      	#0x9124
0x00a5ca:	movs    	r1, #0
0x00a5cc:	movs    	r2, #0
0x00a5ce:	str     	r2, [sp, #8]
0x00a5d0:	str     	r1, [sp]
0x00a5d2:	str     	r1, [sp, #4]
0x00a5d4:	movs    	r1, #0x1b
0x00a5d6:	movs    	r2, #1
0x00a5d8:	adds    	r3, r4, #0
0x00a5da:	movs    	r0, #0xf1
0x00a5dc:	lsls    	r0, r0, #9
0x00a5de:	bl      	#0x9124
0x00a5e2:	add     	sp, #0x14
0x00a5e4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a5e8 =====
0x00a5e8:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x00a5ea:	sub     	sp, #0xc
0x00a5ec:	movs    	r1, #0
0x00a5ee:	movs    	r5, #0xff
0x00a5f0:	movs    	r4, #0
0x00a5f2:	movs    	r2, #0
0x00a5f4:	str     	r2, [sp, #8]
0x00a5f6:	adds    	r3, r4, #0
0x00a5f8:	adds    	r5, #0x5c
0x00a5fa:	str     	r1, [sp]
0x00a5fc:	str     	r1, [sp, #4]
0x00a5fe:	movs    	r1, #0x17
0x00a600:	adds    	r2, r5, #0
0x00a602:	movs    	r0, #0xf1
0x00a604:	lsls    	r0, r0, #9
0x00a606:	bl      	#0x9124
0x00a60a:	movs    	r1, #0
0x00a60c:	movs    	r2, #0
0x00a60e:	str     	r2, [sp, #8]
0x00a610:	str     	r1, [sp]
0x00a612:	str     	r1, [sp, #4]
0x00a614:	movs    	r1, #0xe1
0x00a616:	movs    	r2, #0x1d
0x00a618:	adds    	r3, r4, #0
0x00a61a:	movs    	r0, #0xf1
0x00a61c:	lsls    	r0, r0, #9
0x00a61e:	bl      	#0x9124
0x00a622:	movs    	r1, #0
0x00a624:	adds    	r6, r0, #0
0x00a626:	movs    	r2, #0
0x00a628:	str     	r2, [sp, #8]
0x00a62a:	str     	r1, [sp]
0x00a62c:	str     	r1, [sp, #4]
0x00a62e:	movs    	r1, #0xe1
0x00a630:	movs    	r2, #0x18
0x00a632:	movs    	r0, #0xf1
0x00a634:	adds    	r3, r4, #0
0x00a636:	lsls    	r0, r0, #9
0x00a638:	bl      	#0x9124
0x00a63c:	ldr     	r7, [r0, #0xc]
0x00a63e:	movs    	r1, #0
0x00a640:	movs    	r2, #0
0x00a642:	str     	r2, [sp, #8]
0x00a644:	str     	r1, [sp]
0x00a646:	str     	r1, [sp, #4]
0x00a648:	movs    	r1, #0xe1
0x00a64a:	movs    	r2, #0x18
0x00a64c:	movs    	r0, #0xf1
0x00a64e:	adds    	r3, r4, #0
0x00a650:	lsls    	r0, r0, #9
0x00a652:	bl      	#0x9124
0x00a656:	ldr     	r3, [r0, #8]
0x00a658:	movs    	r2, #0
0x00a65a:	str     	r2, [sp, #8]
0x00a65c:	adds    	r2, r5, #0
0x00a65e:	movs    	r0, #0xf1
0x00a660:	movs    	r1, #0x52
0x00a662:	lsls    	r0, r0, #9
0x00a664:	str     	r7, [sp]
0x00a666:	str     	r6, [sp, #4]
0x00a668:	bl      	#0x9124
0x00a66c:	movs    	r1, #0
0x00a66e:	movs    	r2, #0
0x00a670:	str     	r1, [sp]
0x00a672:	str     	r1, [sp, #4]
0x00a674:	movs    	r1, #0x19
0x00a676:	str     	r2, [sp, #8]
0x00a678:	adds    	r3, r4, #0
0x00a67a:	movs    	r0, #0xf1
0x00a67c:	lsls    	r0, r0, #9
0x00a67e:	ldr     	r2, [sp, #0xc]
0x00a680:	bl      	#0x9124
0x00a684:	movs    	r1, #0
0x00a686:	movs    	r2, #0
0x00a688:	str     	r1, [sp]
0x00a68a:	str     	r1, [sp, #4]
0x00a68c:	movs    	r1, #0x19
0x00a68e:	str     	r2, [sp, #8]
0x00a690:	adds    	r3, r4, #0
0x00a692:	movs    	r0, #0xf1
0x00a694:	lsls    	r0, r0, #9
0x00a696:	ldr     	r2, [sp, #0x10]
0x00a698:	bl      	#0x9124
0x00a69c:	movs    	r1, #0
0x00a69e:	movs    	r2, #0
0x00a6a0:	str     	r2, [sp, #8]
0x00a6a2:	str     	r1, [sp]
0x00a6a4:	str     	r1, [sp, #4]
0x00a6a6:	movs    	r1, #0x1b
0x00a6a8:	movs    	r2, #1
0x00a6aa:	adds    	r3, r4, #0
0x00a6ac:	movs    	r0, #0xf1
0x00a6ae:	lsls    	r0, r0, #9
0x00a6b0:	bl      	#0x9124
0x00a6b4:	add     	sp, #0x14
0x00a6b6:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a6b8 =====
0x00a6b8:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x00a6ba:	sub     	sp, #0x10
0x00a6bc:	movs    	r1, #0
0x00a6be:	movs    	r5, #0xff
0x00a6c0:	movs    	r2, #0
0x00a6c2:	movs    	r4, #0
0x00a6c4:	adds    	r3, r4, #0
0x00a6c6:	str     	r2, [sp, #8]
0x00a6c8:	adds    	r5, #0x5d
0x00a6ca:	str     	r1, [sp]
0x00a6cc:	str     	r1, [sp, #4]
0x00a6ce:	movs    	r1, #0x17
0x00a6d0:	adds    	r2, r5, #0
0x00a6d2:	movs    	r0, #0xf1
0x00a6d4:	lsls    	r0, r0, #9
0x00a6d6:	bl      	#0x9124
0x00a6da:	movs    	r1, #0
0x00a6dc:	movs    	r2, #0
0x00a6de:	str     	r2, [sp, #8]
0x00a6e0:	str     	r1, [sp]
0x00a6e2:	str     	r1, [sp, #4]
0x00a6e4:	movs    	r1, #0xe1
0x00a6e6:	movs    	r2, #0x1d
0x00a6e8:	adds    	r3, r4, #0
0x00a6ea:	movs    	r0, #0xf1
0x00a6ec:	lsls    	r0, r0, #9
0x00a6ee:	bl      	#0x9124
0x00a6f2:	movs    	r1, #0
0x00a6f4:	adds    	r6, r0, #0
0x00a6f6:	movs    	r2, #0
0x00a6f8:	str     	r2, [sp, #8]
0x00a6fa:	str     	r1, [sp]
0x00a6fc:	str     	r1, [sp, #4]
0x00a6fe:	movs    	r1, #0xe1
0x00a700:	movs    	r2, #0x18
0x00a702:	movs    	r0, #0xf1
0x00a704:	adds    	r3, r4, #0
0x00a706:	lsls    	r0, r0, #9
0x00a708:	bl      	#0x9124
0x00a70c:	ldr     	r7, [r0, #0xc]
0x00a70e:	movs    	r1, #0
0x00a710:	movs    	r2, #0
0x00a712:	str     	r2, [sp, #8]
0x00a714:	str     	r1, [sp]
0x00a716:	str     	r1, [sp, #4]
0x00a718:	movs    	r1, #0xe1
0x00a71a:	movs    	r2, #0x18
0x00a71c:	movs    	r0, #0xf1
0x00a71e:	adds    	r3, r4, #0
0x00a720:	lsls    	r0, r0, #9
0x00a722:	bl      	#0x9124
0x00a726:	ldr     	r3, [r0, #8]
0x00a728:	movs    	r2, #0
0x00a72a:	str     	r2, [sp, #8]
0x00a72c:	adds    	r2, r5, #0
0x00a72e:	movs    	r0, #0xf1
0x00a730:	movs    	r1, #0x52
0x00a732:	lsls    	r0, r0, #9
0x00a734:	str     	r7, [sp]
0x00a736:	str     	r6, [sp, #4]
0x00a738:	bl      	#0x9124
0x00a73c:	movs    	r1, #0
0x00a73e:	movs    	r2, #0
0x00a740:	str     	r1, [sp]
0x00a742:	str     	r1, [sp, #4]
0x00a744:	movs    	r1, #0x19
0x00a746:	str     	r2, [sp, #8]
0x00a748:	adds    	r3, r4, #0
0x00a74a:	movs    	r0, #0xf1
0x00a74c:	lsls    	r0, r0, #9
0x00a74e:	ldr     	r2, [sp, #0x10]
0x00a750:	bl      	#0x9124
0x00a754:	movs    	r1, #0
0x00a756:	movs    	r2, #0
0x00a758:	str     	r1, [sp]
0x00a75a:	str     	r1, [sp, #4]
0x00a75c:	movs    	r1, #0x19
0x00a75e:	str     	r2, [sp, #8]
0x00a760:	adds    	r3, r4, #0
0x00a762:	movs    	r0, #0xf1
0x00a764:	lsls    	r0, r0, #9
0x00a766:	ldr     	r2, [sp, #0x14]
0x00a768:	bl      	#0x9124
0x00a76c:	movs    	r1, #0
0x00a76e:	movs    	r2, #0
0x00a770:	str     	r1, [sp]
0x00a772:	str     	r1, [sp, #4]
0x00a774:	movs    	r1, #0x19
0x00a776:	str     	r2, [sp, #8]
0x00a778:	adds    	r3, r4, #0
0x00a77a:	movs    	r0, #0xf1
0x00a77c:	lsls    	r0, r0, #9
0x00a77e:	ldr     	r2, [sp, #0x18]
0x00a780:	bl      	#0x9124
0x00a784:	movs    	r1, #0
0x00a786:	movs    	r2, #0
0x00a788:	str     	r2, [sp, #8]
0x00a78a:	str     	r1, [sp]
0x00a78c:	str     	r1, [sp, #4]
0x00a78e:	movs    	r1, #0x1b
0x00a790:	movs    	r2, #1
0x00a792:	adds    	r3, r4, #0
0x00a794:	movs    	r0, #0xf1
0x00a796:	lsls    	r0, r0, #9
0x00a798:	bl      	#0x9124
0x00a79c:	add     	sp, #0x1c
0x00a79e:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a7a0 =====
0x00a7a0:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x00a7a2:	sub     	sp, #0x10
0x00a7a4:	movs    	r1, #0
0x00a7a6:	movs    	r2, #0
0x00a7a8:	str     	r2, [sp, #8]
0x00a7aa:	str     	r1, [sp]
0x00a7ac:	str     	r1, [sp, #4]
0x00a7ae:	movs    	r6, #0xf1
0x00a7b0:	movs    	r5, #0x69
0x00a7b2:	movs    	r4, #0
0x00a7b4:	adds    	r3, r4, #0
0x00a7b6:	adds    	r2, r5, #0
0x00a7b8:	lsls    	r6, r6, #9
0x00a7ba:	movs    	r1, #0x17
0x00a7bc:	adds    	r0, r6, #0
0x00a7be:	bl      	#0x9124
0x00a7c2:	movs    	r1, #0
0x00a7c4:	movs    	r2, #0
0x00a7c6:	str     	r2, [sp, #8]
0x00a7c8:	str     	r1, [sp]
0x00a7ca:	str     	r1, [sp, #4]
0x00a7cc:	movs    	r1, #0xe1
0x00a7ce:	movs    	r2, #0x1d
0x00a7d0:	adds    	r3, r4, #0
0x00a7d2:	adds    	r0, r6, #0
0x00a7d4:	bl      	#0x9124
0x00a7d8:	movs    	r1, #0
0x00a7da:	movs    	r2, #0
0x00a7dc:	str     	r2, [sp, #8]
0x00a7de:	str     	r1, [sp]
0x00a7e0:	str     	r1, [sp, #4]
0x00a7e2:	movs    	r1, #0xe1
0x00a7e4:	movs    	r2, #0x18
0x00a7e6:	str     	r0, [sp, #0xc]
0x00a7e8:	adds    	r3, r4, #0
0x00a7ea:	adds    	r0, r6, #0
0x00a7ec:	bl      	#0x9124
0x00a7f0:	ldr     	r7, [r0, #0xc]
0x00a7f2:	movs    	r1, #0
0x00a7f4:	movs    	r2, #0
0x00a7f6:	str     	r2, [sp, #8]
0x00a7f8:	str     	r1, [sp]
0x00a7fa:	str     	r1, [sp, #4]
0x00a7fc:	movs    	r1, #0xe1
0x00a7fe:	movs    	r2, #0x18
0x00a800:	adds    	r3, r4, #0
0x00a802:	adds    	r0, r6, #0
0x00a804:	bl      	#0x9124
0x00a808:	ldr     	r3, [r0, #8]
0x00a80a:	ldr     	r1, [sp, #0xc]
0x00a80c:	movs    	r2, #0
0x00a80e:	str     	r2, [sp, #8]
0x00a810:	str     	r1, [sp, #4]
0x00a812:	movs    	r1, #0x52
0x00a814:	adds    	r2, r5, #0
0x00a816:	adds    	r0, r6, #0
0x00a818:	str     	r7, [sp]
0x00a81a:	bl      	#0x9124
0x00a81e:	movs    	r1, #0
0x00a820:	movs    	r2, #0
0x00a822:	str     	r2, [sp, #8]
0x00a824:	str     	r1, [sp]
0x00a826:	str     	r1, [sp, #4]
0x00a828:	movs    	r1, #0xe1
0x00a82a:	movs    	r2, #0x3d
0x00a82c:	adds    	r3, r4, #0
0x00a82e:	adds    	r0, r6, #0
0x00a830:	bl      	#0x9124
0x00a834:	movs    	r1, #0
0x00a836:	movs    	r2, #0
0x00a838:	str     	r2, [sp, #8]
0x00a83a:	str     	r1, [sp]
0x00a83c:	str     	r1, [sp, #4]
0x00a83e:	movs    	r1, #0x19
0x00a840:	adds    	r2, r0, #0
0x00a842:	adds    	r3, r4, #0
0x00a844:	adds    	r0, r6, #0
0x00a846:	bl      	#0x9124
0x00a84a:	movs    	r1, #0
0x00a84c:	movs    	r2, #0
0x00a84e:	str     	r1, [sp]
0x00a850:	str     	r1, [sp, #4]
0x00a852:	movs    	r1, #0x19
0x00a854:	str     	r2, [sp, #8]
0x00a856:	adds    	r3, r4, #0
0x00a858:	adds    	r0, r6, #0
0x00a85a:	ldr     	r2, [sp, #0x10]
0x00a85c:	bl      	#0x9124
0x00a860:	movs    	r1, #0
0x00a862:	movs    	r2, #0
0x00a864:	str     	r1, [sp]
0x00a866:	str     	r1, [sp, #4]
0x00a868:	movs    	r1, #0x19
0x00a86a:	str     	r2, [sp, #8]
0x00a86c:	adds    	r3, r4, #0
0x00a86e:	adds    	r0, r6, #0
0x00a870:	ldr     	r2, [sp, #0x14]
0x00a872:	bl      	#0x9124
0x00a876:	movs    	r1, #0
0x00a878:	movs    	r2, #0
0x00a87a:	str     	r1, [sp]
0x00a87c:	str     	r1, [sp, #4]
0x00a87e:	movs    	r1, #0x19
0x00a880:	str     	r2, [sp, #8]
0x00a882:	adds    	r3, r4, #0
0x00a884:	adds    	r0, r6, #0
0x00a886:	ldr     	r2, [sp, #0x18]
0x00a888:	bl      	#0x9124
0x00a88c:	ldr     	r0, [pc, #0x4c]
0x00a88e:	add     	r0, sb
0x00a890:	ldr     	r0, [r0, #0x28]
0x00a892:	cmp     	r0, #0
0x00a894:	beq     	#0xa8ae
0x00a896:	movs    	r1, #0
0x00a898:	movs    	r2, #0
0x00a89a:	str     	r2, [sp, #8]
0x00a89c:	str     	r1, [sp]
0x00a89e:	str     	r1, [sp, #4]
0x00a8a0:	movs    	r1, #0x1a
0x00a8a2:	movs    	r2, #1
0x00a8a4:	adds    	r3, r4, #0
0x00a8a6:	adds    	r0, r6, #0
0x00a8a8:	bl      	#0x9124
0x00a8ac:	b       	#0xa8c2
0x00a8ae:	movs    	r1, #0
0x00a8b0:	str     	r1, [sp]
0x00a8b2:	str     	r1, [sp, #4]
0x00a8b4:	movs    	r2, #0
0x00a8b6:	movs    	r1, #0x1a
0x00a8b8:	adds    	r3, r4, #0
0x00a8ba:	adds    	r0, r6, #0
0x00a8bc:	str     	r2, [sp, #8]
0x00a8be:	bl      	#0x9124
0x00a8c2:	movs    	r1, #0
0x00a8c4:	movs    	r2, #0
0x00a8c6:	str     	r2, [sp, #8]
0x00a8c8:	str     	r1, [sp]
0x00a8ca:	str     	r1, [sp, #4]
0x00a8cc:	movs    	r1, #0x1b
0x00a8ce:	movs    	r2, #1
0x00a8d0:	adds    	r3, r4, #0

; ===== candidate_00a8e0 =====
0x00a8e0:	push    	{r4, r5, r6, r7, lr}
0x00a8e2:	ldr     	r4, [pc, #0x30]
0x00a8e4:	adds    	r6, r0, #0
0x00a8e6:	add     	r4, sb
0x00a8e8:	ldr     	r7, [r4, #0x78]
0x00a8ea:	movs    	r5, #0
0x00a8ec:	cmp     	r7, #0
0x00a8ee:	sub     	sp, #0xc
0x00a8f0:	beq     	#0xa90a
0x00a8f2:	movs    	r1, #0
0x00a8f4:	movs    	r2, #0
0x00a8f6:	str     	r2, [sp, #8]
0x00a8f8:	str     	r1, [sp]
0x00a8fa:	str     	r1, [sp, #4]
0x00a8fc:	adds    	r3, r5, #0
0x00a8fe:	adds    	r2, r7, #0
0x00a900:	movs    	r1, #9
0x00a902:	movs    	r0, #0xf1
0x00a904:	lsls    	r0, r0, #9
0x00a906:	bl      	#0x9124
0x00a90a:	str     	r5, [r4, #0x7c]
0x00a90c:	str     	r6, [r4, #0x78]
0x00a90e:	add     	sp, #0xc
0x00a910:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a918 =====
0x00a918:	push    	{r0, r4, r5, r6, r7, lr}
0x00a91a:	sub     	sp, #0x10
0x00a91c:	movs    	r2, #0
0x00a91e:	movs    	r1, #0
0x00a920:	str     	r2, [sp, #8]
0x00a922:	movs    	r2, #0xff
0x00a924:	str     	r1, [sp]
0x00a926:	str     	r1, [sp, #4]
0x00a928:	movs    	r4, #0xf1
0x00a92a:	movs    	r5, #0
0x00a92c:	adds    	r3, r5, #0
0x00a92e:	lsls    	r4, r4, #9
0x00a930:	movs    	r1, #0xe1
0x00a932:	adds    	r2, #0xc
0x00a934:	adds    	r0, r4, #0
0x00a936:	bl      	#0x9124
0x00a93a:	movs    	r1, #0
0x00a93c:	movs    	r2, #0
0x00a93e:	str     	r2, [sp, #8]
0x00a940:	str     	r1, [sp]
0x00a942:	str     	r1, [sp, #4]
0x00a944:	movs    	r1, #0x11
0x00a946:	adds    	r2, r0, #0
0x00a948:	movs    	r3, #4
0x00a94a:	adds    	r0, r4, #0
0x00a94c:	bl      	#0x9124
0x00a950:	ldr     	r7, [pc, #0x3a4]
0x00a952:	adds    	r6, r0, #2
0x00a954:	add     	r7, sb
0x00a956:	ldr     	r0, [r7, #0x70]
0x00a958:	cmp     	r0, #0
0x00a95a:	bne     	#0xa98e
0x00a95c:	movs    	r2, #0
0x00a95e:	movs    	r1, #0
0x00a960:	str     	r2, [sp, #8]
0x00a962:	movs    	r2, #0xff
0x00a964:	str     	r1, [sp]
0x00a966:	str     	r1, [sp, #4]
0x00a968:	movs    	r1, #0xe1
0x00a96a:	adds    	r2, #9
0x00a96c:	adds    	r3, r5, #0
0x00a96e:	adds    	r0, r4, #0
0x00a970:	bl      	#0x9124
0x00a974:	movs    	r2, #0
0x00a976:	movs    	r1, #0
0x00a978:	str     	r2, [sp, #8]
0x00a97a:	adds    	r2, r0, #0
0x00a97c:	str     	r1, [sp]
0x00a97e:	str     	r1, [sp, #4]
0x00a980:	movs    	r1, #0x26
0x00a982:	adds    	r0, r4, #0
0x00a984:	adds    	r3, r5, #0
0x00a986:	bl      	#0x9124
0x00a98a:	mov     	ip, r0
0x00a98c:	b       	#0xa9e0
0x00a98e:	subs    	r1, r6, #1
0x00a990:	cmp     	r1, r0
0x00a992:	bne     	#0xa9ae
0x00a994:	movs    	r1, #0
0x00a996:	str     	r1, [sp]
0x00a998:	str     	r1, [sp, #4]
0x00a99a:	movs    	r2, #0
0x00a99c:	str     	r2, [sp, #8]
0x00a99e:	movs    	r1, #0x11
0x00a9a0:	movs    	r3, #4
0x00a9a2:	adds    	r0, r4, #0
0x00a9a4:	ldr     	r2, [r7, #0x34]
0x00a9a6:	bl      	#0x9124
0x00a9aa:	mov     	ip, r0
0x00a9ac:	b       	#0xa9e0
0x00a9ae:	movs    	r2, #0
0x00a9b0:	movs    	r1, #0
0x00a9b2:	str     	r2, [sp, #8]
0x00a9b4:	movs    	r2, #0xff
0x00a9b6:	str     	r1, [sp]
0x00a9b8:	str     	r1, [sp, #4]
0x00a9ba:	movs    	r1, #0xe1
0x00a9bc:	adds    	r2, #0x14
0x00a9be:	adds    	r3, r5, #0
0x00a9c0:	adds    	r0, r4, #0
0x00a9c2:	bl      	#0x9124
0x00a9c6:	movs    	r2, #0
0x00a9c8:	movs    	r1, #0
0x00a9ca:	str     	r2, [sp, #8]
0x00a9cc:	adds    	r2, r0, #0
0x00a9ce:	str     	r1, [sp]
0x00a9d0:	str     	r1, [sp, #4]
0x00a9d2:	movs    	r1, #0x11
0x00a9d4:	movs    	r0, #0xf1
0x00a9d6:	movs    	r3, #4
0x00a9d8:	lsls    	r0, r0, #9
0x00a9da:	bl      	#0x9124
0x00a9de:	mov     	ip, r0
0x00a9e0:	ldr     	r0, [sp, #0x10]
0x00a9e2:	subs    	r0, #2
0x00a9e4:	cmp     	r0, #0x13
0x00a9e6:	bhs     	#0xa9f2
0x00a9e8:	adr     	r3, #0xc
0x00a9ea:	adds    	r3, r3, r0
0x00a9ec:	ldrh    	r3, [r3, r0]
0x00a9ee:	lsls    	r3, r3, #1
0x00a9f0:	add     	pc, r3
0x00a9f2:	add     	sp, #0x14
0x00a9f4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00ad3a =====
0x00ad3a:	push    	{r3, r4, r5, r7}

; ===== candidate_00ada6 =====
0x00ada6:	push    	{r0, r1, r2, r3, r4, r5, r7}
0x00ada8:	udf     	#0xc0
0x00adaa:	add     	r0, sp, #0x330
0x00adac:	movs    	r7, r6
0x00adae:	movs    	r0, r0
0x00adb0:	movs    	r7, r5
0x00adb2:	movs    	r0, r0
0x00adb4:	bhs     	#0xad54
0x00adb6:	movs    	r0, r0
0x00adb8:	adr     	r6, #0x328
0x00adba:	pop     	{r0, r2, r3, r6, r7, pc}

; ===== candidate_00adbe =====
0x00adbe:	push    	{r0, r1, r2, r3, r6, r7, lr}
0x00adc0:	movs    	r0, r0
0x00adc2:	movs    	r0, r0
0x00adc4:	ble     	#0xad70
0x00adc6:	udf     	#0xce
0x00adc8:	adr     	r6, #0x328
0x00adca:	push    	{r3, r4, r5, r7, lr}
0x00adcc:	movs    	r0, r0
0x00adce:	movs    	r0, r0
0x00add0:	adr     	r6, #0x328
0x00add2:	push    	{r3, r4, r5, r7, lr}
0x00add4:	movs    	r0, r0
0x00add6:	movs    	r0, r0
0x00add8:	pop     	{r0, r2, r3, r6, r7, pc}

; ===== candidate_00adca =====
0x00adca:	push    	{r3, r4, r5, r7, lr}
0x00adcc:	movs    	r0, r0
0x00adce:	movs    	r0, r0
0x00add0:	adr     	r6, #0x328
0x00add2:	push    	{r3, r4, r5, r7, lr}
0x00add4:	movs    	r0, r0
0x00add6:	movs    	r0, r0
0x00add8:	pop     	{r0, r2, r3, r6, r7, pc}

; ===== candidate_00add2 =====
0x00add2:	push    	{r3, r4, r5, r7, lr}
0x00add4:	movs    	r0, r0
0x00add6:	movs    	r0, r0
0x00add8:	pop     	{r0, r2, r3, r6, r7, pc}
0x00adda:	bgt     	#0xad48
0x00addc:	movs    	r0, r0
0x00adde:	movs    	r0, r0
0x00ade0:	ble     	#0xad8c
0x00ade2:	udf     	#0xce
0x00ade4:	pop     	{r0, r2, r3, r6, r7, pc}

; ===== candidate_00adf2 =====
0x00adf2:	push    	{r3, r4, r5, r7, lr}
0x00adf4:	movs    	r0, r0
0x00adf6:	movs    	r0, r0

; ===== candidate_00adfa =====
0x00adfa:	push    	{r0, r1, r2, r3, r4, r5, r7}
0x00adfc:	adr     	r6, #0x328
0x00adfe:	push    	{r3, r4, r5, r7, lr}
0x00ae00:	movs    	r0, r0
0x00ae02:	movs    	r0, r0
0x00ae04:	bkpt    	#0xc9
0x00ae06:	ldc2    	p13, c11, [r3, #0x334]!
0x00ae0a:	bgt     	#0xad78
0x00ae0c:	movs    	r0, r0
0x00ae0e:	movs    	r0, r0
0x00ae10:	add     	r3, sp, #0x2d0
0x00ae12:	bge     	#0xadaa
0x00ae14:	add     	r5, sp, #0x2f8
0x00ae16:	ldrd    	r0, r0, [r1]
0x00ae1a:	movs    	r0, r0

; ===== candidate_00adfe =====
0x00adfe:	push    	{r3, r4, r5, r7, lr}
0x00ae00:	movs    	r0, r0
0x00ae02:	movs    	r0, r0
0x00ae04:	bkpt    	#0xc9
0x00ae06:	ldc2    	p13, c11, [r3, #0x334]!
0x00ae0a:	bgt     	#0xad78
0x00ae0c:	movs    	r0, r0
0x00ae0e:	movs    	r0, r0
0x00ae10:	add     	r3, sp, #0x2d0
0x00ae12:	bge     	#0xadaa
0x00ae14:	add     	r5, sp, #0x2f8
0x00ae16:	ldrd    	r0, r0, [r1]
0x00ae1a:	movs    	r0, r0

; ===== candidate_00ae1e =====
0x00ae1e:	push    	{r0, r1, r2, r3, r4, r5, r7}
0x00ae20:	pop     	{r0, r2, r3, r6, r7, pc}
0x00ae22:	bgt     	#0xad90
0x00ae24:	movs    	r0, r0
0x00ae26:	movs    	r0, r0
0x00ae28:	push    	{r0, r1, r2, r4, r5, r7, lr}
0x00ae2a:	bhi     	#0xada4
0x00ae2c:	movs    	r0, r0
0x00ae2e:	movs    	r0, r0
0x00ae30:	adr     	r6, #0x328
0x00ae32:	push    	{r3, r4, r5, r7, lr}
0x00ae34:	ittte   	gt
0x00ae36:	stclgt  	p9, c12, [ip], {0xbf}
0x00ae3a:	bgt     	#0xade2
0x00ae3c:	addgt   	r2, sp, #0x338
0x00ae3e:	pople   	{r0, r2, r3, r6, r7, pc}
0x00ae40:	bgt     	#0xadae
0x00ae42:	adr     	r1, #0x8c
0x00ae44:	push    	{r1, r2, r3, r4, r5, r7}
0x00ae46:	ldm     	r2!, {r0, r1, r3, r5, r7}
0x00ae48:	bkpt    	#0xda
0x00ae4a:	bne     	#0xada8
0x00ae4c:	adr     	r1, #0x3a4
0x00ae4e:	cmp     	r7, #0xbf
0x00ae50:	push    	{r1, r2, r5, lr}
0x00ae52:	ldm     	r5, {r0, r4, r5, r7}
0x00ae54:	push    	{r0, r2, r3, r4, r5, r7, lr}
0x00ae56:	push    	{r2, r3, r4, r6, r7, lr}
0x00ae58:	pop     	{r3, r6, r7}
0x00ae5a:	push    	{r1, r2, r4, r5, r7}
0x00ae5c:	push    	{r0, r1, r2, r3, r5, r6, r7, lr}
0x00ae5e:	cmp     	r2, #0xbd
0x00ae60:	adds    	r0, #0x32
0x00ae62:	adds    	r3, #0x2c
0x00ae64:	cmp     	r4, #0x30
0x00ae66:	adds    	r0, #0x34
0x00ae68:	pop     	{r0, r1, r2, r3, r5}
0x00ae6a:	push    	{r1, r2, r4, r5, r7, lr}
0x00ae6c:	ldm     	r2, {r2, r6, r7}

; ===== candidate_00ae28 =====
0x00ae28:	push    	{r0, r1, r2, r4, r5, r7, lr}
0x00ae2a:	bhi     	#0xada4
0x00ae2c:	movs    	r0, r0
0x00ae2e:	movs    	r0, r0
0x00ae30:	adr     	r6, #0x328
0x00ae32:	push    	{r3, r4, r5, r7, lr}
0x00ae34:	ittte   	gt
0x00ae36:	stclgt  	p9, c12, [ip], {0xbf}
0x00ae3a:	bgt     	#0xade2
0x00ae3c:	addgt   	r2, sp, #0x338
0x00ae3e:	pople   	{r0, r2, r3, r6, r7, pc}
0x00ae40:	bgt     	#0xadae
0x00ae42:	adr     	r1, #0x8c
0x00ae44:	push    	{r1, r2, r3, r4, r5, r7}
0x00ae46:	ldm     	r2!, {r0, r1, r3, r5, r7}
0x00ae48:	bkpt    	#0xda
0x00ae4a:	bne     	#0xada8
0x00ae4c:	adr     	r1, #0x3a4
0x00ae4e:	cmp     	r7, #0xbf
0x00ae50:	push    	{r1, r2, r5, lr}
0x00ae52:	ldm     	r5, {r0, r4, r5, r7}
0x00ae54:	push    	{r0, r2, r3, r4, r5, r7, lr}
0x00ae56:	push    	{r2, r3, r4, r6, r7, lr}
0x00ae58:	pop     	{r3, r6, r7}
0x00ae5a:	push    	{r1, r2, r4, r5, r7}
0x00ae5c:	push    	{r0, r1, r2, r3, r5, r6, r7, lr}
0x00ae5e:	cmp     	r2, #0xbd
0x00ae60:	adds    	r0, #0x32
0x00ae62:	adds    	r3, #0x2c
0x00ae64:	cmp     	r4, #0x30
0x00ae66:	adds    	r0, #0x34
0x00ae68:	pop     	{r0, r1, r2, r3, r5}
0x00ae6a:	push    	{r1, r2, r4, r5, r7, lr}
0x00ae6c:	ldm     	r2, {r2, r6, r7}

; ===== candidate_00ae32 =====
0x00ae32:	push    	{r3, r4, r5, r7, lr}
0x00ae34:	ittte   	gt
0x00ae36:	stclgt  	p9, c12, [ip], {0xbf}
0x00ae3a:	bgt     	#0xade2
0x00ae3c:	addgt   	r2, sp, #0x338
0x00ae3e:	pople   	{r0, r2, r3, r6, r7, pc}
0x00ae40:	bgt     	#0xadae
0x00ae42:	adr     	r1, #0x8c
0x00ae44:	push    	{r1, r2, r3, r4, r5, r7}
0x00ae46:	ldm     	r2!, {r0, r1, r3, r5, r7}
0x00ae48:	bkpt    	#0xda
0x00ae4a:	bne     	#0xada8
0x00ae4c:	adr     	r1, #0x3a4
0x00ae4e:	cmp     	r7, #0xbf
0x00ae50:	push    	{r1, r2, r5, lr}
0x00ae52:	ldm     	r5, {r0, r4, r5, r7}
0x00ae54:	push    	{r0, r2, r3, r4, r5, r7, lr}
0x00ae56:	push    	{r2, r3, r4, r6, r7, lr}
0x00ae58:	pop     	{r3, r6, r7}
0x00ae5a:	push    	{r1, r2, r4, r5, r7}
0x00ae5c:	push    	{r0, r1, r2, r3, r5, r6, r7, lr}
0x00ae5e:	cmp     	r2, #0xbd
0x00ae60:	adds    	r0, #0x32
0x00ae62:	adds    	r3, #0x2c
0x00ae64:	cmp     	r4, #0x30
0x00ae66:	adds    	r0, #0x34
0x00ae68:	pop     	{r0, r1, r2, r3, r5}
0x00ae6a:	push    	{r1, r2, r4, r5, r7, lr}
0x00ae6c:	ldm     	r2, {r2, r6, r7}

; ===== candidate_00ae44 =====
0x00ae44:	push    	{r1, r2, r3, r4, r5, r7}
0x00ae46:	ldm     	r2!, {r0, r1, r3, r5, r7}
0x00ae48:	bkpt    	#0xda
0x00ae4a:	bne     	#0xada8
0x00ae4c:	adr     	r1, #0x3a4
0x00ae4e:	cmp     	r7, #0xbf
0x00ae50:	push    	{r1, r2, r5, lr}
0x00ae52:	ldm     	r5, {r0, r4, r5, r7}
0x00ae54:	push    	{r0, r2, r3, r4, r5, r7, lr}
0x00ae56:	push    	{r2, r3, r4, r6, r7, lr}
0x00ae58:	pop     	{r3, r6, r7}
0x00ae5a:	push    	{r1, r2, r4, r5, r7}
0x00ae5c:	push    	{r0, r1, r2, r3, r5, r6, r7, lr}
0x00ae5e:	cmp     	r2, #0xbd
0x00ae60:	adds    	r0, #0x32
0x00ae62:	adds    	r3, #0x2c
0x00ae64:	cmp     	r4, #0x30
0x00ae66:	adds    	r0, #0x34
0x00ae68:	pop     	{r0, r1, r2, r3, r5}
0x00ae6a:	push    	{r1, r2, r4, r5, r7, lr}
0x00ae6c:	ldm     	r2, {r2, r6, r7}

; ===== candidate_00ae50 =====
0x00ae50:	push    	{r1, r2, r5, lr}
0x00ae52:	ldm     	r5, {r0, r4, r5, r7}
0x00ae54:	push    	{r0, r2, r3, r4, r5, r7, lr}
0x00ae56:	push    	{r2, r3, r4, r6, r7, lr}
0x00ae58:	pop     	{r3, r6, r7}
0x00ae5a:	push    	{r1, r2, r4, r5, r7}
0x00ae5c:	push    	{r0, r1, r2, r3, r5, r6, r7, lr}
0x00ae5e:	cmp     	r2, #0xbd
0x00ae60:	adds    	r0, #0x32
0x00ae62:	adds    	r3, #0x2c
0x00ae64:	cmp     	r4, #0x30
0x00ae66:	adds    	r0, #0x34
0x00ae68:	pop     	{r0, r1, r2, r3, r5}
0x00ae6a:	push    	{r1, r2, r4, r5, r7, lr}
0x00ae6c:	ldm     	r2, {r2, r6, r7}

; ===== candidate_00ae54 =====
0x00ae54:	push    	{r0, r2, r3, r4, r5, r7, lr}
0x00ae56:	push    	{r2, r3, r4, r6, r7, lr}
0x00ae58:	pop     	{r3, r6, r7}
0x00ae5a:	push    	{r1, r2, r4, r5, r7}
0x00ae5c:	push    	{r0, r1, r2, r3, r5, r6, r7, lr}
0x00ae5e:	cmp     	r2, #0xbd
0x00ae60:	adds    	r0, #0x32
0x00ae62:	adds    	r3, #0x2c
0x00ae64:	cmp     	r4, #0x30
0x00ae66:	adds    	r0, #0x34
0x00ae68:	pop     	{r0, r1, r2, r3, r5}
0x00ae6a:	push    	{r1, r2, r4, r5, r7, lr}
0x00ae6c:	ldm     	r2, {r2, r6, r7}

; ===== candidate_00ae56 =====
0x00ae56:	push    	{r2, r3, r4, r6, r7, lr}
0x00ae58:	pop     	{r3, r6, r7}
0x00ae5a:	push    	{r1, r2, r4, r5, r7}
0x00ae5c:	push    	{r0, r1, r2, r3, r5, r6, r7, lr}
0x00ae5e:	cmp     	r2, #0xbd
0x00ae60:	adds    	r0, #0x32
0x00ae62:	adds    	r3, #0x2c
0x00ae64:	cmp     	r4, #0x30
0x00ae66:	adds    	r0, #0x34
0x00ae68:	pop     	{r0, r1, r2, r3, r5}
0x00ae6a:	push    	{r1, r2, r4, r5, r7, lr}
0x00ae6c:	ldm     	r2, {r2, r6, r7}

; ===== candidate_00ae5a =====
0x00ae5a:	push    	{r1, r2, r4, r5, r7}
0x00ae5c:	push    	{r0, r1, r2, r3, r5, r6, r7, lr}
0x00ae5e:	cmp     	r2, #0xbd
0x00ae60:	adds    	r0, #0x32
0x00ae62:	adds    	r3, #0x2c
0x00ae64:	cmp     	r4, #0x30
0x00ae66:	adds    	r0, #0x34
0x00ae68:	pop     	{r0, r1, r2, r3, r5}
0x00ae6a:	push    	{r1, r2, r4, r5, r7, lr}
0x00ae6c:	ldm     	r2, {r2, r6, r7}

; ===== candidate_00ae5c =====
0x00ae5c:	push    	{r0, r1, r2, r3, r5, r6, r7, lr}
0x00ae5e:	cmp     	r2, #0xbd
0x00ae60:	adds    	r0, #0x32
0x00ae62:	adds    	r3, #0x2c
0x00ae64:	cmp     	r4, #0x30
0x00ae66:	adds    	r0, #0x34
0x00ae68:	pop     	{r0, r1, r2, r3, r5}
0x00ae6a:	push    	{r1, r2, r4, r5, r7, lr}
0x00ae6c:	ldm     	r2, {r2, r6, r7}

; ===== candidate_00ae6a =====
0x00ae6a:	push    	{r1, r2, r4, r5, r7, lr}
0x00ae6c:	ldm     	r2, {r2, r6, r7}

; ===== candidate_00ae84 =====
0x00ae84:	push    	{r1, r2, r5, lr}
0x00ae86:	ldm     	r5, {r0, r4, r5, r7}
0x00ae88:	push    	{r0, r2, r3, r4, r5, r7, lr}
0x00ae8a:	push    	{r2, r3, r4, r6, r7, lr}
0x00ae8c:	pop     	{r3, r6, r7}

; ===== candidate_00ae88 =====
0x00ae88:	push    	{r0, r2, r3, r4, r5, r7, lr}
0x00ae8a:	push    	{r2, r3, r4, r6, r7, lr}
0x00ae8c:	pop     	{r3, r6, r7}

; ===== candidate_00ae8a =====
0x00ae8a:	push    	{r2, r3, r4, r6, r7, lr}
0x00ae8c:	pop     	{r3, r6, r7}

; ===== candidate_00ae9c =====
0x00ae9c:	push    	{r0, r1, r2, r3, r4, r6, r7}
0x00ae9e:	push    	{r0, r1, r2, r3, r5, r6, r7, lr}
0x00aea0:	adds    	r4, #0xbd
0x00aea2:	pop     	{r4, r5}
0x00aea4:	push    	{r1, r2, r4, r5, r7, lr}
0x00aea6:	ldm     	r2, {r2, r6, r7}

; ===== candidate_00ae9e =====
0x00ae9e:	push    	{r0, r1, r2, r3, r5, r6, r7, lr}
0x00aea0:	adds    	r4, #0xbd
0x00aea2:	pop     	{r4, r5}
0x00aea4:	push    	{r1, r2, r4, r5, r7, lr}
0x00aea6:	ldm     	r2, {r2, r6, r7}

; ===== candidate_00aea4 =====
0x00aea4:	push    	{r1, r2, r4, r5, r7, lr}
0x00aea6:	ldm     	r2, {r2, r6, r7}

; ===== candidate_00aeca =====
0x00aeca:	push    	{r0, r1, r2, r3, r6, r7, lr}
0x00aecc:	movs    	r0, r0
0x00aece:	movs    	r0, r0

; ===== candidate_00aed4 =====
0x00aed4:	push    	{r0, r1, r2, r4, r6, r7}

; ===== candidate_00aef0 =====
0x00aef0:	push    	{r0, r1, r2, r4, r6, r7}
0x00aef2:	add     	r4, sp, #0x330
0x00aef4:	movs    	r0, r0
0x00aef6:	movs    	r0, r0
0x00aef8:	bne     	#0xaea0

; ===== candidate_00af40 =====
0x00af40:	push    	{r1, r3, r4, r6, r7, lr}
0x00af42:	cbz     	r4, #0xafb6
0x00af44:	bkpt    	#0xa1
0x00af46:	subs    	r7, #0xb0
0x00af48:	movs    	r0, r0
0x00af4a:	movs    	r0, r0
0x00af4c:	stm     	r7!, {r1, r3, r6, r7}
0x00af4e:	b.w     	#0x5c2ee2
0x00af52:	add     	r0, sp, #0x2d8
0x00af54:	ldm     	r1, {r0, r1, r2, r4, r5, r7}
0x00af56:	beq     	#0xaefa
0x00af58:	stm     	r1!, {r1, r2, r4, r6, r7}
0x00af5a:	movs    	r0, r4

; ===== candidate_00b0ce =====
0x00b0ce:	push    	{r0, r1, r2, r3, r4, r5, r7}
0x00b0d0:	b       	#0xae6e
0x00b0d2:	bhs     	#0xb04e
0x00b0d4:	movs    	r0, r0
0x00b0d6:	movs    	r0, r0
0x00b0d8:	itt     	gt
0x00b0da:	subgt   	sp, #0x11c
0x00b0dc:	cbnz    	r2, #0xb14c
0x00b0de:	bgt     	#0xb06a
0x00b0e0:	bls     	#0xb048

; ===== candidate_00b1ce =====
0x00b1ce:	push    	{r1, r2, r4, r6, r7, lr}
0x00b1d0:	stc2l   	p6, c11, [sb, #0x2f0]
0x00b1d4:	cbz     	r5, #0xb206
0x00b1d6:	str.w   	r0, [r0, #0x21]
0x00b1da:	movs    	r0, r0
0x00b1dc:	b       	#0xab46
0x00b1de:	push    	{r1, r2, r4, r6, r7, lr}
0x00b1e0:	stm     	r5!, {r4, r6, r7}
0x00b1e2:	adr     	r2, #0x33c
0x00b1e4:	movs    	r0, r0
0x00b1e6:	movs    	r0, r0

; ===== candidate_00b1de =====
0x00b1de:	push    	{r1, r2, r4, r6, r7, lr}
0x00b1e0:	stm     	r5!, {r4, r6, r7}
0x00b1e2:	adr     	r2, #0x33c
0x00b1e4:	movs    	r0, r0
0x00b1e6:	movs    	r0, r0

; ===== candidate_00b1ee =====
0x00b1ee:	push    	{r1, r2, r4, r6, r7, lr}
0x00b1f0:	ldm     	r0, {r0, r2, r4, r5, r7}

; ===== candidate_00b1fa =====
0x00b1fa:	push    	{r1, r2, r4, r6, r7, lr}
0x00b1fc:	bmi     	#0xb262
0x00b1fe:	bmi     	#0xb156
0x00b200:	pop     	{r1, r2, r4, r5, r6, r7}
0x00b202:	cbz     	r3, #0xb27a
0x00b204:	bvs     	#0xb1d0
0x00b206:	bkpt    	#0xb5
0x00b208:	bne     	#0xb166
0x00b20a:	adds    	r1, #0xe9
0x00b20c:	movs    	r0, r0
0x00b20e:	movs    	r0, r0
0x00b210:	add     	r5, sp, #0x2f8
0x00b212:	ldrd    	r0, r0, [r1, #0xe8]
0x00b216:	movs    	r0, r0
0x00b218:	b       	#0xab82
0x00b21a:	push    	{r1, r2, r4, r6, r7, lr}
0x00b21c:	add     	r5, sp, #0x2f8
0x00b21e:	ldrd    	r0, r0, [r1, #0xe8]
0x00b222:	movs    	r0, r0
0x00b224:	bvc     	#0xb1bc
0x00b226:	b       	#0xab90

; ===== candidate_00b21a =====
0x00b21a:	push    	{r1, r2, r4, r6, r7, lr}
0x00b21c:	add     	r5, sp, #0x2f8
0x00b21e:	ldrd    	r0, r0, [r1, #0xe8]
0x00b222:	movs    	r0, r0
0x00b224:	bvc     	#0xb1bc
0x00b226:	b       	#0xab90

; ===== candidate_00b238 =====
0x00b238:	push    	{r1, r2, r4, r6, r7, lr}
0x00b23a:	cbz     	r5, #0xb26c
0x00b23c:	str.w   	r0, [r0]
0x00b240:	b       	#0xabaa
0x00b242:	push    	{r1, r2, r4, r6, r7, lr}
0x00b244:	stc2l   	p6, c11, [sb, #0x2f0]

; ===== candidate_00b242 =====
0x00b242:	push    	{r1, r2, r4, r6, r7, lr}
0x00b244:	stc2l   	p6, c11, [sb, #0x2f0]

; ===== candidate_00b252 =====
0x00b252:	push    	{r0, r1, r2, r3, r4, r5, r7}
0x00b254:	pkhbt   	r8, pc, pc, lsl #0xf
0x00b258:	b       	#0xabc2
0x00b25a:	push    	{r1, r2, r4, r6, r7, lr}
0x00b25c:	stc2l   	p6, c11, [sb, #0x2f0]
0x00b260:	cbz     	r5, #0xb292
0x00b262:	str.w   	r0, [r0]
0x00b266:	movs    	r0, r0
0x00b268:	pop     	{r0, r4, r5}
0x00b26a:	pop     	{r1, r2, r4, r5, r7, pc}

; ===== candidate_00b25a =====
0x00b25a:	push    	{r1, r2, r4, r6, r7, lr}
0x00b25c:	stc2l   	p6, c11, [sb, #0x2f0]
0x00b260:	cbz     	r5, #0xb292
0x00b262:	str.w   	r0, [r0]
0x00b266:	movs    	r0, r0
0x00b268:	pop     	{r0, r4, r5}
0x00b26a:	pop     	{r1, r2, r4, r5, r7, pc}

; ===== candidate_00b290 =====
0x00b290:	push    	{r1, r2, r3, r6, r7}
