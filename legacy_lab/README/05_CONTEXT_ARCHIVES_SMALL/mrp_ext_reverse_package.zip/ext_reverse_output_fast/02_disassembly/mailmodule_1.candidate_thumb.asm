; fallback candidate disassembly from Thumb prologues; true code is ARM entry + Thumb functions.

; ARM entry
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0x524c
0x000018:	pop     	{r4, pc}
0x00001c:	andeq   	r4, r0, r8, ror r7
0x000020:	ands    	r2, r0, #128, #8
0x000024:	rsbmi   	r0, r0, #0
0x000028:	eors    	r3, r2, r1, asr #32
0x00002c:	rsbhs   	r1, r1, #0
0x000030:	rsbs    	ip, r0, r1, lsr #3
0x000034:	blo     	#0xbc
0x000038:	rsbs    	ip, r0, r1, lsr #8
0x00003c:	blo     	#0x80
0x000040:	lsl     	r0, r0, #8
0x000044:	orr     	r2, r2, #0xff000000
0x000048:	rsbs    	ip, r0, r1, lsr #4
0x00004c:	blo     	#0xb0
0x000050:	rsbs    	ip, r0, r1, lsr #8
0x000054:	blo     	#0x80
0x000058:	lsl     	r0, r0, #8
0x00005c:	orr     	r2, r2, #0xff0000
0x000060:	rsbs    	ip, r0, r1, lsr #8
0x000064:	lslhs   	r0, r0, #8
0x000068:	orrhs   	r2, r2, #0xff00
0x00006c:	rsbs    	ip, r0, r1, lsr #4
0x000070:	blo     	#0xb0
0x000074:	rsbs    	ip, r0, #0
0x000078:	bhs     	#0xf8
0x00007c:	lsrhs   	r0, r0, #8
0x000080:	rsbs    	ip, r0, r1, lsr #7
0x000084:	subhs   	r1, r1, r0, lsl #7
0x000088:	adc     	r2, r2, r2
0x00008c:	rsbs    	ip, r0, r1, lsr #6
0x000090:	subhs   	r1, r1, r0, lsl #6
0x000094:	adc     	r2, r2, r2
0x000098:	rsbs    	ip, r0, r1, lsr #5
0x00009c:	subhs   	r1, r1, r0, lsl #5
0x0000a0:	adc     	r2, r2, r2
0x0000a4:	rsbs    	ip, r0, r1, lsr #4
0x0000a8:	subhs   	r1, r1, r0, lsl #4
0x0000ac:	adc     	r2, r2, r2
0x0000b0:	rsbs    	ip, r0, r1, lsr #3
0x0000b4:	subhs   	r1, r1, r0, lsl #3
0x0000b8:	adc     	r2, r2, r2
0x0000bc:	rsbs    	ip, r0, r1, lsr #2
0x0000c0:	subhs   	r1, r1, r0, lsl #2
0x0000c4:	adc     	r2, r2, r2
0x0000c8:	rsbs    	ip, r0, r1, lsr #1
0x0000cc:	subhs   	r1, r1, r0, lsl #1
0x0000d0:	adc     	r2, r2, r2
0x0000d4:	rsbs    	ip, r0, r1
0x0000d8:	subhs   	r1, r1, r0
0x0000dc:	adcs    	r2, r2, r2
0x0000e0:	bhs     	#0x7c
0x0000e4:	eors    	r0, r2, r3, asr #31
0x0000e8:	add     	r0, r0, r3, lsr #31
0x0000ec:	rsbhs   	r1, r1, #0
0x0000f0:	bx      	lr
0x0000f4:	andeq   	r4, r0, r8, ror r7
0x0000f8:	mov     	r0, #2
0x0000fc:	mov     	r1, #2
0x000100:	b       	#0x118
0x000104:	strmi   	r4, [r8, -r0, lsl #14]

; ===== candidate_000008 =====
0x000008:	ands    	r0, r2
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	asrs    	r4, r1, #0x12

; ===== candidate_00000a =====
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	asrs    	r4, r1, #0x12

; ===== candidate_00011a =====
0x00011a:	stmdb   	sp!, {r2}

; ===== candidate_000134 =====
0x000134:	push    	{r4, r5, r6, lr}
0x000136:	ldr     	r6, [pc, #0x38]
0x000138:	adds    	r5, r1, #0
0x00013a:	adds    	r1, r0, #0
0x00013c:	adds    	r4, r0, #0
0x00013e:	add     	r6, pc
0x000140:	adds    	r0, r6, #0
0x000142:	bl      	#0x146
0x000146:	adds    	r2, r0, #0
0x000148:	cmp     	r0, r6
0x00014a:	bne     	#0x15a
0x00014c:	adds    	r1, r5, #0
0x00014e:	adds    	r0, r4, #0
0x000150:	bl      	#0x194
0x000154:	pop     	{r4, r5, r6}
0x000156:	pop     	{r3}
0x000158:	bx      	r3
0x00015a:	ldr     	r0, [pc, #0x18]
0x00015c:	add     	r0, pc
0x00015e:	cmp     	r2, r0
0x000160:	beq     	#0x16a
0x000162:	adds    	r1, r5, #0
0x000164:	adds    	r0, r4, #0
0x000166:	bl      	#0x108
0x00016a:	movs    	r0, #0
0x00016c:	b       	#0x154
0x00016e:	movs    	r0, r0
0x000170:	mcr2    	p15, #6, pc, c5, c7, #7
0x000174:	mcr2    	p15, #5, pc, c5, c7, #7
0x000178:	bx      	pc

; ===== candidate_000194 =====
0x000194:	push    	{r3, r4, r5, lr}
0x000196:	subs    	r2, r0, #1
0x000198:	cmp     	r2, #0xd
0x00019a:	adr     	r4, #0x90
0x00019c:	bhs     	#0x1ec
0x00019e:	movs    	r2, #0x17
0x0001a0:	ldr     	r3, [pc, #0x8c]
0x0001a2:	muls    	r2, r0, r2
0x0001a4:	add     	r3, pc
0x0001a6:	adds    	r5, r2, r3
0x0001a8:	subs    	r5, #0x17
0x0001aa:	cmp     	r0, #2
0x0001ac:	bne     	#0x1d8
0x0001ae:	lsls    	r0, r1, #5
0x0001b0:	bpl     	#0x1b6
0x0001b2:	adr     	r4, #0x80
0x0001b4:	b       	#0x1ee
0x0001b6:	ldr     	r0, [pc, #0x90]
0x0001b8:	ands    	r0, r1
0x0001ba:	beq     	#0x1c0
0x0001bc:	adr     	r4, #0x8c
0x0001be:	b       	#0x1ee
0x0001c0:	lsls    	r0, r1, #3
0x0001c2:	bpl     	#0x1c8
0x0001c4:	adr     	r4, #0x94
0x0001c6:	b       	#0x1ee
0x0001c8:	lsls    	r0, r1, #2
0x0001ca:	bpl     	#0x1d0
0x0001cc:	adr     	r4, #0x98
0x0001ce:	b       	#0x1ee
0x0001d0:	lsls    	r0, r1, #1
0x0001d2:	bpl     	#0x1ee
0x0001d4:	adr     	r4, #0x9c
0x0001d6:	b       	#0x1ee
0x0001d8:	cmp     	r0, #8
0x0001da:	bne     	#0x1e0
0x0001dc:	adds    	r4, r1, #0
0x0001de:	b       	#0x1ee
0x0001e0:	cmp     	r0, #9
0x0001e2:	bne     	#0x1ee
0x0001e4:	cmp     	r1, #1
0x0001e6:	bne     	#0x1ee
0x0001e8:	adr     	r5, #0x98
0x0001ea:	b       	#0x1ee
0x0001ec:	adr     	r5, #0xac
0x0001ee:	movs    	r0, #0xa
0x0001f0:	bl      	#0x2b4
0x0001f4:	ldrb    	r0, [r5]
0x0001f6:	cmp     	r0, #0
0x0001f8:	beq     	#0x208
0x0001fa:	ldrb    	r0, [r5]
0x0001fc:	adds    	r5, #1
0x0001fe:	bl      	#0x2b4
0x000202:	ldrb    	r0, [r5]
0x000204:	cmp     	r0, #0
0x000206:	bne     	#0x1fa
0x000208:	ldrb    	r0, [r4]
0x00020a:	cmp     	r0, #0
0x00020c:	beq     	#0x21c
0x00020e:	ldrb    	r0, [r4]
0x000210:	adds    	r4, #1
0x000212:	bl      	#0x2b4
0x000216:	ldrb    	r0, [r4]
0x000218:	cmp     	r0, #0
0x00021a:	bne     	#0x20e
0x00021c:	movs    	r0, #0xa
0x00021e:	bl      	#0x2b4
0x000222:	pop     	{r3, r4, r5}
0x000224:	pop     	{r3}
0x000226:	movs    	r0, #1
0x000228:	bx      	r3
0x00022a:	movs    	r0, r0
0x00022c:	movs    	r0, r0
0x00022e:	movs    	r0, r0
0x000230:	ldr     	r0, [r5, #0x10]
0x000232:	movs    	r0, r0
0x000234:	ldr     	r1, [r1, #0x64]
0x000236:	str     	r6, [r6, #0x14]
0x000238:	ldr     	r4, [r5, #0x14]
0x00023a:	movs    	r0, #0x64
0x00023c:	strb    	r7, [r1, #1]
0x00023e:	strb    	r5, [r4, #9]
0x000240:	strb    	r1, [r4, #0x11]
0x000242:	ldr     	r1, [r5, #0x74]
0x000244:	lsls    	r6, r5, #1
0x000246:	movs    	r0, r0
0x000248:	movs    	r2, r0
0x00024a:	lsrs    	r0, r0, #0x20
0x00024c:	ldr     	r4, [r0, #0x14]
0x00024e:	ldr     	r6, [r6, #0x14]
0x000250:	str     	r4, [r4, #0x54]
0x000252:	tst     	r0, r4
0x000254:	movs    	r0, #0x79
0x000256:	str     	r2, [r3, #0x54]
0x000258:	ldr     	r2, [r6, #0x74]
0x00025a:	movs    	r0, r0
0x00025c:	strb    	r7, [r1, #0x19]
0x00025e:	strb    	r5, [r4, #9]
0x000260:	ldr     	r6, [r4, #0x44]
0x000262:	strb    	r7, [r5, #0x1d]
0x000264:	movs    	r0, r0
0x000266:	movs    	r0, r0
0x000268:	ldr     	r5, [r2, #0x64]
0x00026a:	str     	r4, [r4, #0x54]
0x00026c:	str     	r2, [r6, #0x64]
0x00026e:	ldr     	r4, [r5, #0x74]
0x000270:	lsls    	r7, r6, #1
0x000272:	movs    	r0, r0
0x000274:	ldr     	r1, [r1, #0x64]
0x000276:	ldrb    	r5, [r4, #1]
0x000278:	str     	r1, [r4, #0x34]
0x00027a:	movs    	r0, #0x74
0x00027c:	str     	r2, [r2, #0x54]
0x00027e:	strb    	r3, [r6, #0x15]
0x000280:	strb    	r4, [r5, #0x11]
0x000282:	movs    	r0, r0
0x000284:	movs    	r0, #0x3a
0x000286:	str     	r0, [r1, #0x54]
0x000288:	strb    	r1, [r4, #1]
0x00028a:	ldr     	r0, [r4, #0x50]
0x00028c:	ldr     	r5, [r4, #0x54]
0x00028e:	strb    	r7, [r5, #9]
0x000290:	movs    	r0, #0x79
0x000292:	ldr     	r3, [r4, #0x74]
0x000294:	strb    	r2, [r6, #9]
0x000296:	strb    	r5, [r6, #1]
0x000298:	str     	r4, [r6, #0x54]
0x00029a:	lsls    	r4, r4, #1
0x00029c:	ldr     	r5, [r2, #0x64]
0x00029e:	ldr     	r3, [r5, #0x64]
0x0002a0:	strb    	r7, [r5, #0x1d]
0x0002a2:	movs    	r0, #0x6e
0x0002a4:	ldr     	r3, [r6, #0x14]
0x0002a6:	ldr     	r7, [r4, #0x64]
0x0002a8:	ldr     	r1, [r4, #0x44]
0x0002aa:	movs    	r0, r0
0x0002ac:	bx      	pc

; ===== candidate_0002b4 =====
0x0002b4:	push    	{r3, lr}
0x0002b6:	add     	r3, sp, #0
0x0002b8:	strb    	r0, [r3]
0x0002ba:	movs    	r0, #3
0x0002bc:	mov     	r1, sp
0x0002be:	svc     	#0xab
0x0002c0:	add     	sp, #4
0x0002c2:	pop     	{r3}
0x0002c4:	bx      	r3
0x0002c6:	movs    	r0, r0
0x0002c8:	movs    	r0, r1
0x0002ca:	b       	#0xfffffe0c
0x0002cc:	asrs    	r0, r1, #0x20
0x0002ce:	b       	#0xfffffe10
0x0002d0:	movs    	r1, r0
0x0002d2:	b       	#0x3d6
0x0002d4:	vrhadd.u16	d14, d14, d31
0x0002d8:	movs    	r0, r6
0x0002da:	movs    	r0, r0
0x0002dc:	lsls    	r0, r7, #7
0x0002de:	movs    	r0, r0
0x0002e0:	str     	r0, [sp]
0x0002e2:	b       	#0x626
0x0002e4:	vrhadd.u16	d14, d14, d31
0x0002e8:	adds    	r0, #0x14
0x0002ea:	b       	#0xfffffe2c
0x0002ec:	cmp     	r7, #0xc0
0x0002ee:	b       	#0x632
0x0002f0:	stm     	r0!, {r0, r1, r4, r7}
0x0002f2:	b       	#0x478
0x0002f4:	adds    	r0, #0x18
0x0002f6:	b       	#0xaba
0x0002f8:	asrs    	r1, r0, #7
0x0002fa:	b       	#0x3c2
0x0002fc:	lsls    	r3, r2, #6
0x0002fe:	b       	#0x342
0x000300:	vrhadd.u16	d14, d14, d31
0x000304:	strh    	r7, [r3, #0x28]
0x000306:	str     	r3, [r5, r7]
0x000308:	adds    	r0, #0x14
0x00030a:	b       	#0xfffffe4c
0x00030c:	cmp     	r7, #0xc0
0x00030e:	b       	#0x652
0x000310:	stm     	r0!, {r0, r1, r4, r7}
0x000312:	b       	#0x498
0x000314:	adds    	r0, #2
0x000316:	b       	#0xada
0x000318:	asrs    	r1, r0, #0x20
0x00031a:	b       	#0x3e2
0x00031c:	lsls    	r3, r2, #6
0x00031e:	b       	#0x362
0x000320:	vrhadd.u16	d14, d14, d31
0x000324:	strb    	r6, [r2, r5]
0x000326:	strb    	r5, [r2, r5]
0x000328:	push    	{r4, r5, lr}
0x00032a:	ldr     	r4, [pc, #0xb4]
0x00032c:	movs    	r2, #0x1c
0x00032e:	add     	r4, pc
0x000330:	ldr     	r0, [r4, #0x38]
0x000332:	movs    	r1, #0
0x000334:	ldr     	r3, [r0, #0x38]
0x000336:	ldr     	r0, [pc, #0xac]
0x000338:	sub     	sp, #0xc
0x00033a:	add     	r0, sb
0x00033c:	blx     	r3
0x00033e:	movs    	r2, #0
0x000340:	movs    	r0, #0
0x000342:	str     	r0, [sp]
0x000344:	ldr     	r1, [pc, #0x9c]
0x000346:	movs    	r3, #0
0x000348:	add     	r1, sb
0x00034a:	str     	r1, [sp, #4]
0x00034c:	movs    	r1, #0x64
0x00034e:	movs    	r0, #1
0x000350:	str     	r2, [sp, #8]
0x000352:	bl      	#0x5324
0x000356:	ldr     	r1, [pc, #0x8c]
0x000358:	movs    	r0, #0
0x00035a:	add     	r1, sb
0x00035c:	subs    	r1, #0x7c
0x00035e:	str     	r0, [r1, #8]
0x000360:	ldr     	r5, [pc, #0x80]
0x000362:	str     	r0, [r1, #0x10]
0x000364:	str     	r0, [r1, #0xc]
0x000366:	add     	r5, sb
0x000368:	subs    	r5, #0xfc
0x00036a:	movs    	r0, #1
0x00036c:	str     	r0, [r5, #0x18]
0x00036e:	ldr     	r0, [r4, #0x38]
0x000370:	ldr     	r2, [pc, #0x74]
0x000372:	ldr     	r1, [r0, #0x68]
0x000374:	add     	r2, sb
0x000376:	str     	r1, [r5, #0x2c]
0x000378:	ldr     	r1, [r0, #0xc]
0x00037a:	ldr     	r4, [pc, #0x70]
0x00037c:	str     	r1, [r5, #0x30]
0x00037e:	ldr     	r1, [r0, #0x10]
0x000380:	str     	r1, [r5, #0x34]
0x000382:	ldr     	r1, [r0, #0x14]
0x000384:	str     	r1, [r5, #0x38]
0x000386:	ldr     	r1, [r0, #0x18]
0x000388:	str     	r1, [r5, #0x3c]
0x00038a:	ldr     	r1, [r0, #0x1c]
0x00038c:	str     	r1, [r5, #0x40]
0x00038e:	ldr     	r1, [r0, #0x20]
0x000390:	str     	r1, [r5, #0x44]
0x000392:	ldr     	r1, [r0, #0x24]
0x000394:	str     	r1, [r5, #0x48]
0x000396:	ldr     	r1, [r0, #0x28]
0x000398:	str     	r1, [r5, #0x4c]
0x00039a:	ldr     	r1, [r0, #0x2c]
0x00039c:	str     	r1, [r5, #0x50]
0x00039e:	ldr     	r1, [r0, #0x30]
0x0003a0:	str     	r1, [r5, #0x54]
0x0003a2:	ldr     	r1, [r0, #0x34]
0x0003a4:	str     	r1, [r5, #0x58]
0x0003a6:	ldr     	r1, [r0, #0x38]
0x0003a8:	str     	r1, [r5, #0x5c]
0x0003aa:	ldr     	r1, [r0, #0x3c]
0x0003ac:	str     	r1, [r5, #0x60]
0x0003ae:	ldr     	r1, [r0, #0x40]
0x0003b0:	str     	r1, [r5, #0x64]
0x0003b2:	ldr     	r1, [r0, #0x44]
0x0003b4:	str     	r1, [r5, #0x68]
0x0003b6:	ldr     	r1, [r0, #0x48]
0x0003b8:	str     	r1, [r5, #0x6c]
0x0003ba:	ldr     	r1, [r0, #0x4c]
0x0003bc:	str     	r1, [r5, #0x70]
0x0003be:	movs    	r1, #0
0x0003c0:	str     	r1, [r2]
0x0003c2:	movs    	r1, #1
0x0003c4:	lsls    	r1, r1, #9
0x0003c6:	adds    	r0, r0, r1
0x0003c8:	ldr     	r3, [r0, #8]
0x0003ca:	movs    	r1, #7
0x0003cc:	adds    	r2, r4, #0
0x0003ce:	movs    	r0, #0
0x0003d0:	blx     	r3
0x0003d2:	cmp     	r0, r4
0x0003d4:	bne     	#0x3da
0x0003d6:	subs    	r0, #2

; ===== candidate_000328 =====
0x000328:	push    	{r4, r5, lr}
0x00032a:	ldr     	r4, [pc, #0xb4]
0x00032c:	movs    	r2, #0x1c
0x00032e:	add     	r4, pc
0x000330:	ldr     	r0, [r4, #0x38]
0x000332:	movs    	r1, #0
0x000334:	ldr     	r3, [r0, #0x38]
0x000336:	ldr     	r0, [pc, #0xac]
0x000338:	sub     	sp, #0xc
0x00033a:	add     	r0, sb
0x00033c:	blx     	r3
0x00033e:	movs    	r2, #0
0x000340:	movs    	r0, #0
0x000342:	str     	r0, [sp]
0x000344:	ldr     	r1, [pc, #0x9c]
0x000346:	movs    	r3, #0
0x000348:	add     	r1, sb
0x00034a:	str     	r1, [sp, #4]
0x00034c:	movs    	r1, #0x64
0x00034e:	movs    	r0, #1
0x000350:	str     	r2, [sp, #8]
0x000352:	bl      	#0x5324
0x000356:	ldr     	r1, [pc, #0x8c]
0x000358:	movs    	r0, #0
0x00035a:	add     	r1, sb
0x00035c:	subs    	r1, #0x7c
0x00035e:	str     	r0, [r1, #8]
0x000360:	ldr     	r5, [pc, #0x80]
0x000362:	str     	r0, [r1, #0x10]
0x000364:	str     	r0, [r1, #0xc]
0x000366:	add     	r5, sb
0x000368:	subs    	r5, #0xfc
0x00036a:	movs    	r0, #1
0x00036c:	str     	r0, [r5, #0x18]
0x00036e:	ldr     	r0, [r4, #0x38]
0x000370:	ldr     	r2, [pc, #0x74]
0x000372:	ldr     	r1, [r0, #0x68]
0x000374:	add     	r2, sb
0x000376:	str     	r1, [r5, #0x2c]
0x000378:	ldr     	r1, [r0, #0xc]
0x00037a:	ldr     	r4, [pc, #0x70]
0x00037c:	str     	r1, [r5, #0x30]
0x00037e:	ldr     	r1, [r0, #0x10]
0x000380:	str     	r1, [r5, #0x34]
0x000382:	ldr     	r1, [r0, #0x14]
0x000384:	str     	r1, [r5, #0x38]
0x000386:	ldr     	r1, [r0, #0x18]
0x000388:	str     	r1, [r5, #0x3c]
0x00038a:	ldr     	r1, [r0, #0x1c]
0x00038c:	str     	r1, [r5, #0x40]
0x00038e:	ldr     	r1, [r0, #0x20]
0x000390:	str     	r1, [r5, #0x44]
0x000392:	ldr     	r1, [r0, #0x24]
0x000394:	str     	r1, [r5, #0x48]
0x000396:	ldr     	r1, [r0, #0x28]
0x000398:	str     	r1, [r5, #0x4c]
0x00039a:	ldr     	r1, [r0, #0x2c]
0x00039c:	str     	r1, [r5, #0x50]
0x00039e:	ldr     	r1, [r0, #0x30]
0x0003a0:	str     	r1, [r5, #0x54]
0x0003a2:	ldr     	r1, [r0, #0x34]
0x0003a4:	str     	r1, [r5, #0x58]
0x0003a6:	ldr     	r1, [r0, #0x38]
0x0003a8:	str     	r1, [r5, #0x5c]
0x0003aa:	ldr     	r1, [r0, #0x3c]
0x0003ac:	str     	r1, [r5, #0x60]
0x0003ae:	ldr     	r1, [r0, #0x40]
0x0003b0:	str     	r1, [r5, #0x64]
0x0003b2:	ldr     	r1, [r0, #0x44]
0x0003b4:	str     	r1, [r5, #0x68]
0x0003b6:	ldr     	r1, [r0, #0x48]
0x0003b8:	str     	r1, [r5, #0x6c]
0x0003ba:	ldr     	r1, [r0, #0x4c]
0x0003bc:	str     	r1, [r5, #0x70]
0x0003be:	movs    	r1, #0
0x0003c0:	str     	r1, [r2]
0x0003c2:	movs    	r1, #1
0x0003c4:	lsls    	r1, r1, #9
0x0003c6:	adds    	r0, r0, r1
0x0003c8:	ldr     	r3, [r0, #8]
0x0003ca:	movs    	r1, #7
0x0003cc:	adds    	r2, r4, #0
0x0003ce:	movs    	r0, #0
0x0003d0:	blx     	r3
0x0003d2:	cmp     	r0, r4
0x0003d4:	bne     	#0x3da
0x0003d6:	subs    	r0, #2
0x0003d8:	str     	r0, [r5, #0x28]
0x0003da:	add     	sp, #0xc
0x0003dc:	pop     	{r4, r5, pc}

; ===== candidate_0003f0 =====
0x0003f0:	push    	{r4, r5, r6, r7, lr}
0x0003f2:	sub     	sp, #0xc
0x0003f4:	movs    	r1, #0
0x0003f6:	str     	r1, [sp]
0x0003f8:	str     	r1, [sp, #4]
0x0003fa:	movs    	r2, #0
0x0003fc:	movs    	r1, #0xa
0x0003fe:	movs    	r3, #4
0x000400:	movs    	r0, #0xf1
0x000402:	lsls    	r0, r0, #9
0x000404:	str     	r2, [sp, #8]
0x000406:	bl      	#0x5324
0x00040a:	movs    	r1, #0
0x00040c:	str     	r1, [sp]
0x00040e:	str     	r1, [sp, #4]
0x000410:	movs    	r2, #0
0x000412:	ldr     	r7, [pc, #0x84]
0x000414:	adds    	r6, r0, #0
0x000416:	movs    	r0, #0xf1
0x000418:	str     	r2, [sp, #8]
0x00041a:	movs    	r1, #0x11
0x00041c:	movs    	r3, #0x2c
0x00041e:	add     	r7, sb
0x000420:	ldr     	r2, [r7, #0xc]
0x000422:	lsls    	r0, r0, #9
0x000424:	bl      	#0x5324
0x000428:	movs    	r1, #0
0x00042a:	movs    	r2, #0
0x00042c:	str     	r2, [sp, #8]
0x00042e:	str     	r1, [sp]
0x000430:	str     	r1, [sp, #4]
0x000432:	adds    	r5, r0, #0
0x000434:	movs    	r0, #0xf1
0x000436:	movs    	r1, #0x14
0x000438:	movs    	r2, #0x82
0x00043a:	movs    	r4, #0
0x00043c:	movs    	r3, #0
0x00043e:	lsls    	r0, r0, #9
0x000440:	bl      	#0x5324
0x000444:	cmp     	r5, #0
0x000446:	ble     	#0x458
0x000448:	ldr     	r1, [r7, #0xc]
0x00044a:	lsls    	r0, r4, #2
0x00044c:	ldr     	r0, [r1, r0]
0x00044e:	bl      	#0x5aa0
0x000452:	adds    	r4, #1
0x000454:	cmp     	r4, r5
0x000456:	blt     	#0x448
0x000458:	movs    	r1, #0
0x00045a:	str     	r1, [sp]
0x00045c:	str     	r1, [sp, #4]
0x00045e:	movs    	r2, #0
0x000460:	movs    	r4, #0
0x000462:	adds    	r3, r4, #0
0x000464:	str     	r2, [sp, #8]
0x000466:	movs    	r1, #9
0x000468:	movs    	r0, #0xf1
0x00046a:	lsls    	r0, r0, #9
0x00046c:	ldr     	r2, [r7, #0xc]
0x00046e:	bl      	#0x5324
0x000472:	str     	r6, [r7, #0xc]
0x000474:	ldr     	r0, [r7, #0x30]
0x000476:	ldr     	r1, [r7, #8]
0x000478:	lsls    	r0, r0, #2
0x00047a:	str     	r6, [r1, r0]
0x00047c:	movs    	r1, #0
0x00047e:	movs    	r2, #0
0x000480:	str     	r2, [sp, #8]
0x000482:	str     	r1, [sp]
0x000484:	str     	r1, [sp, #4]
0x000486:	movs    	r1, #0x67
0x000488:	movs    	r2, #0xed
0x00048a:	movs    	r0, #0xf1
0x00048c:	adds    	r3, r4, #0
0x00048e:	lsls    	r0, r0, #9
0x000490:	bl      	#0x5324
0x000494:	add     	sp, #0xc
0x000496:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00049c =====
0x00049c:	push    	{r4, r5, r6, r7, lr}
0x00049e:	ldr     	r5, [pc, #0x210]
0x0004a0:	ldr     	r1, [pc, #0x210]
0x0004a2:	add     	r5, sb
0x0004a4:	ldr     	r0, [r5, #0x48]
0x0004a6:	add     	r1, sb
0x0004a8:	ldr     	r2, [r1, #0x18]
0x0004aa:	movs    	r7, #0xf1
0x0004ac:	lsls    	r7, r7, #9
0x0004ae:	cmp     	r0, r2
0x0004b0:	sub     	sp, #0xc
0x0004b2:	blt     	#0x4ea
0x0004b4:	ldr     	r3, [r1, #0x1c]
0x0004b6:	cmp     	r0, r3
0x0004b8:	bge     	#0x4ea
0x0004ba:	movs    	r1, #0
0x0004bc:	subs    	r3, r0, r2
0x0004be:	movs    	r2, #0
0x0004c0:	str     	r1, [sp]
0x0004c2:	str     	r1, [sp, #4]
0x0004c4:	movs    	r1, #0x27
0x0004c6:	str     	r2, [sp, #8]
0x0004c8:	ldr     	r2, [r5, #0x28]
0x0004ca:	adds    	r0, r7, #0
0x0004cc:	bl      	#0x5324
0x0004d0:	movs    	r1, #0
0x0004d2:	movs    	r2, #0
0x0004d4:	str     	r2, [sp, #8]
0x0004d6:	str     	r1, [sp]
0x0004d8:	str     	r1, [sp, #4]
0x0004da:	ldr     	r3, [r0, #4]
0x0004dc:	movs    	r1, #0xb9
0x0004de:	adds    	r2, r0, #0
0x0004e0:	adds    	r0, r7, #0
0x0004e2:	bl      	#0x5324
0x0004e6:	add     	sp, #0xc
0x0004e8:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0006c4 =====
0x0006c4:	push    	{r4, r5, r6, r7, lr}
0x0006c6:	sub     	sp, #0x14
0x0006c8:	movs    	r5, #0
0x0006ca:	movs    	r2, #0
0x0006cc:	movs    	r1, #0
0x0006ce:	str     	r2, [sp, #8]
0x0006d0:	adds    	r3, r5, #0
0x0006d2:	adds    	r4, r0, #0
0x0006d4:	adds    	r2, r0, #0
0x0006d6:	str     	r1, [sp]
0x0006d8:	str     	r1, [sp, #4]
0x0006da:	movs    	r1, #0x44
0x0006dc:	movs    	r0, #0xf1
0x0006de:	movs    	r6, #0
0x0006e0:	lsls    	r0, r0, #9
0x0006e2:	bl      	#0x5324
0x0006e6:	movs    	r1, #0
0x0006e8:	str     	r1, [sp]
0x0006ea:	str     	r1, [sp, #4]
0x0006ec:	movs    	r2, #0
0x0006ee:	str     	r2, [sp, #8]
0x0006f0:	movs    	r1, #0x45
0x0006f2:	adds    	r3, r5, #0
0x0006f4:	movs    	r0, #0xf1
0x0006f6:	lsls    	r0, r0, #9
0x0006f8:	ldr     	r2, [r4, #8]
0x0006fa:	bl      	#0x5324
0x0006fe:	str     	r0, [sp, #0x10]
0x000700:	cmp     	r0, #0
0x000702:	ble     	#0x7e8
0x000704:	movs    	r1, #0
0x000706:	str     	r1, [sp]
0x000708:	str     	r1, [sp, #4]
0x00070a:	movs    	r2, #0
0x00070c:	movs    	r5, #0
0x00070e:	adds    	r3, r5, #0
0x000710:	str     	r2, [sp, #8]
0x000712:	movs    	r1, #0x45
0x000714:	movs    	r0, #0xf1
0x000716:	lsls    	r0, r0, #9
0x000718:	ldr     	r2, [r4, #8]
0x00071a:	bl      	#0x5324
0x00071e:	movs    	r1, #0
0x000720:	str     	r1, [sp]
0x000722:	str     	r1, [sp, #4]
0x000724:	str     	r0, [sp, #0xc]
0x000726:	movs    	r2, #0
0x000728:	str     	r2, [sp, #8]
0x00072a:	movs    	r0, #0xf1
0x00072c:	movs    	r1, #0x45
0x00072e:	adds    	r3, r5, #0
0x000730:	lsls    	r0, r0, #9
0x000732:	ldr     	r2, [r4, #8]
0x000734:	bl      	#0x5324
0x000738:	adds    	r7, r0, #0
0x00073a:	movs    	r1, #0
0x00073c:	ldr     	r0, [pc, #0x1f0]
0x00073e:	str     	r1, [sp]
0x000740:	str     	r1, [sp, #4]
0x000742:	movs    	r2, #0
0x000744:	str     	r2, [sp, #8]
0x000746:	ldr     	r3, [sp, #0xc]
0x000748:	add     	r0, sb
0x00074a:	ldr     	r2, [r0, #0x28]
0x00074c:	movs    	r0, #0xf1
0x00074e:	movs    	r1, #0xc8
0x000750:	lsls    	r0, r0, #9
0x000752:	bl      	#0x5324
0x000756:	adds    	r5, r0, #0
0x000758:	beq     	#0x790
0x00075a:	movs    	r1, #0
0x00075c:	movs    	r2, #0
0x00075e:	str     	r2, [sp, #8]
0x000760:	str     	r1, [sp]
0x000762:	str     	r1, [sp, #4]
0x000764:	movs    	r1, #0xa9
0x000766:	adds    	r2, r5, #0
0x000768:	movs    	r3, #1
0x00076a:	movs    	r0, #0xf1
0x00076c:	lsls    	r0, r0, #9
0x00076e:	bl      	#0x5324
0x000772:	movs    	r1, #0
0x000774:	movs    	r2, #0
0x000776:	ldr     	r0, [pc, #0x1b8]
0x000778:	str     	r2, [sp, #8]
0x00077a:	str     	r1, [sp]
0x00077c:	str     	r1, [sp, #4]
0x00077e:	add     	r0, sb
0x000780:	ldr     	r3, [r0, #0x28]
0x000782:	movs    	r0, #0xf1
0x000784:	movs    	r1, #0xc9
0x000786:	adds    	r2, r5, #0
0x000788:	lsls    	r0, r0, #9
0x00078a:	bl      	#0x5324
0x00078e:	b       	#0x806
0x000790:	movs    	r1, #0
0x000792:	ldr     	r0, [pc, #0x19c]
0x000794:	str     	r1, [sp]
0x000796:	str     	r1, [sp, #4]
0x000798:	movs    	r2, #0
0x00079a:	str     	r2, [sp, #8]
0x00079c:	add     	r0, sb
0x00079e:	ldr     	r2, [r0, #0x28]
0x0007a0:	movs    	r0, #0xf1
0x0007a2:	movs    	r1, #0xca
0x0007a4:	adds    	r3, r7, #0
0x0007a6:	lsls    	r0, r0, #9
0x0007a8:	bl      	#0x5324
0x0007ac:	movs    	r1, #0
0x0007ae:	adds    	r5, r0, #0
0x0007b0:	movs    	r2, #0
0x0007b2:	str     	r2, [sp, #8]
0x0007b4:	str     	r1, [sp]
0x0007b6:	str     	r1, [sp, #4]
0x0007b8:	movs    	r1, #0xcb
0x0007ba:	adds    	r2, r7, #0
0x0007bc:	movs    	r0, #0xf1
0x0007be:	movs    	r3, #1
0x0007c0:	lsls    	r0, r0, #9
0x0007c2:	bl      	#0x5324
0x0007c6:	ldrh    	r1, [r0, #8]
0x0007c8:	ldrh    	r2, [r5, #8]
0x0007ca:	adds    	r1, r1, r2
0x0007cc:	strh    	r1, [r0, #8]
0x0007ce:	movs    	r1, #0
0x0007d0:	ldr     	r0, [pc, #0x15c]
0x0007d2:	movs    	r2, #0
0x0007d4:	str     	r2, [sp, #8]
0x0007d6:	str     	r1, [sp]
0x0007d8:	str     	r1, [sp, #4]
0x0007da:	add     	r0, sb
0x0007dc:	ldr     	r3, [r0, #0x28]
0x0007de:	movs    	r0, #0xf1
0x0007e0:	movs    	r1, #0xc9
0x0007e2:	adds    	r2, r5, #0
0x0007e4:	lsls    	r0, r0, #9
0x0007e6:	b       	#0x7ea
0x0007e8:	b       	#0x810
0x0007ea:	bl      	#0x5324
0x0007ee:	movs    	r1, #0
0x0007f0:	movs    	r2, #0

; ===== candidate_00093c =====
0x00093c:	push    	{r4, r5, r6, r7, lr}
0x00093e:	ldr     	r5, [pc, #0xd0]
0x000940:	adds    	r7, r0, #0
0x000942:	add     	r5, sb
0x000944:	ldr     	r0, [r5, #8]
0x000946:	sub     	sp, #0x14
0x000948:	cmp     	r0, #0
0x00094a:	beq     	#0xa0a
0x00094c:	movs    	r1, #0
0x00094e:	movs    	r2, #0
0x000950:	movs    	r6, #0
0x000952:	adds    	r3, r6, #0
0x000954:	str     	r2, [sp, #8]
0x000956:	str     	r1, [sp]
0x000958:	str     	r1, [sp, #4]
0x00095a:	movs    	r1, #0x44
0x00095c:	adds    	r2, r7, #0
0x00095e:	movs    	r4, #0
0x000960:	movs    	r0, #0xf1
0x000962:	lsls    	r0, r0, #9
0x000964:	bl      	#0x5324
0x000968:	movs    	r1, #0
0x00096a:	str     	r1, [sp]
0x00096c:	str     	r1, [sp, #4]
0x00096e:	movs    	r2, #0
0x000970:	str     	r2, [sp, #8]
0x000972:	movs    	r1, #0x45
0x000974:	adds    	r3, r6, #0
0x000976:	movs    	r0, #0xf1
0x000978:	lsls    	r0, r0, #9
0x00097a:	ldr     	r2, [r7, #8]
0x00097c:	bl      	#0x5324
0x000980:	adds    	r6, r0, #0
0x000982:	adds    	r0, r7, #0
0x000984:	bl      	#0x579c
0x000988:	str     	r0, [sp, #0xc]
0x00098a:	lsls    	r0, r6, #2
0x00098c:	str     	r0, [sp, #0x10]
0x00098e:	ldr     	r1, [r5, #8]
0x000990:	movs    	r5, #4
0x000992:	ldr     	r7, [r1, r0]
0x000994:	movs    	r1, #0
0x000996:	movs    	r2, #0
0x000998:	str     	r2, [sp, #8]
0x00099a:	str     	r1, [sp]
0x00099c:	str     	r1, [sp, #4]
0x00099e:	adds    	r3, r5, #0
0x0009a0:	adds    	r2, r7, #0
0x0009a2:	movs    	r1, #0x11
0x0009a4:	movs    	r0, #0xf1
0x0009a6:	lsls    	r0, r0, #9
0x0009a8:	bl      	#0x5324
0x0009ac:	movs    	r2, #0
0x0009ae:	movs    	r1, #0
0x0009b0:	str     	r2, [sp, #8]
0x0009b2:	adds    	r6, r0, #0
0x0009b4:	adds    	r3, r5, #0
0x0009b6:	adds    	r2, r0, #1
0x0009b8:	str     	r1, [sp]
0x0009ba:	str     	r1, [sp, #4]
0x0009bc:	movs    	r1, #0xa
0x0009be:	movs    	r0, #0xf1
0x0009c0:	lsls    	r0, r0, #9
0x0009c2:	bl      	#0x5324
0x0009c6:	adds    	r5, r0, #0
0x0009c8:	cmp     	r6, #0
0x0009ca:	ble     	#0x9da
0x0009cc:	lsls    	r0, r4, #2
0x0009ce:	ldr     	r1, [r7, r0]
0x0009d0:	adds    	r0, r0, r5
0x0009d2:	adds    	r4, #1
0x0009d4:	cmp     	r4, r6
0x0009d6:	str     	r1, [r0, #4]
0x0009d8:	blt     	#0x9cc
0x0009da:	ldr     	r0, [sp, #0xc]
0x0009dc:	movs    	r1, #0
0x0009de:	str     	r0, [r5]
0x0009e0:	movs    	r2, #0
0x0009e2:	str     	r2, [sp, #8]
0x0009e4:	str     	r1, [sp]
0x0009e6:	str     	r1, [sp, #4]
0x0009e8:	movs    	r1, #9
0x0009ea:	adds    	r2, r7, #0
0x0009ec:	movs    	r0, #0xf1
0x0009ee:	movs    	r3, #0
0x0009f0:	lsls    	r0, r0, #9
0x0009f2:	bl      	#0x5324
0x0009f6:	ldr     	r1, [pc, #0x18]
0x0009f8:	ldr     	r0, [sp, #0x10]
0x0009fa:	add     	r1, sb
0x0009fc:	ldr     	r2, [r1, #8]
0x0009fe:	str     	r5, [r2, r0]
0x000a00:	ldr     	r0, [r1, #0x30]
0x000a02:	ldr     	r2, [r1, #8]
0x000a04:	lsls    	r0, r0, #2
0x000a06:	ldr     	r0, [r2, r0]
0x000a08:	str     	r0, [r1, #0xc]
0x000a0a:	add     	sp, #0x14
0x000a0c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000a14 =====
0x000a14:	push    	{r4, r5, r6, r7, lr}
0x000a16:	sub     	sp, #0xc
0x000a18:	movs    	r1, #0
0x000a1a:	movs    	r2, #0
0x000a1c:	str     	r2, [sp, #8]
0x000a1e:	str     	r1, [sp]
0x000a20:	str     	r1, [sp, #4]
0x000a22:	movs    	r7, #0xf1
0x000a24:	lsls    	r7, r7, #9
0x000a26:	movs    	r1, #0x44
0x000a28:	adds    	r2, r0, #0
0x000a2a:	adds    	r5, r0, #0
0x000a2c:	movs    	r4, #0
0x000a2e:	movs    	r3, #0
0x000a30:	adds    	r0, r7, #0
0x000a32:	bl      	#0x5324
0x000a36:	ldr     	r0, [pc, #0x1ac]
0x000a38:	movs    	r6, #7
0x000a3a:	add     	r0, sb
0x000a3c:	ldr     	r0, [r0, #8]
0x000a3e:	cmp     	r0, #0
0x000a40:	bne     	#0xa7a
0x000a42:	movs    	r1, #0
0x000a44:	movs    	r2, #0
0x000a46:	str     	r2, [sp, #8]
0x000a48:	str     	r1, [sp]
0x000a4a:	str     	r1, [sp, #4]
0x000a4c:	movs    	r1, #0xa
0x000a4e:	adds    	r2, r6, #0
0x000a50:	movs    	r3, #4
0x000a52:	adds    	r0, r7, #0
0x000a54:	bl      	#0x5324
0x000a58:	ldr     	r1, [pc, #0x188]
0x000a5a:	movs    	r2, #0
0x000a5c:	add     	r1, sb
0x000a5e:	str     	r0, [r1, #8]
0x000a60:	movs    	r1, #0
0x000a62:	str     	r1, [sp]
0x000a64:	str     	r1, [sp, #4]
0x000a66:	str     	r2, [sp, #8]
0x000a68:	adds    	r2, r6, #0
0x000a6a:	movs    	r1, #0xa
0x000a6c:	movs    	r3, #4
0x000a6e:	adds    	r0, r7, #0
0x000a70:	bl      	#0x5324
0x000a74:	ldr     	r1, [pc, #0x16c]
0x000a76:	add     	r1, sb
0x000a78:	str     	r0, [r1, #0x10]
0x000a7a:	movs    	r1, #0
0x000a7c:	str     	r1, [sp]
0x000a7e:	str     	r1, [sp, #4]
0x000a80:	movs    	r2, #0
0x000a82:	movs    	r6, #0
0x000a84:	adds    	r3, r6, #0
0x000a86:	str     	r2, [sp, #8]
0x000a88:	movs    	r1, #0x45
0x000a8a:	movs    	r0, #0xf1
0x000a8c:	lsls    	r0, r0, #9
0x000a8e:	ldr     	r2, [r5, #8]
0x000a90:	bl      	#0x5324
0x000a94:	movs    	r1, #0
0x000a96:	str     	r1, [sp]
0x000a98:	str     	r1, [sp, #4]
0x000a9a:	adds    	r7, r0, #0
0x000a9c:	movs    	r2, #0
0x000a9e:	str     	r2, [sp, #8]
0x000aa0:	movs    	r0, #0xf1
0x000aa2:	adds    	r3, r6, #0
0x000aa4:	movs    	r1, #0x45
0x000aa6:	lsls    	r0, r0, #9
0x000aa8:	ldr     	r2, [r5, #8]
0x000aaa:	bl      	#0x5324
0x000aae:	movs    	r1, #0
0x000ab0:	movs    	r2, #0
0x000ab2:	str     	r2, [sp, #8]
0x000ab4:	str     	r1, [sp]
0x000ab6:	str     	r1, [sp, #4]
0x000ab8:	adds    	r3, r0, #0
0x000aba:	movs    	r0, #0xf1
0x000abc:	movs    	r1, #0x14
0x000abe:	movs    	r2, #0x6d
0x000ac0:	lsls    	r0, r0, #9
0x000ac2:	bl      	#0x5324
0x000ac6:	movs    	r1, #0
0x000ac8:	str     	r1, [sp]
0x000aca:	str     	r1, [sp, #4]
0x000acc:	movs    	r2, #0
0x000ace:	str     	r2, [sp, #8]
0x000ad0:	movs    	r1, #0x45
0x000ad2:	adds    	r3, r6, #0
0x000ad4:	movs    	r0, #0xf1
0x000ad6:	lsls    	r0, r0, #9
0x000ad8:	ldr     	r2, [r5, #8]
0x000ada:	bl      	#0x5324
0x000ade:	ldr     	r1, [pc, #0x104]
0x000ae0:	ldr     	r6, [pc, #0x100]
0x000ae2:	add     	r1, sb
0x000ae4:	adds    	r1, #0x80
0x000ae6:	str     	r0, [r1, #8]
0x000ae8:	add     	r6, sb
0x000aea:	ldr     	r0, [r6, #0x30]
0x000aec:	cmp     	r7, r0
0x000aee:	bne     	#0xafa
0x000af0:	ldr     	r1, [r6, #8]
0x000af2:	lsls    	r0, r7, #2
0x000af4:	ldr     	r0, [r1, r0]
0x000af6:	bl      	#0x5bdc
0x000afa:	ldr     	r1, [pc, #0xe8]
0x000afc:	movs    	r2, #0
0x000afe:	add     	r1, sb
0x000b00:	adds    	r1, #0x80
0x000b02:	str     	r7, [r1, #0xc]
0x000b04:	movs    	r1, #0
0x000b06:	str     	r1, [sp]
0x000b08:	str     	r1, [sp, #4]
0x000b0a:	str     	r2, [sp, #8]
0x000b0c:	movs    	r7, #0
0x000b0e:	adds    	r3, r7, #0
0x000b10:	movs    	r2, #0x6d
0x000b12:	movs    	r1, #0xe1
0x000b14:	movs    	r0, #0xf1
0x000b16:	lsls    	r0, r0, #9
0x000b18:	bl      	#0x5324
0x000b1c:	ldr     	r1, [pc, #0xc4]
0x000b1e:	ldr     	r6, [pc, #0xc4]
0x000b20:	add     	r1, sb
0x000b22:	adds    	r1, #0x80
0x000b24:	ldr     	r1, [r1, #0xc]
0x000b26:	add     	r6, sb
0x000b28:	ldr     	r2, [r6, #0x10]
0x000b2a:	lsls    	r1, r1, #2
0x000b2c:	str     	r0, [r2, r1]
0x000b2e:	movs    	r1, #0
0x000b30:	str     	r1, [sp]
0x000b32:	str     	r1, [sp, #4]
0x000b34:	movs    	r2, #0
0x000b36:	str     	r2, [sp, #8]
0x000b38:	movs    	r1, #0x45
0x000b3a:	movs    	r0, #0xf1
0x000b3c:	adds    	r3, r7, #0
0x000b3e:	lsls    	r0, r0, #9

; ===== candidate_000bec =====
0x000bec:	push    	{r4, r5, r6, r7, lr}
0x000bee:	sub     	sp, #0x14
0x000bf0:	movs    	r1, #0
0x000bf2:	str     	r1, [sp]
0x000bf4:	str     	r1, [sp, #4]
0x000bf6:	ldr     	r7, [pc, #0x1b8]
0x000bf8:	movs    	r2, #0
0x000bfa:	adds    	r4, r0, #0
0x000bfc:	movs    	r0, #0xf1
0x000bfe:	str     	r2, [sp, #8]
0x000c00:	movs    	r1, #0x11
0x000c02:	movs    	r3, #4
0x000c04:	add     	r7, sb
0x000c06:	ldr     	r2, [r7, #0xc]
0x000c08:	lsls    	r0, r0, #9
0x000c0a:	bl      	#0x5324
0x000c0e:	adds    	r1, r7, #0
0x000c10:	ldr     	r1, [r1, #0x14]
0x000c12:	adds    	r2, r7, #0
0x000c14:	ldr     	r2, [r2, #0xc]
0x000c16:	lsls    	r1, r1, #2
0x000c18:	ldr     	r1, [r2, r1]
0x000c1a:	movs    	r0, #1
0x000c1c:	strb    	r0, [r1, #0x1c]
0x000c1e:	movs    	r1, #0
0x000c20:	movs    	r2, #0
0x000c22:	movs    	r6, #0
0x000c24:	adds    	r3, r6, #0
0x000c26:	str     	r2, [sp, #8]
0x000c28:	str     	r1, [sp]
0x000c2a:	str     	r1, [sp, #4]
0x000c2c:	movs    	r1, #0x44
0x000c2e:	adds    	r2, r4, #0
0x000c30:	movs    	r0, #0xf1
0x000c32:	movs    	r5, #0
0x000c34:	lsls    	r0, r0, #9
0x000c36:	bl      	#0x5324
0x000c3a:	movs    	r1, #0
0x000c3c:	str     	r1, [sp]
0x000c3e:	str     	r1, [sp, #4]
0x000c40:	movs    	r2, #0
0x000c42:	movs    	r1, #0x13
0x000c44:	adds    	r3, r6, #0
0x000c46:	movs    	r0, #0xf1
0x000c48:	lsls    	r0, r0, #9
0x000c4a:	str     	r2, [sp, #8]
0x000c4c:	bl      	#0x5324
0x000c50:	adds    	r1, r7, #0
0x000c52:	str     	r0, [r1, #0x28]
0x000c54:	movs    	r1, #0
0x000c56:	str     	r1, [sp]
0x000c58:	str     	r1, [sp, #4]
0x000c5a:	movs    	r2, #0
0x000c5c:	movs    	r1, #0x13
0x000c5e:	movs    	r0, #0xf1
0x000c60:	adds    	r3, r6, #0
0x000c62:	lsls    	r0, r0, #9
0x000c64:	str     	r2, [sp, #8]
0x000c66:	bl      	#0x5324
0x000c6a:	adds    	r1, r7, #0
0x000c6c:	str     	r0, [r1, #0x2c]
0x000c6e:	movs    	r1, #0
0x000c70:	str     	r1, [sp]
0x000c72:	str     	r1, [sp, #4]
0x000c74:	movs    	r2, #0
0x000c76:	str     	r2, [sp, #8]
0x000c78:	movs    	r1, #0x47
0x000c7a:	movs    	r0, #0xf1
0x000c7c:	adds    	r3, r6, #0
0x000c7e:	lsls    	r0, r0, #9
0x000c80:	ldr     	r2, [r4, #8]
0x000c82:	bl      	#0x5324
0x000c86:	movs    	r1, #0
0x000c88:	str     	r1, [sp]
0x000c8a:	str     	r1, [sp, #4]
0x000c8c:	str     	r0, [sp, #0x10]
0x000c8e:	movs    	r2, #0
0x000c90:	str     	r2, [sp, #8]
0x000c92:	movs    	r0, #0xf1
0x000c94:	movs    	r1, #0x45
0x000c96:	adds    	r3, r6, #0
0x000c98:	lsls    	r0, r0, #9
0x000c9a:	ldr     	r2, [r4, #8]
0x000c9c:	bl      	#0x5324
0x000ca0:	adds    	r6, r0, #0
0x000ca2:	cmp     	r0, #0
0x000ca4:	ble     	#0xcdc
0x000ca6:	movs    	r1, #0
0x000ca8:	movs    	r2, #0
0x000caa:	str     	r2, [sp, #8]
0x000cac:	str     	r1, [sp]
0x000cae:	str     	r1, [sp, #4]
0x000cb0:	movs    	r1, #0xa8
0x000cb2:	adds    	r2, r4, #0
0x000cb4:	movs    	r3, #0
0x000cb6:	movs    	r0, #0xf1
0x000cb8:	lsls    	r0, r0, #9
0x000cba:	bl      	#0x5324
0x000cbe:	movs    	r1, #0
0x000cc0:	str     	r1, [sp]
0x000cc2:	str     	r1, [sp, #4]
0x000cc4:	movs    	r2, #0
0x000cc6:	adds    	r3, r0, #0
0x000cc8:	movs    	r0, #0xf1
0x000cca:	str     	r2, [sp, #8]
0x000ccc:	movs    	r1, #0x36
0x000cce:	lsls    	r0, r0, #9
0x000cd0:	ldr     	r2, [r7, #0x28]
0x000cd2:	bl      	#0x5324
0x000cd6:	adds    	r5, #1
0x000cd8:	cmp     	r5, r6
0x000cda:	blt     	#0xca6
0x000cdc:	movs    	r1, #0
0x000cde:	str     	r1, [sp]
0x000ce0:	str     	r1, [sp, #4]
0x000ce2:	movs    	r2, #0
0x000ce4:	str     	r2, [sp, #8]
0x000ce6:	movs    	r1, #0x45
0x000ce8:	movs    	r3, #0
0x000cea:	movs    	r0, #0xf1
0x000cec:	lsls    	r0, r0, #9
0x000cee:	ldr     	r2, [r4, #8]
0x000cf0:	bl      	#0x5324
0x000cf4:	adds    	r6, r0, #0
0x000cf6:	movs    	r5, #0
0x000cf8:	cmp     	r0, #0
0x000cfa:	ble     	#0xd32
0x000cfc:	movs    	r1, #0
0x000cfe:	movs    	r2, #0
0x000d00:	str     	r2, [sp, #8]
0x000d02:	str     	r1, [sp]
0x000d04:	str     	r1, [sp, #4]
0x000d06:	movs    	r1, #0x91
0x000d08:	adds    	r2, r4, #0
0x000d0a:	movs    	r3, #0
0x000d0c:	movs    	r0, #0xf1
0x000d0e:	lsls    	r0, r0, #9
0x000d10:	bl      	#0x5324
0x000d14:	movs    	r1, #0
0x000d16:	str     	r1, [sp]
0x000d18:	str     	r1, [sp, #4]

; ===== candidate_000db4 =====
0x000db4:	push    	{r4, r5, r6, r7, lr}
0x000db6:	sub     	sp, #0x14
0x000db8:	adds    	r6, r0, #0
0x000dba:	movs    	r1, #0
0x000dbc:	ldr     	r0, [pc, #0x240]
0x000dbe:	str     	r1, [sp]
0x000dc0:	str     	r1, [sp, #4]
0x000dc2:	movs    	r2, #0
0x000dc4:	str     	r2, [sp, #8]
0x000dc6:	movs    	r7, #0xf1
0x000dc8:	add     	r0, sb
0x000dca:	ldr     	r2, [r0, #0x68]
0x000dcc:	lsls    	r7, r7, #9
0x000dce:	movs    	r1, #0x26
0x000dd0:	movs    	r4, #0
0x000dd2:	movs    	r3, #0
0x000dd4:	adds    	r0, r7, #0
0x000dd6:	bl      	#0x5324
0x000dda:	str     	r0, [sp, #0x10]
0x000ddc:	cmp     	r0, #0
0x000dde:	ble     	#0xe44
0x000de0:	movs    	r1, #0
0x000de2:	ldr     	r0, [pc, #0x21c]
0x000de4:	str     	r1, [sp]
0x000de6:	str     	r1, [sp, #4]
0x000de8:	movs    	r2, #0
0x000dea:	str     	r2, [sp, #8]
0x000dec:	add     	r0, sb
0x000dee:	ldr     	r2, [r0, #0x68]
0x000df0:	movs    	r1, #0x27
0x000df2:	adds    	r3, r4, #0
0x000df4:	adds    	r0, r7, #0
0x000df6:	bl      	#0x5324
0x000dfa:	adds    	r5, r0, #0
0x000dfc:	ldr     	r0, [r0]
0x000dfe:	mov     	ip, r0
0x000e00:	ldrb    	r0, [r0, #0x1a]
0x000e02:	cmp     	r0, #1
0x000e04:	bne     	#0xe10
0x000e06:	mov     	r0, ip
0x000e08:	movs    	r3, #8
0x000e0a:	ldrsh   	r0, [r0, r3]
0x000e0c:	cmp     	r0, #0
0x000e0e:	bgt     	#0xe26
0x000e10:	movs    	r1, #0
0x000e12:	movs    	r2, #0
0x000e14:	str     	r1, [sp]
0x000e16:	str     	r1, [sp, #4]
0x000e18:	movs    	r1, #0x8e
0x000e1a:	str     	r2, [sp, #8]
0x000e1c:	movs    	r3, #0
0x000e1e:	adds    	r0, r7, #0
0x000e20:	mov     	r2, ip
0x000e22:	bl      	#0x5324
0x000e26:	movs    	r1, #0
0x000e28:	movs    	r2, #0
0x000e2a:	str     	r2, [sp, #8]
0x000e2c:	str     	r1, [sp]
0x000e2e:	str     	r1, [sp, #4]
0x000e30:	movs    	r1, #9
0x000e32:	adds    	r2, r5, #0
0x000e34:	movs    	r3, #0
0x000e36:	adds    	r0, r7, #0
0x000e38:	bl      	#0x5324
0x000e3c:	ldr     	r0, [sp, #0x10]
0x000e3e:	adds    	r4, #1
0x000e40:	cmp     	r4, r0
0x000e42:	blt     	#0xde0
0x000e44:	movs    	r1, #0
0x000e46:	str     	r1, [sp]
0x000e48:	str     	r1, [sp, #4]
0x000e4a:	movs    	r2, #0
0x000e4c:	ldr     	r5, [pc, #0x1b0]
0x000e4e:	movs    	r4, #0
0x000e50:	adds    	r3, r4, #0
0x000e52:	str     	r2, [sp, #8]
0x000e54:	movs    	r1, #0x28
0x000e56:	movs    	r0, #0xf1
0x000e58:	add     	r5, sb
0x000e5a:	ldr     	r2, [r5, #0x68]
0x000e5c:	lsls    	r0, r0, #9
0x000e5e:	bl      	#0x5324
0x000e62:	movs    	r1, #0
0x000e64:	str     	r1, [sp]
0x000e66:	str     	r1, [sp, #4]
0x000e68:	movs    	r2, #0
0x000e6a:	str     	r2, [sp, #8]
0x000e6c:	movs    	r1, #0x26
0x000e6e:	adds    	r3, r4, #0
0x000e70:	movs    	r0, #0xf1
0x000e72:	lsls    	r0, r0, #9
0x000e74:	ldr     	r2, [r5, #0x6c]
0x000e76:	bl      	#0x5324
0x000e7a:	adds    	r5, r0, #0
0x000e7c:	cmp     	r0, #0
0x000e7e:	ble     	#0xeba
0x000e80:	movs    	r1, #0
0x000e82:	ldr     	r0, [pc, #0x17c]
0x000e84:	str     	r1, [sp]
0x000e86:	str     	r1, [sp, #4]
0x000e88:	movs    	r2, #0
0x000e8a:	str     	r2, [sp, #8]
0x000e8c:	add     	r0, sb
0x000e8e:	ldr     	r2, [r0, #0x6c]
0x000e90:	movs    	r0, #0xf1
0x000e92:	movs    	r1, #0x27
0x000e94:	adds    	r3, r4, #0
0x000e96:	lsls    	r0, r0, #9
0x000e98:	bl      	#0x5324
0x000e9c:	movs    	r2, #0
0x000e9e:	movs    	r1, #0
0x000ea0:	str     	r2, [sp, #8]
0x000ea2:	adds    	r2, r0, #0
0x000ea4:	str     	r1, [sp]
0x000ea6:	str     	r1, [sp, #4]
0x000ea8:	movs    	r1, #0x8c
0x000eaa:	movs    	r0, #0xf1
0x000eac:	movs    	r3, #0
0x000eae:	lsls    	r0, r0, #9
0x000eb0:	bl      	#0x5324
0x000eb4:	adds    	r4, #1
0x000eb6:	cmp     	r4, r5
0x000eb8:	blt     	#0xe80
0x000eba:	movs    	r1, #0
0x000ebc:	str     	r1, [sp]
0x000ebe:	str     	r1, [sp, #4]
0x000ec0:	movs    	r2, #0
0x000ec2:	ldr     	r5, [pc, #0x13c]
0x000ec4:	movs    	r4, #0
0x000ec6:	movs    	r7, #0xf1
0x000ec8:	lsls    	r7, r7, #9
0x000eca:	adds    	r3, r4, #0
0x000ecc:	str     	r2, [sp, #8]
0x000ece:	movs    	r1, #0x28
0x000ed0:	add     	r5, sb
0x000ed2:	ldr     	r2, [r5, #0x6c]
0x000ed4:	adds    	r0, r7, #0
0x000ed6:	bl      	#0x5324
0x000eda:	ldr     	r0, [r5, #0x70]
0x000edc:	cmp     	r0, #0
0x000ede:	ble     	#0xf0e

; ===== candidate_001008 =====
0x001008:	push    	{r4, r5, r6, r7, lr}
0x00100a:	ldr     	r5, [pc, #0x1c0]
0x00100c:	movs    	r4, #0xf1
0x00100e:	add     	r5, sb
0x001010:	ldr     	r0, [r5, #0x60]
0x001012:	lsls    	r4, r4, #9
0x001014:	movs    	r6, #0
0x001016:	cmp     	r0, #0
0x001018:	sub     	sp, #0xc
0x00101a:	bne     	#0x103a
0x00101c:	movs    	r2, #0
0x00101e:	movs    	r1, #0
0x001020:	str     	r2, [sp, #8]
0x001022:	ldr     	r2, [pc, #0x1ac]
0x001024:	str     	r1, [sp]
0x001026:	str     	r1, [sp, #4]
0x001028:	adds    	r3, r6, #0
0x00102a:	add     	r2, pc
0x00102c:	movs    	r1, #0x33
0x00102e:	adds    	r0, r4, #0
0x001030:	bl      	#0x5324
0x001034:	str     	r6, [r5, #0x54]
0x001036:	add     	sp, #0xc
0x001038:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0011f4 =====
0x0011f4:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0011f6:	sub     	sp, #0x64
0x0011f8:	adds    	r5, r1, #0
0x0011fa:	ldr     	r1, [sp, #0x70]
0x0011fc:	adds    	r4, r2, #0
0x0011fe:	ldr     	r0, [sp, #0x88]
0x001200:	ldr     	r7, [sp, #0x8c]
0x001202:	blx     	#0x20
0x001206:	adds    	r6, r0, #0
0x001208:	ldr     	r0, [pc, #0x3dc]
0x00120a:	movs    	r1, #0x3b
0x00120c:	add     	r0, sb
0x00120e:	ldr     	r2, [r0, #0x48]
0x001210:	ldr     	r0, [sp, #0x70]
0x001212:	str     	r7, [sp, #4]
0x001214:	str     	r0, [sp]
0x001216:	ldr     	r0, [sp, #0x64]
0x001218:	str     	r2, [sp, #8]
0x00121a:	adds    	r2, r0, r4
0x00121c:	subs    	r2, #0xc
0x00121e:	adds    	r3, r5, #0
0x001220:	movs    	r0, #0xf1
0x001222:	lsls    	r0, r0, #9
0x001224:	bl      	#0x5324
0x001228:	ldr     	r0, [pc, #0x3bc]
0x00122a:	subs    	r4, #0xc
0x00122c:	str     	r4, [sp, #0x6c]
0x00122e:	add     	r0, sb
0x001230:	ldr     	r1, [r0, #0x48]
0x001232:	adds    	r0, r6, #0
0x001234:	blx     	#0x20
0x001238:	muls    	r0, r6, r0
0x00123a:	adds    	r4, r0, #0
0x00123c:	adds    	r0, r4, r6
0x00123e:	cmp     	r0, r7
0x001240:	bge     	#0x1244
0x001242:	adds    	r7, r0, #0
0x001244:	str     	r7, [sp, #0x2c]
0x001246:	cmp     	r4, r7
0x001248:	bge     	#0x132e
0x00124a:	ldr     	r1, [sp, #0x88]
0x00124c:	ldr     	r0, [sp, #0x64]
0x00124e:	subs    	r1, #2
0x001250:	str     	r1, [sp, #0x60]
0x001252:	ldr     	r1, [sp, #0x64]
0x001254:	adds    	r0, #5
0x001256:	adds    	r1, #0xa
0x001258:	str     	r1, [sp, #0x58]
0x00125a:	str     	r0, [sp, #0x5c]
0x00125c:	ldr     	r1, [sp, #0x88]
0x00125e:	movs    	r2, #0
0x001260:	ldr     	r0, [sp, #0x6c]
0x001262:	str     	r1, [sp, #4]
0x001264:	movs    	r6, #0xf1
0x001266:	lsls    	r6, r6, #9
0x001268:	movs    	r1, #0x32
0x00126a:	str     	r2, [sp, #8]
0x00126c:	adds    	r3, r5, #0
0x00126e:	str     	r0, [sp]
0x001270:	adds    	r0, r6, #0
0x001272:	ldr     	r2, [sp, #0x64]
0x001274:	bl      	#0x5324
0x001278:	ldr     	r1, [pc, #0x36c]
0x00127a:	add     	r1, sb
0x00127c:	ldr     	r0, [r1, #0x48]
0x00127e:	cmp     	r0, r4
0x001280:	bne     	#0x129a
0x001282:	ldr     	r1, [sp, #0x60]
0x001284:	movs    	r2, #1
0x001286:	ldr     	r0, [sp, #0x6c]
0x001288:	str     	r1, [sp, #4]
0x00128a:	movs    	r1, #0xc4
0x00128c:	str     	r2, [sp, #8]
0x00128e:	adds    	r3, r5, #0
0x001290:	str     	r0, [sp]
0x001292:	adds    	r0, r6, #0
0x001294:	ldr     	r2, [sp, #0x64]
0x001296:	bl      	#0x5324
0x00129a:	ldr     	r1, [sp, #0x88]
0x00129c:	movs    	r2, #0
0x00129e:	ldr     	r0, [sp, #0x6c]
0x0012a0:	str     	r1, [sp, #4]
0x0012a2:	movs    	r1, #0x2f
0x0012a4:	str     	r2, [sp, #8]
0x0012a6:	adds    	r3, r5, #0
0x0012a8:	str     	r0, [sp]
0x0012aa:	adds    	r0, r6, #0
0x0012ac:	ldr     	r2, [sp, #0x64]
0x0012ae:	bl      	#0x5324
0x0012b2:	cmp     	r0, #1
0x0012b4:	bne     	#0x12da
0x0012b6:	ldr     	r1, [pc, #0x330]
0x0012b8:	add     	r1, sb
0x0012ba:	ldr     	r0, [r1, #0x48]
0x0012bc:	cmp     	r0, r4
0x0012be:	bne     	#0x12d8
0x0012c0:	ldr     	r1, [sp, #0x6c]
0x0012c2:	ldr     	r2, [sp, #0x88]
0x0012c4:	str     	r1, [sp, #4]
0x0012c6:	str     	r2, [sp, #8]
0x0012c8:	movs    	r2, #4
0x0012ca:	movs    	r1, #0x23
0x0012cc:	adds    	r0, r6, #0
0x0012ce:	ldr     	r3, [sp, #0x64]
0x0012d0:	str     	r5, [sp]
0x0012d2:	bl      	#0x5324
0x0012d6:	b       	#0x12da
0x0012d8:	str     	r4, [r1, #0x48]
0x0012da:	ldr     	r2, [pc, #0x310]
0x0012dc:	add     	r2, sb
0x0012de:	ldr     	r0, [r2, #8]
0x0012e0:	cmp     	r4, r0
0x0012e2:	bne     	#0x13a4
0x0012e4:	ldr     	r0, [pc, #0x308]
0x0012e6:	add     	r0, pc
0x0012e8:	str     	r0, [sp, #0x3c]
0x0012ea:	add     	r1, sp, #0x34
0x0012ec:	str     	r1, [sp, #4]
0x0012ee:	movs    	r0, #0
0x0012f0:	add     	r2, sp, #0x30
0x0012f2:	movs    	r7, #0
0x0012f4:	adds    	r3, r7, #0
0x0012f6:	str     	r2, [sp, #8]
0x0012f8:	str     	r0, [sp]
0x0012fa:	movs    	r1, #0x2a
0x0012fc:	adds    	r0, r6, #0
0x0012fe:	ldr     	r2, [sp, #0x3c]
0x001300:	bl      	#0x5324
0x001304:	ldr     	r0, [sp, #0x3c]
0x001306:	movs    	r6, #0xff
0x001308:	str     	r0, [sp, #0xc]
0x00130a:	ldr     	r0, [sp, #0x5c]
0x00130c:	movs    	r2, #0
0x00130e:	str     	r0, [sp, #0x10]
0x001310:	adds    	r0, r5, #5
0x001312:	movs    	r1, #0
0x001314:	str     	r7, [sp, #0x28]
0x001316:	str     	r2, [sp, #8]
0x001318:	str     	r0, [sp, #0x54]
0x00131a:	str     	r6, [sp, #0x20]
0x00131c:	str     	r7, [sp, #0x24]

; ===== candidate_00179c =====
0x00179c:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00179e:	sub     	sp, #0x3c
0x0017a0:	movs    	r1, #0
0x0017a2:	adds    	r5, r2, #0
0x0017a4:	movs    	r2, #0
0x0017a6:	str     	r1, [sp]
0x0017a8:	str     	r1, [sp, #4]
0x0017aa:	movs    	r6, #0xf1
0x0017ac:	movs    	r7, #0
0x0017ae:	adds    	r3, r7, #0
0x0017b0:	lsls    	r6, r6, #9
0x0017b2:	movs    	r1, #0x1c
0x0017b4:	adds    	r4, r0, #0
0x0017b6:	adds    	r0, r6, #0
0x0017b8:	str     	r2, [sp, #8]
0x0017ba:	bl      	#0x5324
0x0017be:	ldr     	r1, [sp, #0x48]
0x0017c0:	movs    	r2, #0
0x0017c2:	str     	r0, [sp]
0x0017c4:	str     	r1, [sp, #4]
0x0017c6:	movs    	r1, #0x32
0x0017c8:	str     	r2, [sp, #8]
0x0017ca:	adds    	r3, r5, #0
0x0017cc:	adds    	r0, r6, #0
0x0017ce:	ldr     	r2, [sp, #0x40]
0x0017d0:	bl      	#0x5324
0x0017d4:	movs    	r1, #0
0x0017d6:	movs    	r2, #0
0x0017d8:	str     	r2, [sp, #8]
0x0017da:	str     	r1, [sp]
0x0017dc:	str     	r1, [sp, #4]
0x0017de:	movs    	r1, #0xe1
0x0017e0:	movs    	r2, #0x2d
0x0017e2:	adds    	r3, r7, #0
0x0017e4:	adds    	r0, r6, #0
0x0017e6:	bl      	#0x5324
0x0017ea:	movs    	r1, #0
0x0017ec:	movs    	r2, #0
0x0017ee:	str     	r2, [sp, #8]
0x0017f0:	str     	r1, [sp]
0x0017f2:	str     	r1, [sp, #4]
0x0017f4:	movs    	r1, #0xe1
0x0017f6:	movs    	r2, #0x2e
0x0017f8:	str     	r0, [sp, #0x34]
0x0017fa:	adds    	r3, r7, #0
0x0017fc:	adds    	r0, r6, #0
0x0017fe:	bl      	#0x5324
0x001802:	str     	r0, [sp, #0x30]
0x001804:	cmp     	r4, #0
0x001806:	bne     	#0x1882
0x001808:	ldr     	r4, [pc, #0x180]
0x00180a:	add     	r4, pc
0x00180c:	add     	r2, sp, #0x30
0x00180e:	add     	r1, sp, #0x34
0x001810:	str     	r1, [sp, #4]
0x001812:	str     	r2, [sp, #8]
0x001814:	movs    	r0, #0
0x001816:	str     	r0, [sp]
0x001818:	adds    	r2, r4, #0
0x00181a:	movs    	r1, #0x2a
0x00181c:	adds    	r3, r7, #0
0x00181e:	adds    	r0, r6, #0
0x001820:	bl      	#0x5324
0x001824:	movs    	r1, #0
0x001826:	str     	r1, [sp]
0x001828:	str     	r1, [sp, #4]
0x00182a:	movs    	r2, #0
0x00182c:	movs    	r1, #0x1c
0x00182e:	adds    	r3, r7, #0
0x001830:	adds    	r0, r6, #0
0x001832:	str     	r2, [sp, #8]
0x001834:	str     	r4, [sp, #0x10]
0x001836:	bl      	#0x5324
0x00183a:	ldr     	r1, [sp, #0x34]
0x00183c:	movs    	r2, #0
0x00183e:	subs    	r0, r0, r1
0x001840:	lsrs    	r1, r0, #0x1f
0x001842:	adds    	r0, r1, r0
0x001844:	ldr     	r1, [sp, #0x40]
0x001846:	asrs    	r0, r0, #1
0x001848:	adds    	r0, r0, r1
0x00184a:	str     	r0, [sp, #0x14]
0x00184c:	ldr     	r0, [sp, #0x48]
0x00184e:	ldr     	r1, [sp, #0x30]
0x001850:	str     	r7, [sp, #0x28]
0x001852:	subs    	r0, r0, r1
0x001854:	lsrs    	r1, r0, #0x1f
0x001856:	adds    	r0, r1, r0
0x001858:	asrs    	r0, r0, #1
0x00185a:	adds    	r0, r0, r5
0x00185c:	str     	r0, [sp, #0x18]
0x00185e:	movs    	r0, #0xff
0x001860:	str     	r0, [sp, #0x20]
0x001862:	str     	r0, [sp, #0x1c]
0x001864:	movs    	r0, #0xc8
0x001866:	movs    	r1, #0
0x001868:	str     	r0, [sp, #0x24]
0x00186a:	str     	r1, [sp, #4]
0x00186c:	str     	r1, [sp]
0x00186e:	movs    	r1, #0x56
0x001870:	str     	r2, [sp, #8]
0x001872:	adds    	r3, r7, #0
0x001874:	adds    	r0, r6, #0
0x001876:	add     	r2, sp, #0x10
0x001878:	str     	r7, [sp, #0x2c]
0x00187a:	bl      	#0x5324
0x00187e:	add     	sp, #0x4c
0x001880:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0019a8 =====
0x0019a8:	push    	{r4, r5, r6, r7, lr}
0x0019aa:	sub     	sp, #0x54
0x0019ac:	movs    	r0, #0x19
0x0019ae:	movs    	r1, #0
0x0019b0:	str     	r0, [sp, #0x48]
0x0019b2:	str     	r1, [sp]
0x0019b4:	str     	r1, [sp, #4]
0x0019b6:	movs    	r6, #0
0x0019b8:	movs    	r2, #0
0x0019ba:	adds    	r3, r6, #0
0x0019bc:	movs    	r1, #0x1c
0x0019be:	movs    	r0, #0xf1
0x0019c0:	lsls    	r0, r0, #9
0x0019c2:	str     	r2, [sp, #8]
0x0019c4:	bl      	#0x5324
0x0019c8:	adds    	r4, r0, #0
0x0019ca:	ldr     	r0, [pc, #0x388]
0x0019cc:	add     	r0, sb
0x0019ce:	ldr     	r0, [r0, #0x44]
0x0019d0:	ldr     	r0, [r0, #0x14]
0x0019d2:	str     	r0, [sp, #0x44]
0x0019d4:	movs    	r0, #0x32
0x0019d6:	str     	r0, [sp, #0x40]
0x0019d8:	bl      	#0x3b1c
0x0019dc:	adds    	r5, r0, #0
0x0019de:	movs    	r1, #0
0x0019e0:	movs    	r0, #0x19
0x0019e2:	movs    	r3, #0x1a
0x0019e4:	str     	r3, [sp, #0x38]
0x0019e6:	str     	r1, [sp]
0x0019e8:	str     	r1, [sp, #4]
0x0019ea:	movs    	r1, #0xff
0x0019ec:	adds    	r3, r6, #0
0x0019ee:	str     	r0, [sp, #0x34]
0x0019f0:	str     	r0, [sp, #0x30]
0x0019f2:	movs    	r2, #0
0x0019f4:	movs    	r0, #0xf1
0x0019f6:	adds    	r1, #0x26
0x0019f8:	movs    	r7, #0
0x0019fa:	lsls    	r0, r0, #9
0x0019fc:	str     	r2, [sp, #8]
0x0019fe:	bl      	#0x5324
0x001a02:	movs    	r1, #0
0x001a04:	str     	r1, [sp]
0x001a06:	str     	r1, [sp, #4]
0x001a08:	movs    	r1, #0xff
0x001a0a:	movs    	r2, #0
0x001a0c:	adds    	r3, r6, #0
0x001a0e:	adds    	r1, #0x4a
0x001a10:	movs    	r0, #0xf1
0x001a12:	lsls    	r0, r0, #9
0x001a14:	str     	r2, [sp, #8]
0x001a16:	bl      	#0x5324
0x001a1a:	movs    	r1, #0
0x001a1c:	movs    	r2, #0
0x001a1e:	str     	r2, [sp, #8]
0x001a20:	str     	r1, [sp]
0x001a22:	str     	r1, [sp, #4]
0x001a24:	movs    	r1, #0xe1
0x001a26:	movs    	r2, #0xed
0x001a28:	adds    	r3, r6, #0
0x001a2a:	movs    	r0, #0xf1
0x001a2c:	lsls    	r0, r0, #9
0x001a2e:	bl      	#0x5324
0x001a32:	cmp     	r0, #0
0x001a34:	ble     	#0x1b1a
0x001a36:	movs    	r1, #0
0x001a38:	str     	r1, [sp]
0x001a3a:	str     	r1, [sp, #4]
0x001a3c:	movs    	r1, #0xff
0x001a3e:	movs    	r2, #0
0x001a40:	adds    	r1, #0x25
0x001a42:	movs    	r3, #0
0x001a44:	movs    	r0, #0xf1
0x001a46:	lsls    	r0, r0, #9
0x001a48:	str     	r2, [sp, #8]
0x001a4a:	bl      	#0x5324
0x001a4e:	adds    	r1, r5, #0
0x001a50:	ldr     	r0, [sp, #0x30]
0x001a52:	blx     	#0x20
0x001a56:	subs    	r0, #1
0x001a58:	ldr     	r1, [pc, #0x2f8]
0x001a5a:	str     	r0, [sp, #0x3c]
0x001a5c:	add     	r1, sb
0x001a5e:	str     	r0, [r1, #0x4c]
0x001a60:	cmp     	r5, #0x7d
0x001a62:	ble     	#0x1a66
0x001a64:	movs    	r5, #0x7d
0x001a66:	movs    	r2, #0
0x001a68:	movs    	r1, #0
0x001a6a:	movs    	r0, #0
0x001a6c:	bl      	#0x52d4
0x001a70:	movs    	r1, #1
0x001a72:	movs    	r2, #1
0x001a74:	str     	r2, [sp, #8]
0x001a76:	str     	r1, [sp]
0x001a78:	str     	r1, [sp, #4]
0x001a7a:	movs    	r6, #0
0x001a7c:	adds    	r3, r6, #0
0x001a7e:	movs    	r1, #0x55
0x001a80:	movs    	r2, #0
0x001a82:	movs    	r0, #0xf1
0x001a84:	lsls    	r0, r0, #9
0x001a86:	bl      	#0x5324
0x001a8a:	add     	r1, sp, #0x50
0x001a8c:	str     	r1, [sp, #4]
0x001a8e:	movs    	r0, #0
0x001a90:	str     	r0, [sp]
0x001a92:	add     	r2, sp, #0x4c
0x001a94:	str     	r2, [sp, #8]
0x001a96:	movs    	r0, #0xf1
0x001a98:	movs    	r1, #0x2a
0x001a9a:	adds    	r3, r6, #0
0x001a9c:	lsls    	r0, r0, #9
0x001a9e:	ldr     	r2, [sp, #0x44]
0x001aa0:	bl      	#0x5324
0x001aa4:	ldr     	r1, [sp, #0x48]
0x001aa6:	movs    	r2, #0
0x001aa8:	str     	r1, [sp, #4]
0x001aaa:	movs    	r1, #0x31
0x001aac:	movs    	r0, #0xf1
0x001aae:	lsls    	r0, r0, #9
0x001ab0:	str     	r2, [sp, #8]
0x001ab2:	str     	r4, [sp]
0x001ab4:	ldr     	r3, [sp, #0x38]
0x001ab6:	bl      	#0x5324
0x001aba:	ldr     	r0, [sp, #0x44]
0x001abc:	movs    	r1, #0
0x001abe:	str     	r0, [sp, #0x10]
0x001ac0:	ldr     	r0, [sp, #0x50]
0x001ac2:	movs    	r2, #0
0x001ac4:	subs    	r0, r4, r0
0x001ac6:	asrs    	r0, r0, #1
0x001ac8:	str     	r0, [sp, #0x14]
0x001aca:	movs    	r0, #0x1f
0x001acc:	str     	r0, [sp, #0x18]
0x001ace:	movs    	r0, #0xff
0x001ad0:	str     	r0, [sp, #0x20]
0x001ad2:	str     	r0, [sp, #0x24]
0x001ad4:	str     	r1, [sp, #4]
0x001ad6:	str     	r1, [sp]

; ===== candidate_001d5c =====
0x001d5c:	push    	{r4, r5, r6, r7, lr}
0x001d5e:	sub     	sp, #0x74
0x001d60:	movs    	r3, #0x32
0x001d62:	str     	r3, [sp, #0x64]
0x001d64:	movs    	r1, #0
0x001d66:	str     	r1, [sp]
0x001d68:	str     	r1, [sp, #4]
0x001d6a:	movs    	r5, #0xf1
0x001d6c:	movs    	r4, #0
0x001d6e:	movs    	r2, #0
0x001d70:	adds    	r3, r4, #0
0x001d72:	lsls    	r5, r5, #9
0x001d74:	movs    	r1, #0x1c
0x001d76:	adds    	r0, r5, #0
0x001d78:	str     	r2, [sp, #8]
0x001d7a:	bl      	#0x5324
0x001d7e:	str     	r0, [sp, #0x58]
0x001d80:	ldr     	r0, [pc, #0x3dc]
0x001d82:	movs    	r6, #0x19
0x001d84:	add     	r0, sb
0x001d86:	ldr     	r0, [r0, #0x30]
0x001d88:	bl      	#0x3dd4
0x001d8c:	adds    	r7, r0, #0
0x001d8e:	movs    	r1, #0
0x001d90:	str     	r1, [sp, #4]
0x001d92:	movs    	r0, #0
0x001d94:	movs    	r1, #0xff
0x001d96:	movs    	r2, #0
0x001d98:	adds    	r1, #0x4a
0x001d9a:	str     	r0, [sp, #0x4c]
0x001d9c:	str     	r0, [sp]
0x001d9e:	movs    	r3, #0
0x001da0:	adds    	r0, r5, #0
0x001da2:	str     	r2, [sp, #8]
0x001da4:	bl      	#0x5324
0x001da8:	ldr     	r0, [pc, #0x3b4]
0x001daa:	add     	r0, sb
0x001dac:	ldr     	r0, [r0, #8]
0x001dae:	cmp     	r0, #0
0x001db0:	beq     	#0x1dc0
0x001db2:	ldr     	r1, [pc, #0x3ac]
0x001db4:	add     	r1, sb
0x001db6:	ldr     	r1, [r1, #0x30]
0x001db8:	lsls    	r1, r1, #2
0x001dba:	ldr     	r0, [r0, r1]
0x001dbc:	cmp     	r0, #0
0x001dbe:	bne     	#0x1dd8
0x001dc0:	movs    	r1, #0
0x001dc2:	str     	r1, [sp]
0x001dc4:	str     	r1, [sp, #4]
0x001dc6:	movs    	r2, #0
0x001dc8:	movs    	r1, #0x2c
0x001dca:	adds    	r3, r4, #0
0x001dcc:	adds    	r0, r5, #0
0x001dce:	str     	r2, [sp, #8]
0x001dd0:	bl      	#0x5324
0x001dd4:	add     	sp, #0x74
0x001dd6:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0024a8 =====
0x0024a8:	push    	{r4, r5, r6, r7, lr}
0x0024aa:	ldr     	r5, [pc, #0x3e0]
0x0024ac:	sub     	sp, #0x64
0x0024ae:	add     	r5, pc
0x0024b0:	movs    	r3, #0x1a
0x0024b2:	str     	r3, [sp, #0x40]
0x0024b4:	movs    	r1, #0
0x0024b6:	movs    	r2, #0
0x0024b8:	str     	r2, [sp, #8]
0x0024ba:	str     	r1, [sp]
0x0024bc:	str     	r1, [sp, #4]
0x0024be:	movs    	r0, #0x5a
0x0024c0:	movs    	r7, #0
0x0024c2:	movs    	r4, #0xf1
0x0024c4:	lsls    	r4, r4, #9
0x0024c6:	adds    	r3, r7, #0
0x0024c8:	str     	r0, [sp, #0x4c]
0x0024ca:	movs    	r1, #0xe1
0x0024cc:	movs    	r2, #0xff
0x0024ce:	movs    	r6, #0x19
0x0024d0:	adds    	r0, r4, #0
0x0024d2:	bl      	#0x5324
0x0024d6:	cmp     	r0, #0
0x0024d8:	beq     	#0x2504
0x0024da:	movs    	r1, #0
0x0024dc:	movs    	r2, #0
0x0024de:	str     	r2, [sp, #8]
0x0024e0:	str     	r1, [sp]
0x0024e2:	str     	r1, [sp, #4]
0x0024e4:	movs    	r1, #0x14
0x0024e6:	movs    	r2, #0xff
0x0024e8:	adds    	r3, r7, #0
0x0024ea:	adds    	r0, r4, #0
0x0024ec:	bl      	#0x5324
0x0024f0:	movs    	r1, #0
0x0024f2:	movs    	r2, #0
0x0024f4:	str     	r1, [sp]
0x0024f6:	str     	r1, [sp, #4]
0x0024f8:	ldr     	r1, [pc, #0x394]
0x0024fa:	str     	r2, [sp, #8]
0x0024fc:	adds    	r3, r7, #0
0x0024fe:	ldr     	r0, [pc, #0x394]
0x002500:	bl      	#0x5324
0x002504:	movs    	r1, #0
0x002506:	str     	r1, [sp]
0x002508:	str     	r1, [sp, #4]
0x00250a:	movs    	r1, #0xff
0x00250c:	movs    	r2, #0
0x00250e:	adds    	r1, #0x26
0x002510:	adds    	r3, r7, #0
0x002512:	adds    	r0, r4, #0
0x002514:	str     	r2, [sp, #8]
0x002516:	bl      	#0x5324
0x00251a:	movs    	r1, #0
0x00251c:	movs    	r2, #0
0x00251e:	str     	r2, [sp, #8]
0x002520:	str     	r1, [sp]
0x002522:	str     	r1, [sp, #4]
0x002524:	movs    	r1, #0xe1
0x002526:	movs    	r2, #0xed
0x002528:	adds    	r3, r7, #0
0x00252a:	movs    	r0, #0xf1
0x00252c:	lsls    	r0, r0, #9
0x00252e:	bl      	#0x5324
0x002532:	cmp     	r0, #0
0x002534:	ble     	#0x261c
0x002536:	movs    	r1, #0
0x002538:	str     	r1, [sp]
0x00253a:	str     	r1, [sp, #4]
0x00253c:	movs    	r1, #0xff
0x00253e:	movs    	r2, #0
0x002540:	adds    	r1, #0x25
0x002542:	movs    	r3, #0
0x002544:	movs    	r0, #0xf1
0x002546:	lsls    	r0, r0, #9
0x002548:	str     	r2, [sp, #8]
0x00254a:	bl      	#0x5324
0x00254e:	movs    	r1, #0
0x002550:	str     	r1, [sp]
0x002552:	str     	r1, [sp, #4]
0x002554:	movs    	r2, #0
0x002556:	movs    	r7, #0
0x002558:	adds    	r3, r7, #0
0x00255a:	movs    	r1, #0x40
0x00255c:	movs    	r0, #0xf1
0x00255e:	lsls    	r0, r0, #9
0x002560:	str     	r2, [sp, #8]
0x002562:	bl      	#0x5324
0x002566:	movs    	r1, #1
0x002568:	movs    	r2, #1
0x00256a:	str     	r2, [sp, #8]
0x00256c:	str     	r1, [sp]
0x00256e:	str     	r1, [sp, #4]
0x002570:	movs    	r1, #0x55
0x002572:	movs    	r2, #0
0x002574:	adds    	r3, r7, #0
0x002576:	movs    	r0, #0xf1
0x002578:	lsls    	r0, r0, #9
0x00257a:	bl      	#0x5324
0x00257e:	add     	r2, sp, #0x54
0x002580:	add     	r1, sp, #0x58
0x002582:	movs    	r0, #0
0x002584:	str     	r0, [sp]
0x002586:	str     	r1, [sp, #4]
0x002588:	str     	r2, [sp, #8]
0x00258a:	adds    	r3, r7, #0
0x00258c:	adds    	r2, r5, #0
0x00258e:	movs    	r1, #0x2a
0x002590:	movs    	r0, #0xf1
0x002592:	lsls    	r0, r0, #9
0x002594:	bl      	#0x5324
0x002598:	movs    	r1, #0
0x00259a:	movs    	r2, #0
0x00259c:	str     	r2, [sp, #8]
0x00259e:	str     	r1, [sp]
0x0025a0:	str     	r1, [sp, #4]
0x0025a2:	movs    	r1, #0xe1
0x0025a4:	movs    	r2, #0x2a
0x0025a6:	adds    	r3, r7, #0
0x0025a8:	movs    	r0, #0xf1
0x0025aa:	lsls    	r0, r0, #9
0x0025ac:	bl      	#0x5324
0x0025b0:	ldr     	r1, [sp, #0x54]
0x0025b2:	movs    	r2, #0
0x0025b4:	adds    	r4, r0, r1
0x0025b6:	movs    	r1, #0
0x0025b8:	str     	r1, [sp]
0x0025ba:	str     	r1, [sp, #4]
0x0025bc:	movs    	r1, #0x1c
0x0025be:	movs    	r0, #0xf1
0x0025c0:	adds    	r3, r7, #0
0x0025c2:	lsls    	r0, r0, #9
0x0025c4:	str     	r2, [sp, #8]
0x0025c6:	bl      	#0x5324
0x0025ca:	str     	r0, [sp]
0x0025cc:	movs    	r2, #0
0x0025ce:	movs    	r0, #0xf1
0x0025d0:	movs    	r1, #0x32
0x0025d2:	lsls    	r0, r0, #9
0x0025d4:	str     	r2, [sp, #8]
0x0025d6:	ldr     	r3, [sp, #0x40]

; ===== candidate_003b1c =====
0x003b1c:	push    	{r4, r5, r6, r7, lr}
0x003b1e:	ldr     	r6, [pc, #0xb8]
0x003b20:	movs    	r4, #0
0x003b22:	mvns    	r0, r4
0x003b24:	sub     	sp, #0xc
0x003b26:	add     	r6, sb
0x003b28:	str     	r0, [r6, #8]
0x003b2a:	str     	r0, [r6, #0xc]
0x003b2c:	str     	r0, [r6, #0x10]
0x003b2e:	str     	r0, [r6, #0x14]
0x003b30:	str     	r0, [r6, #0x18]
0x003b32:	str     	r0, [r6, #0x1c]
0x003b34:	str     	r0, [r6, #0x20]
0x003b36:	str     	r0, [r6, #0x24]
0x003b38:	str     	r0, [r6, #0x28]
0x003b3a:	ldr     	r0, [pc, #0xa0]
0x003b3c:	movs    	r5, #0
0x003b3e:	add     	r0, sb
0x003b40:	ldr     	r1, [r0, #0x18]
0x003b42:	cmp     	r1, #0
0x003b44:	ble     	#0x3b4c
0x003b46:	movs    	r5, #0x19
0x003b48:	str     	r4, [r6, #8]
0x003b4a:	movs    	r4, #1
0x003b4c:	ldr     	r1, [r0, #0x20]
0x003b4e:	cmp     	r1, #0
0x003b50:	ble     	#0x3b58
0x003b52:	adds    	r5, #0x19
0x003b54:	str     	r4, [r6, #0xc]
0x003b56:	adds    	r4, #1
0x003b58:	ldr     	r1, [r0, #0x1c]
0x003b5a:	cmp     	r1, #0
0x003b5c:	ble     	#0x3b64
0x003b5e:	adds    	r5, #0x19
0x003b60:	str     	r4, [r6, #0x10]
0x003b62:	adds    	r4, #1
0x003b64:	adds    	r7, r0, #0
0x003b66:	ldr     	r0, [r0, #0x24]
0x003b68:	cmp     	r0, #0
0x003b6a:	ble     	#0x3b72
0x003b6c:	adds    	r5, #0x19
0x003b6e:	str     	r4, [r6, #0x14]
0x003b70:	adds    	r4, #1
0x003b72:	movs    	r1, #0
0x003b74:	ldr     	r7, [pc, #0x64]
0x003b76:	str     	r1, [sp]
0x003b78:	str     	r1, [sp, #4]
0x003b7a:	movs    	r2, #0
0x003b7c:	str     	r2, [sp, #8]
0x003b7e:	add     	r7, sb
0x003b80:	ldr     	r2, [r7, #0x28]
0x003b82:	movs    	r7, #0xf1
0x003b84:	lsls    	r7, r7, #9
0x003b86:	movs    	r1, #0x26
0x003b88:	movs    	r3, #0
0x003b8a:	adds    	r0, r7, #0
0x003b8c:	bl      	#0x5324
0x003b90:	movs    	r1, #0x19
0x003b92:	muls    	r1, r0, r1
0x003b94:	adds    	r5, r1, r5
0x003b96:	cmp     	r0, #0
0x003b98:	ble     	#0x3ba0
0x003b9a:	str     	r4, [r6, #0x18]
0x003b9c:	adds    	r4, r4, r0
0x003b9e:	str     	r4, [r6, #0x1c]
0x003ba0:	movs    	r1, #0
0x003ba2:	ldr     	r0, [pc, #0x38]
0x003ba4:	str     	r1, [sp]
0x003ba6:	str     	r1, [sp, #4]
0x003ba8:	movs    	r2, #0
0x003baa:	str     	r2, [sp, #8]
0x003bac:	add     	r0, sb
0x003bae:	ldr     	r2, [r0, #0x2c]
0x003bb0:	movs    	r1, #0x26
0x003bb2:	movs    	r3, #0
0x003bb4:	adds    	r0, r7, #0
0x003bb6:	bl      	#0x5324
0x003bba:	movs    	r1, #0x19
0x003bbc:	muls    	r1, r0, r1
0x003bbe:	adds    	r1, r1, r5
0x003bc0:	cmp     	r0, #0
0x003bc2:	ble     	#0x3bca
0x003bc4:	str     	r4, [r6, #0x20]
0x003bc6:	adds    	r4, r4, r0
0x003bc8:	str     	r4, [r6, #0x24]
0x003bca:	cmp     	r1, #0
0x003bcc:	ble     	#0x3bd2
0x003bce:	adds    	r1, #0x32
0x003bd0:	str     	r4, [r6, #0x28]
0x003bd2:	adds    	r0, r1, #0
0x003bd4:	add     	sp, #0xc
0x003bd6:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003be0 =====
0x003be0:	push    	{r4, r5, r6, r7, lr}
0x003be2:	sub     	sp, #0xc
0x003be4:	adds    	r7, r1, #0
0x003be6:	movs    	r1, #0
0x003be8:	movs    	r2, #0
0x003bea:	str     	r2, [sp, #8]
0x003bec:	adds    	r6, r0, #0
0x003bee:	adds    	r2, r0, #0
0x003bf0:	str     	r1, [sp]
0x003bf2:	str     	r1, [sp, #4]
0x003bf4:	movs    	r1, #0x26
0x003bf6:	movs    	r0, #0xf1
0x003bf8:	movs    	r3, #0
0x003bfa:	lsls    	r0, r0, #9
0x003bfc:	bl      	#0x5324
0x003c00:	adds    	r5, r0, #0
0x003c02:	movs    	r4, #0
0x003c04:	cmp     	r0, #0
0x003c06:	ble     	#0x3c2c
0x003c08:	movs    	r1, #0
0x003c0a:	movs    	r2, #0
0x003c0c:	str     	r2, [sp, #8]
0x003c0e:	str     	r1, [sp]
0x003c10:	str     	r1, [sp, #4]
0x003c12:	adds    	r3, r4, #0
0x003c14:	adds    	r2, r6, #0
0x003c16:	movs    	r1, #0x27
0x003c18:	movs    	r0, #0xf1
0x003c1a:	lsls    	r0, r0, #9
0x003c1c:	bl      	#0x5324
0x003c20:	ldr     	r1, [r0, #8]
0x003c22:	cmp     	r1, r7
0x003c24:	beq     	#0x3c2e
0x003c26:	adds    	r4, #1
0x003c28:	cmp     	r4, r5
0x003c2a:	blt     	#0x3c08
0x003c2c:	movs    	r0, #0
0x003c2e:	add     	sp, #0xc
0x003c30:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003d80 =====
0x003d80:	push    	{r3, lr}
0x003d82:	movs    	r1, #0
0x003d84:	str     	r1, [sp]
0x003d86:	mov     	r1, sp
0x003d88:	bl      	#0x3c34
0x003d8c:	ldr     	r1, [sp]
0x003d8e:	cmp     	r1, #1
0x003d90:	beq     	#0x3d9e
0x003d92:	cmp     	r1, #2
0x003d94:	beq     	#0x3da4
0x003d96:	cmp     	r1, #4
0x003d98:	ldr     	r0, [r0]
0x003d9a:	bne     	#0x3daa
0x003d9c:	pop     	{r3, pc}

; ===== candidate_003dac =====
0x003dac:	push    	{lr}
0x003dae:	sub     	sp, #0xc
0x003db0:	movs    	r1, #0
0x003db2:	movs    	r2, #0
0x003db4:	str     	r2, [sp, #8]
0x003db6:	str     	r1, [sp]
0x003db8:	str     	r1, [sp, #4]
0x003dba:	movs    	r1, #0xe1
0x003dbc:	movs    	r2, #0x15
0x003dbe:	movs    	r3, #0
0x003dc0:	movs    	r0, #0xf1
0x003dc2:	lsls    	r0, r0, #9
0x003dc4:	bl      	#0x5324
0x003dc8:	subs    	r0, #0x64
0x003dca:	blx     	#0x2e8
0x003dce:	adds    	r0, r1, #0
0x003dd0:	add     	sp, #0xc
0x003dd2:	pop     	{pc}

; ===== candidate_003e38 =====
0x003e38:	push    	{r4, r5, r6, r7, lr}
0x003e3a:	sub     	sp, #0xc
0x003e3c:	movs    	r1, #0
0x003e3e:	str     	r1, [sp]
0x003e40:	str     	r1, [sp, #4]
0x003e42:	ldr     	r7, [pc, #0xac]
0x003e44:	movs    	r2, #0
0x003e46:	movs    	r6, #0xf1
0x003e48:	lsls    	r6, r6, #9
0x003e4a:	str     	r2, [sp, #8]
0x003e4c:	movs    	r1, #0x27
0x003e4e:	adds    	r3, r0, #0
0x003e50:	add     	r7, sb
0x003e52:	ldr     	r2, [r7, #0x68]
0x003e54:	adds    	r0, r6, #0
0x003e56:	bl      	#0x5324
0x003e5a:	ldr     	r4, [r0]
0x003e5c:	movs    	r1, #0
0x003e5e:	str     	r1, [sp]
0x003e60:	str     	r1, [sp, #4]
0x003e62:	movs    	r2, #0
0x003e64:	str     	r2, [sp, #8]
0x003e66:	movs    	r1, #0x8d
0x003e68:	adds    	r5, r0, #0
0x003e6a:	adds    	r3, r0, #0
0x003e6c:	adds    	r0, r6, #0
0x003e6e:	ldr     	r2, [r7, #0x68]
0x003e70:	bl      	#0x5324
0x003e74:	ldrb    	r0, [r4, #0x1a]
0x003e76:	movs    	r7, #0
0x003e78:	cmp     	r0, #0
0x003e7a:	bne     	#0x3e94
0x003e7c:	movs    	r1, #0
0x003e7e:	movs    	r2, #0
0x003e80:	str     	r2, [sp, #8]
0x003e82:	str     	r1, [sp]
0x003e84:	str     	r1, [sp, #4]
0x003e86:	movs    	r1, #0xa9
0x003e88:	adds    	r2, r4, #0
0x003e8a:	movs    	r3, #1
0x003e8c:	adds    	r0, r6, #0
0x003e8e:	bl      	#0x5324
0x003e92:	b       	#0x3ed6
0x003e94:	movs    	r1, #0
0x003e96:	str     	r1, [sp]
0x003e98:	str     	r1, [sp, #4]
0x003e9a:	movs    	r2, #0
0x003e9c:	str     	r2, [sp, #8]
0x003e9e:	movs    	r1, #0x90
0x003ea0:	adds    	r3, r7, #0
0x003ea2:	adds    	r0, r6, #0
0x003ea4:	ldr     	r2, [r4]
0x003ea6:	bl      	#0x5324
0x003eaa:	cmp     	r0, #0
0x003eac:	bne     	#0x3ece
0x003eae:	ldrh    	r0, [r4, #8]
0x003eb0:	ldr     	r1, [r5, #4]
0x003eb2:	movs    	r2, #0
0x003eb4:	adds    	r0, r0, r1
0x003eb6:	strh    	r0, [r4, #8]
0x003eb8:	movs    	r1, #0
0x003eba:	str     	r1, [sp]
0x003ebc:	str     	r1, [sp, #4]
0x003ebe:	str     	r2, [sp, #8]
0x003ec0:	adds    	r2, r4, #0
0x003ec2:	movs    	r1, #0xa9
0x003ec4:	movs    	r3, #1
0x003ec6:	adds    	r0, r6, #0
0x003ec8:	bl      	#0x5324
0x003ecc:	b       	#0x3ed6
0x003ece:	ldrh    	r1, [r0, #8]
0x003ed0:	ldr     	r2, [r5, #4]
0x003ed2:	adds    	r1, r1, r2
0x003ed4:	strh    	r1, [r0, #8]
0x003ed6:	movs    	r1, #0
0x003ed8:	movs    	r2, #0
0x003eda:	str     	r2, [sp, #8]
0x003edc:	str     	r1, [sp]
0x003ede:	str     	r1, [sp, #4]
0x003ee0:	movs    	r1, #9
0x003ee2:	adds    	r2, r5, #0
0x003ee4:	adds    	r3, r7, #0
0x003ee6:	adds    	r0, r6, #0
0x003ee8:	bl      	#0x5324
0x003eec:	add     	sp, #0xc
0x003eee:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003ef4 =====
0x003ef4:	push    	{r4, r5, r6, lr}
0x003ef6:	ldr     	r5, [pc, #0x58]
0x003ef8:	sub     	sp, #0x10
0x003efa:	add     	r5, sb
0x003efc:	str     	r0, [r5, #0x44]
0x003efe:	movs    	r4, #0
0x003f00:	adds    	r6, r1, #0
0x003f02:	str     	r4, [r5, #0x48]
0x003f04:	movs    	r1, #0
0x003f06:	str     	r1, [sp]
0x003f08:	str     	r1, [sp, #4]
0x003f0a:	movs    	r2, #0
0x003f0c:	movs    	r1, #0x34
0x003f0e:	adds    	r3, r4, #0
0x003f10:	movs    	r0, #0xf1
0x003f12:	lsls    	r0, r0, #9
0x003f14:	str     	r2, [sp, #8]
0x003f16:	bl      	#0x5324
0x003f1a:	str     	r6, [r5, #0x5c]
0x003f1c:	movs    	r1, #0
0x003f1e:	movs    	r2, #0
0x003f20:	str     	r2, [sp, #8]
0x003f22:	str     	r1, [sp]
0x003f24:	str     	r1, [sp, #4]
0x003f26:	movs    	r1, #0x14
0x003f28:	movs    	r2, #0x17
0x003f2a:	movs    	r3, #0xf0
0x003f2c:	movs    	r0, #0xf1
0x003f2e:	lsls    	r0, r0, #9
0x003f30:	bl      	#0x5324
0x003f34:	movs    	r1, #0
0x003f36:	str     	r1, [sp]
0x003f38:	str     	r1, [sp, #4]
0x003f3a:	movs    	r2, #0
0x003f3c:	movs    	r1, #0xe6
0x003f3e:	adds    	r3, r4, #0
0x003f40:	movs    	r0, #0xf1
0x003f42:	lsls    	r0, r0, #9
0x003f44:	str     	r2, [sp, #8]
0x003f46:	bl      	#0x5324
0x003f4a:	add     	sp, #0x10
0x003f4c:	pop     	{r4, r5, r6, pc}

; ===== candidate_003f54 =====
0x003f54:	push    	{r4, r5, r6, r7, lr}
0x003f56:	sub     	sp, #0xc
0x003f58:	movs    	r1, #0
0x003f5a:	adds    	r7, r0, #0
0x003f5c:	str     	r1, [sp]
0x003f5e:	str     	r1, [sp, #4]
0x003f60:	movs    	r6, #0
0x003f62:	movs    	r2, #0
0x003f64:	adds    	r3, r6, #0
0x003f66:	movs    	r1, #0x13
0x003f68:	movs    	r0, #0xf1
0x003f6a:	lsls    	r0, r0, #9
0x003f6c:	str     	r2, [sp, #8]
0x003f6e:	bl      	#0x5324
0x003f72:	movs    	r1, #0
0x003f74:	movs    	r2, #0
0x003f76:	str     	r2, [sp, #8]
0x003f78:	str     	r1, [sp]
0x003f7a:	str     	r1, [sp, #4]
0x003f7c:	adds    	r4, r0, #0
0x003f7e:	movs    	r0, #0xf1
0x003f80:	movs    	r1, #0x14
0x003f82:	movs    	r2, #0x81
0x003f84:	movs    	r3, #0
0x003f86:	lsls    	r0, r0, #9
0x003f88:	bl      	#0x5324
0x003f8c:	movs    	r1, #0
0x003f8e:	str     	r1, [sp]
0x003f90:	str     	r1, [sp, #4]
0x003f92:	movs    	r2, #0
0x003f94:	movs    	r1, #0x34
0x003f96:	movs    	r3, #0
0x003f98:	movs    	r0, #0xf1
0x003f9a:	lsls    	r0, r0, #9
0x003f9c:	str     	r2, [sp, #8]
0x003f9e:	bl      	#0x5324
0x003fa2:	ldr     	r5, [pc, #0x3e0]
0x003fa4:	add     	r5, pc
0x003fa6:	cmp     	r7, #0
0x003fa8:	beq     	#0x408e
0x003faa:	movs    	r1, #0
0x003fac:	movs    	r2, #0
0x003fae:	adds    	r3, r7, #0
0x003fb0:	movs    	r7, #0xf1
0x003fb2:	str     	r2, [sp, #8]
0x003fb4:	str     	r1, [sp]
0x003fb6:	str     	r1, [sp, #4]
0x003fb8:	movs    	r1, #0x14
0x003fba:	movs    	r2, #0x82
0x003fbc:	lsls    	r7, r7, #9
0x003fbe:	adds    	r0, r7, #0
0x003fc0:	bl      	#0x5324
0x003fc4:	movs    	r1, #0
0x003fc6:	movs    	r2, #0
0x003fc8:	str     	r2, [sp, #8]
0x003fca:	str     	r1, [sp]
0x003fcc:	str     	r1, [sp, #4]
0x003fce:	movs    	r1, #0xe1
0x003fd0:	movs    	r2, #0x17
0x003fd2:	adds    	r3, r6, #0
0x003fd4:	adds    	r0, r7, #0
0x003fd6:	bl      	#0x5324
0x003fda:	cmp     	r0, #0xf0
0x003fdc:	bne     	#0x3fe8
0x003fde:	ldr     	r1, [pc, #0x3a8]
0x003fe0:	movs    	r0, #1
0x003fe2:	add     	r1, sb
0x003fe4:	strb    	r0, [r1, #1]
0x003fe6:	b       	#0x3fee
0x003fe8:	ldr     	r0, [pc, #0x39c]
0x003fea:	add     	r0, sb
0x003fec:	strb    	r6, [r0, #1]
0x003fee:	movs    	r1, #0
0x003ff0:	movs    	r2, #0
0x003ff2:	str     	r2, [sp, #8]
0x003ff4:	str     	r1, [sp]
0x003ff6:	str     	r1, [sp, #4]
0x003ff8:	movs    	r1, #0xe1
0x003ffa:	movs    	r2, #0x17
0x003ffc:	adds    	r3, r6, #0
0x003ffe:	adds    	r0, r7, #0
0x004000:	bl      	#0x5324
0x004004:	cmp     	r0, #0xf0
0x004006:	beq     	#0x4038
0x004008:	movs    	r2, #0
0x00400a:	movs    	r1, #0
0x00400c:	str     	r2, [sp, #8]
0x00400e:	ldr     	r2, [pc, #0x37c]
0x004010:	str     	r1, [sp]
0x004012:	str     	r1, [sp, #4]
0x004014:	adds    	r3, r5, #0
0x004016:	add     	r2, pc
0x004018:	movs    	r1, #0x35
0x00401a:	adds    	r0, r7, #0
0x00401c:	bl      	#0x5324
0x004020:	movs    	r1, #0
0x004022:	adds    	r3, r0, #0
0x004024:	movs    	r2, #0
0x004026:	str     	r2, [sp, #8]
0x004028:	str     	r1, [sp]
0x00402a:	str     	r1, [sp, #4]
0x00402c:	movs    	r1, #0x36
0x00402e:	adds    	r2, r4, #0
0x004030:	movs    	r0, #0xf1
0x004032:	lsls    	r0, r0, #9
0x004034:	bl      	#0x5324
0x004038:	movs    	r1, #0
0x00403a:	movs    	r2, #0
0x00403c:	str     	r2, [sp, #8]
0x00403e:	str     	r1, [sp]
0x004040:	str     	r1, [sp, #4]
0x004042:	movs    	r1, #0xe1
0x004044:	movs    	r2, #0x82
0x004046:	adds    	r3, r6, #0
0x004048:	adds    	r0, r7, #0
0x00404a:	bl      	#0x5324
0x00404e:	ldr     	r0, [r0, #4]
0x004050:	adds    	r3, r0, #1
0x004052:	beq     	#0x410e
0x004054:	movs    	r1, #0
0x004056:	movs    	r2, #0
0x004058:	str     	r2, [sp, #8]
0x00405a:	str     	r1, [sp]
0x00405c:	str     	r1, [sp, #4]
0x00405e:	movs    	r1, #0xe1
0x004060:	movs    	r2, #0x82
0x004062:	adds    	r3, r6, #0
0x004064:	adds    	r0, r7, #0
0x004066:	bl      	#0x5324
0x00406a:	ldr     	r0, [r0, #8]
0x00406c:	adds    	r3, r0, #1
0x00406e:	beq     	#0x410e
0x004070:	movs    	r2, #0
0x004072:	movs    	r1, #0
0x004074:	str     	r2, [sp, #8]
0x004076:	ldr     	r2, [pc, #0x318]
0x004078:	str     	r1, [sp]
0x00407a:	str     	r1, [sp, #4]
0x00407c:	adds    	r3, r5, #0
0x00407e:	add     	r2, pc
0x004080:	movs    	r1, #0x35

; ===== candidate_0043d4 =====
0x0043d4:	push    	{r4, r5, r6, r7, lr}
0x0043d6:	ldr     	r5, [pc, #0xe8]
0x0043d8:	sub     	sp, #0xc
0x0043da:	movs    	r0, #1
0x0043dc:	add     	r5, sb
0x0043de:	strb    	r0, [r5]
0x0043e0:	movs    	r1, #0
0x0043e2:	str     	r1, [sp]
0x0043e4:	str     	r1, [sp, #4]
0x0043e6:	movs    	r2, #0
0x0043e8:	movs    	r1, #0x34
0x0043ea:	movs    	r0, #0xf1
0x0043ec:	movs    	r4, #0
0x0043ee:	movs    	r3, #0
0x0043f0:	lsls    	r0, r0, #9
0x0043f2:	str     	r2, [sp, #8]
0x0043f4:	bl      	#0x5324
0x0043f8:	movs    	r1, #0
0x0043fa:	movs    	r2, #0
0x0043fc:	str     	r2, [sp, #8]
0x0043fe:	str     	r1, [sp]
0x004400:	str     	r1, [sp, #4]
0x004402:	movs    	r1, #0x14
0x004404:	movs    	r2, #0x17
0x004406:	movs    	r3, #0xed
0x004408:	movs    	r0, #0xf1
0x00440a:	lsls    	r0, r0, #9
0x00440c:	bl      	#0x5324
0x004410:	movs    	r2, #0
0x004412:	mvns    	r1, r2
0x004414:	ldr     	r3, [pc, #0xac]
0x004416:	str     	r1, [sp]
0x004418:	str     	r1, [sp, #4]
0x00441a:	str     	r2, [sp, #8]
0x00441c:	add     	r3, pc
0x00441e:	movs    	r1, #5
0x004420:	movs    	r0, #0xf1
0x004422:	lsls    	r0, r0, #9
0x004424:	ldr     	r2, [r5, #0x34]
0x004426:	bl      	#0x5324
0x00442a:	str     	r0, [r5, #0x34]
0x00442c:	movs    	r1, #0
0x00442e:	str     	r1, [sp]
0x004430:	str     	r1, [sp, #4]
0x004432:	movs    	r2, #0
0x004434:	movs    	r6, #4
0x004436:	adds    	r3, r6, #0
0x004438:	str     	r2, [sp, #8]
0x00443a:	movs    	r1, #0x11
0x00443c:	movs    	r0, #0xf1
0x00443e:	lsls    	r0, r0, #9
0x004440:	ldr     	r2, [r5, #8]
0x004442:	bl      	#0x5324
0x004446:	adds    	r5, r0, #0
0x004448:	cmp     	r0, #0
0x00444a:	ble     	#0x4498
0x00444c:	ldr     	r7, [pc, #0x70]
0x00444e:	add     	r7, sb
0x004450:	ldr     	r0, [r7, #8]
0x004452:	lsls    	r6, r4, #2
0x004454:	ldr     	r3, [r0, r6]
0x004456:	cmp     	r3, #0
0x004458:	beq     	#0x4492
0x00445a:	movs    	r2, #0
0x00445c:	movs    	r1, #0
0x00445e:	str     	r2, [sp, #8]
0x004460:	adds    	r2, r3, #0
0x004462:	str     	r1, [sp]
0x004464:	str     	r1, [sp, #4]
0x004466:	movs    	r1, #0x11
0x004468:	movs    	r3, #4
0x00446a:	movs    	r0, #0xf1
0x00446c:	lsls    	r0, r0, #9
0x00446e:	bl      	#0x5324
0x004472:	movs    	r1, #0
0x004474:	cmp     	r0, #0
0x004476:	ble     	#0x4492
0x004478:	ldr     	r2, [r7, #8]
0x00447a:	ldr     	r2, [r2, r6]
0x00447c:	lsls    	r3, r1, #2
0x00447e:	ldr     	r3, [r2, r3]
0x004480:	ldrb    	r3, [r3, #0x1c]
0x004482:	cmp     	r3, #0
0x004484:	bne     	#0x448c
0x004486:	str     	r1, [r7, #0x14]
0x004488:	str     	r4, [r7, #0x30]
0x00448a:	b       	#0x4492
0x00448c:	adds    	r1, #1
0x00448e:	cmp     	r1, r0
0x004490:	blt     	#0x447c
0x004492:	adds    	r4, #1
0x004494:	cmp     	r4, r5
0x004496:	blt     	#0x4450
0x004498:	ldr     	r0, [pc, #0x24]
0x00449a:	movs    	r3, #0
0x00449c:	add     	r0, sb
0x00449e:	ldr     	r1, [r0, #0x30]
0x0044a0:	ldr     	r2, [r0, #8]
0x0044a2:	lsls    	r1, r1, #2
0x0044a4:	ldr     	r1, [r2, r1]
0x0044a6:	movs    	r2, #0
0x0044a8:	str     	r1, [r0, #0xc]
0x0044aa:	movs    	r1, #0
0x0044ac:	str     	r1, [sp]
0x0044ae:	str     	r1, [sp, #4]
0x0044b0:	movs    	r1, #0xba
0x0044b2:	movs    	r0, #0xf1
0x0044b4:	lsls    	r0, r0, #9
0x0044b6:	str     	r2, [sp, #8]
0x0044b8:	bl      	#0x5324
0x0044bc:	add     	sp, #0xc
0x0044be:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0044c8 =====
0x0044c8:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0044ca:	sub     	sp, #0xc
0x0044cc:	movs    	r1, #0
0x0044ce:	str     	r1, [sp]
0x0044d0:	str     	r1, [sp, #4]
0x0044d2:	movs    	r6, #0xf1
0x0044d4:	movs    	r5, #0
0x0044d6:	adds    	r4, r3, #0
0x0044d8:	movs    	r2, #0
0x0044da:	adds    	r3, r5, #0
0x0044dc:	lsls    	r6, r6, #9
0x0044de:	movs    	r1, #0xba
0x0044e0:	adds    	r0, r6, #0
0x0044e2:	str     	r2, [sp, #8]
0x0044e4:	bl      	#0x5324
0x0044e8:	movs    	r1, #0
0x0044ea:	movs    	r2, #0
0x0044ec:	str     	r2, [sp, #8]
0x0044ee:	str     	r1, [sp]
0x0044f0:	str     	r1, [sp, #4]
0x0044f2:	movs    	r1, #0xe1
0x0044f4:	movs    	r2, #0x80
0x0044f6:	adds    	r3, r5, #0
0x0044f8:	adds    	r0, r6, #0
0x0044fa:	bl      	#0x5324
0x0044fe:	cmp     	r0, #0
0x004500:	bne     	#0x4546
0x004502:	movs    	r1, #0
0x004504:	movs    	r2, #0
0x004506:	str     	r2, [sp, #8]
0x004508:	str     	r1, [sp]
0x00450a:	str     	r1, [sp, #4]
0x00450c:	movs    	r1, #0xe1
0x00450e:	movs    	r2, #0x80
0x004510:	adds    	r3, r5, #0
0x004512:	adds    	r0, r6, #0
0x004514:	bl      	#0x5324
0x004518:	movs    	r2, #0
0x00451a:	mvns    	r1, r2
0x00451c:	ldr     	r3, [pc, #0x224]
0x00451e:	str     	r1, [sp]
0x004520:	str     	r1, [sp, #4]
0x004522:	str     	r2, [sp, #8]
0x004524:	add     	r3, pc
0x004526:	adds    	r2, r0, #0
0x004528:	movs    	r1, #5
0x00452a:	adds    	r0, r6, #0
0x00452c:	bl      	#0x5324
0x004530:	movs    	r1, #0
0x004532:	movs    	r2, #0
0x004534:	str     	r2, [sp, #8]
0x004536:	str     	r1, [sp]
0x004538:	str     	r1, [sp, #4]
0x00453a:	movs    	r1, #0x14
0x00453c:	movs    	r2, #0x80
0x00453e:	adds    	r3, r0, #0
0x004540:	adds    	r0, r6, #0
0x004542:	bl      	#0x5324
0x004546:	movs    	r0, #0x11
0x004548:	bl      	#0x3d80
0x00454c:	cmp     	r0, #1
0x00454e:	bne     	#0x4566
0x004550:	movs    	r1, #0
0x004552:	movs    	r2, #0
0x004554:	str     	r2, [sp, #8]
0x004556:	str     	r1, [sp]
0x004558:	str     	r1, [sp, #4]
0x00455a:	movs    	r1, #0x9c
0x00455c:	movs    	r2, #0x12
0x00455e:	adds    	r3, r5, #0
0x004560:	adds    	r0, r6, #0
0x004562:	bl      	#0x5324
0x004566:	movs    	r1, #0
0x004568:	movs    	r2, #0
0x00456a:	str     	r2, [sp, #8]
0x00456c:	str     	r1, [sp]
0x00456e:	str     	r1, [sp, #4]
0x004570:	movs    	r1, #0x14
0x004572:	movs    	r2, #0x7e
0x004574:	adds    	r3, r5, #0
0x004576:	adds    	r0, r6, #0
0x004578:	bl      	#0x5324
0x00457c:	ldr     	r7, [pc, #0x1c8]
0x00457e:	movs    	r0, #0
0x004580:	add     	r7, sb
0x004582:	adds    	r1, r7, #0
0x004584:	str     	r0, [r7, #0x40]
0x004586:	str     	r0, [r1, #0x54]
0x004588:	ldr     	r0, [sp, #0xc]
0x00458a:	adds    	r1, #0x80
0x00458c:	str     	r0, [r1, #0x10]
0x00458e:	ldr     	r0, [sp, #0x10]
0x004590:	str     	r0, [r1, #0x14]
0x004592:	adds    	r0, r7, #0
0x004594:	ldr     	r3, [r0, #0x60]
0x004596:	cmp     	r3, #0
0x004598:	beq     	#0x45b0
0x00459a:	movs    	r1, #0
0x00459c:	movs    	r2, #0
0x00459e:	str     	r2, [sp, #8]
0x0045a0:	str     	r1, [sp]
0x0045a2:	str     	r1, [sp, #4]
0x0045a4:	movs    	r1, #9
0x0045a6:	adds    	r2, r3, #0
0x0045a8:	adds    	r0, r6, #0
0x0045aa:	adds    	r3, r5, #0
0x0045ac:	bl      	#0x5324
0x0045b0:	ldr     	r0, [sp, #0x14]
0x0045b2:	cmp     	r0, #0
0x0045b4:	beq     	#0x45da
0x0045b6:	movs    	r2, #0
0x0045b8:	movs    	r1, #0
0x0045ba:	ldr     	r3, [pc, #0x190]
0x0045bc:	str     	r1, [sp]
0x0045be:	str     	r1, [sp, #4]
0x0045c0:	str     	r2, [sp, #8]
0x0045c2:	add     	r3, pc
0x0045c4:	movs    	r1, #0x35
0x0045c6:	adds    	r0, r6, #0
0x0045c8:	ldr     	r2, [sp, #0x14]
0x0045ca:	bl      	#0x5324
0x0045ce:	str     	r0, [r7, #0x60]
0x0045d0:	cmp     	r0, #0
0x0045d2:	bne     	#0x45de
0x0045d4:	str     	r5, [r7, #0x54]
0x0045d6:	str     	r5, [r7, #0x64]
0x0045d8:	b       	#0x45e2
0x0045da:	str     	r5, [r7, #0x60]
0x0045dc:	b       	#0x45d4
0x0045de:	movs    	r0, #1
0x0045e0:	str     	r0, [r7, #0x64]
0x0045e2:	ldr     	r0, [r7, #0x64]
0x0045e4:	str     	r0, [r7, #0x54]
0x0045e6:	ldr     	r3, [r7, #0x58]
0x0045e8:	cmp     	r3, #0
0x0045ea:	beq     	#0x4602
0x0045ec:	movs    	r1, #0
0x0045ee:	movs    	r2, #0
0x0045f0:	str     	r2, [sp, #8]
0x0045f2:	str     	r1, [sp]
0x0045f4:	str     	r1, [sp, #4]

; ===== candidate_0047a0 =====
0x0047a0:	push    	{r4, r5, r6, r7, lr}
0x0047a2:	ldr     	r5, [pc, #0x300]
0x0047a4:	adds    	r7, r0, #0
0x0047a6:	add     	r5, sb
0x0047a8:	ldr     	r0, [r5, #8]
0x0047aa:	sub     	sp, #0xc
0x0047ac:	cmp     	r0, #0
0x0047ae:	beq     	#0x481e
0x0047b0:	ldr     	r1, [r5, #0x30]
0x0047b2:	lsls    	r1, r1, #2
0x0047b4:	ldr     	r0, [r0, r1]
0x0047b6:	cmp     	r0, #0
0x0047b8:	beq     	#0x481e
0x0047ba:	movs    	r1, #0
0x0047bc:	str     	r1, [sp]
0x0047be:	str     	r1, [sp, #4]
0x0047c0:	movs    	r2, #0
0x0047c2:	movs    	r6, #4
0x0047c4:	adds    	r3, r6, #0
0x0047c6:	str     	r2, [sp, #8]
0x0047c8:	movs    	r1, #0x11
0x0047ca:	movs    	r0, #0xf1
0x0047cc:	lsls    	r0, r0, #9
0x0047ce:	ldr     	r2, [r5, #0xc]
0x0047d0:	bl      	#0x5324
0x0047d4:	movs    	r1, #0
0x0047d6:	str     	r1, [sp]
0x0047d8:	str     	r1, [sp, #4]
0x0047da:	adds    	r4, r0, #0
0x0047dc:	movs    	r2, #0
0x0047de:	str     	r2, [sp, #8]
0x0047e0:	movs    	r0, #0xf1
0x0047e2:	adds    	r3, r6, #0
0x0047e4:	movs    	r1, #0x11
0x0047e6:	lsls    	r0, r0, #9
0x0047e8:	ldr     	r2, [r5, #8]
0x0047ea:	bl      	#0x5324
0x0047ee:	movs    	r2, #0
0x0047f0:	movs    	r1, #0
0x0047f2:	str     	r2, [sp, #8]
0x0047f4:	str     	r1, [sp]
0x0047f6:	str     	r1, [sp, #4]
0x0047f8:	adds    	r6, r0, #0
0x0047fa:	ldr     	r0, [r5, #0x30]
0x0047fc:	ldr     	r1, [r5, #0x10]
0x0047fe:	lsls    	r0, r0, #2
0x004800:	ldr     	r3, [r1, r0]
0x004802:	movs    	r0, #0xf1
0x004804:	movs    	r1, #0x14
0x004806:	movs    	r2, #0x6d
0x004808:	lsls    	r0, r0, #9
0x00480a:	bl      	#0x5324
0x00480e:	subs    	r7, #2
0x004810:	cmp     	r7, #0x13
0x004812:	bhs     	#0x481e
0x004814:	adr     	r3, #0xc
0x004816:	adds    	r3, r3, r7
0x004818:	ldrh    	r3, [r3, r7]
0x00481a:	lsls    	r3, r3, #1
0x00481c:	add     	pc, r3
0x00481e:	add     	sp, #0xc
0x004820:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_004ab4 =====
0x004ab4:	push    	{r4, r5, r6, r7, lr}
0x004ab6:	ldr     	r1, [pc, #0x3bc]
0x004ab8:	adds    	r4, r0, #0
0x004aba:	add     	r1, sb
0x004abc:	ldr     	r7, [r1, #4]
0x004abe:	ldr     	r1, [pc, #0x3b8]
0x004ac0:	ldr     	r0, [pc, #0x3b4]
0x004ac2:	add     	r1, sb
0x004ac4:	subs    	r1, #0x54
0x004ac6:	movs    	r5, #0xf1
0x004ac8:	lsls    	r5, r5, #9
0x004aca:	ldr     	r2, [r1, #0x40]
0x004acc:	ldr     	r3, [r1, #0x64]
0x004ace:	movs    	r6, #6
0x004ad0:	cmp     	r4, #0xd
0x004ad2:	ldr     	r1, [r1, #0x54]
0x004ad4:	sub     	sp, #0xc
0x004ad6:	add     	r0, sb
0x004ad8:	beq     	#0x4b38
0x004ada:	bgt     	#0x4b02
0x004adc:	cmp     	r4, #2
0x004ade:	beq     	#0x4aec
0x004ae0:	cmp     	r4, #5
0x004ae2:	beq     	#0x4b0e
0x004ae4:	cmp     	r4, #8
0x004ae6:	beq     	#0x4b38
0x004ae8:	cmp     	r4, #0xc
0x004aea:	bne     	#0x4afe
0x004aec:	ldr     	r4, [pc, #0x388]
0x004aee:	add     	r4, sb
0x004af0:	subs    	r4, #0x54
0x004af2:	cmp     	r1, #0
0x004af4:	bne     	#0x4b18
0x004af6:	cmp     	r2, #0
0x004af8:	ble     	#0x4b18
0x004afa:	subs    	r2, #1
0x004afc:	str     	r2, [r4, #0x40]
0x004afe:	add     	sp, #0xc
0x004b00:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_004f20 =====
0x004f20:	push    	{r4, r5, r6, r7, lr}
0x004f22:	ldr     	r4, [pc, #0x110]
0x004f24:	adds    	r1, r0, #0
0x004f26:	add     	r4, sb
0x004f28:	subs    	r4, #0x48
0x004f2a:	ldr     	r0, [pc, #0x108]
0x004f2c:	movs    	r6, #0xf1
0x004f2e:	lsls    	r6, r6, #9
0x004f30:	movs    	r5, #0
0x004f32:	cmp     	r1, #0xd
0x004f34:	ldr     	r7, [r4, #0x4c]
0x004f36:	sub     	sp, #0xc
0x004f38:	add     	r0, sb
0x004f3a:	beq     	#0x5000
0x004f3c:	bgt     	#0x4f6c
0x004f3e:	cmp     	r1, #2
0x004f40:	beq     	#0x4f4e
0x004f42:	cmp     	r1, #5
0x004f44:	beq     	#0x4f78
0x004f46:	cmp     	r1, #8
0x004f48:	beq     	#0x5000
0x004f4a:	cmp     	r1, #0xc
0x004f4c:	bne     	#0x4f68
0x004f4e:	cmp     	r7, #0
0x004f50:	ble     	#0x4f68
0x004f52:	movs    	r2, #0
0x004f54:	movs    	r1, #0
0x004f56:	str     	r1, [sp, #4]
0x004f58:	str     	r2, [sp, #8]
0x004f5a:	adds    	r2, r7, #0
0x004f5c:	movs    	r1, #0x29
0x004f5e:	str     	r0, [sp]
0x004f60:	adds    	r3, r5, #0
0x004f62:	adds    	r0, r6, #0
0x004f64:	bl      	#0x5324
0x004f68:	add     	sp, #0xc
0x004f6a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_005038 =====
0x005038:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00503a:	sub     	sp, #0xc
0x00503c:	adds    	r4, r1, #0
0x00503e:	movs    	r1, #0
0x005040:	adds    	r5, r2, #0
0x005042:	movs    	r2, #0
0x005044:	str     	r2, [sp, #8]
0x005046:	str     	r1, [sp]
0x005048:	str     	r1, [sp, #4]
0x00504a:	movs    	r7, #0xf1
0x00504c:	adds    	r6, r3, #0
0x00504e:	movs    	r3, #0
0x005050:	lsls    	r7, r7, #9
0x005052:	movs    	r1, #0xe1
0x005054:	movs    	r2, #0xc4
0x005056:	adds    	r0, r7, #0
0x005058:	bl      	#0x5324
0x00505c:	cmp     	r0, #0
0x00505e:	bne     	#0x5076
0x005060:	movs    	r1, #0
0x005062:	movs    	r2, #0
0x005064:	str     	r2, [sp, #8]
0x005066:	str     	r1, [sp]
0x005068:	str     	r1, [sp, #4]
0x00506a:	movs    	r1, #0x14
0x00506c:	movs    	r2, #0xc4
0x00506e:	movs    	r3, #1
0x005070:	adds    	r0, r7, #0
0x005072:	bl      	#0x5324
0x005076:	ldr     	r0, [sp, #0xc]
0x005078:	cmp     	r0, #0x19
0x00507a:	bhs     	#0x5086
0x00507c:	adr     	r3, #8
0x00507e:	adds    	r3, r3, r0
0x005080:	ldrh    	r3, [r3, r0]
0x005082:	lsls    	r3, r3, #1
0x005084:	add     	pc, r3
0x005086:	b       	#0x5230
0x005088:	lsls    	r6, r7, #2
0x00508a:	lsls    	r1, r1, #3
0x00508c:	lsls    	r1, r7, #2
0x00508e:	lsls    	r7, r4, #2
0x005090:	lsls    	r4, r4, #2
0x005092:	lsls    	r5, r3, #2
0x005094:	lsls    	r0, r3, #2
0x005096:	lsls    	r3, r2, #2
0x005098:	lsls    	r6, r1, #2
0x00509a:	lsls    	r1, r1, #2
0x00509c:	lsls    	r0, r7, #1
0x00509e:	lsls    	r3, r6, #1
0x0050a0:	lsls    	r6, r5, #1
0x0050a2:	lsls    	r6, r4, #1
0x0050a4:	lsls    	r2, r4, #1
0x0050a6:	lsls    	r6, r3, #1
0x0050a8:	lsls    	r2, r3, #1
0x0050aa:	lsls    	r4, r2, #1
0x0050ac:	lsls    	r3, r0, #1
0x0050ae:	movs    	r6, r7
0x0050b0:	movs    	r5, r5
0x0050b2:	movs    	r0, r5
0x0050b4:	movs    	r3, r4
0x0050b6:	movs    	r6, r3
0x0050b8:	movs    	r1, r3
0x0050ba:	adds    	r0, r4, #0
0x0050bc:	bl      	#0x3d80
0x0050c0:	add     	sp, #0x1c
0x0050c2:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00524c =====
0x00524c:	push    	{r3, r4, r5, lr}
0x00524e:	ldr     	r4, [pc, #0x74]
0x005250:	add     	r4, pc
0x005252:	ldr     	r0, [r4, #0x38]
0x005254:	movs    	r1, #0x14
0x005256:	ldr     	r2, [r0, #0x64]
0x005258:	ldr     	r0, [pc, #0x6c]
0x00525a:	add     	r0, pc
0x00525c:	blx     	r2
0x00525e:	movs    	r5, #0
0x005260:	mvns    	r5, r5
0x005262:	cmp     	r0, r5
0x005264:	bne     	#0x526a
0x005266:	adds    	r0, r5, #0
0x005268:	pop     	{r3, r4, r5, pc}

; ===== candidate_0052d4 =====
0x0052d4:	push    	{r4, lr}
0x0052d6:	sub     	sp, #0x10
0x0052d8:	lsls    	r0, r0, #0x18
0x0052da:	lsrs    	r0, r0, #0x18
0x0052dc:	str     	r0, [sp]
0x0052de:	ldr     	r0, [pc, #0x38]
0x0052e0:	lsls    	r2, r2, #0x18
0x0052e2:	lsls    	r1, r1, #0x18
0x0052e4:	lsrs    	r1, r1, #0x18
0x0052e6:	lsrs    	r2, r2, #0x18
0x0052e8:	str     	r2, [sp, #8]
0x0052ea:	str     	r1, [sp, #4]
0x0052ec:	add     	r0, pc
0x0052ee:	ldr     	r0, [r0, #0x38]
0x0052f0:	adds    	r1, r0, #0
0x0052f2:	adds    	r1, #0xff
0x0052f4:	adds    	r1, #0x41
0x0052f6:	ldr     	r2, [r1, #0x34]
0x0052f8:	ldr     	r1, [r1, #0x30]
0x0052fa:	ldr     	r2, [r2]
0x0052fc:	ldr     	r1, [r1]
0x0052fe:	lsls    	r3, r2, #0x10
0x005300:	lsls    	r2, r1, #0x10
0x005302:	asrs    	r2, r2, #0x10
0x005304:	asrs    	r3, r3, #0x10
0x005306:	adds    	r0, #0xff
0x005308:	adds    	r0, #0xc1
0x00530a:	ldr     	r4, [r0, #0x28]
0x00530c:	movs    	r1, #0
0x00530e:	movs    	r0, #0
0x005310:	blx     	r4
0x005312:	add     	sp, #0x10
0x005314:	pop     	{r4, pc}

; ===== candidate_005324 =====
0x005324:	push    	{r4, r5, r6, r7, lr}
0x005326:	adds    	r5, r1, #0
0x005328:	adds    	r4, r0, #0
0x00532a:	adds    	r6, r2, #0
0x00532c:	ldr     	r2, [pc, #0x28]
0x00532e:	sub     	sp, #0x14
0x005330:	mov     	ip, r3
0x005332:	add     	r2, pc
0x005334:	ldr     	r0, [sp, #0x2c]
0x005336:	ldr     	r1, [sp, #0x30]
0x005338:	ldr     	r7, [sp, #0x28]
0x00533a:	ldr     	r3, [r2, #0x3c]
0x00533c:	movs    	r2, #2
0x00533e:	str     	r2, [sp, #0xc]
0x005340:	str     	r1, [sp, #8]
0x005342:	str     	r0, [sp, #4]
0x005344:	str     	r7, [sp]
0x005346:	ldr     	r0, [r3, #0xc]
0x005348:	adds    	r1, r5, #0
0x00534a:	adds    	r2, r6, #0
0x00534c:	ldr     	r7, [r0, #0x28]
0x00534e:	adds    	r0, r4, #0
0x005350:	mov     	r3, ip
0x005352:	blx     	r7
0x005354:	add     	sp, #0x14
0x005356:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_005360 =====
0x005360:	push    	{r4, lr}
0x005362:	movs    	r2, #0
0x005364:	add     	r0, pc
0x005366:	ldr     	r4, [r0, #0x3c]
0x005368:	sub     	sp, #0x10
0x00536a:	movs    	r1, #0
0x00536c:	str     	r1, [sp, #4]
0x00536e:	str     	r1, [sp, #8]
0x005370:	str     	r2, [sp, #0xc]
0x005372:	str     	r2, [sp]
0x005374:	ldr     	r0, [r4, #0xc]
0x005376:	ldr     	r2, [r0, #0x24]
0x005378:	ldr     	r4, [r0, #0x28]
0x00537a:	blx     	r4
0x00537c:	add     	sp, #0x10
0x00537e:	pop     	{r4, pc}

; ===== candidate_005384 =====
0x005384:	push    	{r4, lr}
0x005386:	ldr     	r0, [pc, #0x24]
0x005388:	sub     	sp, #0x10
0x00538a:	add     	r0, pc
0x00538c:	ldr     	r3, [r0, #0x3c]
0x00538e:	movs    	r2, #0
0x005390:	movs    	r1, #0
0x005392:	str     	r1, [sp, #4]
0x005394:	str     	r1, [sp, #8]
0x005396:	str     	r2, [sp, #0xc]
0x005398:	str     	r2, [sp]
0x00539a:	ldr     	r0, [r3, #0xc]
0x00539c:	movs    	r3, #0
0x00539e:	ldr     	r2, [r0, #0x24]
0x0053a0:	ldr     	r4, [r0, #0x28]
0x0053a2:	movs    	r1, #1
0x0053a4:	blx     	r4
0x0053a6:	add     	sp, #0x10
0x0053a8:	pop     	{r4, pc}

; ===== candidate_0053c4 =====
0x0053c4:	push    	{r4, lr}
0x0053c6:	sub     	sp, #0x10
0x0053c8:	movs    	r2, #0
0x0053ca:	movs    	r1, #0
0x0053cc:	str     	r2, [sp, #8]
0x0053ce:	ldr     	r2, [pc, #0x3c]
0x0053d0:	str     	r1, [sp]
0x0053d2:	str     	r1, [sp, #4]
0x0053d4:	movs    	r3, #0
0x0053d6:	add     	r2, pc
0x0053d8:	ldr     	r1, [pc, #0x34]
0x0053da:	ldr     	r0, [pc, #0x38]
0x0053dc:	bl      	#0x5324
0x0053e0:	ldr     	r3, [pc, #0x38]
0x0053e2:	ldr     	r4, [pc, #0x34]
0x0053e4:	add     	r3, sb
0x0053e6:	ldr     	r3, [r3]
0x0053e8:	movs    	r2, #0x41
0x0053ea:	movs    	r1, #0
0x0053ec:	add     	r4, sb
0x0053ee:	adds    	r0, r4, #0
0x0053f0:	blx     	r3
0x0053f2:	bl      	#0x53b0
0x0053f6:	ldr     	r3, [pc, #0x28]
0x0053f8:	adds    	r1, r0, #0
0x0053fa:	add     	r3, sb
0x0053fc:	ldr     	r3, [r3]
0x0053fe:	movs    	r2, #0x41
0x005400:	adds    	r0, r4, #0
0x005402:	blx     	r3
0x005404:	movs    	r0, #0
0x005406:	add     	sp, #0x10
0x005408:	pop     	{r4, pc}

; ===== candidate_005428 =====
0x005428:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00542a:	adds    	r7, r3, #0
0x00542c:	adds    	r6, r2, #0
0x00542e:	adds    	r5, r0, #0
0x005430:	ldr     	r0, [r0]
0x005432:	sub     	sp, #4
0x005434:	mov     	r1, sb
0x005436:	str     	r1, [sp]
0x005438:	movs    	r4, #0
0x00543a:	blx     	#0x2e0
0x00543e:	ldr     	r0, [sp, #8]
0x005440:	cmp     	r0, #0xb
0x005442:	bhs     	#0x54b0
0x005444:	adr     	r3, #4
0x005446:	ldrb    	r3, [r3, r0]
0x005448:	lsls    	r3, r3, #1
0x00544a:	add     	pc, r3
0x00544c:	lsrs    	r5, r0, #0x1c
0x00544e:	subs    	r4, r3, #4
0x005450:	movs    	r4, #0x21
0x005452:	adds    	r1, #0x27
0x005454:	adds    	r1, #0x2b
0x005456:	movs    	r7, r5
0x005458:	ldr     	r1, [pc, #0x60]
0x00545a:	ldr     	r0, [r5, #0xc]
0x00545c:	add     	r1, sb
0x00545e:	str     	r0, [r1, #0x14]
0x005460:	bl      	#0x328
0x005464:	bl      	#0x53c4
0x005468:	adds    	r4, r0, #0
0x00546a:	b       	#0x54b0
0x00546c:	ldr     	r0, [r6]
0x00546e:	cmp     	r0, #8
0x005470:	bne     	#0x547a
0x005472:	bl      	#0x5320
0x005476:	adds    	r4, r0, #0
0x005478:	b       	#0x54b0
0x00547a:	ldr     	r1, [r6, #4]
0x00547c:	ldr     	r2, [r6, #8]
0x00547e:	bl      	#0x531c
0x005482:	adds    	r4, r0, #0
0x005484:	b       	#0x54b0
0x005486:	bl      	#0x56b8
0x00548a:	b       	#0x54b0
0x00548c:	str     	r7, [r5, #0xc]
0x00548e:	b       	#0x54b0
0x005490:	bl      	#0x5424
0x005494:	b       	#0x54b0
0x005496:	bl      	#0x54f4
0x00549a:	b       	#0x54b0
0x00549c:	ldr     	r0, [pc, #0x1c]
0x00549e:	add     	r0, sb
0x0054a0:	str     	r7, [r0, #0x1c]
0x0054a2:	b       	#0x54b0
0x0054a4:	ldr     	r0, [pc, #0x14]
0x0054a6:	add     	r0, sb
0x0054a8:	str     	r6, [r0, #0x20]
0x0054aa:	b       	#0x54b0
0x0054ac:	ldr     	r4, [pc, #0x10]
0x0054ae:	add     	r4, pc
0x0054b0:	ldr     	r1, [sp]
0x0054b2:	add     	sp, #0x14
0x0054b4:	adds    	r0, r4, #0
0x0054b6:	mov     	sb, r1
0x0054b8:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0054c4 =====
0x0054c4:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0054c6:	sub     	sp, #0xc
0x0054c8:	ldr     	r0, [sp, #0x38]
0x0054ca:	ldr     	r4, [sp, #0x3c]
0x0054cc:	ldr     	r6, [sp, #0x34]
0x0054ce:	ldr     	r0, [r0]
0x0054d0:	mov     	r7, sb
0x0054d2:	movs    	r5, #0
0x0054d4:	blx     	#0x2e0
0x0054d8:	cmp     	r4, #0
0x0054da:	beq     	#0x54ea
0x0054dc:	ldr     	r1, [sp, #0x30]
0x0054de:	str     	r6, [sp, #4]
0x0054e0:	add     	r3, sp, #0xc
0x0054e2:	str     	r1, [sp]
0x0054e4:	ldm     	r3, {r0, r1, r2, r3}
0x0054e6:	blx     	r4
0x0054e8:	adds    	r5, r0, #0
0x0054ea:	mov     	sb, r7
0x0054ec:	adds    	r0, r5, #0
0x0054ee:	add     	sp, #0x1c
0x0054f0:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_005558 =====
0x005558:	push    	{r3, r4, r5, r6, r7, lr}
0x00555a:	adds    	r4, r0, #0
0x00555c:	ldr     	r0, [pc, #0x10c]
0x00555e:	movs    	r5, #0
0x005560:	mvns    	r5, r5
0x005562:	mov     	ip, r2
0x005564:	add     	r0, pc
0x005566:	ldr     	r2, [r0, #0x38]
0x005568:	cmp     	r4, #0
0x00556a:	bne     	#0x557c
0x00556c:	ldr     	r0, [pc, #0x100]
0x00556e:	ldr     	r2, [r2, #0x68]
0x005570:	movs    	r1, #0x7d
0x005572:	lsls    	r1, r1, #3
0x005574:	add     	r0, pc
0x005576:	blx     	r2
0x005578:	adds    	r0, r5, #0
0x00557a:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_005684 =====
0x005684:	push    	{r3, r4, r5, lr}
0x005686:	ldr     	r4, [pc, #0x28]
0x005688:	adds    	r5, r0, #0
0x00568a:	add     	r4, pc
0x00568c:	ldr     	r0, [r4, #0x38]
0x00568e:	adds    	r0, #0x80
0x005690:	ldr     	r0, [r0, #4]
0x005692:	blx     	r0
0x005694:	adds    	r0, r0, r5
0x005696:	ldr     	r1, [pc, #0x1c]
0x005698:	add     	r1, sb
0x00569a:	str     	r0, [r1, #0x10]
0x00569c:	ldr     	r0, [r4, #0x38]
0x00569e:	adds    	r0, #0x80
0x0056a0:	ldr     	r0, [r0]
0x0056a2:	blx     	r0
0x0056a4:	ldr     	r0, [r4, #0x38]
0x0056a6:	ldr     	r1, [r0, #0x7c]
0x0056a8:	lsls    	r0, r5, #0x10
0x0056aa:	lsrs    	r0, r0, #0x10
0x0056ac:	blx     	r1
0x0056ae:	pop     	{r3, r4, r5, pc}

; ===== candidate_0056ba =====
0x0056ba:	push    	{r3, r4, r5, r6, r7, lr}
0x0056bc:	add     	r0, pc
0x0056be:	ldr     	r0, [r0, #0x38]
0x0056c0:	adds    	r0, #0x80
0x0056c2:	ldr     	r0, [r0, #4]
0x0056c4:	blx     	r0
0x0056c6:	movs    	r5, #0
0x0056c8:	ldr     	r6, [pc, #0xc8]
0x0056ca:	add     	r6, sb
0x0056cc:	ldr     	r1, [r6, #0x10]
0x0056ce:	str     	r5, [r6, #0x10]
0x0056d0:	subs    	r1, r0, r1
0x0056d2:	ldr     	r0, [r6, #8]
0x0056d4:	adds    	r3, r1, #0
0x0056d6:	cmp     	r0, #0
0x0056d8:	beq     	#0x578e
0x0056da:	ldr     	r2, [r0, #8]
0x0056dc:	cmp     	r2, #0
0x0056de:	bne     	#0x573e
0x0056e0:	mvns    	r7, r2
0x0056e2:	str     	r7, [r0, #8]
0x0056e4:	ldr     	r2, [r0, #0x18]
0x0056e6:	adds    	r4, r0, #0
0x0056e8:	cmp     	r1, #0x32
0x0056ea:	str     	r2, [r6, #8]
0x0056ec:	bge     	#0x56f2
0x0056ee:	movs    	r1, #0x32
0x0056f0:	b       	#0x570e
0x0056f2:	movs    	r2, #0x7d
0x0056f4:	lsls    	r2, r2, #4
0x0056f6:	cmp     	r1, r2
0x0056f8:	ble     	#0x570e
0x0056fa:	adds    	r1, r2, #0
0x0056fc:	b       	#0x570e
0x0056fe:	movs    	r7, #0
0x005700:	mvns    	r7, r7
0x005702:	str     	r7, [r2, #8]
0x005704:	ldr     	r2, [r0, #0x18]
0x005706:	str     	r2, [r0, #0x1c]
0x005708:	ldr     	r0, [r2, #0x18]
0x00570a:	str     	r0, [r6, #8]
0x00570c:	adds    	r0, r2, #0
0x00570e:	ldr     	r2, [r0, #0x18]
0x005710:	cmp     	r2, #0
0x005712:	beq     	#0x571a
0x005714:	ldr     	r7, [r2, #8]
0x005716:	cmp     	r7, r1
0x005718:	blt     	#0x56fe
0x00571a:	str     	r5, [r0, #0x1c]
0x00571c:	ldr     	r0, [r6, #8]
0x00571e:	cmp     	r0, #0
0x005720:	beq     	#0x5782
0x005722:	cmp     	r3, #0
0x005724:	bge     	#0x5728
0x005726:	movs    	r3, #0
0x005728:	ldr     	r0, [r6, #8]
0x00572a:	ldr     	r1, [r0, #8]
0x00572c:	cmp     	r1, #0
0x00572e:	bge     	#0x5734
0x005730:	movs    	r1, #0
0x005732:	str     	r5, [r0, #8]
0x005734:	ldr     	r2, [pc, #0x60]
0x005736:	cmp     	r1, r2
0x005738:	ble     	#0x5742
0x00573a:	adds    	r1, r2, #0
0x00573c:	b       	#0x5742
0x00573e:	movs    	r4, #0
0x005740:	b       	#0x5722
0x005742:	ldr     	r2, [r0, #8]
0x005744:	subs    	r2, r2, r1
0x005746:	str     	r2, [r0, #8]
0x005748:	ldr     	r0, [r0, #0x18]
0x00574a:	cmp     	r0, #0
0x00574c:	bne     	#0x5742
0x00574e:	subs    	r0, r1, r3
0x005750:	cmp     	r0, #0
0x005752:	bgt     	#0x5756
0x005754:	movs    	r0, #0xa
0x005756:	bl      	#0x5684
0x00575a:	b       	#0x5782
0x00575c:	str     	r5, [r4, #8]
0x00575e:	ldr     	r0, [r4, #0x1c]
0x005760:	adds    	r3, r5, #0
0x005762:	str     	r0, [r6, #0xc]
0x005764:	ldr     	r0, [r4, #0x14]
0x005766:	cmp     	r0, #0
0x005768:	beq     	#0x5776
0x00576a:	str     	r0, [sp]
0x00576c:	movs    	r1, #0
0x00576e:	adds    	r0, r4, #0
0x005770:	ldr     	r2, [r4, #0x10]
0x005772:	bl      	#0x5558
0x005776:	ldr     	r1, [r4, #0xc]
0x005778:	cmp     	r1, #0
0x00577a:	beq     	#0x5780
0x00577c:	ldr     	r0, [r4, #0x10]
0x00577e:	blx     	r1
0x005780:	ldr     	r4, [r6, #0xc]
0x005782:	cmp     	r4, #0
0x005784:	beq     	#0x578c
0x005786:	ldr     	r0, [r4, #8]
0x005788:	cmp     	r0, #0
0x00578a:	blt     	#0x575c
0x00578c:	str     	r5, [r6, #0xc]
0x00578e:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_00579c =====
0x00579c:	push    	{r4, r5, r6, r7, lr}
0x00579e:	sub     	sp, #0x44
0x0057a0:	movs    	r1, #0
0x0057a2:	adds    	r4, r0, #0
0x0057a4:	movs    	r2, #0
0x0057a6:	str     	r2, [sp, #8]
0x0057a8:	str     	r1, [sp]
0x0057aa:	str     	r1, [sp, #4]
0x0057ac:	movs    	r6, #0
0x0057ae:	adds    	r3, r6, #0
0x0057b0:	movs    	r1, #0xf
0x0057b2:	movs    	r2, #0x2c
0x0057b4:	movs    	r0, #0xf1
0x0057b6:	lsls    	r0, r0, #9
0x0057b8:	bl      	#0x5324
0x0057bc:	str     	r6, [r0, #0xc]
0x0057be:	str     	r6, [r0, #0x10]
0x0057c0:	str     	r6, [r0, #0x14]
0x0057c2:	str     	r6, [r0, #0x18]
0x0057c4:	adds    	r3, r0, #0
0x0057c6:	strb    	r6, [r0, #0x1c]
0x0057c8:	adds    	r3, #0x10
0x0057ca:	str     	r3, [sp, #0x40]
0x0057cc:	strb    	r6, [r3, #0xd]
0x0057ce:	movs    	r1, #0
0x0057d0:	str     	r1, [sp]
0x0057d2:	str     	r1, [sp, #4]
0x0057d4:	adds    	r5, r0, #0
0x0057d6:	movs    	r2, #0
0x0057d8:	str     	r2, [sp, #8]
0x0057da:	movs    	r0, #0xf1
0x0057dc:	adds    	r3, r6, #0
0x0057de:	movs    	r1, #0x45
0x0057e0:	lsls    	r0, r0, #9
0x0057e2:	ldr     	r2, [r4, #8]
0x0057e4:	bl      	#0x5324
0x0057e8:	movs    	r1, #0
0x0057ea:	str     	r1, [sp]
0x0057ec:	str     	r1, [sp, #4]
0x0057ee:	str     	r0, [sp, #0x3c]
0x0057f0:	movs    	r2, #0
0x0057f2:	str     	r2, [sp, #8]
0x0057f4:	movs    	r0, #0xf1
0x0057f6:	movs    	r1, #0x45
0x0057f8:	adds    	r3, r6, #0
0x0057fa:	lsls    	r0, r0, #9
0x0057fc:	ldr     	r2, [r4, #8]
0x0057fe:	bl      	#0x5324
0x005802:	movs    	r1, #0
0x005804:	str     	r1, [sp]
0x005806:	str     	r1, [sp, #4]
0x005808:	str     	r0, [sp, #0x38]
0x00580a:	movs    	r2, #0
0x00580c:	str     	r2, [sp, #8]
0x00580e:	movs    	r0, #0xf1
0x005810:	movs    	r1, #0x45
0x005812:	adds    	r3, r6, #0
0x005814:	lsls    	r0, r0, #9
0x005816:	ldr     	r2, [r4, #8]
0x005818:	bl      	#0x5324
0x00581c:	movs    	r1, #0
0x00581e:	str     	r1, [sp]
0x005820:	str     	r1, [sp, #4]
0x005822:	str     	r0, [sp, #0x34]
0x005824:	movs    	r2, #0
0x005826:	str     	r2, [sp, #8]
0x005828:	movs    	r0, #0xf1
0x00582a:	movs    	r1, #0x47
0x00582c:	adds    	r3, r6, #0
0x00582e:	lsls    	r0, r0, #9
0x005830:	ldr     	r2, [r4, #8]
0x005832:	bl      	#0x5324
0x005836:	movs    	r1, #0
0x005838:	str     	r1, [sp]
0x00583a:	str     	r1, [sp, #4]
0x00583c:	str     	r0, [sp, #0x30]
0x00583e:	movs    	r2, #0
0x005840:	str     	r2, [sp, #8]
0x005842:	movs    	r0, #0xf1
0x005844:	movs    	r1, #0x47
0x005846:	adds    	r3, r6, #0
0x005848:	lsls    	r0, r0, #9
0x00584a:	ldr     	r2, [r4, #8]
0x00584c:	bl      	#0x5324
0x005850:	movs    	r1, #0
0x005852:	str     	r1, [sp]
0x005854:	str     	r1, [sp, #4]
0x005856:	str     	r0, [sp, #0x2c]
0x005858:	movs    	r2, #0
0x00585a:	str     	r2, [sp, #8]
0x00585c:	movs    	r0, #0xf1
0x00585e:	movs    	r1, #0x47
0x005860:	adds    	r3, r6, #0
0x005862:	lsls    	r0, r0, #9
0x005864:	ldr     	r2, [r4, #8]
0x005866:	bl      	#0x5324
0x00586a:	movs    	r1, #0
0x00586c:	str     	r0, [sp, #0x28]
0x00586e:	str     	r1, [sp]
0x005870:	str     	r1, [sp, #4]
0x005872:	movs    	r2, #0
0x005874:	str     	r2, [sp, #8]
0x005876:	movs    	r1, #0x46
0x005878:	movs    	r0, #0xf1
0x00587a:	adds    	r3, r6, #0
0x00587c:	lsls    	r0, r0, #9
0x00587e:	ldr     	r2, [r4, #8]
0x005880:	bl      	#0x5324
0x005884:	str     	r0, [sp, #0x24]
0x005886:	movs    	r1, #0
0x005888:	str     	r1, [sp]
0x00588a:	str     	r1, [sp, #4]
0x00588c:	movs    	r2, #0
0x00588e:	str     	r2, [sp, #8]
0x005890:	movs    	r1, #0x46
0x005892:	movs    	r0, #0xf1
0x005894:	adds    	r3, r6, #0
0x005896:	lsls    	r0, r0, #9
0x005898:	ldr     	r2, [r4, #8]
0x00589a:	bl      	#0x5324
0x00589e:	str     	r0, [sp, #0x20]
0x0058a0:	movs    	r1, #0
0x0058a2:	str     	r1, [sp]
0x0058a4:	str     	r1, [sp, #4]
0x0058a6:	movs    	r2, #0
0x0058a8:	str     	r2, [sp, #8]
0x0058aa:	movs    	r1, #0x46
0x0058ac:	movs    	r0, #0xf1
0x0058ae:	adds    	r3, r6, #0
0x0058b0:	lsls    	r0, r0, #9
0x0058b2:	ldr     	r2, [r4, #8]
0x0058b4:	bl      	#0x5324
0x0058b8:	movs    	r1, #0
0x0058ba:	str     	r1, [sp]
0x0058bc:	str     	r1, [sp, #4]
0x0058be:	str     	r0, [sp, #0x1c]
0x0058c0:	movs    	r2, #0
0x0058c2:	str     	r2, [sp, #8]
0x0058c4:	movs    	r0, #0xf1
0x0058c6:	movs    	r1, #0x46
0x0058c8:	adds    	r3, r6, #0

; ===== candidate_005998 =====
0x005998:	push    	{r4, r5, r6, r7, lr}
0x00599a:	sub     	sp, #0xc
0x00599c:	movs    	r1, #0
0x00599e:	ldr     	r0, [pc, #0xfc]
0x0059a0:	str     	r1, [sp]
0x0059a2:	str     	r1, [sp, #4]
0x0059a4:	movs    	r2, #0
0x0059a6:	str     	r2, [sp, #8]
0x0059a8:	movs    	r7, #0xf1
0x0059aa:	movs    	r6, #0
0x0059ac:	add     	r0, sb
0x0059ae:	ldr     	r2, [r0, #0x28]
0x0059b0:	adds    	r3, r6, #0
0x0059b2:	lsls    	r7, r7, #9
0x0059b4:	movs    	r1, #0x26
0x0059b6:	adds    	r0, r7, #0
0x0059b8:	bl      	#0x5324
0x0059bc:	adds    	r5, r0, #0
0x0059be:	movs    	r4, #0
0x0059c0:	cmp     	r0, #0
0x0059c2:	ble     	#0x59fc
0x0059c4:	movs    	r1, #0
0x0059c6:	ldr     	r0, [pc, #0xd4]
0x0059c8:	str     	r1, [sp]
0x0059ca:	str     	r1, [sp, #4]
0x0059cc:	movs    	r2, #0
0x0059ce:	str     	r2, [sp, #8]
0x0059d0:	add     	r0, sb
0x0059d2:	ldr     	r2, [r0, #0x28]
0x0059d4:	movs    	r1, #0x27
0x0059d6:	adds    	r3, r4, #0
0x0059d8:	adds    	r0, r7, #0
0x0059da:	bl      	#0x5324
0x0059de:	movs    	r2, #0
0x0059e0:	str     	r2, [sp, #8]
0x0059e2:	movs    	r1, #0
0x0059e4:	adds    	r2, r0, #0
0x0059e6:	movs    	r0, #0xf1
0x0059e8:	str     	r1, [sp]
0x0059ea:	str     	r1, [sp, #4]
0x0059ec:	movs    	r1, #0x8e
0x0059ee:	lsls    	r0, r0, #9
0x0059f0:	adds    	r3, r6, #0
0x0059f2:	bl      	#0x5324
0x0059f6:	adds    	r4, #1
0x0059f8:	cmp     	r4, r5
0x0059fa:	blt     	#0x59c4
0x0059fc:	movs    	r1, #0
0x0059fe:	str     	r1, [sp]
0x005a00:	str     	r1, [sp, #4]
0x005a02:	movs    	r2, #0
0x005a04:	ldr     	r4, [pc, #0x94]
0x005a06:	str     	r2, [sp, #8]
0x005a08:	movs    	r1, #0x28
0x005a0a:	adds    	r3, r6, #0
0x005a0c:	add     	r4, sb
0x005a0e:	ldr     	r2, [r4, #0x28]
0x005a10:	adds    	r0, r7, #0
0x005a12:	bl      	#0x5324
0x005a16:	movs    	r1, #0
0x005a18:	str     	r1, [sp]
0x005a1a:	str     	r1, [sp, #4]
0x005a1c:	movs    	r2, #0
0x005a1e:	str     	r2, [sp, #8]
0x005a20:	movs    	r1, #0x26
0x005a22:	adds    	r3, r6, #0
0x005a24:	movs    	r0, #0xf1
0x005a26:	lsls    	r0, r0, #9
0x005a28:	ldr     	r2, [r4, #0x2c]
0x005a2a:	bl      	#0x5324
0x005a2e:	adds    	r5, r0, #0
0x005a30:	movs    	r4, #0
0x005a32:	cmp     	r0, #0
0x005a34:	ble     	#0x5a6e
0x005a36:	movs    	r1, #0
0x005a38:	ldr     	r0, [pc, #0x60]
0x005a3a:	str     	r1, [sp]
0x005a3c:	str     	r1, [sp, #4]
0x005a3e:	movs    	r2, #0
0x005a40:	str     	r2, [sp, #8]
0x005a42:	add     	r0, sb
0x005a44:	ldr     	r2, [r0, #0x2c]
0x005a46:	movs    	r1, #0x27
0x005a48:	adds    	r3, r4, #0
0x005a4a:	adds    	r0, r7, #0
0x005a4c:	bl      	#0x5324
0x005a50:	movs    	r2, #0
0x005a52:	str     	r2, [sp, #8]
0x005a54:	movs    	r1, #0
0x005a56:	adds    	r2, r0, #0
0x005a58:	movs    	r0, #0xf1
0x005a5a:	str     	r1, [sp]
0x005a5c:	str     	r1, [sp, #4]
0x005a5e:	movs    	r1, #0x8c
0x005a60:	lsls    	r0, r0, #9
0x005a62:	adds    	r3, r6, #0
0x005a64:	bl      	#0x5324
0x005a68:	adds    	r4, #1
0x005a6a:	cmp     	r4, r5
0x005a6c:	blt     	#0x5a36
0x005a6e:	movs    	r1, #0
0x005a70:	str     	r1, [sp]
0x005a72:	str     	r1, [sp, #4]
0x005a74:	movs    	r2, #0
0x005a76:	ldr     	r4, [pc, #0x24]
0x005a78:	str     	r2, [sp, #8]
0x005a7a:	movs    	r1, #0x28
0x005a7c:	adds    	r3, r6, #0
0x005a7e:	add     	r4, sb
0x005a80:	ldr     	r2, [r4, #0x2c]
0x005a82:	adds    	r0, r7, #0
0x005a84:	bl      	#0x5324
0x005a88:	movs    	r0, #0
0x005a8a:	mvns    	r0, r0
0x005a8c:	str     	r0, [r4, #0x18]
0x005a8e:	str     	r0, [r4, #0x20]
0x005a90:	str     	r0, [r4, #0x1c]
0x005a92:	str     	r0, [r4, #0x24]
0x005a94:	str     	r6, [r4, #0x4c]
0x005a96:	add     	sp, #0xc
0x005a98:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_005aa0 =====
0x005aa0:	push    	{r4, r5, r6, lr}
0x005aa2:	sub     	sp, #0x10
0x005aa4:	adds    	r4, r0, #0
0x005aa6:	beq     	#0x5b34
0x005aa8:	movs    	r6, #0xf1
0x005aaa:	ldr     	r3, [r4, #0xc]
0x005aac:	lsls    	r6, r6, #9
0x005aae:	movs    	r5, #0
0x005ab0:	cmp     	r3, #0
0x005ab2:	beq     	#0x5aca
0x005ab4:	movs    	r2, #0
0x005ab6:	movs    	r1, #0
0x005ab8:	str     	r2, [sp, #8]
0x005aba:	adds    	r2, r3, #0
0x005abc:	str     	r1, [sp]
0x005abe:	str     	r1, [sp, #4]
0x005ac0:	movs    	r1, #9
0x005ac2:	adds    	r3, r5, #0
0x005ac4:	adds    	r0, r6, #0
0x005ac6:	bl      	#0x5324
0x005aca:	ldr     	r3, [r4, #0x14]
0x005acc:	cmp     	r3, #0
0x005ace:	beq     	#0x5ae6
0x005ad0:	movs    	r2, #0
0x005ad2:	movs    	r1, #0
0x005ad4:	str     	r2, [sp, #8]
0x005ad6:	adds    	r2, r3, #0
0x005ad8:	str     	r1, [sp]
0x005ada:	str     	r1, [sp, #4]
0x005adc:	movs    	r1, #9
0x005ade:	adds    	r3, r5, #0
0x005ae0:	adds    	r0, r6, #0
0x005ae2:	bl      	#0x5324
0x005ae6:	ldr     	r3, [r4, #0x18]
0x005ae8:	cmp     	r3, #0
0x005aea:	beq     	#0x5b02
0x005aec:	movs    	r2, #0
0x005aee:	movs    	r1, #0
0x005af0:	str     	r2, [sp, #8]
0x005af2:	adds    	r2, r3, #0
0x005af4:	str     	r1, [sp]
0x005af6:	str     	r1, [sp, #4]
0x005af8:	movs    	r1, #9
0x005afa:	adds    	r3, r5, #0
0x005afc:	adds    	r0, r6, #0
0x005afe:	bl      	#0x5324
0x005b02:	ldr     	r3, [r4, #0x10]
0x005b04:	cmp     	r3, #0
0x005b06:	beq     	#0x5b1e
0x005b08:	movs    	r2, #0
0x005b0a:	movs    	r1, #0
0x005b0c:	str     	r2, [sp, #8]
0x005b0e:	adds    	r2, r3, #0
0x005b10:	str     	r1, [sp]
0x005b12:	str     	r1, [sp, #4]
0x005b14:	movs    	r1, #9
0x005b16:	adds    	r3, r5, #0
0x005b18:	adds    	r0, r6, #0
0x005b1a:	bl      	#0x5324
0x005b1e:	movs    	r1, #0
0x005b20:	movs    	r2, #0
0x005b22:	str     	r2, [sp, #8]
0x005b24:	str     	r1, [sp]
0x005b26:	str     	r1, [sp, #4]
0x005b28:	movs    	r1, #9
0x005b2a:	adds    	r2, r4, #0
0x005b2c:	adds    	r3, r5, #0
0x005b2e:	adds    	r0, r6, #0
0x005b30:	bl      	#0x5324
0x005b34:	add     	sp, #0x10
0x005b36:	pop     	{r4, r5, r6, pc}

; ===== candidate_005b38 =====
0x005b38:	push    	{r4, r5, r6, r7, lr}
0x005b3a:	ldr     	r7, [pc, #0x9c]
0x005b3c:	movs    	r4, #0xf1
0x005b3e:	add     	r7, sb
0x005b40:	ldr     	r5, [r7, #0x34]
0x005b42:	lsls    	r4, r4, #9
0x005b44:	movs    	r6, #0
0x005b46:	cmp     	r5, #0
0x005b48:	sub     	sp, #0xc
0x005b4a:	beq     	#0x5b64
0x005b4c:	movs    	r1, #0
0x005b4e:	movs    	r2, #0
0x005b50:	str     	r2, [sp, #8]
0x005b52:	str     	r1, [sp]
0x005b54:	str     	r1, [sp, #4]
0x005b56:	movs    	r1, #6
0x005b58:	adds    	r2, r5, #0
0x005b5a:	adds    	r3, r6, #0
0x005b5c:	adds    	r0, r4, #0
0x005b5e:	bl      	#0x5324
0x005b62:	str     	r6, [r7, #0x34]
0x005b64:	ldr     	r5, [r7, #0x10]
0x005b66:	cmp     	r5, #0
0x005b68:	beq     	#0x5b82
0x005b6a:	movs    	r1, #0
0x005b6c:	movs    	r2, #0
0x005b6e:	str     	r2, [sp, #8]
0x005b70:	str     	r1, [sp]
0x005b72:	str     	r1, [sp, #4]
0x005b74:	movs    	r1, #9
0x005b76:	adds    	r2, r5, #0
0x005b78:	adds    	r3, r6, #0
0x005b7a:	adds    	r0, r4, #0
0x005b7c:	bl      	#0x5324
0x005b80:	str     	r6, [r7, #0x10]
0x005b82:	ldr     	r5, [r7, #8]
0x005b84:	cmp     	r5, #0
0x005b86:	beq     	#0x5bd0
0x005b88:	movs    	r1, #0
0x005b8a:	movs    	r2, #0
0x005b8c:	str     	r2, [sp, #8]
0x005b8e:	str     	r1, [sp]
0x005b90:	str     	r1, [sp, #4]
0x005b92:	movs    	r1, #0x11
0x005b94:	adds    	r2, r5, #0
0x005b96:	movs    	r3, #4
0x005b98:	movs    	r0, #0xf1
0x005b9a:	lsls    	r0, r0, #9
0x005b9c:	bl      	#0x5324
0x005ba0:	adds    	r5, r0, #0
0x005ba2:	movs    	r4, #0
0x005ba4:	cmp     	r0, #0
0x005ba6:	ble     	#0x5bb8
0x005ba8:	ldr     	r1, [r7, #8]
0x005baa:	lsls    	r0, r4, #2
0x005bac:	ldr     	r0, [r1, r0]
0x005bae:	bl      	#0x5bdc
0x005bb2:	adds    	r4, #1
0x005bb4:	cmp     	r4, r5
0x005bb6:	blt     	#0x5ba8
0x005bb8:	movs    	r1, #0
0x005bba:	str     	r1, [sp]
0x005bbc:	str     	r1, [sp, #4]
0x005bbe:	movs    	r2, #0
0x005bc0:	str     	r2, [sp, #8]
0x005bc2:	movs    	r1, #9
0x005bc4:	adds    	r3, r6, #0
0x005bc6:	movs    	r0, #0xf1
0x005bc8:	lsls    	r0, r0, #9
0x005bca:	ldr     	r2, [r7, #8]
0x005bcc:	bl      	#0x5324
0x005bd0:	str     	r6, [r7, #0xc]
0x005bd2:	str     	r6, [r7, #8]
0x005bd4:	add     	sp, #0xc
0x005bd6:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_005bdc =====
0x005bdc:	push    	{r4, r5, r6, r7, lr}
0x005bde:	adds    	r5, r0, #0
0x005be0:	movs    	r4, #0
0x005be2:	cmp     	r0, #0
0x005be4:	sub     	sp, #0xc
0x005be6:	beq     	#0x5c2c
0x005be8:	movs    	r1, #0
0x005bea:	movs    	r2, #0
0x005bec:	str     	r2, [sp, #8]
0x005bee:	str     	r1, [sp]
0x005bf0:	str     	r1, [sp, #4]
0x005bf2:	movs    	r7, #0xf1
0x005bf4:	lsls    	r7, r7, #9
0x005bf6:	movs    	r1, #0x11
0x005bf8:	adds    	r2, r5, #0
0x005bfa:	movs    	r3, #4
0x005bfc:	adds    	r0, r7, #0
0x005bfe:	bl      	#0x5324
0x005c02:	adds    	r6, r0, #0
0x005c04:	cmp     	r0, #0
0x005c06:	ble     	#0x5c16
0x005c08:	lsls    	r0, r4, #2
0x005c0a:	ldr     	r0, [r5, r0]
0x005c0c:	bl      	#0x5aa0
0x005c10:	adds    	r4, #1
0x005c12:	cmp     	r4, r6
0x005c14:	blt     	#0x5c08
0x005c16:	movs    	r1, #0
0x005c18:	movs    	r2, #0
0x005c1a:	str     	r2, [sp, #8]
0x005c1c:	str     	r1, [sp]
0x005c1e:	str     	r1, [sp, #4]
0x005c20:	movs    	r1, #9
0x005c22:	adds    	r2, r5, #0
0x005c24:	movs    	r3, #0
0x005c26:	adds    	r0, r7, #0
0x005c28:	bl      	#0x5324
0x005c2c:	add     	sp, #0xc
0x005c2e:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_005c30 =====
0x005c30:	push    	{r4, r5, r6, r7, lr}
0x005c32:	sub     	sp, #0xc
0x005c34:	bl      	#0x5998
0x005c38:	movs    	r1, #0
0x005c3a:	str     	r1, [sp]
0x005c3c:	str     	r1, [sp, #4]
0x005c3e:	movs    	r2, #0
0x005c40:	ldr     	r4, [pc, #0x80]
0x005c42:	movs    	r5, #0
0x005c44:	movs    	r6, #0xf1
0x005c46:	lsls    	r6, r6, #9
0x005c48:	adds    	r3, r5, #0
0x005c4a:	str     	r2, [sp, #8]
0x005c4c:	movs    	r1, #9
0x005c4e:	add     	r4, sb
0x005c50:	ldr     	r2, [r4, #0x28]
0x005c52:	adds    	r0, r6, #0
0x005c54:	bl      	#0x5324
0x005c58:	movs    	r0, #0
0x005c5a:	str     	r0, [r4, #0x28]
0x005c5c:	movs    	r1, #0
0x005c5e:	str     	r1, [sp, #4]
0x005c60:	movs    	r2, #0
0x005c62:	str     	r0, [sp]
0x005c64:	str     	r2, [sp, #8]
0x005c66:	movs    	r1, #9
0x005c68:	movs    	r3, #0
0x005c6a:	adds    	r0, r6, #0
0x005c6c:	ldr     	r2, [r4, #0x2c]
0x005c6e:	bl      	#0x5324
0x005c72:	movs    	r0, #0
0x005c74:	str     	r0, [r4, #0x2c]
0x005c76:	ldr     	r7, [r4, #0x5c]
0x005c78:	cmp     	r7, #0
0x005c7a:	beq     	#0x5c92
0x005c7c:	movs    	r1, #0
0x005c7e:	movs    	r2, #0
0x005c80:	str     	r2, [sp, #8]
0x005c82:	str     	r1, [sp]
0x005c84:	str     	r1, [sp, #4]
0x005c86:	movs    	r1, #9
0x005c88:	adds    	r2, r7, #0
0x005c8a:	adds    	r3, r5, #0
0x005c8c:	adds    	r0, r6, #0
0x005c8e:	bl      	#0x5324
0x005c92:	str     	r5, [r4, #0x5c]
0x005c94:	movs    	r1, #0
0x005c96:	str     	r1, [sp]
0x005c98:	str     	r1, [sp, #4]
0x005c9a:	movs    	r2, #0
0x005c9c:	movs    	r1, #0xe6
0x005c9e:	adds    	r3, r5, #0
0x005ca0:	adds    	r0, r6, #0
0x005ca2:	str     	r2, [sp, #8]
0x005ca4:	bl      	#0x5324
0x005ca8:	movs    	r1, #0
0x005caa:	str     	r1, [sp]
0x005cac:	str     	r1, [sp, #4]
0x005cae:	movs    	r2, #0
0x005cb0:	movs    	r1, #0x2c
0x005cb2:	adds    	r3, r5, #0
0x005cb4:	movs    	r0, #0xf1
0x005cb6:	lsls    	r0, r0, #9
0x005cb8:	str     	r2, [sp, #8]
0x005cba:	bl      	#0x5324
0x005cbe:	add     	sp, #0xc
0x005cc0:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_005cc8 =====
0x005cc8:	push    	{r4, r5, r6, r7, lr}
0x005cca:	sub     	sp, #0xc
0x005ccc:	movs    	r1, #0
0x005cce:	movs    	r2, #0
0x005cd0:	str     	r2, [sp, #8]
0x005cd2:	str     	r1, [sp]
0x005cd4:	str     	r1, [sp, #4]
0x005cd6:	movs    	r4, #0xf1
0x005cd8:	movs    	r6, #0
0x005cda:	adds    	r3, r6, #0
0x005cdc:	lsls    	r4, r4, #9
0x005cde:	movs    	r1, #0xe1
0x005ce0:	movs    	r2, #0x80
0x005ce2:	movs    	r5, #0
0x005ce4:	adds    	r0, r4, #0
0x005ce6:	bl      	#0x5324
0x005cea:	cmp     	r0, #0
0x005cec:	beq     	#0x5d30
0x005cee:	movs    	r1, #0
0x005cf0:	movs    	r2, #0
0x005cf2:	str     	r2, [sp, #8]
0x005cf4:	str     	r1, [sp]
0x005cf6:	str     	r1, [sp, #4]
0x005cf8:	movs    	r1, #0xe1
0x005cfa:	movs    	r2, #0x80
0x005cfc:	adds    	r3, r6, #0
0x005cfe:	adds    	r0, r4, #0
0x005d00:	bl      	#0x5324
0x005d04:	movs    	r1, #0
0x005d06:	movs    	r2, #0
0x005d08:	str     	r2, [sp, #8]
0x005d0a:	str     	r1, [sp]
0x005d0c:	str     	r1, [sp, #4]
0x005d0e:	movs    	r1, #6
0x005d10:	adds    	r2, r0, #0
0x005d12:	adds    	r3, r6, #0
0x005d14:	adds    	r0, r4, #0
0x005d16:	bl      	#0x5324
0x005d1a:	movs    	r1, #0
0x005d1c:	movs    	r2, #0
0x005d1e:	str     	r2, [sp, #8]
0x005d20:	str     	r1, [sp]
0x005d22:	str     	r1, [sp, #4]
0x005d24:	movs    	r1, #0x14
0x005d26:	movs    	r2, #0x80
0x005d28:	adds    	r3, r6, #0
0x005d2a:	adds    	r0, r4, #0
0x005d2c:	bl      	#0x5324
0x005d30:	ldr     	r7, [pc, #0x180]
0x005d32:	add     	r7, sb
0x005d34:	ldr     	r3, [r7, #0x58]
0x005d36:	cmp     	r3, #0
0x005d38:	beq     	#0x5d50
0x005d3a:	movs    	r1, #0
0x005d3c:	movs    	r2, #0
0x005d3e:	str     	r2, [sp, #8]
0x005d40:	str     	r1, [sp]
0x005d42:	str     	r1, [sp, #4]
0x005d44:	movs    	r1, #9
0x005d46:	adds    	r2, r3, #0
0x005d48:	adds    	r0, r4, #0
0x005d4a:	adds    	r3, r6, #0
0x005d4c:	bl      	#0x5324
0x005d50:	str     	r6, [r7, #0x58]
0x005d52:	ldr     	r3, [r7, #0x5c]
0x005d54:	cmp     	r3, #0
0x005d56:	beq     	#0x5d6e
0x005d58:	movs    	r1, #0
0x005d5a:	movs    	r2, #0
0x005d5c:	str     	r2, [sp, #8]
0x005d5e:	str     	r1, [sp]
0x005d60:	str     	r1, [sp, #4]
0x005d62:	movs    	r1, #9
0x005d64:	adds    	r2, r3, #0
0x005d66:	adds    	r0, r4, #0
0x005d68:	adds    	r3, r6, #0
0x005d6a:	bl      	#0x5324
0x005d6e:	str     	r6, [r7, #0x5c]
0x005d70:	ldr     	r3, [r7, #0x60]
0x005d72:	cmp     	r3, #0
0x005d74:	beq     	#0x5d8c
0x005d76:	movs    	r1, #0
0x005d78:	movs    	r2, #0
0x005d7a:	str     	r2, [sp, #8]
0x005d7c:	str     	r1, [sp]
0x005d7e:	str     	r1, [sp, #4]
0x005d80:	movs    	r1, #9
0x005d82:	adds    	r2, r3, #0
0x005d84:	adds    	r0, r4, #0
0x005d86:	adds    	r3, r6, #0
0x005d88:	bl      	#0x5324
0x005d8c:	ldr     	r0, [pc, #0x124]
0x005d8e:	add     	r0, sb
0x005d90:	adds    	r0, #0x80
0x005d92:	ldr     	r3, [r0]
0x005d94:	cmp     	r3, #0
0x005d96:	beq     	#0x5dae
0x005d98:	movs    	r1, #0
0x005d9a:	movs    	r2, #0
0x005d9c:	str     	r2, [sp, #8]
0x005d9e:	str     	r1, [sp]
0x005da0:	str     	r1, [sp, #4]
0x005da2:	movs    	r1, #0x12
0x005da4:	adds    	r2, r3, #0
0x005da6:	adds    	r0, r4, #0
0x005da8:	adds    	r3, r6, #0
0x005daa:	bl      	#0x5324
0x005dae:	movs    	r1, #0
0x005db0:	str     	r1, [sp]
0x005db2:	str     	r1, [sp, #4]
0x005db4:	movs    	r2, #0
0x005db6:	str     	r2, [sp, #8]
0x005db8:	movs    	r1, #0x26
0x005dba:	movs    	r3, #0
0x005dbc:	adds    	r0, r4, #0
0x005dbe:	ldr     	r2, [r7, #0x68]
0x005dc0:	bl      	#0x5324
0x005dc4:	adds    	r6, r0, #0
0x005dc6:	cmp     	r0, #0
0x005dc8:	ble     	#0x5dd6
0x005dca:	adds    	r0, r5, #0
0x005dcc:	bl      	#0x3e38
0x005dd0:	subs    	r6, #1
0x005dd2:	cmp     	r5, r6
0x005dd4:	blt     	#0x5dca
0x005dd6:	movs    	r1, #0
0x005dd8:	str     	r1, [sp]
0x005dda:	str     	r1, [sp, #4]
0x005ddc:	movs    	r2, #0
0x005dde:	ldr     	r7, [pc, #0xd4]
0x005de0:	movs    	r5, #0
0x005de2:	adds    	r3, r5, #0
0x005de4:	str     	r2, [sp, #8]
0x005de6:	movs    	r1, #9
0x005de8:	movs    	r0, #0xf1
0x005dea:	add     	r7, sb
0x005dec:	ldr     	r2, [r7, #0x68]
0x005dee:	lsls    	r0, r0, #9
0x005df0:	bl      	#0x5324
0x005df4:	str     	r5, [r7, #0x68]
0x005df6:	movs    	r1, #0

; ===== candidate_005eb8 =====
0x005eb8:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x005eba:	sub     	sp, #0xc
0x005ebc:	adds    	r5, r1, #0
0x005ebe:	movs    	r1, #0
0x005ec0:	movs    	r4, #0
0x005ec2:	movs    	r2, #0
0x005ec4:	str     	r2, [sp, #8]
0x005ec6:	adds    	r3, r4, #0
0x005ec8:	str     	r1, [sp]
0x005eca:	str     	r1, [sp, #4]
0x005ecc:	movs    	r1, #0x17
0x005ece:	adds    	r2, r5, #0
0x005ed0:	movs    	r0, #0xf1
0x005ed2:	lsls    	r0, r0, #9
0x005ed4:	bl      	#0x5324
0x005ed8:	movs    	r1, #0
0x005eda:	movs    	r2, #0
0x005edc:	str     	r2, [sp, #8]
0x005ede:	str     	r1, [sp]
0x005ee0:	str     	r1, [sp, #4]
0x005ee2:	movs    	r1, #0xe1
0x005ee4:	movs    	r2, #0x1d
0x005ee6:	adds    	r3, r4, #0
0x005ee8:	movs    	r0, #0xf1
0x005eea:	lsls    	r0, r0, #9
0x005eec:	bl      	#0x5324
0x005ef0:	movs    	r1, #0
0x005ef2:	adds    	r6, r0, #0
0x005ef4:	movs    	r2, #0
0x005ef6:	str     	r2, [sp, #8]
0x005ef8:	str     	r1, [sp]
0x005efa:	str     	r1, [sp, #4]
0x005efc:	movs    	r1, #0xe1
0x005efe:	movs    	r2, #0x18
0x005f00:	movs    	r0, #0xf1
0x005f02:	adds    	r3, r4, #0
0x005f04:	lsls    	r0, r0, #9
0x005f06:	bl      	#0x5324
0x005f0a:	ldr     	r7, [r0, #0xc]
0x005f0c:	movs    	r1, #0
0x005f0e:	movs    	r2, #0
0x005f10:	str     	r2, [sp, #8]
0x005f12:	str     	r1, [sp]
0x005f14:	str     	r1, [sp, #4]
0x005f16:	movs    	r1, #0xe1
0x005f18:	movs    	r2, #0x18
0x005f1a:	movs    	r0, #0xf1
0x005f1c:	adds    	r3, r4, #0
0x005f1e:	lsls    	r0, r0, #9
0x005f20:	bl      	#0x5324
0x005f24:	ldr     	r3, [r0, #8]
0x005f26:	movs    	r2, #0
0x005f28:	str     	r2, [sp, #8]
0x005f2a:	adds    	r2, r5, #0
0x005f2c:	movs    	r0, #0xf1
0x005f2e:	movs    	r1, #0x52
0x005f30:	lsls    	r0, r0, #9
0x005f32:	str     	r7, [sp]
0x005f34:	str     	r6, [sp, #4]
0x005f36:	bl      	#0x5324
0x005f3a:	movs    	r1, #0
0x005f3c:	movs    	r2, #0
0x005f3e:	str     	r1, [sp]
0x005f40:	str     	r1, [sp, #4]
0x005f42:	movs    	r1, #0x19
0x005f44:	str     	r2, [sp, #8]
0x005f46:	adds    	r3, r4, #0
0x005f48:	movs    	r0, #0xf1
0x005f4a:	lsls    	r0, r0, #9
0x005f4c:	ldr     	r2, [sp, #0xc]
0x005f4e:	bl      	#0x5324
0x005f52:	movs    	r1, #0
0x005f54:	movs    	r2, #0
0x005f56:	str     	r2, [sp, #8]
0x005f58:	str     	r1, [sp]
0x005f5a:	str     	r1, [sp, #4]
0x005f5c:	movs    	r1, #0x1b
0x005f5e:	movs    	r2, #1
0x005f60:	adds    	r3, r4, #0
0x005f62:	movs    	r0, #0xf1
0x005f64:	lsls    	r0, r0, #9
0x005f66:	bl      	#0x5324
0x005f6a:	add     	sp, #0x14
0x005f6c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_005f70 =====
0x005f70:	push    	{r0, r4, r5, r6, r7, lr}
0x005f72:	sub     	sp, #0x10
0x005f74:	movs    	r1, #0
0x005f76:	movs    	r4, #0
0x005f78:	movs    	r2, #0
0x005f7a:	str     	r2, [sp, #8]
0x005f7c:	adds    	r3, r4, #0
0x005f7e:	str     	r1, [sp]
0x005f80:	str     	r1, [sp, #4]
0x005f82:	movs    	r5, #0xa4
0x005f84:	adds    	r2, r5, #0
0x005f86:	movs    	r1, #0x17
0x005f88:	movs    	r0, #0xf1
0x005f8a:	lsls    	r0, r0, #9
0x005f8c:	bl      	#0x5324
0x005f90:	movs    	r1, #0
0x005f92:	movs    	r2, #0
0x005f94:	str     	r2, [sp, #8]
0x005f96:	str     	r1, [sp]
0x005f98:	str     	r1, [sp, #4]
0x005f9a:	movs    	r1, #0xe1
0x005f9c:	movs    	r2, #0x1d
0x005f9e:	adds    	r3, r4, #0
0x005fa0:	movs    	r0, #0xf1
0x005fa2:	lsls    	r0, r0, #9
0x005fa4:	bl      	#0x5324
0x005fa8:	movs    	r1, #0
0x005faa:	adds    	r6, r0, #0
0x005fac:	movs    	r2, #0
0x005fae:	str     	r2, [sp, #8]
0x005fb0:	str     	r1, [sp]
0x005fb2:	str     	r1, [sp, #4]
0x005fb4:	movs    	r1, #0xe1
0x005fb6:	movs    	r2, #0x18
0x005fb8:	movs    	r0, #0xf1
0x005fba:	adds    	r3, r4, #0
0x005fbc:	lsls    	r0, r0, #9
0x005fbe:	bl      	#0x5324
0x005fc2:	ldr     	r7, [r0, #0xc]
0x005fc4:	movs    	r1, #0
0x005fc6:	movs    	r2, #0
0x005fc8:	str     	r2, [sp, #8]
0x005fca:	str     	r1, [sp]
0x005fcc:	str     	r1, [sp, #4]
0x005fce:	movs    	r1, #0xe1
0x005fd0:	movs    	r2, #0x18
0x005fd2:	movs    	r0, #0xf1
0x005fd4:	adds    	r3, r4, #0
0x005fd6:	lsls    	r0, r0, #9
0x005fd8:	bl      	#0x5324
0x005fdc:	ldr     	r3, [r0, #8]
0x005fde:	movs    	r2, #0
0x005fe0:	str     	r2, [sp, #8]
0x005fe2:	adds    	r2, r5, #0
0x005fe4:	movs    	r0, #0xf1
0x005fe6:	movs    	r1, #0x52
0x005fe8:	lsls    	r0, r0, #9
0x005fea:	str     	r7, [sp]
0x005fec:	str     	r6, [sp, #4]
0x005fee:	bl      	#0x5324
0x005ff2:	movs    	r1, #0
0x005ff4:	movs    	r2, #0
0x005ff6:	str     	r1, [sp]
0x005ff8:	str     	r1, [sp, #4]
0x005ffa:	movs    	r1, #0x19
0x005ffc:	str     	r2, [sp, #8]
0x005ffe:	adds    	r3, r4, #0
0x006000:	movs    	r0, #0xf1
0x006002:	lsls    	r0, r0, #9
0x006004:	ldr     	r2, [sp, #0x10]
0x006006:	bl      	#0x5324
0x00600a:	movs    	r1, #0
0x00600c:	movs    	r2, #0
0x00600e:	str     	r2, [sp, #8]
0x006010:	str     	r1, [sp]
0x006012:	str     	r1, [sp, #4]
0x006014:	movs    	r1, #0x1b
0x006016:	movs    	r2, #1
0x006018:	adds    	r3, r4, #0
0x00601a:	movs    	r0, #0xf1
0x00601c:	lsls    	r0, r0, #9
0x00601e:	bl      	#0x5324
0x006022:	add     	sp, #0x14
0x006024:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_006028 =====
0x006028:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x00602a:	sub     	sp, #0x10
0x00602c:	movs    	r1, #0
0x00602e:	movs    	r2, #0
0x006030:	movs    	r4, #0
0x006032:	adds    	r3, r4, #0
0x006034:	str     	r2, [sp, #8]
0x006036:	str     	r1, [sp]
0x006038:	str     	r1, [sp, #4]
0x00603a:	movs    	r5, #0x74
0x00603c:	adds    	r2, r5, #0
0x00603e:	movs    	r1, #0x17
0x006040:	movs    	r0, #0xf1
0x006042:	lsls    	r0, r0, #9
0x006044:	bl      	#0x5324
0x006048:	movs    	r1, #0
0x00604a:	movs    	r2, #0
0x00604c:	str     	r2, [sp, #8]
0x00604e:	str     	r1, [sp]
0x006050:	str     	r1, [sp, #4]
0x006052:	movs    	r1, #0xe1
0x006054:	movs    	r2, #0x1d
0x006056:	adds    	r3, r4, #0
0x006058:	movs    	r0, #0xf1
0x00605a:	lsls    	r0, r0, #9
0x00605c:	bl      	#0x5324
0x006060:	movs    	r1, #0
0x006062:	adds    	r6, r0, #0
0x006064:	movs    	r2, #0
0x006066:	str     	r2, [sp, #8]
0x006068:	str     	r1, [sp]
0x00606a:	str     	r1, [sp, #4]
0x00606c:	movs    	r1, #0xe1
0x00606e:	movs    	r2, #0x18
0x006070:	movs    	r0, #0xf1
0x006072:	adds    	r3, r4, #0
0x006074:	lsls    	r0, r0, #9
0x006076:	bl      	#0x5324
0x00607a:	ldr     	r7, [r0, #0xc]
0x00607c:	movs    	r1, #0
0x00607e:	movs    	r2, #0
0x006080:	str     	r2, [sp, #8]
0x006082:	str     	r1, [sp]
0x006084:	str     	r1, [sp, #4]
0x006086:	movs    	r1, #0xe1
0x006088:	movs    	r2, #0x18
0x00608a:	movs    	r0, #0xf1
0x00608c:	adds    	r3, r4, #0
0x00608e:	lsls    	r0, r0, #9
0x006090:	bl      	#0x5324
0x006094:	ldr     	r3, [r0, #8]
0x006096:	movs    	r2, #0
0x006098:	str     	r2, [sp, #8]
0x00609a:	adds    	r2, r5, #0
0x00609c:	movs    	r0, #0xf1
0x00609e:	movs    	r1, #0x52
0x0060a0:	lsls    	r0, r0, #9
0x0060a2:	str     	r7, [sp]
0x0060a4:	str     	r6, [sp, #4]
0x0060a6:	bl      	#0x5324
0x0060aa:	movs    	r1, #0
0x0060ac:	movs    	r2, #0
0x0060ae:	str     	r1, [sp]
0x0060b0:	str     	r1, [sp, #4]
0x0060b2:	movs    	r1, #0x19
0x0060b4:	str     	r2, [sp, #8]
0x0060b6:	adds    	r3, r4, #0
0x0060b8:	movs    	r0, #0xf1
0x0060ba:	lsls    	r0, r0, #9
0x0060bc:	ldr     	r2, [sp, #0x10]
0x0060be:	bl      	#0x5324
0x0060c2:	movs    	r1, #0
0x0060c4:	movs    	r2, #0
0x0060c6:	str     	r1, [sp]
0x0060c8:	str     	r1, [sp, #4]
0x0060ca:	movs    	r1, #0x19
0x0060cc:	str     	r2, [sp, #8]
0x0060ce:	adds    	r3, r4, #0
0x0060d0:	movs    	r0, #0xf1
0x0060d2:	lsls    	r0, r0, #9
0x0060d4:	ldr     	r2, [sp, #0x14]
0x0060d6:	bl      	#0x5324
0x0060da:	movs    	r1, #0
0x0060dc:	movs    	r2, #0
0x0060de:	str     	r1, [sp]
0x0060e0:	str     	r1, [sp, #4]
0x0060e2:	movs    	r1, #0x19
0x0060e4:	str     	r2, [sp, #8]
0x0060e6:	adds    	r3, r4, #0
0x0060e8:	movs    	r0, #0xf1
0x0060ea:	lsls    	r0, r0, #9
0x0060ec:	ldr     	r2, [sp, #0x18]
0x0060ee:	bl      	#0x5324
0x0060f2:	movs    	r1, #0
0x0060f4:	movs    	r2, #0
0x0060f6:	str     	r2, [sp, #8]
0x0060f8:	str     	r1, [sp]
0x0060fa:	str     	r1, [sp, #4]
0x0060fc:	movs    	r1, #0x1b
0x0060fe:	movs    	r2, #1
0x006100:	adds    	r3, r4, #0
0x006102:	movs    	r0, #0xf1
0x006104:	lsls    	r0, r0, #9
0x006106:	bl      	#0x5324
0x00610a:	add     	sp, #0x1c
0x00610c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_006110 =====
0x006110:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x006112:	sub     	sp, #0x14
0x006114:	movs    	r1, #0
0x006116:	movs    	r2, #0
0x006118:	str     	r2, [sp, #8]
0x00611a:	str     	r1, [sp]
0x00611c:	str     	r1, [sp, #4]
0x00611e:	movs    	r7, #0xf1
0x006120:	movs    	r6, #0x75
0x006122:	movs    	r5, #0
0x006124:	adds    	r3, r5, #0
0x006126:	adds    	r2, r6, #0
0x006128:	lsls    	r7, r7, #9
0x00612a:	movs    	r1, #0x17
0x00612c:	movs    	r4, #0
0x00612e:	adds    	r0, r7, #0
0x006130:	bl      	#0x5324
0x006134:	movs    	r1, #0
0x006136:	movs    	r2, #0
0x006138:	str     	r2, [sp, #8]
0x00613a:	str     	r1, [sp]
0x00613c:	str     	r1, [sp, #4]
0x00613e:	movs    	r1, #0xe1
0x006140:	movs    	r2, #0x1d
0x006142:	adds    	r3, r5, #0
0x006144:	adds    	r0, r7, #0
0x006146:	bl      	#0x5324
0x00614a:	movs    	r1, #0
0x00614c:	movs    	r2, #0
0x00614e:	str     	r2, [sp, #8]
0x006150:	str     	r1, [sp]
0x006152:	str     	r1, [sp, #4]
0x006154:	movs    	r1, #0xe1
0x006156:	movs    	r2, #0x18
0x006158:	str     	r0, [sp, #0x10]
0x00615a:	adds    	r3, r5, #0
0x00615c:	adds    	r0, r7, #0
0x00615e:	bl      	#0x5324
0x006162:	ldr     	r0, [r0, #0xc]
0x006164:	movs    	r1, #0
0x006166:	movs    	r2, #0
0x006168:	str     	r2, [sp, #8]
0x00616a:	str     	r1, [sp]
0x00616c:	str     	r1, [sp, #4]
0x00616e:	movs    	r1, #0xe1
0x006170:	movs    	r2, #0x18
0x006172:	adds    	r3, r5, #0
0x006174:	str     	r0, [sp, #0xc]
0x006176:	adds    	r0, r7, #0
0x006178:	bl      	#0x5324
0x00617c:	ldr     	r3, [r0, #8]
0x00617e:	ldr     	r1, [sp, #0x10]
0x006180:	ldr     	r0, [sp, #0xc]
0x006182:	movs    	r2, #0
0x006184:	str     	r2, [sp, #8]
0x006186:	str     	r1, [sp, #4]
0x006188:	movs    	r1, #0x52
0x00618a:	adds    	r2, r6, #0
0x00618c:	str     	r0, [sp]
0x00618e:	adds    	r0, r7, #0
0x006190:	bl      	#0x5324
0x006194:	movs    	r1, #0
0x006196:	movs    	r2, #0
0x006198:	str     	r1, [sp]
0x00619a:	str     	r1, [sp, #4]
0x00619c:	movs    	r1, #0x49
0x00619e:	str     	r2, [sp, #8]
0x0061a0:	adds    	r3, r5, #0
0x0061a2:	adds    	r0, r7, #0
0x0061a4:	ldr     	r2, [sp, #0x14]
0x0061a6:	bl      	#0x5324
0x0061aa:	movs    	r1, #0
0x0061ac:	movs    	r2, #0
0x0061ae:	str     	r1, [sp]
0x0061b0:	str     	r1, [sp, #4]
0x0061b2:	movs    	r1, #0x49
0x0061b4:	str     	r2, [sp, #8]
0x0061b6:	adds    	r3, r5, #0
0x0061b8:	adds    	r0, r7, #0
0x0061ba:	ldr     	r2, [sp, #0x18]
0x0061bc:	bl      	#0x5324
0x0061c0:	movs    	r1, #0
0x0061c2:	movs    	r2, #0
0x0061c4:	str     	r1, [sp]
0x0061c6:	str     	r1, [sp, #4]
0x0061c8:	movs    	r1, #0x19
0x0061ca:	str     	r2, [sp, #8]
0x0061cc:	adds    	r3, r5, #0
0x0061ce:	adds    	r0, r7, #0
0x0061d0:	ldr     	r2, [sp, #0x1c]
0x0061d2:	bl      	#0x5324
0x0061d6:	movs    	r1, #0
0x0061d8:	str     	r1, [sp]
0x0061da:	movs    	r2, #0
0x0061dc:	str     	r1, [sp, #4]
0x0061de:	movs    	r1, #0x19
0x0061e0:	str     	r2, [sp, #8]
0x0061e2:	adds    	r3, r5, #0
0x0061e4:	adds    	r0, r7, #0
0x0061e6:	ldr     	r2, [sp, #0x20]
0x0061e8:	bl      	#0x5324
0x0061ec:	movs    	r1, #0
0x0061ee:	movs    	r2, #0
0x0061f0:	str     	r1, [sp]
0x0061f2:	str     	r1, [sp, #4]
0x0061f4:	movs    	r1, #0x49
0x0061f6:	str     	r2, [sp, #8]
0x0061f8:	adds    	r3, r5, #0
0x0061fa:	adds    	r0, r7, #0
0x0061fc:	ldr     	r2, [sp, #0x38]
0x0061fe:	bl      	#0x5324
0x006202:	movs    	r1, #0
0x006204:	adds    	r3, r5, #0
0x006206:	ldr     	r5, [pc, #0x24c]
0x006208:	str     	r1, [sp]
0x00620a:	str     	r1, [sp, #4]
0x00620c:	movs    	r2, #0
0x00620e:	str     	r2, [sp, #8]
0x006210:	movs    	r1, #0x26
0x006212:	add     	r5, sb
0x006214:	ldr     	r2, [r5, #0x68]
0x006216:	adds    	r0, r7, #0
0x006218:	bl      	#0x5324
0x00621c:	cmp     	r0, #0
0x00621e:	ble     	#0x62c0
0x006220:	movs    	r1, #0
0x006222:	str     	r1, [sp]
0x006224:	str     	r1, [sp, #4]
0x006226:	movs    	r2, #0
0x006228:	movs    	r5, #0
0x00622a:	adds    	r3, r5, #0
0x00622c:	movs    	r1, #0x19
0x00622e:	adds    	r0, r7, #0
0x006230:	str     	r2, [sp, #8]
0x006232:	bl      	#0x5324
0x006236:	movs    	r1, #0
0x006238:	adds    	r3, r5, #0
0x00623a:	ldr     	r5, [pc, #0x218]
0x00623c:	str     	r1, [sp]
0x00623e:	str     	r1, [sp, #4]
0x006240:	movs    	r2, #0

; ===== candidate_0064d6 =====
0x0064d6:	push    	{r0, r1, r2, r3, r6, r7, lr}
0x0064d8:	ldm     	r5, {r0, r1, r2, r3, r4, r5, r7}
0x0064da:	cdp2    	p0, #0xb, c0, c7, c1, #1
0x0064de:	movs    	r0, r0
0x0064e0:	push    	{r4, r6, r7}
0x0064e2:	stm     	r2!, {r4, r6, r7}
0x0064e4:	ldm     	r2!, {r0, r1, r4, r6, r7}
0x0064e6:	cdp2    	p0, #0xb, c0, c12, c0, #0
0x0064ea:	movs    	r0, r0
0x0064ec:	bpl     	#0x6484
0x0064ee:	vcvta.s32.f64	s24, d8
0x0064f2:	movs    	r0, r0
0x0064f4:	bpl     	#0x648c
0x0064f6:	vcvta.s32.f64	s24, d8
0x0064fa:	movs    	r2, r7
0x0064fc:	stm     	r3!, {r1, r3, r4, r5, r7}
0x0064fe:	bne     	#0x64a8
0x006500:	beq     	#0x6486
0x006502:	ldc     	p0, c0, [r1, #0]!
0x006506:	movs    	r0, r0

; ===== candidate_0064e0 =====
0x0064e0:	push    	{r4, r6, r7}
0x0064e2:	stm     	r2!, {r4, r6, r7}
0x0064e4:	ldm     	r2!, {r0, r1, r4, r6, r7}
0x0064e6:	cdp2    	p0, #0xb, c0, c12, c0, #0
0x0064ea:	movs    	r0, r0
0x0064ec:	bpl     	#0x6484
0x0064ee:	vcvta.s32.f64	s24, d8
0x0064f2:	movs    	r0, r0
0x0064f4:	bpl     	#0x648c
0x0064f6:	vcvta.s32.f64	s24, d8
0x0064fa:	movs    	r2, r7
0x0064fc:	stm     	r3!, {r1, r3, r4, r5, r7}
0x0064fe:	bne     	#0x64a8
0x006500:	beq     	#0x6486
0x006502:	ldc     	p0, c0, [r1, #0]!
0x006506:	movs    	r0, r0

; ===== candidate_0065e0 =====
0x0065e0:	push    	{r3, r5}

; ===== candidate_0065f8 =====
0x0065f8:	push    	{r3, r5}

; ===== candidate_006604 =====
0x006604:	push    	{r0, r1, r2, r3, r6, r7, lr}
0x006606:	cbz     	r5, #0x667c
0x006608:	ldm     	r2!, {r0, r1, r4, r6, r7}
0x00660a:	cdp2    	p14, #0xb, c12, c12, c8, #1

; ===== candidate_006618 =====
0x006618:	push    	{r0, r1, r2, r3, r6, r7, lr}
0x00661a:	cbz     	r5, #0x6690
0x00661c:	ldm     	r2!, {r0, r1, r4, r6, r7}
0x00661e:	cdp2    	p4, #0xb, c11, c12, c8, #1

; ===== candidate_006620 =====
0x006620:	push    	{r3, r5}

; ===== candidate_00664c =====
0x00664c:	push    	{r1, r2, r3, r6, r7}
0x00664e:	stm     	r1!, {r1, r2, r4, r5, r7}
0x006650:	movs    	r0, r0
0x006652:	movs    	r0, r0
0x006654:	ble     	#0x6600
0x006656:	udf     	#0xce
0x006658:	ldm     	r3!, {r2, r4, r5, r7}
0x00665a:	b       	#0x67de
0x00665c:	ldm     	r2!, {r0, r1, r4, r6, r7}
0x00665e:	cdp2    	p0, #0xb, c0, c12, c0, #0
0x006662:	movs    	r0, r0

; ===== candidate_006706 =====
0x006706:	push    	{r3, r4, r5, r7}
0x006708:	ldm     	r2!, {r0, r1, r4, r6, r7}
0x00670a:	cdp2    	p0, #0xb, c0, c12, c0, #0
0x00670e:	movs    	r0, r0
0x006710:	push    	{r4, r6, r7}
0x006712:	ldm     	r2!, {r0, r1, r4, r6, r7}
0x006714:	cdp2    	p0, #0xb, c0, c12, c0, #0
0x006718:	bkpt    	#0xc9
0x00671a:	ldc2    	p11, c12, [r3, #0x2d0]!
0x00671e:	b       	#0x68a2
0x006720:	ldm     	r2!, {r0, r1, r4, r6, r7}
0x006722:	cdp2    	p0, #0xb, c0, c12, c0, #0
0x006726:	movs    	r0, r0
0x006728:	bkpt    	#0xc9
0x00672a:	ldc2    	p10, c12, [r3, #0x34c]!
0x00672e:	cdp2    	p0, #0xb, c0, c12, c0, #0
0x006732:	movs    	r0, r0
0x006734:	blo     	#0x66b0
0x006736:	add     	r2, sp, #0x338
0x006738:	stm     	r3!, {r1, r3, r4, r5, r7}
0x00673a:	bne     	#0x66e4
0x00673c:	movs    	r0, r0
0x00673e:	movs    	r0, r0

; ===== candidate_006710 =====
0x006710:	push    	{r4, r6, r7}
0x006712:	ldm     	r2!, {r0, r1, r4, r6, r7}
0x006714:	cdp2    	p0, #0xb, c0, c12, c0, #0
0x006718:	bkpt    	#0xc9
0x00671a:	ldc2    	p11, c12, [r3, #0x2d0]!
0x00671e:	b       	#0x68a2
0x006720:	ldm     	r2!, {r0, r1, r4, r6, r7}
0x006722:	cdp2    	p0, #0xb, c0, c12, c0, #0
0x006726:	movs    	r0, r0
0x006728:	bkpt    	#0xc9
0x00672a:	ldc2    	p10, c12, [r3, #0x34c]!
0x00672e:	cdp2    	p0, #0xb, c0, c12, c0, #0
0x006732:	movs    	r0, r0
0x006734:	blo     	#0x66b0
0x006736:	add     	r2, sp, #0x338
0x006738:	stm     	r3!, {r1, r3, r4, r5, r7}
0x00673a:	bne     	#0x66e4
0x00673c:	movs    	r0, r0
0x00673e:	movs    	r0, r0

; ===== candidate_006742 =====
0x006742:	push    	{r0, r1, r2, r3, r4, r5, r7}
0x006744:	adr     	r2, #0x2dc
0x006746:	vcvta.s32.f64	s24, d8
0x00674a:	movs    	r0, r0
0x00674c:	push    	{r0, r1, r2, r4, r5, r7, lr}
0x00674e:	bhi     	#0x66c8
0x006750:	movs    	r0, r0
0x006752:	movs    	r0, r0
0x006754:	ldm     	r2!, {r0, r1, r4, r6, r7}
0x006756:	mrc2    	p2, #5, sl, c12, c7, #5
0x00675a:	ldm     	r5!, {r0, r1, r3, r6, r7}
0x00675c:	beq     	#0x670c
0x00675e:	cmp     	r6, #0x2e
0x006760:	movs    	r6, r5
0x006762:	movs    	r0, r0
0x006764:	rsb     	r1, r7, r1, lsr #11
0x006768:	bl      	#0xddb300
0x00676c:	vcvta.s32.f64	s24, d8
0x006770:	movs    	r1, r4
0x006772:	movs    	r0, r0
0x006774:	rsb     	r4, r7, sl, lsl #27
0x006778:	rsb     	sl, r8, r1, ror #26
0x00677c:	b       	#0x6d18
0x00677e:	movs    	r1, r4
0x006780:	rsb     	r4, r7, sl, lsl #27
0x006784:	rsb     	sl, r8, r3, lsr #19
0x006788:	vcvta.s32.f32	s26, s8
0x00678c:	ble     	#0x6720
0x00678e:	movs    	r0, r0
0x006790:	pop     	{r3, r4, r5, r7, pc}

; ===== candidate_00674c =====
0x00674c:	push    	{r0, r1, r2, r4, r5, r7, lr}
0x00674e:	bhi     	#0x66c8
0x006750:	movs    	r0, r0
0x006752:	movs    	r0, r0
0x006754:	ldm     	r2!, {r0, r1, r4, r6, r7}
0x006756:	mrc2    	p2, #5, sl, c12, c7, #5
0x00675a:	ldm     	r5!, {r0, r1, r3, r6, r7}
0x00675c:	beq     	#0x670c
0x00675e:	cmp     	r6, #0x2e
0x006760:	movs    	r6, r5
0x006762:	movs    	r0, r0
0x006764:	rsb     	r1, r7, r1, lsr #11
0x006768:	bl      	#0xddb300
0x00676c:	vcvta.s32.f64	s24, d8
0x006770:	movs    	r1, r4
0x006772:	movs    	r0, r0
0x006774:	rsb     	r4, r7, sl, lsl #27
0x006778:	rsb     	sl, r8, r1, ror #26
0x00677c:	b       	#0x6d18
0x00677e:	movs    	r1, r4
0x006780:	rsb     	r4, r7, sl, lsl #27
0x006784:	rsb     	sl, r8, r3, lsr #19
0x006788:	vcvta.s32.f32	s26, s8
0x00678c:	ble     	#0x6720
0x00678e:	movs    	r0, r0
0x006790:	pop     	{r3, r4, r5, r7, pc}

; ===== candidate_0067c0 =====
0x0067c0:	push    	{r1, r2, r4, r6, r7, lr}
0x0067c2:	movs    	r0, r0
0x0067c4:	stm     	r7!, {r1, r3, r6, r7}
0x0067c6:	b.w     	#0x5be75a
0x0067ca:	add     	r0, sp, #0x2d8
0x0067cc:	adr     	r2, #0x2dc
0x0067ce:	ldm     	r5!, {r0, r1, r3, r6, r7}
0x0067d0:	ldm     	r2!, {r0, r1, r4, r6, r7}
0x0067d2:	cdp2    	p15, #0xb, c11, c12, c3, #5
0x0067d6:	movs    	r0, r0
