; fallback candidate disassembly from Thumb prologues; true code is ARM entry + Thumb functions.

; ARM entry
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0x713c
0x000018:	pop     	{r4, pc}
0x00001c:	andeq   	r4, r0, r8, ror r7
0x000020:	ands    	r2, r0, #128, #8
0x000024:	rsbmi   	r0, r0, #0
0x000028:	eors    	r3, r2, r1, asr #32
0x00002c:	rsbhs   	r1, r1, #0
0x000030:	rsbs    	ip, r0, r1, lsr #3
0x000034:	blo     	#0xbc
0x000038:	rsbs    	ip, r0, r1, lsr #8
0x00003c:	blo     	#0x80
0x000040:	lsl     	r0, r0, #8
0x000044:	orr     	r2, r2, #0xff000000
0x000048:	rsbs    	ip, r0, r1, lsr #4
0x00004c:	blo     	#0xb0
0x000050:	rsbs    	ip, r0, r1, lsr #8
0x000054:	blo     	#0x80
0x000058:	lsl     	r0, r0, #8
0x00005c:	orr     	r2, r2, #0xff0000
0x000060:	rsbs    	ip, r0, r1, lsr #8
0x000064:	lslhs   	r0, r0, #8
0x000068:	orrhs   	r2, r2, #0xff00
0x00006c:	rsbs    	ip, r0, r1, lsr #4
0x000070:	blo     	#0xb0
0x000074:	rsbs    	ip, r0, #0
0x000078:	bhs     	#0xf8
0x00007c:	lsrhs   	r0, r0, #8
0x000080:	rsbs    	ip, r0, r1, lsr #7
0x000084:	subhs   	r1, r1, r0, lsl #7
0x000088:	adc     	r2, r2, r2
0x00008c:	rsbs    	ip, r0, r1, lsr #6
0x000090:	subhs   	r1, r1, r0, lsl #6
0x000094:	adc     	r2, r2, r2
0x000098:	rsbs    	ip, r0, r1, lsr #5
0x00009c:	subhs   	r1, r1, r0, lsl #5
0x0000a0:	adc     	r2, r2, r2
0x0000a4:	rsbs    	ip, r0, r1, lsr #4
0x0000a8:	subhs   	r1, r1, r0, lsl #4
0x0000ac:	adc     	r2, r2, r2
0x0000b0:	rsbs    	ip, r0, r1, lsr #3
0x0000b4:	subhs   	r1, r1, r0, lsl #3
0x0000b8:	adc     	r2, r2, r2
0x0000bc:	rsbs    	ip, r0, r1, lsr #2
0x0000c0:	subhs   	r1, r1, r0, lsl #2
0x0000c4:	adc     	r2, r2, r2
0x0000c8:	rsbs    	ip, r0, r1, lsr #1
0x0000cc:	subhs   	r1, r1, r0, lsl #1
0x0000d0:	adc     	r2, r2, r2
0x0000d4:	rsbs    	ip, r0, r1
0x0000d8:	subhs   	r1, r1, r0
0x0000dc:	adcs    	r2, r2, r2
0x0000e0:	bhs     	#0x7c
0x0000e4:	eors    	r0, r2, r3, asr #31
0x0000e8:	add     	r0, r0, r3, lsr #31
0x0000ec:	rsbhs   	r1, r1, #0
0x0000f0:	bx      	lr
0x0000f4:	andeq   	r4, r0, r8, ror r7
0x0000f8:	mov     	r0, #2
0x0000fc:	mov     	r1, #2
0x000100:	b       	#0x118
0x000104:	strmi   	r4, [r8, -r0, lsl #14]

; ===== candidate_000008 =====
0x000008:	ands    	r0, r2
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	adds    	r0, r1, #1

; ===== candidate_00000a =====
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	adds    	r0, r1, #1

; ===== candidate_00011a =====
0x00011a:	stmdb   	sp!, {r2}

; ===== candidate_000134 =====
0x000134:	push    	{r4, r5, r6, lr}
0x000136:	ldr     	r6, [pc, #0x38]
0x000138:	adds    	r5, r1, #0
0x00013a:	adds    	r1, r0, #0
0x00013c:	adds    	r4, r0, #0
0x00013e:	add     	r6, pc
0x000140:	adds    	r0, r6, #0
0x000142:	bl      	#0x146
0x000146:	adds    	r2, r0, #0
0x000148:	cmp     	r0, r6
0x00014a:	bne     	#0x15a
0x00014c:	adds    	r1, r5, #0
0x00014e:	adds    	r0, r4, #0
0x000150:	bl      	#0x194
0x000154:	pop     	{r4, r5, r6}
0x000156:	pop     	{r3}
0x000158:	bx      	r3
0x00015a:	ldr     	r0, [pc, #0x18]
0x00015c:	add     	r0, pc
0x00015e:	cmp     	r2, r0
0x000160:	beq     	#0x16a
0x000162:	adds    	r1, r5, #0
0x000164:	adds    	r0, r4, #0
0x000166:	bl      	#0x108
0x00016a:	movs    	r0, #0
0x00016c:	b       	#0x154
0x00016e:	movs    	r0, r0
0x000170:	mcr2    	p15, #6, pc, c5, c7, #7
0x000174:	mcr2    	p15, #5, pc, c5, c7, #7
0x000178:	bx      	pc

; ===== candidate_000194 =====
0x000194:	push    	{r3, r4, r5, lr}
0x000196:	subs    	r2, r0, #1
0x000198:	cmp     	r2, #0xd
0x00019a:	adr     	r4, #0x90
0x00019c:	bhs     	#0x1ec
0x00019e:	movs    	r2, #0x17
0x0001a0:	ldr     	r3, [pc, #0x8c]
0x0001a2:	muls    	r2, r0, r2
0x0001a4:	add     	r3, pc
0x0001a6:	adds    	r5, r2, r3
0x0001a8:	subs    	r5, #0x17
0x0001aa:	cmp     	r0, #2
0x0001ac:	bne     	#0x1d8
0x0001ae:	lsls    	r0, r1, #5
0x0001b0:	bpl     	#0x1b6
0x0001b2:	adr     	r4, #0x80
0x0001b4:	b       	#0x1ee
0x0001b6:	ldr     	r0, [pc, #0x90]
0x0001b8:	ands    	r0, r1
0x0001ba:	beq     	#0x1c0
0x0001bc:	adr     	r4, #0x8c
0x0001be:	b       	#0x1ee
0x0001c0:	lsls    	r0, r1, #3
0x0001c2:	bpl     	#0x1c8
0x0001c4:	adr     	r4, #0x94
0x0001c6:	b       	#0x1ee
0x0001c8:	lsls    	r0, r1, #2
0x0001ca:	bpl     	#0x1d0
0x0001cc:	adr     	r4, #0x98
0x0001ce:	b       	#0x1ee
0x0001d0:	lsls    	r0, r1, #1
0x0001d2:	bpl     	#0x1ee
0x0001d4:	adr     	r4, #0x9c
0x0001d6:	b       	#0x1ee
0x0001d8:	cmp     	r0, #8
0x0001da:	bne     	#0x1e0
0x0001dc:	adds    	r4, r1, #0
0x0001de:	b       	#0x1ee
0x0001e0:	cmp     	r0, #9
0x0001e2:	bne     	#0x1ee
0x0001e4:	cmp     	r1, #1
0x0001e6:	bne     	#0x1ee
0x0001e8:	adr     	r5, #0x98
0x0001ea:	b       	#0x1ee
0x0001ec:	adr     	r5, #0xac
0x0001ee:	movs    	r0, #0xa
0x0001f0:	bl      	#0x2b4
0x0001f4:	ldrb    	r0, [r5]
0x0001f6:	cmp     	r0, #0
0x0001f8:	beq     	#0x208
0x0001fa:	ldrb    	r0, [r5]
0x0001fc:	adds    	r5, #1
0x0001fe:	bl      	#0x2b4
0x000202:	ldrb    	r0, [r5]
0x000204:	cmp     	r0, #0
0x000206:	bne     	#0x1fa
0x000208:	ldrb    	r0, [r4]
0x00020a:	cmp     	r0, #0
0x00020c:	beq     	#0x21c
0x00020e:	ldrb    	r0, [r4]
0x000210:	adds    	r4, #1
0x000212:	bl      	#0x2b4
0x000216:	ldrb    	r0, [r4]
0x000218:	cmp     	r0, #0
0x00021a:	bne     	#0x20e
0x00021c:	movs    	r0, #0xa
0x00021e:	bl      	#0x2b4
0x000222:	pop     	{r3, r4, r5}
0x000224:	pop     	{r3}
0x000226:	movs    	r0, #1
0x000228:	bx      	r3
0x00022a:	movs    	r0, r0
0x00022c:	movs    	r0, r0
0x00022e:	movs    	r0, r0
0x000230:	ldrh    	r0, [r4, #0x14]
0x000232:	movs    	r0, r0
0x000234:	ldr     	r1, [r1, #0x64]
0x000236:	str     	r6, [r6, #0x14]
0x000238:	ldr     	r4, [r5, #0x14]
0x00023a:	movs    	r0, #0x64
0x00023c:	strb    	r7, [r1, #1]
0x00023e:	strb    	r5, [r4, #9]
0x000240:	strb    	r1, [r4, #0x11]
0x000242:	ldr     	r1, [r5, #0x74]
0x000244:	lsls    	r6, r5, #1
0x000246:	movs    	r0, r0
0x000248:	movs    	r2, r0
0x00024a:	lsrs    	r0, r0, #0x20
0x00024c:	ldr     	r4, [r0, #0x14]
0x00024e:	ldr     	r6, [r6, #0x14]
0x000250:	str     	r4, [r4, #0x54]
0x000252:	tst     	r0, r4
0x000254:	movs    	r0, #0x79
0x000256:	str     	r2, [r3, #0x54]
0x000258:	ldr     	r2, [r6, #0x74]
0x00025a:	movs    	r0, r0
0x00025c:	strb    	r7, [r1, #0x19]
0x00025e:	strb    	r5, [r4, #9]
0x000260:	ldr     	r6, [r4, #0x44]
0x000262:	strb    	r7, [r5, #0x1d]
0x000264:	movs    	r0, r0
0x000266:	movs    	r0, r0
0x000268:	ldr     	r5, [r2, #0x64]
0x00026a:	str     	r4, [r4, #0x54]
0x00026c:	str     	r2, [r6, #0x64]
0x00026e:	ldr     	r4, [r5, #0x74]
0x000270:	lsls    	r7, r6, #1
0x000272:	movs    	r0, r0
0x000274:	ldr     	r1, [r1, #0x64]
0x000276:	ldrb    	r5, [r4, #1]
0x000278:	str     	r1, [r4, #0x34]
0x00027a:	movs    	r0, #0x74
0x00027c:	str     	r2, [r2, #0x54]
0x00027e:	strb    	r3, [r6, #0x15]
0x000280:	strb    	r4, [r5, #0x11]
0x000282:	movs    	r0, r0
0x000284:	movs    	r0, #0x3a
0x000286:	str     	r0, [r1, #0x54]
0x000288:	strb    	r1, [r4, #1]
0x00028a:	ldr     	r0, [r4, #0x50]
0x00028c:	ldr     	r5, [r4, #0x54]
0x00028e:	strb    	r7, [r5, #9]
0x000290:	movs    	r0, #0x79
0x000292:	ldr     	r3, [r4, #0x74]
0x000294:	strb    	r2, [r6, #9]
0x000296:	strb    	r5, [r6, #1]
0x000298:	str     	r4, [r6, #0x54]
0x00029a:	lsls    	r4, r4, #1
0x00029c:	ldr     	r5, [r2, #0x64]
0x00029e:	ldr     	r3, [r5, #0x64]
0x0002a0:	strb    	r7, [r5, #0x1d]
0x0002a2:	movs    	r0, #0x6e
0x0002a4:	ldr     	r3, [r6, #0x14]
0x0002a6:	ldr     	r7, [r4, #0x64]
0x0002a8:	ldr     	r1, [r4, #0x44]
0x0002aa:	movs    	r0, r0
0x0002ac:	bx      	pc

; ===== candidate_0002b4 =====
0x0002b4:	push    	{r3, lr}
0x0002b6:	add     	r3, sp, #0
0x0002b8:	strb    	r0, [r3]
0x0002ba:	movs    	r0, #3
0x0002bc:	mov     	r1, sp
0x0002be:	svc     	#0xab
0x0002c0:	add     	sp, #4
0x0002c2:	pop     	{r3}
0x0002c4:	bx      	r3
0x0002c6:	movs    	r0, r0
0x0002c8:	movs    	r0, r1
0x0002ca:	b       	#0xfffffe0c
0x0002cc:	asrs    	r0, r1, #0x20
0x0002ce:	b       	#0xfffffe10
0x0002d0:	movs    	r1, r0
0x0002d2:	b       	#0x3d6
0x0002d4:	vrhadd.u16	d14, d14, d31
0x0002d8:	movs    	r4, r0
0x0002da:	movs    	r0, r0
0x0002dc:	lsls    	r4, r3, #7
0x0002de:	movs    	r0, r0
0x0002e0:	str     	r0, [sp]
0x0002e2:	b       	#0x626
0x0002e4:	vrhadd.u16	d14, d14, d31
0x0002e8:	adds    	r0, #0x14
0x0002ea:	b       	#0xfffffe2c
0x0002ec:	cmp     	r7, #0xc0
0x0002ee:	b       	#0x632
0x0002f0:	stm     	r0!, {r0, r1, r4, r7}
0x0002f2:	b       	#0x478
0x0002f4:	adds    	r0, #0x18
0x0002f6:	b       	#0xaba
0x0002f8:	asrs    	r1, r0, #7
0x0002fa:	b       	#0x3c2
0x0002fc:	lsls    	r3, r2, #6
0x0002fe:	b       	#0x342
0x000300:	vrhadd.u16	d14, d14, d31
0x000304:	strh    	r7, [r3, #0x28]
0x000306:	str     	r3, [r5, r7]
0x000308:	adds    	r0, #0x14
0x00030a:	b       	#0xfffffe4c
0x00030c:	cmp     	r7, #0xc0
0x00030e:	b       	#0x652
0x000310:	stm     	r0!, {r0, r1, r4, r7}
0x000312:	b       	#0x498
0x000314:	adds    	r0, #2
0x000316:	b       	#0xada
0x000318:	asrs    	r1, r0, #0x20
0x00031a:	b       	#0x3e2
0x00031c:	lsls    	r3, r2, #6
0x00031e:	b       	#0x362
0x000320:	vrhadd.u16	d14, d14, d31
0x000324:	strb    	r6, [r2, r5]
0x000326:	strb    	r5, [r2, r5]
0x000328:	push    	{r4, r5, lr}
0x00032a:	ldr     	r4, [pc, #0xb4]
0x00032c:	movs    	r2, #0x1c
0x00032e:	add     	r4, pc
0x000330:	ldr     	r0, [r4, #0x38]
0x000332:	movs    	r1, #0
0x000334:	ldr     	r3, [r0, #0x38]
0x000336:	ldr     	r0, [pc, #0xac]
0x000338:	sub     	sp, #0xc
0x00033a:	add     	r0, sb
0x00033c:	blx     	r3
0x00033e:	movs    	r2, #0
0x000340:	movs    	r0, #0
0x000342:	str     	r0, [sp]
0x000344:	ldr     	r1, [pc, #0x9c]
0x000346:	movs    	r3, #0
0x000348:	add     	r1, sb
0x00034a:	str     	r1, [sp, #4]
0x00034c:	movs    	r1, #0x64
0x00034e:	movs    	r0, #1
0x000350:	str     	r2, [sp, #8]
0x000352:	bl      	#0x7214
0x000356:	ldr     	r1, [pc, #0x8c]
0x000358:	movs    	r0, #0
0x00035a:	add     	r1, sb
0x00035c:	subs    	r1, #0x7c
0x00035e:	str     	r0, [r1, #8]
0x000360:	ldr     	r5, [pc, #0x80]
0x000362:	str     	r0, [r1, #0x10]
0x000364:	str     	r0, [r1, #0xc]
0x000366:	add     	r5, sb
0x000368:	subs    	r5, #0xfc
0x00036a:	movs    	r0, #1
0x00036c:	str     	r0, [r5, #0x18]
0x00036e:	ldr     	r0, [r4, #0x38]
0x000370:	ldr     	r2, [pc, #0x74]
0x000372:	ldr     	r1, [r0, #0x68]
0x000374:	add     	r2, sb
0x000376:	str     	r1, [r5, #0x2c]
0x000378:	ldr     	r1, [r0, #0xc]
0x00037a:	ldr     	r4, [pc, #0x70]
0x00037c:	str     	r1, [r5, #0x30]
0x00037e:	ldr     	r1, [r0, #0x10]
0x000380:	str     	r1, [r5, #0x34]
0x000382:	ldr     	r1, [r0, #0x14]
0x000384:	str     	r1, [r5, #0x38]
0x000386:	ldr     	r1, [r0, #0x18]
0x000388:	str     	r1, [r5, #0x3c]
0x00038a:	ldr     	r1, [r0, #0x1c]
0x00038c:	str     	r1, [r5, #0x40]
0x00038e:	ldr     	r1, [r0, #0x20]
0x000390:	str     	r1, [r5, #0x44]
0x000392:	ldr     	r1, [r0, #0x24]
0x000394:	str     	r1, [r5, #0x48]
0x000396:	ldr     	r1, [r0, #0x28]
0x000398:	str     	r1, [r5, #0x4c]
0x00039a:	ldr     	r1, [r0, #0x2c]
0x00039c:	str     	r1, [r5, #0x50]
0x00039e:	ldr     	r1, [r0, #0x30]
0x0003a0:	str     	r1, [r5, #0x54]
0x0003a2:	ldr     	r1, [r0, #0x34]
0x0003a4:	str     	r1, [r5, #0x58]
0x0003a6:	ldr     	r1, [r0, #0x38]
0x0003a8:	str     	r1, [r5, #0x5c]
0x0003aa:	ldr     	r1, [r0, #0x3c]
0x0003ac:	str     	r1, [r5, #0x60]
0x0003ae:	ldr     	r1, [r0, #0x40]
0x0003b0:	str     	r1, [r5, #0x64]
0x0003b2:	ldr     	r1, [r0, #0x44]
0x0003b4:	str     	r1, [r5, #0x68]
0x0003b6:	ldr     	r1, [r0, #0x48]
0x0003b8:	str     	r1, [r5, #0x6c]
0x0003ba:	ldr     	r1, [r0, #0x4c]
0x0003bc:	str     	r1, [r5, #0x70]
0x0003be:	movs    	r1, #0
0x0003c0:	str     	r1, [r2]
0x0003c2:	movs    	r1, #1
0x0003c4:	lsls    	r1, r1, #9
0x0003c6:	adds    	r0, r0, r1
0x0003c8:	ldr     	r3, [r0, #8]
0x0003ca:	movs    	r1, #7
0x0003cc:	adds    	r2, r4, #0
0x0003ce:	movs    	r0, #0
0x0003d0:	blx     	r3
0x0003d2:	cmp     	r0, r4
0x0003d4:	bne     	#0x3da
0x0003d6:	subs    	r0, #2

; ===== candidate_000328 =====
0x000328:	push    	{r4, r5, lr}
0x00032a:	ldr     	r4, [pc, #0xb4]
0x00032c:	movs    	r2, #0x1c
0x00032e:	add     	r4, pc
0x000330:	ldr     	r0, [r4, #0x38]
0x000332:	movs    	r1, #0
0x000334:	ldr     	r3, [r0, #0x38]
0x000336:	ldr     	r0, [pc, #0xac]
0x000338:	sub     	sp, #0xc
0x00033a:	add     	r0, sb
0x00033c:	blx     	r3
0x00033e:	movs    	r2, #0
0x000340:	movs    	r0, #0
0x000342:	str     	r0, [sp]
0x000344:	ldr     	r1, [pc, #0x9c]
0x000346:	movs    	r3, #0
0x000348:	add     	r1, sb
0x00034a:	str     	r1, [sp, #4]
0x00034c:	movs    	r1, #0x64
0x00034e:	movs    	r0, #1
0x000350:	str     	r2, [sp, #8]
0x000352:	bl      	#0x7214
0x000356:	ldr     	r1, [pc, #0x8c]
0x000358:	movs    	r0, #0
0x00035a:	add     	r1, sb
0x00035c:	subs    	r1, #0x7c
0x00035e:	str     	r0, [r1, #8]
0x000360:	ldr     	r5, [pc, #0x80]
0x000362:	str     	r0, [r1, #0x10]
0x000364:	str     	r0, [r1, #0xc]
0x000366:	add     	r5, sb
0x000368:	subs    	r5, #0xfc
0x00036a:	movs    	r0, #1
0x00036c:	str     	r0, [r5, #0x18]
0x00036e:	ldr     	r0, [r4, #0x38]
0x000370:	ldr     	r2, [pc, #0x74]
0x000372:	ldr     	r1, [r0, #0x68]
0x000374:	add     	r2, sb
0x000376:	str     	r1, [r5, #0x2c]
0x000378:	ldr     	r1, [r0, #0xc]
0x00037a:	ldr     	r4, [pc, #0x70]
0x00037c:	str     	r1, [r5, #0x30]
0x00037e:	ldr     	r1, [r0, #0x10]
0x000380:	str     	r1, [r5, #0x34]
0x000382:	ldr     	r1, [r0, #0x14]
0x000384:	str     	r1, [r5, #0x38]
0x000386:	ldr     	r1, [r0, #0x18]
0x000388:	str     	r1, [r5, #0x3c]
0x00038a:	ldr     	r1, [r0, #0x1c]
0x00038c:	str     	r1, [r5, #0x40]
0x00038e:	ldr     	r1, [r0, #0x20]
0x000390:	str     	r1, [r5, #0x44]
0x000392:	ldr     	r1, [r0, #0x24]
0x000394:	str     	r1, [r5, #0x48]
0x000396:	ldr     	r1, [r0, #0x28]
0x000398:	str     	r1, [r5, #0x4c]
0x00039a:	ldr     	r1, [r0, #0x2c]
0x00039c:	str     	r1, [r5, #0x50]
0x00039e:	ldr     	r1, [r0, #0x30]
0x0003a0:	str     	r1, [r5, #0x54]
0x0003a2:	ldr     	r1, [r0, #0x34]
0x0003a4:	str     	r1, [r5, #0x58]
0x0003a6:	ldr     	r1, [r0, #0x38]
0x0003a8:	str     	r1, [r5, #0x5c]
0x0003aa:	ldr     	r1, [r0, #0x3c]
0x0003ac:	str     	r1, [r5, #0x60]
0x0003ae:	ldr     	r1, [r0, #0x40]
0x0003b0:	str     	r1, [r5, #0x64]
0x0003b2:	ldr     	r1, [r0, #0x44]
0x0003b4:	str     	r1, [r5, #0x68]
0x0003b6:	ldr     	r1, [r0, #0x48]
0x0003b8:	str     	r1, [r5, #0x6c]
0x0003ba:	ldr     	r1, [r0, #0x4c]
0x0003bc:	str     	r1, [r5, #0x70]
0x0003be:	movs    	r1, #0
0x0003c0:	str     	r1, [r2]
0x0003c2:	movs    	r1, #1
0x0003c4:	lsls    	r1, r1, #9
0x0003c6:	adds    	r0, r0, r1
0x0003c8:	ldr     	r3, [r0, #8]
0x0003ca:	movs    	r1, #7
0x0003cc:	adds    	r2, r4, #0
0x0003ce:	movs    	r0, #0
0x0003d0:	blx     	r3
0x0003d2:	cmp     	r0, r4
0x0003d4:	bne     	#0x3da
0x0003d6:	subs    	r0, #2
0x0003d8:	str     	r0, [r5, #0x28]
0x0003da:	add     	sp, #0xc
0x0003dc:	pop     	{r4, r5, pc}

; ===== candidate_0003f0 =====
0x0003f0:	push    	{r4, lr}
0x0003f2:	sub     	sp, #0x10
0x0003f4:	movs    	r1, #0
0x0003f6:	movs    	r2, #0
0x0003f8:	str     	r2, [sp, #8]
0x0003fa:	str     	r1, [sp]
0x0003fc:	str     	r1, [sp, #4]
0x0003fe:	movs    	r4, #0
0x000400:	adds    	r3, r4, #0
0x000402:	movs    	r1, #0x67
0x000404:	movs    	r2, #0x14
0x000406:	movs    	r0, #0xf1
0x000408:	lsls    	r0, r0, #9
0x00040a:	bl      	#0x7214
0x00040e:	movs    	r1, #0
0x000410:	str     	r1, [sp]
0x000412:	str     	r1, [sp, #4]
0x000414:	movs    	r2, #0
0x000416:	movs    	r1, #0x34
0x000418:	adds    	r3, r4, #0
0x00041a:	movs    	r0, #0xf1
0x00041c:	lsls    	r0, r0, #9
0x00041e:	str     	r2, [sp, #8]
0x000420:	bl      	#0x7214
0x000424:	movs    	r2, #0
0x000426:	movs    	r1, #0
0x000428:	str     	r2, [sp, #8]
0x00042a:	ldr     	r2, [pc, #0x18]
0x00042c:	str     	r1, [sp]
0x00042e:	str     	r1, [sp, #4]
0x000430:	adds    	r3, r4, #0
0x000432:	add     	r2, pc
0x000434:	movs    	r1, #0x33
0x000436:	movs    	r0, #0xf1
0x000438:	lsls    	r0, r0, #9
0x00043a:	bl      	#0x7214
0x00043e:	add     	sp, #0x10
0x000440:	pop     	{r4, pc}

; ===== candidate_000448 =====
0x000448:	push    	{r4, r5, r6, r7, lr}
0x00044a:	sub     	sp, #0xc
0x00044c:	movs    	r6, #0
0x00044e:	movs    	r2, #0
0x000450:	movs    	r1, #0
0x000452:	str     	r2, [sp, #8]
0x000454:	adds    	r3, r6, #0
0x000456:	adds    	r4, r0, #0
0x000458:	adds    	r2, r0, #0
0x00045a:	str     	r1, [sp]
0x00045c:	str     	r1, [sp, #4]
0x00045e:	movs    	r1, #0x44
0x000460:	movs    	r0, #0xf1
0x000462:	lsls    	r0, r0, #9
0x000464:	bl      	#0x7214
0x000468:	movs    	r1, #0
0x00046a:	str     	r1, [sp]
0x00046c:	str     	r1, [sp, #4]
0x00046e:	movs    	r2, #0
0x000470:	str     	r2, [sp, #8]
0x000472:	movs    	r1, #0x45
0x000474:	adds    	r3, r6, #0
0x000476:	movs    	r0, #0xf1
0x000478:	lsls    	r0, r0, #9
0x00047a:	ldr     	r2, [r4, #8]
0x00047c:	bl      	#0x7214
0x000480:	movs    	r1, #0
0x000482:	str     	r1, [sp]
0x000484:	str     	r1, [sp, #4]
0x000486:	adds    	r7, r0, #0
0x000488:	movs    	r2, #0
0x00048a:	str     	r2, [sp, #8]
0x00048c:	movs    	r0, #0xf1
0x00048e:	adds    	r3, r6, #0
0x000490:	movs    	r1, #0x45
0x000492:	lsls    	r0, r0, #9
0x000494:	ldr     	r2, [r4, #8]
0x000496:	bl      	#0x7214
0x00049a:	movs    	r1, #0
0x00049c:	str     	r1, [sp]
0x00049e:	str     	r1, [sp, #4]
0x0004a0:	adds    	r5, r0, #0
0x0004a2:	movs    	r2, #0
0x0004a4:	str     	r2, [sp, #8]
0x0004a6:	movs    	r0, #0xf1
0x0004a8:	adds    	r3, r6, #0
0x0004aa:	movs    	r1, #0x45
0x0004ac:	lsls    	r0, r0, #9
0x0004ae:	ldr     	r2, [r4, #8]
0x0004b0:	bl      	#0x7214
0x0004b4:	lsls    	r4, r0, #0x18
0x0004b6:	adds    	r0, r7, #0
0x0004b8:	ldr     	r7, [pc, #0x54]
0x0004ba:	adds    	r3, r6, #0
0x0004bc:	add     	r7, sb
0x0004be:	ldr     	r1, [r7, #0x1c]
0x0004c0:	ldr     	r2, [r7, #0x24]
0x0004c2:	lsls    	r1, r1, #2
0x0004c4:	ldr     	r1, [r2, r1]
0x0004c6:	movs    	r2, #0
0x0004c8:	str     	r0, [r1, #0x14]
0x0004ca:	movs    	r1, #0
0x0004cc:	str     	r1, [sp]
0x0004ce:	str     	r1, [sp, #4]
0x0004d0:	movs    	r1, #0x2c
0x0004d2:	movs    	r0, #0xf1
0x0004d4:	asrs    	r4, r4, #0x18
0x0004d6:	lsls    	r0, r0, #9
0x0004d8:	str     	r2, [sp, #8]
0x0004da:	bl      	#0x7214
0x0004de:	ldr     	r0, [r7, #0x18]
0x0004e0:	cmp     	r0, #0
0x0004e2:	beq     	#0x4fc
0x0004e4:	ldr     	r3, [pc, #0x2c]
0x0004e6:	cmp     	r4, r3
0x0004e8:	beq     	#0x500
0x0004ea:	adds    	r3, #1
0x0004ec:	cmp     	r4, r3
0x0004ee:	beq     	#0x508
0x0004f0:	adds    	r3, #1
0x0004f2:	cmp     	r4, r3
0x0004f4:	bne     	#0x4fc
0x0004f6:	ldr     	r1, [r0, #0x28]
0x0004f8:	adds    	r1, r1, r5
0x0004fa:	str     	r1, [r0, #0x28]
0x0004fc:	add     	sp, #0xc
0x0004fe:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000518 =====
0x000518:	push    	{r4, r5, r6, r7, lr}
0x00051a:	sub     	sp, #0x24
0x00051c:	movs    	r7, #0
0x00051e:	movs    	r2, #0
0x000520:	movs    	r1, #0
0x000522:	str     	r2, [sp, #8]
0x000524:	adds    	r3, r7, #0
0x000526:	adds    	r5, r0, #0
0x000528:	adds    	r2, r0, #0
0x00052a:	str     	r1, [sp]
0x00052c:	str     	r1, [sp, #4]
0x00052e:	movs    	r1, #0x44
0x000530:	movs    	r0, #0xf1
0x000532:	movs    	r6, #0
0x000534:	lsls    	r0, r0, #9
0x000536:	bl      	#0x7214
0x00053a:	bl      	#0x7bbc
0x00053e:	movs    	r1, #0
0x000540:	str     	r1, [sp]
0x000542:	str     	r1, [sp, #4]
0x000544:	movs    	r2, #0
0x000546:	str     	r2, [sp, #8]
0x000548:	movs    	r1, #0x45
0x00054a:	adds    	r3, r7, #0
0x00054c:	movs    	r0, #0xf1
0x00054e:	lsls    	r0, r0, #9
0x000550:	ldr     	r2, [r5, #8]
0x000552:	bl      	#0x7214
0x000556:	str     	r0, [sp, #0x20]
0x000558:	movs    	r2, #0
0x00055a:	movs    	r1, #0
0x00055c:	str     	r2, [sp, #8]
0x00055e:	adds    	r2, r0, #0
0x000560:	str     	r1, [sp]
0x000562:	str     	r1, [sp, #4]
0x000564:	movs    	r1, #0xa
0x000566:	movs    	r0, #0xf1
0x000568:	movs    	r3, #4
0x00056a:	lsls    	r0, r0, #9
0x00056c:	bl      	#0x7214
0x000570:	ldr     	r1, [pc, #0x130]
0x000572:	add     	r1, sb
0x000574:	str     	r0, [r1, #0x24]
0x000576:	ldr     	r0, [sp, #0x20]
0x000578:	cmp     	r0, #0
0x00057a:	ble     	#0x658
0x00057c:	movs    	r1, #0
0x00057e:	str     	r1, [sp]
0x000580:	str     	r1, [sp, #4]
0x000582:	movs    	r2, #0
0x000584:	str     	r2, [sp, #8]
0x000586:	movs    	r1, #0x46
0x000588:	adds    	r3, r7, #0
0x00058a:	movs    	r0, #0xf1
0x00058c:	lsls    	r0, r0, #9
0x00058e:	ldr     	r2, [r5, #8]
0x000590:	bl      	#0x7214
0x000594:	movs    	r1, #0
0x000596:	str     	r1, [sp]
0x000598:	str     	r1, [sp, #4]
0x00059a:	str     	r0, [sp, #0x1c]
0x00059c:	movs    	r2, #0
0x00059e:	str     	r2, [sp, #8]
0x0005a0:	movs    	r0, #0xf1
0x0005a2:	movs    	r1, #0x47
0x0005a4:	adds    	r3, r7, #0
0x0005a6:	lsls    	r0, r0, #9
0x0005a8:	ldr     	r2, [r5, #8]
0x0005aa:	bl      	#0x7214
0x0005ae:	movs    	r1, #0
0x0005b0:	str     	r1, [sp]
0x0005b2:	str     	r1, [sp, #4]
0x0005b4:	str     	r0, [sp, #0x18]
0x0005b6:	movs    	r2, #0
0x0005b8:	str     	r2, [sp, #8]
0x0005ba:	movs    	r0, #0xf1
0x0005bc:	movs    	r1, #0x46
0x0005be:	adds    	r3, r7, #0
0x0005c0:	lsls    	r0, r0, #9
0x0005c2:	ldr     	r2, [r5, #8]
0x0005c4:	bl      	#0x7214
0x0005c8:	movs    	r1, #0
0x0005ca:	str     	r1, [sp]
0x0005cc:	str     	r1, [sp, #4]
0x0005ce:	str     	r0, [sp, #0x14]
0x0005d0:	movs    	r2, #0
0x0005d2:	str     	r2, [sp, #8]
0x0005d4:	movs    	r0, #0xf1
0x0005d6:	movs    	r1, #0x47
0x0005d8:	adds    	r3, r7, #0
0x0005da:	lsls    	r0, r0, #9
0x0005dc:	ldr     	r2, [r5, #8]
0x0005de:	bl      	#0x7214
0x0005e2:	movs    	r1, #0
0x0005e4:	str     	r1, [sp]
0x0005e6:	str     	r1, [sp, #4]
0x0005e8:	str     	r0, [sp, #0x10]
0x0005ea:	movs    	r2, #0
0x0005ec:	str     	r2, [sp, #8]
0x0005ee:	movs    	r0, #0xf1
0x0005f0:	movs    	r1, #0x46
0x0005f2:	adds    	r3, r7, #0
0x0005f4:	lsls    	r0, r0, #9
0x0005f6:	ldr     	r2, [r5, #8]
0x0005f8:	bl      	#0x7214
0x0005fc:	lsls    	r0, r0, #0x18
0x0005fe:	movs    	r1, #0
0x000600:	asrs    	r0, r0, #0x18
0x000602:	movs    	r2, #0
0x000604:	str     	r2, [sp, #8]
0x000606:	str     	r0, [sp, #0xc]
0x000608:	str     	r1, [sp]
0x00060a:	str     	r1, [sp, #4]
0x00060c:	movs    	r1, #0xf
0x00060e:	movs    	r0, #0xf1
0x000610:	movs    	r2, #0x18
0x000612:	adds    	r3, r7, #0
0x000614:	lsls    	r0, r0, #9
0x000616:	bl      	#0x7214
0x00061a:	movs    	r1, #0
0x00061c:	str     	r1, [sp]
0x00061e:	str     	r1, [sp, #4]
0x000620:	adds    	r4, r0, #0
0x000622:	movs    	r2, #0
0x000624:	str     	r2, [sp, #8]
0x000626:	movs    	r0, #0xf1
0x000628:	adds    	r3, r7, #0
0x00062a:	movs    	r1, #0x46
0x00062c:	lsls    	r0, r0, #9
0x00062e:	ldr     	r2, [r5, #8]
0x000630:	bl      	#0x7214
0x000634:	lsls    	r0, r0, #0x18
0x000636:	asrs    	r0, r0, #0x18
0x000638:	adds    	r3, r0, #1
0x00063a:	beq     	#0x65a
0x00063c:	movs    	r1, #0
0x00063e:	str     	r1, [sp]
0x000640:	str     	r1, [sp, #4]
0x000642:	movs    	r2, #0
0x000644:	str     	r2, [sp, #8]
0x000646:	movs    	r1, #0x45

; ===== candidate_0006a8 =====
0x0006a8:	push    	{r4, r5, r6, r7, lr}
0x0006aa:	sub     	sp, #0xc
0x0006ac:	movs    	r6, #0
0x0006ae:	movs    	r2, #0
0x0006b0:	movs    	r1, #0
0x0006b2:	str     	r2, [sp, #8]
0x0006b4:	adds    	r3, r6, #0
0x0006b6:	adds    	r5, r0, #0
0x0006b8:	adds    	r2, r0, #0
0x0006ba:	str     	r1, [sp]
0x0006bc:	str     	r1, [sp, #4]
0x0006be:	movs    	r1, #0x44
0x0006c0:	movs    	r0, #0xf1
0x0006c2:	movs    	r4, #0
0x0006c4:	lsls    	r0, r0, #9
0x0006c6:	bl      	#0x7214
0x0006ca:	bl      	#0x7a84
0x0006ce:	ldr     	r7, [pc, #0x9c]
0x0006d0:	movs    	r1, #0
0x0006d2:	add     	r7, sb
0x0006d4:	str     	r6, [r7, #0x64]
0x0006d6:	str     	r1, [sp]
0x0006d8:	str     	r1, [sp, #4]
0x0006da:	movs    	r2, #0
0x0006dc:	str     	r2, [sp, #8]
0x0006de:	movs    	r1, #0x45
0x0006e0:	adds    	r3, r6, #0
0x0006e2:	movs    	r0, #0xf1
0x0006e4:	lsls    	r0, r0, #9
0x0006e6:	ldr     	r2, [r5, #8]
0x0006e8:	bl      	#0x7214
0x0006ec:	str     	r0, [r7, #0x78]
0x0006ee:	movs    	r1, #0
0x0006f0:	str     	r1, [sp]
0x0006f2:	str     	r1, [sp, #4]
0x0006f4:	movs    	r2, #0
0x0006f6:	str     	r2, [sp, #8]
0x0006f8:	movs    	r1, #0x45
0x0006fa:	movs    	r0, #0xf1
0x0006fc:	adds    	r3, r6, #0
0x0006fe:	lsls    	r0, r0, #9
0x000700:	ldr     	r2, [r5, #8]
0x000702:	bl      	#0x7214
0x000706:	str     	r0, [r7, #0x74]
0x000708:	movs    	r1, #0
0x00070a:	str     	r1, [sp]
0x00070c:	str     	r1, [sp, #4]
0x00070e:	movs    	r2, #0
0x000710:	str     	r2, [sp, #8]
0x000712:	movs    	r1, #0x45
0x000714:	movs    	r0, #0xf1
0x000716:	adds    	r3, r6, #0
0x000718:	lsls    	r0, r0, #9
0x00071a:	ldr     	r2, [r5, #8]
0x00071c:	bl      	#0x7214
0x000720:	movs    	r2, #0
0x000722:	movs    	r1, #0
0x000724:	str     	r2, [sp, #8]
0x000726:	adds    	r6, r0, #0
0x000728:	adds    	r2, r0, #0
0x00072a:	str     	r1, [sp]
0x00072c:	str     	r1, [sp, #4]
0x00072e:	movs    	r1, #0xa
0x000730:	movs    	r0, #0xf1
0x000732:	movs    	r3, #4
0x000734:	lsls    	r0, r0, #9
0x000736:	bl      	#0x7214
0x00073a:	str     	r0, [r7, #0x28]
0x00073c:	cmp     	r6, #0
0x00073e:	ble     	#0x752
0x000740:	adds    	r0, r5, #0
0x000742:	bl      	#0x768c
0x000746:	lsls    	r1, r4, #2
0x000748:	ldr     	r2, [r7, #0x28]
0x00074a:	adds    	r4, #1
0x00074c:	cmp     	r4, r6
0x00074e:	str     	r0, [r2, r1]
0x000750:	blt     	#0x740
0x000752:	movs    	r1, #0
0x000754:	str     	r1, [sp]
0x000756:	str     	r1, [sp, #4]
0x000758:	movs    	r2, #0
0x00075a:	movs    	r1, #0x2c
0x00075c:	movs    	r3, #0
0x00075e:	movs    	r0, #0xf1
0x000760:	lsls    	r0, r0, #9
0x000762:	str     	r2, [sp, #8]
0x000764:	bl      	#0x7214
0x000768:	add     	sp, #0xc
0x00076a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000770 =====
0x000770:	push    	{r4, r5, r6, lr}
0x000772:	sub     	sp, #0x10
0x000774:	movs    	r5, #0
0x000776:	movs    	r2, #0
0x000778:	movs    	r1, #0
0x00077a:	str     	r2, [sp, #8]
0x00077c:	adds    	r3, r5, #0
0x00077e:	adds    	r4, r0, #0
0x000780:	adds    	r2, r0, #0
0x000782:	str     	r1, [sp]
0x000784:	str     	r1, [sp, #4]
0x000786:	movs    	r1, #0x44
0x000788:	movs    	r0, #0xf1
0x00078a:	lsls    	r0, r0, #9
0x00078c:	bl      	#0x7214
0x000790:	adds    	r0, r4, #0
0x000792:	bl      	#0x7798
0x000796:	ldr     	r6, [pc, #0x144]
0x000798:	movs    	r1, #0
0x00079a:	add     	r6, sb
0x00079c:	str     	r0, [r6, #0x18]
0x00079e:	str     	r1, [sp]
0x0007a0:	str     	r1, [sp, #4]
0x0007a2:	movs    	r2, #0
0x0007a4:	str     	r2, [sp, #8]
0x0007a6:	movs    	r1, #0xe2
0x0007a8:	movs    	r0, #0xf1
0x0007aa:	adds    	r3, r5, #0
0x0007ac:	lsls    	r0, r0, #9
0x0007ae:	ldr     	r2, [r4, #8]
0x0007b0:	bl      	#0x7214
0x0007b4:	strh    	r0, [r6]
0x0007b6:	movs    	r1, #0
0x0007b8:	str     	r1, [sp]
0x0007ba:	str     	r1, [sp, #4]
0x0007bc:	movs    	r2, #0
0x0007be:	str     	r2, [sp, #8]
0x0007c0:	movs    	r1, #0xe2
0x0007c2:	movs    	r0, #0xf1
0x0007c4:	adds    	r3, r5, #0
0x0007c6:	lsls    	r0, r0, #9
0x0007c8:	ldr     	r2, [r4, #8]
0x0007ca:	bl      	#0x7214
0x0007ce:	strh    	r0, [r6, #2]
0x0007d0:	movs    	r1, #0
0x0007d2:	str     	r1, [sp]
0x0007d4:	str     	r1, [sp, #4]
0x0007d6:	movs    	r2, #0
0x0007d8:	str     	r2, [sp, #8]
0x0007da:	movs    	r1, #0xe2
0x0007dc:	movs    	r0, #0xf1
0x0007de:	adds    	r3, r5, #0
0x0007e0:	lsls    	r0, r0, #9
0x0007e2:	ldr     	r2, [r4, #8]
0x0007e4:	bl      	#0x7214
0x0007e8:	strh    	r0, [r6, #4]
0x0007ea:	movs    	r1, #0
0x0007ec:	str     	r1, [sp]
0x0007ee:	str     	r1, [sp, #4]
0x0007f0:	movs    	r2, #0
0x0007f2:	str     	r2, [sp, #8]
0x0007f4:	movs    	r1, #0xe2
0x0007f6:	movs    	r0, #0xf1
0x0007f8:	adds    	r3, r5, #0
0x0007fa:	lsls    	r0, r0, #9
0x0007fc:	ldr     	r2, [r4, #8]
0x0007fe:	bl      	#0x7214
0x000802:	strh    	r0, [r6, #6]
0x000804:	movs    	r1, #0
0x000806:	str     	r1, [sp]
0x000808:	str     	r1, [sp, #4]
0x00080a:	movs    	r2, #0
0x00080c:	str     	r2, [sp, #8]
0x00080e:	movs    	r1, #0xe2
0x000810:	movs    	r0, #0xf1
0x000812:	adds    	r3, r5, #0
0x000814:	lsls    	r0, r0, #9
0x000816:	ldr     	r2, [r4, #8]
0x000818:	bl      	#0x7214
0x00081c:	strh    	r0, [r6, #8]
0x00081e:	movs    	r1, #0
0x000820:	str     	r1, [sp]
0x000822:	str     	r1, [sp, #4]
0x000824:	movs    	r2, #0
0x000826:	str     	r2, [sp, #8]
0x000828:	movs    	r1, #0xe2
0x00082a:	movs    	r0, #0xf1
0x00082c:	adds    	r3, r5, #0
0x00082e:	lsls    	r0, r0, #9
0x000830:	ldr     	r2, [r4, #8]
0x000832:	bl      	#0x7214
0x000836:	strh    	r0, [r6, #0xa]
0x000838:	movs    	r1, #0
0x00083a:	str     	r1, [sp]
0x00083c:	str     	r1, [sp, #4]
0x00083e:	movs    	r2, #0
0x000840:	str     	r2, [sp, #8]
0x000842:	movs    	r1, #0xe2
0x000844:	movs    	r0, #0xf1
0x000846:	adds    	r3, r5, #0
0x000848:	lsls    	r0, r0, #9
0x00084a:	ldr     	r2, [r4, #8]
0x00084c:	bl      	#0x7214
0x000850:	strh    	r0, [r6, #0x14]
0x000852:	movs    	r1, #0
0x000854:	str     	r1, [sp]
0x000856:	str     	r1, [sp, #4]
0x000858:	movs    	r2, #0
0x00085a:	str     	r2, [sp, #8]
0x00085c:	movs    	r1, #0xe2
0x00085e:	movs    	r0, #0xf1
0x000860:	adds    	r3, r5, #0
0x000862:	lsls    	r0, r0, #9
0x000864:	ldr     	r2, [r4, #8]
0x000866:	bl      	#0x7214
0x00086a:	strh    	r0, [r6, #0x16]
0x00086c:	movs    	r1, #0
0x00086e:	str     	r1, [sp]
0x000870:	str     	r1, [sp, #4]
0x000872:	movs    	r2, #0
0x000874:	str     	r2, [sp, #8]
0x000876:	movs    	r1, #0xe2
0x000878:	movs    	r0, #0xf1
0x00087a:	adds    	r3, r5, #0
0x00087c:	lsls    	r0, r0, #9
0x00087e:	ldr     	r2, [r4, #8]
0x000880:	bl      	#0x7214
0x000884:	strh    	r0, [r6, #0x10]
0x000886:	movs    	r1, #0
0x000888:	str     	r1, [sp]
0x00088a:	str     	r1, [sp, #4]
0x00088c:	movs    	r2, #0
0x00088e:	str     	r2, [sp, #8]
0x000890:	movs    	r1, #0xe2
0x000892:	movs    	r0, #0xf1
0x000894:	adds    	r3, r5, #0
0x000896:	lsls    	r0, r0, #9
0x000898:	ldr     	r2, [r4, #8]
0x00089a:	bl      	#0x7214
0x00089e:	strh    	r0, [r6, #0x12]
0x0008a0:	movs    	r1, #0

; ===== candidate_0008e0 =====
0x0008e0:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x0008e2:	sub     	sp, #0x14
0x0008e4:	movs    	r1, #0
0x0008e6:	movs    	r6, #0
0x0008e8:	movs    	r2, #0
0x0008ea:	str     	r2, [sp, #8]
0x0008ec:	adds    	r3, r6, #0
0x0008ee:	adds    	r5, r0, #0
0x0008f0:	adds    	r2, r0, #0
0x0008f2:	str     	r1, [sp]
0x0008f4:	str     	r1, [sp, #4]
0x0008f6:	movs    	r1, #0x44
0x0008f8:	movs    	r0, #0xf1
0x0008fa:	movs    	r4, #0
0x0008fc:	lsls    	r0, r0, #9
0x0008fe:	bl      	#0x7214
0x000902:	movs    	r1, #0
0x000904:	str     	r1, [sp]
0x000906:	str     	r1, [sp, #4]
0x000908:	movs    	r2, #0
0x00090a:	str     	r2, [sp, #8]
0x00090c:	movs    	r1, #0x45
0x00090e:	adds    	r3, r6, #0
0x000910:	movs    	r0, #0xf1
0x000912:	lsls    	r0, r0, #9
0x000914:	ldr     	r2, [r5, #8]
0x000916:	bl      	#0x7214
0x00091a:	movs    	r1, #0
0x00091c:	str     	r1, [sp]
0x00091e:	str     	r1, [sp, #4]
0x000920:	str     	r0, [sp, #0x10]
0x000922:	movs    	r2, #0
0x000924:	str     	r2, [sp, #8]
0x000926:	movs    	r0, #0xf1
0x000928:	movs    	r1, #0x45
0x00092a:	adds    	r3, r6, #0
0x00092c:	lsls    	r0, r0, #9
0x00092e:	ldr     	r2, [r5, #8]
0x000930:	bl      	#0x7214
0x000934:	movs    	r1, #0
0x000936:	str     	r1, [sp]
0x000938:	str     	r1, [sp, #4]
0x00093a:	adds    	r7, r0, #0
0x00093c:	movs    	r2, #0
0x00093e:	str     	r2, [sp, #8]
0x000940:	movs    	r0, #0xf1
0x000942:	adds    	r3, r6, #0
0x000944:	movs    	r1, #0x45
0x000946:	lsls    	r0, r0, #9
0x000948:	ldr     	r2, [r5, #8]
0x00094a:	bl      	#0x7214
0x00094e:	adds    	r6, r0, #0
0x000950:	adds    	r0, r7, #0
0x000952:	ldr     	r7, [pc, #0x70]
0x000954:	add     	r7, sb
0x000956:	str     	r0, [r7, #0x48]
0x000958:	ldr     	r0, [sp, #0x10]
0x00095a:	str     	r0, [r7, #0x4c]
0x00095c:	bl      	#0x7c90
0x000960:	movs    	r1, #0
0x000962:	movs    	r2, #0
0x000964:	str     	r2, [sp, #8]
0x000966:	str     	r1, [sp]
0x000968:	str     	r1, [sp, #4]
0x00096a:	movs    	r1, #0xa
0x00096c:	adds    	r2, r6, #0
0x00096e:	movs    	r3, #4
0x000970:	movs    	r0, #0xf1
0x000972:	lsls    	r0, r0, #9
0x000974:	bl      	#0x7214
0x000978:	str     	r0, [r7, #0x54]
0x00097a:	cmp     	r6, #0
0x00097c:	ble     	#0x990
0x00097e:	adds    	r0, r5, #0
0x000980:	bl      	#0x7950
0x000984:	lsls    	r1, r4, #2
0x000986:	ldr     	r2, [r7, #0x54]
0x000988:	adds    	r4, #1
0x00098a:	cmp     	r4, r6
0x00098c:	str     	r0, [r2, r1]
0x00098e:	blt     	#0x97e
0x000990:	movs    	r1, #0
0x000992:	str     	r1, [sp]
0x000994:	str     	r1, [sp, #4]
0x000996:	movs    	r2, #0
0x000998:	movs    	r1, #0x2c
0x00099a:	movs    	r3, #0
0x00099c:	movs    	r0, #0xf1
0x00099e:	lsls    	r0, r0, #9
0x0009a0:	str     	r2, [sp, #8]
0x0009a2:	bl      	#0x7214
0x0009a6:	ldr     	r0, [sp, #0x18]
0x0009a8:	subs    	r0, #0xff
0x0009aa:	subs    	r0, #0x31
0x0009ac:	bne     	#0x9ba
0x0009ae:	movs    	r0, #0xff
0x0009b0:	adds    	r0, #0x24
0x0009b2:	bl      	#0x5da0
0x0009b6:	add     	sp, #0x1c
0x0009b8:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0009c8 =====
0x0009c8:	push    	{r4, r5, r6, r7, lr}
0x0009ca:	sub     	sp, #0xc
0x0009cc:	movs    	r6, #0
0x0009ce:	movs    	r2, #0
0x0009d0:	movs    	r1, #0
0x0009d2:	str     	r2, [sp, #8]
0x0009d4:	adds    	r3, r6, #0
0x0009d6:	adds    	r5, r0, #0
0x0009d8:	adds    	r2, r0, #0
0x0009da:	str     	r1, [sp]
0x0009dc:	str     	r1, [sp, #4]
0x0009de:	movs    	r1, #0x44
0x0009e0:	movs    	r0, #0xf1
0x0009e2:	movs    	r4, #0
0x0009e4:	lsls    	r0, r0, #9
0x0009e6:	bl      	#0x7214
0x0009ea:	bl      	#0x7a84
0x0009ee:	ldr     	r7, [pc, #0xa0]
0x0009f0:	movs    	r1, #0
0x0009f2:	add     	r7, sb
0x0009f4:	str     	r6, [r7, #0x64]
0x0009f6:	str     	r1, [sp]
0x0009f8:	str     	r1, [sp, #4]
0x0009fa:	movs    	r2, #0
0x0009fc:	str     	r2, [sp, #8]
0x0009fe:	movs    	r1, #0x45
0x000a00:	adds    	r3, r6, #0
0x000a02:	movs    	r0, #0xf1
0x000a04:	lsls    	r0, r0, #9
0x000a06:	ldr     	r2, [r5, #8]
0x000a08:	bl      	#0x7214
0x000a0c:	str     	r0, [r7, #0x78]
0x000a0e:	movs    	r1, #0
0x000a10:	str     	r1, [sp]
0x000a12:	str     	r1, [sp, #4]
0x000a14:	movs    	r2, #0
0x000a16:	str     	r2, [sp, #8]
0x000a18:	movs    	r1, #0x45
0x000a1a:	movs    	r0, #0xf1
0x000a1c:	adds    	r3, r6, #0
0x000a1e:	lsls    	r0, r0, #9
0x000a20:	ldr     	r2, [r5, #8]
0x000a22:	bl      	#0x7214
0x000a26:	str     	r0, [r7, #0x74]
0x000a28:	movs    	r1, #0
0x000a2a:	str     	r1, [sp]
0x000a2c:	str     	r1, [sp, #4]
0x000a2e:	movs    	r2, #0
0x000a30:	str     	r2, [sp, #8]
0x000a32:	movs    	r1, #0x45
0x000a34:	movs    	r0, #0xf1
0x000a36:	adds    	r3, r6, #0
0x000a38:	lsls    	r0, r0, #9
0x000a3a:	ldr     	r2, [r5, #8]
0x000a3c:	bl      	#0x7214
0x000a40:	movs    	r2, #0
0x000a42:	movs    	r1, #0
0x000a44:	str     	r2, [sp, #8]
0x000a46:	adds    	r6, r0, #0
0x000a48:	adds    	r2, r0, #0
0x000a4a:	str     	r1, [sp]
0x000a4c:	str     	r1, [sp, #4]
0x000a4e:	movs    	r1, #0xa
0x000a50:	movs    	r0, #0xf1
0x000a52:	movs    	r3, #4
0x000a54:	lsls    	r0, r0, #9
0x000a56:	bl      	#0x7214
0x000a5a:	str     	r0, [r7, #0x28]
0x000a5c:	cmp     	r6, #0
0x000a5e:	ble     	#0xa72
0x000a60:	adds    	r0, r5, #0
0x000a62:	bl      	#0x768c
0x000a66:	lsls    	r1, r4, #2
0x000a68:	ldr     	r2, [r7, #0x28]
0x000a6a:	adds    	r4, #1
0x000a6c:	cmp     	r4, r6
0x000a6e:	str     	r0, [r2, r1]
0x000a70:	blt     	#0xa60
0x000a72:	movs    	r1, #0
0x000a74:	str     	r1, [sp]
0x000a76:	str     	r1, [sp, #4]
0x000a78:	movs    	r2, #0
0x000a7a:	movs    	r1, #0x2c
0x000a7c:	movs    	r3, #0
0x000a7e:	movs    	r0, #0xf1
0x000a80:	lsls    	r0, r0, #9
0x000a82:	str     	r2, [sp, #8]
0x000a84:	bl      	#0x7214
0x000a88:	bl      	#0x5d48
0x000a8c:	add     	sp, #0xc
0x000a8e:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000a94 =====
0x000a94:	push    	{r4, r5, r6, r7, lr}
0x000a96:	ldr     	r1, [pc, #0x3e4]
0x000a98:	sub     	sp, #0x14
0x000a9a:	adds    	r4, r0, #0
0x000a9c:	add     	r1, pc
0x000a9e:	ldr     	r7, [pc, #0x3e0]
0x000aa0:	add     	r7, sb
0x000aa2:	ldr     	r2, [r7]
0x000aa4:	blx     	r2
0x000aa6:	movs    	r6, #0xf1
0x000aa8:	lsls    	r6, r6, #9
0x000aaa:	movs    	r5, #0
0x000aac:	cmp     	r0, #0
0x000aae:	bne     	#0xafc
0x000ab0:	movs    	r1, #0
0x000ab2:	movs    	r2, #0
0x000ab4:	str     	r2, [sp, #8]
0x000ab6:	str     	r1, [sp]
0x000ab8:	str     	r1, [sp, #4]
0x000aba:	movs    	r1, #0x9c
0x000abc:	movs    	r2, #0x12
0x000abe:	adds    	r3, r5, #0
0x000ac0:	adds    	r0, r6, #0
0x000ac2:	bl      	#0x7214
0x000ac6:	movs    	r1, #0
0x000ac8:	str     	r1, [sp, #4]
0x000aca:	movs    	r2, #0
0x000acc:	movs    	r0, #0x11
0x000ace:	str     	r0, [sp]
0x000ad0:	movs    	r1, #0x53
0x000ad2:	movs    	r3, #0x32
0x000ad4:	adds    	r0, r6, #0
0x000ad6:	str     	r2, [sp, #8]
0x000ad8:	bl      	#0x7214
0x000adc:	movs    	r1, #0
0x000ade:	ldr     	r7, [pc, #0x3a4]
0x000ae0:	str     	r1, [sp]
0x000ae2:	str     	r1, [sp, #4]
0x000ae4:	movs    	r2, #0
0x000ae6:	str     	r2, [sp, #8]
0x000ae8:	add     	r7, sb
0x000aea:	ldr     	r0, [r7, #0x18]
0x000aec:	movs    	r1, #0xff
0x000aee:	adds    	r1, #0x1f
0x000af0:	adds    	r3, r5, #0
0x000af2:	ldr     	r2, [r0, #0xc]
0x000af4:	adds    	r0, r6, #0
0x000af6:	bl      	#0x7214
0x000afa:	b       	#0xf76
0x000afc:	ldr     	r1, [pc, #0x388]
0x000afe:	add     	r1, pc
0x000b00:	ldr     	r7, [pc, #0x37c]
0x000b02:	adds    	r0, r4, #0
0x000b04:	add     	r7, sb
0x000b06:	ldr     	r2, [r7]
0x000b08:	blx     	r2
0x000b0a:	cmp     	r0, #0
0x000b0c:	bne     	#0xb2c
0x000b0e:	movs    	r1, #0
0x000b10:	movs    	r2, #0
0x000b12:	str     	r2, [sp, #8]
0x000b14:	str     	r1, [sp]
0x000b16:	str     	r1, [sp, #4]
0x000b18:	movs    	r1, #0x9c
0x000b1a:	movs    	r2, #0x12
0x000b1c:	adds    	r3, r5, #0
0x000b1e:	adds    	r0, r6, #0
0x000b20:	bl      	#0x7214
0x000b24:	movs    	r0, #0
0x000b26:	bl      	#0x5b28
0x000b2a:	b       	#0xf76
0x000b2c:	ldr     	r1, [pc, #0x35c]
0x000b2e:	add     	r1, pc
0x000b30:	ldr     	r2, [r7]
0x000b32:	adds    	r0, r4, #0
0x000b34:	blx     	r2
0x000b36:	cmp     	r0, #0
0x000b38:	bne     	#0xb58
0x000b3a:	movs    	r1, #0
0x000b3c:	movs    	r2, #0
0x000b3e:	str     	r2, [sp, #8]
0x000b40:	str     	r1, [sp]
0x000b42:	str     	r1, [sp, #4]
0x000b44:	movs    	r1, #0x9c
0x000b46:	movs    	r2, #0x12
0x000b48:	adds    	r3, r5, #0
0x000b4a:	adds    	r0, r6, #0
0x000b4c:	bl      	#0x7214
0x000b50:	movs    	r0, #1
0x000b52:	bl      	#0x5b28
0x000b56:	b       	#0xf76
0x000b58:	ldr     	r1, [pc, #0x334]
0x000b5a:	add     	r1, pc
0x000b5c:	ldr     	r2, [r7]
0x000b5e:	adds    	r0, r4, #0
0x000b60:	blx     	r2
0x000b62:	cmp     	r0, #0
0x000b64:	bne     	#0xbb2
0x000b66:	movs    	r1, #0
0x000b68:	movs    	r2, #0
0x000b6a:	str     	r2, [sp, #8]
0x000b6c:	str     	r1, [sp]
0x000b6e:	str     	r1, [sp, #4]
0x000b70:	movs    	r1, #0x9c
0x000b72:	movs    	r2, #0x12
0x000b74:	adds    	r3, r5, #0
0x000b76:	adds    	r0, r6, #0
0x000b78:	bl      	#0x7214
0x000b7c:	movs    	r1, #0
0x000b7e:	str     	r1, [sp]
0x000b80:	str     	r1, [sp, #4]
0x000b82:	movs    	r2, #0
0x000b84:	movs    	r1, #0x34
0x000b86:	adds    	r3, r5, #0
0x000b88:	movs    	r0, #0xf1
0x000b8a:	lsls    	r0, r0, #9
0x000b8c:	str     	r2, [sp, #8]
0x000b8e:	bl      	#0x7214
0x000b92:	movs    	r2, #0
0x000b94:	movs    	r1, #0
0x000b96:	str     	r2, [sp, #8]
0x000b98:	str     	r1, [sp]
0x000b9a:	str     	r1, [sp, #4]
0x000b9c:	ldr     	r7, [pc, #0x2e4]
0x000b9e:	movs    	r2, #0xff
0x000ba0:	adds    	r2, #0x46
0x000ba2:	movs    	r1, #0x50
0x000ba4:	movs    	r0, #0xf1
0x000ba6:	add     	r7, sb
0x000ba8:	ldr     	r3, [r7, #0x1c]
0x000baa:	lsls    	r0, r0, #9
0x000bac:	bl      	#0x7214
0x000bb0:	b       	#0xf76
0x000bb2:	ldr     	r1, [pc, #0x2e0]
0x000bb4:	add     	r1, pc
0x000bb6:	ldr     	r2, [r7]
0x000bb8:	adds    	r0, r4, #0
0x000bba:	blx     	r2
0x000bbc:	cmp     	r0, #0
0x000bbe:	bne     	#0xbdc
0x000bc0:	movs    	r1, #0

; ===== candidate_0014d8 =====
0x0014d8:	push    	{r4, r5, lr}
0x0014da:	sub     	sp, #0xc
0x0014dc:	movs    	r4, #0
0x0014de:	movs    	r2, #0
0x0014e0:	movs    	r1, #0
0x0014e2:	str     	r2, [sp, #8]
0x0014e4:	adds    	r3, r4, #0
0x0014e6:	adds    	r2, r0, #0
0x0014e8:	str     	r1, [sp]
0x0014ea:	str     	r1, [sp, #4]
0x0014ec:	movs    	r1, #0x44
0x0014ee:	movs    	r0, #0xf1
0x0014f0:	lsls    	r0, r0, #9
0x0014f2:	bl      	#0x7214
0x0014f6:	movs    	r1, #0
0x0014f8:	str     	r1, [sp]
0x0014fa:	str     	r1, [sp, #4]
0x0014fc:	movs    	r2, #0
0x0014fe:	movs    	r1, #0x2c
0x001500:	adds    	r3, r4, #0
0x001502:	movs    	r0, #0xf1
0x001504:	lsls    	r0, r0, #9
0x001506:	str     	r2, [sp, #8]
0x001508:	bl      	#0x7214
0x00150c:	movs    	r1, #0
0x00150e:	str     	r1, [sp]
0x001510:	str     	r1, [sp, #4]
0x001512:	movs    	r2, #0
0x001514:	movs    	r1, #0x34
0x001516:	adds    	r3, r4, #0
0x001518:	movs    	r0, #0xf1
0x00151a:	lsls    	r0, r0, #9
0x00151c:	str     	r2, [sp, #8]
0x00151e:	bl      	#0x7214
0x001522:	bl      	#0x501c
0x001526:	adds    	r3, r0, #0
0x001528:	ldr     	r0, [pc, #0x14]
0x00152a:	mvns    	r2, r4
0x00152c:	add     	r0, sb
0x00152e:	ldr     	r0, [r0, #0x18]
0x001530:	ldr     	r0, [r0]
0x001532:	ldr     	r1, [r0]
0x001534:	movs    	r0, #0xff
0x001536:	adds    	r0, #0x39
0x001538:	bl      	#0x7e7c
0x00153c:	add     	sp, #0xc
0x00153e:	pop     	{r4, r5, pc}

; ===== candidate_001544 =====
0x001544:	push    	{r4, r5, r6, r7, lr}
0x001546:	sub     	sp, #0x14
0x001548:	movs    	r1, #0
0x00154a:	movs    	r2, #0
0x00154c:	str     	r2, [sp, #8]
0x00154e:	str     	r1, [sp]
0x001550:	str     	r1, [sp, #4]
0x001552:	movs    	r6, #0xf1
0x001554:	movs    	r5, #0
0x001556:	adds    	r3, r5, #0
0x001558:	lsls    	r6, r6, #9
0x00155a:	movs    	r1, #0x44
0x00155c:	adds    	r2, r0, #0
0x00155e:	adds    	r4, r0, #0
0x001560:	adds    	r0, r6, #0
0x001562:	bl      	#0x7214
0x001566:	movs    	r1, #0
0x001568:	str     	r1, [sp]
0x00156a:	str     	r1, [sp, #4]
0x00156c:	movs    	r2, #0
0x00156e:	str     	r2, [sp, #8]
0x001570:	movs    	r1, #0x45
0x001572:	adds    	r3, r5, #0
0x001574:	adds    	r0, r6, #0
0x001576:	ldr     	r2, [r4, #8]
0x001578:	bl      	#0x7214
0x00157c:	movs    	r1, #0
0x00157e:	str     	r1, [sp]
0x001580:	str     	r1, [sp, #4]
0x001582:	movs    	r2, #0
0x001584:	str     	r0, [sp, #0x10]
0x001586:	str     	r2, [sp, #8]
0x001588:	movs    	r1, #0x45
0x00158a:	adds    	r3, r5, #0
0x00158c:	adds    	r0, r6, #0
0x00158e:	ldr     	r2, [r4, #8]
0x001590:	bl      	#0x7214
0x001594:	movs    	r1, #0
0x001596:	str     	r1, [sp]
0x001598:	str     	r1, [sp, #4]
0x00159a:	movs    	r2, #0
0x00159c:	str     	r2, [sp, #8]
0x00159e:	movs    	r1, #0x45
0x0015a0:	adds    	r7, r0, #0
0x0015a2:	adds    	r3, r5, #0
0x0015a4:	adds    	r0, r6, #0
0x0015a6:	ldr     	r2, [r4, #8]
0x0015a8:	bl      	#0x7214
0x0015ac:	ldr     	r4, [pc, #0xa4]
0x0015ae:	ldr     	r2, [sp, #0x10]
0x0015b0:	add     	r4, sb
0x0015b2:	ldr     	r1, [r4, #0x18]
0x0015b4:	adds    	r3, r5, #0
0x0015b6:	strh    	r2, [r1, #0x10]
0x0015b8:	str     	r0, [r1, #4]
0x0015ba:	str     	r7, [r1, #8]
0x0015bc:	movs    	r1, #0
0x0015be:	str     	r1, [sp]
0x0015c0:	str     	r1, [sp, #4]
0x0015c2:	movs    	r2, #0
0x0015c4:	movs    	r1, #0x2c
0x0015c6:	adds    	r0, r6, #0
0x0015c8:	str     	r2, [sp, #8]
0x0015ca:	bl      	#0x7214
0x0015ce:	movs    	r1, #0
0x0015d0:	str     	r1, [sp]
0x0015d2:	str     	r1, [sp, #4]
0x0015d4:	movs    	r2, #0
0x0015d6:	movs    	r1, #0x34
0x0015d8:	adds    	r3, r5, #0
0x0015da:	adds    	r0, r6, #0
0x0015dc:	str     	r2, [sp, #8]
0x0015de:	bl      	#0x7214
0x0015e2:	ldr     	r7, [r4, #0x60]
0x0015e4:	cmp     	r7, #0
0x0015e6:	beq     	#0x1600
0x0015e8:	movs    	r1, #0
0x0015ea:	movs    	r2, #0
0x0015ec:	str     	r2, [sp, #8]
0x0015ee:	str     	r1, [sp]
0x0015f0:	str     	r1, [sp, #4]
0x0015f2:	movs    	r1, #0x12
0x0015f4:	adds    	r2, r7, #0
0x0015f6:	adds    	r3, r5, #0
0x0015f8:	adds    	r0, r6, #0
0x0015fa:	bl      	#0x7214
0x0015fe:	str     	r5, [r4, #0x60]
0x001600:	movs    	r1, #0
0x001602:	movs    	r2, #0
0x001604:	str     	r2, [sp, #8]
0x001606:	str     	r1, [sp]
0x001608:	str     	r1, [sp, #4]
0x00160a:	ldr     	r0, [r4, #0x18]
0x00160c:	movs    	r2, #0xff
0x00160e:	ldr     	r0, [r0]
0x001610:	adds    	r2, #0x43
0x001612:	movs    	r1, #0x50
0x001614:	ldr     	r3, [r0]
0x001616:	adds    	r0, r6, #0
0x001618:	bl      	#0x7214
0x00161c:	movs    	r2, #0
0x00161e:	movs    	r1, #0
0x001620:	str     	r2, [sp, #8]
0x001622:	ldr     	r2, [pc, #0x34]
0x001624:	str     	r1, [sp]
0x001626:	str     	r1, [sp, #4]
0x001628:	adds    	r3, r5, #0
0x00162a:	add     	r2, pc
0x00162c:	movs    	r1, #0x6f
0x00162e:	movs    	r0, #0xf1
0x001630:	lsls    	r0, r0, #9
0x001632:	bl      	#0x7214
0x001636:	movs    	r1, #0
0x001638:	movs    	r2, #0
0x00163a:	str     	r2, [sp, #8]
0x00163c:	str     	r1, [sp]
0x00163e:	str     	r1, [sp, #4]
0x001640:	movs    	r1, #0x14
0x001642:	movs    	r2, #0xeb
0x001644:	movs    	r3, #1
0x001646:	movs    	r0, #0xf1
0x001648:	lsls    	r0, r0, #9
0x00164a:	bl      	#0x7214
0x00164e:	add     	sp, #0x14
0x001650:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00165c =====
0x00165c:	push    	{r4, r5, r6, r7, lr}
0x00165e:	sub     	sp, #0x2c
0x001660:	movs    	r1, #0
0x001662:	movs    	r2, #0
0x001664:	str     	r2, [sp, #8]
0x001666:	str     	r1, [sp]
0x001668:	str     	r1, [sp, #4]
0x00166a:	movs    	r7, #0xf1
0x00166c:	movs    	r5, #0
0x00166e:	adds    	r3, r5, #0
0x001670:	lsls    	r7, r7, #9
0x001672:	movs    	r1, #0x44
0x001674:	adds    	r2, r0, #0
0x001676:	movs    	r6, #0
0x001678:	adds    	r4, r0, #0
0x00167a:	adds    	r0, r7, #0
0x00167c:	bl      	#0x7214
0x001680:	movs    	r1, #0
0x001682:	str     	r1, [sp]
0x001684:	str     	r1, [sp, #4]
0x001686:	movs    	r2, #0
0x001688:	str     	r2, [sp, #8]
0x00168a:	movs    	r1, #0x45
0x00168c:	adds    	r3, r5, #0
0x00168e:	adds    	r0, r7, #0
0x001690:	ldr     	r2, [r4, #8]
0x001692:	bl      	#0x7214
0x001696:	movs    	r1, #0
0x001698:	str     	r1, [sp]
0x00169a:	str     	r1, [sp, #4]
0x00169c:	str     	r0, [sp, #0x28]
0x00169e:	movs    	r2, #0
0x0016a0:	str     	r2, [sp, #8]
0x0016a2:	movs    	r1, #0x45
0x0016a4:	adds    	r3, r5, #0
0x0016a6:	adds    	r0, r7, #0
0x0016a8:	ldr     	r2, [r4, #8]
0x0016aa:	bl      	#0x7214
0x0016ae:	movs    	r1, #0
0x0016b0:	str     	r0, [sp, #0x24]
0x0016b2:	str     	r1, [sp, #4]
0x0016b4:	str     	r1, [sp]
0x0016b6:	movs    	r2, #0
0x0016b8:	str     	r2, [sp, #8]
0x0016ba:	movs    	r1, #0x45
0x0016bc:	adds    	r3, r5, #0
0x0016be:	adds    	r0, r7, #0
0x0016c0:	ldr     	r2, [r4, #8]
0x0016c2:	bl      	#0x7214
0x0016c6:	movs    	r1, #0
0x0016c8:	str     	r0, [sp, #0x20]
0x0016ca:	str     	r1, [sp]
0x0016cc:	str     	r1, [sp, #4]
0x0016ce:	movs    	r2, #0
0x0016d0:	str     	r2, [sp, #8]
0x0016d2:	movs    	r1, #0x45
0x0016d4:	adds    	r3, r5, #0
0x0016d6:	adds    	r0, r7, #0
0x0016d8:	ldr     	r2, [r4, #8]
0x0016da:	bl      	#0x7214
0x0016de:	movs    	r1, #0
0x0016e0:	str     	r1, [sp]
0x0016e2:	str     	r1, [sp, #4]
0x0016e4:	movs    	r2, #0
0x0016e6:	str     	r0, [sp, #0x18]
0x0016e8:	str     	r2, [sp, #8]
0x0016ea:	movs    	r1, #0x45
0x0016ec:	adds    	r3, r5, #0
0x0016ee:	adds    	r0, r7, #0
0x0016f0:	ldr     	r2, [r4, #8]
0x0016f2:	bl      	#0x7214
0x0016f6:	movs    	r1, #0
0x0016f8:	str     	r1, [sp]
0x0016fa:	str     	r1, [sp, #4]
0x0016fc:	movs    	r2, #0
0x0016fe:	str     	r0, [sp, #0x14]
0x001700:	str     	r2, [sp, #8]
0x001702:	movs    	r1, #0x45
0x001704:	adds    	r3, r5, #0
0x001706:	adds    	r0, r7, #0
0x001708:	ldr     	r2, [r4, #8]
0x00170a:	bl      	#0x7214
0x00170e:	movs    	r1, #0
0x001710:	str     	r1, [sp]
0x001712:	str     	r1, [sp, #4]
0x001714:	movs    	r2, #0
0x001716:	str     	r0, [sp, #0x10]
0x001718:	str     	r2, [sp, #8]
0x00171a:	movs    	r1, #0x45
0x00171c:	adds    	r3, r5, #0
0x00171e:	adds    	r0, r7, #0
0x001720:	ldr     	r2, [r4, #8]
0x001722:	bl      	#0x7214
0x001726:	str     	r0, [sp, #0x1c]
0x001728:	movs    	r1, #0
0x00172a:	str     	r1, [sp]
0x00172c:	str     	r1, [sp, #4]
0x00172e:	movs    	r2, #0
0x001730:	movs    	r7, #0xf1
0x001732:	lsls    	r7, r7, #9
0x001734:	str     	r2, [sp, #8]
0x001736:	movs    	r1, #0x45
0x001738:	movs    	r3, #0
0x00173a:	adds    	r0, r7, #0
0x00173c:	ldr     	r2, [r4, #8]
0x00173e:	bl      	#0x7214
0x001742:	adds    	r5, r0, #0
0x001744:	adds    	r3, r0, #1
0x001746:	beq     	#0x17b6
0x001748:	movs    	r1, #0
0x00174a:	str     	r1, [sp]
0x00174c:	str     	r1, [sp, #4]
0x00174e:	movs    	r2, #0
0x001750:	str     	r2, [sp, #8]
0x001752:	movs    	r1, #0x45
0x001754:	movs    	r3, #0
0x001756:	adds    	r0, r7, #0
0x001758:	ldr     	r2, [r4, #8]
0x00175a:	bl      	#0x7214
0x00175e:	movs    	r1, #0
0x001760:	adds    	r7, r0, #0
0x001762:	movs    	r2, #0
0x001764:	str     	r2, [sp, #8]
0x001766:	str     	r1, [sp]
0x001768:	str     	r1, [sp, #4]
0x00176a:	movs    	r1, #0x90
0x00176c:	adds    	r2, r5, #0
0x00176e:	movs    	r0, #0xf1
0x001770:	movs    	r3, #0
0x001772:	lsls    	r0, r0, #9
0x001774:	bl      	#0x7214
0x001778:	lsls    	r1, r7, #0x10
0x00177a:	asrs    	r1, r1, #0x10
0x00177c:	adds    	r5, r0, #0
0x00177e:	cmp     	r1, #0
0x001780:	strh    	r1, [r0, #8]
0x001782:	bgt     	#0x17b6
0x001784:	movs    	r1, #0
0x001786:	movs    	r2, #0
0x001788:	movs    	r7, #0
0x00178a:	adds    	r3, r7, #0

; ===== candidate_00188c =====
0x00188c:	push    	{r4, r5, lr}
0x00188e:	sub     	sp, #0xc
0x001890:	movs    	r4, #0
0x001892:	movs    	r2, #0
0x001894:	movs    	r1, #0
0x001896:	str     	r2, [sp, #8]
0x001898:	adds    	r3, r4, #0
0x00189a:	adds    	r2, r0, #0
0x00189c:	str     	r1, [sp]
0x00189e:	str     	r1, [sp, #4]
0x0018a0:	movs    	r1, #0x44
0x0018a2:	movs    	r0, #0xf1
0x0018a4:	lsls    	r0, r0, #9
0x0018a6:	bl      	#0x7214
0x0018aa:	movs    	r1, #0
0x0018ac:	str     	r1, [sp]
0x0018ae:	str     	r1, [sp, #4]
0x0018b0:	movs    	r2, #0
0x0018b2:	movs    	r1, #0x2c
0x0018b4:	adds    	r3, r4, #0
0x0018b6:	movs    	r0, #0xf1
0x0018b8:	lsls    	r0, r0, #9
0x0018ba:	str     	r2, [sp, #8]
0x0018bc:	bl      	#0x7214
0x0018c0:	movs    	r1, #0
0x0018c2:	str     	r1, [sp]
0x0018c4:	str     	r1, [sp, #4]
0x0018c6:	movs    	r2, #0
0x0018c8:	movs    	r1, #0x34
0x0018ca:	adds    	r3, r4, #0
0x0018cc:	movs    	r0, #0xf1
0x0018ce:	lsls    	r0, r0, #9
0x0018d0:	str     	r2, [sp, #8]
0x0018d2:	bl      	#0x7214
0x0018d6:	bl      	#0x501c
0x0018da:	adds    	r3, r0, #0
0x0018dc:	ldr     	r0, [pc, #0x14]
0x0018de:	mvns    	r2, r4
0x0018e0:	add     	r0, sb
0x0018e2:	ldr     	r0, [r0, #0x18]
0x0018e4:	ldr     	r0, [r0]
0x0018e6:	ldr     	r1, [r0]
0x0018e8:	movs    	r0, #0xff
0x0018ea:	adds    	r0, #0x3a
0x0018ec:	bl      	#0x7e7c
0x0018f0:	add     	sp, #0xc
0x0018f2:	pop     	{r4, r5, pc}

; ===== candidate_0018f8 =====
0x0018f8:	push    	{r4, r5, r6, r7, lr}
0x0018fa:	sub     	sp, #0xc
0x0018fc:	movs    	r1, #0
0x0018fe:	movs    	r2, #0
0x001900:	str     	r2, [sp, #8]
0x001902:	str     	r1, [sp]
0x001904:	str     	r1, [sp, #4]
0x001906:	movs    	r7, #0xf1
0x001908:	movs    	r6, #0
0x00190a:	adds    	r3, r6, #0
0x00190c:	lsls    	r7, r7, #9
0x00190e:	movs    	r1, #0x44
0x001910:	adds    	r2, r0, #0
0x001912:	adds    	r4, r0, #0
0x001914:	adds    	r0, r7, #0
0x001916:	bl      	#0x7214
0x00191a:	movs    	r1, #0
0x00191c:	str     	r1, [sp]
0x00191e:	str     	r1, [sp, #4]
0x001920:	movs    	r2, #0
0x001922:	str     	r2, [sp, #8]
0x001924:	movs    	r1, #0x47
0x001926:	adds    	r3, r6, #0
0x001928:	adds    	r0, r7, #0
0x00192a:	ldr     	r2, [r4, #8]
0x00192c:	bl      	#0x7214
0x001930:	movs    	r1, #0
0x001932:	str     	r1, [sp]
0x001934:	str     	r1, [sp, #4]
0x001936:	movs    	r2, #0
0x001938:	movs    	r1, #0x2c
0x00193a:	adds    	r4, r0, #0
0x00193c:	adds    	r3, r6, #0
0x00193e:	adds    	r0, r7, #0
0x001940:	str     	r2, [sp, #8]
0x001942:	bl      	#0x7214
0x001946:	ldr     	r5, [pc, #0x48]
0x001948:	add     	r5, sb
0x00194a:	ldr     	r0, [r5, #0x18]
0x00194c:	ldr     	r3, [r0, #0xc]
0x00194e:	cmp     	r3, #0
0x001950:	beq     	#0x198a
0x001952:	movs    	r2, #0
0x001954:	movs    	r1, #0
0x001956:	str     	r2, [sp, #8]
0x001958:	adds    	r2, r3, #0
0x00195a:	str     	r1, [sp]
0x00195c:	str     	r1, [sp, #4]
0x00195e:	movs    	r1, #9
0x001960:	adds    	r3, r6, #0
0x001962:	adds    	r0, r7, #0
0x001964:	bl      	#0x7214
0x001968:	ldr     	r0, [r5, #0x18]
0x00196a:	str     	r4, [r0, #0xc]
0x00196c:	ldr     	r4, [r5, #0x5c]
0x00196e:	cmp     	r4, #0
0x001970:	beq     	#0x198a
0x001972:	movs    	r1, #0
0x001974:	movs    	r2, #0
0x001976:	str     	r2, [sp, #8]
0x001978:	str     	r1, [sp]
0x00197a:	str     	r1, [sp, #4]
0x00197c:	movs    	r1, #0x12
0x00197e:	adds    	r2, r4, #0
0x001980:	adds    	r3, r6, #0
0x001982:	adds    	r0, r7, #0
0x001984:	bl      	#0x7214
0x001988:	str     	r6, [r5, #0x5c]
0x00198a:	add     	sp, #0xc
0x00198c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_001994 =====
0x001994:	push    	{r4, r5, lr}
0x001996:	sub     	sp, #0xc
0x001998:	movs    	r5, #0
0x00199a:	movs    	r2, #0
0x00199c:	movs    	r1, #0
0x00199e:	str     	r2, [sp, #8]
0x0019a0:	adds    	r3, r5, #0
0x0019a2:	adds    	r4, r0, #0
0x0019a4:	adds    	r2, r0, #0
0x0019a6:	str     	r1, [sp]
0x0019a8:	str     	r1, [sp, #4]
0x0019aa:	movs    	r1, #0x44
0x0019ac:	movs    	r0, #0xf1
0x0019ae:	lsls    	r0, r0, #9
0x0019b0:	bl      	#0x7214
0x0019b4:	movs    	r1, #0
0x0019b6:	str     	r1, [sp]
0x0019b8:	str     	r1, [sp, #4]
0x0019ba:	movs    	r2, #0
0x0019bc:	str     	r2, [sp, #8]
0x0019be:	movs    	r1, #0x45
0x0019c0:	adds    	r3, r5, #0
0x0019c2:	movs    	r0, #0xf1
0x0019c4:	lsls    	r0, r0, #9
0x0019c6:	ldr     	r2, [r4, #8]
0x0019c8:	bl      	#0x7214
0x0019cc:	ldr     	r2, [pc, #0x24]
0x0019ce:	adds    	r3, r5, #0
0x0019d0:	add     	r2, sb
0x0019d2:	ldr     	r1, [r2, #0x64]
0x0019d4:	ldr     	r2, [r2, #0x28]
0x0019d6:	lsls    	r1, r1, #2
0x0019d8:	ldr     	r1, [r2, r1]
0x0019da:	movs    	r2, #0
0x0019dc:	strb    	r0, [r1, #0xd]
0x0019de:	movs    	r1, #0
0x0019e0:	str     	r1, [sp]
0x0019e2:	str     	r1, [sp, #4]
0x0019e4:	movs    	r1, #0x2c
0x0019e6:	movs    	r0, #0xf1
0x0019e8:	lsls    	r0, r0, #9
0x0019ea:	str     	r2, [sp, #8]
0x0019ec:	bl      	#0x7214
0x0019f0:	add     	sp, #0xc
0x0019f2:	pop     	{r4, r5, pc}

; ===== candidate_0019f8 =====
0x0019f8:	push    	{r4, r5, r6, r7, lr}
0x0019fa:	ldr     	r6, [pc, #0x3e0]
0x0019fc:	sub     	sp, #0x14
0x0019fe:	add     	r6, pc
0x001a00:	movs    	r1, #0
0x001a02:	ldr     	r5, [pc, #0x3dc]
0x001a04:	str     	r1, [sp]
0x001a06:	str     	r1, [sp, #4]
0x001a08:	movs    	r2, #0
0x001a0a:	str     	r2, [sp, #8]
0x001a0c:	movs    	r3, #0
0x001a0e:	movs    	r0, #0xf1
0x001a10:	add     	r5, sb
0x001a12:	ldrsh   	r2, [r5, r3]
0x001a14:	lsls    	r0, r0, #9
0x001a16:	movs    	r1, #0x3f
0x001a18:	movs    	r4, #0
0x001a1a:	adds    	r3, r4, #0
0x001a1c:	bl      	#0x7214
0x001a20:	movs    	r1, #0
0x001a22:	adds    	r7, r0, #0
0x001a24:	movs    	r2, #0
0x001a26:	adds    	r3, r0, #0
0x001a28:	str     	r2, [sp, #8]
0x001a2a:	str     	r1, [sp]
0x001a2c:	str     	r1, [sp, #4]
0x001a2e:	movs    	r1, #0x2d
0x001a30:	adds    	r2, r6, #0
0x001a32:	movs    	r0, #0xf1
0x001a34:	lsls    	r0, r0, #9
0x001a36:	bl      	#0x7214
0x001a3a:	movs    	r2, #0
0x001a3c:	movs    	r1, #0
0x001a3e:	ldr     	r3, [pc, #0x3a4]
0x001a40:	str     	r1, [sp]
0x001a42:	str     	r1, [sp, #4]
0x001a44:	str     	r2, [sp, #8]
0x001a46:	add     	r3, pc
0x001a48:	adds    	r2, r0, #0
0x001a4a:	movs    	r0, #0xf1
0x001a4c:	movs    	r1, #0x2d
0x001a4e:	lsls    	r0, r0, #9
0x001a50:	bl      	#0x7214
0x001a54:	movs    	r1, #0
0x001a56:	adds    	r6, r0, #0
0x001a58:	movs    	r2, #0
0x001a5a:	str     	r2, [sp, #8]
0x001a5c:	str     	r1, [sp]
0x001a5e:	str     	r1, [sp, #4]
0x001a60:	adds    	r3, r4, #0
0x001a62:	adds    	r2, r7, #0
0x001a64:	movs    	r1, #9
0x001a66:	movs    	r0, #0xf1
0x001a68:	lsls    	r0, r0, #9
0x001a6a:	bl      	#0x7214
0x001a6e:	movs    	r1, #0
0x001a70:	str     	r1, [sp]
0x001a72:	str     	r1, [sp, #4]
0x001a74:	movs    	r2, #0
0x001a76:	str     	r2, [sp, #8]
0x001a78:	movs    	r3, #2
0x001a7a:	movs    	r0, #0xf1
0x001a7c:	lsls    	r0, r0, #9
0x001a7e:	ldrsh   	r2, [r5, r3]
0x001a80:	movs    	r1, #0x3f
0x001a82:	adds    	r3, r4, #0
0x001a84:	bl      	#0x7214
0x001a88:	movs    	r2, #0
0x001a8a:	adds    	r7, r0, #0
0x001a8c:	movs    	r1, #0
0x001a8e:	ldr     	r3, [pc, #0x358]
0x001a90:	str     	r1, [sp]
0x001a92:	str     	r1, [sp, #4]
0x001a94:	str     	r2, [sp, #8]
0x001a96:	add     	r3, pc
0x001a98:	adds    	r2, r6, #0
0x001a9a:	movs    	r1, #0x2d
0x001a9c:	movs    	r0, #0xf1
0x001a9e:	lsls    	r0, r0, #9
0x001aa0:	bl      	#0x7214
0x001aa4:	movs    	r2, #0
0x001aa6:	movs    	r1, #0
0x001aa8:	str     	r2, [sp, #8]
0x001aaa:	adds    	r3, r7, #0
0x001aac:	adds    	r2, r0, #0
0x001aae:	str     	r1, [sp]
0x001ab0:	str     	r1, [sp, #4]
0x001ab2:	movs    	r1, #0x2d
0x001ab4:	movs    	r0, #0xf1
0x001ab6:	lsls    	r0, r0, #9
0x001ab8:	bl      	#0x7214
0x001abc:	movs    	r1, #0
0x001abe:	adds    	r6, r0, #0
0x001ac0:	movs    	r2, #0
0x001ac2:	str     	r2, [sp, #8]
0x001ac4:	str     	r1, [sp]
0x001ac6:	str     	r1, [sp, #4]
0x001ac8:	adds    	r3, r4, #0
0x001aca:	adds    	r2, r7, #0
0x001acc:	movs    	r1, #9
0x001ace:	movs    	r0, #0xf1
0x001ad0:	lsls    	r0, r0, #9
0x001ad2:	bl      	#0x7214
0x001ad6:	movs    	r2, #0
0x001ad8:	movs    	r1, #0
0x001ada:	ldr     	r7, [pc, #0x310]
0x001adc:	str     	r1, [sp]
0x001ade:	str     	r1, [sp, #4]
0x001ae0:	str     	r2, [sp, #8]
0x001ae2:	add     	r7, pc
0x001ae4:	adds    	r3, r7, #0
0x001ae6:	adds    	r2, r6, #0
0x001ae8:	movs    	r1, #0x2d
0x001aea:	movs    	r0, #0xf1
0x001aec:	lsls    	r0, r0, #9
0x001aee:	bl      	#0x7214
0x001af2:	movs    	r1, #0
0x001af4:	str     	r0, [sp, #0x10]
0x001af6:	str     	r1, [sp]
0x001af8:	str     	r1, [sp, #4]
0x001afa:	movs    	r2, #0
0x001afc:	str     	r2, [sp, #8]
0x001afe:	movs    	r0, #0xf1
0x001b00:	movs    	r3, #4
0x001b02:	ldrsh   	r2, [r5, r3]
0x001b04:	lsls    	r0, r0, #9
0x001b06:	movs    	r1, #0x3f
0x001b08:	adds    	r3, r4, #0
0x001b0a:	bl      	#0x7214
0x001b0e:	movs    	r1, #0
0x001b10:	adds    	r6, r0, #0
0x001b12:	movs    	r2, #0
0x001b14:	adds    	r3, r0, #0
0x001b16:	str     	r1, [sp]
0x001b18:	str     	r1, [sp, #4]
0x001b1a:	movs    	r1, #0x2d
0x001b1c:	movs    	r0, #0xf1
0x001b1e:	str     	r2, [sp, #8]
0x001b20:	ldr     	r2, [sp, #0x10]
0x001b22:	lsls    	r0, r0, #9
0x001b24:	bl      	#0x7214

; ===== candidate_001ffc =====
0x001ffc:	push    	{r4, r5, r6, r7, lr}
0x001ffe:	sub     	sp, #0x44
0x002000:	movs    	r1, #0
0x002002:	str     	r1, [sp]
0x002004:	str     	r1, [sp, #4]
0x002006:	movs    	r5, #0xf1
0x002008:	movs    	r7, #0
0x00200a:	movs    	r2, #0
0x00200c:	adds    	r3, r7, #0
0x00200e:	lsls    	r5, r5, #9
0x002010:	movs    	r1, #0x1c
0x002012:	movs    	r6, #0x19
0x002014:	adds    	r0, r5, #0
0x002016:	str     	r2, [sp, #8]
0x002018:	bl      	#0x7214
0x00201c:	movs    	r1, #0
0x00201e:	movs    	r2, #0
0x002020:	str     	r2, [sp, #8]
0x002022:	str     	r1, [sp]
0x002024:	str     	r1, [sp, #4]
0x002026:	movs    	r1, #0xe1
0x002028:	movs    	r2, #0xed
0x00202a:	adds    	r4, r0, #0
0x00202c:	adds    	r3, r7, #0
0x00202e:	adds    	r0, r5, #0
0x002030:	bl      	#0x7214
0x002034:	cmp     	r0, #0
0x002036:	ble     	#0x211c
0x002038:	movs    	r1, #0
0x00203a:	str     	r1, [sp]
0x00203c:	str     	r1, [sp, #4]
0x00203e:	movs    	r1, #0xff
0x002040:	movs    	r2, #0
0x002042:	adds    	r1, #0x25
0x002044:	adds    	r3, r7, #0
0x002046:	adds    	r0, r5, #0
0x002048:	str     	r2, [sp, #8]
0x00204a:	bl      	#0x7214
0x00204e:	movs    	r2, #0
0x002050:	movs    	r1, #0
0x002052:	movs    	r0, #0
0x002054:	bl      	#0x71c4
0x002058:	movs    	r2, #0
0x00205a:	adds    	r3, r7, #0
0x00205c:	movs    	r1, #0x32
0x00205e:	adds    	r0, r5, #0
0x002060:	str     	r2, [sp, #8]
0x002062:	str     	r4, [sp]
0x002064:	str     	r6, [sp, #4]
0x002066:	bl      	#0x7214
0x00206a:	ldr     	r5, [pc, #0x3dc]
0x00206c:	add     	r5, pc
0x00206e:	add     	r2, sp, #0x3c
0x002070:	add     	r1, sp, #0x40
0x002072:	movs    	r0, #0
0x002074:	str     	r0, [sp]
0x002076:	str     	r1, [sp, #4]
0x002078:	str     	r2, [sp, #8]
0x00207a:	adds    	r3, r7, #0
0x00207c:	adds    	r2, r5, #0
0x00207e:	movs    	r1, #0x2a
0x002080:	movs    	r0, #0xf1
0x002082:	lsls    	r0, r0, #9
0x002084:	bl      	#0x7214
0x002088:	ldr     	r0, [sp, #0x40]
0x00208a:	str     	r5, [sp, #0x14]
0x00208c:	subs    	r0, r4, r0
0x00208e:	lsrs    	r1, r0, #0x1f
0x002090:	adds    	r0, r1, r0
0x002092:	movs    	r5, #0xff
0x002094:	asrs    	r0, r0, #1
0x002096:	str     	r0, [sp, #0x18]
0x002098:	movs    	r1, #0
0x00209a:	movs    	r0, #6
0x00209c:	str     	r5, [sp, #0x20]
0x00209e:	str     	r5, [sp, #0x24]
0x0020a0:	movs    	r2, #0
0x0020a2:	str     	r1, [sp, #4]
0x0020a4:	str     	r1, [sp]
0x0020a6:	str     	r0, [sp, #0x1c]
0x0020a8:	str     	r5, [sp, #0x28]
0x0020aa:	str     	r2, [sp, #8]
0x0020ac:	movs    	r0, #0xf1
0x0020ae:	movs    	r1, #0x56
0x0020b0:	adds    	r3, r7, #0
0x0020b2:	lsls    	r0, r0, #9
0x0020b4:	add     	r2, sp, #0x14
0x0020b6:	str     	r7, [sp, #0x2c]
0x0020b8:	str     	r7, [sp, #0x30]
0x0020ba:	bl      	#0x7214
0x0020be:	movs    	r1, #1
0x0020c0:	movs    	r2, #1
0x0020c2:	str     	r2, [sp, #8]
0x0020c4:	str     	r1, [sp]
0x0020c6:	str     	r1, [sp, #4]
0x0020c8:	movs    	r1, #0x55
0x0020ca:	movs    	r2, #0
0x0020cc:	adds    	r3, r6, #0
0x0020ce:	movs    	r0, #0xf1
0x0020d0:	lsls    	r0, r0, #9
0x0020d2:	bl      	#0x7214
0x0020d6:	ldr     	r0, [pc, #0x374]
0x0020d8:	movs    	r1, #0xa
0x0020da:	str     	r1, [sp, #0x18]
0x0020dc:	add     	r0, pc
0x0020de:	str     	r0, [sp, #0x14]
0x0020e0:	movs    	r1, #0
0x0020e2:	movs    	r0, #0x42
0x0020e4:	str     	r5, [sp, #0x20]
0x0020e6:	str     	r5, [sp, #0x24]
0x0020e8:	movs    	r2, #0
0x0020ea:	str     	r1, [sp, #4]
0x0020ec:	str     	r1, [sp]
0x0020ee:	str     	r0, [sp, #0x1c]
0x0020f0:	str     	r5, [sp, #0x28]
0x0020f2:	str     	r2, [sp, #8]
0x0020f4:	movs    	r0, #0xf1
0x0020f6:	movs    	r1, #0x56
0x0020f8:	movs    	r6, #0x3c
0x0020fa:	adds    	r3, r7, #0
0x0020fc:	lsls    	r0, r0, #9
0x0020fe:	add     	r2, sp, #0x14
0x002100:	str     	r7, [sp, #0x2c]
0x002102:	str     	r7, [sp, #0x30]
0x002104:	bl      	#0x7214
0x002108:	ldr     	r5, [sp, #0x40]
0x00210a:	movs    	r2, #0
0x00210c:	movs    	r1, #0x1e
0x00210e:	adds    	r5, #0xf
0x002110:	adds    	r3, r6, #0
0x002112:	str     	r1, [sp, #4]
0x002114:	movs    	r1, #0x2f
0x002116:	str     	r2, [sp, #8]
0x002118:	str     	r4, [sp]
0x00211a:	b       	#0x211e
0x00211c:	b       	#0x28b2
0x00211e:	movs    	r0, #0xf1
0x002120:	lsls    	r0, r0, #9
0x002122:	bl      	#0x7214
0x002126:	cmp     	r0, #1
0x002128:	bne     	#0x214a

; ===== candidate_002c18 =====
0x002c18:	push    	{lr}
0x002c1a:	sub     	sp, #0xc
0x002c1c:	movs    	r1, #0
0x002c1e:	movs    	r2, #0
0x002c20:	str     	r2, [sp, #8]
0x002c22:	str     	r1, [sp]
0x002c24:	str     	r1, [sp, #4]
0x002c26:	movs    	r1, #0xe1
0x002c28:	movs    	r2, #0x17
0x002c2a:	movs    	r3, #0
0x002c2c:	movs    	r0, #0xf1
0x002c2e:	lsls    	r0, r0, #9
0x002c30:	bl      	#0x7214
0x002c34:	movs    	r3, #0xff
0x002c36:	adds    	r3, #0x28
0x002c38:	cmp     	r0, r3
0x002c3a:	beq     	#0x2c8e
0x002c3c:	bgt     	#0x2c58
0x002c3e:	subs    	r3, #4
0x002c40:	cmp     	r0, r3
0x002c42:	beq     	#0x2c74
0x002c44:	adds    	r3, #1
0x002c46:	cmp     	r0, r3
0x002c48:	beq     	#0x2c88
0x002c4a:	adds    	r3, #1
0x002c4c:	cmp     	r0, r3
0x002c4e:	beq     	#0x2c82
0x002c50:	adds    	r3, #1
0x002c52:	cmp     	r0, r3
0x002c54:	bne     	#0x2c78
0x002c56:	b       	#0x2c8e
0x002c58:	movs    	r3, #0xff
0x002c5a:	adds    	r3, #0x29
0x002c5c:	cmp     	r0, r3
0x002c5e:	beq     	#0x2c8e
0x002c60:	adds    	r3, #1
0x002c62:	cmp     	r0, r3
0x002c64:	beq     	#0x2c8e
0x002c66:	adds    	r3, #1
0x002c68:	cmp     	r0, r3
0x002c6a:	beq     	#0x2c7c
0x002c6c:	movs    	r3, #0xff
0x002c6e:	adds    	r3, #0x43
0x002c70:	cmp     	r0, r3
0x002c72:	bne     	#0x2c78
0x002c74:	bl      	#0x3600
0x002c78:	add     	sp, #0xc
0x002c7a:	pop     	{pc}

; ===== candidate_002c94 =====
0x002c94:	push    	{r4, r5, lr}
0x002c96:	adds    	r5, r0, #0
0x002c98:	ldr     	r3, [r0, #0x18]
0x002c9a:	adds    	r4, r2, #0
0x002c9c:	adds    	r4, #0xa
0x002c9e:	movs    	r0, #0x1e
0x002ca0:	sub     	sp, #0x2c
0x002ca2:	movs    	r2, #0
0x002ca4:	str     	r2, [sp, #8]
0x002ca6:	ldr     	r2, [pc, #0x48]
0x002ca8:	str     	r0, [sp]
0x002caa:	str     	r4, [sp, #4]
0x002cac:	add     	r2, pc
0x002cae:	movs    	r1, #0x3c
0x002cb0:	movs    	r0, #0xf1
0x002cb2:	lsls    	r0, r0, #9
0x002cb4:	bl      	#0x7214
0x002cb8:	ldr     	r2, [r5, #0x20]
0x002cba:	movs    	r0, #0x3c
0x002cbc:	str     	r0, [sp, #0x10]
0x002cbe:	movs    	r0, #0xff
0x002cc0:	adds    	r1, r4, #0
0x002cc2:	movs    	r3, #0
0x002cc4:	adds    	r1, #0x14
0x002cc6:	str     	r1, [sp, #0x14]
0x002cc8:	movs    	r1, #0
0x002cca:	str     	r0, [sp, #0x20]
0x002ccc:	str     	r2, [sp, #0xc]
0x002cce:	movs    	r2, #0
0x002cd0:	str     	r3, [sp, #0x24]
0x002cd2:	str     	r1, [sp, #4]
0x002cd4:	str     	r1, [sp]
0x002cd6:	str     	r3, [sp, #0x28]
0x002cd8:	str     	r0, [sp, #0x18]
0x002cda:	str     	r0, [sp, #0x1c]
0x002cdc:	movs    	r0, #0xf1
0x002cde:	str     	r2, [sp, #8]
0x002ce0:	movs    	r1, #0x56
0x002ce2:	lsls    	r0, r0, #9
0x002ce4:	add     	r2, sp, #0xc
0x002ce6:	bl      	#0x7214
0x002cea:	add     	sp, #0x2c
0x002cec:	pop     	{r4, r5, pc}

; ===== candidate_002cf4 =====
0x002cf4:	push    	{r4, r5, r6, r7, lr}
0x002cf6:	sub     	sp, #0x3c
0x002cf8:	movs    	r1, #0
0x002cfa:	str     	r1, [sp]
0x002cfc:	str     	r1, [sp, #4]
0x002cfe:	movs    	r6, #0xf1
0x002d00:	movs    	r7, #0
0x002d02:	movs    	r2, #0
0x002d04:	adds    	r3, r7, #0
0x002d06:	lsls    	r6, r6, #9
0x002d08:	movs    	r1, #0x1c
0x002d0a:	movs    	r5, #0x19
0x002d0c:	adds    	r0, r6, #0
0x002d0e:	str     	r2, [sp, #8]
0x002d10:	bl      	#0x7214
0x002d14:	movs    	r1, #0
0x002d16:	movs    	r2, #0
0x002d18:	str     	r2, [sp, #8]
0x002d1a:	str     	r1, [sp]
0x002d1c:	str     	r1, [sp, #4]
0x002d1e:	movs    	r1, #0xe1
0x002d20:	movs    	r2, #0xed
0x002d22:	adds    	r4, r0, #0
0x002d24:	adds    	r3, r7, #0
0x002d26:	adds    	r0, r6, #0
0x002d28:	bl      	#0x7214
0x002d2c:	cmp     	r0, #0
0x002d2e:	ble     	#0x2e14
0x002d30:	movs    	r1, #0
0x002d32:	str     	r1, [sp]
0x002d34:	str     	r1, [sp, #4]
0x002d36:	movs    	r1, #0xff
0x002d38:	movs    	r2, #0
0x002d3a:	adds    	r1, #0x25
0x002d3c:	movs    	r3, #0
0x002d3e:	adds    	r0, r6, #0
0x002d40:	str     	r2, [sp, #8]
0x002d42:	bl      	#0x7214
0x002d46:	movs    	r2, #0
0x002d48:	movs    	r1, #0
0x002d4a:	movs    	r0, #0
0x002d4c:	bl      	#0x71c4
0x002d50:	str     	r5, [sp, #4]
0x002d52:	movs    	r5, #0
0x002d54:	movs    	r2, #0
0x002d56:	adds    	r3, r5, #0
0x002d58:	movs    	r1, #0x32
0x002d5a:	adds    	r0, r6, #0
0x002d5c:	str     	r2, [sp, #8]
0x002d5e:	str     	r4, [sp]
0x002d60:	bl      	#0x7214
0x002d64:	ldr     	r6, [pc, #0x3dc]
0x002d66:	add     	r6, pc
0x002d68:	add     	r2, sp, #0x34
0x002d6a:	add     	r1, sp, #0x38
0x002d6c:	movs    	r0, #0
0x002d6e:	str     	r0, [sp]
0x002d70:	str     	r1, [sp, #4]
0x002d72:	str     	r2, [sp, #8]
0x002d74:	adds    	r3, r5, #0
0x002d76:	adds    	r2, r6, #0
0x002d78:	movs    	r1, #0x2a
0x002d7a:	movs    	r0, #0xf1
0x002d7c:	lsls    	r0, r0, #9
0x002d7e:	bl      	#0x7214
0x002d82:	ldr     	r0, [sp, #0x38]
0x002d84:	movs    	r7, #0xff
0x002d86:	subs    	r0, r4, r0
0x002d88:	lsrs    	r1, r0, #0x1f
0x002d8a:	adds    	r0, r1, r0
0x002d8c:	asrs    	r0, r0, #1
0x002d8e:	str     	r0, [sp, #0x10]
0x002d90:	movs    	r1, #0
0x002d92:	movs    	r0, #6
0x002d94:	str     	r7, [sp, #0x20]
0x002d96:	str     	r5, [sp, #0x24]
0x002d98:	movs    	r2, #0
0x002d9a:	str     	r1, [sp, #4]
0x002d9c:	str     	r1, [sp]
0x002d9e:	str     	r0, [sp, #0x14]
0x002da0:	str     	r5, [sp, #0x28]
0x002da2:	str     	r2, [sp, #8]
0x002da4:	movs    	r0, #0xf1
0x002da6:	movs    	r1, #0x56
0x002da8:	adds    	r3, r5, #0
0x002daa:	lsls    	r0, r0, #9
0x002dac:	add     	r2, sp, #0xc
0x002dae:	str     	r7, [sp, #0x18]
0x002db0:	str     	r7, [sp, #0x1c]
0x002db2:	str     	r6, [sp, #0xc]
0x002db4:	bl      	#0x7214
0x002db8:	movs    	r0, #0xa
0x002dba:	str     	r0, [sp, #0x2c]
0x002dbc:	ldr     	r0, [pc, #0x388]
0x002dbe:	add     	r2, sp, #0x34
0x002dc0:	add     	r0, pc
0x002dc2:	str     	r0, [sp, #0x30]
0x002dc4:	movs    	r0, #0
0x002dc6:	str     	r2, [sp, #8]
0x002dc8:	ldr     	r2, [pc, #0x380]
0x002dca:	movs    	r6, #0x23
0x002dcc:	add     	r1, sp, #0x38
0x002dce:	str     	r1, [sp, #4]
0x002dd0:	adds    	r3, r5, #0
0x002dd2:	str     	r0, [sp]
0x002dd4:	add     	r2, pc
0x002dd6:	movs    	r1, #0x2a
0x002dd8:	movs    	r0, #0xf1
0x002dda:	lsls    	r0, r0, #9
0x002ddc:	bl      	#0x7214
0x002de0:	ldr     	r0, [sp, #0x30]
0x002de2:	movs    	r1, #0
0x002de4:	str     	r0, [sp, #0xc]
0x002de6:	ldr     	r0, [sp, #0x2c]
0x002de8:	str     	r7, [sp, #0x20]
0x002dea:	str     	r0, [sp, #0x10]
0x002dec:	movs    	r0, #0x29
0x002dee:	str     	r5, [sp, #0x24]
0x002df0:	movs    	r2, #0
0x002df2:	str     	r1, [sp, #4]
0x002df4:	str     	r0, [sp, #0x14]
0x002df6:	str     	r1, [sp]
0x002df8:	str     	r5, [sp, #0x28]
0x002dfa:	str     	r2, [sp, #8]
0x002dfc:	movs    	r1, #0x56
0x002dfe:	movs    	r0, #0xf1
0x002e00:	adds    	r3, r5, #0
0x002e02:	lsls    	r0, r0, #9
0x002e04:	add     	r2, sp, #0xc
0x002e06:	str     	r7, [sp, #0x18]
0x002e08:	str     	r7, [sp, #0x1c]
0x002e0a:	bl      	#0x7214
0x002e0e:	ldr     	r5, [sp, #0x38]
0x002e10:	adds    	r5, #0xf
0x002e12:	b       	#0x2e16
0x002e14:	b       	#0x31c6
0x002e16:	movs    	r1, #0x1e
0x002e18:	str     	r1, [sp, #4]
0x002e1a:	movs    	r2, #0
0x002e1c:	movs    	r1, #0x2f
0x002e1e:	adds    	r3, r6, #0

; ===== candidate_0031e0 =====
0x0031e0:	push    	{r4, r5, r6, r7, lr}
0x0031e2:	sub     	sp, #0x2c
0x0031e4:	movs    	r1, #0
0x0031e6:	str     	r1, [sp]
0x0031e8:	str     	r1, [sp, #4]
0x0031ea:	ldr     	r6, [pc, #0xc0]
0x0031ec:	movs    	r5, #0
0x0031ee:	movs    	r2, #0
0x0031f0:	adds    	r3, r5, #0
0x0031f2:	movs    	r1, #0xff
0x0031f4:	adds    	r1, #0x10
0x0031f6:	str     	r2, [sp, #8]
0x0031f8:	movs    	r0, #0xf1
0x0031fa:	add     	r6, sb
0x0031fc:	ldr     	r2, [r6, #0x6c]
0x0031fe:	lsls    	r0, r0, #9
0x003200:	bl      	#0x7214
0x003204:	ldr     	r4, [r6, #0x6c]
0x003206:	lsls    	r0, r0, #2
0x003208:	ldr     	r7, [r4, r0]
0x00320a:	movs    	r1, #0
0x00320c:	movs    	r2, #0
0x00320e:	str     	r2, [sp, #8]
0x003210:	str     	r1, [sp]
0x003212:	str     	r1, [sp, #4]
0x003214:	movs    	r1, #0x11
0x003216:	adds    	r2, r4, #0
0x003218:	movs    	r0, #0xf1
0x00321a:	movs    	r3, #4
0x00321c:	lsls    	r0, r0, #9
0x00321e:	bl      	#0x7214
0x003222:	adds    	r4, r0, #0
0x003224:	movs    	r0, #0
0x003226:	add     	r2, sp, #0x24
0x003228:	add     	r1, sp, #0x28
0x00322a:	str     	r1, [sp, #4]
0x00322c:	str     	r2, [sp, #8]
0x00322e:	str     	r0, [sp]
0x003230:	adds    	r3, r5, #0
0x003232:	adds    	r2, r7, #0
0x003234:	movs    	r0, #0xf1
0x003236:	movs    	r1, #0x2a
0x003238:	lsls    	r0, r0, #9
0x00323a:	bl      	#0x7214
0x00323e:	ldr     	r0, [sp, #0x24]
0x003240:	ldr     	r7, [sp, #0x28]
0x003242:	muls    	r4, r0, r4
0x003244:	ldr     	r0, [r6, #0x6c]
0x003246:	movs    	r1, #0
0x003248:	str     	r0, [sp, #0xc]
0x00324a:	movs    	r0, #0xa
0x00324c:	str     	r0, [sp, #0x10]
0x00324e:	str     	r1, [sp]
0x003250:	str     	r1, [sp, #4]
0x003252:	movs    	r2, #0
0x003254:	adds    	r7, #0x28
0x003256:	adds    	r4, #0x14
0x003258:	adds    	r3, r5, #0
0x00325a:	movs    	r1, #0x1d
0x00325c:	movs    	r0, #0xf1
0x00325e:	lsls    	r0, r0, #9
0x003260:	str     	r2, [sp, #8]
0x003262:	bl      	#0x7214
0x003266:	subs    	r0, r0, r4
0x003268:	subs    	r0, #0x14
0x00326a:	str     	r0, [sp, #0x14]
0x00326c:	ldr     	r0, [pc, #0x3c]
0x00326e:	movs    	r1, #0
0x003270:	add     	r0, sb
0x003272:	adds    	r0, #0x68
0x003274:	str     	r0, [sp, #0x20]
0x003276:	movs    	r2, #0
0x003278:	str     	r1, [sp]
0x00327a:	str     	r1, [sp, #4]
0x00327c:	movs    	r1, #0x2b
0x00327e:	str     	r2, [sp, #8]
0x003280:	movs    	r0, #0xf1
0x003282:	adds    	r3, r5, #0
0x003284:	lsls    	r0, r0, #9
0x003286:	add     	r2, sp, #0xc
0x003288:	str     	r7, [sp, #0x18]
0x00328a:	str     	r4, [sp, #0x1c]
0x00328c:	bl      	#0x7214
0x003290:	movs    	r1, #0
0x003292:	movs    	r2, #0
0x003294:	str     	r2, [sp, #8]
0x003296:	str     	r1, [sp]
0x003298:	str     	r1, [sp, #4]
0x00329a:	movs    	r1, #0x24
0x00329c:	movs    	r2, #1
0x00329e:	movs    	r3, #1
0x0032a0:	movs    	r0, #0xf1
0x0032a2:	lsls    	r0, r0, #9
0x0032a4:	bl      	#0x7214
0x0032a8:	add     	sp, #0x2c
0x0032aa:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0032b0 =====
0x0032b0:	push    	{r4, r5, lr}
0x0032b2:	sub     	sp, #0xc
0x0032b4:	movs    	r1, #0
0x0032b6:	str     	r1, [sp]
0x0032b8:	str     	r1, [sp, #4]
0x0032ba:	movs    	r1, #0xff
0x0032bc:	movs    	r5, #0xf1
0x0032be:	movs    	r4, #0
0x0032c0:	movs    	r2, #0
0x0032c2:	adds    	r3, r4, #0
0x0032c4:	lsls    	r5, r5, #9
0x0032c6:	adds    	r1, #0x26
0x0032c8:	adds    	r0, r5, #0
0x0032ca:	str     	r2, [sp, #8]
0x0032cc:	bl      	#0x7214
0x0032d0:	movs    	r1, #0
0x0032d2:	movs    	r2, #0
0x0032d4:	str     	r2, [sp, #8]
0x0032d6:	str     	r1, [sp]
0x0032d8:	str     	r1, [sp, #4]
0x0032da:	movs    	r1, #0xe1
0x0032dc:	movs    	r2, #0xed
0x0032de:	adds    	r3, r4, #0
0x0032e0:	adds    	r0, r5, #0
0x0032e2:	bl      	#0x7214
0x0032e6:	cmp     	r0, #0
0x0032e8:	ble     	#0x332a
0x0032ea:	movs    	r1, #0
0x0032ec:	str     	r1, [sp]
0x0032ee:	str     	r1, [sp, #4]
0x0032f0:	movs    	r1, #0xff
0x0032f2:	movs    	r2, #0
0x0032f4:	adds    	r1, #0x25
0x0032f6:	adds    	r3, r4, #0
0x0032f8:	adds    	r0, r5, #0
0x0032fa:	str     	r2, [sp, #8]
0x0032fc:	bl      	#0x7214
0x003300:	movs    	r2, #0
0x003302:	movs    	r1, #0
0x003304:	movs    	r0, #0
0x003306:	bl      	#0x71c4
0x00330a:	bl      	#0x3344
0x00330e:	ldr     	r0, [pc, #0x30]
0x003310:	add     	r0, sb
0x003312:	ldr     	r1, [r0, #0x58]
0x003314:	cmp     	r1, #0
0x003316:	beq     	#0x332e
0x003318:	cmp     	r1, #1
0x00331a:	beq     	#0x3334
0x00331c:	cmp     	r1, #2
0x00331e:	bne     	#0x332a
0x003320:	ldr     	r0, [r0, #0x24]
0x003322:	cmp     	r0, #0
0x003324:	beq     	#0x332a
0x003326:	bl      	#0x4500
0x00332a:	add     	sp, #0xc
0x00332c:	pop     	{r4, r5, pc}

; ===== candidate_003344 =====
0x003344:	push    	{r4, r5, r6, r7, lr}
0x003346:	sub     	sp, #0x4c
0x003348:	movs    	r1, #0
0x00334a:	str     	r1, [sp]
0x00334c:	str     	r1, [sp, #4]
0x00334e:	movs    	r6, #0
0x003350:	movs    	r2, #0
0x003352:	adds    	r3, r6, #0
0x003354:	movs    	r1, #0x1c
0x003356:	movs    	r4, #0
0x003358:	movs    	r0, #0xf1
0x00335a:	lsls    	r0, r0, #9
0x00335c:	str     	r2, [sp, #8]
0x00335e:	bl      	#0x7214
0x003362:	adds    	r5, r0, #0
0x003364:	blx     	#0x308
0x003368:	movs    	r2, #0
0x00336a:	movs    	r0, #0
0x00336c:	str     	r0, [sp, #0x2c]
0x00336e:	str     	r1, [sp, #0x34]
0x003370:	movs    	r7, #0x19
0x003372:	movs    	r1, #0x32
0x003374:	movs    	r0, #0xf1
0x003376:	adds    	r3, r6, #0
0x003378:	lsls    	r0, r0, #9
0x00337a:	str     	r7, [sp, #4]
0x00337c:	str     	r2, [sp, #0x30]
0x00337e:	str     	r2, [sp, #8]
0x003380:	str     	r5, [sp]
0x003382:	bl      	#0x7214
0x003386:	ldr     	r5, [pc, #0x180]
0x003388:	add     	r5, pc
0x00338a:	add     	r2, sp, #0x38
0x00338c:	add     	r1, sp, #0x3c
0x00338e:	movs    	r0, #0
0x003390:	str     	r0, [sp]
0x003392:	str     	r1, [sp, #4]
0x003394:	str     	r2, [sp, #8]
0x003396:	adds    	r3, r6, #0
0x003398:	adds    	r2, r5, #0
0x00339a:	movs    	r1, #0x2a
0x00339c:	movs    	r0, #0xf1
0x00339e:	lsls    	r0, r0, #9
0x0033a0:	bl      	#0x7214
0x0033a4:	ldr     	r6, [sp, #0x34]
0x0033a6:	ldr     	r0, [sp, #0x2c]
0x0033a8:	subs    	r7, #6
0x0033aa:	subs    	r6, #0xa
0x0033ac:	adds    	r0, #6
0x0033ae:	str     	r0, [sp, #0x48]
0x0033b0:	cmp     	r4, #0
0x0033b2:	beq     	#0x3406
0x0033b4:	cmp     	r4, #1
0x0033b6:	beq     	#0x340c
0x0033b8:	cmp     	r4, #2
0x0033ba:	bne     	#0x33c0
0x0033bc:	ldr     	r5, [pc, #0x14c]
0x0033be:	add     	r5, pc
0x0033c0:	movs    	r2, #0
0x0033c2:	str     	r2, [sp, #8]
0x0033c4:	ldr     	r0, [sp, #0x34]
0x0033c6:	adds    	r2, r4, #0
0x0033c8:	muls    	r2, r0, r2
0x0033ca:	str     	r7, [sp, #4]
0x0033cc:	str     	r2, [sp, #0x44]
0x0033ce:	adds    	r2, #5
0x0033d0:	movs    	r0, #0xf1
0x0033d2:	str     	r6, [sp]
0x0033d4:	movs    	r3, #3
0x0033d6:	movs    	r1, #0x2f
0x0033d8:	lsls    	r0, r0, #9
0x0033da:	str     	r2, [sp, #0x40]
0x0033dc:	bl      	#0x7214
0x0033e0:	cmp     	r0, #1
0x0033e2:	bne     	#0x349a
0x0033e4:	ldr     	r1, [pc, #0x128]
0x0033e6:	add     	r1, sb
0x0033e8:	ldr     	r0, [r1, #0x58]
0x0033ea:	cmp     	r0, r4
0x0033ec:	bne     	#0x3412
0x0033ee:	movs    	r0, #3
0x0033f0:	str     	r0, [sp]
0x0033f2:	movs    	r0, #0xf1
0x0033f4:	movs    	r2, #4
0x0033f6:	movs    	r1, #0x23
0x0033f8:	lsls    	r0, r0, #9
0x0033fa:	ldr     	r3, [sp, #0x40]
0x0033fc:	str     	r6, [sp, #4]
0x0033fe:	str     	r7, [sp, #8]
0x003400:	bl      	#0x7214
0x003404:	b       	#0x349a
0x003406:	ldr     	r5, [pc, #0x10c]
0x003408:	add     	r5, pc
0x00340a:	b       	#0x33c0
0x00340c:	ldr     	r5, [pc, #0x108]
0x00340e:	add     	r5, pc
0x003410:	b       	#0x33c0
0x003412:	ldr     	r1, [pc, #0xfc]
0x003414:	add     	r1, sb
0x003416:	str     	r4, [r1, #0x58]
0x003418:	ldr     	r0, [r1, #0x28]
0x00341a:	cmp     	r0, #0
0x00341c:	bne     	#0x3452
0x00341e:	cmp     	r4, #1
0x003420:	bne     	#0x3452
0x003422:	movs    	r1, #0
0x003424:	str     	r1, [sp]
0x003426:	str     	r1, [sp, #4]
0x003428:	movs    	r2, #0
0x00342a:	movs    	r1, #0x34
0x00342c:	movs    	r3, #0
0x00342e:	movs    	r0, #0xf1
0x003430:	lsls    	r0, r0, #9
0x003432:	str     	r2, [sp, #8]
0x003434:	bl      	#0x7214
0x003438:	bl      	#0x501c
0x00343c:	adds    	r3, r0, #0
0x00343e:	ldr     	r0, [pc, #0xd0]
0x003440:	rsbs    	r2, r4, #0
0x003442:	add     	r0, sb
0x003444:	ldr     	r0, [r0, #0x18]
0x003446:	ldr     	r0, [r0]
0x003448:	ldr     	r1, [r0]
0x00344a:	movs    	r0, #0xff
0x00344c:	adds    	r0, #0x39
0x00344e:	bl      	#0x7e7c
0x003452:	ldr     	r1, [pc, #0xbc]
0x003454:	add     	r1, sb
0x003456:	ldr     	r0, [r1, #0x24]
0x003458:	cmp     	r0, #0
0x00345a:	bne     	#0x349a
0x00345c:	ldr     	r0, [r1, #0x58]
0x00345e:	cmp     	r0, #2
0x003460:	bne     	#0x349a
0x003462:	movs    	r1, #0
0x003464:	str     	r1, [sp]
0x003466:	str     	r1, [sp, #4]
0x003468:	movs    	r2, #0
0x00346a:	movs    	r1, #0x34
0x00346c:	movs    	r3, #0
0x00346e:	movs    	r0, #0xf1

; ===== candidate_00351c =====
0x00351c:	push    	{r4, r5, r6, r7, lr}
0x00351e:	sub     	sp, #0x34
0x003520:	movs    	r1, #0
0x003522:	str     	r1, [sp]
0x003524:	str     	r1, [sp, #4]
0x003526:	movs    	r7, #0
0x003528:	movs    	r2, #0
0x00352a:	adds    	r3, r7, #0
0x00352c:	movs    	r1, #0x1c
0x00352e:	movs    	r5, #0x19
0x003530:	movs    	r0, #0xf1
0x003532:	lsls    	r0, r0, #9
0x003534:	str     	r2, [sp, #8]
0x003536:	bl      	#0x7214
0x00353a:	ldr     	r4, [pc, #0xc0]
0x00353c:	adds    	r6, r0, #0
0x00353e:	add     	r4, pc
0x003540:	movs    	r1, #0
0x003542:	movs    	r2, #0
0x003544:	str     	r2, [sp, #8]
0x003546:	str     	r1, [sp]
0x003548:	str     	r1, [sp, #4]
0x00354a:	movs    	r1, #0xe1
0x00354c:	movs    	r2, #0xed
0x00354e:	adds    	r3, r7, #0
0x003550:	movs    	r0, #0xf1
0x003552:	lsls    	r0, r0, #9
0x003554:	bl      	#0x7214
0x003558:	cmp     	r0, #0
0x00355a:	ble     	#0x35f8
0x00355c:	movs    	r1, #0
0x00355e:	str     	r1, [sp]
0x003560:	str     	r1, [sp, #4]
0x003562:	movs    	r1, #0xff
0x003564:	movs    	r2, #0
0x003566:	movs    	r7, #0xf1
0x003568:	lsls    	r7, r7, #9
0x00356a:	adds    	r1, #0x25
0x00356c:	movs    	r3, #0
0x00356e:	adds    	r0, r7, #0
0x003570:	str     	r2, [sp, #8]
0x003572:	bl      	#0x7214
0x003576:	movs    	r2, #0
0x003578:	movs    	r1, #0
0x00357a:	movs    	r0, #0
0x00357c:	bl      	#0x71c4
0x003580:	str     	r5, [sp, #4]
0x003582:	movs    	r5, #0
0x003584:	movs    	r2, #0
0x003586:	adds    	r3, r5, #0
0x003588:	movs    	r1, #0x32
0x00358a:	adds    	r0, r7, #0
0x00358c:	str     	r2, [sp, #8]
0x00358e:	str     	r6, [sp]
0x003590:	bl      	#0x7214
0x003594:	add     	r2, sp, #0x2c
0x003596:	add     	r1, sp, #0x30
0x003598:	str     	r1, [sp, #4]
0x00359a:	str     	r2, [sp, #8]
0x00359c:	movs    	r0, #0
0x00359e:	str     	r0, [sp]
0x0035a0:	adds    	r2, r4, #0
0x0035a2:	movs    	r1, #0x2a
0x0035a4:	adds    	r3, r5, #0
0x0035a6:	adds    	r0, r7, #0
0x0035a8:	bl      	#0x7214
0x0035ac:	movs    	r1, #0
0x0035ae:	str     	r1, [sp]
0x0035b0:	str     	r1, [sp, #4]
0x0035b2:	movs    	r2, #0
0x0035b4:	movs    	r1, #0x1c
0x0035b6:	adds    	r3, r5, #0
0x0035b8:	adds    	r0, r7, #0
0x0035ba:	str     	r2, [sp, #8]
0x0035bc:	str     	r4, [sp, #0xc]
0x0035be:	bl      	#0x7214
0x0035c2:	ldr     	r1, [sp, #0x30]
0x0035c4:	str     	r5, [sp, #0x24]
0x0035c6:	subs    	r0, r0, r1
0x0035c8:	lsrs    	r1, r0, #0x1f
0x0035ca:	adds    	r0, r1, r0
0x0035cc:	asrs    	r0, r0, #1
0x0035ce:	str     	r0, [sp, #0x10]
0x0035d0:	movs    	r0, #6
0x0035d2:	str     	r0, [sp, #0x14]
0x0035d4:	movs    	r0, #0xff
0x0035d6:	movs    	r1, #0
0x0035d8:	str     	r0, [sp, #0x20]
0x0035da:	movs    	r2, #0
0x0035dc:	str     	r1, [sp]
0x0035de:	str     	r1, [sp, #4]
0x0035e0:	str     	r5, [sp, #0x28]
0x0035e2:	str     	r2, [sp, #8]
0x0035e4:	movs    	r1, #0x56
0x0035e6:	str     	r0, [sp, #0x18]
0x0035e8:	str     	r0, [sp, #0x1c]
0x0035ea:	adds    	r3, r5, #0
0x0035ec:	adds    	r0, r7, #0
0x0035ee:	add     	r2, sp, #0xc
0x0035f0:	bl      	#0x7214
0x0035f4:	bl      	#0x4a70
0x0035f8:	add     	sp, #0x34
0x0035fa:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003600 =====
0x003600:	push    	{r4, r5, r6, r7, lr}
0x003602:	sub     	sp, #0x64
0x003604:	movs    	r1, #0x32
0x003606:	str     	r1, [sp, #0x4c]
0x003608:	movs    	r0, #0
0x00360a:	movs    	r1, #0
0x00360c:	str     	r1, [sp, #4]
0x00360e:	str     	r0, [sp, #0x48]
0x003610:	movs    	r4, #0xf1
0x003612:	movs    	r7, #0
0x003614:	movs    	r2, #0
0x003616:	adds    	r3, r7, #0
0x003618:	lsls    	r4, r4, #9
0x00361a:	movs    	r1, #0x1c
0x00361c:	str     	r0, [sp]
0x00361e:	movs    	r5, #0x19
0x003620:	adds    	r0, r4, #0
0x003622:	str     	r2, [sp, #8]
0x003624:	bl      	#0x7214
0x003628:	movs    	r1, #0
0x00362a:	movs    	r2, #0
0x00362c:	str     	r2, [sp, #8]
0x00362e:	str     	r1, [sp]
0x003630:	str     	r1, [sp, #4]
0x003632:	movs    	r1, #0xe1
0x003634:	movs    	r2, #0xed
0x003636:	str     	r0, [sp, #0x3c]
0x003638:	movs    	r6, #0x19
0x00363a:	adds    	r3, r7, #0
0x00363c:	adds    	r0, r4, #0
0x00363e:	bl      	#0x7214
0x003642:	cmp     	r0, #0
0x003644:	ble     	#0x372a
0x003646:	movs    	r1, #0
0x003648:	str     	r1, [sp]
0x00364a:	str     	r1, [sp, #4]
0x00364c:	movs    	r1, #0xff
0x00364e:	movs    	r2, #0
0x003650:	adds    	r1, #0x25
0x003652:	adds    	r3, r7, #0
0x003654:	adds    	r0, r4, #0
0x003656:	str     	r2, [sp, #8]
0x003658:	bl      	#0x7214
0x00365c:	movs    	r2, #0
0x00365e:	movs    	r1, #0
0x003660:	movs    	r0, #0
0x003662:	bl      	#0x71c4
0x003666:	movs    	r1, #0
0x003668:	str     	r1, [sp]
0x00366a:	str     	r1, [sp, #4]
0x00366c:	movs    	r2, #0
0x00366e:	movs    	r1, #0x1c
0x003670:	adds    	r3, r7, #0
0x003672:	adds    	r0, r4, #0
0x003674:	str     	r2, [sp, #8]
0x003676:	bl      	#0x7214
0x00367a:	movs    	r2, #0
0x00367c:	str     	r0, [sp]
0x00367e:	adds    	r3, r7, #0
0x003680:	movs    	r1, #0x32
0x003682:	adds    	r0, r4, #0
0x003684:	str     	r2, [sp, #8]
0x003686:	str     	r5, [sp, #4]
0x003688:	bl      	#0x7214
0x00368c:	movs    	r1, #0
0x00368e:	movs    	r2, #0
0x003690:	str     	r2, [sp, #8]
0x003692:	str     	r1, [sp]
0x003694:	str     	r1, [sp, #4]
0x003696:	movs    	r1, #0xe1
0x003698:	movs    	r2, #0x17
0x00369a:	adds    	r3, r7, #0
0x00369c:	adds    	r0, r4, #0
0x00369e:	bl      	#0x7214
0x0036a2:	subs    	r0, #0xff
0x0036a4:	subs    	r0, #0x24
0x0036a6:	bne     	#0x36ae
0x0036a8:	ldr     	r4, [pc, #0x3dc]
0x0036aa:	add     	r4, pc
0x0036ac:	b       	#0x36b2
0x0036ae:	ldr     	r4, [pc, #0x3dc]
0x0036b0:	add     	r4, pc
0x0036b2:	add     	r2, sp, #0x54
0x0036b4:	add     	r1, sp, #0x58
0x0036b6:	movs    	r0, #0
0x0036b8:	movs    	r7, #0
0x0036ba:	adds    	r3, r7, #0
0x0036bc:	str     	r0, [sp]
0x0036be:	str     	r1, [sp, #4]
0x0036c0:	str     	r2, [sp, #8]
0x0036c2:	adds    	r2, r4, #0
0x0036c4:	movs    	r1, #0x2a
0x0036c6:	movs    	r0, #0xf1
0x0036c8:	lsls    	r0, r0, #9
0x0036ca:	bl      	#0x7214
0x0036ce:	movs    	r1, #0
0x0036d0:	str     	r1, [sp]
0x0036d2:	str     	r1, [sp, #4]
0x0036d4:	movs    	r2, #0
0x0036d6:	movs    	r1, #0x1c
0x0036d8:	adds    	r3, r7, #0
0x0036da:	movs    	r0, #0xf1
0x0036dc:	lsls    	r0, r0, #9
0x0036de:	str     	r2, [sp, #8]
0x0036e0:	str     	r4, [sp, #0x18]
0x0036e2:	bl      	#0x7214
0x0036e6:	ldr     	r1, [sp, #0x58]
0x0036e8:	movs    	r4, #0xff
0x0036ea:	subs    	r0, r0, r1
0x0036ec:	lsrs    	r1, r0, #0x1f
0x0036ee:	adds    	r0, r1, r0
0x0036f0:	asrs    	r0, r0, #1
0x0036f2:	str     	r0, [sp, #0x1c]
0x0036f4:	movs    	r0, #6
0x0036f6:	str     	r0, [sp, #0x20]
0x0036f8:	movs    	r0, #0xff
0x0036fa:	str     	r0, [sp, #0x28]
0x0036fc:	movs    	r1, #0
0x0036fe:	str     	r4, [sp, #0x24]
0x003700:	movs    	r2, #0
0x003702:	str     	r1, [sp, #4]
0x003704:	str     	r1, [sp]
0x003706:	str     	r0, [sp, #0x2c]
0x003708:	movs    	r0, #0xf1
0x00370a:	movs    	r1, #0x56
0x00370c:	str     	r2, [sp, #8]
0x00370e:	adds    	r3, r7, #0
0x003710:	lsls    	r0, r0, #9
0x003712:	add     	r2, sp, #0x18
0x003714:	str     	r7, [sp, #0x30]
0x003716:	str     	r7, [sp, #0x34]
0x003718:	bl      	#0x7214
0x00371c:	movs    	r1, #0
0x00371e:	movs    	r2, #0
0x003720:	str     	r2, [sp, #8]
0x003722:	movs    	r3, #4
0x003724:	str     	r1, [sp]
0x003726:	str     	r1, [sp, #4]
0x003728:	b       	#0x372c
0x00372a:	b       	#0x3ab4
0x00372c:	ldr     	r0, [pc, #0x360]

; ===== candidate_003bd4 =====
0x003bd4:	push    	{r4, r5, r6, r7, lr}
0x003bd6:	sub     	sp, #0x54
0x003bd8:	movs    	r1, #0
0x003bda:	str     	r1, [sp]
0x003bdc:	str     	r1, [sp, #4]
0x003bde:	movs    	r6, #0
0x003be0:	movs    	r2, #0
0x003be2:	adds    	r3, r6, #0
0x003be4:	movs    	r1, #0x1c
0x003be6:	movs    	r0, #0xf1
0x003be8:	lsls    	r0, r0, #9
0x003bea:	str     	r2, [sp, #8]
0x003bec:	bl      	#0x7214
0x003bf0:	adds    	r4, r0, #0
0x003bf2:	movs    	r0, #0
0x003bf4:	str     	r0, [sp, #0x40]
0x003bf6:	movs    	r0, #0x50
0x003bf8:	str     	r0, [sp, #0x3c]
0x003bfa:	movs    	r1, #0
0x003bfc:	movs    	r0, #0x19
0x003bfe:	str     	r0, [sp, #0x38]
0x003c00:	str     	r1, [sp]
0x003c02:	str     	r1, [sp, #4]
0x003c04:	movs    	r2, #0
0x003c06:	movs    	r1, #0x1d
0x003c08:	movs    	r0, #0xf1
0x003c0a:	adds    	r3, r6, #0
0x003c0c:	movs    	r5, #0x19
0x003c0e:	movs    	r7, #0
0x003c10:	lsls    	r0, r0, #9
0x003c12:	str     	r2, [sp, #8]
0x003c14:	bl      	#0x7214
0x003c18:	ldr     	r1, [sp, #0x38]
0x003c1a:	movs    	r2, #0
0x003c1c:	str     	r1, [sp, #4]
0x003c1e:	movs    	r1, #0x32
0x003c20:	str     	r2, [sp, #8]
0x003c22:	movs    	r3, #0x19
0x003c24:	str     	r4, [sp]
0x003c26:	movs    	r0, #0xf1
0x003c28:	lsls    	r0, r0, #9
0x003c2a:	ldr     	r2, [sp, #0x40]
0x003c2c:	bl      	#0x7214
0x003c30:	movs    	r2, #0
0x003c32:	movs    	r1, #0
0x003c34:	ldr     	r0, [pc, #0x3e0]
0x003c36:	str     	r1, [sp]
0x003c38:	str     	r1, [sp, #4]
0x003c3a:	str     	r2, [sp, #8]
0x003c3c:	add     	r0, sb
0x003c3e:	ldr     	r0, [r0, #0x18]
0x003c40:	ldr     	r2, [pc, #0x3d8]
0x003c42:	ldr     	r0, [r0]
0x003c44:	add     	r2, pc
0x003c46:	ldr     	r3, [r0, #4]
0x003c48:	movs    	r0, #0xf1
0x003c4a:	movs    	r1, #0x2d
0x003c4c:	lsls    	r0, r0, #9
0x003c4e:	bl      	#0x7214
0x003c52:	movs    	r2, #0
0x003c54:	movs    	r1, #0
0x003c56:	ldr     	r3, [pc, #0x3c8]
0x003c58:	str     	r1, [sp]
0x003c5a:	str     	r1, [sp, #4]
0x003c5c:	str     	r2, [sp, #8]
0x003c5e:	add     	r3, pc
0x003c60:	adds    	r2, r0, #0
0x003c62:	movs    	r0, #0xf1
0x003c64:	movs    	r1, #0x2d
0x003c66:	lsls    	r0, r0, #9
0x003c68:	bl      	#0x7214
0x003c6c:	str     	r0, [sp, #0x44]
0x003c6e:	add     	r1, sp, #0x4c
0x003c70:	str     	r1, [sp, #4]
0x003c72:	movs    	r0, #0
0x003c74:	str     	r0, [sp]
0x003c76:	add     	r2, sp, #0x48
0x003c78:	str     	r2, [sp, #8]
0x003c7a:	movs    	r0, #0xf1
0x003c7c:	movs    	r1, #0x2a
0x003c7e:	adds    	r3, r6, #0
0x003c80:	lsls    	r0, r0, #9
0x003c82:	ldr     	r2, [sp, #0x44]
0x003c84:	bl      	#0x7214
0x003c88:	ldr     	r0, [sp, #0x44]
0x003c8a:	movs    	r2, #0
0x003c8c:	str     	r0, [sp, #0x10]
0x003c8e:	ldr     	r0, [sp, #0x4c]
0x003c90:	str     	r6, [sp, #0x28]
0x003c92:	subs    	r0, r4, r0
0x003c94:	lsrs    	r1, r0, #0x1f
0x003c96:	adds    	r0, r1, r0
0x003c98:	asrs    	r0, r0, #1
0x003c9a:	str     	r0, [sp, #0x14]
0x003c9c:	movs    	r0, #0x1f
0x003c9e:	str     	r0, [sp, #0x18]
0x003ca0:	movs    	r0, #0xff
0x003ca2:	str     	r0, [sp, #0x20]
0x003ca4:	str     	r0, [sp, #0x24]
0x003ca6:	movs    	r1, #0
0x003ca8:	str     	r1, [sp]
0x003caa:	str     	r1, [sp, #4]
0x003cac:	str     	r0, [sp, #0x1c]
0x003cae:	movs    	r0, #0xf1
0x003cb0:	movs    	r1, #0x56
0x003cb2:	adds    	r3, r6, #0
0x003cb4:	str     	r2, [sp, #8]
0x003cb6:	add     	r2, sp, #0x10
0x003cb8:	lsls    	r0, r0, #9
0x003cba:	str     	r6, [sp, #0x2c]
0x003cbc:	bl      	#0x7214
0x003cc0:	movs    	r2, #0
0x003cc2:	str     	r2, [sp, #8]
0x003cc4:	movs    	r3, #0x32
0x003cc6:	str     	r4, [sp]
0x003cc8:	movs    	r1, #0x31
0x003cca:	movs    	r0, #0xf1
0x003ccc:	lsls    	r0, r0, #9
0x003cce:	ldr     	r2, [sp, #0x40]
0x003cd0:	str     	r5, [sp, #4]
0x003cd2:	bl      	#0x7214
0x003cd6:	movs    	r0, #0xa
0x003cd8:	str     	r0, [sp]
0x003cda:	movs    	r2, #0
0x003cdc:	ldr     	r0, [pc, #0x338]
0x003cde:	movs    	r1, #0x38
0x003ce0:	str     	r1, [sp, #4]
0x003ce2:	str     	r2, [sp, #8]
0x003ce4:	add     	r0, sb
0x003ce6:	ldr     	r0, [r0, #0x18]
0x003ce8:	ldr     	r2, [pc, #0x338]
0x003cea:	ldr     	r0, [r0]
0x003cec:	add     	r2, pc
0x003cee:	ldr     	r3, [r0, #0x18]
0x003cf0:	movs    	r0, #0xf1
0x003cf2:	movs    	r1, #0x3c
0x003cf4:	lsls    	r0, r0, #9
0x003cf6:	bl      	#0x7214
0x003cfa:	lsrs    	r0, r4, #0x1f
0x003cfc:	adds    	r0, r0, r4
0x003cfe:	asrs    	r0, r0, #1

; ===== candidate_004500 =====
0x004500:	push    	{r4, r5, r6, r7, lr}
0x004502:	sub     	sp, #0x6c
0x004504:	movs    	r0, #0
0x004506:	movs    	r1, #0x6e
0x004508:	str     	r1, [sp, #0x4c]
0x00450a:	movs    	r1, #0
0x00450c:	str     	r1, [sp, #4]
0x00450e:	str     	r0, [sp, #0x58]
0x004510:	str     	r0, [sp, #0x54]
0x004512:	str     	r0, [sp, #0x50]
0x004514:	str     	r0, [sp]
0x004516:	movs    	r2, #0
0x004518:	movs    	r0, #0xf1
0x00451a:	movs    	r1, #0x1c
0x00451c:	movs    	r7, #0x19
0x00451e:	movs    	r4, #0x19
0x004520:	movs    	r3, #0
0x004522:	lsls    	r0, r0, #9
0x004524:	str     	r2, [sp, #8]
0x004526:	bl      	#0x7214
0x00452a:	str     	r0, [sp, #0x40]
0x00452c:	movs    	r1, #0
0x00452e:	str     	r1, [sp]
0x004530:	str     	r1, [sp, #4]
0x004532:	movs    	r2, #0
0x004534:	movs    	r1, #0x1d
0x004536:	movs    	r0, #0xf1
0x004538:	movs    	r3, #0
0x00453a:	lsls    	r0, r0, #9
0x00453c:	str     	r2, [sp, #8]
0x00453e:	bl      	#0x7214
0x004542:	subs    	r6, r0, r4
0x004544:	movs    	r1, #0
0x004546:	ldr     	r0, [pc, #0x3e8]
0x004548:	str     	r1, [sp]
0x00454a:	str     	r1, [sp, #4]
0x00454c:	movs    	r2, #0
0x00454e:	str     	r2, [sp, #8]
0x004550:	add     	r0, sb
0x004552:	ldr     	r2, [r0, #0x24]
0x004554:	movs    	r0, #0xf1
0x004556:	movs    	r1, #0x11
0x004558:	movs    	r3, #4
0x00455a:	lsls    	r0, r0, #9
0x00455c:	bl      	#0x7214
0x004560:	adds    	r5, r0, #0
0x004562:	cmp     	r0, #0
0x004564:	ble     	#0x4634
0x004566:	ldr     	r0, [pc, #0x3c8]
0x004568:	subs    	r6, #0x6e
0x00456a:	add     	r0, sb
0x00456c:	ldr     	r2, [r0, #0x1c]
0x00456e:	str     	r6, [sp]
0x004570:	str     	r2, [sp, #8]
0x004572:	ldr     	r2, [sp, #0x40]
0x004574:	adds    	r3, r4, #0
0x004576:	subs    	r2, #0xc
0x004578:	movs    	r0, #0xf1
0x00457a:	movs    	r1, #0x3b
0x00457c:	lsls    	r0, r0, #9
0x00457e:	str     	r2, [sp, #0x68]
0x004580:	str     	r5, [sp, #4]
0x004582:	bl      	#0x7214
0x004586:	ldr     	r2, [sp, #0x68]
0x004588:	movs    	r1, #0
0x00458a:	str     	r2, [sp, #0x40]
0x00458c:	movs    	r2, #0
0x00458e:	str     	r2, [sp, #8]
0x004590:	str     	r1, [sp]
0x004592:	str     	r1, [sp, #4]
0x004594:	movs    	r1, #0xe1
0x004596:	movs    	r2, #0x2d
0x004598:	movs    	r3, #0
0x00459a:	movs    	r0, #0xf1
0x00459c:	lsls    	r0, r0, #9
0x00459e:	bl      	#0x7214
0x0045a2:	str     	r0, [sp, #0x60]
0x0045a4:	movs    	r1, #0
0x0045a6:	movs    	r2, #0
0x0045a8:	str     	r2, [sp, #8]
0x0045aa:	str     	r1, [sp]
0x0045ac:	str     	r1, [sp, #4]
0x0045ae:	movs    	r1, #0xe1
0x0045b0:	movs    	r2, #0x2e
0x0045b2:	movs    	r0, #0xf1
0x0045b4:	movs    	r3, #0
0x0045b6:	lsls    	r0, r0, #9
0x0045b8:	bl      	#0x7214
0x0045bc:	adds    	r1, r6, #0
0x0045be:	subs    	r1, #0xa
0x0045c0:	str     	r0, [sp, #0x5c]
0x0045c2:	adds    	r0, r7, #0
0x0045c4:	blx     	#0x20
0x0045c8:	adds    	r6, r0, #0
0x0045ca:	ldr     	r0, [pc, #0x364]
0x0045cc:	add     	r0, sb
0x0045ce:	ldr     	r1, [r0, #0x1c]
0x0045d0:	adds    	r0, r6, #0
0x0045d2:	blx     	#0x20
0x0045d6:	muls    	r0, r6, r0
0x0045d8:	adds    	r1, r0, r6
0x0045da:	cmp     	r1, r5
0x0045dc:	bge     	#0x45e0
0x0045de:	adds    	r5, r1, #0
0x0045e0:	str     	r5, [sp, #0x44]
0x0045e2:	ldr     	r1, [sp, #0x44]
0x0045e4:	adds    	r5, r0, #0
0x0045e6:	cmp     	r0, r1
0x0045e8:	bge     	#0x4634
0x0045ea:	ldr     	r1, [pc, #0x344]
0x0045ec:	lsls    	r0, r5, #2
0x0045ee:	add     	r1, sb
0x0045f0:	ldr     	r1, [r1, #0x24]
0x0045f2:	movs    	r2, #0
0x0045f4:	ldr     	r6, [r1, r0]
0x0045f6:	movs    	r0, #0xa
0x0045f8:	str     	r0, [sp, #0x48]
0x0045fa:	ldr     	r0, [sp, #0x40]
0x0045fc:	movs    	r1, #0x2f
0x0045fe:	str     	r0, [sp]
0x004600:	movs    	r0, #0xf1
0x004602:	adds    	r3, r4, #0
0x004604:	lsls    	r0, r0, #9
0x004606:	str     	r2, [sp, #8]
0x004608:	str     	r7, [sp, #4]
0x00460a:	bl      	#0x7214
0x00460e:	cmp     	r0, #1
0x004610:	bne     	#0x4664
0x004612:	ldr     	r1, [pc, #0x31c]
0x004614:	add     	r1, sb
0x004616:	ldr     	r0, [r1, #0x1c]
0x004618:	cmp     	r0, r5
0x00461a:	bne     	#0x4636
0x00461c:	ldr     	r1, [sp, #0x40]
0x00461e:	movs    	r3, #0
0x004620:	str     	r1, [sp, #4]
0x004622:	movs    	r1, #0x23
0x004624:	movs    	r2, #4
0x004626:	movs    	r0, #0xf1
0x004628:	lsls    	r0, r0, #9
0x00462a:	str     	r4, [sp]

; ===== candidate_004a70 =====
0x004a70:	push    	{r4, r5, r6, r7, lr}
0x004a72:	sub     	sp, #0x4c
0x004a74:	movs    	r1, #0
0x004a76:	str     	r1, [sp]
0x004a78:	str     	r1, [sp, #4]
0x004a7a:	movs    	r5, #0
0x004a7c:	movs    	r2, #0
0x004a7e:	adds    	r3, r5, #0
0x004a80:	movs    	r1, #0x1c
0x004a82:	movs    	r7, #0x19
0x004a84:	movs    	r4, #0x19
0x004a86:	movs    	r0, #0xf1
0x004a88:	lsls    	r0, r0, #9
0x004a8a:	str     	r2, [sp, #8]
0x004a8c:	bl      	#0x7214
0x004a90:	movs    	r1, #0
0x004a92:	str     	r1, [sp]
0x004a94:	str     	r1, [sp, #4]
0x004a96:	str     	r0, [sp, #0x30]
0x004a98:	movs    	r2, #0
0x004a9a:	movs    	r0, #0xf1
0x004a9c:	movs    	r1, #0x1d
0x004a9e:	adds    	r3, r5, #0
0x004aa0:	lsls    	r0, r0, #9
0x004aa2:	str     	r2, [sp, #8]
0x004aa4:	bl      	#0x7214
0x004aa8:	subs    	r6, r0, r4
0x004aaa:	ldr     	r0, [pc, #0x3b0]
0x004aac:	add     	r0, sb
0x004aae:	ldr     	r5, [r0, #0x28]
0x004ab0:	cmp     	r5, #0
0x004ab2:	beq     	#0x4b98
0x004ab4:	movs    	r1, #0
0x004ab6:	movs    	r2, #0
0x004ab8:	str     	r2, [sp, #8]
0x004aba:	str     	r1, [sp]
0x004abc:	str     	r1, [sp, #4]
0x004abe:	movs    	r1, #0x11
0x004ac0:	adds    	r2, r5, #0
0x004ac2:	movs    	r3, #4
0x004ac4:	movs    	r0, #0xf1
0x004ac6:	lsls    	r0, r0, #9
0x004ac8:	bl      	#0x7214
0x004acc:	adds    	r5, r0, #0
0x004ace:	cmp     	r0, #0
0x004ad0:	ble     	#0x4b98
0x004ad2:	ldr     	r1, [pc, #0x388]
0x004ad4:	movs    	r0, #0x19
0x004ad6:	add     	r1, sb
0x004ad8:	ldr     	r2, [r1, #0x74]
0x004ada:	ldr     	r1, [r1, #0x78]
0x004adc:	subs    	r6, #0x19
0x004ade:	adds    	r3, r6, r0
0x004ae0:	str     	r0, [sp]
0x004ae2:	str     	r2, [sp, #8]
0x004ae4:	str     	r1, [sp, #4]
0x004ae6:	movs    	r1, #0xb3
0x004ae8:	movs    	r2, #0
0x004aea:	movs    	r0, #0xf1
0x004aec:	lsls    	r0, r0, #9
0x004aee:	bl      	#0x7214
0x004af2:	ldr     	r1, [pc, #0x368]
0x004af4:	adds    	r3, r4, #0
0x004af6:	add     	r1, sb
0x004af8:	ldr     	r2, [r1, #0x64]
0x004afa:	movs    	r1, #0x3b
0x004afc:	str     	r2, [sp, #8]
0x004afe:	ldr     	r2, [sp, #0x30]
0x004b00:	movs    	r0, #0xf1
0x004b02:	subs    	r2, #0xc
0x004b04:	str     	r2, [sp, #0x48]
0x004b06:	lsls    	r0, r0, #9
0x004b08:	str     	r6, [sp]
0x004b0a:	str     	r5, [sp, #4]
0x004b0c:	bl      	#0x7214
0x004b10:	ldr     	r2, [sp, #0x48]
0x004b12:	movs    	r1, #0
0x004b14:	str     	r2, [sp, #0x30]
0x004b16:	movs    	r2, #0
0x004b18:	str     	r2, [sp, #8]
0x004b1a:	str     	r1, [sp]
0x004b1c:	str     	r1, [sp, #4]
0x004b1e:	movs    	r1, #0xe1
0x004b20:	movs    	r2, #0x2d
0x004b22:	movs    	r3, #0
0x004b24:	movs    	r0, #0xf1
0x004b26:	lsls    	r0, r0, #9
0x004b28:	bl      	#0x7214
0x004b2c:	str     	r0, [sp, #0x40]
0x004b2e:	movs    	r1, #0
0x004b30:	movs    	r2, #0
0x004b32:	str     	r2, [sp, #8]
0x004b34:	str     	r1, [sp]
0x004b36:	str     	r1, [sp, #4]
0x004b38:	movs    	r1, #0xe1
0x004b3a:	movs    	r2, #0x2e
0x004b3c:	movs    	r0, #0xf1
0x004b3e:	movs    	r3, #0
0x004b40:	lsls    	r0, r0, #9
0x004b42:	bl      	#0x7214
0x004b46:	adds    	r1, r6, #0
0x004b48:	subs    	r1, #0xa
0x004b4a:	str     	r0, [sp, #0x3c]
0x004b4c:	adds    	r0, r7, #0
0x004b4e:	blx     	#0x20
0x004b52:	adds    	r6, r0, #0
0x004b54:	ldr     	r0, [pc, #0x304]
0x004b56:	add     	r0, sb
0x004b58:	ldr     	r1, [r0, #0x64]
0x004b5a:	adds    	r0, r6, #0
0x004b5c:	blx     	#0x20
0x004b60:	muls    	r0, r6, r0
0x004b62:	adds    	r1, r0, r6
0x004b64:	cmp     	r1, r5
0x004b66:	bge     	#0x4b6a
0x004b68:	adds    	r5, r1, #0
0x004b6a:	str     	r5, [sp, #0x34]
0x004b6c:	ldr     	r1, [sp, #0x34]
0x004b6e:	adds    	r5, r0, #0
0x004b70:	cmp     	r0, r1
0x004b72:	bge     	#0x4c58
0x004b74:	ldr     	r1, [pc, #0x2e4]
0x004b76:	lsls    	r0, r5, #2
0x004b78:	add     	r1, sb
0x004b7a:	ldr     	r1, [r1, #0x28]
0x004b7c:	movs    	r2, #0
0x004b7e:	ldr     	r6, [r1, r0]
0x004b80:	ldr     	r0, [sp, #0x30]
0x004b82:	movs    	r1, #0x2f
0x004b84:	str     	r0, [sp]
0x004b86:	movs    	r0, #0xf1
0x004b88:	adds    	r3, r4, #0
0x004b8a:	lsls    	r0, r0, #9
0x004b8c:	str     	r7, [sp, #4]
0x004b8e:	str     	r2, [sp, #8]
0x004b90:	bl      	#0x7214
0x004b94:	cmp     	r0, #1
0x004b96:	b       	#0x4b9a
0x004b98:	b       	#0x4dae
0x004b9a:	bne     	#0x4bc0
0x004b9c:	ldr     	r1, [pc, #0x2bc]

; ===== candidate_004e70 =====
0x004e70:	push    	{r4, r5, lr}
0x004e72:	ldr     	r0, [pc, #0x58]
0x004e74:	sub     	sp, #0xc
0x004e76:	add     	r0, sb
0x004e78:	ldr     	r0, [r0, #0x18]
0x004e7a:	movs    	r1, #0
0x004e7c:	ldr     	r0, [r0]
0x004e7e:	movs    	r2, #0
0x004e80:	ldr     	r4, [r0]
0x004e82:	str     	r1, [sp]
0x004e84:	str     	r1, [sp, #4]
0x004e86:	str     	r2, [sp, #8]
0x004e88:	movs    	r5, #0
0x004e8a:	adds    	r3, r5, #0
0x004e8c:	movs    	r2, #0x12
0x004e8e:	movs    	r1, #0x9c
0x004e90:	movs    	r0, #0xf1
0x004e92:	lsls    	r0, r0, #9
0x004e94:	bl      	#0x7214
0x004e98:	movs    	r1, #0
0x004e9a:	str     	r1, [sp]
0x004e9c:	str     	r1, [sp, #4]
0x004e9e:	movs    	r2, #0
0x004ea0:	movs    	r1, #0x34
0x004ea2:	adds    	r3, r5, #0
0x004ea4:	movs    	r0, #0xf1
0x004ea6:	lsls    	r0, r0, #9
0x004ea8:	str     	r2, [sp, #8]
0x004eaa:	bl      	#0x7214
0x004eae:	movs    	r2, #0
0x004eb0:	movs    	r1, #0
0x004eb2:	str     	r2, [sp, #8]
0x004eb4:	movs    	r2, #0xff
0x004eb6:	str     	r1, [sp]
0x004eb8:	str     	r1, [sp, #4]
0x004eba:	adds    	r3, r4, #0
0x004ebc:	adds    	r2, #0x42
0x004ebe:	movs    	r1, #0x50
0x004ec0:	movs    	r0, #0xf1
0x004ec2:	lsls    	r0, r0, #9
0x004ec4:	bl      	#0x7214
0x004ec8:	add     	sp, #0xc
0x004eca:	pop     	{r4, r5, pc}

; ===== candidate_004ed0 =====
0x004ed0:	push    	{r4, r5, r6, r7, lr}
0x004ed2:	ldr     	r7, [pc, #0xb8]
0x004ed4:	movs    	r6, #0xf1
0x004ed6:	add     	r7, sb
0x004ed8:	ldr     	r4, [r7, #0x5c]
0x004eda:	lsls    	r6, r6, #9
0x004edc:	movs    	r5, #0
0x004ede:	cmp     	r4, #0
0x004ee0:	sub     	sp, #0xc
0x004ee2:	beq     	#0x4efc
0x004ee4:	movs    	r1, #0
0x004ee6:	movs    	r2, #0
0x004ee8:	str     	r2, [sp, #8]
0x004eea:	str     	r1, [sp]
0x004eec:	str     	r1, [sp, #4]
0x004eee:	movs    	r1, #0x12
0x004ef0:	adds    	r2, r4, #0
0x004ef2:	adds    	r3, r5, #0
0x004ef4:	adds    	r0, r6, #0
0x004ef6:	bl      	#0x7214
0x004efa:	str     	r5, [r7, #0x5c]
0x004efc:	ldr     	r4, [r7, #0x18]
0x004efe:	cmp     	r4, #0
0x004f00:	beq     	#0x4f36
0x004f02:	ldr     	r0, [r4]
0x004f04:	bl      	#0x7b40
0x004f08:	movs    	r1, #0
0x004f0a:	str     	r1, [sp]
0x004f0c:	str     	r1, [sp, #4]
0x004f0e:	movs    	r2, #0
0x004f10:	str     	r2, [sp, #8]
0x004f12:	movs    	r1, #9
0x004f14:	adds    	r3, r5, #0
0x004f16:	adds    	r0, r6, #0
0x004f18:	ldr     	r2, [r4, #0xc]
0x004f1a:	bl      	#0x7214
0x004f1e:	movs    	r1, #0
0x004f20:	movs    	r2, #0
0x004f22:	str     	r2, [sp, #8]
0x004f24:	str     	r1, [sp]
0x004f26:	str     	r1, [sp, #4]
0x004f28:	adds    	r3, r5, #0
0x004f2a:	adds    	r2, r4, #0
0x004f2c:	movs    	r1, #9
0x004f2e:	movs    	r0, #0xf1
0x004f30:	lsls    	r0, r0, #9
0x004f32:	bl      	#0x7214
0x004f36:	str     	r5, [r7, #0x18]
0x004f38:	bl      	#0x7a84
0x004f3c:	bl      	#0x7bbc
0x004f40:	movs    	r1, #0
0x004f42:	str     	r1, [sp]
0x004f44:	str     	r1, [sp, #4]
0x004f46:	movs    	r2, #0
0x004f48:	movs    	r1, #0x2c
0x004f4a:	adds    	r3, r5, #0
0x004f4c:	adds    	r0, r6, #0
0x004f4e:	str     	r2, [sp, #8]
0x004f50:	bl      	#0x7214
0x004f54:	movs    	r2, #0
0x004f56:	movs    	r1, #0
0x004f58:	str     	r2, [sp, #8]
0x004f5a:	movs    	r2, #0xff
0x004f5c:	str     	r1, [sp]
0x004f5e:	str     	r1, [sp, #4]
0x004f60:	adds    	r3, r5, #0
0x004f62:	adds    	r2, #0x1b
0x004f64:	movs    	r1, #0x14
0x004f66:	movs    	r0, #0xf1
0x004f68:	lsls    	r0, r0, #9
0x004f6a:	bl      	#0x7214
0x004f6e:	movs    	r1, #0
0x004f70:	movs    	r2, #0
0x004f72:	str     	r2, [sp, #8]
0x004f74:	str     	r1, [sp]
0x004f76:	str     	r1, [sp, #4]
0x004f78:	movs    	r1, #0xe1
0x004f7a:	movs    	r2, #0x17
0x004f7c:	adds    	r3, r5, #0
0x004f7e:	movs    	r0, #0xf1
0x004f80:	lsls    	r0, r0, #9
0x004f82:	bl      	#0x7214
0x004f86:	add     	sp, #0xc
0x004f88:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00501c =====
0x00501c:	push    	{lr}
0x00501e:	sub     	sp, #0xc
0x005020:	movs    	r1, #0
0x005022:	movs    	r2, #0
0x005024:	str     	r2, [sp, #8]
0x005026:	str     	r1, [sp]
0x005028:	str     	r1, [sp, #4]
0x00502a:	movs    	r1, #0xe1
0x00502c:	movs    	r2, #0x15
0x00502e:	movs    	r3, #0
0x005030:	movs    	r0, #0xf1
0x005032:	lsls    	r0, r0, #9
0x005034:	bl      	#0x7214
0x005038:	subs    	r0, #0x32
0x00503a:	blx     	#0x2e8
0x00503e:	adds    	r0, r1, #0
0x005040:	add     	sp, #0xc
0x005042:	pop     	{pc}

; ===== candidate_005044 =====
0x005044:	push    	{lr}
0x005046:	sub     	sp, #0xc
0x005048:	movs    	r1, #0
0x00504a:	movs    	r2, #0
0x00504c:	str     	r2, [sp, #8]
0x00504e:	str     	r1, [sp]
0x005050:	str     	r1, [sp, #4]
0x005052:	movs    	r1, #0xe1
0x005054:	movs    	r2, #0x15
0x005056:	movs    	r3, #0
0x005058:	movs    	r0, #0xf1
0x00505a:	lsls    	r0, r0, #9
0x00505c:	bl      	#0x7214
0x005060:	subs    	r0, #0x78
0x005062:	blx     	#0x2e8
0x005066:	adds    	r0, r1, #0
0x005068:	add     	sp, #0xc
0x00506a:	pop     	{pc}

; ===== candidate_00506c =====
0x00506c:	push    	{r4, lr}
0x00506e:	movs    	r4, #0xf1
0x005070:	lsls    	r4, r4, #9
0x005072:	adds    	r3, r0, #0
0x005074:	cmp     	r0, #0
0x005076:	sub     	sp, #0x10
0x005078:	bne     	#0x5090
0x00507a:	movs    	r1, #0
0x00507c:	str     	r1, [sp]
0x00507e:	str     	r1, [sp, #4]
0x005080:	movs    	r2, #0
0x005082:	movs    	r1, #0x34
0x005084:	movs    	r3, #0
0x005086:	adds    	r0, r4, #0
0x005088:	str     	r2, [sp, #8]
0x00508a:	bl      	#0x7214
0x00508e:	b       	#0x50a4
0x005090:	movs    	r1, #0
0x005092:	movs    	r2, #0
0x005094:	str     	r2, [sp, #8]
0x005096:	str     	r1, [sp]
0x005098:	str     	r1, [sp, #4]
0x00509a:	movs    	r1, #0x14
0x00509c:	movs    	r2, #0x74
0x00509e:	adds    	r0, r4, #0
0x0050a0:	bl      	#0x7214
0x0050a4:	movs    	r1, #0
0x0050a6:	str     	r1, [sp, #4]
0x0050a8:	movs    	r2, #0
0x0050aa:	movs    	r0, #0x10
0x0050ac:	str     	r0, [sp]
0x0050ae:	movs    	r1, #0x53
0x0050b0:	movs    	r3, #6
0x0050b2:	adds    	r0, r4, #0
0x0050b4:	str     	r2, [sp, #8]
0x0050b6:	bl      	#0x7214
0x0050ba:	add     	sp, #0x10
0x0050bc:	pop     	{r4, pc}

; ===== candidate_0050c0 =====
0x0050c0:	push    	{r4, r5, r6, lr}
0x0050c2:	sub     	sp, #0x10
0x0050c4:	movs    	r1, #0
0x0050c6:	movs    	r2, #0
0x0050c8:	str     	r2, [sp, #8]
0x0050ca:	str     	r1, [sp]
0x0050cc:	str     	r1, [sp, #4]
0x0050ce:	movs    	r6, #0xf1
0x0050d0:	movs    	r5, #0
0x0050d2:	adds    	r3, r5, #0
0x0050d4:	lsls    	r6, r6, #9
0x0050d6:	movs    	r1, #0xe1
0x0050d8:	movs    	r2, #0xe3
0x0050da:	adds    	r0, r6, #0
0x0050dc:	bl      	#0x7214
0x0050e0:	adds    	r4, r0, #0
0x0050e2:	beq     	#0x50f6
0x0050e4:	ldr     	r1, [pc, #0x10c]
0x0050e6:	add     	r1, pc
0x0050e8:	ldr     	r2, [pc, #0x10c]
0x0050ea:	adds    	r0, r4, #0
0x0050ec:	add     	r2, sb
0x0050ee:	ldr     	r2, [r2]
0x0050f0:	blx     	r2
0x0050f2:	cmp     	r0, #0
0x0050f4:	bne     	#0x512a
0x0050f6:	movs    	r1, #0
0x0050f8:	movs    	r2, #0
0x0050fa:	str     	r2, [sp, #8]
0x0050fc:	str     	r1, [sp]
0x0050fe:	str     	r1, [sp, #4]
0x005100:	movs    	r1, #0x14
0x005102:	movs    	r2, #0xe3
0x005104:	adds    	r3, r5, #0
0x005106:	adds    	r0, r6, #0
0x005108:	bl      	#0x7214
0x00510c:	movs    	r2, #0
0x00510e:	movs    	r1, #0
0x005110:	str     	r2, [sp, #8]
0x005112:	ldr     	r2, [pc, #0xe8]
0x005114:	str     	r1, [sp]
0x005116:	str     	r1, [sp, #4]
0x005118:	adds    	r3, r5, #0
0x00511a:	add     	r2, pc
0x00511c:	movs    	r1, #0x33
0x00511e:	movs    	r0, #0xf1
0x005120:	lsls    	r0, r0, #9
0x005122:	bl      	#0x7214
0x005126:	add     	sp, #0x10
0x005128:	pop     	{r4, r5, r6, pc}

; ===== candidate_005206 =====
0x005206:	push    	{lr}
0x005208:	sub     	sp, #0xc
0x00520a:	movs    	r3, #0
0x00520c:	add     	r0, sb
0x00520e:	str     	r3, [r0, #0x2c]
0x005210:	str     	r3, [r0, #0x30]
0x005212:	str     	r3, [r0, #0x34]
0x005214:	str     	r3, [r0, #0x38]
0x005216:	str     	r3, [r0, #0x3c]
0x005218:	str     	r3, [r0, #0x44]
0x00521a:	str     	r3, [r0, #0x40]
0x00521c:	movs    	r1, #0
0x00521e:	str     	r1, [sp]
0x005220:	str     	r1, [sp, #4]
0x005222:	movs    	r2, #0
0x005224:	movs    	r1, #0x34
0x005226:	movs    	r0, #0xf1
0x005228:	lsls    	r0, r0, #9
0x00522a:	str     	r2, [sp, #8]
0x00522c:	bl      	#0x7214
0x005230:	movs    	r1, #0
0x005232:	movs    	r2, #0
0x005234:	str     	r2, [sp, #8]
0x005236:	str     	r1, [sp]
0x005238:	str     	r1, [sp, #4]
0x00523a:	movs    	r3, #0xff
0x00523c:	adds    	r3, #0x2b
0x00523e:	movs    	r1, #0x14
0x005240:	movs    	r2, #0x17
0x005242:	movs    	r0, #0xf1
0x005244:	lsls    	r0, r0, #9
0x005246:	bl      	#0x7214
0x00524a:	add     	sp, #0xc
0x00524c:	pop     	{pc}

; ===== candidate_005254 =====
0x005254:	push    	{r4, r5, r6, r7, lr}
0x005256:	sub     	sp, #0xc
0x005258:	movs    	r1, #0
0x00525a:	str     	r1, [sp]
0x00525c:	str     	r1, [sp, #4]
0x00525e:	movs    	r5, #0xf1
0x005260:	movs    	r6, #0
0x005262:	movs    	r2, #0
0x005264:	adds    	r3, r6, #0
0x005266:	lsls    	r5, r5, #9
0x005268:	movs    	r1, #0x13
0x00526a:	adds    	r0, r5, #0
0x00526c:	str     	r2, [sp, #8]
0x00526e:	bl      	#0x7214
0x005272:	ldr     	r2, [pc, #0x370]
0x005274:	movs    	r1, #0
0x005276:	add     	r2, sb
0x005278:	str     	r6, [r2, #0x68]
0x00527a:	movs    	r2, #0
0x00527c:	str     	r2, [sp, #8]
0x00527e:	movs    	r2, #0xff
0x005280:	str     	r1, [sp]
0x005282:	str     	r1, [sp, #4]
0x005284:	movs    	r1, #0xe1
0x005286:	adds    	r2, #0x1b
0x005288:	adds    	r4, r0, #0
0x00528a:	adds    	r3, r6, #0
0x00528c:	adds    	r0, r5, #0
0x00528e:	bl      	#0x7214
0x005292:	ldr     	r6, [pc, #0x354]
0x005294:	add     	r6, pc
0x005296:	cmp     	r0, #0
0x005298:	bne     	#0x537e
0x00529a:	movs    	r1, #0
0x00529c:	movs    	r2, #0
0x00529e:	str     	r2, [sp, #8]
0x0052a0:	str     	r1, [sp]
0x0052a2:	str     	r1, [sp, #4]
0x0052a4:	movs    	r7, #0
0x0052a6:	adds    	r3, r7, #0
0x0052a8:	movs    	r1, #0xe1
0x0052aa:	movs    	r2, #0xe4
0x0052ac:	adds    	r0, r5, #0
0x0052ae:	bl      	#0x7214
0x0052b2:	adds    	r3, r0, #1
0x0052b4:	bne     	#0x52e4
0x0052b6:	movs    	r2, #0
0x0052b8:	movs    	r1, #0
0x0052ba:	str     	r2, [sp, #8]
0x0052bc:	adds    	r2, r6, #0
0x0052be:	str     	r1, [sp]
0x0052c0:	str     	r1, [sp, #4]
0x0052c2:	movs    	r1, #0x35
0x0052c4:	subs    	r2, #0x64
0x0052c6:	adds    	r3, r6, #0
0x0052c8:	adds    	r0, r5, #0
0x0052ca:	bl      	#0x7214
0x0052ce:	movs    	r1, #0
0x0052d0:	movs    	r2, #0
0x0052d2:	str     	r2, [sp, #8]
0x0052d4:	str     	r1, [sp]
0x0052d6:	str     	r1, [sp, #4]
0x0052d8:	movs    	r1, #0x36
0x0052da:	adds    	r2, r4, #0
0x0052dc:	adds    	r3, r0, #0
0x0052de:	adds    	r0, r5, #0
0x0052e0:	bl      	#0x7214
0x0052e4:	movs    	r2, #0
0x0052e6:	movs    	r1, #0
0x0052e8:	str     	r2, [sp, #8]
0x0052ea:	ldr     	r2, [pc, #0x300]
0x0052ec:	str     	r1, [sp]
0x0052ee:	str     	r1, [sp, #4]
0x0052f0:	adds    	r3, r6, #0
0x0052f2:	add     	r2, pc
0x0052f4:	movs    	r1, #0x35
0x0052f6:	adds    	r0, r5, #0
0x0052f8:	bl      	#0x7214
0x0052fc:	movs    	r1, #0
0x0052fe:	adds    	r3, r0, #0
0x005300:	movs    	r2, #0
0x005302:	str     	r2, [sp, #8]
0x005304:	str     	r1, [sp]
0x005306:	str     	r1, [sp, #4]
0x005308:	movs    	r1, #0x36
0x00530a:	adds    	r2, r4, #0
0x00530c:	movs    	r0, #0xf1
0x00530e:	lsls    	r0, r0, #9
0x005310:	bl      	#0x7214
0x005314:	movs    	r1, #0
0x005316:	movs    	r2, #0
0x005318:	str     	r2, [sp, #8]
0x00531a:	str     	r1, [sp]
0x00531c:	str     	r1, [sp, #4]
0x00531e:	movs    	r1, #0xe1
0x005320:	movs    	r2, #0xe4
0x005322:	adds    	r3, r7, #0
0x005324:	movs    	r0, #0xf1
0x005326:	lsls    	r0, r0, #9
0x005328:	bl      	#0x7214
0x00532c:	ldr     	r2, [pc, #0x2b4]
0x00532e:	add     	r2, sb
0x005330:	ldr     	r1, [r2, #0x18]
0x005332:	ldr     	r1, [r1]
0x005334:	ldr     	r1, [r1]
0x005336:	cmp     	r0, r1
0x005338:	bne     	#0x541e
0x00533a:	movs    	r2, #0
0x00533c:	movs    	r1, #0
0x00533e:	str     	r2, [sp, #8]
0x005340:	ldr     	r2, [pc, #0x2ac]
0x005342:	str     	r1, [sp]
0x005344:	str     	r1, [sp, #4]
0x005346:	adds    	r3, r6, #0
0x005348:	add     	r2, pc
0x00534a:	movs    	r1, #0x35
0x00534c:	adds    	r0, r5, #0
0x00534e:	bl      	#0x7214
0x005352:	movs    	r1, #0
0x005354:	adds    	r3, r0, #0
0x005356:	movs    	r2, #0
0x005358:	str     	r2, [sp, #8]
0x00535a:	str     	r1, [sp]
0x00535c:	str     	r1, [sp, #4]
0x00535e:	movs    	r1, #0x36
0x005360:	adds    	r2, r4, #0
0x005362:	movs    	r0, #0xf1
0x005364:	lsls    	r0, r0, #9
0x005366:	bl      	#0x7214
0x00536a:	movs    	r2, #0
0x00536c:	movs    	r1, #0
0x00536e:	str     	r2, [sp, #8]
0x005370:	ldr     	r2, [pc, #0x280]
0x005372:	str     	r1, [sp]
0x005374:	str     	r1, [sp, #4]
0x005376:	adds    	r3, r6, #0
0x005378:	add     	r2, pc
0x00537a:	movs    	r1, #0x35
0x00537c:	b       	#0x5380
0x00537e:	b       	#0x54ba
0x005380:	movs    	r0, #0xf1

; ===== candidate_00560c =====
0x00560c:	push    	{r4, r5, r6, r7, lr}
0x00560e:	sub     	sp, #0xc
0x005610:	movs    	r1, #0
0x005612:	str     	r1, [sp]
0x005614:	str     	r1, [sp, #4]
0x005616:	movs    	r5, #0xf1
0x005618:	movs    	r6, #0
0x00561a:	movs    	r2, #0
0x00561c:	adds    	r3, r6, #0
0x00561e:	lsls    	r5, r5, #9
0x005620:	movs    	r1, #0x13
0x005622:	adds    	r0, r5, #0
0x005624:	str     	r2, [sp, #8]
0x005626:	bl      	#0x7214
0x00562a:	ldr     	r7, [pc, #0x200]
0x00562c:	movs    	r1, #0
0x00562e:	add     	r7, sb
0x005630:	str     	r6, [r7, #0x68]
0x005632:	movs    	r2, #0
0x005634:	str     	r2, [sp, #8]
0x005636:	str     	r1, [sp]
0x005638:	str     	r1, [sp, #4]
0x00563a:	movs    	r1, #0xe1
0x00563c:	movs    	r2, #0xe4
0x00563e:	adds    	r4, r0, #0
0x005640:	adds    	r3, r6, #0
0x005642:	adds    	r0, r5, #0
0x005644:	bl      	#0x7214
0x005648:	ldr     	r1, [r7, #0x18]
0x00564a:	ldr     	r1, [r1]
0x00564c:	ldr     	r1, [r1]
0x00564e:	cmp     	r0, r1
0x005650:	bne     	#0x5736
0x005652:	adds    	r2, r7, #0
0x005654:	ldr     	r0, [r2, #0x1c]
0x005656:	ldr     	r1, [r2, #0x24]
0x005658:	lsls    	r0, r0, #2
0x00565a:	ldr     	r7, [r1, r0]
0x00565c:	movs    	r1, #0
0x00565e:	movs    	r2, #0
0x005660:	str     	r2, [sp, #8]
0x005662:	str     	r1, [sp]
0x005664:	str     	r1, [sp, #4]
0x005666:	movs    	r1, #0xe1
0x005668:	movs    	r2, #0xe5
0x00566a:	adds    	r3, r6, #0
0x00566c:	adds    	r0, r5, #0
0x00566e:	bl      	#0x7214
0x005672:	cmp     	r0, #0
0x005674:	beq     	#0x56aa
0x005676:	movs    	r1, #0
0x005678:	movs    	r2, #0
0x00567a:	str     	r2, [sp, #8]
0x00567c:	str     	r1, [sp]
0x00567e:	str     	r1, [sp, #4]
0x005680:	movs    	r1, #0xe1
0x005682:	movs    	r2, #0xe5
0x005684:	adds    	r3, r6, #0
0x005686:	adds    	r0, r5, #0
0x005688:	bl      	#0x7214
0x00568c:	cmp     	r0, #1
0x00568e:	beq     	#0x56aa
0x005690:	movs    	r1, #0
0x005692:	movs    	r2, #0
0x005694:	str     	r2, [sp, #8]
0x005696:	str     	r1, [sp]
0x005698:	str     	r1, [sp, #4]
0x00569a:	movs    	r1, #0xe1
0x00569c:	movs    	r2, #0xe5
0x00569e:	adds    	r3, r6, #0
0x0056a0:	adds    	r0, r5, #0
0x0056a2:	bl      	#0x7214
0x0056a6:	cmp     	r0, #2
0x0056a8:	bne     	#0x5736
0x0056aa:	movs    	r1, #0
0x0056ac:	movs    	r2, #0
0x0056ae:	str     	r2, [sp, #8]
0x0056b0:	str     	r1, [sp]
0x0056b2:	str     	r1, [sp, #4]
0x0056b4:	movs    	r1, #0xe1
0x0056b6:	movs    	r2, #0xe5
0x0056b8:	adds    	r3, r6, #0
0x0056ba:	adds    	r0, r5, #0
0x0056bc:	bl      	#0x7214
0x0056c0:	cmp     	r0, #0
0x0056c2:	beq     	#0x56de
0x0056c4:	movs    	r1, #0
0x0056c6:	movs    	r2, #0
0x0056c8:	str     	r2, [sp, #8]
0x0056ca:	str     	r1, [sp]
0x0056cc:	str     	r1, [sp, #4]
0x0056ce:	movs    	r1, #0xe1
0x0056d0:	movs    	r2, #0xe5
0x0056d2:	adds    	r3, r6, #0
0x0056d4:	adds    	r0, r5, #0
0x0056d6:	bl      	#0x7214
0x0056da:	cmp     	r0, #1
0x0056dc:	bne     	#0x5710
0x0056de:	movs    	r2, #0
0x0056e0:	movs    	r1, #0
0x0056e2:	ldr     	r3, [pc, #0x14c]
0x0056e4:	str     	r1, [sp]
0x0056e6:	str     	r1, [sp, #4]
0x0056e8:	str     	r2, [sp, #8]
0x0056ea:	add     	r3, pc
0x0056ec:	adds    	r2, r3, #0
0x0056ee:	adds    	r2, #0x34
0x0056f0:	movs    	r1, #0x35
0x0056f2:	adds    	r0, r5, #0
0x0056f4:	bl      	#0x7214
0x0056f8:	movs    	r1, #0
0x0056fa:	adds    	r3, r0, #0
0x0056fc:	movs    	r2, #0
0x0056fe:	str     	r2, [sp, #8]
0x005700:	str     	r1, [sp]
0x005702:	str     	r1, [sp, #4]
0x005704:	movs    	r1, #0x36
0x005706:	adds    	r2, r4, #0
0x005708:	movs    	r0, #0xf1
0x00570a:	lsls    	r0, r0, #9
0x00570c:	bl      	#0x7214
0x005710:	ldr     	r0, [r7, #0x14]
0x005712:	cmp     	r0, #0
0x005714:	bne     	#0x5736
0x005716:	movs    	r2, #0
0x005718:	movs    	r1, #0
0x00571a:	ldr     	r3, [pc, #0x118]
0x00571c:	str     	r1, [sp]
0x00571e:	str     	r1, [sp, #4]
0x005720:	str     	r2, [sp, #8]
0x005722:	add     	r3, pc
0x005724:	adds    	r2, r3, #0
0x005726:	adds    	r2, #0x40
0x005728:	movs    	r1, #0x35
0x00572a:	adds    	r0, r5, #0
0x00572c:	bl      	#0x7214
0x005730:	adds    	r3, r0, #0
0x005732:	movs    	r2, #0
0x005734:	b       	#0x5738
0x005736:	b       	#0x574c
0x005738:	movs    	r1, #0

; ===== candidate_005838 =====
0x005838:	push    	{r4, r5, r6, r7, lr}
0x00583a:	ldr     	r6, [pc, #0x2d0]
0x00583c:	sub     	sp, #0xc
0x00583e:	add     	r6, sb
0x005840:	ldr     	r0, [r6, #0x64]
0x005842:	ldr     	r1, [r6, #0x28]
0x005844:	lsls    	r0, r0, #2
0x005846:	ldr     	r4, [r1, r0]
0x005848:	movs    	r1, #0
0x00584a:	movs    	r2, #0
0x00584c:	str     	r2, [sp, #8]
0x00584e:	str     	r1, [sp]
0x005850:	str     	r1, [sp, #4]
0x005852:	movs    	r7, #0xf1
0x005854:	movs    	r5, #0
0x005856:	adds    	r3, r5, #0
0x005858:	lsls    	r7, r7, #9
0x00585a:	movs    	r1, #0xe1
0x00585c:	movs    	r2, #0x18
0x00585e:	adds    	r0, r7, #0
0x005860:	bl      	#0x7214
0x005864:	ldr     	r0, [r0, #0xc]
0x005866:	ldr     	r1, [r4, #4]
0x005868:	cmp     	r0, r1
0x00586a:	bne     	#0x5888
0x00586c:	movs    	r2, #0
0x00586e:	movs    	r1, #0
0x005870:	str     	r2, [sp, #8]
0x005872:	ldr     	r2, [pc, #0x29c]
0x005874:	str     	r1, [sp]
0x005876:	str     	r1, [sp, #4]
0x005878:	adds    	r3, r5, #0
0x00587a:	add     	r2, pc
0x00587c:	movs    	r1, #0x33
0x00587e:	adds    	r0, r7, #0
0x005880:	bl      	#0x7214
0x005884:	add     	sp, #0xc
0x005886:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_005b2a =====
0x005b2a:	push    	{lr}
0x005b2c:	sub     	sp, #0xc
0x005b2e:	add     	r1, sb
0x005b30:	str     	r0, [r1, #0x70]
0x005b32:	movs    	r1, #0
0x005b34:	str     	r1, [sp]
0x005b36:	str     	r1, [sp, #4]
0x005b38:	movs    	r2, #0
0x005b3a:	movs    	r1, #0x34
0x005b3c:	movs    	r0, #0xf1
0x005b3e:	movs    	r3, #0
0x005b40:	lsls    	r0, r0, #9
0x005b42:	str     	r2, [sp, #8]
0x005b44:	bl      	#0x7214
0x005b48:	movs    	r1, #0
0x005b4a:	movs    	r2, #0
0x005b4c:	str     	r2, [sp, #8]
0x005b4e:	str     	r1, [sp]
0x005b50:	str     	r1, [sp, #4]
0x005b52:	movs    	r3, #0xff
0x005b54:	adds    	r3, #0x32
0x005b56:	movs    	r1, #0x14
0x005b58:	movs    	r2, #0x17
0x005b5a:	movs    	r0, #0xf1
0x005b5c:	lsls    	r0, r0, #9
0x005b5e:	bl      	#0x7214
0x005b62:	add     	sp, #0xc
0x005b64:	pop     	{pc}

; ===== candidate_005b6c =====
0x005b6c:	push    	{r4, r5, r6, r7, lr}
0x005b6e:	sub     	sp, #0xc
0x005b70:	movs    	r1, #0
0x005b72:	str     	r1, [sp]
0x005b74:	str     	r1, [sp, #4]
0x005b76:	movs    	r7, #0xf1
0x005b78:	movs    	r4, #0
0x005b7a:	movs    	r2, #0
0x005b7c:	adds    	r3, r4, #0
0x005b7e:	lsls    	r7, r7, #9
0x005b80:	movs    	r1, #0x13
0x005b82:	adds    	r0, r7, #0
0x005b84:	str     	r2, [sp, #8]
0x005b86:	bl      	#0x7214
0x005b8a:	ldr     	r2, [pc, #0x144]
0x005b8c:	adds    	r5, r0, #0
0x005b8e:	add     	r2, sb
0x005b90:	str     	r4, [r2, #0x68]
0x005b92:	movs    	r2, #0
0x005b94:	movs    	r1, #0
0x005b96:	ldr     	r6, [pc, #0x13c]
0x005b98:	str     	r1, [sp]
0x005b9a:	str     	r1, [sp, #4]
0x005b9c:	str     	r2, [sp, #8]
0x005b9e:	add     	r6, pc
0x005ba0:	ldr     	r2, [pc, #0x134]
0x005ba2:	adds    	r3, r6, #0
0x005ba4:	add     	r2, pc
0x005ba6:	movs    	r1, #0x35
0x005ba8:	adds    	r0, r7, #0
0x005baa:	bl      	#0x7214
0x005bae:	movs    	r1, #0
0x005bb0:	movs    	r2, #0
0x005bb2:	str     	r2, [sp, #8]
0x005bb4:	str     	r1, [sp]
0x005bb6:	str     	r1, [sp, #4]
0x005bb8:	movs    	r1, #0x36
0x005bba:	adds    	r2, r5, #0
0x005bbc:	adds    	r3, r0, #0
0x005bbe:	adds    	r0, r7, #0
0x005bc0:	bl      	#0x7214
0x005bc4:	movs    	r2, #0
0x005bc6:	movs    	r1, #0
0x005bc8:	str     	r2, [sp, #8]
0x005bca:	ldr     	r2, [pc, #0x110]
0x005bcc:	str     	r1, [sp]
0x005bce:	str     	r1, [sp, #4]
0x005bd0:	adds    	r3, r6, #0
0x005bd2:	add     	r2, pc
0x005bd4:	movs    	r1, #0x35
0x005bd6:	adds    	r0, r7, #0
0x005bd8:	bl      	#0x7214
0x005bdc:	movs    	r1, #0
0x005bde:	movs    	r2, #0
0x005be0:	str     	r2, [sp, #8]
0x005be2:	str     	r1, [sp]
0x005be4:	str     	r1, [sp, #4]
0x005be6:	movs    	r1, #0x36
0x005be8:	adds    	r2, r5, #0
0x005bea:	adds    	r3, r0, #0
0x005bec:	adds    	r0, r7, #0
0x005bee:	bl      	#0x7214
0x005bf2:	movs    	r1, #0
0x005bf4:	movs    	r2, #0
0x005bf6:	str     	r2, [sp, #8]
0x005bf8:	str     	r1, [sp]
0x005bfa:	str     	r1, [sp, #4]
0x005bfc:	movs    	r1, #0x26
0x005bfe:	adds    	r2, r5, #0
0x005c00:	adds    	r3, r4, #0
0x005c02:	adds    	r0, r7, #0
0x005c04:	bl      	#0x7214
0x005c08:	adds    	r6, r0, #0
0x005c0a:	bne     	#0x5c26
0x005c0c:	movs    	r1, #0
0x005c0e:	movs    	r2, #0
0x005c10:	str     	r2, [sp, #8]
0x005c12:	str     	r1, [sp]
0x005c14:	str     	r1, [sp, #4]
0x005c16:	movs    	r1, #9
0x005c18:	adds    	r2, r5, #0
0x005c1a:	movs    	r3, #0
0x005c1c:	adds    	r0, r7, #0
0x005c1e:	bl      	#0x7214
0x005c22:	add     	sp, #0xc
0x005c24:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_005ce0 =====
0x005ce0:	push    	{r4, lr}
0x005ce2:	sub     	sp, #0x10
0x005ce4:	movs    	r1, #0
0x005ce6:	str     	r1, [sp]
0x005ce8:	str     	r1, [sp, #4]
0x005cea:	movs    	r4, #0
0x005cec:	movs    	r2, #0
0x005cee:	adds    	r3, r4, #0
0x005cf0:	movs    	r1, #0x34
0x005cf2:	movs    	r0, #0xf1
0x005cf4:	lsls    	r0, r0, #9
0x005cf6:	str     	r2, [sp, #8]
0x005cf8:	bl      	#0x7214
0x005cfc:	ldr     	r0, [pc, #0x44]
0x005cfe:	mvns    	r1, r4
0x005d00:	add     	r0, sb
0x005d02:	str     	r4, [r0, #0x58]
0x005d04:	str     	r4, [r0, #0x1c]
0x005d06:	str     	r4, [r0, #0x5c]
0x005d08:	str     	r4, [r0, #0x28]
0x005d0a:	str     	r4, [r0, #0x60]
0x005d0c:	str     	r1, [r0, #0x74]
0x005d0e:	str     	r4, [r0, #0x24]
0x005d10:	movs    	r1, #0
0x005d12:	str     	r1, [sp]
0x005d14:	str     	r1, [sp, #4]
0x005d16:	movs    	r2, #0
0x005d18:	movs    	r1, #0xba
0x005d1a:	movs    	r0, #0xf1
0x005d1c:	adds    	r3, r4, #0
0x005d1e:	lsls    	r0, r0, #9
0x005d20:	str     	r2, [sp, #8]
0x005d22:	bl      	#0x7214
0x005d26:	movs    	r1, #0
0x005d28:	movs    	r2, #0
0x005d2a:	str     	r2, [sp, #8]
0x005d2c:	str     	r1, [sp]
0x005d2e:	str     	r1, [sp, #4]
0x005d30:	movs    	r3, #0xff
0x005d32:	adds    	r3, #0x25
0x005d34:	movs    	r1, #0x14
0x005d36:	movs    	r2, #0x17
0x005d38:	movs    	r0, #0xf1
0x005d3a:	lsls    	r0, r0, #9
0x005d3c:	bl      	#0x7214
0x005d40:	add     	sp, #0x10
0x005d42:	pop     	{r4, pc}

; ===== candidate_005d48 =====
0x005d48:	push    	{r4, r5, lr}
0x005d4a:	sub     	sp, #0xc
0x005d4c:	movs    	r1, #0
0x005d4e:	movs    	r2, #0
0x005d50:	str     	r2, [sp, #8]
0x005d52:	str     	r1, [sp]
0x005d54:	str     	r1, [sp, #4]
0x005d56:	movs    	r4, #0xf1
0x005d58:	movs    	r5, #0
0x005d5a:	adds    	r3, r5, #0
0x005d5c:	lsls    	r4, r4, #9
0x005d5e:	movs    	r1, #0xe1
0x005d60:	movs    	r2, #0x17
0x005d62:	adds    	r0, r4, #0
0x005d64:	bl      	#0x7214
0x005d68:	subs    	r0, #0xff
0x005d6a:	subs    	r0, #0x26
0x005d6c:	beq     	#0x5d82
0x005d6e:	movs    	r1, #0
0x005d70:	str     	r1, [sp]
0x005d72:	str     	r1, [sp, #4]
0x005d74:	movs    	r2, #0
0x005d76:	movs    	r1, #0x34
0x005d78:	adds    	r3, r5, #0
0x005d7a:	adds    	r0, r4, #0
0x005d7c:	str     	r2, [sp, #8]
0x005d7e:	bl      	#0x7214
0x005d82:	movs    	r1, #0
0x005d84:	movs    	r2, #0
0x005d86:	str     	r2, [sp, #8]
0x005d88:	str     	r1, [sp]
0x005d8a:	str     	r1, [sp, #4]
0x005d8c:	movs    	r3, #0xff
0x005d8e:	adds    	r3, #0x26
0x005d90:	movs    	r1, #0x14
0x005d92:	movs    	r2, #0x17
0x005d94:	adds    	r0, r4, #0
0x005d96:	bl      	#0x7214
0x005d9a:	add     	sp, #0xc
0x005d9c:	pop     	{r4, r5, pc}

; ===== candidate_005da0 =====
0x005da0:	push    	{r4, r5, r6, r7, lr}
0x005da2:	ldr     	r7, [pc, #0x84]
0x005da4:	movs    	r5, #0
0x005da6:	sub     	sp, #0xc
0x005da8:	add     	r7, sb
0x005daa:	str     	r5, [r7, #0x50]
0x005dac:	movs    	r1, #0
0x005dae:	movs    	r2, #0
0x005db0:	str     	r2, [sp, #8]
0x005db2:	str     	r1, [sp]
0x005db4:	str     	r1, [sp, #4]
0x005db6:	movs    	r6, #0xf1
0x005db8:	lsls    	r6, r6, #9
0x005dba:	movs    	r1, #0xe1
0x005dbc:	movs    	r2, #0x74
0x005dbe:	adds    	r3, r5, #0
0x005dc0:	adds    	r4, r0, #0
0x005dc2:	adds    	r0, r6, #0
0x005dc4:	bl      	#0x7214
0x005dc8:	str     	r0, [r7, #0x20]
0x005dca:	movs    	r1, #0
0x005dcc:	movs    	r2, #0
0x005dce:	str     	r2, [sp, #8]
0x005dd0:	str     	r1, [sp]
0x005dd2:	str     	r1, [sp, #4]
0x005dd4:	movs    	r1, #0xe1
0x005dd6:	movs    	r2, #0x17
0x005dd8:	adds    	r3, r5, #0
0x005dda:	adds    	r0, r6, #0
0x005ddc:	bl      	#0x7214
0x005de0:	cmp     	r0, r4
0x005de2:	beq     	#0x5df8
0x005de4:	movs    	r1, #0
0x005de6:	str     	r1, [sp]
0x005de8:	str     	r1, [sp, #4]
0x005dea:	movs    	r2, #0
0x005dec:	movs    	r1, #0x34
0x005dee:	adds    	r3, r5, #0
0x005df0:	adds    	r0, r6, #0
0x005df2:	str     	r2, [sp, #8]
0x005df4:	bl      	#0x7214
0x005df8:	movs    	r1, #0
0x005dfa:	str     	r1, [sp]
0x005dfc:	str     	r1, [sp, #4]
0x005dfe:	movs    	r2, #0
0x005e00:	movs    	r1, #0xba
0x005e02:	adds    	r3, r5, #0
0x005e04:	adds    	r0, r6, #0
0x005e06:	str     	r2, [sp, #8]
0x005e08:	bl      	#0x7214
0x005e0c:	movs    	r1, #0
0x005e0e:	movs    	r2, #0
0x005e10:	str     	r2, [sp, #8]
0x005e12:	str     	r1, [sp]
0x005e14:	str     	r1, [sp, #4]
0x005e16:	movs    	r1, #0x14
0x005e18:	movs    	r2, #0x17
0x005e1a:	adds    	r3, r4, #0
0x005e1c:	movs    	r0, #0xf1
0x005e1e:	lsls    	r0, r0, #9
0x005e20:	bl      	#0x7214
0x005e24:	add     	sp, #0xc
0x005e26:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_005e2c =====
0x005e2c:	push    	{r4, r5, r6, r7, lr}
0x005e2e:	sub     	sp, #0xc
0x005e30:	ldr     	r5, [pc, #0x3c0]
0x005e32:	adds    	r1, r0, #0
0x005e34:	ldr     	r0, [pc, #0x3bc]
0x005e36:	movs    	r6, #0xf1
0x005e38:	add     	r5, sb
0x005e3a:	subs    	r5, #0x38
0x005e3c:	lsls    	r6, r6, #9
0x005e3e:	movs    	r4, #0
0x005e40:	cmp     	r1, #0xd
0x005e42:	add     	r0, sb
0x005e44:	beq     	#0x5f2c
0x005e46:	bgt     	#0x5e72
0x005e48:	cmp     	r1, #2
0x005e4a:	beq     	#0x5e58
0x005e4c:	cmp     	r1, #5
0x005e4e:	beq     	#0x5e7e
0x005e50:	cmp     	r1, #8
0x005e52:	beq     	#0x5f2c
0x005e54:	cmp     	r1, #0xc
0x005e56:	bne     	#0x5e6e
0x005e58:	movs    	r2, #0
0x005e5a:	movs    	r1, #0
0x005e5c:	str     	r1, [sp, #4]
0x005e5e:	str     	r2, [sp, #8]
0x005e60:	movs    	r2, #7
0x005e62:	movs    	r1, #0x29
0x005e64:	str     	r0, [sp]
0x005e66:	adds    	r3, r4, #0
0x005e68:	adds    	r0, r6, #0
0x005e6a:	bl      	#0x7214
0x005e6e:	add     	sp, #0xc
0x005e70:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_006304 =====
0x006304:	push    	{r4, r5, r6, lr}
0x006306:	sub     	sp, #0x10
0x006308:	movs    	r1, #0
0x00630a:	movs    	r2, #0
0x00630c:	str     	r2, [sp, #8]
0x00630e:	str     	r1, [sp]
0x006310:	str     	r1, [sp, #4]
0x006312:	movs    	r6, #0xf1
0x006314:	movs    	r5, #0
0x006316:	adds    	r3, r5, #0
0x006318:	lsls    	r6, r6, #9
0x00631a:	movs    	r1, #0xe1
0x00631c:	movs    	r2, #0x17
0x00631e:	adds    	r4, r0, #0
0x006320:	adds    	r0, r6, #0
0x006322:	bl      	#0x7214
0x006326:	movs    	r3, #0xff
0x006328:	adds    	r3, #0x28
0x00632a:	cmp     	r0, r3
0x00632c:	beq     	#0x63e0
0x00632e:	bgt     	#0x634a
0x006330:	subs    	r3, #4
0x006332:	cmp     	r0, r3
0x006334:	beq     	#0x6366
0x006336:	adds    	r3, #1
0x006338:	cmp     	r0, r3
0x00633a:	beq     	#0x63c2
0x00633c:	adds    	r3, #1
0x00633e:	cmp     	r0, r3
0x006340:	beq     	#0x63a4
0x006342:	adds    	r3, #1
0x006344:	cmp     	r0, r3
0x006346:	bne     	#0x6382
0x006348:	b       	#0x63e0
0x00634a:	movs    	r3, #0xff
0x00634c:	adds    	r3, #0x29
0x00634e:	cmp     	r0, r3
0x006350:	beq     	#0x63e0
0x006352:	adds    	r3, #1
0x006354:	cmp     	r0, r3
0x006356:	beq     	#0x63e0
0x006358:	adds    	r3, #1
0x00635a:	cmp     	r0, r3
0x00635c:	beq     	#0x6386
0x00635e:	movs    	r3, #0xff
0x006360:	adds    	r3, #0x43
0x006362:	cmp     	r0, r3
0x006364:	bne     	#0x6382
0x006366:	adds    	r0, r4, #0
0x006368:	bl      	#0x65ac
0x00636c:	movs    	r1, #0
0x00636e:	movs    	r2, #0
0x006370:	str     	r2, [sp, #8]
0x006372:	str     	r1, [sp]
0x006374:	str     	r1, [sp, #4]
0x006376:	movs    	r1, #0x21
0x006378:	adds    	r2, r4, #0
0x00637a:	adds    	r3, r5, #0
0x00637c:	adds    	r0, r6, #0
0x00637e:	bl      	#0x7214
0x006382:	add     	sp, #0x10
0x006384:	pop     	{r4, r5, r6, pc}

; ===== candidate_006400 =====
0x006400:	push    	{r4, lr}
0x006402:	adds    	r1, r0, #0
0x006404:	ldr     	r0, [pc, #0xcc]
0x006406:	movs    	r4, #0xf1
0x006408:	lsls    	r4, r4, #9
0x00640a:	movs    	r3, #0
0x00640c:	cmp     	r1, #0xd
0x00640e:	sub     	sp, #0x10
0x006410:	add     	r0, sb
0x006412:	beq     	#0x64be
0x006414:	bgt     	#0x643e
0x006416:	cmp     	r1, #2
0x006418:	beq     	#0x6426
0x00641a:	cmp     	r1, #5
0x00641c:	beq     	#0x644a
0x00641e:	cmp     	r1, #8
0x006420:	beq     	#0x64be
0x006422:	cmp     	r1, #0xc
0x006424:	bne     	#0x643a
0x006426:	movs    	r2, #0
0x006428:	movs    	r1, #0
0x00642a:	str     	r1, [sp, #4]
0x00642c:	str     	r2, [sp, #8]
0x00642e:	movs    	r2, #3
0x006430:	movs    	r1, #0x29
0x006432:	str     	r0, [sp]
0x006434:	adds    	r0, r4, #0
0x006436:	bl      	#0x7214
0x00643a:	add     	sp, #0x10
0x00643c:	pop     	{r4, pc}

; ===== candidate_0064d8 =====
0x0064d8:	push    	{r4, r5, r6, r7, lr}
0x0064da:	ldr     	r6, [pc, #0xcc]
0x0064dc:	movs    	r4, #0xf1
0x0064de:	add     	r6, sb
0x0064e0:	ldr     	r3, [r6, #0x6c]
0x0064e2:	lsls    	r4, r4, #9
0x0064e4:	movs    	r7, #0
0x0064e6:	adds    	r5, r0, #0
0x0064e8:	cmp     	r3, #0
0x0064ea:	sub     	sp, #0xc
0x0064ec:	beq     	#0x6508
0x0064ee:	movs    	r1, #0
0x0064f0:	movs    	r2, #0
0x0064f2:	str     	r2, [sp, #8]
0x0064f4:	str     	r1, [sp]
0x0064f6:	str     	r1, [sp, #4]
0x0064f8:	movs    	r1, #0x11
0x0064fa:	adds    	r2, r3, #0
0x0064fc:	movs    	r7, #4
0x0064fe:	adds    	r0, r4, #0
0x006500:	adds    	r3, r7, #0
0x006502:	bl      	#0x7214
0x006506:	adds    	r7, r0, #0
0x006508:	ldr     	r0, [pc, #0x9c]
0x00650a:	adds    	r1, r5, #0
0x00650c:	add     	r0, sb
0x00650e:	adds    	r0, #0x68
0x006510:	movs    	r5, #0
0x006512:	cmp     	r1, #0xd
0x006514:	beq     	#0x655c
0x006516:	bgt     	#0x6542
0x006518:	cmp     	r1, #2
0x00651a:	beq     	#0x6528
0x00651c:	cmp     	r1, #5
0x00651e:	beq     	#0x654e
0x006520:	cmp     	r1, #6
0x006522:	beq     	#0x655c
0x006524:	cmp     	r1, #0xc
0x006526:	bne     	#0x653e
0x006528:	movs    	r2, #0
0x00652a:	movs    	r1, #0
0x00652c:	str     	r1, [sp, #4]
0x00652e:	str     	r2, [sp, #8]
0x006530:	adds    	r2, r7, #0
0x006532:	movs    	r1, #0x29
0x006534:	str     	r0, [sp]
0x006536:	adds    	r3, r5, #0
0x006538:	adds    	r0, r4, #0
0x00653a:	bl      	#0x7214
0x00653e:	add     	sp, #0xc
0x006540:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0065ac =====
0x0065ac:	push    	{r4, r5, r6, r7, lr}
0x0065ae:	ldr     	r5, [pc, #0x300]
0x0065b0:	movs    	r4, #0xf1
0x0065b2:	add     	r5, sb
0x0065b4:	ldr     	r3, [r5, #0x54]
0x0065b6:	lsls    	r4, r4, #9
0x0065b8:	movs    	r7, #0
0x0065ba:	adds    	r6, r0, #0
0x0065bc:	cmp     	r3, #0
0x0065be:	sub     	sp, #0xc
0x0065c0:	beq     	#0x65dc
0x0065c2:	movs    	r1, #0
0x0065c4:	movs    	r2, #0
0x0065c6:	str     	r2, [sp, #8]
0x0065c8:	str     	r1, [sp]
0x0065ca:	str     	r1, [sp, #4]
0x0065cc:	movs    	r1, #0x11
0x0065ce:	adds    	r2, r3, #0
0x0065d0:	movs    	r7, #4
0x0065d2:	adds    	r0, r4, #0
0x0065d4:	adds    	r3, r7, #0
0x0065d6:	bl      	#0x7214
0x0065da:	adds    	r7, r0, #0
0x0065dc:	subs    	r6, #2
0x0065de:	cmp     	r6, #0x13
0x0065e0:	bhs     	#0x65ec
0x0065e2:	adr     	r3, #0xc
0x0065e4:	adds    	r3, r3, r6
0x0065e6:	ldrh    	r3, [r3, r6]
0x0065e8:	lsls    	r3, r3, #1
0x0065ea:	add     	pc, r3
0x0065ec:	add     	sp, #0xc
0x0065ee:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0068be =====
0x0068be:	push    	{r3, lr}
0x0068c0:	add     	r1, sb
0x0068c2:	ldr     	r1, [r1, #0x58]
0x0068c4:	cmp     	r1, #0
0x0068c6:	beq     	#0x68d6
0x0068c8:	cmp     	r1, #1
0x0068ca:	beq     	#0x6910
0x0068cc:	cmp     	r1, #2
0x0068ce:	bne     	#0x68d4
0x0068d0:	bl      	#0x6ab0
0x0068d4:	pop     	{r3, pc}

; ===== candidate_00691c =====
0x00691c:	push    	{r4, r5, lr}
0x00691e:	sub     	sp, #0xc
0x006920:	adds    	r4, r0, #0
0x006922:	movs    	r1, #0
0x006924:	ldr     	r0, [pc, #0x180]
0x006926:	str     	r1, [sp]
0x006928:	str     	r1, [sp, #4]
0x00692a:	movs    	r2, #0
0x00692c:	str     	r2, [sp, #8]
0x00692e:	add     	r0, sb
0x006930:	ldr     	r2, [r0, #0x28]
0x006932:	movs    	r0, #0xf1
0x006934:	movs    	r1, #0x11
0x006936:	movs    	r3, #4
0x006938:	lsls    	r0, r0, #9
0x00693a:	bl      	#0x7214
0x00693e:	adds    	r5, r0, #0
0x006940:	subs    	r4, #2
0x006942:	cmp     	r4, #0x13
0x006944:	bhs     	#0x696c
0x006946:	adr     	r3, #8
0x006948:	ldrb    	r3, [r3, r4]
0x00694a:	lsls    	r3, r3, #1
0x00694c:	add     	pc, r3
0x00694e:	movs    	r0, r0
0x006950:	lsrs    	r1, r1, #0x19
0x006952:	subs    	r5, r1, #2
0x006954:	lsrs    	r5, r5, #0x19
0x006956:	lsrs    	r3, r3, #0x19
0x006958:	lsrs    	r6, r1, #0x18
0x00695a:	ldrh    	r1, [r1, r5]
0x00695c:	ldr     	r5, [r1, #0x58]
0x00695e:	lsrs    	r6, r1, #8
0x006960:	lsrs    	r0, r2, #0x18
0x006962:	movs    	r6, r3
0x006964:	cmp     	r5, #0
0x006966:	ble     	#0x696c
0x006968:	bl      	#0x5b6c
0x00696c:	add     	sp, #0xc
0x00696e:	pop     	{r4, r5, pc}

; ===== candidate_006ab0 =====
0x006ab0:	push    	{r4, r5, r6, r7, lr}
0x006ab2:	sub     	sp, #0xc
0x006ab4:	adds    	r4, r0, #0
0x006ab6:	movs    	r1, #0
0x006ab8:	ldr     	r0, [pc, #0x100]
0x006aba:	str     	r1, [sp]
0x006abc:	str     	r1, [sp, #4]
0x006abe:	movs    	r2, #0
0x006ac0:	str     	r2, [sp, #8]
0x006ac2:	add     	r0, sb
0x006ac4:	ldr     	r2, [r0, #0x24]
0x006ac6:	movs    	r0, #0xf1
0x006ac8:	movs    	r1, #0x11
0x006aca:	movs    	r3, #4
0x006acc:	lsls    	r0, r0, #9
0x006ace:	bl      	#0x7214
0x006ad2:	adds    	r5, r0, #0
0x006ad4:	subs    	r4, #2
0x006ad6:	cmp     	r4, #0x13
0x006ad8:	bhs     	#0x6b1a
0x006ada:	adr     	r3, #8
0x006adc:	ldrb    	r3, [r3, r4]
0x006ade:	lsls    	r3, r3, #1
0x006ae0:	add     	pc, r3
0x006ae2:	movs    	r0, r0
0x006ae4:	subs    	r6, r4, r4
0x006ae6:	lsrs    	r3, r4, #8
0x006ae8:	subs    	r0, r4, r4
0x006aea:	subs    	r1, r1, r5
0x006aec:	subs    	r3, r3, r4
0x006aee:	ldr     	r1, [pc, #0x98]
0x006af0:	movs    	r0, #0x23
0x006af2:	lsrs    	r3, r3, #8
0x006af4:	subs    	r5, r3, r4
0x006af6:	movs    	r2, r1
0x006af8:	movs    	r2, #0
0x006afa:	movs    	r1, #0
0x006afc:	str     	r2, [sp, #8]
0x006afe:	movs    	r2, #0xff
0x006b00:	str     	r1, [sp]
0x006b02:	str     	r1, [sp, #4]
0x006b04:	movs    	r1, #0xe1
0x006b06:	adds    	r2, #0x1b
0x006b08:	movs    	r3, #0
0x006b0a:	movs    	r0, #0xf1
0x006b0c:	lsls    	r0, r0, #9
0x006b0e:	bl      	#0x7214
0x006b12:	cmp     	r0, #0
0x006b14:	bne     	#0x6b1a
0x006b16:	bl      	#0x560c
0x006b1a:	add     	sp, #0xc
0x006b1c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_006bc0 =====
0x006bc0:	push    	{r4, r5, r6, r7, lr}
0x006bc2:	ldr     	r5, [pc, #0x1ac]
0x006bc4:	movs    	r4, #0xf1
0x006bc6:	add     	r5, sb
0x006bc8:	ldr     	r3, [r5, #0x28]
0x006bca:	lsls    	r4, r4, #9
0x006bcc:	movs    	r7, #0
0x006bce:	adds    	r6, r0, #0
0x006bd0:	cmp     	r3, #0
0x006bd2:	sub     	sp, #0xc
0x006bd4:	beq     	#0x6bf0
0x006bd6:	movs    	r1, #0
0x006bd8:	movs    	r2, #0
0x006bda:	str     	r2, [sp, #8]
0x006bdc:	str     	r1, [sp]
0x006bde:	str     	r1, [sp, #4]
0x006be0:	movs    	r1, #0x11
0x006be2:	adds    	r2, r3, #0
0x006be4:	movs    	r7, #4
0x006be6:	adds    	r0, r4, #0
0x006be8:	adds    	r3, r7, #0
0x006bea:	bl      	#0x7214
0x006bee:	adds    	r7, r0, #0
0x006bf0:	subs    	r6, #2
0x006bf2:	cmp     	r6, #0x13
0x006bf4:	bhs     	#0x6c38
0x006bf6:	adr     	r3, #8
0x006bf8:	ldrb    	r3, [r3, r6]
0x006bfa:	lsls    	r3, r3, #1
0x006bfc:	add     	pc, r3
0x006bfe:	movs    	r0, r0
0x006c00:	adds    	r0, r3, #1
0x006c02:	subs    	r7, r2, #2
0x006c04:	adds    	r2, r7, #1
0x006c06:	adds    	r1, r5, #1
0x006c08:	adds    	r4, r3, #0
0x006c0a:	ldr     	r0, [r3, #0x14]
0x006c0c:	uxth    	r5, r6
0x006c0e:	lsrs    	r4, r3, #8
0x006c10:	adds    	r5, r2, #1
0x006c12:	movs    	r6, r3
0x006c14:	cmp     	r7, #0
0x006c16:	ble     	#0x6c38
0x006c18:	movs    	r2, #0
0x006c1a:	movs    	r1, #0
0x006c1c:	str     	r2, [sp, #8]
0x006c1e:	movs    	r2, #0xff
0x006c20:	str     	r1, [sp]
0x006c22:	str     	r1, [sp, #4]
0x006c24:	movs    	r1, #0xe1
0x006c26:	adds    	r2, #0x1b
0x006c28:	movs    	r3, #0
0x006c2a:	adds    	r0, r4, #0
0x006c2c:	bl      	#0x7214
0x006c30:	cmp     	r0, #0
0x006c32:	bne     	#0x6c38
0x006c34:	bl      	#0x5838
0x006c38:	add     	sp, #0xc
0x006c3a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_006d78 =====
0x006d78:	push    	{r4, r5, r6, lr}
0x006d7a:	sub     	sp, #0x10
0x006d7c:	ldr     	r0, [pc, #0x9c]
0x006d7e:	movs    	r2, #0
0x006d80:	movs    	r1, #0
0x006d82:	str     	r1, [sp, #4]
0x006d84:	str     	r2, [sp, #8]
0x006d86:	movs    	r6, #0xf1
0x006d88:	movs    	r4, #0
0x006d8a:	add     	r0, sb
0x006d8c:	str     	r0, [sp]
0x006d8e:	adds    	r3, r4, #0
0x006d90:	lsls    	r6, r6, #9
0x006d92:	movs    	r2, #3
0x006d94:	movs    	r1, #0x29
0x006d96:	adds    	r0, r6, #0
0x006d98:	bl      	#0x7214
0x006d9c:	ldr     	r5, [pc, #0x7c]
0x006d9e:	add     	r5, sb
0x006da0:	subs    	r5, #0x58
0x006da2:	ldr     	r0, [r5, #0x28]
0x006da4:	cmp     	r0, #0
0x006da6:	bne     	#0x6dd8
0x006da8:	ldr     	r0, [r5, #0x58]
0x006daa:	cmp     	r0, #1
0x006dac:	bne     	#0x6dd8
0x006dae:	movs    	r1, #0
0x006db0:	str     	r1, [sp]
0x006db2:	str     	r1, [sp, #4]
0x006db4:	movs    	r2, #0
0x006db6:	movs    	r1, #0x34
0x006db8:	adds    	r3, r4, #0
0x006dba:	adds    	r0, r6, #0
0x006dbc:	str     	r2, [sp, #8]
0x006dbe:	bl      	#0x7214
0x006dc2:	bl      	#0x501c
0x006dc6:	adds    	r3, r0, #0
0x006dc8:	ldr     	r0, [r5, #0x18]
0x006dca:	mvns    	r2, r4
0x006dcc:	ldr     	r0, [r0]
0x006dce:	ldr     	r1, [r0]
0x006dd0:	movs    	r0, #0xff
0x006dd2:	adds    	r0, #0x39
0x006dd4:	bl      	#0x7e7c
0x006dd8:	ldr     	r0, [r5, #0x24]
0x006dda:	cmp     	r0, #0
0x006ddc:	bne     	#0x6e16
0x006dde:	ldr     	r0, [r5, #0x58]
0x006de0:	cmp     	r0, #2
0x006de2:	bne     	#0x6e16
0x006de4:	movs    	r1, #0
0x006de6:	str     	r1, [sp]
0x006de8:	str     	r1, [sp, #4]
0x006dea:	movs    	r2, #0
0x006dec:	movs    	r1, #0x34
0x006dee:	adds    	r3, r4, #0
0x006df0:	adds    	r0, r6, #0
0x006df2:	str     	r2, [sp, #8]
0x006df4:	bl      	#0x7214
0x006df8:	movs    	r1, #0
0x006dfa:	movs    	r2, #0
0x006dfc:	str     	r2, [sp, #8]
0x006dfe:	str     	r1, [sp]
0x006e00:	str     	r1, [sp, #4]
0x006e02:	ldr     	r0, [r5, #0x18]
0x006e04:	movs    	r2, #0xff
0x006e06:	ldr     	r0, [r0]
0x006e08:	adds    	r2, #0x43
0x006e0a:	ldr     	r3, [r0]
0x006e0c:	movs    	r0, #0xf1
0x006e0e:	movs    	r1, #0x50
0x006e10:	lsls    	r0, r0, #9
0x006e12:	bl      	#0x7214
0x006e16:	add     	sp, #0x10
0x006e18:	pop     	{r4, r5, r6, pc}

; ===== candidate_006e20 =====
0x006e20:	push    	{r4, r5, r6, lr}
0x006e22:	sub     	sp, #0x10
0x006e24:	ldr     	r0, [pc, #0x9c]
0x006e26:	movs    	r2, #0
0x006e28:	movs    	r1, #1
0x006e2a:	str     	r1, [sp, #4]
0x006e2c:	str     	r2, [sp, #8]
0x006e2e:	movs    	r6, #0xf1
0x006e30:	movs    	r4, #0
0x006e32:	add     	r0, sb
0x006e34:	str     	r0, [sp]
0x006e36:	adds    	r3, r4, #0
0x006e38:	lsls    	r6, r6, #9
0x006e3a:	movs    	r2, #3
0x006e3c:	movs    	r1, #0x29
0x006e3e:	adds    	r0, r6, #0
0x006e40:	bl      	#0x7214
0x006e44:	ldr     	r5, [pc, #0x7c]
0x006e46:	add     	r5, sb
0x006e48:	subs    	r5, #0x58
0x006e4a:	ldr     	r0, [r5, #0x28]
0x006e4c:	cmp     	r0, #0
0x006e4e:	bne     	#0x6e80
0x006e50:	ldr     	r0, [r5, #0x58]
0x006e52:	cmp     	r0, #1
0x006e54:	bne     	#0x6e80
0x006e56:	movs    	r1, #0
0x006e58:	str     	r1, [sp]
0x006e5a:	str     	r1, [sp, #4]
0x006e5c:	movs    	r2, #0
0x006e5e:	movs    	r1, #0x34
0x006e60:	adds    	r3, r4, #0
0x006e62:	adds    	r0, r6, #0
0x006e64:	str     	r2, [sp, #8]
0x006e66:	bl      	#0x7214
0x006e6a:	bl      	#0x501c
0x006e6e:	adds    	r3, r0, #0
0x006e70:	ldr     	r0, [r5, #0x18]
0x006e72:	mvns    	r2, r4
0x006e74:	ldr     	r0, [r0]
0x006e76:	ldr     	r1, [r0]
0x006e78:	movs    	r0, #0xff
0x006e7a:	adds    	r0, #0x39
0x006e7c:	bl      	#0x7e7c
0x006e80:	ldr     	r0, [r5, #0x24]
0x006e82:	cmp     	r0, #0
0x006e84:	bne     	#0x6ebe
0x006e86:	ldr     	r0, [r5, #0x58]
0x006e88:	cmp     	r0, #2
0x006e8a:	bne     	#0x6ebe
0x006e8c:	movs    	r1, #0
0x006e8e:	str     	r1, [sp]
0x006e90:	str     	r1, [sp, #4]
0x006e92:	movs    	r2, #0
0x006e94:	movs    	r1, #0x34
0x006e96:	adds    	r3, r4, #0
0x006e98:	adds    	r0, r6, #0
0x006e9a:	str     	r2, [sp, #8]
0x006e9c:	bl      	#0x7214
0x006ea0:	movs    	r1, #0
0x006ea2:	movs    	r2, #0
0x006ea4:	str     	r2, [sp, #8]
0x006ea6:	str     	r1, [sp]
0x006ea8:	str     	r1, [sp, #4]
0x006eaa:	ldr     	r0, [r5, #0x18]
0x006eac:	movs    	r2, #0xff
0x006eae:	ldr     	r0, [r0]
0x006eb0:	adds    	r2, #0x43
0x006eb2:	ldr     	r3, [r0]
0x006eb4:	movs    	r0, #0xf1
0x006eb6:	movs    	r1, #0x50
0x006eb8:	lsls    	r0, r0, #9
0x006eba:	bl      	#0x7214
0x006ebe:	add     	sp, #0x10
0x006ec0:	pop     	{r4, r5, r6, pc}

; ===== candidate_006ec8 =====
0x006ec8:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x006eca:	sub     	sp, #0xc
0x006ecc:	adds    	r4, r1, #0
0x006ece:	movs    	r1, #0
0x006ed0:	adds    	r5, r2, #0
0x006ed2:	movs    	r2, #0
0x006ed4:	str     	r2, [sp, #8]
0x006ed6:	str     	r1, [sp]
0x006ed8:	str     	r1, [sp, #4]
0x006eda:	movs    	r6, #0xf1
0x006edc:	lsls    	r6, r6, #9
0x006ede:	movs    	r1, #0xe1
0x006ee0:	movs    	r2, #0xe2
0x006ee2:	movs    	r3, #0
0x006ee4:	adds    	r0, r6, #0
0x006ee6:	ldr     	r7, [sp, #0x30]
0x006ee8:	bl      	#0x7214
0x006eec:	cmp     	r0, #0
0x006eee:	bne     	#0x6f06
0x006ef0:	movs    	r1, #0
0x006ef2:	movs    	r2, #0
0x006ef4:	str     	r2, [sp, #8]
0x006ef6:	str     	r1, [sp]
0x006ef8:	str     	r1, [sp, #4]
0x006efa:	movs    	r1, #0x14
0x006efc:	movs    	r2, #0xe2
0x006efe:	movs    	r3, #1
0x006f00:	adds    	r0, r6, #0
0x006f02:	bl      	#0x7214
0x006f06:	ldr     	r0, [sp, #0xc]
0x006f08:	cmp     	r0, #0x24
0x006f0a:	bhs     	#0x6f16
0x006f0c:	adr     	r3, #8
0x006f0e:	adds    	r3, r3, r0
0x006f10:	ldrh    	r3, [r3, r0]
0x006f12:	lsls    	r3, r3, #1
0x006f14:	add     	pc, r3
0x006f16:	b       	#0x7128
0x006f18:	lsls    	r5, r0, #3
0x006f1a:	lsls    	r0, r2, #3
0x006f1c:	lsls    	r3, r3, #3
0x006f1e:	lsls    	r0, r4, #3
0x006f20:	lsls    	r6, r6, #3
0x006f22:	lsls    	r7, r7, #2
0x006f24:	lsls    	r4, r7, #2
0x006f26:	lsls    	r6, r6, #2
0x006f28:	lsls    	r2, r6, #2
0x006f2a:	lsls    	r5, r5, #2
0x006f2c:	lsls    	r0, r5, #2
0x006f2e:	lsls    	r4, r4, #2
0x006f30:	lsls    	r7, r3, #2
0x006f32:	lsls    	r2, r3, #2
0x006f34:	lsls    	r6, r2, #2
0x006f36:	lsls    	r1, r2, #2
0x006f38:	lsls    	r4, r1, #2
0x006f3a:	lsls    	r7, r0, #2
0x006f3c:	lsls    	r3, r0, #2
0x006f3e:	lsls    	r7, r7, #1
0x006f40:	lsls    	r2, r7, #1
0x006f42:	lsls    	r5, r6, #1
0x006f44:	lsls    	r0, r6, #1
0x006f46:	lsls    	r3, r5, #1
0x006f48:	lsls    	r7, r3, #1
0x006f4a:	lsls    	r2, r3, #1
0x006f4c:	lsls    	r5, r2, #1
0x006f4e:	lsls    	r0, r2, #1
0x006f50:	lsls    	r3, r1, #1
0x006f52:	lsls    	r6, r0, #1
0x006f54:	lsls    	r1, r0, #1
0x006f56:	movs    	r5, r7
0x006f58:	movs    	r0, r7
0x006f5a:	movs    	r0, r6
0x006f5c:	movs    	r2, r5
0x006f5e:	movs    	r4, r4
0x006f60:	adds    	r0, r4, #0
0x006f62:	bl      	#0x3f0
0x006f66:	movs    	r0, #0
0x006f68:	add     	sp, #0x1c
0x006f6a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00713c =====
0x00713c:	push    	{r3, r4, r5, lr}
0x00713e:	ldr     	r4, [pc, #0x74]
0x007140:	add     	r4, pc
0x007142:	ldr     	r0, [r4, #0x38]
0x007144:	movs    	r1, #0x14
0x007146:	ldr     	r2, [r0, #0x64]
0x007148:	ldr     	r0, [pc, #0x6c]
0x00714a:	add     	r0, pc
0x00714c:	blx     	r2
0x00714e:	movs    	r5, #0
0x007150:	mvns    	r5, r5
0x007152:	cmp     	r0, r5
0x007154:	bne     	#0x715a
0x007156:	adds    	r0, r5, #0
0x007158:	pop     	{r3, r4, r5, pc}

; ===== candidate_0071c4 =====
0x0071c4:	push    	{r4, lr}
0x0071c6:	sub     	sp, #0x10
0x0071c8:	lsls    	r0, r0, #0x18
0x0071ca:	lsrs    	r0, r0, #0x18
0x0071cc:	str     	r0, [sp]
0x0071ce:	ldr     	r0, [pc, #0x38]
0x0071d0:	lsls    	r2, r2, #0x18
0x0071d2:	lsls    	r1, r1, #0x18
0x0071d4:	lsrs    	r1, r1, #0x18
0x0071d6:	lsrs    	r2, r2, #0x18
0x0071d8:	str     	r2, [sp, #8]
0x0071da:	str     	r1, [sp, #4]
0x0071dc:	add     	r0, pc
0x0071de:	ldr     	r0, [r0, #0x38]
0x0071e0:	adds    	r1, r0, #0
0x0071e2:	adds    	r1, #0xff
0x0071e4:	adds    	r1, #0x41
0x0071e6:	ldr     	r2, [r1, #0x34]
0x0071e8:	ldr     	r1, [r1, #0x30]
0x0071ea:	ldr     	r2, [r2]
0x0071ec:	ldr     	r1, [r1]
0x0071ee:	lsls    	r3, r2, #0x10
0x0071f0:	lsls    	r2, r1, #0x10
0x0071f2:	asrs    	r2, r2, #0x10
0x0071f4:	asrs    	r3, r3, #0x10
0x0071f6:	adds    	r0, #0xff
0x0071f8:	adds    	r0, #0xc1
0x0071fa:	ldr     	r4, [r0, #0x28]
0x0071fc:	movs    	r1, #0
0x0071fe:	movs    	r0, #0
0x007200:	blx     	r4
0x007202:	add     	sp, #0x10
0x007204:	pop     	{r4, pc}

; ===== candidate_007214 =====
0x007214:	push    	{r4, r5, r6, r7, lr}
0x007216:	adds    	r5, r1, #0
0x007218:	adds    	r4, r0, #0
0x00721a:	adds    	r6, r2, #0
0x00721c:	ldr     	r2, [pc, #0x28]
0x00721e:	sub     	sp, #0x14
0x007220:	mov     	ip, r3
0x007222:	add     	r2, pc
0x007224:	ldr     	r0, [sp, #0x2c]
0x007226:	ldr     	r1, [sp, #0x30]
0x007228:	ldr     	r7, [sp, #0x28]
0x00722a:	ldr     	r3, [r2, #0x3c]
0x00722c:	movs    	r2, #2
0x00722e:	str     	r2, [sp, #0xc]
0x007230:	str     	r1, [sp, #8]
0x007232:	str     	r0, [sp, #4]
0x007234:	str     	r7, [sp]
0x007236:	ldr     	r0, [r3, #0xc]
0x007238:	adds    	r1, r5, #0
0x00723a:	adds    	r2, r6, #0
0x00723c:	ldr     	r7, [r0, #0x28]
0x00723e:	adds    	r0, r4, #0
0x007240:	mov     	r3, ip
0x007242:	blx     	r7
0x007244:	add     	sp, #0x14
0x007246:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007250 =====
0x007250:	push    	{r4, lr}
0x007252:	movs    	r2, #0
0x007254:	add     	r0, pc
0x007256:	ldr     	r4, [r0, #0x3c]
0x007258:	sub     	sp, #0x10
0x00725a:	movs    	r1, #0
0x00725c:	str     	r1, [sp, #4]
0x00725e:	str     	r1, [sp, #8]
0x007260:	str     	r2, [sp, #0xc]
0x007262:	str     	r2, [sp]
0x007264:	ldr     	r0, [r4, #0xc]
0x007266:	ldr     	r2, [r0, #0x24]
0x007268:	ldr     	r4, [r0, #0x28]
0x00726a:	blx     	r4
0x00726c:	add     	sp, #0x10
0x00726e:	pop     	{r4, pc}

; ===== candidate_007274 =====
0x007274:	push    	{r4, lr}
0x007276:	ldr     	r0, [pc, #0x24]
0x007278:	sub     	sp, #0x10
0x00727a:	add     	r0, pc
0x00727c:	ldr     	r3, [r0, #0x3c]
0x00727e:	movs    	r2, #0
0x007280:	movs    	r1, #0
0x007282:	str     	r1, [sp, #4]
0x007284:	str     	r1, [sp, #8]
0x007286:	str     	r2, [sp, #0xc]
0x007288:	str     	r2, [sp]
0x00728a:	ldr     	r0, [r3, #0xc]
0x00728c:	movs    	r3, #0
0x00728e:	ldr     	r2, [r0, #0x24]
0x007290:	ldr     	r4, [r0, #0x28]
0x007292:	movs    	r1, #1
0x007294:	blx     	r4
0x007296:	add     	sp, #0x10
0x007298:	pop     	{r4, pc}

; ===== candidate_0072b4 =====
0x0072b4:	push    	{r4, lr}
0x0072b6:	sub     	sp, #0x10
0x0072b8:	movs    	r2, #0
0x0072ba:	movs    	r1, #0
0x0072bc:	str     	r2, [sp, #8]
0x0072be:	ldr     	r2, [pc, #0x3c]
0x0072c0:	str     	r1, [sp]
0x0072c2:	str     	r1, [sp, #4]
0x0072c4:	movs    	r3, #0
0x0072c6:	add     	r2, pc
0x0072c8:	ldr     	r1, [pc, #0x34]
0x0072ca:	ldr     	r0, [pc, #0x38]
0x0072cc:	bl      	#0x7214
0x0072d0:	ldr     	r3, [pc, #0x38]
0x0072d2:	ldr     	r4, [pc, #0x34]
0x0072d4:	add     	r3, sb
0x0072d6:	ldr     	r3, [r3]
0x0072d8:	movs    	r2, #0x41
0x0072da:	movs    	r1, #0
0x0072dc:	add     	r4, sb
0x0072de:	adds    	r0, r4, #0
0x0072e0:	blx     	r3
0x0072e2:	bl      	#0x72a0
0x0072e6:	ldr     	r3, [pc, #0x28]
0x0072e8:	adds    	r1, r0, #0
0x0072ea:	add     	r3, sb
0x0072ec:	ldr     	r3, [r3]
0x0072ee:	movs    	r2, #0x41
0x0072f0:	adds    	r0, r4, #0
0x0072f2:	blx     	r3
0x0072f4:	movs    	r0, #0
0x0072f6:	add     	sp, #0x10
0x0072f8:	pop     	{r4, pc}

; ===== candidate_007318 =====
0x007318:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00731a:	adds    	r7, r3, #0
0x00731c:	adds    	r6, r2, #0
0x00731e:	adds    	r5, r0, #0
0x007320:	ldr     	r0, [r0]
0x007322:	sub     	sp, #4
0x007324:	mov     	r1, sb
0x007326:	str     	r1, [sp]
0x007328:	movs    	r4, #0
0x00732a:	blx     	#0x2e0
0x00732e:	ldr     	r0, [sp, #8]
0x007330:	cmp     	r0, #0xb
0x007332:	bhs     	#0x73a0
0x007334:	adr     	r3, #4
0x007336:	ldrb    	r3, [r3, r0]
0x007338:	lsls    	r3, r3, #1
0x00733a:	add     	pc, r3
0x00733c:	lsrs    	r5, r0, #0x1c
0x00733e:	subs    	r4, r3, #4
0x007340:	movs    	r4, #0x21
0x007342:	adds    	r1, #0x27
0x007344:	adds    	r1, #0x2b
0x007346:	movs    	r7, r5
0x007348:	ldr     	r1, [pc, #0x60]
0x00734a:	ldr     	r0, [r5, #0xc]
0x00734c:	add     	r1, sb
0x00734e:	str     	r0, [r1, #0x14]
0x007350:	bl      	#0x328
0x007354:	bl      	#0x72b4
0x007358:	adds    	r4, r0, #0
0x00735a:	b       	#0x73a0
0x00735c:	ldr     	r0, [r6]
0x00735e:	cmp     	r0, #8
0x007360:	bne     	#0x736a
0x007362:	bl      	#0x7210
0x007366:	adds    	r4, r0, #0
0x007368:	b       	#0x73a0
0x00736a:	ldr     	r1, [r6, #4]
0x00736c:	ldr     	r2, [r6, #8]
0x00736e:	bl      	#0x720c
0x007372:	adds    	r4, r0, #0
0x007374:	b       	#0x73a0
0x007376:	bl      	#0x75a8
0x00737a:	b       	#0x73a0
0x00737c:	str     	r7, [r5, #0xc]
0x00737e:	b       	#0x73a0
0x007380:	bl      	#0x7314
0x007384:	b       	#0x73a0
0x007386:	bl      	#0x73e4
0x00738a:	b       	#0x73a0
0x00738c:	ldr     	r0, [pc, #0x1c]
0x00738e:	add     	r0, sb
0x007390:	str     	r7, [r0, #0x1c]
0x007392:	b       	#0x73a0
0x007394:	ldr     	r0, [pc, #0x14]
0x007396:	add     	r0, sb
0x007398:	str     	r6, [r0, #0x20]
0x00739a:	b       	#0x73a0
0x00739c:	ldr     	r4, [pc, #0x10]
0x00739e:	add     	r4, pc
0x0073a0:	ldr     	r1, [sp]
0x0073a2:	add     	sp, #0x14
0x0073a4:	adds    	r0, r4, #0
0x0073a6:	mov     	sb, r1
0x0073a8:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0073b4 =====
0x0073b4:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0073b6:	sub     	sp, #0xc
0x0073b8:	ldr     	r0, [sp, #0x38]
0x0073ba:	ldr     	r4, [sp, #0x3c]
0x0073bc:	ldr     	r6, [sp, #0x34]
0x0073be:	ldr     	r0, [r0]
0x0073c0:	mov     	r7, sb
0x0073c2:	movs    	r5, #0
0x0073c4:	blx     	#0x2e0
0x0073c8:	cmp     	r4, #0
0x0073ca:	beq     	#0x73da
0x0073cc:	ldr     	r1, [sp, #0x30]
0x0073ce:	str     	r6, [sp, #4]
0x0073d0:	add     	r3, sp, #0xc
0x0073d2:	str     	r1, [sp]
0x0073d4:	ldm     	r3, {r0, r1, r2, r3}
0x0073d6:	blx     	r4
0x0073d8:	adds    	r5, r0, #0
0x0073da:	mov     	sb, r7
0x0073dc:	adds    	r0, r5, #0
0x0073de:	add     	sp, #0x1c
0x0073e0:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007448 =====
0x007448:	push    	{r3, r4, r5, r6, r7, lr}
0x00744a:	adds    	r4, r0, #0
0x00744c:	ldr     	r0, [pc, #0x10c]
0x00744e:	movs    	r5, #0
0x007450:	mvns    	r5, r5
0x007452:	mov     	ip, r2
0x007454:	add     	r0, pc
0x007456:	ldr     	r2, [r0, #0x38]
0x007458:	cmp     	r4, #0
0x00745a:	bne     	#0x746c
0x00745c:	ldr     	r0, [pc, #0x100]
0x00745e:	ldr     	r2, [r2, #0x68]
0x007460:	movs    	r1, #0x7d
0x007462:	lsls    	r1, r1, #3
0x007464:	add     	r0, pc
0x007466:	blx     	r2
0x007468:	adds    	r0, r5, #0
0x00746a:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_007574 =====
0x007574:	push    	{r3, r4, r5, lr}
0x007576:	ldr     	r4, [pc, #0x28]
0x007578:	adds    	r5, r0, #0
0x00757a:	add     	r4, pc
0x00757c:	ldr     	r0, [r4, #0x38]
0x00757e:	adds    	r0, #0x80
0x007580:	ldr     	r0, [r0, #4]
0x007582:	blx     	r0
0x007584:	adds    	r0, r0, r5
0x007586:	ldr     	r1, [pc, #0x1c]
0x007588:	add     	r1, sb
0x00758a:	str     	r0, [r1, #0x10]
0x00758c:	ldr     	r0, [r4, #0x38]
0x00758e:	adds    	r0, #0x80
0x007590:	ldr     	r0, [r0]
0x007592:	blx     	r0
0x007594:	ldr     	r0, [r4, #0x38]
0x007596:	ldr     	r1, [r0, #0x7c]
0x007598:	lsls    	r0, r5, #0x10
0x00759a:	lsrs    	r0, r0, #0x10
0x00759c:	blx     	r1
0x00759e:	pop     	{r3, r4, r5, pc}

; ===== candidate_0075aa =====
0x0075aa:	push    	{r3, r4, r5, r6, r7, lr}
0x0075ac:	add     	r0, pc
0x0075ae:	ldr     	r0, [r0, #0x38]
0x0075b0:	adds    	r0, #0x80
0x0075b2:	ldr     	r0, [r0, #4]
0x0075b4:	blx     	r0
0x0075b6:	movs    	r5, #0
0x0075b8:	ldr     	r6, [pc, #0xc8]
0x0075ba:	add     	r6, sb
0x0075bc:	ldr     	r1, [r6, #0x10]
0x0075be:	str     	r5, [r6, #0x10]
0x0075c0:	subs    	r1, r0, r1
0x0075c2:	ldr     	r0, [r6, #8]
0x0075c4:	adds    	r3, r1, #0
0x0075c6:	cmp     	r0, #0
0x0075c8:	beq     	#0x767e
0x0075ca:	ldr     	r2, [r0, #8]
0x0075cc:	cmp     	r2, #0
0x0075ce:	bne     	#0x762e
0x0075d0:	mvns    	r7, r2
0x0075d2:	str     	r7, [r0, #8]
0x0075d4:	ldr     	r2, [r0, #0x18]
0x0075d6:	adds    	r4, r0, #0
0x0075d8:	cmp     	r1, #0x32
0x0075da:	str     	r2, [r6, #8]
0x0075dc:	bge     	#0x75e2
0x0075de:	movs    	r1, #0x32
0x0075e0:	b       	#0x75fe
0x0075e2:	movs    	r2, #0x7d
0x0075e4:	lsls    	r2, r2, #4
0x0075e6:	cmp     	r1, r2
0x0075e8:	ble     	#0x75fe
0x0075ea:	adds    	r1, r2, #0
0x0075ec:	b       	#0x75fe
0x0075ee:	movs    	r7, #0
0x0075f0:	mvns    	r7, r7
0x0075f2:	str     	r7, [r2, #8]
0x0075f4:	ldr     	r2, [r0, #0x18]
0x0075f6:	str     	r2, [r0, #0x1c]
0x0075f8:	ldr     	r0, [r2, #0x18]
0x0075fa:	str     	r0, [r6, #8]
0x0075fc:	adds    	r0, r2, #0
0x0075fe:	ldr     	r2, [r0, #0x18]
0x007600:	cmp     	r2, #0
0x007602:	beq     	#0x760a
0x007604:	ldr     	r7, [r2, #8]
0x007606:	cmp     	r7, r1
0x007608:	blt     	#0x75ee
0x00760a:	str     	r5, [r0, #0x1c]
0x00760c:	ldr     	r0, [r6, #8]
0x00760e:	cmp     	r0, #0
0x007610:	beq     	#0x7672
0x007612:	cmp     	r3, #0
0x007614:	bge     	#0x7618
0x007616:	movs    	r3, #0
0x007618:	ldr     	r0, [r6, #8]
0x00761a:	ldr     	r1, [r0, #8]
0x00761c:	cmp     	r1, #0
0x00761e:	bge     	#0x7624
0x007620:	movs    	r1, #0
0x007622:	str     	r5, [r0, #8]
0x007624:	ldr     	r2, [pc, #0x60]
0x007626:	cmp     	r1, r2
0x007628:	ble     	#0x7632
0x00762a:	adds    	r1, r2, #0
0x00762c:	b       	#0x7632
0x00762e:	movs    	r4, #0
0x007630:	b       	#0x7612
0x007632:	ldr     	r2, [r0, #8]
0x007634:	subs    	r2, r2, r1
0x007636:	str     	r2, [r0, #8]
0x007638:	ldr     	r0, [r0, #0x18]
0x00763a:	cmp     	r0, #0
0x00763c:	bne     	#0x7632
0x00763e:	subs    	r0, r1, r3
0x007640:	cmp     	r0, #0
0x007642:	bgt     	#0x7646
0x007644:	movs    	r0, #0xa
0x007646:	bl      	#0x7574
0x00764a:	b       	#0x7672
0x00764c:	str     	r5, [r4, #8]
0x00764e:	ldr     	r0, [r4, #0x1c]
0x007650:	adds    	r3, r5, #0
0x007652:	str     	r0, [r6, #0xc]
0x007654:	ldr     	r0, [r4, #0x14]
0x007656:	cmp     	r0, #0
0x007658:	beq     	#0x7666
0x00765a:	str     	r0, [sp]
0x00765c:	movs    	r1, #0
0x00765e:	adds    	r0, r4, #0
0x007660:	ldr     	r2, [r4, #0x10]
0x007662:	bl      	#0x7448
0x007666:	ldr     	r1, [r4, #0xc]
0x007668:	cmp     	r1, #0
0x00766a:	beq     	#0x7670
0x00766c:	ldr     	r0, [r4, #0x10]
0x00766e:	blx     	r1
0x007670:	ldr     	r4, [r6, #0xc]
0x007672:	cmp     	r4, #0
0x007674:	beq     	#0x767c
0x007676:	ldr     	r0, [r4, #8]
0x007678:	cmp     	r0, #0
0x00767a:	blt     	#0x764c
0x00767c:	str     	r5, [r6, #0xc]
0x00767e:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_00768c =====
0x00768c:	push    	{r4, r5, r6, r7, lr}
0x00768e:	sub     	sp, #0xc
0x007690:	movs    	r1, #0
0x007692:	movs    	r2, #0
0x007694:	str     	r2, [sp, #8]
0x007696:	str     	r1, [sp]
0x007698:	str     	r1, [sp, #4]
0x00769a:	movs    	r7, #0xf1
0x00769c:	movs    	r6, #0
0x00769e:	adds    	r3, r6, #0
0x0076a0:	lsls    	r7, r7, #9
0x0076a2:	movs    	r1, #0xf
0x0076a4:	movs    	r2, #0x1c
0x0076a6:	adds    	r5, r0, #0
0x0076a8:	adds    	r0, r7, #0
0x0076aa:	bl      	#0x7214
0x0076ae:	movs    	r1, #0
0x0076b0:	str     	r1, [sp]
0x0076b2:	str     	r1, [sp, #4]
0x0076b4:	movs    	r2, #0
0x0076b6:	str     	r2, [sp, #8]
0x0076b8:	movs    	r1, #0x45
0x0076ba:	adds    	r4, r0, #0
0x0076bc:	adds    	r3, r6, #0
0x0076be:	adds    	r0, r7, #0
0x0076c0:	ldr     	r2, [r5, #8]
0x0076c2:	bl      	#0x7214
0x0076c6:	str     	r0, [r4]
0x0076c8:	movs    	r1, #0
0x0076ca:	str     	r1, [sp]
0x0076cc:	str     	r1, [sp, #4]
0x0076ce:	movs    	r2, #0
0x0076d0:	str     	r2, [sp, #8]
0x0076d2:	movs    	r1, #0x45
0x0076d4:	adds    	r3, r6, #0
0x0076d6:	adds    	r0, r7, #0
0x0076d8:	ldr     	r2, [r5, #8]
0x0076da:	bl      	#0x7214
0x0076de:	str     	r0, [r4, #4]
0x0076e0:	movs    	r1, #0
0x0076e2:	str     	r1, [sp]
0x0076e4:	str     	r1, [sp, #4]
0x0076e6:	movs    	r2, #0
0x0076e8:	str     	r2, [sp, #8]
0x0076ea:	movs    	r1, #0x46
0x0076ec:	adds    	r3, r6, #0
0x0076ee:	adds    	r0, r7, #0
0x0076f0:	ldr     	r2, [r5, #8]
0x0076f2:	bl      	#0x7214
0x0076f6:	strb    	r0, [r4, #0xc]
0x0076f8:	movs    	r1, #0
0x0076fa:	str     	r1, [sp]
0x0076fc:	str     	r1, [sp, #4]
0x0076fe:	movs    	r2, #0
0x007700:	str     	r2, [sp, #8]
0x007702:	movs    	r1, #0x47
0x007704:	adds    	r3, r6, #0
0x007706:	adds    	r0, r7, #0
0x007708:	ldr     	r2, [r5, #8]
0x00770a:	bl      	#0x7214
0x00770e:	str     	r0, [r4, #8]
0x007710:	movs    	r1, #0
0x007712:	str     	r1, [sp]
0x007714:	str     	r1, [sp, #4]
0x007716:	movs    	r2, #0
0x007718:	str     	r2, [sp, #8]
0x00771a:	movs    	r1, #0x46
0x00771c:	adds    	r3, r6, #0
0x00771e:	adds    	r0, r7, #0
0x007720:	ldr     	r2, [r5, #8]
0x007722:	bl      	#0x7214
0x007726:	strb    	r0, [r4, #0xd]
0x007728:	movs    	r1, #0
0x00772a:	str     	r1, [sp]
0x00772c:	str     	r1, [sp, #4]
0x00772e:	movs    	r2, #0
0x007730:	str     	r2, [sp, #8]
0x007732:	movs    	r1, #0x45
0x007734:	adds    	r3, r6, #0
0x007736:	adds    	r0, r7, #0
0x007738:	ldr     	r2, [r5, #8]
0x00773a:	bl      	#0x7214
0x00773e:	str     	r0, [r4, #0x10]
0x007740:	movs    	r1, #0
0x007742:	str     	r1, [sp]
0x007744:	str     	r1, [sp, #4]
0x007746:	movs    	r2, #0
0x007748:	str     	r2, [sp, #8]
0x00774a:	movs    	r1, #0x46
0x00774c:	adds    	r3, r6, #0
0x00774e:	adds    	r0, r7, #0
0x007750:	ldr     	r2, [r5, #8]
0x007752:	bl      	#0x7214
0x007756:	lsls    	r0, r0, #0x18
0x007758:	asrs    	r0, r0, #0x18
0x00775a:	adds    	r3, r0, #1
0x00775c:	bne     	#0x7762
0x00775e:	str     	r6, [r4, #0x14]
0x007760:	b       	#0x777a
0x007762:	movs    	r1, #0
0x007764:	str     	r1, [sp]
0x007766:	str     	r1, [sp, #4]
0x007768:	movs    	r2, #0
0x00776a:	str     	r2, [sp, #8]
0x00776c:	movs    	r1, #0x47
0x00776e:	adds    	r3, r6, #0
0x007770:	adds    	r0, r7, #0
0x007772:	ldr     	r2, [r5, #8]
0x007774:	bl      	#0x7214
0x007778:	str     	r0, [r4, #0x14]
0x00777a:	movs    	r1, #0
0x00777c:	str     	r1, [sp]
0x00777e:	str     	r1, [sp, #4]
0x007780:	movs    	r2, #0
0x007782:	str     	r2, [sp, #8]
0x007784:	movs    	r1, #0x46
0x007786:	adds    	r3, r6, #0
0x007788:	adds    	r0, r7, #0
0x00778a:	ldr     	r2, [r5, #8]
0x00778c:	bl      	#0x7214
0x007790:	strb    	r0, [r4, #0x18]
0x007792:	add     	sp, #0xc
0x007794:	adds    	r0, r4, #0
0x007796:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007798 =====
0x007798:	push    	{r4, r5, r6, lr}
0x00779a:	sub     	sp, #0x10
0x00779c:	movs    	r1, #0
0x00779e:	adds    	r5, r0, #0
0x0077a0:	movs    	r2, #0
0x0077a2:	str     	r2, [sp, #8]
0x0077a4:	str     	r1, [sp]
0x0077a6:	str     	r1, [sp, #4]
0x0077a8:	movs    	r6, #0
0x0077aa:	adds    	r3, r6, #0
0x0077ac:	movs    	r1, #0xf
0x0077ae:	movs    	r2, #0x40
0x0077b0:	movs    	r0, #0xf1
0x0077b2:	lsls    	r0, r0, #9
0x0077b4:	bl      	#0x7214
0x0077b8:	adds    	r4, r0, #0
0x0077ba:	adds    	r0, r5, #0
0x0077bc:	bl      	#0x7950
0x0077c0:	str     	r0, [r4]
0x0077c2:	movs    	r1, #0
0x0077c4:	str     	r1, [sp]
0x0077c6:	str     	r1, [sp, #4]
0x0077c8:	movs    	r2, #0
0x0077ca:	str     	r2, [sp, #8]
0x0077cc:	movs    	r1, #0x45
0x0077ce:	movs    	r0, #0xf1
0x0077d0:	adds    	r3, r6, #0
0x0077d2:	lsls    	r0, r0, #9
0x0077d4:	ldr     	r2, [r5, #8]
0x0077d6:	bl      	#0x7214
0x0077da:	str     	r0, [r4, #4]
0x0077dc:	movs    	r1, #0
0x0077de:	str     	r1, [sp]
0x0077e0:	str     	r1, [sp, #4]
0x0077e2:	movs    	r2, #0
0x0077e4:	str     	r2, [sp, #8]
0x0077e6:	movs    	r1, #0x45
0x0077e8:	movs    	r0, #0xf1
0x0077ea:	adds    	r3, r6, #0
0x0077ec:	lsls    	r0, r0, #9
0x0077ee:	ldr     	r2, [r5, #8]
0x0077f0:	bl      	#0x7214
0x0077f4:	str     	r0, [r4, #8]
0x0077f6:	movs    	r1, #0
0x0077f8:	str     	r1, [sp]
0x0077fa:	str     	r1, [sp, #4]
0x0077fc:	movs    	r2, #0
0x0077fe:	str     	r2, [sp, #8]
0x007800:	movs    	r1, #0x45
0x007802:	movs    	r0, #0xf1
0x007804:	adds    	r3, r6, #0
0x007806:	lsls    	r0, r0, #9
0x007808:	ldr     	r2, [r5, #8]
0x00780a:	bl      	#0x7214
0x00780e:	str     	r0, [r4, #0x30]
0x007810:	movs    	r1, #0
0x007812:	str     	r1, [sp]
0x007814:	str     	r1, [sp, #4]
0x007816:	movs    	r2, #0
0x007818:	str     	r2, [sp, #8]
0x00781a:	movs    	r1, #0xe2
0x00781c:	movs    	r0, #0xf1
0x00781e:	adds    	r3, r6, #0
0x007820:	lsls    	r0, r0, #9
0x007822:	ldr     	r2, [r5, #8]
0x007824:	bl      	#0x7214
0x007828:	strh    	r0, [r4, #0x14]
0x00782a:	movs    	r1, #0
0x00782c:	str     	r1, [sp]
0x00782e:	str     	r1, [sp, #4]
0x007830:	movs    	r2, #0
0x007832:	str     	r2, [sp, #8]
0x007834:	movs    	r1, #0xe2
0x007836:	movs    	r0, #0xf1
0x007838:	adds    	r3, r6, #0
0x00783a:	lsls    	r0, r0, #9
0x00783c:	ldr     	r2, [r5, #8]
0x00783e:	bl      	#0x7214
0x007842:	strh    	r0, [r4, #0x10]
0x007844:	movs    	r1, #0
0x007846:	str     	r1, [sp]
0x007848:	str     	r1, [sp, #4]
0x00784a:	movs    	r2, #0
0x00784c:	str     	r2, [sp, #8]
0x00784e:	movs    	r1, #0x47
0x007850:	movs    	r0, #0xf1
0x007852:	adds    	r3, r6, #0
0x007854:	lsls    	r0, r0, #9
0x007856:	ldr     	r2, [r5, #8]
0x007858:	bl      	#0x7214
0x00785c:	str     	r0, [r4, #0xc]
0x00785e:	movs    	r1, #0
0x007860:	str     	r1, [sp]
0x007862:	str     	r1, [sp, #4]
0x007864:	movs    	r2, #0
0x007866:	str     	r2, [sp, #8]
0x007868:	movs    	r1, #0x45
0x00786a:	movs    	r0, #0xf1
0x00786c:	adds    	r3, r6, #0
0x00786e:	lsls    	r0, r0, #9
0x007870:	ldr     	r2, [r5, #8]
0x007872:	bl      	#0x7214
0x007876:	str     	r0, [r4, #0x18]
0x007878:	movs    	r1, #0
0x00787a:	str     	r1, [sp]
0x00787c:	str     	r1, [sp, #4]
0x00787e:	movs    	r2, #0
0x007880:	str     	r2, [sp, #8]
0x007882:	movs    	r1, #0x45
0x007884:	movs    	r0, #0xf1
0x007886:	adds    	r3, r6, #0
0x007888:	lsls    	r0, r0, #9
0x00788a:	ldr     	r2, [r5, #8]
0x00788c:	bl      	#0x7214
0x007890:	str     	r0, [r4, #0x20]
0x007892:	movs    	r1, #0
0x007894:	str     	r1, [sp]
0x007896:	str     	r1, [sp, #4]
0x007898:	movs    	r2, #0
0x00789a:	str     	r2, [sp, #8]
0x00789c:	movs    	r1, #0x45
0x00789e:	movs    	r0, #0xf1
0x0078a0:	adds    	r3, r6, #0
0x0078a2:	lsls    	r0, r0, #9
0x0078a4:	ldr     	r2, [r5, #8]
0x0078a6:	bl      	#0x7214
0x0078aa:	str     	r0, [r4, #0x1c]
0x0078ac:	movs    	r1, #0
0x0078ae:	str     	r1, [sp]
0x0078b0:	str     	r1, [sp, #4]
0x0078b2:	movs    	r2, #0
0x0078b4:	str     	r2, [sp, #8]
0x0078b6:	movs    	r1, #0x45
0x0078b8:	movs    	r0, #0xf1
0x0078ba:	adds    	r3, r6, #0
0x0078bc:	lsls    	r0, r0, #9
0x0078be:	ldr     	r2, [r5, #8]
0x0078c0:	bl      	#0x7214
0x0078c4:	str     	r0, [r4, #0x24]
0x0078c6:	movs    	r1, #0
0x0078c8:	str     	r1, [sp]

; ===== candidate_007950 =====
0x007950:	push    	{r4, r5, r6, r7, lr}
0x007952:	sub     	sp, #0x24
0x007954:	movs    	r1, #0
0x007956:	str     	r1, [sp]
0x007958:	str     	r1, [sp, #4]
0x00795a:	movs    	r2, #0
0x00795c:	str     	r2, [sp, #8]
0x00795e:	adds    	r4, r0, #0
0x007960:	ldr     	r2, [r0, #8]
0x007962:	movs    	r5, #0
0x007964:	adds    	r3, r5, #0
0x007966:	movs    	r0, #0xf1
0x007968:	movs    	r1, #0x45
0x00796a:	lsls    	r0, r0, #9
0x00796c:	bl      	#0x7214
0x007970:	str     	r0, [sp, #0x20]
0x007972:	movs    	r1, #0
0x007974:	str     	r1, [sp]
0x007976:	str     	r1, [sp, #4]
0x007978:	movs    	r2, #0
0x00797a:	str     	r2, [sp, #8]
0x00797c:	movs    	r1, #0x47
0x00797e:	movs    	r0, #0xf1
0x007980:	adds    	r3, r5, #0
0x007982:	lsls    	r0, r0, #9
0x007984:	ldr     	r2, [r4, #8]
0x007986:	bl      	#0x7214
0x00798a:	movs    	r1, #0
0x00798c:	str     	r1, [sp]
0x00798e:	str     	r1, [sp, #4]
0x007990:	str     	r0, [sp, #0x1c]
0x007992:	movs    	r2, #0
0x007994:	str     	r2, [sp, #8]
0x007996:	movs    	r0, #0xf1
0x007998:	movs    	r1, #0xe2
0x00799a:	adds    	r3, r5, #0
0x00799c:	lsls    	r0, r0, #9
0x00799e:	ldr     	r2, [r4, #8]
0x0079a0:	bl      	#0x7214
0x0079a4:	lsls    	r1, r0, #0x10
0x0079a6:	asrs    	r1, r1, #0x10
0x0079a8:	str     	r1, [sp, #0x18]
0x0079aa:	movs    	r1, #0
0x0079ac:	str     	r1, [sp]
0x0079ae:	str     	r1, [sp, #4]
0x0079b0:	movs    	r2, #0
0x0079b2:	str     	r2, [sp, #8]
0x0079b4:	movs    	r1, #0xe2
0x0079b6:	movs    	r0, #0xf1
0x0079b8:	adds    	r3, r5, #0
0x0079ba:	lsls    	r0, r0, #9
0x0079bc:	ldr     	r2, [r4, #8]
0x0079be:	bl      	#0x7214
0x0079c2:	lsls    	r1, r0, #0x10
0x0079c4:	asrs    	r1, r1, #0x10
0x0079c6:	str     	r1, [sp, #0x14]
0x0079c8:	movs    	r1, #0
0x0079ca:	str     	r1, [sp]
0x0079cc:	str     	r1, [sp, #4]
0x0079ce:	movs    	r2, #0
0x0079d0:	str     	r2, [sp, #8]
0x0079d2:	movs    	r1, #0x45
0x0079d4:	movs    	r0, #0xf1
0x0079d6:	adds    	r3, r5, #0
0x0079d8:	lsls    	r0, r0, #9
0x0079da:	ldr     	r2, [r4, #8]
0x0079dc:	bl      	#0x7214
0x0079e0:	movs    	r1, #0
0x0079e2:	str     	r1, [sp]
0x0079e4:	str     	r1, [sp, #4]
0x0079e6:	str     	r0, [sp, #0x10]
0x0079e8:	movs    	r2, #0
0x0079ea:	str     	r2, [sp, #8]
0x0079ec:	movs    	r0, #0xf1
0x0079ee:	movs    	r1, #0x45
0x0079f0:	adds    	r3, r5, #0
0x0079f2:	lsls    	r0, r0, #9
0x0079f4:	ldr     	r2, [r4, #8]
0x0079f6:	bl      	#0x7214
0x0079fa:	movs    	r1, #0
0x0079fc:	str     	r1, [sp]
0x0079fe:	str     	r1, [sp, #4]
0x007a00:	str     	r0, [sp, #0xc]
0x007a02:	movs    	r2, #0
0x007a04:	str     	r2, [sp, #8]
0x007a06:	movs    	r0, #0xf1
0x007a08:	movs    	r1, #0x47
0x007a0a:	adds    	r3, r5, #0
0x007a0c:	lsls    	r0, r0, #9
0x007a0e:	ldr     	r2, [r4, #8]
0x007a10:	bl      	#0x7214
0x007a14:	movs    	r1, #0
0x007a16:	str     	r1, [sp]
0x007a18:	str     	r1, [sp, #4]
0x007a1a:	adds    	r6, r0, #0
0x007a1c:	movs    	r2, #0
0x007a1e:	str     	r2, [sp, #8]
0x007a20:	movs    	r0, #0xf1
0x007a22:	adds    	r3, r5, #0
0x007a24:	movs    	r1, #0x45
0x007a26:	lsls    	r0, r0, #9
0x007a28:	ldr     	r2, [r4, #8]
0x007a2a:	bl      	#0x7214
0x007a2e:	movs    	r1, #0
0x007a30:	str     	r1, [sp]
0x007a32:	str     	r1, [sp, #4]
0x007a34:	adds    	r7, r0, #0
0x007a36:	movs    	r2, #0
0x007a38:	str     	r2, [sp, #8]
0x007a3a:	movs    	r0, #0xf1
0x007a3c:	adds    	r3, r5, #0
0x007a3e:	movs    	r1, #0x47
0x007a40:	lsls    	r0, r0, #9
0x007a42:	ldr     	r2, [r4, #8]
0x007a44:	bl      	#0x7214
0x007a48:	movs    	r1, #0
0x007a4a:	adds    	r4, r0, #0
0x007a4c:	movs    	r2, #0
0x007a4e:	str     	r2, [sp, #8]
0x007a50:	str     	r1, [sp]
0x007a52:	str     	r1, [sp, #4]
0x007a54:	movs    	r1, #0xf
0x007a56:	movs    	r2, #0x24
0x007a58:	movs    	r0, #0xf1
0x007a5a:	adds    	r3, r5, #0
0x007a5c:	lsls    	r0, r0, #9
0x007a5e:	bl      	#0x7214
0x007a62:	ldr     	r1, [sp, #0x20]
0x007a64:	str     	r1, [r0]
0x007a66:	ldr     	r1, [sp, #0x1c]
0x007a68:	str     	r1, [r0, #4]
0x007a6a:	ldr     	r1, [sp, #0x18]
0x007a6c:	str     	r1, [r0, #8]
0x007a6e:	ldr     	r1, [sp, #0x14]
0x007a70:	str     	r1, [r0, #0xc]
0x007a72:	ldr     	r1, [sp, #0x10]
0x007a74:	str     	r1, [r0, #0x10]
0x007a76:	ldr     	r1, [sp, #0xc]
0x007a78:	adds    	r0, #0x14
0x007a7a:	stm     	r0!, {r1, r6, r7}
0x007a7c:	subs    	r0, #0x20

; ===== candidate_007a84 =====
0x007a84:	push    	{r4, r5, r6, r7, lr}
0x007a86:	ldr     	r6, [pc, #0xb4]
0x007a88:	sub     	sp, #0xc
0x007a8a:	add     	r6, sb
0x007a8c:	ldr     	r5, [r6, #0x28]
0x007a8e:	cmp     	r5, #0
0x007a90:	beq     	#0x7b36
0x007a92:	movs    	r1, #0
0x007a94:	movs    	r2, #0
0x007a96:	str     	r2, [sp, #8]
0x007a98:	str     	r1, [sp]
0x007a9a:	str     	r1, [sp, #4]
0x007a9c:	movs    	r1, #0x11
0x007a9e:	adds    	r2, r5, #0
0x007aa0:	movs    	r4, #0
0x007aa2:	movs    	r3, #4
0x007aa4:	movs    	r0, #0xf1
0x007aa6:	lsls    	r0, r0, #9
0x007aa8:	bl      	#0x7214
0x007aac:	adds    	r6, r0, #0
0x007aae:	movs    	r7, #0
0x007ab0:	cmp     	r0, #0
0x007ab2:	ble     	#0x7b18
0x007ab4:	ldr     	r1, [pc, #0x84]
0x007ab6:	lsls    	r0, r4, #2
0x007ab8:	add     	r1, sb
0x007aba:	ldr     	r1, [r1, #0x28]
0x007abc:	ldr     	r5, [r1, r0]
0x007abe:	ldr     	r3, [r5, #8]
0x007ac0:	cmp     	r3, #0
0x007ac2:	beq     	#0x7adc
0x007ac4:	movs    	r2, #0
0x007ac6:	movs    	r1, #0
0x007ac8:	str     	r2, [sp, #8]
0x007aca:	adds    	r2, r3, #0
0x007acc:	str     	r1, [sp]
0x007ace:	str     	r1, [sp, #4]
0x007ad0:	movs    	r1, #9
0x007ad2:	adds    	r3, r7, #0
0x007ad4:	movs    	r0, #0xf1
0x007ad6:	lsls    	r0, r0, #9
0x007ad8:	bl      	#0x7214
0x007adc:	ldr     	r3, [r5, #0x14]
0x007ade:	cmp     	r3, #0
0x007ae0:	beq     	#0x7afa
0x007ae2:	movs    	r2, #0
0x007ae4:	movs    	r1, #0
0x007ae6:	str     	r2, [sp, #8]
0x007ae8:	adds    	r2, r3, #0
0x007aea:	str     	r1, [sp]
0x007aec:	str     	r1, [sp, #4]
0x007aee:	movs    	r1, #9
0x007af0:	adds    	r3, r7, #0
0x007af2:	movs    	r0, #0xf1
0x007af4:	lsls    	r0, r0, #9
0x007af6:	bl      	#0x7214
0x007afa:	movs    	r1, #0
0x007afc:	movs    	r2, #0
0x007afe:	str     	r2, [sp, #8]
0x007b00:	str     	r1, [sp]
0x007b02:	str     	r1, [sp, #4]
0x007b04:	adds    	r3, r7, #0
0x007b06:	adds    	r2, r5, #0
0x007b08:	movs    	r1, #9
0x007b0a:	movs    	r0, #0xf1
0x007b0c:	lsls    	r0, r0, #9
0x007b0e:	bl      	#0x7214
0x007b12:	adds    	r4, #1
0x007b14:	cmp     	r4, r6
0x007b16:	blt     	#0x7ab4
0x007b18:	movs    	r1, #0
0x007b1a:	str     	r1, [sp]
0x007b1c:	str     	r1, [sp, #4]
0x007b1e:	movs    	r2, #0
0x007b20:	ldr     	r4, [pc, #0x18]
0x007b22:	str     	r2, [sp, #8]
0x007b24:	movs    	r1, #9
0x007b26:	adds    	r3, r7, #0
0x007b28:	movs    	r0, #0xf1
0x007b2a:	add     	r4, sb
0x007b2c:	ldr     	r2, [r4, #0x28]
0x007b2e:	lsls    	r0, r0, #9
0x007b30:	bl      	#0x7214
0x007b34:	str     	r7, [r4, #0x28]
0x007b36:	add     	sp, #0xc
0x007b38:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007b40 =====
0x007b40:	push    	{r4, r5, r6, lr}
0x007b42:	sub     	sp, #0x10
0x007b44:	adds    	r4, r0, #0
0x007b46:	beq     	#0x7bb8
0x007b48:	movs    	r6, #0xf1
0x007b4a:	ldr     	r3, [r4, #4]
0x007b4c:	lsls    	r6, r6, #9
0x007b4e:	movs    	r5, #0
0x007b50:	cmp     	r3, #0
0x007b52:	beq     	#0x7b6a
0x007b54:	movs    	r2, #0
0x007b56:	movs    	r1, #0
0x007b58:	str     	r2, [sp, #8]
0x007b5a:	adds    	r2, r3, #0
0x007b5c:	str     	r1, [sp]
0x007b5e:	str     	r1, [sp, #4]
0x007b60:	movs    	r1, #9
0x007b62:	adds    	r3, r5, #0
0x007b64:	adds    	r0, r6, #0
0x007b66:	bl      	#0x7214
0x007b6a:	ldr     	r3, [r4, #0x20]
0x007b6c:	cmp     	r3, #0
0x007b6e:	beq     	#0x7b86
0x007b70:	movs    	r2, #0
0x007b72:	movs    	r1, #0
0x007b74:	str     	r2, [sp, #8]
0x007b76:	adds    	r2, r3, #0
0x007b78:	str     	r1, [sp]
0x007b7a:	str     	r1, [sp, #4]
0x007b7c:	movs    	r1, #9
0x007b7e:	adds    	r3, r5, #0
0x007b80:	adds    	r0, r6, #0
0x007b82:	bl      	#0x7214
0x007b86:	ldr     	r3, [r4, #0x18]
0x007b88:	cmp     	r3, #0
0x007b8a:	beq     	#0x7ba2
0x007b8c:	movs    	r2, #0
0x007b8e:	movs    	r1, #0
0x007b90:	str     	r2, [sp, #8]
0x007b92:	adds    	r2, r3, #0
0x007b94:	str     	r1, [sp]
0x007b96:	str     	r1, [sp, #4]
0x007b98:	movs    	r1, #9
0x007b9a:	adds    	r3, r5, #0
0x007b9c:	adds    	r0, r6, #0
0x007b9e:	bl      	#0x7214
0x007ba2:	movs    	r1, #0
0x007ba4:	movs    	r2, #0
0x007ba6:	str     	r2, [sp, #8]
0x007ba8:	str     	r1, [sp]
0x007baa:	str     	r1, [sp, #4]
0x007bac:	movs    	r1, #9
0x007bae:	adds    	r2, r4, #0
0x007bb0:	adds    	r3, r5, #0
0x007bb2:	adds    	r0, r6, #0
0x007bb4:	bl      	#0x7214
0x007bb8:	add     	sp, #0x10
0x007bba:	pop     	{r4, r5, r6, pc}

; ===== candidate_007bbc =====
0x007bbc:	push    	{r4, r5, r6, r7, lr}
0x007bbe:	ldr     	r4, [pc, #0xcc]
0x007bc0:	movs    	r6, #0
0x007bc2:	add     	r4, sb
0x007bc4:	ldr     	r5, [r4, #0x24]
0x007bc6:	sub     	sp, #0xc
0x007bc8:	cmp     	r5, #0
0x007bca:	beq     	#0x7c62
0x007bcc:	movs    	r1, #0
0x007bce:	movs    	r2, #0
0x007bd0:	str     	r2, [sp, #8]
0x007bd2:	str     	r1, [sp]
0x007bd4:	str     	r1, [sp, #4]
0x007bd6:	movs    	r1, #0x11
0x007bd8:	adds    	r2, r5, #0
0x007bda:	movs    	r4, #0
0x007bdc:	movs    	r3, #4
0x007bde:	movs    	r0, #0xf1
0x007be0:	lsls    	r0, r0, #9
0x007be2:	bl      	#0x7214
0x007be6:	adds    	r7, r0, #0
0x007be8:	cmp     	r0, #0
0x007bea:	ble     	#0x7c44
0x007bec:	ldr     	r1, [pc, #0x9c]
0x007bee:	lsls    	r0, r4, #2
0x007bf0:	add     	r1, sb
0x007bf2:	ldr     	r1, [r1, #0x24]
0x007bf4:	movs    	r2, #0
0x007bf6:	ldr     	r5, [r1, r0]
0x007bf8:	movs    	r1, #0
0x007bfa:	str     	r1, [sp]
0x007bfc:	str     	r1, [sp, #4]
0x007bfe:	movs    	r1, #9
0x007c00:	str     	r2, [sp, #8]
0x007c02:	movs    	r0, #0xf1
0x007c04:	adds    	r3, r6, #0
0x007c06:	lsls    	r0, r0, #9
0x007c08:	ldr     	r2, [r5, #4]
0x007c0a:	bl      	#0x7214
0x007c0e:	movs    	r1, #0
0x007c10:	str     	r1, [sp]
0x007c12:	str     	r1, [sp, #4]
0x007c14:	movs    	r2, #0
0x007c16:	str     	r2, [sp, #8]
0x007c18:	movs    	r1, #9
0x007c1a:	adds    	r3, r6, #0
0x007c1c:	movs    	r0, #0xf1
0x007c1e:	lsls    	r0, r0, #9
0x007c20:	ldr     	r2, [r5, #0xc]
0x007c22:	bl      	#0x7214
0x007c26:	movs    	r1, #0
0x007c28:	movs    	r2, #0
0x007c2a:	str     	r2, [sp, #8]
0x007c2c:	str     	r1, [sp]
0x007c2e:	str     	r1, [sp, #4]
0x007c30:	adds    	r3, r6, #0
0x007c32:	adds    	r2, r5, #0
0x007c34:	movs    	r1, #9
0x007c36:	movs    	r0, #0xf1
0x007c38:	lsls    	r0, r0, #9
0x007c3a:	bl      	#0x7214
0x007c3e:	adds    	r4, #1
0x007c40:	cmp     	r4, r7
0x007c42:	blt     	#0x7bec
0x007c44:	movs    	r1, #0
0x007c46:	str     	r1, [sp]
0x007c48:	str     	r1, [sp, #4]
0x007c4a:	movs    	r2, #0
0x007c4c:	ldr     	r4, [pc, #0x3c]
0x007c4e:	str     	r2, [sp, #8]
0x007c50:	movs    	r1, #9
0x007c52:	adds    	r3, r6, #0
0x007c54:	movs    	r0, #0xf1
0x007c56:	add     	r4, sb
0x007c58:	ldr     	r2, [r4, #0x24]
0x007c5a:	lsls    	r0, r0, #9
0x007c5c:	bl      	#0x7214
0x007c60:	str     	r6, [r4, #0x24]
0x007c62:	ldr     	r4, [pc, #0x28]
0x007c64:	add     	r4, sb
0x007c66:	ldr     	r5, [r4, #0x60]
0x007c68:	cmp     	r5, #0
0x007c6a:	beq     	#0x7c86
0x007c6c:	movs    	r1, #0
0x007c6e:	movs    	r2, #0
0x007c70:	str     	r2, [sp, #8]
0x007c72:	str     	r1, [sp]
0x007c74:	str     	r1, [sp, #4]
0x007c76:	adds    	r3, r6, #0
0x007c78:	adds    	r2, r5, #0
0x007c7a:	movs    	r1, #0x12
0x007c7c:	movs    	r0, #0xf1
0x007c7e:	lsls    	r0, r0, #9
0x007c80:	bl      	#0x7214
0x007c84:	str     	r6, [r4, #0x60]
0x007c86:	add     	sp, #0xc
0x007c88:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007c90 =====
0x007c90:	push    	{r4, r5, r6, r7, lr}
0x007c92:	ldr     	r6, [pc, #0x5c]
0x007c94:	sub     	sp, #0xc
0x007c96:	add     	r6, sb
0x007c98:	ldr     	r4, [r6, #0x54]
0x007c9a:	cmp     	r4, #0
0x007c9c:	beq     	#0x7ce6
0x007c9e:	movs    	r1, #0
0x007ca0:	movs    	r2, #0
0x007ca2:	str     	r2, [sp, #8]
0x007ca4:	str     	r1, [sp]
0x007ca6:	str     	r1, [sp, #4]
0x007ca8:	movs    	r7, #0xf1
0x007caa:	lsls    	r7, r7, #9
0x007cac:	movs    	r1, #0x11
0x007cae:	adds    	r2, r4, #0
0x007cb0:	movs    	r3, #4
0x007cb2:	adds    	r0, r7, #0
0x007cb4:	bl      	#0x7214
0x007cb8:	adds    	r5, r0, #0
0x007cba:	movs    	r4, #0
0x007cbc:	cmp     	r0, #0
0x007cbe:	ble     	#0x7cd0
0x007cc0:	ldr     	r1, [r6, #0x54]
0x007cc2:	lsls    	r0, r4, #2
0x007cc4:	ldr     	r0, [r1, r0]
0x007cc6:	bl      	#0x7b40
0x007cca:	adds    	r4, #1
0x007ccc:	cmp     	r4, r5
0x007cce:	blt     	#0x7cc0
0x007cd0:	movs    	r1, #0
0x007cd2:	str     	r1, [sp]
0x007cd4:	str     	r1, [sp, #4]
0x007cd6:	movs    	r2, #0
0x007cd8:	str     	r2, [sp, #8]
0x007cda:	movs    	r1, #9
0x007cdc:	movs    	r3, #0
0x007cde:	adds    	r0, r7, #0
0x007ce0:	ldr     	r2, [r6, #0x54]
0x007ce2:	bl      	#0x7214
0x007ce6:	movs    	r3, #0
0x007ce8:	str     	r3, [r6, #0x54]
0x007cea:	add     	sp, #0xc
0x007cec:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007cf4 =====
0x007cf4:	push    	{r0, r4, r5, r6, r7, lr}
0x007cf6:	sub     	sp, #0x10
0x007cf8:	movs    	r1, #0
0x007cfa:	movs    	r5, #0xff
0x007cfc:	movs    	r4, #0
0x007cfe:	movs    	r2, #0
0x007d00:	str     	r2, [sp, #8]
0x007d02:	adds    	r3, r4, #0
0x007d04:	adds    	r5, #0x32
0x007d06:	str     	r1, [sp]
0x007d08:	str     	r1, [sp, #4]
0x007d0a:	movs    	r1, #0x17
0x007d0c:	adds    	r2, r5, #0
0x007d0e:	movs    	r0, #0xf1
0x007d10:	lsls    	r0, r0, #9
0x007d12:	bl      	#0x7214
0x007d16:	movs    	r1, #0
0x007d18:	movs    	r2, #0
0x007d1a:	str     	r2, [sp, #8]
0x007d1c:	str     	r1, [sp]
0x007d1e:	str     	r1, [sp, #4]
0x007d20:	movs    	r1, #0xe1
0x007d22:	movs    	r2, #0x1d
0x007d24:	adds    	r3, r4, #0
0x007d26:	movs    	r0, #0xf1
0x007d28:	lsls    	r0, r0, #9
0x007d2a:	bl      	#0x7214
0x007d2e:	movs    	r1, #0
0x007d30:	adds    	r6, r0, #0
0x007d32:	movs    	r2, #0
0x007d34:	str     	r2, [sp, #8]
0x007d36:	str     	r1, [sp]
0x007d38:	str     	r1, [sp, #4]
0x007d3a:	movs    	r1, #0xe1
0x007d3c:	movs    	r2, #0x18
0x007d3e:	movs    	r0, #0xf1
0x007d40:	adds    	r3, r4, #0
0x007d42:	lsls    	r0, r0, #9
0x007d44:	bl      	#0x7214
0x007d48:	ldr     	r7, [r0, #0xc]
0x007d4a:	movs    	r1, #0
0x007d4c:	movs    	r2, #0
0x007d4e:	str     	r2, [sp, #8]
0x007d50:	str     	r1, [sp]
0x007d52:	str     	r1, [sp, #4]
0x007d54:	movs    	r1, #0xe1
0x007d56:	movs    	r2, #0x18
0x007d58:	movs    	r0, #0xf1
0x007d5a:	adds    	r3, r4, #0
0x007d5c:	lsls    	r0, r0, #9
0x007d5e:	bl      	#0x7214
0x007d62:	ldr     	r3, [r0, #8]
0x007d64:	movs    	r2, #0
0x007d66:	str     	r2, [sp, #8]
0x007d68:	adds    	r2, r5, #0
0x007d6a:	movs    	r0, #0xf1
0x007d6c:	movs    	r1, #0x52
0x007d6e:	lsls    	r0, r0, #9
0x007d70:	str     	r7, [sp]
0x007d72:	str     	r6, [sp, #4]
0x007d74:	bl      	#0x7214
0x007d78:	movs    	r1, #0
0x007d7a:	movs    	r2, #0
0x007d7c:	str     	r1, [sp]
0x007d7e:	str     	r1, [sp, #4]
0x007d80:	movs    	r1, #0x49
0x007d82:	str     	r2, [sp, #8]
0x007d84:	adds    	r3, r4, #0
0x007d86:	movs    	r0, #0xf1
0x007d88:	lsls    	r0, r0, #9
0x007d8a:	ldr     	r2, [sp, #0x10]
0x007d8c:	bl      	#0x7214
0x007d90:	movs    	r1, #0
0x007d92:	movs    	r2, #0
0x007d94:	str     	r2, [sp, #8]
0x007d96:	str     	r1, [sp]
0x007d98:	str     	r1, [sp, #4]
0x007d9a:	movs    	r1, #0x1b
0x007d9c:	movs    	r2, #1
0x007d9e:	adds    	r3, r4, #0
0x007da0:	movs    	r0, #0xf1
0x007da2:	lsls    	r0, r0, #9
0x007da4:	bl      	#0x7214
0x007da8:	add     	sp, #0x14
0x007daa:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007dac =====
0x007dac:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x007dae:	sub     	sp, #0xc
0x007db0:	movs    	r1, #0
0x007db2:	movs    	r5, #0xff
0x007db4:	movs    	r4, #0
0x007db6:	movs    	r2, #0
0x007db8:	str     	r2, [sp, #8]
0x007dba:	adds    	r3, r4, #0
0x007dbc:	adds    	r5, #0xa0
0x007dbe:	str     	r1, [sp]
0x007dc0:	str     	r1, [sp, #4]
0x007dc2:	movs    	r1, #0x17
0x007dc4:	adds    	r2, r5, #0
0x007dc6:	movs    	r0, #0xf1
0x007dc8:	lsls    	r0, r0, #9
0x007dca:	bl      	#0x7214
0x007dce:	movs    	r1, #0
0x007dd0:	movs    	r2, #0
0x007dd2:	str     	r2, [sp, #8]
0x007dd4:	str     	r1, [sp]
0x007dd6:	str     	r1, [sp, #4]
0x007dd8:	movs    	r1, #0xe1
0x007dda:	movs    	r2, #0x1d
0x007ddc:	adds    	r3, r4, #0
0x007dde:	movs    	r0, #0xf1
0x007de0:	lsls    	r0, r0, #9
0x007de2:	bl      	#0x7214
0x007de6:	movs    	r1, #0
0x007de8:	adds    	r6, r0, #0
0x007dea:	movs    	r2, #0
0x007dec:	str     	r2, [sp, #8]
0x007dee:	str     	r1, [sp]
0x007df0:	str     	r1, [sp, #4]
0x007df2:	movs    	r1, #0xe1
0x007df4:	movs    	r2, #0x18
0x007df6:	movs    	r0, #0xf1
0x007df8:	adds    	r3, r4, #0
0x007dfa:	lsls    	r0, r0, #9
0x007dfc:	bl      	#0x7214
0x007e00:	ldr     	r7, [r0, #0xc]
0x007e02:	movs    	r1, #0
0x007e04:	movs    	r2, #0
0x007e06:	str     	r2, [sp, #8]
0x007e08:	str     	r1, [sp]
0x007e0a:	str     	r1, [sp, #4]
0x007e0c:	movs    	r1, #0xe1
0x007e0e:	movs    	r2, #0x18
0x007e10:	movs    	r0, #0xf1
0x007e12:	adds    	r3, r4, #0
0x007e14:	lsls    	r0, r0, #9
0x007e16:	bl      	#0x7214
0x007e1a:	ldr     	r3, [r0, #8]
0x007e1c:	movs    	r2, #0
0x007e1e:	str     	r2, [sp, #8]
0x007e20:	adds    	r2, r5, #0
0x007e22:	movs    	r0, #0xf1
0x007e24:	movs    	r1, #0x52
0x007e26:	lsls    	r0, r0, #9
0x007e28:	str     	r7, [sp]
0x007e2a:	str     	r6, [sp, #4]
0x007e2c:	bl      	#0x7214
0x007e30:	movs    	r1, #0
0x007e32:	movs    	r2, #0
0x007e34:	str     	r1, [sp]
0x007e36:	str     	r1, [sp, #4]
0x007e38:	movs    	r1, #0x19
0x007e3a:	str     	r2, [sp, #8]
0x007e3c:	adds    	r3, r4, #0
0x007e3e:	movs    	r0, #0xf1
0x007e40:	lsls    	r0, r0, #9
0x007e42:	ldr     	r2, [sp, #0xc]
0x007e44:	bl      	#0x7214
0x007e48:	movs    	r1, #0
0x007e4a:	movs    	r2, #0
0x007e4c:	str     	r1, [sp]
0x007e4e:	str     	r1, [sp, #4]
0x007e50:	movs    	r1, #0x19
0x007e52:	str     	r2, [sp, #8]
0x007e54:	adds    	r3, r4, #0
0x007e56:	movs    	r0, #0xf1
0x007e58:	lsls    	r0, r0, #9
0x007e5a:	ldr     	r2, [sp, #0x10]
0x007e5c:	bl      	#0x7214
0x007e60:	movs    	r1, #0
0x007e62:	movs    	r2, #0
0x007e64:	str     	r2, [sp, #8]
0x007e66:	str     	r1, [sp]
0x007e68:	str     	r1, [sp, #4]
0x007e6a:	movs    	r1, #0x1b
0x007e6c:	movs    	r2, #1
0x007e6e:	adds    	r3, r4, #0
0x007e70:	movs    	r0, #0xf1
0x007e72:	lsls    	r0, r0, #9
0x007e74:	bl      	#0x7214
0x007e78:	add     	sp, #0x14
0x007e7a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007e7c =====
0x007e7c:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x007e7e:	sub     	sp, #0xc
0x007e80:	movs    	r2, #0
0x007e82:	movs    	r1, #0
0x007e84:	movs    	r4, #0
0x007e86:	adds    	r3, r4, #0
0x007e88:	str     	r2, [sp, #8]
0x007e8a:	adds    	r5, r0, #0
0x007e8c:	adds    	r2, r0, #0
0x007e8e:	str     	r1, [sp]
0x007e90:	str     	r1, [sp, #4]
0x007e92:	movs    	r1, #0x17
0x007e94:	movs    	r0, #0xf1
0x007e96:	lsls    	r0, r0, #9
0x007e98:	bl      	#0x7214
0x007e9c:	movs    	r1, #0
0x007e9e:	movs    	r2, #0
0x007ea0:	str     	r2, [sp, #8]
0x007ea2:	str     	r1, [sp]
0x007ea4:	str     	r1, [sp, #4]
0x007ea6:	movs    	r1, #0xe1
0x007ea8:	movs    	r2, #0x1d
0x007eaa:	adds    	r3, r4, #0
0x007eac:	movs    	r0, #0xf1
0x007eae:	lsls    	r0, r0, #9
0x007eb0:	bl      	#0x7214
0x007eb4:	movs    	r1, #0
0x007eb6:	adds    	r6, r0, #0
0x007eb8:	movs    	r2, #0
0x007eba:	str     	r2, [sp, #8]
0x007ebc:	str     	r1, [sp]
0x007ebe:	str     	r1, [sp, #4]
0x007ec0:	movs    	r1, #0xe1
0x007ec2:	movs    	r2, #0x18
0x007ec4:	movs    	r0, #0xf1
0x007ec6:	adds    	r3, r4, #0
0x007ec8:	lsls    	r0, r0, #9
0x007eca:	bl      	#0x7214
0x007ece:	ldr     	r7, [r0, #0xc]
0x007ed0:	movs    	r1, #0
0x007ed2:	movs    	r2, #0
0x007ed4:	str     	r2, [sp, #8]
0x007ed6:	str     	r1, [sp]
0x007ed8:	str     	r1, [sp, #4]
0x007eda:	movs    	r1, #0xe1
0x007edc:	movs    	r2, #0x18
0x007ede:	movs    	r0, #0xf1
0x007ee0:	adds    	r3, r4, #0
0x007ee2:	lsls    	r0, r0, #9
0x007ee4:	bl      	#0x7214
0x007ee8:	ldr     	r3, [r0, #8]
0x007eea:	movs    	r2, #0
0x007eec:	str     	r2, [sp, #8]
0x007eee:	adds    	r2, r5, #0
0x007ef0:	movs    	r0, #0xf1
0x007ef2:	movs    	r1, #0x52
0x007ef4:	lsls    	r0, r0, #9
0x007ef6:	str     	r7, [sp]
0x007ef8:	str     	r6, [sp, #4]
0x007efa:	bl      	#0x7214
0x007efe:	movs    	r1, #0
0x007f00:	movs    	r2, #0
0x007f02:	str     	r1, [sp]
0x007f04:	str     	r1, [sp, #4]
0x007f06:	movs    	r1, #0x19
0x007f08:	str     	r2, [sp, #8]
0x007f0a:	adds    	r3, r4, #0
0x007f0c:	movs    	r0, #0xf1
0x007f0e:	lsls    	r0, r0, #9
0x007f10:	ldr     	r2, [sp, #0x10]
0x007f12:	bl      	#0x7214
0x007f16:	movs    	r1, #0
0x007f18:	movs    	r2, #0
0x007f1a:	str     	r1, [sp]
0x007f1c:	str     	r1, [sp, #4]
0x007f1e:	movs    	r1, #0x19
0x007f20:	str     	r2, [sp, #8]
0x007f22:	adds    	r3, r4, #0
0x007f24:	movs    	r0, #0xf1
0x007f26:	lsls    	r0, r0, #9
0x007f28:	ldr     	r2, [sp, #0x14]
0x007f2a:	bl      	#0x7214
0x007f2e:	movs    	r1, #0
0x007f30:	movs    	r2, #0
0x007f32:	str     	r1, [sp]
0x007f34:	str     	r1, [sp, #4]
0x007f36:	movs    	r1, #0x19
0x007f38:	str     	r2, [sp, #8]
0x007f3a:	adds    	r3, r4, #0
0x007f3c:	movs    	r0, #0xf1
0x007f3e:	lsls    	r0, r0, #9
0x007f40:	ldr     	r2, [sp, #0x18]
0x007f42:	bl      	#0x7214
0x007f46:	movs    	r1, #0
0x007f48:	movs    	r2, #0
0x007f4a:	str     	r2, [sp, #8]
0x007f4c:	str     	r1, [sp]
0x007f4e:	str     	r1, [sp, #4]
0x007f50:	movs    	r1, #0x1b
0x007f52:	movs    	r2, #1
0x007f54:	adds    	r3, r4, #0
0x007f56:	movs    	r0, #0xf1
0x007f58:	lsls    	r0, r0, #9
0x007f5a:	bl      	#0x7214
0x007f5e:	add     	sp, #0x1c
0x007f60:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007f64 =====
0x007f64:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x007f66:	sub     	sp, #0xc
0x007f68:	movs    	r1, #0
0x007f6a:	movs    	r5, #0xff
0x007f6c:	movs    	r4, #0
0x007f6e:	movs    	r2, #0
0x007f70:	str     	r2, [sp, #8]
0x007f72:	adds    	r3, r4, #0
0x007f74:	adds    	r5, #0x31
0x007f76:	str     	r1, [sp]
0x007f78:	str     	r1, [sp, #4]
0x007f7a:	movs    	r1, #0x17
0x007f7c:	adds    	r2, r5, #0
0x007f7e:	movs    	r0, #0xf1
0x007f80:	lsls    	r0, r0, #9
0x007f82:	bl      	#0x7214
0x007f86:	movs    	r1, #0
0x007f88:	movs    	r2, #0
0x007f8a:	str     	r2, [sp, #8]
0x007f8c:	str     	r1, [sp]
0x007f8e:	str     	r1, [sp, #4]
0x007f90:	movs    	r1, #0xe1
0x007f92:	movs    	r2, #0x1d
0x007f94:	adds    	r3, r4, #0
0x007f96:	movs    	r0, #0xf1
0x007f98:	lsls    	r0, r0, #9
0x007f9a:	bl      	#0x7214
0x007f9e:	movs    	r1, #0
0x007fa0:	adds    	r6, r0, #0
0x007fa2:	movs    	r2, #0
0x007fa4:	str     	r2, [sp, #8]
0x007fa6:	str     	r1, [sp]
0x007fa8:	str     	r1, [sp, #4]
0x007faa:	movs    	r1, #0xe1
0x007fac:	movs    	r2, #0x18
0x007fae:	movs    	r0, #0xf1
0x007fb0:	adds    	r3, r4, #0
0x007fb2:	lsls    	r0, r0, #9
0x007fb4:	bl      	#0x7214
0x007fb8:	ldr     	r7, [r0, #0xc]
0x007fba:	movs    	r1, #0
0x007fbc:	movs    	r2, #0
0x007fbe:	str     	r2, [sp, #8]
0x007fc0:	str     	r1, [sp]
0x007fc2:	str     	r1, [sp, #4]
0x007fc4:	movs    	r1, #0xe1
0x007fc6:	movs    	r2, #0x18
0x007fc8:	movs    	r0, #0xf1
0x007fca:	adds    	r3, r4, #0
0x007fcc:	lsls    	r0, r0, #9
0x007fce:	bl      	#0x7214
0x007fd2:	ldr     	r3, [r0, #8]
0x007fd4:	movs    	r2, #0
0x007fd6:	str     	r2, [sp, #8]
0x007fd8:	adds    	r2, r5, #0
0x007fda:	movs    	r0, #0xf1
0x007fdc:	movs    	r1, #0x52
0x007fde:	lsls    	r0, r0, #9
0x007fe0:	str     	r7, [sp]
0x007fe2:	str     	r6, [sp, #4]
0x007fe4:	bl      	#0x7214
0x007fe8:	movs    	r1, #0
0x007fea:	movs    	r2, #0
0x007fec:	str     	r1, [sp]
0x007fee:	str     	r1, [sp, #4]
0x007ff0:	movs    	r1, #0x19
0x007ff2:	str     	r2, [sp, #8]
0x007ff4:	adds    	r3, r4, #0
0x007ff6:	movs    	r0, #0xf1
0x007ff8:	lsls    	r0, r0, #9
0x007ffa:	ldr     	r2, [sp, #0xc]
0x007ffc:	bl      	#0x7214
0x008000:	movs    	r1, #0
0x008002:	movs    	r2, #0
0x008004:	str     	r1, [sp]
0x008006:	str     	r1, [sp, #4]
0x008008:	movs    	r1, #0x19
0x00800a:	str     	r2, [sp, #8]
0x00800c:	adds    	r3, r4, #0
0x00800e:	movs    	r0, #0xf1
0x008010:	lsls    	r0, r0, #9
0x008012:	ldr     	r2, [sp, #0x10]
0x008014:	bl      	#0x7214
0x008018:	movs    	r1, #0
0x00801a:	movs    	r2, #0
0x00801c:	str     	r2, [sp, #8]
0x00801e:	str     	r1, [sp]
0x008020:	str     	r1, [sp, #4]
0x008022:	movs    	r1, #0x1b
0x008024:	movs    	r2, #1
0x008026:	adds    	r3, r4, #0
0x008028:	movs    	r0, #0xf1
0x00802a:	lsls    	r0, r0, #9
0x00802c:	bl      	#0x7214
0x008030:	add     	sp, #0x14
0x008032:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_008034 =====
0x008034:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x008036:	sub     	sp, #0xc
0x008038:	movs    	r1, #0
0x00803a:	movs    	r5, #0xff
0x00803c:	movs    	r2, #0
0x00803e:	movs    	r4, #0
0x008040:	adds    	r3, r4, #0
0x008042:	str     	r2, [sp, #8]
0x008044:	adds    	r5, #0x45
0x008046:	str     	r1, [sp]
0x008048:	str     	r1, [sp, #4]
0x00804a:	movs    	r1, #0x17
0x00804c:	adds    	r2, r5, #0
0x00804e:	movs    	r0, #0xf1
0x008050:	lsls    	r0, r0, #9
0x008052:	bl      	#0x7214
0x008056:	movs    	r1, #0
0x008058:	movs    	r2, #0
0x00805a:	str     	r2, [sp, #8]
0x00805c:	str     	r1, [sp]
0x00805e:	str     	r1, [sp, #4]
0x008060:	movs    	r1, #0xe1
0x008062:	movs    	r2, #0x1d
0x008064:	adds    	r3, r4, #0
0x008066:	movs    	r0, #0xf1
0x008068:	lsls    	r0, r0, #9
0x00806a:	bl      	#0x7214
0x00806e:	movs    	r1, #0
0x008070:	adds    	r6, r0, #0
0x008072:	movs    	r2, #0
0x008074:	str     	r2, [sp, #8]
0x008076:	str     	r1, [sp]
0x008078:	str     	r1, [sp, #4]
0x00807a:	movs    	r1, #0xe1
0x00807c:	movs    	r2, #0x18
0x00807e:	movs    	r0, #0xf1
0x008080:	adds    	r3, r4, #0
0x008082:	lsls    	r0, r0, #9
0x008084:	bl      	#0x7214
0x008088:	ldr     	r7, [r0, #0xc]
0x00808a:	movs    	r1, #0
0x00808c:	movs    	r2, #0
0x00808e:	str     	r2, [sp, #8]
0x008090:	str     	r1, [sp]
0x008092:	str     	r1, [sp, #4]
0x008094:	movs    	r1, #0xe1
0x008096:	movs    	r2, #0x18
0x008098:	movs    	r0, #0xf1
0x00809a:	adds    	r3, r4, #0
0x00809c:	lsls    	r0, r0, #9
0x00809e:	bl      	#0x7214
0x0080a2:	ldr     	r3, [r0, #8]
0x0080a4:	movs    	r2, #0
0x0080a6:	str     	r2, [sp, #8]
0x0080a8:	adds    	r2, r5, #0
0x0080aa:	movs    	r0, #0xf1
0x0080ac:	movs    	r1, #0x52
0x0080ae:	lsls    	r0, r0, #9
0x0080b0:	str     	r7, [sp]
0x0080b2:	str     	r6, [sp, #4]
0x0080b4:	bl      	#0x7214
0x0080b8:	movs    	r1, #0
0x0080ba:	movs    	r2, #0
0x0080bc:	str     	r1, [sp]
0x0080be:	str     	r1, [sp, #4]
0x0080c0:	movs    	r1, #0x19
0x0080c2:	str     	r2, [sp, #8]
0x0080c4:	adds    	r3, r4, #0
0x0080c6:	movs    	r0, #0xf1
0x0080c8:	lsls    	r0, r0, #9
0x0080ca:	ldr     	r2, [sp, #0xc]
0x0080cc:	bl      	#0x7214
0x0080d0:	movs    	r1, #0
0x0080d2:	movs    	r2, #0
0x0080d4:	str     	r1, [sp]
0x0080d6:	str     	r1, [sp, #4]
0x0080d8:	movs    	r1, #0x19
0x0080da:	str     	r2, [sp, #8]
0x0080dc:	adds    	r3, r4, #0
0x0080de:	movs    	r0, #0xf1
0x0080e0:	lsls    	r0, r0, #9
0x0080e2:	ldr     	r2, [sp, #0x10]
0x0080e4:	bl      	#0x7214
0x0080e8:	movs    	r1, #0
0x0080ea:	movs    	r2, #0
0x0080ec:	str     	r1, [sp]
0x0080ee:	str     	r1, [sp, #4]
0x0080f0:	movs    	r1, #0x19
0x0080f2:	str     	r2, [sp, #8]
0x0080f4:	adds    	r3, r4, #0
0x0080f6:	movs    	r0, #0xf1
0x0080f8:	lsls    	r0, r0, #9
0x0080fa:	ldr     	r2, [sp, #0x14]
0x0080fc:	bl      	#0x7214
0x008100:	movs    	r1, #0
0x008102:	movs    	r2, #0
0x008104:	str     	r1, [sp]
0x008106:	str     	r1, [sp, #4]
0x008108:	movs    	r1, #0x19
0x00810a:	str     	r2, [sp, #8]
0x00810c:	adds    	r3, r4, #0
0x00810e:	movs    	r0, #0xf1
0x008110:	lsls    	r0, r0, #9
0x008112:	ldr     	r2, [sp, #0x18]
0x008114:	bl      	#0x7214
0x008118:	movs    	r1, #0
0x00811a:	movs    	r2, #0
0x00811c:	str     	r1, [sp]
0x00811e:	str     	r1, [sp, #4]
0x008120:	movs    	r1, #0x19
0x008122:	str     	r2, [sp, #8]
0x008124:	adds    	r3, r4, #0
0x008126:	movs    	r0, #0xf1
0x008128:	lsls    	r0, r0, #9
0x00812a:	ldr     	r2, [sp, #0x30]
0x00812c:	bl      	#0x7214
0x008130:	movs    	r1, #0
0x008132:	movs    	r2, #0
0x008134:	str     	r1, [sp]
0x008136:	str     	r1, [sp, #4]
0x008138:	movs    	r1, #0x19
0x00813a:	str     	r2, [sp, #8]
0x00813c:	adds    	r3, r4, #0
0x00813e:	movs    	r0, #0xf1
0x008140:	lsls    	r0, r0, #9
0x008142:	ldr     	r2, [sp, #0x34]
0x008144:	bl      	#0x7214
0x008148:	movs    	r1, #0
0x00814a:	movs    	r2, #0
0x00814c:	str     	r2, [sp, #8]
0x00814e:	str     	r1, [sp]
0x008150:	str     	r1, [sp, #4]
0x008152:	movs    	r1, #0x1b
0x008154:	movs    	r2, #1
0x008156:	adds    	r3, r4, #0
0x008158:	movs    	r0, #0xf1
0x00815a:	lsls    	r0, r0, #9
0x00815c:	bl      	#0x7214
0x008160:	add     	sp, #0x1c
0x008162:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_008164 =====
0x008164:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x008166:	sub     	sp, #0xc
0x008168:	movs    	r1, #0
0x00816a:	movs    	r5, #0xff
0x00816c:	movs    	r2, #0
0x00816e:	movs    	r4, #0
0x008170:	adds    	r3, r4, #0
0x008172:	str     	r2, [sp, #8]
0x008174:	adds    	r5, #0x5e
0x008176:	str     	r1, [sp]
0x008178:	str     	r1, [sp, #4]
0x00817a:	movs    	r1, #0x17
0x00817c:	adds    	r2, r5, #0
0x00817e:	movs    	r0, #0xf1
0x008180:	lsls    	r0, r0, #9
0x008182:	bl      	#0x7214
0x008186:	movs    	r1, #0
0x008188:	movs    	r2, #0
0x00818a:	str     	r2, [sp, #8]
0x00818c:	str     	r1, [sp]
0x00818e:	str     	r1, [sp, #4]
0x008190:	movs    	r1, #0xe1
0x008192:	movs    	r2, #0x1d
0x008194:	adds    	r3, r4, #0
0x008196:	movs    	r0, #0xf1
0x008198:	lsls    	r0, r0, #9
0x00819a:	bl      	#0x7214
0x00819e:	movs    	r1, #0
0x0081a0:	adds    	r6, r0, #0
0x0081a2:	movs    	r2, #0
0x0081a4:	str     	r2, [sp, #8]
0x0081a6:	str     	r1, [sp]
0x0081a8:	str     	r1, [sp, #4]
0x0081aa:	movs    	r1, #0xe1
0x0081ac:	movs    	r2, #0x18
0x0081ae:	movs    	r0, #0xf1
0x0081b0:	adds    	r3, r4, #0
0x0081b2:	lsls    	r0, r0, #9
0x0081b4:	bl      	#0x7214
0x0081b8:	ldr     	r7, [r0, #0xc]
0x0081ba:	movs    	r1, #0
0x0081bc:	movs    	r2, #0
0x0081be:	str     	r2, [sp, #8]
0x0081c0:	str     	r1, [sp]
0x0081c2:	str     	r1, [sp, #4]
0x0081c4:	movs    	r1, #0xe1
0x0081c6:	movs    	r2, #0x18
0x0081c8:	movs    	r0, #0xf1
0x0081ca:	adds    	r3, r4, #0
0x0081cc:	lsls    	r0, r0, #9
0x0081ce:	bl      	#0x7214
0x0081d2:	ldr     	r3, [r0, #8]
0x0081d4:	movs    	r2, #0
0x0081d6:	str     	r2, [sp, #8]
0x0081d8:	adds    	r2, r5, #0
0x0081da:	movs    	r0, #0xf1
0x0081dc:	movs    	r1, #0x52
0x0081de:	lsls    	r0, r0, #9
0x0081e0:	str     	r7, [sp]
0x0081e2:	str     	r6, [sp, #4]
0x0081e4:	bl      	#0x7214
0x0081e8:	movs    	r1, #0
0x0081ea:	movs    	r2, #0
0x0081ec:	str     	r1, [sp]
0x0081ee:	str     	r1, [sp, #4]
0x0081f0:	movs    	r1, #0x19
0x0081f2:	str     	r2, [sp, #8]
0x0081f4:	adds    	r3, r4, #0
0x0081f6:	movs    	r0, #0xf1
0x0081f8:	lsls    	r0, r0, #9
0x0081fa:	ldr     	r2, [sp, #0xc]
0x0081fc:	bl      	#0x7214
0x008200:	movs    	r1, #0
0x008202:	movs    	r2, #0
0x008204:	str     	r1, [sp]
0x008206:	str     	r1, [sp, #4]
0x008208:	movs    	r1, #0x19
0x00820a:	str     	r2, [sp, #8]
0x00820c:	adds    	r3, r4, #0
0x00820e:	movs    	r0, #0xf1
0x008210:	lsls    	r0, r0, #9
0x008212:	ldr     	r2, [sp, #0x10]
0x008214:	bl      	#0x7214
0x008218:	movs    	r1, #0
0x00821a:	movs    	r2, #0
0x00821c:	str     	r1, [sp]
0x00821e:	str     	r1, [sp, #4]
0x008220:	movs    	r1, #0x19
0x008222:	str     	r2, [sp, #8]
0x008224:	adds    	r3, r4, #0
0x008226:	movs    	r0, #0xf1
0x008228:	lsls    	r0, r0, #9
0x00822a:	ldr     	r2, [sp, #0x14]
0x00822c:	bl      	#0x7214
0x008230:	movs    	r1, #0
0x008232:	movs    	r2, #0
0x008234:	str     	r1, [sp]
0x008236:	str     	r1, [sp, #4]
0x008238:	movs    	r1, #0x19
0x00823a:	str     	r2, [sp, #8]
0x00823c:	adds    	r3, r4, #0
0x00823e:	movs    	r0, #0xf1
0x008240:	lsls    	r0, r0, #9
0x008242:	ldr     	r2, [sp, #0x18]
0x008244:	bl      	#0x7214
0x008248:	movs    	r1, #0
0x00824a:	movs    	r2, #0
0x00824c:	str     	r2, [sp, #8]
0x00824e:	str     	r1, [sp]
0x008250:	str     	r1, [sp, #4]
0x008252:	movs    	r1, #0x1b
0x008254:	movs    	r2, #1
0x008256:	adds    	r3, r4, #0
0x008258:	movs    	r0, #0xf1
0x00825a:	lsls    	r0, r0, #9
0x00825c:	bl      	#0x7214
0x008260:	add     	sp, #0x1c
0x008262:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_008264 =====
0x008264:	push    	{r0, r4, r5, r6, r7, lr}
0x008266:	sub     	sp, #0x10
0x008268:	movs    	r1, #0
0x00826a:	movs    	r5, #0xff
0x00826c:	movs    	r4, #0
0x00826e:	movs    	r2, #0
0x008270:	str     	r2, [sp, #8]
0x008272:	adds    	r3, r4, #0
0x008274:	adds    	r5, #0x41
0x008276:	str     	r1, [sp]
0x008278:	str     	r1, [sp, #4]
0x00827a:	movs    	r1, #0x17
0x00827c:	adds    	r2, r5, #0
0x00827e:	movs    	r0, #0xf1
0x008280:	lsls    	r0, r0, #9
0x008282:	bl      	#0x7214
0x008286:	movs    	r1, #0
0x008288:	movs    	r2, #0
0x00828a:	str     	r2, [sp, #8]
0x00828c:	str     	r1, [sp]
0x00828e:	str     	r1, [sp, #4]
0x008290:	movs    	r1, #0xe1
0x008292:	movs    	r2, #0x1d
0x008294:	adds    	r3, r4, #0
0x008296:	movs    	r0, #0xf1
0x008298:	lsls    	r0, r0, #9
0x00829a:	bl      	#0x7214
0x00829e:	movs    	r1, #0
0x0082a0:	adds    	r6, r0, #0
0x0082a2:	movs    	r2, #0
0x0082a4:	str     	r2, [sp, #8]
0x0082a6:	str     	r1, [sp]
0x0082a8:	str     	r1, [sp, #4]
0x0082aa:	movs    	r1, #0xe1
0x0082ac:	movs    	r2, #0x18
0x0082ae:	movs    	r0, #0xf1
0x0082b0:	adds    	r3, r4, #0
0x0082b2:	lsls    	r0, r0, #9
0x0082b4:	bl      	#0x7214
0x0082b8:	ldr     	r7, [r0, #0xc]
0x0082ba:	movs    	r1, #0
0x0082bc:	movs    	r2, #0
0x0082be:	str     	r2, [sp, #8]
0x0082c0:	str     	r1, [sp]
0x0082c2:	str     	r1, [sp, #4]
0x0082c4:	movs    	r1, #0xe1
0x0082c6:	movs    	r2, #0x18
0x0082c8:	movs    	r0, #0xf1
0x0082ca:	adds    	r3, r4, #0
0x0082cc:	lsls    	r0, r0, #9
0x0082ce:	bl      	#0x7214
0x0082d2:	ldr     	r3, [r0, #8]
0x0082d4:	movs    	r2, #0
0x0082d6:	str     	r2, [sp, #8]
0x0082d8:	adds    	r2, r5, #0
0x0082da:	movs    	r0, #0xf1
0x0082dc:	movs    	r1, #0x52
0x0082de:	lsls    	r0, r0, #9
0x0082e0:	str     	r7, [sp]
0x0082e2:	str     	r6, [sp, #4]
0x0082e4:	bl      	#0x7214
0x0082e8:	movs    	r1, #0
0x0082ea:	movs    	r2, #0
0x0082ec:	str     	r1, [sp]
0x0082ee:	str     	r1, [sp, #4]
0x0082f0:	movs    	r1, #0x49
0x0082f2:	str     	r2, [sp, #8]
0x0082f4:	adds    	r3, r4, #0
0x0082f6:	movs    	r0, #0xf1
0x0082f8:	lsls    	r0, r0, #9
0x0082fa:	ldr     	r2, [sp, #0x10]
0x0082fc:	bl      	#0x7214
0x008300:	movs    	r1, #0
0x008302:	movs    	r2, #0
0x008304:	str     	r2, [sp, #8]
0x008306:	str     	r1, [sp]
0x008308:	str     	r1, [sp, #4]
0x00830a:	movs    	r1, #0x1b
0x00830c:	movs    	r2, #1
0x00830e:	adds    	r3, r4, #0
0x008310:	movs    	r0, #0xf1
0x008312:	lsls    	r0, r0, #9
0x008314:	bl      	#0x7214
0x008318:	add     	sp, #0x14
0x00831a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_008326 =====
0x008326:	push    	{r0, r1, r2, r3, r4, r5, r7}
0x008328:	add     	r2, sp, #0x304
0x00832a:	ldm     	r3!, {r0, r1, r6, r7}
0x00832c:	beq     	#0x82b2
0x00832e:	ldc     	p0, c0, [r1, #0]!
0x008332:	movs    	r0, r0
0x008334:	adr     	r1, #0x344
0x008336:	bvc.w   	#0xdcab4
0x00833a:	add     	r2, sp, #0x348
0x00833c:	adr     	r2, #0x2dc
0x00833e:	b.w     	#0xceeec

; ===== candidate_008372 =====
0x008372:	push    	{r6, r7}
0x008374:	ldrd    	sl, r8, [r7, #0x2f4]
0x008378:	bmi     	#0x832a

; ===== candidate_0083fe =====
0x0083fe:	push    	{r2, r4, r6, r7}
0x008400:	movs    	r0, r0
0x008402:	movs    	r0, r0
0x008404:	itt     	gt

; ===== candidate_008420 =====
0x008420:	push    	{r0, r2, r3, r4, r5, r7, lr}
0x008422:	sub     	sp, #0x158
0x008424:	movs    	r0, r0
0x008426:	movs    	r0, r0
0x008428:	stc2l   	p0, c11, [sb, #0x358]
0x00842c:	movs    	r0, r0
0x00842e:	movs    	r0, r0
0x008430:	add     	r2, sp, #0x35c
0x008432:	stm     	r3!, {r3, r6, r7}
0x008434:	add     	r2, sp, #0x304
0x008436:	ldm     	r3!, {r0, r1, r6, r7}
0x008438:	movs    	r0, r0
0x00843a:	movs    	r0, r0
0x00843c:	ldrh.w  	lr, [sp, #0xbc8]
0x008440:	add     	r2, sp, #0x304
0x008442:	ldm     	r3!, {r0, r1, r6, r7}
0x008444:	movs    	r0, r0
0x008446:	movs    	r0, r0
0x008448:	ldm     	r3, {r0, r2, r3, r6, r7}
0x00844a:	bge.w   	#0xffffb9d0
0x00844e:	ldm     	r3!, {r0, r1, r6, r7}
0x008450:	movs    	r0, r0
0x008452:	movs    	r0, r0
0x008454:	ldm.w   	lr!, {r2, r4, r6, r7, r8, fp, ip, sp, lr, pc}
0x008458:	bl      	#0xff1c39be
0x00845c:	movs    	r0, r0
0x00845e:	movs    	r0, r0
0x008460:	rsb     	r3, r7, r7, lsl #31
0x008464:	bgt     	#0x83da
0x008466:	stcl    	p0, c0, [r0]
0x00846a:	movs    	r0, r0

; ===== candidate_00849c =====
0x00849c:	push    	{r1, r2, r3, r6, r7}
0x00849e:	add     	r0, sp, #0x2f4
0x0084a0:	ldcl    	p0, c0, [r4], {0}
0x0084a4:	ldm     	r2, {r0, r1, r2, r4, r6, r7}
0x0084a6:	push    	{r2, r4, r6, r7}

; ===== candidate_0084a6 =====
0x0084a6:	push    	{r2, r4, r6, r7}

; ===== candidate_0084c6 =====
0x0084c6:	push    	{r2, r4, r6, r7}
0x0084c8:	ldm     	r1, {r1, r4, r5, r7}
0x0084ca:	add     	r7, sp, #0x2f0
0x0084cc:	movs    	r1, r4
0x0084ce:	movs    	r0, r0
0x0084d0:	rsb     	r3, r7, r7, lsl #31
0x0084d4:	blo     	#0x8450
0x0084d6:	rsb     	sl, r8, r1, lsl #11
0x0084da:	ldm     	r3!, {r0, r1, r6, r7}
0x0084dc:	movs    	r0, r0
0x0084de:	movs    	r0, r0
0x0084e0:	cbz     	r1, #0x8512
0x0084e2:	bvc     	#0x8484
0x0084e4:	movs    	r0, r0
0x0084e6:	movs    	r0, r0
0x0084e8:	ble     	#0x8494
0x0084ea:	udf     	#0xce
0x0084ec:	blo     	#0x8468
0x0084ee:	rsb     	fp, r8, r7, lsl #27

; ===== candidate_008568 =====
0x008568:	push    	{r2, r4, r5, r7}
0x00856a:	add     	r0, sp, #0x2f4
0x00856c:	cbz     	r2, #0x85a2
0x00856e:	b       	#0x7eea
0x008570:	movs    	r0, r0
0x008572:	movs    	r0, r0
0x008574:	adr     	r7, #0x2f8
0x008576:	b       	#0x8112
0x008578:	movs    	r0, r0
0x00857a:	movs    	r0, r0
0x00857c:	bkpt    	#0xd0
0x00857e:	add     	r4, sp, #0x318
0x008580:	movs    	r0, r0
0x008582:	movs    	r0, r0
0x008584:	ldm     	r7, {r1, r3, r4, r5, r7}

; ===== candidate_008606 =====
0x008606:	push    	{r2, r4, r6, r7}
0x008608:	movs    	r0, r0
0x00860a:	movs    	r0, r0
0x00860c:	bkpt    	#0xd0
0x00860e:	add     	r4, sp, #0x318
0x008610:	ldm     	r2, {r0, r1, r2, r4, r6, r7}
0x008612:	push    	{r2, r4, r6, r7}
0x008614:	movs    	r0, r0
0x008616:	movs    	r0, r0
0x008618:	adr     	r3, #0x328
0x00861a:	b       	#0x87c4
0x00861c:	movs    	r0, r0
0x00861e:	movs    	r0, r0
0x008620:	adr     	r7, #0x2f8
0x008622:	b       	#0x81be
0x008624:	ldm     	r2, {r0, r1, r2, r4, r6, r7}
0x008626:	push    	{r2, r4, r6, r7}
0x008628:	movs    	r0, r0
0x00862a:	movs    	r0, r0

; ===== candidate_008612 =====
0x008612:	push    	{r2, r4, r6, r7}
0x008614:	movs    	r0, r0
0x008616:	movs    	r0, r0
0x008618:	adr     	r3, #0x328
0x00861a:	b       	#0x87c4
0x00861c:	movs    	r0, r0
0x00861e:	movs    	r0, r0
0x008620:	adr     	r7, #0x2f8
0x008622:	b       	#0x81be
0x008624:	ldm     	r2, {r0, r1, r2, r4, r6, r7}
0x008626:	push    	{r2, r4, r6, r7}
0x008628:	movs    	r0, r0
0x00862a:	movs    	r0, r0

; ===== candidate_008626 =====
0x008626:	push    	{r2, r4, r6, r7}
0x008628:	movs    	r0, r0
0x00862a:	movs    	r0, r0

; ===== candidate_00863a =====
0x00863a:	push    	{r0, r1, r2, r3, r4, r5, r7}
0x00863c:	ldm.w   	lr!, {r2, r4, r6, r7, r8, fp, ip, sp, lr, pc}
0x008640:	cbz     	r5, #0x8672
0x008642:	str.w   	r0, [r0]
0x008646:	movs    	r0, r0
0x008648:	cbnz    	r2, #0x86b8
0x00864a:	bgt     	#0x85d6
0x00864c:	ldm     	r4, {r2, r3, r4, r5, r7}
0x00864e:	ldr.w   	pc, [r0, #0xdc9]

; ===== candidate_00872e =====
0x00872e:	push    	{r0, r2, r3, r4, r5, r7, lr}
0x008730:	ldm     	r3!, {r2, r4, r5, r7}
0x008732:	b       	#0x84d0
0x008734:	bhs     	#0x86b0
0x008736:	sub     	sp, #0x158
0x008738:	cbnz    	r6, #0x87ae
0x00873a:	ittte   	ge
0x00873c:	movs    	r0, r0
0x00873e:	movs    	r0, r0
0x008740:	stmge   	r7!, {r1, r3, r6, r7}
0x008742:	blt.w   	#0x5c06d6
0x008746:	add     	r0, sp, #0x2d8
0x008748:	ldm     	r3, {r0, r2, r3, r6, r7}
0x00874a:	bge.w   	#0xffffbcd0
0x00874e:	ldm     	r3!, {r0, r1, r6, r7}
0x008750:	ittte   	ge
0x008752:	movs    	r0, r0
0x008754:	revge   	r0, r4
0x008756:	popge   	{r0, r1, r2, r3, r6, r7, pc}
0x008758:	blt     	#0x873c
0x00875a:	bmi     	#0x86f2
0x00875c:	lsls    	r4, r6, #2
0x00875e:	movs    	r0, r0
0x008760:	cbnz    	r0, #0x876c
0x008762:	ldm     	r7, {r0, r4, r5, r7}
0x008764:	bvs     	#0x8716
0x008766:	movs    	r6, #0xb5
0x008768:	movs    	r0, r0
0x00876a:	movs    	r0, r0
0x00876c:	pop     	{r5, pc}

; ===== candidate_008774 =====
0x008774:	push    	{r5, lr}
0x008776:	ldm     	r0, {r0, r1, r5, r6, r7}
0x008778:	lsls    	r7, r5, #2
0x00877a:	movs    	r0, r0
0x00877c:	stm     	r4!, {r5}
0x00877e:	stm     	r1!, {r2, r3, r4, r6, r7}
0x008780:	itttt   	lt
0x008782:	lsllt   	r1, r5, #3
0x008784:	poplt   	{r5, pc}
0x008786:	stmlt   	r7!, {r4, r5, r6, r7}
0x008788:	lsllt   	r6, r5, #2
0x00878a:	movs    	r0, r0
0x00878c:	b       	#0x88fc
0x00878e:	b       	#0x8938
0x008790:	itee    	lt
0x008792:	blt     	#0x8704
0x008794:	addge   	r3, sp, #0x2f4
0x008796:	bge     	#0x8b10
0x008798:	ldm     	r3, {r0, r2, r3, r6, r7}
0x00879a:	cbnz    	r3, #0x87cc
0x00879c:	movs    	r1, r4
0x00879e:	movs    	r0, r0
0x0087a0:	beq     	#0x87e4
0x0087a2:	stm     	r6!, {r1, r2, r3, r4, r5, r7}
0x0087a4:	bvc     	#0x8700
0x0087a6:	bmi     	#0x873e
0x0087a8:	lsls    	r4, r6, #2
0x0087aa:	movs    	r0, r0
0x0087ac:	bkpt    	#0x20
0x0087ae:	ldm     	r4!, {r0, r1, r2, r5, r7}
0x0087b0:	bvc     	#0x877e
0x0087b2:	bmi     	#0x874a
0x0087b4:	lsls    	r4, r6, #2
0x0087b6:	movs    	r0, r0
0x0087b8:	b       	#0x8f44
0x0087ba:	bvs     	#0x872c
0x0087bc:	stm     	r4!, {r1, r2, r3, r6, r7}
0x0087be:	push    	{r1, r2, r3, r6, r7}
0x0087c0:	ldm.w   	lr!, {r0, r1, r5, r7, r8, sp, pc}
0x0087c4:	movs    	r0, r0
0x0087c6:	movs    	r0, r0
0x0087c8:	b       	#0x8f54
0x0087ca:	stm     	r4!, {r0, r2, r4, r5, r7}
0x0087cc:	bkpt    	#0xa1
0x0087ce:	bhs.w   	#0x106560
0x0087d2:	itttt   	ge
0x0087d4:	cbnz    	r2, #0x8844
0x0087d6:	cbnz    	r1, #0x8848
0x0087d8:	ldmge.w 	lr!, {r2, r4, r6, r7, r8, fp, ip, sp, lr, pc}
0x0087dc:	stc2lge 	p14, c14, [sl, #0x2d8]
0x0087e0:	movs    	r0, r0
0x0087e2:	movs    	r0, r0
0x0087e4:	b       	#0x8f70
0x0087e6:	stm     	r4!, {r0, r2, r4, r5, r7}
0x0087e8:	bkpt    	#0xa1
0x0087ea:	bgt     	#0x8776
0x0087ec:	itttt   	gt

; ===== candidate_0087be =====
0x0087be:	push    	{r1, r2, r3, r6, r7}
0x0087c0:	ldm.w   	lr!, {r0, r1, r5, r7, r8, sp, pc}
0x0087c4:	movs    	r0, r0
0x0087c6:	movs    	r0, r0
0x0087c8:	b       	#0x8f54
0x0087ca:	stm     	r4!, {r0, r2, r4, r5, r7}
0x0087cc:	bkpt    	#0xa1
0x0087ce:	bhs.w   	#0x106560
0x0087d2:	itttt   	ge
0x0087d4:	cbnz    	r2, #0x8844
0x0087d6:	cbnz    	r1, #0x8848
0x0087d8:	ldmge.w 	lr!, {r2, r4, r6, r7, r8, fp, ip, sp, lr, pc}
0x0087dc:	stc2lge 	p14, c14, [sl, #0x2d8]
0x0087e0:	movs    	r0, r0
0x0087e2:	movs    	r0, r0
0x0087e4:	b       	#0x8f70
0x0087e6:	stm     	r4!, {r0, r2, r4, r5, r7}
0x0087e8:	bkpt    	#0xa1
0x0087ea:	bgt     	#0x8776
0x0087ec:	itttt   	gt

; ===== candidate_008828 =====
0x008828:	push    	{r2, r4, r6, r7}
0x00882a:	itttt   	ge
0x00882c:	cbnz    	r2, #0x889c
0x00882e:	cbnz    	r1, #0x88a0
0x008830:	ldmge.w 	lr!, {r2, r4, r6, r7, r8, fp, ip, sp, lr, pc}
0x008834:	stc2lge 	p14, c14, [sl, #0x2d8]
0x008838:	movs    	r0, r0
0x00883a:	movs    	r0, r0
0x00883c:	b       	#0x8fc8
0x00883e:	stm     	r4!, {r0, r2, r4, r5, r7}
0x008840:	bkpt    	#0xa1
0x008842:	bkpt    	#0xd0
0x008844:	add     	r4, sp, #0x318
0x008846:	ldm     	r2, {r0, r1, r2, r4, r6, r7}
0x008848:	push    	{r2, r4, r6, r7}
0x00884a:	itttt   	ge
0x00884c:	cbnz    	r2, #0x88bc
0x00884e:	cbnz    	r1, #0x88c0
0x008850:	ldmge.w 	lr!, {r2, r4, r6, r7, r8, fp, ip, sp, lr, pc}
0x008854:	stc2lge 	p14, c14, [sl, #0x2d8]
0x008858:	movs    	r0, r0
0x00885a:	movs    	r0, r0
0x00885c:	b       	#0x8fe8
0x00885e:	stm     	r4!, {r0, r2, r4, r5, r7}
0x008860:	bkpt    	#0xa1
0x008862:	adr     	r7, #0x2f8
0x008864:	b       	#0x8400
0x008866:	ldm     	r2, {r0, r1, r2, r4, r6, r7}
0x008868:	push    	{r2, r4, r6, r7}
0x00886a:	itttt   	ge
0x00886c:	cbnz    	r2, #0x88dc
0x00886e:	cbnz    	r1, #0x88e0
0x008870:	ldmge.w 	lr!, {r2, r4, r6, r7, r8, fp, ip, sp, lr, pc}
0x008874:	stc2lge 	p14, c14, [sl, #0x2d8]
0x008878:	movs    	r0, r0
0x00887a:	movs    	r0, r0
0x00887c:	bhs.w   	#0x10660e
0x008880:	adr     	r1, #0x340
0x008882:	bge     	#0x882c
0x008884:	mrc     	p1, #6, sl, c7, c0, #6
0x008888:	ldm.w   	lr!, {r2, r4, r6, r7, r8, fp, ip, sp, lr, pc}
0x00888c:	stc2l   	p0, c0, [sl]
0x008890:	b       	#0x8ffe
0x008892:	add     	r7, sp, #0x320
0x008894:	adr     	r1, #0x340
0x008896:	bge     	#0x8840
0x008898:	mrc     	p1, #6, sl, c7, c0, #6
0x00889c:	ldm.w   	lr!, {r2, r4, r6, r7, r8, fp, ip, sp, lr, pc}
0x0088a0:	stc2l   	p0, c0, [sl]
0x0088a4:	bgt     	#0x8830
0x0088a6:	itttt   	gt

; ===== candidate_008848 =====
0x008848:	push    	{r2, r4, r6, r7}
0x00884a:	itttt   	ge
0x00884c:	cbnz    	r2, #0x88bc
0x00884e:	cbnz    	r1, #0x88c0
0x008850:	ldmge.w 	lr!, {r2, r4, r6, r7, r8, fp, ip, sp, lr, pc}
0x008854:	stc2lge 	p14, c14, [sl, #0x2d8]
0x008858:	movs    	r0, r0
0x00885a:	movs    	r0, r0
0x00885c:	b       	#0x8fe8
0x00885e:	stm     	r4!, {r0, r2, r4, r5, r7}
0x008860:	bkpt    	#0xa1
0x008862:	adr     	r7, #0x2f8
0x008864:	b       	#0x8400
0x008866:	ldm     	r2, {r0, r1, r2, r4, r6, r7}
0x008868:	push    	{r2, r4, r6, r7}
0x00886a:	itttt   	ge
0x00886c:	cbnz    	r2, #0x88dc
0x00886e:	cbnz    	r1, #0x88e0
0x008870:	ldmge.w 	lr!, {r2, r4, r6, r7, r8, fp, ip, sp, lr, pc}
0x008874:	stc2lge 	p14, c14, [sl, #0x2d8]
0x008878:	movs    	r0, r0
0x00887a:	movs    	r0, r0
0x00887c:	bhs.w   	#0x10660e
0x008880:	adr     	r1, #0x340
0x008882:	bge     	#0x882c
0x008884:	mrc     	p1, #6, sl, c7, c0, #6
0x008888:	ldm.w   	lr!, {r2, r4, r6, r7, r8, fp, ip, sp, lr, pc}
0x00888c:	stc2l   	p0, c0, [sl]
0x008890:	b       	#0x8ffe
0x008892:	add     	r7, sp, #0x320
0x008894:	adr     	r1, #0x340
0x008896:	bge     	#0x8840
0x008898:	mrc     	p1, #6, sl, c7, c0, #6
0x00889c:	ldm.w   	lr!, {r2, r4, r6, r7, r8, fp, ip, sp, lr, pc}
0x0088a0:	stc2l   	p0, c0, [sl]
0x0088a4:	bgt     	#0x8830
0x0088a6:	itttt   	gt

; ===== candidate_008868 =====
0x008868:	push    	{r2, r4, r6, r7}
0x00886a:	itttt   	ge
0x00886c:	cbnz    	r2, #0x88dc
0x00886e:	cbnz    	r1, #0x88e0
0x008870:	ldmge.w 	lr!, {r2, r4, r6, r7, r8, fp, ip, sp, lr, pc}
0x008874:	stc2lge 	p14, c14, [sl, #0x2d8]
0x008878:	movs    	r0, r0
0x00887a:	movs    	r0, r0
0x00887c:	bhs.w   	#0x10660e
0x008880:	adr     	r1, #0x340
0x008882:	bge     	#0x882c
0x008884:	mrc     	p1, #6, sl, c7, c0, #6
0x008888:	ldm.w   	lr!, {r2, r4, r6, r7, r8, fp, ip, sp, lr, pc}
0x00888c:	stc2l   	p0, c0, [sl]
0x008890:	b       	#0x8ffe
0x008892:	add     	r7, sp, #0x320
0x008894:	adr     	r1, #0x340
0x008896:	bge     	#0x8840
0x008898:	mrc     	p1, #6, sl, c7, c0, #6
0x00889c:	ldm.w   	lr!, {r2, r4, r6, r7, r8, fp, ip, sp, lr, pc}
0x0088a0:	stc2l   	p0, c0, [sl]
0x0088a4:	bgt     	#0x8830
0x0088a6:	itttt   	gt

; ===== candidate_008932 =====
0x008932:	push    	{r2, r3, r6, r7, lr}

; ===== candidate_008990 =====
0x008990:	push    	{r3, r4, r5, r7}
0x008992:	add     	r4, sp, #0x28c
0x008994:	b       	#0x8928

; ===== candidate_00899c =====
0x00899c:	push    	{r1, r2, r3, r6, r7}
0x00899e:	b.w     	#0x4bd312
0x0089a2:	add     	r3, sp, #0x2f4
0x0089a4:	b       	#0x8938
0x0089a6:	bge     	#0x8936
0x0089a8:	add     	r2, sp, #0x2fc
0x0089aa:	pop     	{r0, r2, r4, r6, r7, pc}

; ===== candidate_0089a0 =====
0x0089a0:	push    	{r3, r4, r5, r7}
0x0089a2:	add     	r3, sp, #0x2f4
0x0089a4:	b       	#0x8938
0x0089a6:	bge     	#0x8936
0x0089a8:	add     	r2, sp, #0x2fc
0x0089aa:	pop     	{r0, r2, r4, r6, r7, pc}
