; function-oriented angr/capstone disassembly

; ===== sub_0 @ 0x0 offset=0x0 size=8 blocks=1 cc=1 =====
; block 0x0
0x000000:	ldrbmi  	r5, [r0, -sp, asr #4]
0x000004:	subpl   	r4, r1, r3, asr #26
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0x5080

; ===== _start @ 0x8 offset=0x8 size=20 blocks=2 cc=1 =====
; block 0x8
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0x5080
; block 0x18
0x000018:	pop     	{r4, pc}

; ===== sub_1c @ 0x1c offset=0x1c size=4 blocks=1 cc=1 =====
; block 0x1c
0x00001c:	andeq   	r4, r0, r8, ror r7
0x000020:	ands    	r2, r0, #128, #8
0x000024:	rsbmi   	r0, r0, #0
0x000028:	eors    	r3, r2, r1, asr #32
0x00002c:	rsbhs   	r1, r1, #0
0x000030:	rsbs    	ip, r0, r1, lsr #3
0x000034:	blo     	#0xbc

; ===== sub_20 @ 0x20 offset=0x20 size=284 blocks=20 cc=7 =====
; block 0x20
0x000020:	ands    	r2, r0, #128, #8
0x000024:	rsbmi   	r0, r0, #0
0x000028:	eors    	r3, r2, r1, asr #32
0x00002c:	rsbhs   	r1, r1, #0
0x000030:	rsbs    	ip, r0, r1, lsr #3
0x000034:	blo     	#0xbc
; block 0x38
0x000038:	rsbs    	ip, r0, r1, lsr #8
0x00003c:	blo     	#0x80
; block 0x40
0x000040:	lsl     	r0, r0, #8
0x000044:	orr     	r2, r2, #0xff000000
0x000048:	rsbs    	ip, r0, r1, lsr #4
0x00004c:	blo     	#0xb0
; block 0x50
0x000050:	rsbs    	ip, r0, r1, lsr #8
0x000054:	blo     	#0x80
; block 0x58
0x000058:	lsl     	r0, r0, #8
0x00005c:	orr     	r2, r2, #0xff0000
0x000060:	rsbs    	ip, r0, r1, lsr #8
0x000064:	lslhs   	r0, r0, #8
0x000068:	orrhs   	r2, r2, #0xff00
0x00006c:	rsbs    	ip, r0, r1, lsr #4
0x000070:	blo     	#0xb0
; block 0x74
0x000074:	rsbs    	ip, r0, #0
0x000078:	bhs     	#0xf8
; block 0x7c
0x00007c:	lsrhs   	r0, r0, #8
0x000080:	rsbs    	ip, r0, r1, lsr #7
0x000084:	subhs   	r1, r1, r0, lsl #7
0x000088:	adc     	r2, r2, r2
0x00008c:	rsbs    	ip, r0, r1, lsr #6
0x000090:	subhs   	r1, r1, r0, lsl #6
0x000094:	adc     	r2, r2, r2
0x000098:	rsbs    	ip, r0, r1, lsr #5
0x00009c:	subhs   	r1, r1, r0, lsl #5
0x0000a0:	adc     	r2, r2, r2
0x0000a4:	rsbs    	ip, r0, r1, lsr #4
0x0000a8:	subhs   	r1, r1, r0, lsl #4
0x0000ac:	adc     	r2, r2, r2
0x0000b0:	rsbs    	ip, r0, r1, lsr #3
0x0000b4:	subhs   	r1, r1, r0, lsl #3
0x0000b8:	adc     	r2, r2, r2
0x0000bc:	rsbs    	ip, r0, r1, lsr #2
0x0000c0:	subhs   	r1, r1, r0, lsl #2
0x0000c4:	adc     	r2, r2, r2
0x0000c8:	rsbs    	ip, r0, r1, lsr #1
0x0000cc:	subhs   	r1, r1, r0, lsl #1
0x0000d0:	adc     	r2, r2, r2
0x0000d4:	rsbs    	ip, r0, r1
0x0000d8:	subhs   	r1, r1, r0
0x0000dc:	adcs    	r2, r2, r2
0x0000e0:	bhs     	#0x7c
; block 0x80
0x000080:	rsbs    	ip, r0, r1, lsr #7
0x000084:	subhs   	r1, r1, r0, lsl #7
0x000088:	adc     	r2, r2, r2
0x00008c:	rsbs    	ip, r0, r1, lsr #6
0x000090:	subhs   	r1, r1, r0, lsl #6
0x000094:	adc     	r2, r2, r2
0x000098:	rsbs    	ip, r0, r1, lsr #5
0x00009c:	subhs   	r1, r1, r0, lsl #5
0x0000a0:	adc     	r2, r2, r2
0x0000a4:	rsbs    	ip, r0, r1, lsr #4
0x0000a8:	subhs   	r1, r1, r0, lsl #4
0x0000ac:	adc     	r2, r2, r2
0x0000b0:	rsbs    	ip, r0, r1, lsr #3
0x0000b4:	subhs   	r1, r1, r0, lsl #3
0x0000b8:	adc     	r2, r2, r2
0x0000bc:	rsbs    	ip, r0, r1, lsr #2
0x0000c0:	subhs   	r1, r1, r0, lsl #2
0x0000c4:	adc     	r2, r2, r2
0x0000c8:	rsbs    	ip, r0, r1, lsr #1
0x0000cc:	subhs   	r1, r1, r0, lsl #1
0x0000d0:	adc     	r2, r2, r2
0x0000d4:	rsbs    	ip, r0, r1
0x0000d8:	subhs   	r1, r1, r0
0x0000dc:	adcs    	r2, r2, r2
0x0000e0:	bhs     	#0x7c
; block 0xb0
0x0000b0:	rsbs    	ip, r0, r1, lsr #3
0x0000b4:	subhs   	r1, r1, r0, lsl #3
0x0000b8:	adc     	r2, r2, r2
0x0000bc:	rsbs    	ip, r0, r1, lsr #2
0x0000c0:	subhs   	r1, r1, r0, lsl #2
0x0000c4:	adc     	r2, r2, r2
0x0000c8:	rsbs    	ip, r0, r1, lsr #1
0x0000cc:	subhs   	r1, r1, r0, lsl #1
0x0000d0:	adc     	r2, r2, r2
0x0000d4:	rsbs    	ip, r0, r1
0x0000d8:	subhs   	r1, r1, r0
0x0000dc:	adcs    	r2, r2, r2
0x0000e0:	bhs     	#0x7c
; block 0xbc
0x0000bc:	rsbs    	ip, r0, r1, lsr #2
0x0000c0:	subhs   	r1, r1, r0, lsl #2
0x0000c4:	adc     	r2, r2, r2
0x0000c8:	rsbs    	ip, r0, r1, lsr #1
0x0000cc:	subhs   	r1, r1, r0, lsl #1
0x0000d0:	adc     	r2, r2, r2
0x0000d4:	rsbs    	ip, r0, r1
0x0000d8:	subhs   	r1, r1, r0
0x0000dc:	adcs    	r2, r2, r2
0x0000e0:	bhs     	#0x7c
; block 0xe4
0x0000e4:	eors    	r0, r2, r3, asr #31
0x0000e8:	add     	r0, r0, r3, lsr #31
0x0000ec:	rsbhs   	r1, r1, #0
0x0000f0:	bx      	lr
; block 0xf8
0x0000f8:	mov     	r0, #2
0x0000fc:	mov     	r1, #2
0x000100:	b       	#0x118
; block 0x118
0x000118:	push    	{r4, lr}
0x00011c:	blx     	#0x134
; block 0x120
0x000120:	cmp     	r0, #0
0x000124:	popeq   	{r4, lr}
0x000128:	bxeq    	lr
; block 0x128
0x000128:	bxeq    	lr
; block 0x12c
0x00012c:	pop     	{r4, lr}
0x000130:	b       	#0x17c
; block 0x17c
0x00017c:	mov     	r0, #0x18
0x000180:	ldr     	r1, [pc, #8]
0x000184:	svc     	#0x123456
; block 0x188
0x000188:	bx      	lr
; block 0x8c3
0x0008c3:	movs    	r1, #0x14
0x0008c5:	movs    	r2, #0x23
0x0008c7:	adds    	r3, r7, #0
0x0008c9:	adds    	r0, r4, #0
0x0008cb:	bl      	#0x5159
; block 0x8cf
0x0008cf:	add     	sp, #0xc
0x0008d1:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_f4 @ 0xf4 offset=0xf4 size=4 blocks=1 cc=1 =====
; block 0xf4
0x0000f4:	andeq   	r4, r0, r8, ror r7
0x0000f8:	mov     	r0, #2
0x0000fc:	mov     	r1, #2
0x000100:	b       	#0x118

; ===== sub_109 @ 0x109 offset=0x108 size=2 blocks=1 cc=1 =====
; block 0x109
0x000109:	bx      	r2

; ===== sub_10b @ 0x10b offset=0x10a size=2 blocks=1 cc=1 =====
; block 0x10b
0x00010b:	bx      	r3

; ===== sub_135 @ 0x135 offset=0x134 size=58 blocks=7 cc=3 =====
; block 0x135
0x000135:	push    	{r4, r5, r6, lr}
0x000137:	ldr     	r6, [pc, #0x38]
0x000139:	adds    	r5, r1, #0
0x00013b:	adds    	r1, r0, #0
0x00013d:	adds    	r4, r0, #0
0x00013f:	add     	r6, pc
0x000141:	adds    	r0, r6, #0
0x000143:	bl      	#0x147
; block 0x147
0x000147:	adds    	r2, r0, #0
0x000149:	cmp     	r0, r6
0x00014b:	bne     	#0x15b
; block 0x14d
0x00014d:	adds    	r1, r5, #0
0x00014f:	adds    	r0, r4, #0
0x000151:	bl      	#0x195
; block 0x155
0x000155:	pop     	{r4, r5, r6}
0x000157:	pop     	{r3}
0x000159:	bx      	r3
; block 0x15b
0x00015b:	ldr     	r0, [pc, #0x18]
0x00015d:	add     	r0, pc
0x00015f:	cmp     	r2, r0
0x000161:	beq     	#0x16b
; block 0x163
0x000163:	adds    	r1, r5, #0
0x000165:	adds    	r0, r4, #0
0x000167:	bl      	#0x109
; block 0x16b
0x00016b:	movs    	r0, #0
0x00016d:	b       	#0x155

; ===== sub_177 @ 0x177 offset=0x176 size=6 blocks=1 cc=1 =====
; block 0x177
0x000177:	vqshl.u32	q10, q12, #0x17
0x00017b:	movs    	r0, r0
0x00017d:	movs    	r0, r3
0x00017f:	b       	#0x8c3

; ===== sub_18d @ 0x18d offset=0x18c size=8 blocks=1 cc=1 =====
; block 0x18d
0x00018d:	lsls    	r1, r4, #4
0x00018f:	movs    	r0, r0
0x000191:	movs    	r6, r4
0x000193:	movs    	r2, r0
0x000195:	push    	{r3, r4, r5, lr}
0x000197:	subs    	r2, r0, #1
0x000199:	cmp     	r2, #0xd
0x00019b:	adr     	r4, #0x90
0x00019d:	bhs     	#0x1ed

; ===== sub_195 @ 0x195 offset=0x194 size=150 blocks=27 cc=18 =====
; block 0x195
0x000195:	push    	{r3, r4, r5, lr}
0x000197:	subs    	r2, r0, #1
0x000199:	cmp     	r2, #0xd
0x00019b:	adr     	r4, #0x90
0x00019d:	bhs     	#0x1ed
; block 0x19f
0x00019f:	movs    	r2, #0x17
0x0001a1:	ldr     	r3, [pc, #0x8c]
0x0001a3:	muls    	r2, r0, r2
0x0001a5:	add     	r3, pc
0x0001a7:	adds    	r5, r2, r3
0x0001a9:	subs    	r5, #0x17
0x0001ab:	cmp     	r0, #2
0x0001ad:	bne     	#0x1d9
; block 0x1af
0x0001af:	lsls    	r0, r1, #5
0x0001b1:	bpl     	#0x1b7
; block 0x1b3
0x0001b3:	adr     	r4, #0x80
0x0001b5:	b       	#0x1ef
; block 0x1b7
0x0001b7:	ldr     	r0, [pc, #0x90]
0x0001b9:	ands    	r0, r1
0x0001bb:	beq     	#0x1c1
; block 0x1bd
0x0001bd:	adr     	r4, #0x8c
0x0001bf:	b       	#0x1ef
; block 0x1c1
0x0001c1:	lsls    	r0, r1, #3
0x0001c3:	bpl     	#0x1c9
; block 0x1c5
0x0001c5:	adr     	r4, #0x94
0x0001c7:	b       	#0x1ef
; block 0x1c9
0x0001c9:	lsls    	r0, r1, #2
0x0001cb:	bpl     	#0x1d1
; block 0x1cd
0x0001cd:	adr     	r4, #0x98
0x0001cf:	b       	#0x1ef
; block 0x1d1
0x0001d1:	lsls    	r0, r1, #1
0x0001d3:	bpl     	#0x1ef
; block 0x1d5
0x0001d5:	adr     	r4, #0x9c
0x0001d7:	b       	#0x1ef
; block 0x1d9
0x0001d9:	cmp     	r0, #8
0x0001db:	bne     	#0x1e1
; block 0x1dd
0x0001dd:	adds    	r4, r1, #0
0x0001df:	b       	#0x1ef
; block 0x1e1
0x0001e1:	cmp     	r0, #9
0x0001e3:	bne     	#0x1ef
; block 0x1e5
0x0001e5:	cmp     	r1, #1
0x0001e7:	bne     	#0x1ef
; block 0x1e9
0x0001e9:	adr     	r5, #0x98
0x0001eb:	b       	#0x1ef
; block 0x1ed
0x0001ed:	adr     	r5, #0xac
0x0001ef:	movs    	r0, #0xa
0x0001f1:	bl      	#0x2b5
; block 0x1ef
0x0001ef:	movs    	r0, #0xa
0x0001f1:	bl      	#0x2b5
; block 0x1f5
0x0001f5:	ldrb    	r0, [r5]
0x0001f7:	cmp     	r0, #0
0x0001f9:	beq     	#0x209
; block 0x1fb
0x0001fb:	ldrb    	r0, [r5]
0x0001fd:	adds    	r5, #1
0x0001ff:	bl      	#0x2b5
; block 0x203
0x000203:	ldrb    	r0, [r5]
0x000205:	cmp     	r0, #0
0x000207:	bne     	#0x1fb
; block 0x209
0x000209:	ldrb    	r0, [r4]
0x00020b:	cmp     	r0, #0
0x00020d:	beq     	#0x21d
; block 0x20f
0x00020f:	ldrb    	r0, [r4]
0x000211:	adds    	r4, #1
0x000213:	bl      	#0x2b5
; block 0x217
0x000217:	ldrb    	r0, [r4]
0x000219:	cmp     	r0, #0
0x00021b:	bne     	#0x20f
; block 0x21d
0x00021d:	movs    	r0, #0xa
0x00021f:	bl      	#0x2b5
; block 0x223
0x000223:	pop     	{r3, r4, r5}
0x000225:	pop     	{r3}
0x000227:	movs    	r0, #1
0x000229:	bx      	r3

; ===== sub_231 @ 0x231 offset=0x230 size=130 blocks=2 cc=1 =====
; block 0x231
0x000231:	ldr     	r0, [r1, #0x54]
0x000233:	movs    	r0, r0
0x000235:	ldr     	r1, [r1, #0x64]
0x000237:	str     	r6, [r6, #0x14]
0x000239:	ldr     	r4, [r5, #0x14]
0x00023b:	movs    	r0, #0x64
0x00023d:	strb    	r7, [r1, #1]
0x00023f:	strb    	r5, [r4, #9]
0x000241:	strb    	r1, [r4, #0x11]
0x000243:	ldr     	r1, [r5, #0x74]
0x000245:	lsls    	r6, r5, #1
0x000247:	movs    	r0, r0
0x000249:	movs    	r2, r0
0x00024b:	lsrs    	r0, r0, #0x20
0x00024d:	ldr     	r4, [r0, #0x14]
0x00024f:	ldr     	r6, [r6, #0x14]
0x000251:	str     	r4, [r4, #0x54]
0x000253:	tst     	r0, r4
0x000255:	movs    	r0, #0x79
0x000257:	str     	r2, [r3, #0x54]
0x000259:	ldr     	r2, [r6, #0x74]
0x00025b:	movs    	r0, r0
0x00025d:	strb    	r7, [r1, #0x19]
0x00025f:	strb    	r5, [r4, #9]
0x000261:	ldr     	r6, [r4, #0x44]
0x000263:	strb    	r7, [r5, #0x1d]
0x000265:	movs    	r0, r0
0x000267:	movs    	r0, r0
0x000269:	ldr     	r5, [r2, #0x64]
0x00026b:	str     	r4, [r4, #0x54]
0x00026d:	str     	r2, [r6, #0x64]
0x00026f:	ldr     	r4, [r5, #0x74]
0x000271:	lsls    	r7, r6, #1
0x000273:	movs    	r0, r0
0x000275:	ldr     	r1, [r1, #0x64]
0x000277:	ldrb    	r5, [r4, #1]
0x000279:	str     	r1, [r4, #0x34]
0x00027b:	movs    	r0, #0x74
0x00027d:	str     	r2, [r2, #0x54]
0x00027f:	strb    	r3, [r6, #0x15]
0x000281:	strb    	r4, [r5, #0x11]
0x000283:	movs    	r0, r0
0x000285:	movs    	r0, #0x3a
0x000287:	str     	r0, [r1, #0x54]
0x000289:	strb    	r1, [r4, #1]
0x00028b:	ldr     	r0, [r4, #0x50]
0x00028d:	ldr     	r5, [r4, #0x54]
0x00028f:	strb    	r7, [r5, #9]
0x000291:	movs    	r0, #0x79
0x000293:	ldr     	r3, [r4, #0x74]
0x000295:	strb    	r2, [r6, #9]
0x000297:	strb    	r5, [r6, #1]
0x000299:	str     	r4, [r6, #0x54]
0x00029b:	lsls    	r4, r4, #1
0x00029d:	ldr     	r5, [r2, #0x64]
0x00029f:	ldr     	r3, [r5, #0x64]
0x0002a1:	strb    	r7, [r5, #0x1d]
0x0002a3:	movs    	r0, #0x6e
0x0002a5:	ldr     	r3, [r6, #0x14]
0x0002a7:	ldr     	r7, [r4, #0x64]
0x0002a9:	ldr     	r1, [r4, #0x44]
0x0002ab:	movs    	r0, r0
0x0002ad:	bx      	pc
; block 0x2b0
0x0002b0:	bx      	lr

; ===== sub_2b5 @ 0x2b5 offset=0x2b4 size=18 blocks=2 cc=1 =====
; block 0x2b5
0x0002b5:	push    	{r3, lr}
0x0002b7:	add     	r3, sp, #0
0x0002b9:	strb    	r0, [r3]
0x0002bb:	movs    	r0, #3
0x0002bd:	mov     	r1, sp
0x0002bf:	svc     	#0xab
; block 0x2c1
0x0002c1:	add     	sp, #4
0x0002c3:	pop     	{r3}
0x0002c5:	bx      	r3

; ===== sub_2c8 @ 0x2c8 offset=0x2c8 size=16 blocks=1 cc=1 =====
; block 0x2c8
0x0002c8:	ldr     	r0, [pc, #8]
0x0002cc:	ldr     	r1, [pc, #8]
0x0002d0:	add     	r0, r0, r1
0x0002d4:	bx      	lr

; ===== sub_2d8 @ 0x2d8 offset=0x2d8 size=8 blocks=1 cc=1 =====
; block 0x2d8
0x0002d8:	andeq   	r0, r0, ip
0x0002dc:	andeq   	r0, r0, r0, lsl r2
0x0002e0:	mov     	sb, r0
0x0002e4:	bx      	lr

; ===== sub_2e0 @ 0x2e0 offset=0x2e0 size=8 blocks=1 cc=1 =====
; block 0x2e0
0x0002e0:	mov     	sb, r0
0x0002e4:	bx      	lr

; ===== sub_2e8 @ 0x2e8 offset=0x2e8 size=28 blocks=1 cc=1 =====
; block 0x2e8
0x0002e8:	ldr     	r3, [pc, #0x14]
0x0002ec:	asr     	r2, r0, #0x1f
0x0002f0:	smull   	ip, r1, r3, r0
0x0002f4:	mvn     	r3, #2
0x0002f8:	rsb     	r1, r2, r1
0x0002fc:	mla     	r0, r3, r1, r0
0x000300:	bx      	lr

; ===== sub_304 @ 0x304 offset=0x304 size=4 blocks=1 cc=1 =====
; block 0x304
0x000304:	ldrbpl  	r5, [r5, #-0x556]
0x000308:	ldr     	r3, [pc, #0x14]
0x00030c:	asr     	r2, r0, #0x1f
0x000310:	smull   	ip, r1, r3, r0
0x000314:	mvn     	r3, #5
0x000318:	rsb     	r1, r2, r1
0x00031c:	mla     	r0, r3, r1, r0
0x000320:	bx      	lr

; ===== sub_308 @ 0x308 offset=0x308 size=28 blocks=1 cc=1 =====
; block 0x308
0x000308:	ldr     	r3, [pc, #0x14]
0x00030c:	asr     	r2, r0, #0x1f
0x000310:	smull   	ip, r1, r3, r0
0x000314:	mvn     	r3, #5
0x000318:	rsb     	r1, r2, r1
0x00031c:	mla     	r0, r3, r1, r0
0x000320:	bx      	lr

; ===== sub_324 @ 0x324 offset=0x324 size=4 blocks=1 cc=1 =====
; block 0x324
0x000324:	bhs     	#0xfeaaadd8

; ===== sub_329 @ 0x329 offset=0x328 size=22 blocks=1 cc=1 =====
; block 0x329
0x000329:	push    	{r4, r5, lr}
0x00032b:	ldr     	r4, [pc, #0xb4]
0x00032d:	movs    	r2, #0x1c
0x00032f:	add     	r4, pc
0x000331:	ldr     	r0, [r4, #0x38]
0x000333:	movs    	r1, #0
0x000335:	ldr     	r3, [r0, #0x38]
0x000337:	ldr     	r0, [pc, #0xac]
0x000339:	sub     	sp, #0xc
0x00033b:	add     	r0, sb
0x00033d:	blx     	r3

; ===== sub_34b @ 0x34b offset=0x34a size=148 blocks=5 cc=2 =====
; block 0x34b
0x00034b:	str     	r1, [sp, #4]
0x00034d:	movs    	r1, #0x64
0x00034f:	movs    	r0, #1
0x000351:	str     	r2, [sp, #8]
0x000353:	bl      	#0x5159
; block 0x357
0x000357:	ldr     	r1, [pc, #0x8c]
0x000359:	movs    	r0, #0
0x00035b:	add     	r1, sb
0x00035d:	subs    	r1, #0x7c
0x00035f:	str     	r0, [r1, #8]
0x000361:	ldr     	r5, [pc, #0x80]
0x000363:	str     	r0, [r1, #0x10]
0x000365:	str     	r0, [r1, #0xc]
0x000367:	add     	r5, sb
0x000369:	subs    	r5, #0xfc
0x00036b:	movs    	r0, #1
0x00036d:	str     	r0, [r5, #0x18]
0x00036f:	ldr     	r0, [r4, #0x38]
0x000371:	ldr     	r2, [pc, #0x74]
0x000373:	ldr     	r1, [r0, #0x68]
0x000375:	add     	r2, sb
0x000377:	str     	r1, [r5, #0x2c]
0x000379:	ldr     	r1, [r0, #0xc]
0x00037b:	ldr     	r4, [pc, #0x70]
0x00037d:	str     	r1, [r5, #0x30]
0x00037f:	ldr     	r1, [r0, #0x10]
0x000381:	str     	r1, [r5, #0x34]
0x000383:	ldr     	r1, [r0, #0x14]
0x000385:	str     	r1, [r5, #0x38]
0x000387:	ldr     	r1, [r0, #0x18]
0x000389:	str     	r1, [r5, #0x3c]
0x00038b:	ldr     	r1, [r0, #0x1c]
0x00038d:	str     	r1, [r5, #0x40]
0x00038f:	ldr     	r1, [r0, #0x20]
0x000391:	str     	r1, [r5, #0x44]
0x000393:	ldr     	r1, [r0, #0x24]
0x000395:	str     	r1, [r5, #0x48]
0x000397:	ldr     	r1, [r0, #0x28]
0x000399:	str     	r1, [r5, #0x4c]
0x00039b:	ldr     	r1, [r0, #0x2c]
0x00039d:	str     	r1, [r5, #0x50]
0x00039f:	ldr     	r1, [r0, #0x30]
0x0003a1:	str     	r1, [r5, #0x54]
0x0003a3:	ldr     	r1, [r0, #0x34]
0x0003a5:	str     	r1, [r5, #0x58]
0x0003a7:	ldr     	r1, [r0, #0x38]
0x0003a9:	str     	r1, [r5, #0x5c]
0x0003ab:	ldr     	r1, [r0, #0x3c]
0x0003ad:	str     	r1, [r5, #0x60]
0x0003af:	ldr     	r1, [r0, #0x40]
0x0003b1:	str     	r1, [r5, #0x64]
0x0003b3:	ldr     	r1, [r0, #0x44]
0x0003b5:	str     	r1, [r5, #0x68]
0x0003b7:	ldr     	r1, [r0, #0x48]
0x0003b9:	str     	r1, [r5, #0x6c]
0x0003bb:	ldr     	r1, [r0, #0x4c]
0x0003bd:	str     	r1, [r5, #0x70]
0x0003bf:	movs    	r1, #0
0x0003c1:	str     	r1, [r2]
0x0003c3:	movs    	r1, #1
0x0003c5:	lsls    	r1, r1, #9
0x0003c7:	adds    	r0, r0, r1
0x0003c9:	ldr     	r3, [r0, #8]
0x0003cb:	movs    	r1, #7
0x0003cd:	adds    	r2, r4, #0
0x0003cf:	movs    	r0, #0
0x0003d1:	blx     	r3
; block 0x3d3
0x0003d3:	cmp     	r0, r4
0x0003d5:	bne     	#0x3db
; block 0x3d7
0x0003d7:	subs    	r0, #2
0x0003d9:	str     	r0, [r5, #0x28]
0x0003db:	add     	sp, #0xc
0x0003dd:	pop     	{r4, r5, pc}
; block 0x3db
0x0003db:	add     	sp, #0xc
0x0003dd:	pop     	{r4, r5, pc}

; ===== sub_3e1 @ 0x3e1 offset=0x3e0 size=16 blocks=1 cc=1 =====
; block 0x3e1
0x0003e1:	ldc2    	p15, c15, [r6], {0xff}
0x0003e5:	lsls    	r4, r7, #7
0x0003e7:	movs    	r0, r0
0x0003e9:	lsls    	r0, r3, #8
0x0003eb:	movs    	r0, r0
0x0003ed:	movs    	r7, #0xf
0x0003ef:	movs    	r0, r0
0x0003f1:	push    	{r4, r5, r6, r7, lr}
0x0003f3:	sub     	sp, #0xc
0x0003f5:	movs    	r1, #0
0x0003f7:	movs    	r2, #0
0x0003f9:	str     	r2, [sp, #8]
0x0003fb:	str     	r1, [sp]
0x0003fd:	str     	r1, [sp, #4]
0x0003ff:	adds    	r5, r0, #0
0x000401:	movs    	r0, #0xf1
0x000403:	movs    	r1, #0xe1
0x000405:	movs    	r2, #0x24
0x000407:	movs    	r3, #0
0x000409:	lsls    	r0, r0, #9
0x00040b:	bl      	#0x5159

; ===== sub_3f1 @ 0x3f1 offset=0x3f0 size=76 blocks=6 cc=2 =====
; block 0x3f1
0x0003f1:	push    	{r4, r5, r6, r7, lr}
0x0003f3:	sub     	sp, #0xc
0x0003f5:	movs    	r1, #0
0x0003f7:	movs    	r2, #0
0x0003f9:	str     	r2, [sp, #8]
0x0003fb:	str     	r1, [sp]
0x0003fd:	str     	r1, [sp, #4]
0x0003ff:	adds    	r5, r0, #0
0x000401:	movs    	r0, #0xf1
0x000403:	movs    	r1, #0xe1
0x000405:	movs    	r2, #0x24
0x000407:	movs    	r3, #0
0x000409:	lsls    	r0, r0, #9
0x00040b:	bl      	#0x5159
; block 0x3f5
0x0003f5:	movs    	r1, #0
0x0003f7:	movs    	r2, #0
0x0003f9:	str     	r2, [sp, #8]
0x0003fb:	str     	r1, [sp]
0x0003fd:	str     	r1, [sp, #4]
0x0003ff:	adds    	r5, r0, #0
0x000401:	movs    	r0, #0xf1
0x000403:	movs    	r1, #0xe1
0x000405:	movs    	r2, #0x24
0x000407:	movs    	r3, #0
0x000409:	lsls    	r0, r0, #9
0x00040b:	bl      	#0x5159
; block 0x40f
0x00040f:	movs    	r2, #0
0x000411:	movs    	r1, #0
0x000413:	str     	r2, [sp, #8]
0x000415:	adds    	r2, r0, #0
0x000417:	str     	r1, [sp]
0x000419:	str     	r1, [sp, #4]
0x00041b:	movs    	r1, #0x11
0x00041d:	movs    	r0, #0xf1
0x00041f:	movs    	r3, #0x1c
0x000421:	lsls    	r0, r0, #9
0x000423:	bl      	#0x5159
; block 0x427
0x000427:	adds    	r4, r0, #0
0x000429:	subs    	r5, #2
0x00042b:	cmp     	r5, #0x13
0x00042d:	bhs     	#0x439
; block 0x42f
0x00042f:	adr     	r3, #0xc
0x000431:	adds    	r3, r3, r5
0x000433:	ldrh    	r3, [r3, r5]
0x000435:	lsls    	r3, r3, #1
0x000437:	add     	pc, r3
; block 0x439
0x000439:	add     	sp, #0xc
0x00043b:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_43d @ 0x43d offset=0x43c size=38 blocks=1 cc=1 =====
; block 0x43d
0x00043d:	movs    	r3, r4
0x00043f:	movs    	r4, r2
0x000441:	lsls    	r1, r0, #1
0x000443:	lsls    	r2, r5, #5
0x000445:	lsls    	r4, r3, #2
0x000447:	movs    	r4, r2
0x000449:	movs    	r2, r6
0x00044b:	movs    	r4, r2
0x00044d:	movs    	r4, r2
0x00044f:	movs    	r4, r2
0x000451:	movs    	r3, r4
0x000453:	movs    	r2, r6
0x000455:	lsls    	r1, r0, #1
0x000457:	lsls    	r4, r3, #2
0x000459:	movs    	r4, r2
0x00045b:	lsls    	r7, r6, #3
0x00045d:	movs    	r5, r2
0x00045f:	movs    	r4, r2
0x000461:	lsls    	r2, r5, #5
0x000463:	b       	#0x439

; ===== sub_463 @ 0x463 offset=0x462 size=2 blocks=1 cc=1 =====
; block 0x463
0x000463:	b       	#0x439

; ===== sub_465 @ 0x465 offset=0x464 size=28 blocks=3 cc=1 =====
; block 0x465
0x000465:	bl      	#0x59dd
; block 0x469
0x000469:	movs    	r1, #0
0x00046b:	str     	r1, [sp]
0x00046d:	str     	r1, [sp, #4]
0x00046f:	movs    	r2, #0
0x000471:	movs    	r1, #0x2c
0x000473:	movs    	r3, #0
0x000475:	movs    	r0, #0xf1
0x000477:	lsls    	r0, r0, #9
0x000479:	str     	r2, [sp, #8]
0x00047b:	bl      	#0x5159
; block 0x47f
0x00047f:	b       	#0x439

; ===== sub_481 @ 0x481 offset=0x480 size=30 blocks=2 cc=1 =====
; block 0x481
0x000481:	ldr     	r0, [pc, #0x32c]
0x000483:	movs    	r2, #0
0x000485:	movs    	r1, #0
0x000487:	add     	r0, sb
0x000489:	str     	r0, [sp]
0x00048b:	str     	r1, [sp, #4]
0x00048d:	str     	r2, [sp, #8]
0x00048f:	movs    	r2, #4
0x000491:	movs    	r1, #0x29
0x000493:	movs    	r0, #0xf1
0x000495:	movs    	r3, #0
0x000497:	lsls    	r0, r0, #9
0x000499:	bl      	#0x5159
; block 0x49d
0x00049d:	b       	#0x439

; ===== sub_49f @ 0x49f offset=0x49e size=30 blocks=2 cc=1 =====
; block 0x49f
0x00049f:	ldr     	r0, [pc, #0x310]
0x0004a1:	movs    	r2, #0
0x0004a3:	movs    	r1, #1
0x0004a5:	add     	r0, sb
0x0004a7:	str     	r0, [sp]
0x0004a9:	str     	r1, [sp, #4]
0x0004ab:	str     	r2, [sp, #8]
0x0004ad:	movs    	r2, #4
0x0004af:	movs    	r1, #0x29
0x0004b1:	movs    	r0, #0xf1
0x0004b3:	movs    	r3, #0
0x0004b5:	lsls    	r0, r0, #9
0x0004b7:	bl      	#0x5159
; block 0x4bb
0x0004bb:	b       	#0x439

; ===== sub_4bd @ 0x4bd offset=0x4bc size=182 blocks=15 cc=10 =====
; block 0x4bd
0x0004bd:	ldr     	r6, [pc, #0x2f0]
0x0004bf:	add     	r6, sb
0x0004c1:	subs    	r6, #8
0x0004c3:	ldr     	r0, [r6, #8]
0x0004c5:	cmp     	r0, #0
0x0004c7:	beq     	#0x439
; block 0x4c9
0x0004c9:	cmp     	r0, #1
0x0004cb:	beq     	#0x439
; block 0x4cd
0x0004cd:	cmp     	r0, #2
0x0004cf:	beq     	#0x51b
; block 0x4d1
0x0004d1:	cmp     	r0, #3
0x0004d3:	bne     	#0x439
; block 0x4d5
0x0004d5:	ldr     	r7, [r6]
0x0004d7:	cmp     	r7, #0
0x0004d9:	beq     	#0x4f7
; block 0x4db
0x0004db:	movs    	r1, #0
0x0004dd:	movs    	r2, #0
0x0004df:	movs    	r5, #0
0x0004e1:	adds    	r3, r5, #0
0x0004e3:	str     	r2, [sp, #8]
0x0004e5:	str     	r1, [sp]
0x0004e7:	str     	r1, [sp, #4]
0x0004e9:	movs    	r1, #0x4c
0x0004eb:	adds    	r2, r7, #0
0x0004ed:	movs    	r0, #0xf1
0x0004ef:	lsls    	r0, r0, #9
0x0004f1:	bl      	#0x5159
; block 0x4f5
0x0004f5:	str     	r5, [r6]
0x0004f7:	bl      	#0x49bd
; block 0x4f7
0x0004f7:	bl      	#0x49bd
; block 0x4fb
0x0004fb:	ldr     	r0, [pc, #0x2b4]
0x0004fd:	movs    	r2, #0
0x0004ff:	add     	r0, sb
0x000501:	adds    	r0, #0x14
0x000503:	movs    	r1, #0
0x000505:	str     	r1, [sp, #4]
0x000507:	str     	r0, [sp]
0x000509:	str     	r2, [sp, #8]
0x00050b:	adds    	r2, r4, #0
0x00050d:	movs    	r0, #0xf1
0x00050f:	movs    	r1, #0x29
0x000511:	movs    	r3, #0
0x000513:	lsls    	r0, r0, #9
0x000515:	bl      	#0x5159
; block 0x519
0x000519:	b       	#0x439
; block 0x51b
0x00051b:	movs    	r1, #0
0x00051d:	movs    	r2, #0
0x00051f:	str     	r2, [sp, #8]
0x000521:	str     	r1, [sp]
0x000523:	str     	r1, [sp, #4]
0x000525:	movs    	r4, #0
0x000527:	adds    	r3, r4, #0
0x000529:	movs    	r1, #0xe1
0x00052b:	movs    	r2, #0x25
0x00052d:	movs    	r0, #0xf1
0x00052f:	lsls    	r0, r0, #9
0x000531:	bl      	#0x5159
; block 0x535
0x000535:	movs    	r2, #0
0x000537:	movs    	r1, #0
0x000539:	str     	r2, [sp, #8]
0x00053b:	adds    	r2, r0, #0
0x00053d:	str     	r1, [sp]
0x00053f:	str     	r1, [sp, #4]
0x000541:	movs    	r1, #0x11
0x000543:	movs    	r0, #0xf1
0x000545:	movs    	r3, #4
0x000547:	lsls    	r0, r0, #9
0x000549:	bl      	#0x5159
; block 0x54d
0x00054d:	adds    	r5, r0, #0
0x00054f:	ldr     	r0, [pc, #0x260]
0x000551:	movs    	r2, #0
0x000553:	add     	r0, sb
0x000555:	subs    	r0, #4
0x000557:	movs    	r1, #0
0x000559:	str     	r1, [sp, #4]
0x00055b:	str     	r0, [sp]
0x00055d:	str     	r2, [sp, #8]
0x00055f:	adds    	r3, r4, #0
0x000561:	adds    	r2, r5, #0
0x000563:	movs    	r0, #0xf1
0x000565:	movs    	r1, #0x29
0x000567:	lsls    	r0, r0, #9
0x000569:	bl      	#0x5159
; block 0x56d
0x00056d:	bl      	#0x6005
; block 0x571
0x000571:	b       	#0x439

; ===== sub_573 @ 0x573 offset=0x572 size=182 blocks=15 cc=9 =====
; block 0x573
0x000573:	ldr     	r6, [pc, #0x23c]
0x000575:	add     	r6, sb
0x000577:	subs    	r6, #8
0x000579:	ldr     	r0, [r6, #8]
0x00057b:	cmp     	r0, #0
0x00057d:	beq     	#0x49d
; block 0x57f
0x00057f:	cmp     	r0, #1
0x000581:	beq     	#0x49d
; block 0x583
0x000583:	cmp     	r0, #2
0x000585:	beq     	#0x5d1
; block 0x587
0x000587:	cmp     	r0, #3
0x000589:	bne     	#0x49d
; block 0x58b
0x00058b:	ldr     	r7, [r6]
0x00058d:	cmp     	r7, #0
0x00058f:	beq     	#0x5ad
; block 0x591
0x000591:	movs    	r1, #0
0x000593:	movs    	r2, #0
0x000595:	movs    	r5, #0
0x000597:	adds    	r3, r5, #0
0x000599:	str     	r2, [sp, #8]
0x00059b:	str     	r1, [sp]
0x00059d:	str     	r1, [sp, #4]
0x00059f:	movs    	r1, #0x4c
0x0005a1:	adds    	r2, r7, #0
0x0005a3:	movs    	r0, #0xf1
0x0005a5:	lsls    	r0, r0, #9
0x0005a7:	bl      	#0x5159
; block 0x5ab
0x0005ab:	str     	r5, [r6]
0x0005ad:	bl      	#0x49bd
; block 0x5ad
0x0005ad:	bl      	#0x49bd
; block 0x5b1
0x0005b1:	ldr     	r0, [pc, #0x1fc]
0x0005b3:	movs    	r2, #0
0x0005b5:	add     	r0, sb
0x0005b7:	adds    	r0, #0x14
0x0005b9:	movs    	r1, #1
0x0005bb:	str     	r1, [sp, #4]
0x0005bd:	str     	r0, [sp]
0x0005bf:	str     	r2, [sp, #8]
0x0005c1:	adds    	r2, r4, #0
0x0005c3:	movs    	r0, #0xf1
0x0005c5:	movs    	r1, #0x29
0x0005c7:	movs    	r3, #0
0x0005c9:	lsls    	r0, r0, #9
0x0005cb:	bl      	#0x5159
; block 0x5cf
0x0005cf:	b       	#0x439
; block 0x5d1
0x0005d1:	movs    	r1, #0
0x0005d3:	movs    	r2, #0
0x0005d5:	str     	r2, [sp, #8]
0x0005d7:	str     	r1, [sp]
0x0005d9:	str     	r1, [sp, #4]
0x0005db:	movs    	r4, #0
0x0005dd:	adds    	r3, r4, #0
0x0005df:	movs    	r1, #0xe1
0x0005e1:	movs    	r2, #0x25
0x0005e3:	movs    	r0, #0xf1
0x0005e5:	lsls    	r0, r0, #9
0x0005e7:	bl      	#0x5159
; block 0x5eb
0x0005eb:	movs    	r2, #0
0x0005ed:	movs    	r1, #0
0x0005ef:	str     	r2, [sp, #8]
0x0005f1:	adds    	r2, r0, #0
0x0005f3:	str     	r1, [sp]
0x0005f5:	str     	r1, [sp, #4]
0x0005f7:	movs    	r1, #0x11
0x0005f9:	movs    	r0, #0xf1
0x0005fb:	movs    	r3, #4
0x0005fd:	lsls    	r0, r0, #9
0x0005ff:	bl      	#0x5159
; block 0x603
0x000603:	adds    	r5, r0, #0
0x000605:	ldr     	r0, [pc, #0x1a8]
0x000607:	movs    	r2, #0
0x000609:	add     	r0, sb
0x00060b:	subs    	r0, #4
0x00060d:	movs    	r1, #0
0x00060f:	str     	r1, [sp, #4]
0x000611:	str     	r0, [sp]
0x000613:	str     	r2, [sp, #8]
0x000615:	adds    	r3, r4, #0
0x000617:	adds    	r2, r5, #0
0x000619:	movs    	r0, #0xf1
0x00061b:	movs    	r1, #0x29
0x00061d:	lsls    	r0, r0, #9
0x00061f:	bl      	#0x5159
; block 0x623
0x000623:	bl      	#0x6005
; block 0x627
0x000627:	b       	#0x439

; ===== sub_629 @ 0x629 offset=0x628 size=230 blocks=16 cc=11 =====
; block 0x629
0x000629:	movs    	r1, #0
0x00062b:	movs    	r2, #0
0x00062d:	str     	r2, [sp, #8]
0x00062f:	str     	r1, [sp]
0x000631:	str     	r1, [sp, #4]
0x000633:	movs    	r4, #0
0x000635:	movs    	r5, #0xf1
0x000637:	lsls    	r5, r5, #9
0x000639:	adds    	r3, r4, #0
0x00063b:	movs    	r1, #0xe1
0x00063d:	movs    	r2, #0x1e
0x00063f:	adds    	r0, r5, #0
0x000641:	bl      	#0x5159
; block 0x645
0x000645:	cmp     	r0, #0
0x000647:	beq     	#0x66f
; block 0x649
0x000649:	movs    	r1, #0
0x00064b:	movs    	r2, #0
0x00064d:	str     	r2, [sp, #8]
0x00064f:	str     	r1, [sp]
0x000651:	str     	r1, [sp, #4]
0x000653:	movs    	r1, #0xe1
0x000655:	movs    	r2, #0x1e
0x000657:	adds    	r3, r4, #0
0x000659:	adds    	r0, r5, #0
0x00065b:	bl      	#0x5159
; block 0x65f
0x00065f:	ldr     	r1, [pc, #0x154]
0x000661:	add     	r1, pc
0x000663:	ldr     	r2, [pc, #0x154]
0x000665:	add     	r2, sb
0x000667:	ldr     	r2, [r2]
0x000669:	blx     	r2
; block 0x66b
0x00066b:	cmp     	r0, #0
0x00066d:	bne     	#0x689
; block 0x66f
0x00066f:	movs    	r2, #0
0x000671:	movs    	r1, #0
0x000673:	str     	r2, [sp, #8]
0x000675:	ldr     	r2, [pc, #0x144]
0x000677:	str     	r1, [sp]
0x000679:	str     	r1, [sp, #4]
0x00067b:	adds    	r3, r4, #0
0x00067d:	add     	r2, pc
0x00067f:	movs    	r1, #0x33
0x000681:	adds    	r0, r5, #0
0x000683:	bl      	#0x5159
; block 0x687
0x000687:	b       	#0x439
; block 0x689
0x000689:	movs    	r1, #0
0x00068b:	movs    	r2, #0
0x00068d:	str     	r2, [sp, #8]
0x00068f:	str     	r1, [sp]
0x000691:	str     	r1, [sp, #4]
0x000693:	movs    	r1, #0xe1
0x000695:	movs    	r2, #0x1e
0x000697:	adds    	r3, r4, #0
0x000699:	adds    	r0, r5, #0
0x00069b:	bl      	#0x5159
; block 0x69f
0x00069f:	movs    	r2, #0
0x0006a1:	movs    	r1, #0
0x0006a3:	str     	r2, [sp, #8]
0x0006a5:	adds    	r3, r4, #0
0x0006a7:	adds    	r2, r0, #0
0x0006a9:	str     	r1, [sp]
0x0006ab:	str     	r1, [sp, #4]
0x0006ad:	movs    	r1, #0x54
0x0006af:	movs    	r0, #0xf1
0x0006b1:	lsls    	r0, r0, #9
0x0006b3:	bl      	#0x5159
; block 0x6b7
0x0006b7:	cmp     	r0, #6
0x0006b9:	ble     	#0x6d5
; block 0x6bb
0x0006bb:	movs    	r2, #0
0x0006bd:	movs    	r1, #0
0x0006bf:	str     	r2, [sp, #8]
0x0006c1:	ldr     	r2, [pc, #0xfc]
0x0006c3:	str     	r1, [sp]
0x0006c5:	str     	r1, [sp, #4]
0x0006c7:	adds    	r3, r4, #0
0x0006c9:	add     	r2, pc
0x0006cb:	movs    	r1, #0x33
0x0006cd:	adds    	r0, r5, #0
0x0006cf:	bl      	#0x5159
; block 0x6d3
0x0006d3:	b       	#0x439
; block 0x6d5
0x0006d5:	movs    	r1, #0
0x0006d7:	str     	r1, [sp]
0x0006d9:	str     	r1, [sp, #4]
0x0006db:	movs    	r2, #0
0x0006dd:	movs    	r1, #0x34
0x0006df:	adds    	r3, r4, #0
0x0006e1:	adds    	r0, r5, #0
0x0006e3:	str     	r2, [sp, #8]
0x0006e5:	bl      	#0x5159
; block 0x6e9
0x0006e9:	movs    	r1, #0
0x0006eb:	movs    	r2, #0
0x0006ed:	str     	r2, [sp, #8]
0x0006ef:	str     	r1, [sp]
0x0006f1:	str     	r1, [sp, #4]
0x0006f3:	movs    	r1, #0xe1
0x0006f5:	movs    	r2, #0x1e
0x0006f7:	adds    	r3, r4, #0
0x0006f9:	movs    	r0, #0xf1
0x0006fb:	lsls    	r0, r0, #9
0x0006fd:	bl      	#0x5159
; block 0x701
0x000701:	ldr     	r1, [pc, #0xac]
0x000703:	add     	r1, sb
0x000705:	subs    	r1, #8
0x000707:	ldr     	r1, [r1, #0x1c]
0x000709:	bl      	#0x6039
; block 0x70d
0x00070d:	b       	#0x439

; ===== sub_70f @ 0x70f offset=0x70e size=160 blocks=13 cc=7 =====
; block 0x70f
0x00070f:	ldr     	r0, [pc, #0xa0]
0x000711:	add     	r0, sb
0x000713:	subs    	r0, #8
0x000715:	ldr     	r0, [r0, #8]
0x000717:	cmp     	r0, #0
0x000719:	beq     	#0x72b
; block 0x71b
0x00071b:	cmp     	r0, #1
0x00071d:	beq     	#0x779
; block 0x71f
0x00071f:	cmp     	r0, #2
0x000721:	beq     	#0x7ab
; block 0x723
0x000723:	cmp     	r0, #3
0x000725:	bne     	#0x687
; block 0x727
0x000727:	movs    	r0, #0xf
0x000729:	b       	#0x3f5
; block 0x72b
0x00072b:	movs    	r1, #0
0x00072d:	movs    	r0, #3
0x00072f:	str     	r0, [sp]
0x000731:	str     	r1, [sp, #4]
0x000733:	movs    	r2, #0
0x000735:	movs    	r1, #0x53
0x000737:	movs    	r0, #0xf1
0x000739:	movs    	r3, #6
0x00073b:	lsls    	r0, r0, #9
0x00073d:	str     	r2, [sp, #8]
0x00073f:	bl      	#0x5159
; block 0x743
0x000743:	movs    	r1, #0
0x000745:	movs    	r2, #0
0x000747:	str     	r2, [sp, #8]
0x000749:	str     	r1, [sp]
0x00074b:	str     	r1, [sp, #4]
0x00074d:	movs    	r4, #0
0x00074f:	adds    	r3, r4, #0
0x000751:	movs    	r1, #0xe1
0x000753:	movs    	r2, #0x1e
0x000755:	movs    	r0, #0xf1
0x000757:	lsls    	r0, r0, #9
0x000759:	bl      	#0x5159
; block 0x75d
0x00075d:	movs    	r2, #0
0x00075f:	movs    	r1, #0
0x000761:	str     	r2, [sp, #8]
0x000763:	adds    	r2, r0, #0
0x000765:	str     	r1, [sp]
0x000767:	str     	r1, [sp, #4]
0x000769:	movs    	r1, #0xff
0x00076b:	adds    	r3, r4, #0
0x00076d:	adds    	r1, #0x1f
0x00076f:	movs    	r0, #0xf1
0x000771:	lsls    	r0, r0, #9
0x000773:	bl      	#0x5159
; block 0x777
0x000777:	b       	#0x439
; block 0x779
0x000779:	movs    	r1, #0
0x00077b:	str     	r1, [sp]
0x00077d:	str     	r1, [sp, #4]
0x00077f:	movs    	r2, #0
0x000781:	movs    	r1, #0x34
0x000783:	movs    	r3, #0
0x000785:	movs    	r0, #0xf1
0x000787:	lsls    	r0, r0, #9
0x000789:	str     	r2, [sp, #8]
0x00078b:	bl      	#0x5159
; block 0x78f
0x00078f:	movs    	r2, #0
0x000791:	movs    	r1, #0
0x000793:	str     	r2, [sp, #8]
0x000795:	movs    	r2, #0xff
0x000797:	str     	r1, [sp]
0x000799:	str     	r1, [sp, #4]
0x00079b:	movs    	r1, #0x50
0x00079d:	adds    	r2, #0x14
0x00079f:	movs    	r3, #1
0x0007a1:	movs    	r0, #0xf1
0x0007a3:	lsls    	r0, r0, #9
0x0007a5:	bl      	#0x5159
; block 0x7a9
0x0007a9:	b       	#0x439
; block 0x7ab
0x0007ab:	movs    	r0, #0xf
0x0007ad:	b       	#0x3f5

; ===== sub_7c5 @ 0x7c5 offset=0x7c4 size=210 blocks=13 cc=10 =====
; block 0x7c5
0x0007c5:	push    	{r4, r5, r6, r7, lr}
0x0007c7:	sub     	sp, #0xc
0x0007c9:	movs    	r1, #0
0x0007cb:	movs    	r2, #0
0x0007cd:	str     	r2, [sp, #8]
0x0007cf:	str     	r1, [sp]
0x0007d1:	str     	r1, [sp, #4]
0x0007d3:	movs    	r7, #0xf1
0x0007d5:	movs    	r6, #0
0x0007d7:	adds    	r3, r6, #0
0x0007d9:	lsls    	r7, r7, #9
0x0007db:	movs    	r1, #0x44
0x0007dd:	adds    	r2, r0, #0
0x0007df:	adds    	r4, r0, #0
0x0007e1:	adds    	r0, r7, #0
0x0007e3:	bl      	#0x5159
; block 0x7e7
0x0007e7:	movs    	r1, #0
0x0007e9:	str     	r1, [sp]
0x0007eb:	str     	r1, [sp, #4]
0x0007ed:	movs    	r2, #0
0x0007ef:	str     	r2, [sp, #8]
0x0007f1:	movs    	r1, #0x47
0x0007f3:	adds    	r3, r6, #0
0x0007f5:	adds    	r0, r7, #0
0x0007f7:	ldr     	r2, [r4, #8]
0x0007f9:	bl      	#0x5159
; block 0x7fd
0x0007fd:	movs    	r1, #0
0x0007ff:	str     	r1, [sp]
0x000801:	str     	r1, [sp, #4]
0x000803:	movs    	r2, #0
0x000805:	str     	r2, [sp, #8]
0x000807:	movs    	r1, #0x45
0x000809:	adds    	r5, r0, #0
0x00080b:	adds    	r3, r6, #0
0x00080d:	adds    	r0, r7, #0
0x00080f:	ldr     	r2, [r4, #8]
0x000811:	bl      	#0x5159
; block 0x815
0x000815:	cmp     	r0, #0
0x000817:	bne     	#0x839
; block 0x819
0x000819:	bl      	#0x4089
; block 0x81d
0x00081d:	movs    	r2, #0
0x00081f:	movs    	r1, #0
0x000821:	str     	r1, [sp, #4]
0x000823:	str     	r2, [sp, #8]
0x000825:	movs    	r0, #2
0x000827:	str     	r0, [sp]
0x000829:	movs    	r2, #0x1e
0x00082b:	movs    	r1, #0x14
0x00082d:	adds    	r3, r5, #0
0x00082f:	adds    	r0, r7, #0
0x000831:	bl      	#0x5159
; block 0x835
0x000835:	add     	sp, #0xc
0x000837:	pop     	{r4, r5, r6, r7, pc}
; block 0x839
0x000839:	movs    	r1, #0
0x00083b:	movs    	r2, #0
0x00083d:	str     	r2, [sp, #8]
0x00083f:	str     	r1, [sp]
0x000841:	str     	r1, [sp, #4]
0x000843:	movs    	r1, #0xe1
0x000845:	movs    	r2, #0x1e
0x000847:	adds    	r3, r6, #0
0x000849:	adds    	r0, r7, #0
0x00084b:	bl      	#0x5159
; block 0x84f
0x00084f:	adds    	r4, r0, #0
0x000851:	beq     	#0x869
; block 0x853
0x000853:	movs    	r1, #0
0x000855:	movs    	r2, #0
0x000857:	str     	r2, [sp, #8]
0x000859:	str     	r1, [sp]
0x00085b:	str     	r1, [sp, #4]
0x00085d:	movs    	r1, #9
0x00085f:	adds    	r2, r4, #0
0x000861:	adds    	r3, r6, #0
0x000863:	adds    	r0, r7, #0
0x000865:	bl      	#0x5159
; block 0x869
0x000869:	movs    	r1, #0
0x00086b:	movs    	r2, #0
0x00086d:	str     	r2, [sp, #8]
0x00086f:	str     	r1, [sp]
0x000871:	str     	r1, [sp, #4]
0x000873:	movs    	r1, #0x14
0x000875:	movs    	r2, #0x1e
0x000877:	adds    	r3, r5, #0
0x000879:	adds    	r0, r7, #0
0x00087b:	bl      	#0x5159
; block 0x87f
0x00087f:	movs    	r1, #0
0x000881:	str     	r1, [sp]
0x000883:	str     	r1, [sp, #4]
0x000885:	movs    	r2, #0
0x000887:	movs    	r1, #0x2c
0x000889:	adds    	r3, r6, #0
0x00088b:	movs    	r0, #0xf1
0x00088d:	lsls    	r0, r0, #9
0x00088f:	str     	r2, [sp, #8]
0x000891:	bl      	#0x5159
; block 0x895
0x000895:	b       	#0x835

; ===== sub_899 @ 0x899 offset=0x898 size=340 blocks=33 cc=21 =====
; block 0x899
0x000899:	push    	{r4, r5, r6, r7, lr}
0x00089b:	ldr     	r6, [pc, #0x160]
0x00089d:	movs    	r4, #0xf1
0x00089f:	add     	r6, sb
0x0008a1:	ldr     	r0, [r6, #0x20]
0x0008a3:	lsls    	r4, r4, #9
0x0008a5:	movs    	r7, #1
0x0008a7:	cmp     	r0, #0
0x0008a9:	sub     	sp, #0xc
0x0008ab:	beq     	#0x8d3
; block 0x8ad
0x0008ad:	cmp     	r0, #1
0x0008af:	beq     	#0x995
; block 0x8b1
0x0008b1:	cmp     	r0, #2
0x0008b3:	beq     	#0x997
; block 0x8b5
0x0008b5:	cmp     	r0, #3
0x0008b7:	bne     	#0x8cf
; block 0x8b9
0x0008b9:	movs    	r1, #0
0x0008bb:	movs    	r2, #0
0x0008bd:	str     	r2, [sp, #8]
0x0008bf:	str     	r1, [sp]
0x0008c1:	str     	r1, [sp, #4]
0x0008c3:	movs    	r1, #0x14
0x0008c5:	movs    	r2, #0x23
0x0008c7:	adds    	r3, r7, #0
0x0008c9:	adds    	r0, r4, #0
0x0008cb:	bl      	#0x5159
; block 0x8d3
0x0008d3:	ldr     	r3, [r6, #0x24]
0x0008d5:	movs    	r5, #0
0x0008d7:	cmp     	r3, #0
0x0008d9:	beq     	#0x8f1
; block 0x8db
0x0008db:	movs    	r1, #0
0x0008dd:	movs    	r2, #0
0x0008df:	str     	r2, [sp, #8]
0x0008e1:	str     	r1, [sp]
0x0008e3:	str     	r1, [sp, #4]
0x0008e5:	movs    	r1, #6
0x0008e7:	adds    	r2, r3, #0
0x0008e9:	adds    	r0, r4, #0
0x0008eb:	adds    	r3, r5, #0
0x0008ed:	bl      	#0x5159
; block 0x8f1
0x0008f1:	str     	r5, [r6, #0x24]
0x0008f3:	ldr     	r3, [r6, #0x28]
0x0008f5:	cmp     	r3, #0
0x0008f7:	beq     	#0x90f
; block 0x8f9
0x0008f9:	movs    	r1, #0
0x0008fb:	movs    	r2, #0
0x0008fd:	str     	r2, [sp, #8]
0x0008ff:	str     	r1, [sp]
0x000901:	str     	r1, [sp, #4]
0x000903:	movs    	r1, #6
0x000905:	adds    	r2, r3, #0
0x000907:	adds    	r0, r4, #0
0x000909:	adds    	r3, r5, #0
0x00090b:	bl      	#0x5159
; block 0x90f
0x00090f:	str     	r5, [r6, #0x28]
0x000911:	ldr     	r3, [r6, #0x2c]
0x000913:	cmp     	r3, #0
0x000915:	beq     	#0x92d
; block 0x917
0x000917:	movs    	r1, #0
0x000919:	movs    	r2, #0
0x00091b:	str     	r2, [sp, #8]
0x00091d:	str     	r1, [sp]
0x00091f:	str     	r1, [sp, #4]
0x000921:	movs    	r1, #6
0x000923:	adds    	r2, r3, #0
0x000925:	adds    	r0, r4, #0
0x000927:	adds    	r3, r5, #0
0x000929:	bl      	#0x5159
; block 0x92d
0x00092d:	str     	r5, [r6, #0x2c]
0x00092f:	ldr     	r3, [r6, #0x30]
0x000931:	cmp     	r3, #0
0x000933:	beq     	#0x94b
; block 0x935
0x000935:	movs    	r1, #0
0x000937:	movs    	r2, #0
0x000939:	str     	r2, [sp, #8]
0x00093b:	str     	r1, [sp]
0x00093d:	str     	r1, [sp, #4]
0x00093f:	movs    	r1, #6
0x000941:	adds    	r2, r3, #0
0x000943:	adds    	r0, r4, #0
0x000945:	adds    	r3, r5, #0
0x000947:	bl      	#0x5159
; block 0x94b
0x00094b:	str     	r5, [r6, #0x30]
0x00094d:	ldr     	r3, [r6, #0x34]
0x00094f:	cmp     	r3, #0
0x000951:	beq     	#0x969
; block 0x953
0x000953:	movs    	r1, #0
0x000955:	movs    	r2, #0
0x000957:	str     	r2, [sp, #8]
0x000959:	str     	r1, [sp]
0x00095b:	str     	r1, [sp, #4]
0x00095d:	movs    	r1, #6
0x00095f:	adds    	r2, r3, #0
0x000961:	adds    	r0, r4, #0
0x000963:	adds    	r3, r5, #0
0x000965:	bl      	#0x5159
; block 0x969
0x000969:	str     	r5, [r6, #0x34]
0x00096b:	ldr     	r3, [r6, #0x38]
0x00096d:	cmp     	r3, #0
0x00096f:	beq     	#0x987
; block 0x971
0x000971:	movs    	r1, #0
0x000973:	movs    	r2, #0
0x000975:	str     	r2, [sp, #8]
0x000977:	str     	r1, [sp]
0x000979:	str     	r1, [sp, #4]
0x00097b:	movs    	r1, #6
0x00097d:	adds    	r2, r3, #0
0x00097f:	adds    	r0, r4, #0
0x000981:	adds    	r3, r5, #0
0x000983:	bl      	#0x5159
; block 0x987
0x000987:	str     	r5, [r6, #0x38]
0x000989:	ldr     	r3, [r6, #0x3c]
0x00098b:	cmp     	r3, #0
0x00098d:	beq     	#0x9ab
; block 0x98f
0x00098f:	movs    	r2, #0
0x000991:	movs    	r1, #0
0x000993:	b       	#0x999
; block 0x995
0x000995:	b       	#0x9f1
; block 0x997
0x000997:	b       	#0x9f7
; block 0x999
0x000999:	str     	r1, [sp]
0x00099b:	str     	r1, [sp, #4]
0x00099d:	str     	r2, [sp, #8]
0x00099f:	adds    	r2, r3, #0
0x0009a1:	movs    	r1, #6
0x0009a3:	adds    	r0, r4, #0
0x0009a5:	adds    	r3, r5, #0
0x0009a7:	bl      	#0x5159
; block 0x9ab
0x0009ab:	str     	r5, [r6, #0x3c]
0x0009ad:	ldr     	r3, [r6, #0x40]
0x0009af:	cmp     	r3, #0
0x0009b1:	beq     	#0x9c9
; block 0x9b3
0x0009b3:	movs    	r1, #0
0x0009b5:	movs    	r2, #0
0x0009b7:	str     	r2, [sp, #8]
0x0009b9:	str     	r1, [sp]
0x0009bb:	str     	r1, [sp, #4]
0x0009bd:	movs    	r1, #6
0x0009bf:	adds    	r2, r3, #0
0x0009c1:	adds    	r0, r4, #0
0x0009c3:	adds    	r3, r5, #0
0x0009c5:	bl      	#0x5159
; block 0x9c9
0x0009c9:	str     	r5, [r6, #0x40]
0x0009cb:	movs    	r1, #0
0x0009cd:	movs    	r2, #0
0x0009cf:	str     	r2, [sp, #8]
0x0009d1:	str     	r1, [sp]
0x0009d3:	str     	r1, [sp, #4]
0x0009d5:	movs    	r1, #0x14
0x0009d7:	movs    	r2, #0x1f
0x0009d9:	adds    	r3, r7, #0
0x0009db:	adds    	r0, r4, #0
0x0009dd:	bl      	#0x5159
; block 0x9e1
0x0009e1:	ldr     	r0, [r6, #0xc]
0x0009e3:	cmp     	r0, #0
0x0009e5:	beq     	#0x9eb
; block 0x9e7
0x0009e7:	bl      	#0x5ebd
; block 0x9eb
0x0009eb:	bl      	#0x634d
; block 0x9ef
0x0009ef:	b       	#0x8cf
; block 0x9f1
0x0009f1:	bl      	#0x4301
; block 0x9f5
0x0009f5:	b       	#0x8cf
; block 0x9f7
0x0009f7:	bl      	#0x4021
; block 0x9fb
0x0009fb:	b       	#0x8cf

; ===== sub_9fd @ 0x9fd offset=0x9fc size=4 blocks=1 cc=1 =====
; block 0x9fd
0x0009fd:	movs    	r4, r1
0x0009ff:	movs    	r0, r0
0x000a01:	push    	{r4, r5, r6, r7, lr}
0x000a03:	ldr     	r1, [pc, #0x180]
0x000a05:	sub     	sp, #0xc
0x000a07:	adds    	r4, r0, #0
0x000a09:	add     	r1, pc
0x000a0b:	ldr     	r7, [pc, #0x17c]
0x000a0d:	add     	r7, sb
0x000a0f:	ldr     	r2, [r7]
0x000a11:	blx     	r2

; ===== sub_a01 @ 0xa01 offset=0xa00 size=386 blocks=31 cc=21 =====
; block 0xa01
0x000a01:	push    	{r4, r5, r6, r7, lr}
0x000a03:	ldr     	r1, [pc, #0x180]
0x000a05:	sub     	sp, #0xc
0x000a07:	adds    	r4, r0, #0
0x000a09:	add     	r1, pc
0x000a0b:	ldr     	r7, [pc, #0x17c]
0x000a0d:	add     	r7, sb
0x000a0f:	ldr     	r2, [r7]
0x000a11:	blx     	r2
; block 0xa13
0x000a13:	movs    	r5, #0xf1
0x000a15:	lsls    	r5, r5, #9
0x000a17:	movs    	r6, #0
0x000a19:	cmp     	r0, #0
0x000a1b:	bne     	#0xa39
; block 0xa1d
0x000a1d:	bl      	#0x5e89
; block 0xa21
0x000a21:	movs    	r1, #0
0x000a23:	str     	r1, [sp]
0x000a25:	str     	r1, [sp, #4]
0x000a27:	movs    	r2, #0
0x000a29:	movs    	r1, #0x2c
0x000a2b:	adds    	r3, r6, #0
0x000a2d:	adds    	r0, r5, #0
0x000a2f:	str     	r2, [sp, #8]
0x000a31:	bl      	#0x5159
; block 0xa35
0x000a35:	add     	sp, #0xc
0x000a37:	pop     	{r4, r5, r6, r7, pc}
; block 0xa39
0x000a39:	ldr     	r1, [pc, #0x150]
0x000a3b:	add     	r1, pc
0x000a3d:	ldr     	r2, [r7]
0x000a3f:	adds    	r0, r4, #0
0x000a41:	blx     	r2
; block 0xa43
0x000a43:	cmp     	r0, #0
0x000a45:	bne     	#0xa65
; block 0xa47
0x000a47:	bl      	#0x5e89
; block 0xa4b
0x000a4b:	movs    	r2, #0
0x000a4d:	movs    	r1, #0
0x000a4f:	str     	r2, [sp, #8]
0x000a51:	movs    	r2, #0xff
0x000a53:	str     	r1, [sp]
0x000a55:	str     	r1, [sp, #4]
0x000a57:	movs    	r1, #0x50
0x000a59:	adds    	r2, #0x14
0x000a5b:	adds    	r3, r6, #0
0x000a5d:	adds    	r0, r5, #0
0x000a5f:	bl      	#0x5159
; block 0xa63
0x000a63:	b       	#0xa35
; block 0xa65
0x000a65:	ldr     	r1, [pc, #0x128]
0x000a67:	add     	r1, pc
0x000a69:	ldr     	r7, [pc, #0x11c]
0x000a6b:	adds    	r0, r4, #0
0x000a6d:	add     	r7, sb
0x000a6f:	ldr     	r2, [r7]
0x000a71:	blx     	r2
; block 0xa73
0x000a73:	cmp     	r0, #0
0x000a75:	ldr     	r7, [pc, #0x11c]
0x000a77:	add     	r7, sb
0x000a79:	bne     	#0xb2f
; block 0xa7b
0x000a7b:	movs    	r1, #0
0x000a7d:	movs    	r2, #0
0x000a7f:	str     	r2, [sp, #8]
0x000a81:	str     	r1, [sp]
0x000a83:	str     	r1, [sp, #4]
0x000a85:	movs    	r1, #0xe1
0x000a87:	movs    	r2, #0x20
0x000a89:	adds    	r3, r6, #0
0x000a8b:	adds    	r0, r5, #0
0x000a8d:	bl      	#0x5159
; block 0xa91
0x000a91:	cmp     	r0, #0
0x000a93:	bne     	#0xaaf
; block 0xa95
0x000a95:	movs    	r2, #0
0x000a97:	movs    	r1, #0
0x000a99:	str     	r2, [sp, #8]
0x000a9b:	ldr     	r2, [pc, #0xfc]
0x000a9d:	str     	r1, [sp]
0x000a9f:	str     	r1, [sp, #4]
0x000aa1:	adds    	r3, r6, #0
0x000aa3:	add     	r2, pc
0x000aa5:	movs    	r1, #0x51
0x000aa7:	adds    	r0, r5, #0
0x000aa9:	bl      	#0x5159
; block 0xaad
0x000aad:	b       	#0xa35
; block 0xaaf
0x000aaf:	movs    	r1, #0
0x000ab1:	str     	r1, [sp]
0x000ab3:	str     	r1, [sp, #4]
0x000ab5:	movs    	r2, #0
0x000ab7:	str     	r2, [sp, #8]
0x000ab9:	ldr     	r2, [r7, #0x18]
0x000abb:	movs    	r1, #0x27
0x000abd:	adds    	r0, r5, #0
0x000abf:	ldr     	r3, [r7, #0x10]
0x000ac1:	bl      	#0x5159
; block 0xac5
0x000ac5:	movs    	r1, #0
0x000ac7:	adds    	r4, r0, #0
0x000ac9:	movs    	r2, #0
0x000acb:	str     	r2, [sp, #8]
0x000acd:	str     	r1, [sp]
0x000acf:	str     	r1, [sp, #4]
0x000ad1:	movs    	r1, #0x14
0x000ad3:	movs    	r2, #0x20
0x000ad5:	movs    	r0, #0xf1
0x000ad7:	adds    	r3, r6, #0
0x000ad9:	lsls    	r0, r0, #9
0x000adb:	bl      	#0x5159
; block 0xadf
0x000adf:	movs    	r1, #0
0x000ae1:	movs    	r2, #0
0x000ae3:	str     	r2, [sp, #8]
0x000ae5:	str     	r1, [sp]
0x000ae7:	str     	r1, [sp, #4]
0x000ae9:	movs    	r1, #0x9c
0x000aeb:	movs    	r2, #0x12
0x000aed:	adds    	r3, r6, #0
0x000aef:	movs    	r0, #0xf1
0x000af1:	lsls    	r0, r0, #9
0x000af3:	bl      	#0x5159
; block 0xaf7
0x000af7:	movs    	r1, #0
0x000af9:	str     	r1, [sp]
0x000afb:	str     	r1, [sp, #4]
0x000afd:	movs    	r2, #0
0x000aff:	movs    	r1, #0x34
0x000b01:	adds    	r3, r6, #0
0x000b03:	movs    	r0, #0xf1
0x000b05:	lsls    	r0, r0, #9
0x000b07:	str     	r2, [sp, #8]
0x000b09:	bl      	#0x5159
; block 0xb0d
0x000b0d:	movs    	r1, #0
0x000b0f:	movs    	r2, #0
0x000b11:	str     	r2, [sp, #8]
0x000b13:	str     	r1, [sp]
0x000b15:	str     	r1, [sp, #4]
0x000b17:	movs    	r1, #0xe1
0x000b19:	movs    	r2, #0x18
0x000b1b:	adds    	r3, r6, #0
0x000b1d:	movs    	r0, #0xf1
0x000b1f:	lsls    	r0, r0, #9
0x000b21:	bl      	#0x5159
; block 0xb25
0x000b25:	ldr     	r1, [r0, #8]
0x000b27:	ldr     	r0, [r4, #0x10]
0x000b29:	bl      	#0x6149
; block 0xb2d
0x000b2d:	b       	#0xa35
; block 0xb2f
0x000b2f:	ldr     	r1, [pc, #0x6c]
0x000b31:	add     	r1, pc
0x000b33:	ldr     	r2, [pc, #0x54]
0x000b35:	adds    	r0, r4, #0
0x000b37:	add     	r2, sb
0x000b39:	ldr     	r2, [r2]
0x000b3b:	blx     	r2
; block 0xb3d
0x000b3d:	cmp     	r0, #0
0x000b3f:	bne     	#0xa63
; block 0xb41
0x000b41:	movs    	r1, #0
0x000b43:	str     	r1, [sp]
0x000b45:	str     	r1, [sp, #4]
0x000b47:	movs    	r2, #0
0x000b49:	str     	r2, [sp, #8]
0x000b4b:	ldr     	r2, [r7, #0x18]
0x000b4d:	movs    	r1, #0x27
0x000b4f:	adds    	r0, r5, #0
0x000b51:	ldr     	r3, [r7, #0x10]
0x000b53:	bl      	#0x5159
; block 0xb57
0x000b57:	movs    	r1, #0
0x000b59:	adds    	r4, r0, #0
0x000b5b:	movs    	r2, #0
0x000b5d:	str     	r2, [sp, #8]
0x000b5f:	str     	r1, [sp]
0x000b61:	str     	r1, [sp, #4]
0x000b63:	movs    	r1, #0xe1
0x000b65:	movs    	r2, #0x18
0x000b67:	movs    	r0, #0xf1
0x000b69:	adds    	r3, r6, #0
0x000b6b:	lsls    	r0, r0, #9
0x000b6d:	bl      	#0x5159
; block 0xb71
0x000b71:	ldr     	r0, [r0, #8]
0x000b73:	ldr     	r1, [r4, #0x10]
0x000b75:	bl      	#0x4191
; block 0xb79
0x000b79:	bl      	#0x5e89
; block 0xb7d
0x000b7d:	bl      	#0x5d2d
; block 0xb81
0x000b81:	b       	#0xa35

; ===== sub_ba1 @ 0xba1 offset=0xba0 size=124 blocks=8 cc=4 =====
; block 0xba1
0x000ba1:	push    	{r4, r5, lr}
0x000ba3:	sub     	sp, #0xc
0x000ba5:	movs    	r5, #0
0x000ba7:	movs    	r2, #0
0x000ba9:	movs    	r1, #0
0x000bab:	str     	r2, [sp, #8]
0x000bad:	adds    	r3, r5, #0
0x000baf:	adds    	r4, r0, #0
0x000bb1:	adds    	r2, r0, #0
0x000bb3:	str     	r1, [sp]
0x000bb5:	str     	r1, [sp, #4]
0x000bb7:	movs    	r1, #0x44
0x000bb9:	movs    	r0, #0xf1
0x000bbb:	lsls    	r0, r0, #9
0x000bbd:	bl      	#0x5159
; block 0xbc1
0x000bc1:	movs    	r1, #0
0x000bc3:	str     	r1, [sp]
0x000bc5:	str     	r1, [sp, #4]
0x000bc7:	movs    	r2, #0
0x000bc9:	str     	r2, [sp, #8]
0x000bcb:	movs    	r1, #0x45
0x000bcd:	adds    	r3, r5, #0
0x000bcf:	movs    	r0, #0xf1
0x000bd1:	lsls    	r0, r0, #9
0x000bd3:	ldr     	r2, [r4, #8]
0x000bd5:	bl      	#0x5159
; block 0xbd9
0x000bd9:	movs    	r1, #0
0x000bdb:	adds    	r4, r0, #0
0x000bdd:	str     	r1, [sp]
0x000bdf:	str     	r1, [sp, #4]
0x000be1:	movs    	r2, #0
0x000be3:	movs    	r1, #0x2c
0x000be5:	movs    	r0, #0xf1
0x000be7:	adds    	r3, r5, #0
0x000be9:	lsls    	r0, r0, #9
0x000beb:	str     	r2, [sp, #8]
0x000bed:	bl      	#0x5159
; block 0xbf1
0x000bf1:	bl      	#0x59dd
; block 0xbf5
0x000bf5:	bl      	#0x5d2d
; block 0xbf9
0x000bf9:	movs    	r1, #0
0x000bfb:	movs    	r2, #0
0x000bfd:	str     	r2, [sp, #8]
0x000bff:	str     	r1, [sp]
0x000c01:	str     	r1, [sp, #4]
0x000c03:	movs    	r1, #0xe1
0x000c05:	movs    	r2, #0x18
0x000c07:	adds    	r3, r5, #0
0x000c09:	movs    	r0, #0xf1
0x000c0b:	lsls    	r0, r0, #9
0x000c0d:	bl      	#0x5159
; block 0xc11
0x000c11:	ldr     	r0, [r0, #8]
0x000c13:	adds    	r1, r4, #0
0x000c15:	bl      	#0x4191
; block 0xc19
0x000c19:	add     	sp, #0xc
0x000c1b:	pop     	{r4, r5, pc}

; ===== sub_c1d @ 0xc1d offset=0xc1c size=720 blocks=32 cc=26 =====
; block 0xc1d
0x000c1d:	push    	{r4, r5, r6, r7, lr}
0x000c1f:	sub     	sp, #0x54
0x000c21:	movs    	r1, #0
0x000c23:	movs    	r7, #0
0x000c25:	adds    	r4, r0, #0
0x000c27:	adds    	r5, r7, #0
0x000c29:	str     	r1, [sp]
0x000c2b:	str     	r1, [sp, #4]
0x000c2d:	movs    	r2, #0
0x000c2f:	movs    	r1, #0x13
0x000c31:	adds    	r3, r7, #0
0x000c33:	movs    	r0, #0xf1
0x000c35:	lsls    	r0, r0, #9
0x000c37:	str     	r2, [sp, #8]
0x000c39:	bl      	#0x5159
; block 0xc3d
0x000c3d:	movs    	r1, #0
0x000c3f:	movs    	r2, #0
0x000c41:	str     	r2, [sp, #8]
0x000c43:	str     	r1, [sp]
0x000c45:	str     	r1, [sp, #4]
0x000c47:	str     	r0, [sp, #0x4c]
0x000c49:	adds    	r3, r5, #0
0x000c4b:	adds    	r2, r4, #0
0x000c4d:	movs    	r0, #0xf1
0x000c4f:	movs    	r1, #0x44
0x000c51:	lsls    	r0, r0, #9
0x000c53:	bl      	#0x5159
; block 0xc57
0x000c57:	movs    	r1, #0
0x000c59:	str     	r1, [sp]
0x000c5b:	str     	r1, [sp, #4]
0x000c5d:	movs    	r2, #0
0x000c5f:	str     	r2, [sp, #8]
0x000c61:	movs    	r1, #0x45
0x000c63:	adds    	r3, r5, #0
0x000c65:	movs    	r0, #0xf1
0x000c67:	lsls    	r0, r0, #9
0x000c69:	ldr     	r2, [r4, #8]
0x000c6b:	bl      	#0x5159
; block 0xc6f
0x000c6f:	movs    	r6, #0
0x000c71:	cmp     	r0, #0
0x000c73:	str     	r0, [sp, #0x50]
0x000c75:	ble     	#0xd5d
; block 0xc77
0x000c77:	movs    	r1, #0
0x000c79:	movs    	r2, #0
0x000c7b:	str     	r2, [sp, #8]
0x000c7d:	str     	r1, [sp]
0x000c7f:	str     	r1, [sp, #4]
0x000c81:	movs    	r1, #0xf
0x000c83:	movs    	r2, #0x44
0x000c85:	adds    	r3, r7, #0
0x000c87:	movs    	r0, #0xf1
0x000c89:	lsls    	r0, r0, #9
0x000c8b:	bl      	#0x5159
; block 0xc8f
0x000c8f:	adds    	r5, r0, #0
0x000c91:	movs    	r0, #0
0x000c93:	movs    	r1, #0
0x000c95:	str     	r1, [sp, #4]
0x000c97:	str     	r0, [sp, #0x10]
0x000c99:	str     	r0, [sp]
0x000c9b:	movs    	r2, #0
0x000c9d:	str     	r2, [sp, #8]
0x000c9f:	movs    	r0, #0xf1
0x000ca1:	movs    	r1, #0x45
0x000ca3:	adds    	r3, r7, #0
0x000ca5:	lsls    	r0, r0, #9
0x000ca7:	ldr     	r2, [r4, #8]
0x000ca9:	bl      	#0x5159
; block 0xcad
0x000cad:	str     	r0, [sp, #0x44]
0x000caf:	movs    	r1, #0
0x000cb1:	str     	r1, [sp]
0x000cb3:	str     	r1, [sp, #4]
0x000cb5:	movs    	r2, #0
0x000cb7:	str     	r2, [sp, #8]
0x000cb9:	movs    	r1, #0x47
0x000cbb:	movs    	r0, #0xf1
0x000cbd:	adds    	r3, r7, #0
0x000cbf:	lsls    	r0, r0, #9
0x000cc1:	ldr     	r2, [r4, #8]
0x000cc3:	bl      	#0x5159
; block 0xcc7
0x000cc7:	str     	r0, [sp, #0x48]
0x000cc9:	movs    	r1, #0
0x000ccb:	movs    	r2, #0
0x000ccd:	str     	r2, [sp, #8]
0x000ccf:	str     	r1, [sp]
0x000cd1:	str     	r1, [sp, #4]
0x000cd3:	adds    	r3, r7, #0
0x000cd5:	adds    	r2, r4, #0
0x000cd7:	movs    	r1, #0x48
0x000cd9:	movs    	r0, #0xf1
0x000cdb:	lsls    	r0, r0, #9
0x000cdd:	bl      	#0x5159
; block 0xce1
0x000ce1:	movs    	r1, #0
0x000ce3:	str     	r1, [sp]
0x000ce5:	str     	r1, [sp, #4]
0x000ce7:	str     	r0, [sp, #0x1c]
0x000ce9:	movs    	r2, #0
0x000ceb:	str     	r2, [sp, #8]
0x000ced:	movs    	r0, #0xf1
0x000cef:	movs    	r1, #0x45
0x000cf1:	adds    	r3, r7, #0
0x000cf3:	lsls    	r0, r0, #9
0x000cf5:	ldr     	r2, [r4, #8]
0x000cf7:	bl      	#0x5159
; block 0xcfb
0x000cfb:	str     	r0, [sp, #0x40]
0x000cfd:	movs    	r1, #0
0x000cff:	str     	r1, [sp]
0x000d01:	str     	r1, [sp, #4]
0x000d03:	movs    	r2, #0
0x000d05:	str     	r2, [sp, #8]
0x000d07:	movs    	r1, #0x45
0x000d09:	movs    	r0, #0xf1
0x000d0b:	adds    	r3, r7, #0
0x000d0d:	lsls    	r0, r0, #9
0x000d0f:	ldr     	r2, [r4, #8]
0x000d11:	bl      	#0x5159
; block 0xd15
0x000d15:	movs    	r1, #0
0x000d17:	str     	r1, [sp]
0x000d19:	str     	r1, [sp, #4]
0x000d1b:	str     	r0, [sp, #0x3c]
0x000d1d:	movs    	r2, #0
0x000d1f:	str     	r2, [sp, #8]
0x000d21:	movs    	r0, #0xf1
0x000d23:	movs    	r1, #0x45
0x000d25:	adds    	r3, r7, #0
0x000d27:	lsls    	r0, r0, #9
0x000d29:	ldr     	r2, [r4, #8]
0x000d2b:	bl      	#0x5159
; block 0xd2f
0x000d2f:	movs    	r1, #0
0x000d31:	str     	r1, [sp]
0x000d33:	str     	r1, [sp, #4]
0x000d35:	str     	r0, [sp, #0x38]
0x000d37:	movs    	r2, #0
0x000d39:	str     	r2, [sp, #8]
0x000d3b:	movs    	r0, #0xf1
0x000d3d:	movs    	r1, #0x45
0x000d3f:	adds    	r3, r7, #0
0x000d41:	lsls    	r0, r0, #9
0x000d43:	ldr     	r2, [r4, #8]
0x000d45:	bl      	#0x5159
; block 0xd49
0x000d49:	movs    	r1, #0
0x000d4b:	movs    	r2, #0
0x000d4d:	str     	r1, [sp]
0x000d4f:	str     	r1, [sp, #4]
0x000d51:	str     	r2, [sp, #8]
0x000d53:	str     	r0, [sp, #0x34]
0x000d55:	adds    	r3, r7, #0
0x000d57:	movs    	r1, #0x46
0x000d59:	ldr     	r2, [r4, #8]
0x000d5b:	b       	#0xd5f
; block 0xd5d
0x000d5d:	b       	#0xeb1
; block 0xd5f
0x000d5f:	movs    	r0, #0xf1
0x000d61:	lsls    	r0, r0, #9
0x000d63:	bl      	#0x5159
; block 0xd67
0x000d67:	lsls    	r0, r0, #0x18
0x000d69:	asrs    	r0, r0, #0x18
0x000d6b:	str     	r0, [sp, #0x24]
0x000d6d:	movs    	r1, #0
0x000d6f:	str     	r1, [sp]
0x000d71:	str     	r1, [sp, #4]
0x000d73:	movs    	r2, #0
0x000d75:	str     	r2, [sp, #8]
0x000d77:	movs    	r1, #0x45
0x000d79:	movs    	r0, #0xf1
0x000d7b:	adds    	r3, r7, #0
0x000d7d:	lsls    	r0, r0, #9
0x000d7f:	ldr     	r2, [r4, #8]
0x000d81:	bl      	#0x5159
; block 0xd85
0x000d85:	movs    	r1, #0
0x000d87:	str     	r1, [sp]
0x000d89:	str     	r1, [sp, #4]
0x000d8b:	str     	r0, [sp, #0x30]
0x000d8d:	movs    	r2, #0
0x000d8f:	str     	r2, [sp, #8]
0x000d91:	movs    	r0, #0xf1
0x000d93:	movs    	r1, #0x45
0x000d95:	adds    	r3, r7, #0
0x000d97:	lsls    	r0, r0, #9
0x000d99:	ldr     	r2, [r4, #8]
0x000d9b:	bl      	#0x5159
; block 0xd9f
0x000d9f:	movs    	r1, #0
0x000da1:	str     	r0, [sp, #0x28]
0x000da3:	str     	r1, [sp]
0x000da5:	str     	r1, [sp, #4]
0x000da7:	movs    	r2, #0
0x000da9:	str     	r2, [sp, #8]
0x000dab:	movs    	r1, #0x47
0x000dad:	movs    	r0, #0xf1
0x000daf:	adds    	r3, r7, #0
0x000db1:	lsls    	r0, r0, #9
0x000db3:	ldr     	r2, [r4, #8]
0x000db5:	bl      	#0x5159
; block 0xdb9
0x000db9:	movs    	r1, #0
0x000dbb:	str     	r1, [sp]
0x000dbd:	str     	r1, [sp, #4]
0x000dbf:	str     	r0, [sp, #0x2c]
0x000dc1:	movs    	r2, #0
0x000dc3:	str     	r2, [sp, #8]
0x000dc5:	movs    	r0, #0xf1
0x000dc7:	movs    	r1, #0x46
0x000dc9:	adds    	r3, r7, #0
0x000dcb:	lsls    	r0, r0, #9
0x000dcd:	ldr     	r2, [r4, #8]
0x000dcf:	bl      	#0x5159
; block 0xdd3
0x000dd3:	lsls    	r0, r0, #0x18
0x000dd5:	asrs    	r0, r0, #0x18
0x000dd7:	str     	r0, [sp, #0x20]
0x000dd9:	movs    	r1, #0
0x000ddb:	str     	r1, [sp]
0x000ddd:	str     	r1, [sp, #4]
0x000ddf:	movs    	r2, #0
0x000de1:	str     	r2, [sp, #8]
0x000de3:	movs    	r1, #0x45
0x000de5:	movs    	r0, #0xf1
0x000de7:	adds    	r3, r7, #0
0x000de9:	lsls    	r0, r0, #9
0x000deb:	ldr     	r2, [r4, #8]
0x000ded:	bl      	#0x5159
; block 0xdf1
0x000df1:	movs    	r1, #0
0x000df3:	str     	r1, [sp]
0x000df5:	str     	r1, [sp, #4]
0x000df7:	str     	r0, [sp, #0x18]
0x000df9:	movs    	r2, #0
0x000dfb:	str     	r2, [sp, #8]
0x000dfd:	movs    	r0, #0xf1
0x000dff:	movs    	r1, #0x46
0x000e01:	adds    	r3, r7, #0
0x000e03:	lsls    	r0, r0, #9
0x000e05:	ldr     	r2, [r4, #8]
0x000e07:	bl      	#0x5159
; block 0xe0b
0x000e0b:	lsls    	r0, r0, #0x18
0x000e0d:	asrs    	r0, r0, #0x18
0x000e0f:	str     	r0, [sp, #0x14]
0x000e11:	ldr     	r0, [sp, #0x18]
0x000e13:	adds    	r3, r0, #1
0x000e15:	beq     	#0xe31
; block 0xe17
0x000e17:	movs    	r1, #0
0x000e19:	str     	r1, [sp]
0x000e1b:	str     	r1, [sp, #4]
0x000e1d:	movs    	r2, #0
0x000e1f:	str     	r2, [sp, #8]
0x000e21:	movs    	r1, #0x47
0x000e23:	adds    	r3, r7, #0
0x000e25:	movs    	r0, #0xf1
0x000e27:	lsls    	r0, r0, #9
0x000e29:	ldr     	r2, [r4, #8]
0x000e2b:	bl      	#0x5159
; block 0xe2f
0x000e2f:	str     	r0, [sp, #0x10]
0x000e31:	movs    	r1, #0
0x000e33:	str     	r1, [sp]
0x000e35:	str     	r1, [sp, #4]
0x000e37:	movs    	r2, #0
0x000e39:	str     	r2, [sp, #8]
0x000e3b:	movs    	r1, #0x46
0x000e3d:	adds    	r3, r7, #0
0x000e3f:	movs    	r0, #0xf1
0x000e41:	lsls    	r0, r0, #9
0x000e43:	ldr     	r2, [r4, #8]
0x000e45:	bl      	#0x5159
; block 0xe31
0x000e31:	movs    	r1, #0
0x000e33:	str     	r1, [sp]
0x000e35:	str     	r1, [sp, #4]
0x000e37:	movs    	r2, #0
0x000e39:	str     	r2, [sp, #8]
0x000e3b:	movs    	r1, #0x46
0x000e3d:	adds    	r3, r7, #0
0x000e3f:	movs    	r0, #0xf1
0x000e41:	lsls    	r0, r0, #9
0x000e43:	ldr     	r2, [r4, #8]
0x000e45:	bl      	#0x5159
; block 0xe49
0x000e49:	ldr     	r1, [sp, #0x44]
0x000e4b:	movs    	r2, #0x24
0x000e4d:	str     	r1, [r5, #0x10]
0x000e4f:	ldr     	r1, [sp, #0x48]
0x000e51:	str     	r1, [r5]
0x000e53:	ldr     	r1, [sp, #0x1c]
0x000e55:	str     	r1, [r5, #0x14]
0x000e57:	ldr     	r1, [sp, #0x40]
0x000e59:	str     	r1, [r5, #0xc]
0x000e5b:	ldr     	r1, [sp, #0x3c]
0x000e5d:	str     	r1, [r5, #8]
0x000e5f:	ldr     	r1, [sp, #0x38]
0x000e61:	str     	r1, [r5, #0x18]
0x000e63:	ldr     	r1, [sp, #0x34]
0x000e65:	str     	r1, [r5, #0x1c]
0x000e67:	ldr     	r1, [sp, #0x30]
0x000e69:	str     	r1, [r5, #0x20]
0x000e6b:	ldr     	r1, [sp, #0x24]
0x000e6d:	strb    	r1, [r2, r5]
0x000e6f:	ldr     	r1, [sp, #0x2c]
0x000e71:	str     	r1, [r5, #0x28]
0x000e73:	ldr     	r1, [sp, #0x28]
0x000e75:	str     	r1, [r5, #0x2c]
0x000e77:	adds    	r1, r5, #0
0x000e79:	ldr     	r2, [sp, #0x20]
0x000e7b:	adds    	r1, #0x30
0x000e7d:	strb    	r2, [r1]
0x000e7f:	ldr     	r2, [sp, #0x18]
0x000e81:	adds    	r3, r5, #0
0x000e83:	str     	r2, [r5, #0x34]
0x000e85:	ldr     	r2, [sp, #0x10]
0x000e87:	str     	r2, [r5, #0x3c]
0x000e89:	ldr     	r2, [sp, #0x14]
0x000e8b:	strb    	r2, [r1, #8]
0x000e8d:	movs    	r1, #0x40
0x000e8f:	strb    	r0, [r1, r5]
0x000e91:	movs    	r1, #0
0x000e93:	movs    	r2, #0
0x000e95:	str     	r1, [sp]
0x000e97:	str     	r1, [sp, #4]
0x000e99:	movs    	r1, #0x36
0x000e9b:	str     	r2, [sp, #8]
0x000e9d:	movs    	r0, #0xf1
0x000e9f:	lsls    	r0, r0, #9
0x000ea1:	ldr     	r2, [sp, #0x4c]
0x000ea3:	bl      	#0x5159
; block 0xea7
0x000ea7:	ldr     	r0, [sp, #0x50]
0x000ea9:	adds    	r6, #1
0x000eab:	cmp     	r6, r0
0x000ead:	bge     	#0xeb1
; block 0xeaf
0x000eaf:	b       	#0xc77
; block 0xeb1
0x000eb1:	movs    	r1, #0
0x000eb3:	str     	r1, [sp]
0x000eb5:	str     	r1, [sp, #4]
0x000eb7:	movs    	r2, #0
0x000eb9:	str     	r2, [sp, #8]
0x000ebb:	movs    	r1, #0x45
0x000ebd:	adds    	r3, r7, #0
0x000ebf:	movs    	r0, #0xf1
0x000ec1:	lsls    	r0, r0, #9
0x000ec3:	ldr     	r2, [r4, #8]
0x000ec5:	bl      	#0x5159
; block 0xec9
0x000ec9:	adds    	r3, r0, #0
0x000ecb:	movs    	r0, #2
0x000ecd:	movs    	r2, #0
0x000ecf:	movs    	r1, #0
0x000ed1:	str     	r1, [sp, #4]
0x000ed3:	str     	r2, [sp, #8]
0x000ed5:	str     	r0, [sp]
0x000ed7:	movs    	r0, #0xf1
0x000ed9:	movs    	r2, #0x1c
0x000edb:	movs    	r1, #0x14
0x000edd:	lsls    	r0, r0, #9
0x000edf:	bl      	#0x5159
; block 0xee3
0x000ee3:	ldr     	r0, [sp, #0x4c]
0x000ee5:	bl      	#0x4791
; block 0xee9
0x000ee9:	add     	sp, #0x54
0x000eeb:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_eed @ 0xeed offset=0xeec size=578 blocks=28 cc=23 =====
; block 0xeed
0x000eed:	push    	{r4, r5, r6, r7, lr}
0x000eef:	sub     	sp, #0x3c
0x000ef1:	adds    	r4, r0, #0
0x000ef3:	movs    	r0, #0
0x000ef5:	movs    	r5, #0
0x000ef7:	movs    	r2, #0
0x000ef9:	movs    	r1, #0
0x000efb:	str     	r1, [sp, #4]
0x000efd:	str     	r2, [sp, #8]
0x000eff:	adds    	r3, r5, #0
0x000f01:	str     	r0, [sp, #0x34]
0x000f03:	str     	r0, [sp]
0x000f05:	movs    	r0, #0xf1
0x000f07:	adds    	r2, r4, #0
0x000f09:	movs    	r1, #0x44
0x000f0b:	lsls    	r0, r0, #9
0x000f0d:	bl      	#0x5159
; block 0xf11
0x000f11:	movs    	r1, #0
0x000f13:	str     	r1, [sp]
0x000f15:	str     	r1, [sp, #4]
0x000f17:	movs    	r2, #0
0x000f19:	str     	r2, [sp, #8]
0x000f1b:	movs    	r1, #0x45
0x000f1d:	adds    	r3, r5, #0
0x000f1f:	movs    	r0, #0xf1
0x000f21:	lsls    	r0, r0, #9
0x000f23:	ldr     	r2, [r4, #8]
0x000f25:	bl      	#0x5159
; block 0xf29
0x000f29:	str     	r0, [sp, #0x38]
0x000f2b:	cmp     	r0, #0
0x000f2d:	ble     	#0x1013
; block 0xf2f
0x000f2f:	movs    	r1, #0
0x000f31:	str     	r1, [sp]
0x000f33:	str     	r1, [sp, #4]
0x000f35:	movs    	r2, #0
0x000f37:	movs    	r5, #0
0x000f39:	adds    	r3, r5, #0
0x000f3b:	str     	r2, [sp, #8]
0x000f3d:	movs    	r1, #0x46
0x000f3f:	movs    	r0, #0xf1
0x000f41:	lsls    	r0, r0, #9
0x000f43:	ldr     	r2, [r4, #8]
0x000f45:	bl      	#0x5159
; block 0xf49
0x000f49:	lsls    	r0, r0, #0x18
0x000f4b:	movs    	r1, #0
0x000f4d:	asrs    	r0, r0, #0x18
0x000f4f:	str     	r0, [sp, #0x30]
0x000f51:	str     	r1, [sp]
0x000f53:	str     	r1, [sp, #4]
0x000f55:	movs    	r2, #0
0x000f57:	str     	r2, [sp, #8]
0x000f59:	movs    	r1, #0x47
0x000f5b:	movs    	r0, #0xf1
0x000f5d:	adds    	r3, r5, #0
0x000f5f:	lsls    	r0, r0, #9
0x000f61:	ldr     	r2, [r4, #8]
0x000f63:	bl      	#0x5159
; block 0xf67
0x000f67:	movs    	r1, #0
0x000f69:	str     	r1, [sp]
0x000f6b:	str     	r1, [sp, #4]
0x000f6d:	str     	r0, [sp, #0x2c]
0x000f6f:	movs    	r2, #0
0x000f71:	str     	r2, [sp, #8]
0x000f73:	movs    	r0, #0xf1
0x000f75:	movs    	r1, #0x45
0x000f77:	adds    	r3, r5, #0
0x000f79:	lsls    	r0, r0, #9
0x000f7b:	ldr     	r2, [r4, #8]
0x000f7d:	bl      	#0x5159
; block 0xf81
0x000f81:	movs    	r1, #0
0x000f83:	str     	r0, [sp, #0x28]
0x000f85:	str     	r1, [sp]
0x000f87:	str     	r1, [sp, #4]
0x000f89:	movs    	r2, #0
0x000f8b:	str     	r2, [sp, #8]
0x000f8d:	movs    	r1, #0x46
0x000f8f:	movs    	r0, #0xf1
0x000f91:	adds    	r3, r5, #0
0x000f93:	lsls    	r0, r0, #9
0x000f95:	ldr     	r2, [r4, #8]
0x000f97:	bl      	#0x5159
; block 0xf9b
0x000f9b:	lsls    	r1, r0, #0x18
0x000f9d:	asrs    	r1, r1, #0x18
0x000f9f:	str     	r1, [sp, #0x24]
0x000fa1:	movs    	r1, #0
0x000fa3:	str     	r1, [sp]
0x000fa5:	str     	r1, [sp, #4]
0x000fa7:	movs    	r2, #0
0x000fa9:	str     	r2, [sp, #8]
0x000fab:	movs    	r1, #0x46
0x000fad:	movs    	r0, #0xf1
0x000faf:	adds    	r3, r5, #0
0x000fb1:	lsls    	r0, r0, #9
0x000fb3:	ldr     	r2, [r4, #8]
0x000fb5:	bl      	#0x5159
; block 0xfb9
0x000fb9:	lsls    	r0, r0, #0x18
0x000fbb:	asrs    	r0, r0, #0x18
0x000fbd:	str     	r0, [sp, #0x20]
0x000fbf:	movs    	r1, #0
0x000fc1:	str     	r1, [sp]
0x000fc3:	str     	r1, [sp, #4]
0x000fc5:	movs    	r2, #0
0x000fc7:	str     	r2, [sp, #8]
0x000fc9:	movs    	r1, #0x47
0x000fcb:	movs    	r0, #0xf1
0x000fcd:	adds    	r3, r5, #0
0x000fcf:	lsls    	r0, r0, #9
0x000fd1:	ldr     	r2, [r4, #8]
0x000fd3:	bl      	#0x5159
; block 0xfd7
0x000fd7:	movs    	r1, #0
0x000fd9:	str     	r1, [sp]
0x000fdb:	str     	r1, [sp, #4]
0x000fdd:	str     	r0, [sp, #0x1c]
0x000fdf:	movs    	r2, #0
0x000fe1:	str     	r2, [sp, #8]
0x000fe3:	movs    	r0, #0xf1
0x000fe5:	movs    	r1, #0x45
0x000fe7:	adds    	r3, r5, #0
0x000fe9:	lsls    	r0, r0, #9
0x000feb:	ldr     	r2, [r4, #8]
0x000fed:	bl      	#0x5159
; block 0xff1
0x000ff1:	movs    	r1, #0
0x000ff3:	str     	r1, [sp]
0x000ff5:	str     	r1, [sp, #4]
0x000ff7:	str     	r0, [sp, #0x18]
0x000ff9:	movs    	r2, #0
0x000ffb:	str     	r2, [sp, #8]
0x000ffd:	movs    	r0, #0xf1
0x000fff:	movs    	r1, #0x45
0x001001:	adds    	r3, r5, #0
0x001003:	lsls    	r0, r0, #9
0x001005:	ldr     	r2, [r4, #8]
0x001007:	bl      	#0x5159
; block 0x100b
0x00100b:	movs    	r2, #0
0x00100d:	movs    	r1, #0
0x00100f:	str     	r0, [sp, #0x14]
0x001011:	b       	#0x1015
; block 0x1013
0x001013:	b       	#0x110f
; block 0x1015
0x001015:	str     	r1, [sp]
0x001017:	str     	r1, [sp, #4]
0x001019:	movs    	r1, #0x45
0x00101b:	str     	r2, [sp, #8]
0x00101d:	adds    	r3, r5, #0
0x00101f:	movs    	r0, #0xf1
0x001021:	lsls    	r0, r0, #9
0x001023:	ldr     	r2, [r4, #8]
0x001025:	bl      	#0x5159
; block 0x1029
0x001029:	movs    	r1, #0
0x00102b:	str     	r1, [sp]
0x00102d:	str     	r1, [sp, #4]
0x00102f:	str     	r0, [sp, #0x10]
0x001031:	movs    	r2, #0
0x001033:	str     	r2, [sp, #8]
0x001035:	movs    	r0, #0xf1
0x001037:	movs    	r1, #0x46
0x001039:	movs    	r6, #0
0x00103b:	adds    	r3, r5, #0
0x00103d:	lsls    	r0, r0, #9
0x00103f:	ldr     	r2, [r4, #8]
0x001041:	bl      	#0x5159
; block 0x1045
0x001045:	lsls    	r0, r0, #0x18
0x001047:	asrs    	r0, r0, #0x18
0x001049:	cmp     	r0, #1
0x00104b:	bne     	#0x10a7
; block 0x104d
0x00104d:	movs    	r1, #0
0x00104f:	str     	r1, [sp]
0x001051:	str     	r1, [sp, #4]
0x001053:	movs    	r2, #0
0x001055:	str     	r2, [sp, #8]
0x001057:	movs    	r1, #0x46
0x001059:	movs    	r3, #0
0x00105b:	movs    	r0, #0xf1
0x00105d:	lsls    	r0, r0, #9
0x00105f:	ldr     	r2, [r4, #8]
0x001061:	bl      	#0x5159
; block 0x1065
0x001065:	lsls    	r7, r0, #0x18
0x001067:	movs    	r1, #0
0x001069:	movs    	r2, #0
0x00106b:	str     	r2, [sp, #8]
0x00106d:	str     	r1, [sp]
0x00106f:	str     	r1, [sp, #4]
0x001071:	asrs    	r7, r7, #0x18
0x001073:	adds    	r2, r7, #0
0x001075:	movs    	r1, #0xa
0x001077:	movs    	r0, #0xf1
0x001079:	movs    	r3, #1
0x00107b:	lsls    	r0, r0, #9
0x00107d:	bl      	#0x5159
; block 0x1081
0x001081:	adds    	r6, r0, #0
0x001083:	cmp     	r7, #0
0x001085:	ble     	#0x10a7
; block 0x1087
0x001087:	movs    	r1, #0
0x001089:	str     	r1, [sp]
0x00108b:	str     	r1, [sp, #4]
0x00108d:	movs    	r2, #0
0x00108f:	str     	r2, [sp, #8]
0x001091:	movs    	r1, #0x46
0x001093:	movs    	r3, #0
0x001095:	movs    	r0, #0xf1
0x001097:	lsls    	r0, r0, #9
0x001099:	ldr     	r2, [r4, #8]
0x00109b:	bl      	#0x5159
; block 0x109f
0x00109f:	strb    	r0, [r6, r5]
0x0010a1:	adds    	r5, #1
0x0010a3:	cmp     	r5, r7
0x0010a5:	blt     	#0x1087
; block 0x10a7
0x0010a7:	movs    	r1, #0
0x0010a9:	movs    	r2, #0
0x0010ab:	str     	r2, [sp, #8]
0x0010ad:	str     	r1, [sp]
0x0010af:	str     	r1, [sp, #4]
0x0010b1:	movs    	r1, #0xf
0x0010b3:	movs    	r2, #0x20
0x0010b5:	movs    	r3, #0
0x0010b7:	movs    	r0, #0xf1
0x0010b9:	lsls    	r0, r0, #9
0x0010bb:	bl      	#0x5159
; block 0x10bf
0x0010bf:	adds    	r3, r0, #0
0x0010c1:	ldr     	r0, [sp, #0x30]
0x0010c3:	movs    	r2, #0
0x0010c5:	strb    	r0, [r3, #9]
0x0010c7:	ldr     	r1, [sp, #0x2c]
0x0010c9:	ldr     	r0, [pc, #0x64]
0x0010cb:	str     	r1, [r3]
0x0010cd:	ldr     	r1, [sp, #0x24]
0x0010cf:	add     	r0, sb
0x0010d1:	strb    	r1, [r3, #8]
0x0010d3:	ldr     	r1, [sp, #0x28]
0x0010d5:	str     	r1, [r3, #4]
0x0010d7:	ldr     	r1, [sp, #0x20]
0x0010d9:	strb    	r1, [r3, #0xa]
0x0010db:	ldr     	r1, [sp, #0x1c]
0x0010dd:	str     	r1, [r3, #0xc]
0x0010df:	ldr     	r1, [sp, #0x18]
0x0010e1:	str     	r1, [r3, #0x10]
0x0010e3:	ldr     	r1, [sp, #0x14]
0x0010e5:	str     	r1, [r3, #0x14]
0x0010e7:	ldr     	r1, [sp, #0x10]
0x0010e9:	str     	r1, [r3, #0x18]
0x0010eb:	str     	r6, [r3, #0x1c]
0x0010ed:	movs    	r1, #0
0x0010ef:	str     	r1, [sp]
0x0010f1:	str     	r1, [sp, #4]
0x0010f3:	str     	r2, [sp, #8]
0x0010f5:	ldr     	r2, [r0, #0xc]
0x0010f7:	movs    	r0, #0xf1
0x0010f9:	movs    	r1, #0x36
0x0010fb:	lsls    	r0, r0, #9
0x0010fd:	bl      	#0x5159
; block 0x1101
0x001101:	ldr     	r0, [sp, #0x34]
0x001103:	ldr     	r1, [sp, #0x38]
0x001105:	adds    	r0, #1
0x001107:	str     	r0, [sp, #0x34]
0x001109:	cmp     	r0, r1
0x00110b:	bge     	#0x110f
; block 0x110d
0x00110d:	b       	#0xf2f
; block 0x110f
0x00110f:	movs    	r1, #0
0x001111:	str     	r1, [sp]
0x001113:	str     	r1, [sp, #4]
0x001115:	movs    	r2, #0
0x001117:	str     	r2, [sp, #8]
0x001119:	movs    	r1, #0x47
0x00111b:	movs    	r3, #0
0x00111d:	movs    	r0, #0xf1
0x00111f:	lsls    	r0, r0, #9
0x001121:	ldr     	r2, [r4, #8]
0x001123:	bl      	#0x5159
; block 0x1127
0x001127:	bl      	#0x4821
; block 0x112b
0x00112b:	add     	sp, #0x3c
0x00112d:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_1131 @ 0x1131 offset=0x1130 size=4 blocks=1 cc=1 =====
; block 0x1131
0x001131:	movs    	r4, r1
0x001133:	movs    	r0, r0
0x001135:	push    	{r4, r5, r6, r7, lr}
0x001137:	adds    	r6, r0, #0
0x001139:	movs    	r4, #0
0x00113b:	sub     	sp, #0x14
0x00113d:	bl      	#0x6591

; ===== sub_1135 @ 0x1135 offset=0x1134 size=254 blocks=17 cc=14 =====
; block 0x1135
0x001135:	push    	{r4, r5, r6, r7, lr}
0x001137:	adds    	r6, r0, #0
0x001139:	movs    	r4, #0
0x00113b:	sub     	sp, #0x14
0x00113d:	bl      	#0x6591
; block 0x1141
0x001141:	movs    	r1, #0
0x001143:	adds    	r5, r0, #0
0x001145:	movs    	r2, #0
0x001147:	movs    	r7, #0
0x001149:	adds    	r3, r7, #0
0x00114b:	str     	r2, [sp, #8]
0x00114d:	str     	r1, [sp]
0x00114f:	str     	r1, [sp, #4]
0x001151:	movs    	r1, #0x44
0x001153:	adds    	r2, r6, #0
0x001155:	movs    	r0, #0xf1
0x001157:	lsls    	r0, r0, #9
0x001159:	bl      	#0x5159
; block 0x115d
0x00115d:	movs    	r1, #0
0x00115f:	str     	r1, [sp]
0x001161:	str     	r1, [sp, #4]
0x001163:	movs    	r2, #0
0x001165:	str     	r2, [sp, #8]
0x001167:	movs    	r1, #0x45
0x001169:	adds    	r3, r7, #0
0x00116b:	movs    	r0, #0xf1
0x00116d:	lsls    	r0, r0, #9
0x00116f:	ldr     	r2, [r6, #8]
0x001171:	bl      	#0x5159
; block 0x1175
0x001175:	str     	r0, [sp, #0x10]
0x001177:	cmp     	r0, #0
0x001179:	ble     	#0x11cb
; block 0x117b
0x00117b:	movs    	r1, #0
0x00117d:	str     	r1, [sp]
0x00117f:	str     	r1, [sp, #4]
0x001181:	movs    	r2, #0
0x001183:	str     	r2, [sp, #8]
0x001185:	movs    	r1, #0x46
0x001187:	movs    	r3, #0
0x001189:	movs    	r0, #0xf1
0x00118b:	lsls    	r0, r0, #9
0x00118d:	ldr     	r2, [r6, #8]
0x00118f:	bl      	#0x5159
; block 0x1193
0x001193:	lsls    	r7, r0, #0x18
0x001195:	ldr     	r0, [pc, #0x9c]
0x001197:	asrs    	r7, r7, #0x18
0x001199:	add     	r0, sb
0x00119b:	ldr     	r0, [r0, #0xc]
0x00119d:	cmp     	r0, #0
0x00119f:	beq     	#0x11c3
; block 0x11a1
0x0011a1:	cmp     	r5, #0
0x0011a3:	beq     	#0x11c3
; block 0x11a5
0x0011a5:	movs    	r1, #0
0x0011a7:	movs    	r2, #0
0x0011a9:	str     	r2, [sp, #8]
0x0011ab:	str     	r1, [sp]
0x0011ad:	str     	r1, [sp, #4]
0x0011af:	adds    	r3, r4, #0
0x0011b1:	adds    	r2, r5, #0
0x0011b3:	movs    	r1, #0x27
0x0011b5:	movs    	r0, #0xf1
0x0011b7:	lsls    	r0, r0, #9
0x0011b9:	bl      	#0x5159
; block 0x11bd
0x0011bd:	cmp     	r0, #0
0x0011bf:	beq     	#0x11c3
; block 0x11c1
0x0011c1:	strb    	r7, [r0, #8]
0x0011c3:	ldr     	r0, [sp, #0x10]
0x0011c5:	adds    	r4, #1
0x0011c7:	cmp     	r4, r0
0x0011c9:	blt     	#0x117b
; block 0x11c3
0x0011c3:	ldr     	r0, [sp, #0x10]
0x0011c5:	adds    	r4, #1
0x0011c7:	cmp     	r4, r0
0x0011c9:	blt     	#0x117b
; block 0x11cb
0x0011cb:	movs    	r1, #0
0x0011cd:	movs    	r2, #0
0x0011cf:	str     	r2, [sp, #8]
0x0011d1:	str     	r1, [sp]
0x0011d3:	str     	r1, [sp, #4]
0x0011d5:	movs    	r4, #1
0x0011d7:	movs    	r6, #0xf1
0x0011d9:	lsls    	r6, r6, #9
0x0011db:	adds    	r3, r4, #0
0x0011dd:	movs    	r1, #0x14
0x0011df:	movs    	r2, #0x31
0x0011e1:	adds    	r0, r6, #0
0x0011e3:	bl      	#0x5159
; block 0x11e7
0x0011e7:	movs    	r1, #0
0x0011e9:	movs    	r2, #0
0x0011eb:	str     	r2, [sp, #8]
0x0011ed:	str     	r1, [sp]
0x0011ef:	str     	r1, [sp, #4]
0x0011f1:	movs    	r1, #0x14
0x0011f3:	movs    	r2, #0xed
0x0011f5:	adds    	r3, r4, #0
0x0011f7:	adds    	r0, r6, #0
0x0011f9:	bl      	#0x5159
; block 0x11fd
0x0011fd:	cmp     	r5, #0
0x0011ff:	beq     	#0x122f
; block 0x1201
0x001201:	movs    	r1, #0
0x001203:	movs    	r2, #0
0x001205:	str     	r2, [sp, #8]
0x001207:	str     	r1, [sp]
0x001209:	str     	r1, [sp, #4]
0x00120b:	movs    	r7, #0
0x00120d:	adds    	r3, r7, #0
0x00120f:	movs    	r1, #0x28
0x001211:	adds    	r2, r5, #0
0x001213:	adds    	r0, r6, #0
0x001215:	bl      	#0x5159
; block 0x1219
0x001219:	movs    	r1, #0
0x00121b:	movs    	r2, #0
0x00121d:	str     	r2, [sp, #8]
0x00121f:	str     	r1, [sp]
0x001221:	str     	r1, [sp, #4]
0x001223:	movs    	r1, #9
0x001225:	adds    	r2, r5, #0
0x001227:	adds    	r3, r7, #0
0x001229:	adds    	r0, r6, #0
0x00122b:	bl      	#0x5159
; block 0x122f
0x00122f:	add     	sp, #0x14
0x001231:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_1235 @ 0x1235 offset=0x1234 size=4 blocks=1 cc=0 =====
; block 0x1235
0x001235:	movs    	r4, r1
0x001237:	movs    	r0, r0
0x001239:	push    	{r4, r5, r6, r7, lr}
0x00123b:	sub     	sp, #0x64
0x00123d:	movs    	r0, #0
0x00123f:	str     	r0, [sp, #0x44]
0x001241:	str     	r0, [sp, #0x48]
0x001243:	movs    	r1, #0
0x001245:	str     	r1, [sp, #4]
0x001247:	str     	r0, [sp]
0x001249:	movs    	r6, #0
0x00124b:	movs    	r2, #0
0x00124d:	adds    	r3, r6, #0
0x00124f:	movs    	r0, #0xf1
0x001251:	movs    	r1, #0x40
0x001253:	lsls    	r0, r0, #9
0x001255:	str     	r2, [sp, #8]
0x001257:	bl      	#0x5159

; ===== sub_1239 @ 0x1239 offset=0x1238 size=3450 blocks=146 cc=123 =====
; block 0x1239
0x001239:	push    	{r4, r5, r6, r7, lr}
0x00123b:	sub     	sp, #0x64
0x00123d:	movs    	r0, #0
0x00123f:	str     	r0, [sp, #0x44]
0x001241:	str     	r0, [sp, #0x48]
0x001243:	movs    	r1, #0
0x001245:	str     	r1, [sp, #4]
0x001247:	str     	r0, [sp]
0x001249:	movs    	r6, #0
0x00124b:	movs    	r2, #0
0x00124d:	adds    	r3, r6, #0
0x00124f:	movs    	r0, #0xf1
0x001251:	movs    	r1, #0x40
0x001253:	lsls    	r0, r0, #9
0x001255:	str     	r2, [sp, #8]
0x001257:	bl      	#0x5159
; block 0x125b
0x00125b:	ldr     	r5, [pc, #0x3dc]
0x00125d:	add     	r5, pc
0x00125f:	movs    	r1, #0
0x001261:	movs    	r2, #0
0x001263:	str     	r2, [sp, #8]
0x001265:	str     	r1, [sp]
0x001267:	str     	r1, [sp, #4]
0x001269:	movs    	r1, #0xe1
0x00126b:	movs    	r2, #0x28
0x00126d:	adds    	r3, r6, #0
0x00126f:	movs    	r0, #0xf1
0x001271:	lsls    	r0, r0, #9
0x001273:	bl      	#0x5159
; block 0x1277
0x001277:	movs    	r1, #0
0x001279:	adds    	r4, r0, #0
0x00127b:	movs    	r2, #0
0x00127d:	str     	r2, [sp, #8]
0x00127f:	str     	r1, [sp]
0x001281:	str     	r1, [sp, #4]
0x001283:	movs    	r1, #0xe1
0x001285:	movs    	r2, #0x29
0x001287:	movs    	r0, #0xf1
0x001289:	adds    	r3, r6, #0
0x00128b:	lsls    	r0, r0, #9
0x00128d:	bl      	#0x5159
; block 0x1291
0x001291:	adds    	r3, r0, #0
0x001293:	add     	r2, sp, #0x4c
0x001295:	add     	r1, sp, #0x50
0x001297:	str     	r1, [sp, #4]
0x001299:	str     	r2, [sp, #8]
0x00129b:	adds    	r2, r5, #0
0x00129d:	movs    	r1, #0x2a
0x00129f:	movs    	r0, #0xf1
0x0012a1:	lsls    	r0, r0, #9
0x0012a3:	str     	r4, [sp]
0x0012a5:	bl      	#0x5159
; block 0x12a9
0x0012a9:	movs    	r1, #0
0x0012ab:	movs    	r2, #0
0x0012ad:	str     	r2, [sp, #8]
0x0012af:	str     	r1, [sp]
0x0012b1:	str     	r1, [sp, #4]
0x0012b3:	movs    	r1, #0xe1
0x0012b5:	movs    	r2, #0x2a
0x0012b7:	adds    	r3, r6, #0
0x0012b9:	movs    	r0, #0xf1
0x0012bb:	lsls    	r0, r0, #9
0x0012bd:	bl      	#0x5159
; block 0x12c1
0x0012c1:	ldr     	r1, [sp, #0x4c]
0x0012c3:	movs    	r2, #0
0x0012c5:	adds    	r4, r0, r1
0x0012c7:	movs    	r1, #0
0x0012c9:	str     	r1, [sp]
0x0012cb:	str     	r1, [sp, #4]
0x0012cd:	movs    	r1, #0x1c
0x0012cf:	movs    	r0, #0xf1
0x0012d1:	adds    	r3, r6, #0
0x0012d3:	lsls    	r0, r0, #9
0x0012d5:	str     	r2, [sp, #8]
0x0012d7:	bl      	#0x5159
; block 0x12db
0x0012db:	movs    	r2, #0
0x0012dd:	str     	r0, [sp]
0x0012df:	movs    	r0, #0xf1
0x0012e1:	adds    	r3, r6, #0
0x0012e3:	movs    	r1, #0x32
0x0012e5:	lsls    	r0, r0, #9
0x0012e7:	str     	r2, [sp, #8]
0x0012e9:	str     	r4, [sp, #4]
0x0012eb:	bl      	#0x5159
; block 0x12ef
0x0012ef:	movs    	r1, #0
0x0012f1:	str     	r1, [sp]
0x0012f3:	str     	r1, [sp, #4]
0x0012f5:	movs    	r2, #0
0x0012f7:	movs    	r1, #0x1c
0x0012f9:	adds    	r3, r6, #0
0x0012fb:	movs    	r0, #0xf1
0x0012fd:	lsls    	r0, r0, #9
0x0012ff:	str     	r2, [sp, #8]
0x001301:	str     	r5, [sp, #0x10]
0x001303:	bl      	#0x5159
; block 0x1307
0x001307:	ldr     	r1, [sp, #0x50]
0x001309:	movs    	r2, #0
0x00130b:	subs    	r0, r0, r1
0x00130d:	lsrs    	r1, r0, #0x1f
0x00130f:	adds    	r0, r1, r0
0x001311:	movs    	r1, #0
0x001313:	asrs    	r0, r0, #1
0x001315:	str     	r0, [sp, #0x14]
0x001317:	str     	r1, [sp]
0x001319:	str     	r1, [sp, #4]
0x00131b:	str     	r2, [sp, #8]
0x00131d:	movs    	r2, #0x2a
0x00131f:	movs    	r1, #0xe1
0x001321:	movs    	r0, #0xf1
0x001323:	adds    	r3, r6, #0
0x001325:	lsls    	r0, r0, #9
0x001327:	bl      	#0x5159
; block 0x132b
0x00132b:	lsrs    	r1, r0, #0x1f
0x00132d:	adds    	r0, r1, r0
0x00132f:	asrs    	r0, r0, #1
0x001331:	adds    	r0, #2
0x001333:	movs    	r5, #0xff
0x001335:	str     	r0, [sp, #0x18]
0x001337:	add     	r0, sp, #0x30
0x001339:	str     	r5, [sp, #0x24]
0x00133b:	str     	r5, [sp, #0x28]
0x00133d:	str     	r5, [sp, #0x2c]
0x00133f:	str     	r6, [sp, #0x1c]
0x001341:	str     	r6, [sp, #0x20]
0x001343:	movs    	r7, #1
0x001345:	strb    	r7, [r0]
0x001347:	movs    	r1, #0
0x001349:	movs    	r2, #0
0x00134b:	str     	r1, [sp]
0x00134d:	str     	r1, [sp, #4]
0x00134f:	movs    	r1, #0x25
0x001351:	str     	r2, [sp, #8]
0x001353:	movs    	r0, #0xf1
0x001355:	adds    	r3, r6, #0
0x001357:	lsls    	r0, r0, #9
0x001359:	add     	r2, sp, #0x10
0x00135b:	str     	r7, [sp, #0x34]
0x00135d:	bl      	#0x5159
; block 0x1361
0x001361:	movs    	r1, #0
0x001363:	str     	r1, [sp]
0x001365:	str     	r1, [sp, #4]
0x001367:	movs    	r2, #0
0x001369:	movs    	r1, #0x1d
0x00136b:	adds    	r3, r6, #0
0x00136d:	movs    	r0, #0xf1
0x00136f:	lsls    	r0, r0, #9
0x001371:	str     	r2, [sp, #8]
0x001373:	bl      	#0x5159
; block 0x1377
0x001377:	subs    	r0, r0, r4
0x001379:	movs    	r1, #0
0x00137b:	str     	r1, [sp]
0x00137d:	str     	r1, [sp, #4]
0x00137f:	str     	r0, [sp, #0x3c]
0x001381:	movs    	r2, #0
0x001383:	movs    	r0, #0xf1
0x001385:	movs    	r1, #0x1c
0x001387:	adds    	r3, r6, #0
0x001389:	lsls    	r0, r0, #9
0x00138b:	str     	r2, [sp, #8]
0x00138d:	bl      	#0x5159
; block 0x1391
0x001391:	ldr     	r1, [sp, #0x3c]
0x001393:	movs    	r2, #0
0x001395:	str     	r0, [sp]
0x001397:	str     	r1, [sp, #4]
0x001399:	movs    	r1, #0x31
0x00139b:	movs    	r0, #0xf1
0x00139d:	adds    	r3, r4, #0
0x00139f:	lsls    	r0, r0, #9
0x0013a1:	str     	r2, [sp, #8]
0x0013a3:	bl      	#0x5159
; block 0x13a7
0x0013a7:	movs    	r1, #0
0x0013a9:	str     	r1, [sp]
0x0013ab:	str     	r1, [sp, #4]
0x0013ad:	movs    	r2, #0
0x0013af:	movs    	r1, #0x24
0x0013b1:	adds    	r3, r7, #0
0x0013b3:	movs    	r0, #0xf1
0x0013b5:	lsls    	r0, r0, #9
0x0013b7:	str     	r2, [sp, #8]
0x0013b9:	bl      	#0x5159
; block 0x13bd
0x0013bd:	ldr     	r0, [pc, #0x27c]
0x0013bf:	add     	r0, pc
0x0013c1:	str     	r0, [sp, #0x24]
0x0013c3:	str     	r5, [sp, #0x28]
0x0013c5:	str     	r5, [sp, #0x2c]
0x0013c7:	str     	r5, [sp, #0x30]
0x0013c9:	add     	r3, sp, #0x20
0x0013cb:	strb    	r7, [r3, #0x14]
0x0013cd:	strb    	r7, [r3, #0x15]
0x0013cf:	movs    	r1, #0
0x0013d1:	movs    	r2, #0
0x0013d3:	str     	r1, [sp]
0x0013d5:	str     	r1, [sp, #4]
0x0013d7:	movs    	r1, #0x41
0x0013d9:	str     	r2, [sp, #8]
0x0013db:	adds    	r3, r6, #0
0x0013dd:	movs    	r0, #0xf1
0x0013df:	lsls    	r0, r0, #9
0x0013e1:	add     	r2, sp, #0x24
0x0013e3:	bl      	#0x5159
; block 0x13e7
0x0013e7:	ldr     	r4, [pc, #0x258]
0x0013e9:	add     	r4, pc
0x0013eb:	ldr     	r0, [pc, #0x258]
0x0013ed:	add     	r0, sb
0x0013ef:	ldr     	r0, [r0, #8]
0x0013f1:	cmp     	r0, #0
0x0013f3:	bne     	#0x1429
; block 0x13f5
0x0013f5:	movs    	r1, #0
0x0013f7:	str     	r1, [sp]
0x0013f9:	str     	r1, [sp, #4]
0x0013fb:	movs    	r2, #0
0x0013fd:	movs    	r1, #0x1c
0x0013ff:	adds    	r3, r6, #0
0x001401:	movs    	r0, #0xf1
0x001403:	lsls    	r0, r0, #9
0x001405:	str     	r2, [sp, #8]
0x001407:	bl      	#0x5159
; block 0x140b
0x00140b:	subs    	r0, #0xa
0x00140d:	movs    	r2, #0
0x00140f:	movs    	r1, #0x1e
0x001411:	ldr     	r3, [sp, #0x4c]
0x001413:	str     	r1, [sp, #4]
0x001415:	str     	r2, [sp, #8]
0x001417:	str     	r0, [sp]
0x001419:	movs    	r0, #0xf1
0x00141b:	movs    	r2, #5
0x00141d:	movs    	r1, #0x30
0x00141f:	adds    	r3, #0xf
0x001421:	lsls    	r0, r0, #9
0x001423:	bl      	#0x5159
; block 0x1427
0x001427:	b       	#0x1465
; block 0x1429
0x001429:	movs    	r1, #0
0x00142b:	str     	r1, [sp]
0x00142d:	str     	r1, [sp, #4]
0x00142f:	movs    	r2, #0
0x001431:	movs    	r1, #0x1c
0x001433:	adds    	r3, r6, #0
0x001435:	movs    	r0, #0xf1
0x001437:	lsls    	r0, r0, #9
0x001439:	str     	r2, [sp, #8]
0x00143b:	bl      	#0x5159
; block 0x143f
0x00143f:	subs    	r0, #0xa
0x001441:	movs    	r2, #0
0x001443:	movs    	r1, #0x1e
0x001445:	ldr     	r3, [sp, #0x4c]
0x001447:	str     	r1, [sp, #4]
0x001449:	str     	r2, [sp, #8]
0x00144b:	str     	r0, [sp]
0x00144d:	movs    	r0, #0xf1
0x00144f:	movs    	r2, #5
0x001451:	movs    	r1, #0x2f
0x001453:	adds    	r3, #0xf
0x001455:	lsls    	r0, r0, #9
0x001457:	bl      	#0x5159
; block 0x145b
0x00145b:	cmp     	r0, #1
0x00145d:	bne     	#0x1465
; block 0x145f
0x00145f:	ldr     	r0, [pc, #0x1e4]
0x001461:	add     	r0, sb
0x001463:	str     	r6, [r0, #8]
0x001465:	movs    	r1, #0
0x001467:	movs    	r2, #0
0x001469:	str     	r2, [sp, #8]
0x00146b:	str     	r1, [sp]
0x00146d:	str     	r1, [sp, #4]
0x00146f:	movs    	r7, #0xf1
0x001471:	lsls    	r7, r7, #9
0x001473:	movs    	r1, #0xe1
0x001475:	movs    	r2, #0x28
0x001477:	adds    	r3, r6, #0
0x001479:	adds    	r0, r7, #0
0x00147b:	bl      	#0x5159
; block 0x1465
0x001465:	movs    	r1, #0
0x001467:	movs    	r2, #0
0x001469:	str     	r2, [sp, #8]
0x00146b:	str     	r1, [sp]
0x00146d:	str     	r1, [sp, #4]
0x00146f:	movs    	r7, #0xf1
0x001471:	lsls    	r7, r7, #9
0x001473:	movs    	r1, #0xe1
0x001475:	movs    	r2, #0x28
0x001477:	adds    	r3, r6, #0
0x001479:	adds    	r0, r7, #0
0x00147b:	bl      	#0x5159
; block 0x147f
0x00147f:	movs    	r1, #0
0x001481:	movs    	r2, #0
0x001483:	str     	r2, [sp, #8]
0x001485:	str     	r1, [sp]
0x001487:	str     	r1, [sp, #4]
0x001489:	movs    	r1, #0xe1
0x00148b:	movs    	r2, #0x29
0x00148d:	adds    	r5, r0, #0
0x00148f:	adds    	r3, r6, #0
0x001491:	adds    	r0, r7, #0
0x001493:	bl      	#0x5159
; block 0x1497
0x001497:	add     	r2, sp, #0x4c
0x001499:	add     	r1, sp, #0x50
0x00149b:	str     	r1, [sp, #4]
0x00149d:	str     	r2, [sp, #8]
0x00149f:	adds    	r2, r4, #0
0x0014a1:	movs    	r1, #0x2a
0x0014a3:	adds    	r3, r0, #0
0x0014a5:	adds    	r0, r7, #0
0x0014a7:	str     	r5, [sp]
0x0014a9:	bl      	#0x5159
; block 0x14ad
0x0014ad:	movs    	r0, #0xa
0x0014af:	str     	r0, [sp, #0x1c]
0x0014b1:	ldr     	r0, [sp, #0x4c]
0x0014b3:	str     	r4, [sp, #0x18]
0x0014b5:	movs    	r4, #0xff
0x0014b7:	adds    	r0, #0x14
0x0014b9:	str     	r0, [sp, #0x20]
0x0014bb:	movs    	r1, #0
0x0014bd:	str     	r4, [sp, #0x24]
0x0014bf:	str     	r4, [sp, #0x28]
0x0014c1:	movs    	r2, #0
0x0014c3:	str     	r2, [sp, #8]
0x0014c5:	str     	r1, [sp, #4]
0x0014c7:	str     	r1, [sp]
0x0014c9:	movs    	r0, #0xc8
0x0014cb:	str     	r0, [sp, #0x2c]
0x0014cd:	movs    	r1, #0xe1
0x0014cf:	movs    	r2, #0x29
0x0014d1:	adds    	r3, r6, #0
0x0014d3:	adds    	r0, r7, #0
0x0014d5:	bl      	#0x5159
; block 0x14d9
0x0014d9:	movs    	r1, #0
0x0014db:	movs    	r2, #0
0x0014dd:	str     	r2, [sp, #8]
0x0014df:	str     	r1, [sp]
0x0014e1:	str     	r1, [sp, #4]
0x0014e3:	movs    	r1, #0xe1
0x0014e5:	movs    	r2, #0x28
0x0014e7:	str     	r0, [sp, #0x30]
0x0014e9:	adds    	r3, r6, #0
0x0014eb:	adds    	r0, r7, #0
0x0014ed:	bl      	#0x5159
; block 0x14f1
0x0014f1:	movs    	r1, #0
0x0014f3:	movs    	r2, #0
0x0014f5:	str     	r1, [sp]
0x0014f7:	str     	r1, [sp, #4]
0x0014f9:	movs    	r1, #0x56
0x0014fb:	str     	r2, [sp, #8]
0x0014fd:	str     	r0, [sp, #0x34]
0x0014ff:	adds    	r3, r6, #0
0x001501:	adds    	r0, r7, #0
0x001503:	add     	r2, sp, #0x18
0x001505:	bl      	#0x5159
; block 0x1509
0x001509:	ldr     	r0, [sp, #0x50]
0x00150b:	movs    	r2, #0
0x00150d:	adds    	r0, #0x14
0x00150f:	str     	r0, [sp, #0x1c]
0x001511:	ldr     	r0, [sp, #0x4c]
0x001513:	adds    	r3, r6, #0
0x001515:	adds    	r1, r0, #0
0x001517:	adds    	r1, #0x14
0x001519:	str     	r1, [sp, #0x20]
0x00151b:	movs    	r1, #0x82
0x00151d:	str     	r1, [sp, #0x24]
0x00151f:	movs    	r1, #0
0x001521:	adds    	r0, #5
0x001523:	str     	r0, [sp, #0x28]
0x001525:	str     	r1, [sp]
0x001527:	str     	r1, [sp, #4]
0x001529:	movs    	r1, #0x1f
0x00152b:	str     	r2, [sp, #8]
0x00152d:	add     	r2, sp, #0x1c
0x00152f:	adds    	r0, r7, #0
0x001531:	str     	r4, [sp, #0x2c]
0x001533:	str     	r4, [sp, #0x30]
0x001535:	str     	r4, [sp, #0x34]
0x001537:	bl      	#0x5159
; block 0x153b
0x00153b:	ldr     	r0, [sp, #0x4c]
0x00153d:	movs    	r1, #0x82
0x00153f:	adds    	r2, r0, #5
0x001541:	ldr     	r3, [sp, #0x50]
0x001543:	str     	r2, [sp, #8]
0x001545:	adds    	r0, #0x14
0x001547:	str     	r1, [sp, #4]
0x001549:	movs    	r1, #0x23
0x00154b:	str     	r0, [sp]
0x00154d:	movs    	r2, #4
0x00154f:	adds    	r3, #0x14
0x001551:	adds    	r0, r7, #0
0x001553:	bl      	#0x5159
; block 0x1557
0x001557:	movs    	r1, #0
0x001559:	movs    	r2, #0
0x00155b:	str     	r2, [sp, #8]
0x00155d:	str     	r1, [sp]
0x00155f:	str     	r1, [sp, #4]
0x001561:	movs    	r1, #0xe1
0x001563:	movs    	r2, #0x1e
0x001565:	adds    	r3, r6, #0
0x001567:	adds    	r0, r7, #0
0x001569:	bl      	#0x5159
; block 0x156d
0x00156d:	cmp     	r0, #0
0x00156f:	beq     	#0x1637
; block 0x1571
0x001571:	movs    	r1, #0
0x001573:	movs    	r2, #0
0x001575:	str     	r2, [sp, #8]
0x001577:	str     	r1, [sp]
0x001579:	str     	r1, [sp, #4]
0x00157b:	movs    	r1, #0xe1
0x00157d:	movs    	r2, #0x28
0x00157f:	adds    	r3, r6, #0
0x001581:	adds    	r0, r7, #0
0x001583:	bl      	#0x5159
; block 0x1587
0x001587:	movs    	r1, #0
0x001589:	movs    	r2, #0
0x00158b:	str     	r2, [sp, #8]
0x00158d:	str     	r1, [sp]
0x00158f:	str     	r1, [sp, #4]
0x001591:	movs    	r1, #0xe1
0x001593:	movs    	r2, #0x29
0x001595:	adds    	r4, r0, #0
0x001597:	adds    	r3, r6, #0
0x001599:	adds    	r0, r7, #0
0x00159b:	bl      	#0x5159
; block 0x159f
0x00159f:	movs    	r1, #0
0x0015a1:	movs    	r2, #0
0x0015a3:	str     	r2, [sp, #8]
0x0015a5:	str     	r1, [sp]
0x0015a7:	str     	r1, [sp, #4]
0x0015a9:	movs    	r1, #0xe1
0x0015ab:	movs    	r2, #0x1e
0x0015ad:	adds    	r5, r0, #0
0x0015af:	adds    	r3, r6, #0
0x0015b1:	adds    	r0, r7, #0
0x0015b3:	bl      	#0x5159
; block 0x15b7
0x0015b7:	add     	r2, sp, #0x44
0x0015b9:	str     	r2, [sp, #8]
0x0015bb:	add     	r1, sp, #0x48
0x0015bd:	str     	r1, [sp, #4]
0x0015bf:	adds    	r2, r0, #0
0x0015c1:	adds    	r0, r7, #0
0x0015c3:	movs    	r1, #0x2a
0x0015c5:	adds    	r3, r5, #0
0x0015c7:	str     	r4, [sp]
0x0015c9:	bl      	#0x5159
; block 0x15cd
0x0015cd:	movs    	r1, #0
0x0015cf:	movs    	r2, #0
0x0015d1:	str     	r2, [sp, #8]
0x0015d3:	str     	r1, [sp]
0x0015d5:	str     	r1, [sp, #4]
0x0015d7:	movs    	r1, #0xe1
0x0015d9:	movs    	r2, #0x1e
0x0015db:	adds    	r3, r6, #0
0x0015dd:	adds    	r0, r7, #0
0x0015df:	bl      	#0x5159
; block 0x15e3
0x0015e3:	str     	r0, [sp, #0x18]
0x0015e5:	ldr     	r0, [sp, #0x50]
0x0015e7:	movs    	r1, #0
0x0015e9:	adds    	r0, #0x16
0x0015eb:	str     	r0, [sp, #0x1c]
0x0015ed:	ldr     	r0, [sp, #0x4c]
0x0015ef:	str     	r6, [sp, #0x24]
0x0015f1:	adds    	r0, #0x14
0x0015f3:	str     	r0, [sp, #0x20]
0x0015f5:	str     	r6, [sp, #0x28]
0x0015f7:	movs    	r2, #0
0x0015f9:	str     	r2, [sp, #8]
0x0015fb:	str     	r1, [sp]
0x0015fd:	str     	r1, [sp, #4]
0x0015ff:	movs    	r1, #0xe1
0x001601:	movs    	r2, #0x29
0x001603:	adds    	r3, r6, #0
0x001605:	adds    	r0, r7, #0
0x001607:	str     	r6, [sp, #0x2c]
0x001609:	bl      	#0x5159
; block 0x160d
0x00160d:	movs    	r1, #0
0x00160f:	movs    	r2, #0
0x001611:	str     	r2, [sp, #8]
0x001613:	str     	r1, [sp]
0x001615:	str     	r1, [sp, #4]
0x001617:	movs    	r1, #0xe1
0x001619:	movs    	r2, #0x28
0x00161b:	str     	r0, [sp, #0x30]
0x00161d:	adds    	r3, r6, #0
0x00161f:	adds    	r0, r7, #0
0x001621:	bl      	#0x5159
; block 0x1625
0x001625:	movs    	r2, #0
0x001627:	movs    	r1, #0
0x001629:	str     	r2, [sp, #8]
0x00162b:	add     	r2, sp, #0x18
0x00162d:	str     	r1, [sp]
0x00162f:	str     	r1, [sp, #4]
0x001631:	adds    	r3, r6, #0
0x001633:	str     	r0, [sp, #0x34]
0x001635:	b       	#0x1649
; block 0x1637
0x001637:	b       	#0x1651
; block 0x1649
0x001649:	movs    	r1, #0x56
0x00164b:	adds    	r0, r7, #0
0x00164d:	bl      	#0x5159
; block 0x1651
0x001651:	ldr     	r0, [pc, #0x3dc]
0x001653:	add     	r0, sb
0x001655:	ldr     	r0, [r0, #8]
0x001657:	cmp     	r0, #0
0x001659:	bne     	#0x16db
; block 0x165b
0x00165b:	movs    	r1, #0
0x00165d:	movs    	r2, #0
0x00165f:	str     	r2, [sp, #8]
0x001661:	str     	r1, [sp]
0x001663:	str     	r1, [sp, #4]
0x001665:	movs    	r1, #0xe1
0x001667:	movs    	r2, #0x27
0x001669:	adds    	r3, r6, #0
0x00166b:	adds    	r0, r7, #0
0x00166d:	bl      	#0x5159
; block 0x1671
0x001671:	lsls    	r0, r0, #0x1e
0x001673:	bne     	#0x16db
; block 0x1675
0x001675:	ldr     	r0, [pc, #0x3bc]
0x001677:	add     	r0, pc
0x001679:	ldr     	r1, [sp, #0x48]
0x00167b:	str     	r0, [sp, #0x18]
0x00167d:	ldr     	r0, [sp, #0x50]
0x00167f:	str     	r6, [sp, #0x28]
0x001681:	adds    	r0, r0, r1
0x001683:	adds    	r0, #0x15
0x001685:	str     	r0, [sp, #0x1c]
0x001687:	ldr     	r0, [sp, #0x4c]
0x001689:	movs    	r1, #0
0x00168b:	adds    	r0, #0x14
0x00168d:	str     	r0, [sp, #0x20]
0x00168f:	str     	r6, [sp, #0x24]
0x001691:	movs    	r2, #0
0x001693:	str     	r2, [sp, #8]
0x001695:	str     	r1, [sp, #4]
0x001697:	str     	r1, [sp]
0x001699:	movs    	r1, #0xe1
0x00169b:	movs    	r2, #0x29
0x00169d:	adds    	r3, r6, #0
0x00169f:	adds    	r0, r7, #0
0x0016a1:	str     	r6, [sp, #0x2c]
0x0016a3:	bl      	#0x5159
; block 0x16a7
0x0016a7:	movs    	r1, #0
0x0016a9:	movs    	r2, #0
0x0016ab:	str     	r2, [sp, #8]
0x0016ad:	str     	r1, [sp]
0x0016af:	str     	r1, [sp, #4]
0x0016b1:	str     	r0, [sp, #0x30]
0x0016b3:	movs    	r0, #0xf1
0x0016b5:	movs    	r1, #0xe1
0x0016b7:	movs    	r2, #0x28
0x0016b9:	adds    	r3, r6, #0
0x0016bb:	lsls    	r0, r0, #9
0x0016bd:	bl      	#0x5159
; block 0x16c1
0x0016c1:	movs    	r1, #0
0x0016c3:	movs    	r2, #0
0x0016c5:	str     	r1, [sp]
0x0016c7:	str     	r1, [sp, #4]
0x0016c9:	str     	r0, [sp, #0x34]
0x0016cb:	movs    	r0, #0xf1
0x0016cd:	movs    	r1, #0x56
0x0016cf:	str     	r2, [sp, #8]
0x0016d1:	adds    	r3, r6, #0
0x0016d3:	lsls    	r0, r0, #9
0x0016d5:	add     	r2, sp, #0x18
0x0016d7:	bl      	#0x5159
; block 0x16db
0x0016db:	ldr     	r0, [sp, #0x4c]
0x0016dd:	movs    	r1, #0
0x0016df:	str     	r1, [sp]
0x0016e1:	str     	r1, [sp, #4]
0x0016e3:	movs    	r2, #0
0x0016e5:	lsls    	r4, r0, #1
0x0016e7:	adds    	r4, #0x23
0x0016e9:	movs    	r1, #0x1c
0x0016eb:	movs    	r5, #0xa
0x0016ed:	adds    	r3, r6, #0
0x0016ef:	adds    	r0, r7, #0
0x0016f1:	str     	r2, [sp, #8]
0x0016f3:	bl      	#0x5159
; block 0x16f7
0x0016f7:	subs    	r0, #0xa
0x0016f9:	str     	r0, [sp]
0x0016fb:	movs    	r2, #0
0x0016fd:	movs    	r1, #0x1e
0x0016ff:	adds    	r3, r4, #0
0x001701:	subs    	r3, #8
0x001703:	str     	r1, [sp, #4]
0x001705:	str     	r2, [sp, #8]
0x001707:	movs    	r2, #5
0x001709:	movs    	r1, #0x2f
0x00170b:	movs    	r0, #0xf1
0x00170d:	lsls    	r0, r0, #9
0x00170f:	str     	r3, [sp, #0x60]
0x001711:	bl      	#0x5159
; block 0x1715
0x001715:	cmp     	r0, #1
0x001717:	bne     	#0x1759
; block 0x1719
0x001719:	ldr     	r0, [pc, #0x314]
0x00171b:	add     	r0, sb
0x00171d:	ldr     	r1, [r0, #8]
0x00171f:	cmp     	r1, #1
0x001721:	beq     	#0x1729
; block 0x1723
0x001723:	movs    	r1, #1
0x001725:	str     	r1, [r0, #8]
0x001727:	b       	#0x1791
; block 0x1729
0x001729:	movs    	r1, #0
0x00172b:	str     	r1, [sp]
0x00172d:	str     	r1, [sp, #4]
0x00172f:	movs    	r2, #0
0x001731:	movs    	r1, #0x1c
0x001733:	adds    	r3, r6, #0
0x001735:	adds    	r0, r7, #0
0x001737:	str     	r2, [sp, #8]
0x001739:	bl      	#0x5159
; block 0x173d
0x00173d:	adds    	r1, r0, #0
0x00173f:	ldr     	r0, [sp, #0x60]
0x001741:	subs    	r1, #0xa
0x001743:	movs    	r2, #0x1e
0x001745:	str     	r2, [sp, #8]
0x001747:	str     	r1, [sp, #4]
0x001749:	str     	r0, [sp]
0x00174b:	movs    	r0, #0xf1
0x00174d:	movs    	r1, #0x23
0x00174f:	movs    	r2, #4
0x001751:	movs    	r3, #5
0x001753:	lsls    	r0, r0, #9
0x001755:	bl      	#0x5159
; block 0x1759
0x001759:	ldr     	r0, [pc, #0x2d4]
0x00175b:	add     	r0, sb
0x00175d:	ldr     	r0, [r0, #8]
0x00175f:	cmp     	r0, #1
0x001761:	beq     	#0x1791
; block 0x1763
0x001763:	ldr     	r0, [pc, #0x2d4]
0x001765:	add     	r0, pc
0x001767:	str     	r0, [sp, #0x1c]
0x001769:	movs    	r0, #0xff
0x00176b:	str     	r0, [sp, #0x20]
0x00176d:	str     	r0, [sp, #0x24]
0x00176f:	str     	r0, [sp, #0x28]
0x001771:	str     	r5, [sp, #0x2c]
0x001773:	str     	r4, [sp, #0x30]
0x001775:	add     	r3, sp, #0x20
0x001777:	strb    	r6, [r3, #0x14]
0x001779:	movs    	r1, #0
0x00177b:	movs    	r2, #0
0x00177d:	str     	r1, [sp]
0x00177f:	str     	r1, [sp, #4]
0x001781:	movs    	r1, #0x9b
0x001783:	str     	r2, [sp, #8]
0x001785:	adds    	r3, r6, #0
0x001787:	adds    	r0, r7, #0
0x001789:	add     	r2, sp, #0x1c
0x00178b:	bl      	#0x5159
; block 0x178f
0x00178f:	b       	#0x17bf
; block 0x1791
0x001791:	ldr     	r0, [pc, #0x2a8]
0x001793:	add     	r0, pc
0x001795:	str     	r0, [sp, #0x1c]
0x001797:	movs    	r0, #0xff
0x001799:	str     	r0, [sp, #0x20]
0x00179b:	str     	r0, [sp, #0x24]
0x00179d:	str     	r0, [sp, #0x28]
0x00179f:	str     	r5, [sp, #0x2c]
0x0017a1:	str     	r4, [sp, #0x30]
0x0017a3:	movs    	r1, #1
0x0017a5:	add     	r3, sp, #0x20
0x0017a7:	strb    	r1, [r3, #0x14]
0x0017a9:	movs    	r1, #0
0x0017ab:	movs    	r2, #0
0x0017ad:	str     	r1, [sp]
0x0017af:	str     	r1, [sp, #4]
0x0017b1:	movs    	r1, #0x9b
0x0017b3:	str     	r2, [sp, #8]
0x0017b5:	adds    	r3, r6, #0
0x0017b7:	adds    	r0, r7, #0
0x0017b9:	add     	r2, sp, #0x1c
0x0017bb:	bl      	#0x5159
; block 0x17bf
0x0017bf:	ldr     	r0, [sp, #0x4c]
0x0017c1:	ldr     	r1, [pc, #0x26c]
0x0017c3:	lsls    	r4, r0, #1
0x0017c5:	add     	r1, sb
0x0017c7:	ldr     	r0, [r1, #8]
0x0017c9:	adds    	r4, #0x41
0x0017cb:	cmp     	r0, #2
0x0017cd:	bne     	#0x1801
; block 0x17cf
0x0017cf:	movs    	r1, #0
0x0017d1:	str     	r1, [sp]
0x0017d3:	str     	r1, [sp, #4]
0x0017d5:	movs    	r2, #0
0x0017d7:	movs    	r1, #0x1c
0x0017d9:	adds    	r3, r6, #0
0x0017db:	adds    	r0, r7, #0
0x0017dd:	str     	r2, [sp, #8]
0x0017df:	bl      	#0x5159
; block 0x17e3
0x0017e3:	subs    	r0, #0xa
0x0017e5:	movs    	r2, #0
0x0017e7:	movs    	r1, #0x1e
0x0017e9:	str     	r1, [sp, #4]
0x0017eb:	str     	r2, [sp, #8]
0x0017ed:	str     	r0, [sp]
0x0017ef:	adds    	r3, r4, #0
0x0017f1:	subs    	r3, #8
0x0017f3:	movs    	r0, #0xf1
0x0017f5:	movs    	r2, #5
0x0017f7:	movs    	r1, #0x30
0x0017f9:	lsls    	r0, r0, #9
0x0017fb:	bl      	#0x5159
; block 0x17ff
0x0017ff:	b       	#0x183d
; block 0x1801
0x001801:	movs    	r1, #0
0x001803:	str     	r1, [sp]
0x001805:	str     	r1, [sp, #4]
0x001807:	movs    	r2, #0
0x001809:	movs    	r1, #0x1c
0x00180b:	adds    	r3, r6, #0
0x00180d:	adds    	r0, r7, #0
0x00180f:	str     	r2, [sp, #8]
0x001811:	bl      	#0x5159
; block 0x1815
0x001815:	subs    	r0, #0xa
0x001817:	movs    	r2, #0
0x001819:	movs    	r1, #0x1e
0x00181b:	str     	r1, [sp, #4]
0x00181d:	str     	r2, [sp, #8]
0x00181f:	str     	r0, [sp]
0x001821:	adds    	r3, r4, #0
0x001823:	subs    	r3, #8
0x001825:	movs    	r0, #0xf1
0x001827:	movs    	r2, #5
0x001829:	movs    	r1, #0x2f
0x00182b:	lsls    	r0, r0, #9
0x00182d:	bl      	#0x5159
; block 0x1831
0x001831:	cmp     	r0, #1
0x001833:	bne     	#0x183d
; block 0x1835
0x001835:	ldr     	r1, [pc, #0x1f8]
0x001837:	movs    	r0, #2
0x001839:	add     	r1, sb
0x00183b:	str     	r0, [r1, #8]
0x00183d:	ldr     	r0, [pc, #0x200]
0x00183f:	add     	r0, pc
0x001841:	movs    	r1, #0
0x001843:	str     	r0, [sp, #0x40]
0x001845:	movs    	r2, #0
0x001847:	str     	r2, [sp, #8]
0x001849:	str     	r1, [sp]
0x00184b:	str     	r1, [sp, #4]
0x00184d:	movs    	r1, #0xe1
0x00184f:	movs    	r2, #0x28
0x001851:	adds    	r3, r6, #0
0x001853:	adds    	r0, r7, #0
0x001855:	bl      	#0x5159
; block 0x183d
0x00183d:	ldr     	r0, [pc, #0x200]
0x00183f:	add     	r0, pc
0x001841:	movs    	r1, #0
0x001843:	str     	r0, [sp, #0x40]
0x001845:	movs    	r2, #0
0x001847:	str     	r2, [sp, #8]
0x001849:	str     	r1, [sp]
0x00184b:	str     	r1, [sp, #4]
0x00184d:	movs    	r1, #0xe1
0x00184f:	movs    	r2, #0x28
0x001851:	adds    	r3, r6, #0
0x001853:	adds    	r0, r7, #0
0x001855:	bl      	#0x5159
; block 0x1859
0x001859:	movs    	r1, #0
0x00185b:	movs    	r2, #0
0x00185d:	str     	r2, [sp, #8]
0x00185f:	str     	r1, [sp]
0x001861:	str     	r1, [sp, #4]
0x001863:	str     	r0, [sp, #0x34]
0x001865:	movs    	r0, #0xf1
0x001867:	movs    	r1, #0xe1
0x001869:	movs    	r2, #0x29
0x00186b:	adds    	r3, r6, #0
0x00186d:	lsls    	r0, r0, #9
0x00186f:	bl      	#0x5159
; block 0x1873
0x001873:	adds    	r3, r0, #0
0x001875:	ldr     	r0, [sp, #0x34]
0x001877:	add     	r1, sp, #0x50
0x001879:	str     	r0, [sp]
0x00187b:	str     	r1, [sp, #4]
0x00187d:	add     	r2, sp, #0x4c
0x00187f:	str     	r2, [sp, #8]
0x001881:	movs    	r1, #0x2a
0x001883:	movs    	r0, #0xf1
0x001885:	lsls    	r0, r0, #9
0x001887:	ldr     	r2, [sp, #0x40]
0x001889:	bl      	#0x5159
; block 0x188d
0x00188d:	ldr     	r0, [sp, #0x40]
0x00188f:	movs    	r1, #0
0x001891:	str     	r0, [sp, #0x18]
0x001893:	movs    	r0, #0xff
0x001895:	str     	r0, [sp, #0x24]
0x001897:	str     	r0, [sp, #0x28]
0x001899:	movs    	r0, #0xc8
0x00189b:	str     	r4, [sp, #0x20]
0x00189d:	movs    	r2, #0
0x00189f:	str     	r2, [sp, #8]
0x0018a1:	str     	r1, [sp]
0x0018a3:	str     	r0, [sp, #0x2c]
0x0018a5:	str     	r1, [sp, #4]
0x0018a7:	movs    	r1, #0xe1
0x0018a9:	movs    	r0, #0xf1
0x0018ab:	movs    	r2, #0x29
0x0018ad:	adds    	r3, r6, #0
0x0018af:	lsls    	r0, r0, #9
0x0018b1:	str     	r5, [sp, #0x1c]
0x0018b3:	bl      	#0x5159
; block 0x18b7
0x0018b7:	movs    	r1, #0
0x0018b9:	movs    	r2, #0
0x0018bb:	str     	r2, [sp, #8]
0x0018bd:	str     	r1, [sp]
0x0018bf:	str     	r1, [sp, #4]
0x0018c1:	str     	r0, [sp, #0x30]
0x0018c3:	movs    	r0, #0xf1
0x0018c5:	movs    	r1, #0xe1
0x0018c7:	movs    	r2, #0x28
0x0018c9:	adds    	r3, r6, #0
0x0018cb:	lsls    	r0, r0, #9
0x0018cd:	bl      	#0x5159
; block 0x18d1
0x0018d1:	movs    	r1, #0
0x0018d3:	movs    	r2, #0
0x0018d5:	str     	r1, [sp]
0x0018d7:	str     	r1, [sp, #4]
0x0018d9:	str     	r0, [sp, #0x34]
0x0018db:	movs    	r0, #0xf1
0x0018dd:	movs    	r1, #0x56
0x0018df:	str     	r2, [sp, #8]
0x0018e1:	adds    	r3, r6, #0
0x0018e3:	lsls    	r0, r0, #9
0x0018e5:	add     	r2, sp, #0x18
0x0018e7:	bl      	#0x5159
; block 0x18eb
0x0018eb:	ldr     	r5, [sp, #0x50]
0x0018ed:	movs    	r1, #0
0x0018ef:	movs    	r2, #0
0x0018f1:	str     	r2, [sp, #8]
0x0018f3:	str     	r1, [sp]
0x0018f5:	str     	r1, [sp, #4]
0x0018f7:	adds    	r5, #0x32
0x0018f9:	adds    	r3, r6, #0
0x0018fb:	movs    	r1, #0xe1
0x0018fd:	movs    	r2, #0x25
0x0018ff:	movs    	r0, #0xf1
0x001901:	lsls    	r0, r0, #9
0x001903:	bl      	#0x5159
; block 0x1907
0x001907:	ldr     	r1, [pc, #0x128]
0x001909:	add     	r3, sp, #0x10
0x00190b:	add     	r1, sb
0x00190d:	ldr     	r1, [r1, #4]
0x00190f:	movs    	r2, #0
0x001911:	lsls    	r1, r1, #2
0x001913:	ldr     	r0, [r0, r1]
0x001915:	str     	r5, [sp, #0x14]
0x001917:	str     	r0, [sp, #0x40]
0x001919:	str     	r0, [sp, #0x10]
0x00191b:	movs    	r0, #0xc8
0x00191d:	str     	r0, [sp, #0x24]
0x00191f:	movs    	r0, #1
0x001921:	str     	r6, [sp, #0x20]
0x001923:	str     	r4, [sp, #0x18]
0x001925:	str     	r6, [sp, #0x1c]
0x001927:	str     	r6, [sp, #0x28]
0x001929:	str     	r6, [sp, #0x2c]
0x00192b:	movs    	r1, #0x20
0x00192d:	strb    	r0, [r1, r3]
0x00192f:	movs    	r1, #0
0x001931:	str     	r1, [sp]
0x001933:	str     	r1, [sp, #4]
0x001935:	str     	r2, [sp, #8]
0x001937:	movs    	r0, #0xf1
0x001939:	lsls    	r0, r0, #9
0x00193b:	adds    	r2, r3, #0
0x00193d:	movs    	r1, #0x25
0x00193f:	adds    	r3, r6, #0
0x001941:	str     	r6, [sp, #0x34]
0x001943:	bl      	#0x5159
; block 0x1947
0x001947:	movs    	r1, #0
0x001949:	movs    	r2, #0
0x00194b:	str     	r2, [sp, #8]
0x00194d:	str     	r1, [sp]
0x00194f:	str     	r1, [sp, #4]
0x001951:	movs    	r1, #0xe1
0x001953:	movs    	r2, #0x28
0x001955:	adds    	r3, r6, #0
0x001957:	movs    	r0, #0xf1
0x001959:	lsls    	r0, r0, #9
0x00195b:	bl      	#0x5159
; block 0x195f
0x00195f:	movs    	r1, #0
0x001961:	movs    	r2, #0
0x001963:	str     	r2, [sp, #8]
0x001965:	str     	r1, [sp]
0x001967:	str     	r1, [sp, #4]
0x001969:	str     	r0, [sp, #0x34]
0x00196b:	movs    	r0, #0xf1
0x00196d:	movs    	r1, #0xe1
0x00196f:	movs    	r2, #0x29
0x001971:	adds    	r3, r6, #0
0x001973:	lsls    	r0, r0, #9
0x001975:	bl      	#0x5159
; block 0x1979
0x001979:	adds    	r3, r0, #0
0x00197b:	ldr     	r0, [sp, #0x34]
0x00197d:	add     	r1, sp, #0x50
0x00197f:	str     	r0, [sp]
0x001981:	str     	r1, [sp, #4]
0x001983:	add     	r2, sp, #0x4c
0x001985:	str     	r2, [sp, #8]
0x001987:	movs    	r1, #0x2a
0x001989:	movs    	r0, #0xf1
0x00198b:	lsls    	r0, r0, #9
0x00198d:	ldr     	r2, [sp, #0x40]
0x00198f:	bl      	#0x5159
; block 0x1993
0x001993:	ldr     	r1, [pc, #0x9c]
0x001995:	add     	r1, sb
0x001997:	ldr     	r0, [r1, #8]
0x001999:	cmp     	r0, #2
0x00199b:	bne     	#0x1a81
; block 0x199d
0x00199d:	movs    	r1, #0
0x00199f:	movs    	r2, #0
0x0019a1:	str     	r2, [sp, #8]
0x0019a3:	str     	r1, [sp]
0x0019a5:	str     	r1, [sp, #4]
0x0019a7:	movs    	r1, #0xe1
0x0019a9:	movs    	r2, #0x26
0x0019ab:	adds    	r3, r6, #0
0x0019ad:	adds    	r0, r7, #0
0x0019af:	bl      	#0x5159
; block 0x19b3
0x0019b3:	str     	r0, [sp, #0x20]
0x0019b5:	movs    	r1, #0
0x0019b7:	movs    	r2, #0
0x0019b9:	str     	r2, [sp, #8]
0x0019bb:	str     	r1, [sp]
0x0019bd:	str     	r1, [sp, #4]
0x0019bf:	movs    	r1, #0xe1
0x0019c1:	movs    	r2, #0x27
0x0019c3:	movs    	r0, #0xf1
0x0019c5:	adds    	r3, r6, #0
0x0019c7:	lsls    	r0, r0, #9
0x0019c9:	bl      	#0x5159
; block 0x19cd
0x0019cd:	lsrs    	r1, r0, #0x1f
0x0019cf:	adds    	r1, r1, r0
0x0019d1:	asrs    	r1, r1, #1
0x0019d3:	lsls    	r1, r1, #1
0x0019d5:	subs    	r0, r0, r1
0x0019d7:	adds    	r1, r5, #0
0x0019d9:	subs    	r1, #0x14
0x0019db:	lsls    	r0, r0, #1
0x0019dd:	subs    	r0, r1, r0
0x0019df:	str     	r0, [sp, #0x24]
0x0019e1:	movs    	r0, #8
0x0019e3:	str     	r1, [sp, #0x5c]
0x0019e5:	movs    	r1, #0
0x0019e7:	str     	r0, [sp, #0x2c]
0x0019e9:	movs    	r0, #0xe
0x0019eb:	movs    	r2, #0
0x0019ed:	str     	r0, [sp, #0x30]
0x0019ef:	str     	r1, [sp]
0x0019f1:	str     	r1, [sp, #4]
0x0019f3:	str     	r4, [sp, #0x28]
0x0019f5:	str     	r2, [sp, #8]
0x0019f7:	movs    	r1, #0x22
0x0019f9:	movs    	r0, #0xf1
0x0019fb:	adds    	r3, r6, #0
0x0019fd:	lsls    	r0, r0, #9
0x0019ff:	add     	r2, sp, #0x20
0x001a01:	str     	r6, [sp, #0x34]
0x001a03:	bl      	#0x5159
; block 0x1a07
0x001a07:	movs    	r1, #0
0x001a09:	movs    	r2, #0
0x001a0b:	str     	r2, [sp, #8]
0x001a0d:	str     	r1, [sp]
0x001a0f:	str     	r1, [sp, #4]
0x001a11:	movs    	r1, #0xe1
0x001a13:	movs    	r2, #0x27
0x001a15:	adds    	r3, r6, #0
0x001a17:	movs    	r0, #0xf1
0x001a19:	lsls    	r0, r0, #9
0x001a1b:	bl      	#0x5159
; block 0x1a1f
0x001a1f:	lsrs    	r1, r0, #0x1f
0x001a21:	adds    	r1, r1, r0
0x001a23:	asrs    	r1, r1, #1
0x001a25:	lsls    	r1, r1, #1
0x001a27:	subs    	r0, r0, r1
0x001a29:	ldr     	r1, [sp, #0x5c]
0x001a2b:	lsls    	r0, r0, #1
0x001a2d:	subs    	r3, r1, r0
0x001a2f:	b       	#0x1a45
; block 0x1a45
0x001a45:	movs    	r2, #0x14
0x001a47:	movs    	r1, #0x1e
0x001a49:	str     	r1, [sp, #4]
0x001a4b:	str     	r2, [sp, #8]
0x001a4d:	movs    	r2, #2
0x001a4f:	movs    	r1, #0x23
0x001a51:	subs    	r3, #0x14
0x001a53:	movs    	r0, #0xf1
0x001a55:	lsls    	r0, r0, #9
0x001a57:	str     	r4, [sp]
0x001a59:	bl      	#0x5159
; block 0x1a5d
0x001a5d:	movs    	r1, #0
0x001a5f:	movs    	r2, #0
0x001a61:	str     	r2, [sp, #8]
0x001a63:	str     	r1, [sp]
0x001a65:	str     	r1, [sp, #4]
0x001a67:	movs    	r1, #0xe1
0x001a69:	movs    	r2, #0x26
0x001a6b:	adds    	r3, r6, #0
0x001a6d:	movs    	r0, #0xf1
0x001a6f:	lsls    	r0, r0, #9
0x001a71:	bl      	#0x5159
; block 0x1a75
0x001a75:	movs    	r2, #0
0x001a77:	movs    	r1, #0
0x001a79:	str     	r0, [sp, #0x20]
0x001a7b:	str     	r1, [sp]
0x001a7d:	str     	r1, [sp, #4]
0x001a7f:	b       	#0x1a83
; block 0x1a81
0x001a81:	b       	#0x1b11
; block 0x1a83
0x001a83:	str     	r2, [sp, #8]
0x001a85:	movs    	r2, #0x27
0x001a87:	adds    	r3, r6, #0
0x001a89:	movs    	r1, #0xe1
0x001a8b:	movs    	r0, #0xf1
0x001a8d:	lsls    	r0, r0, #9
0x001a8f:	bl      	#0x5159
; block 0x1a93
0x001a93:	lsrs    	r1, r0, #0x1f
0x001a95:	adds    	r1, r1, r0
0x001a97:	asrs    	r1, r1, #1
0x001a99:	lsls    	r1, r1, #1
0x001a9b:	subs    	r0, r0, r1
0x001a9d:	ldr     	r1, [sp, #0x50]
0x001a9f:	lsls    	r0, r0, #1
0x001aa1:	adds    	r1, r5, r1
0x001aa3:	adds    	r0, r0, r1
0x001aa5:	adds    	r0, #0xa
0x001aa7:	str     	r0, [sp, #0x24]
0x001aa9:	movs    	r0, #8
0x001aab:	str     	r0, [sp, #0x2c]
0x001aad:	movs    	r0, #0xe
0x001aaf:	str     	r0, [sp, #0x30]
0x001ab1:	movs    	r1, #0
0x001ab3:	movs    	r0, #1
0x001ab5:	movs    	r2, #0
0x001ab7:	str     	r0, [sp, #0x34]
0x001ab9:	str     	r1, [sp]
0x001abb:	str     	r1, [sp, #4]
0x001abd:	str     	r4, [sp, #0x28]
0x001abf:	str     	r2, [sp, #8]
0x001ac1:	movs    	r1, #0x22
0x001ac3:	movs    	r0, #0xf1
0x001ac5:	adds    	r3, r6, #0
0x001ac7:	lsls    	r0, r0, #9
0x001ac9:	add     	r2, sp, #0x20
0x001acb:	bl      	#0x5159
; block 0x1acf
0x001acf:	movs    	r1, #0
0x001ad1:	movs    	r2, #0
0x001ad3:	str     	r2, [sp, #8]
0x001ad5:	str     	r1, [sp]
0x001ad7:	str     	r1, [sp, #4]
0x001ad9:	movs    	r1, #0xe1
0x001adb:	movs    	r2, #0x27
0x001add:	adds    	r3, r6, #0
0x001adf:	movs    	r0, #0xf1
0x001ae1:	lsls    	r0, r0, #9
0x001ae3:	bl      	#0x5159
; block 0x1ae7
0x001ae7:	lsrs    	r1, r0, #0x1f
0x001ae9:	adds    	r1, r1, r0
0x001aeb:	asrs    	r1, r1, #1
0x001aed:	lsls    	r1, r1, #1
0x001aef:	subs    	r0, r0, r1
0x001af1:	ldr     	r1, [sp, #0x50]
0x001af3:	lsls    	r0, r0, #1
0x001af5:	adds    	r1, r5, r1
0x001af7:	adds    	r3, r0, r1
0x001af9:	movs    	r1, #0x1e
0x001afb:	movs    	r2, #0x14
0x001afd:	str     	r2, [sp, #8]
0x001aff:	str     	r1, [sp, #4]
0x001b01:	movs    	r1, #0x23
0x001b03:	movs    	r2, #3
0x001b05:	adds    	r3, #0xa
0x001b07:	movs    	r0, #0xf1
0x001b09:	lsls    	r0, r0, #9
0x001b0b:	str     	r4, [sp]
0x001b0d:	bl      	#0x5159
; block 0x1b11
0x001b11:	ldr     	r1, [pc, #0x3e4]
0x001b13:	movs    	r0, #0xa
0x001b15:	str     	r0, [sp, #0x38]
0x001b17:	add     	r1, sb
0x001b19:	ldr     	r0, [r1, #8]
0x001b1b:	adds    	r4, #0x1e
0x001b1d:	cmp     	r0, #3
0x001b1f:	bne     	#0x1b53
; block 0x1b21
0x001b21:	movs    	r1, #0
0x001b23:	str     	r1, [sp]
0x001b25:	str     	r1, [sp, #4]
0x001b27:	movs    	r2, #0
0x001b29:	movs    	r1, #0x1c
0x001b2b:	adds    	r3, r6, #0
0x001b2d:	adds    	r0, r7, #0
0x001b2f:	str     	r2, [sp, #8]
0x001b31:	bl      	#0x5159
; block 0x1b35
0x001b35:	subs    	r0, #0xa
0x001b37:	movs    	r2, #0
0x001b39:	movs    	r1, #0x41
0x001b3b:	str     	r1, [sp, #4]
0x001b3d:	str     	r2, [sp, #8]
0x001b3f:	str     	r0, [sp]
0x001b41:	adds    	r3, r4, #0
0x001b43:	subs    	r3, #8
0x001b45:	movs    	r0, #0xf1
0x001b47:	movs    	r2, #5
0x001b49:	movs    	r1, #0x30
0x001b4b:	lsls    	r0, r0, #9
0x001b4d:	bl      	#0x5159
; block 0x1b51
0x001b51:	b       	#0x1b8f
; block 0x1b53
0x001b53:	movs    	r1, #0
0x001b55:	str     	r1, [sp]
0x001b57:	str     	r1, [sp, #4]
0x001b59:	movs    	r2, #0
0x001b5b:	movs    	r1, #0x1c
0x001b5d:	adds    	r3, r6, #0
0x001b5f:	adds    	r0, r7, #0
0x001b61:	str     	r2, [sp, #8]
0x001b63:	bl      	#0x5159
; block 0x1b67
0x001b67:	subs    	r0, #0xa
0x001b69:	movs    	r2, #0
0x001b6b:	movs    	r1, #0x41
0x001b6d:	str     	r1, [sp, #4]
0x001b6f:	str     	r2, [sp, #8]
0x001b71:	str     	r0, [sp]
0x001b73:	adds    	r3, r4, #0
0x001b75:	subs    	r3, #8
0x001b77:	movs    	r0, #0xf1
0x001b79:	movs    	r2, #5
0x001b7b:	movs    	r1, #0x2f
0x001b7d:	lsls    	r0, r0, #9
0x001b7f:	bl      	#0x5159
; block 0x1b83
0x001b83:	cmp     	r0, #1
0x001b85:	bne     	#0x1b8f
; block 0x1b87
0x001b87:	ldr     	r1, [pc, #0x370]
0x001b89:	movs    	r0, #3
0x001b8b:	add     	r1, sb
0x001b8d:	str     	r0, [r1, #8]
0x001b8f:	ldr     	r5, [pc, #0x36c]
0x001b91:	add     	r5, pc
0x001b93:	movs    	r1, #0
0x001b95:	movs    	r2, #0
0x001b97:	str     	r2, [sp, #8]
0x001b99:	str     	r1, [sp]
0x001b9b:	str     	r1, [sp, #4]
0x001b9d:	movs    	r6, #0
0x001b9f:	adds    	r3, r6, #0
0x001ba1:	movs    	r1, #0xe1
0x001ba3:	movs    	r2, #0x28
0x001ba5:	movs    	r0, #0xf1
0x001ba7:	lsls    	r0, r0, #9
0x001ba9:	bl      	#0x5159
; block 0x1b8f
0x001b8f:	ldr     	r5, [pc, #0x36c]
0x001b91:	add     	r5, pc
0x001b93:	movs    	r1, #0
0x001b95:	movs    	r2, #0
0x001b97:	str     	r2, [sp, #8]
0x001b99:	str     	r1, [sp]
0x001b9b:	str     	r1, [sp, #4]
0x001b9d:	movs    	r6, #0
0x001b9f:	adds    	r3, r6, #0
0x001ba1:	movs    	r1, #0xe1
0x001ba3:	movs    	r2, #0x28
0x001ba5:	movs    	r0, #0xf1
0x001ba7:	lsls    	r0, r0, #9
0x001ba9:	bl      	#0x5159
; block 0x1bad
0x001bad:	movs    	r1, #0
0x001baf:	adds    	r7, r0, #0
0x001bb1:	movs    	r2, #0
0x001bb3:	str     	r2, [sp, #8]
0x001bb5:	str     	r1, [sp]
0x001bb7:	str     	r1, [sp, #4]
0x001bb9:	movs    	r1, #0xe1
0x001bbb:	movs    	r2, #0x29
0x001bbd:	movs    	r0, #0xf1
0x001bbf:	adds    	r3, r6, #0
0x001bc1:	lsls    	r0, r0, #9
0x001bc3:	bl      	#0x5159
; block 0x1bc7
0x001bc7:	adds    	r3, r0, #0
0x001bc9:	add     	r2, sp, #0x4c
0x001bcb:	add     	r1, sp, #0x50
0x001bcd:	str     	r1, [sp, #4]
0x001bcf:	str     	r2, [sp, #8]
0x001bd1:	adds    	r2, r5, #0
0x001bd3:	movs    	r1, #0x2a
0x001bd5:	movs    	r0, #0xf1
0x001bd7:	lsls    	r0, r0, #9
0x001bd9:	str     	r7, [sp]
0x001bdb:	bl      	#0x5159
; block 0x1bdf
0x001bdf:	str     	r5, [sp, #0x18]
0x001be1:	ldr     	r0, [sp, #0x38]
0x001be3:	movs    	r1, #0
0x001be5:	str     	r0, [sp, #0x1c]
0x001be7:	movs    	r0, #0xff
0x001be9:	str     	r0, [sp, #0x24]
0x001beb:	str     	r0, [sp, #0x28]
0x001bed:	movs    	r0, #0xc8
0x001bef:	str     	r4, [sp, #0x20]
0x001bf1:	movs    	r2, #0
0x001bf3:	str     	r2, [sp, #8]
0x001bf5:	str     	r1, [sp]
0x001bf7:	str     	r0, [sp, #0x2c]
0x001bf9:	str     	r1, [sp, #4]
0x001bfb:	movs    	r1, #0xe1
0x001bfd:	movs    	r0, #0xf1
0x001bff:	movs    	r2, #0x29
0x001c01:	adds    	r3, r6, #0
0x001c03:	lsls    	r0, r0, #9
0x001c05:	bl      	#0x5159
; block 0x1c09
0x001c09:	movs    	r1, #0
0x001c0b:	movs    	r2, #0
0x001c0d:	str     	r2, [sp, #8]
0x001c0f:	str     	r1, [sp]
0x001c11:	str     	r1, [sp, #4]
0x001c13:	str     	r0, [sp, #0x30]
0x001c15:	movs    	r0, #0xf1
0x001c17:	movs    	r1, #0xe1
0x001c19:	movs    	r2, #0x28
0x001c1b:	adds    	r3, r6, #0
0x001c1d:	lsls    	r0, r0, #9
0x001c1f:	bl      	#0x5159
; block 0x1c23
0x001c23:	movs    	r1, #0
0x001c25:	movs    	r2, #0
0x001c27:	str     	r1, [sp]
0x001c29:	str     	r1, [sp, #4]
0x001c2b:	str     	r0, [sp, #0x34]
0x001c2d:	movs    	r0, #0xf1
0x001c2f:	movs    	r1, #0x56
0x001c31:	str     	r2, [sp, #8]
0x001c33:	adds    	r3, r6, #0
0x001c35:	lsls    	r0, r0, #9
0x001c37:	add     	r2, sp, #0x18
0x001c39:	bl      	#0x5159
; block 0x1c3d
0x001c3d:	ldr     	r6, [pc, #0x2b8]
0x001c3f:	ldr     	r5, [sp, #0x50]
0x001c41:	add     	r6, sb
0x001c43:	ldr     	r0, [r6]
0x001c45:	adds    	r4, #0x1e
0x001c47:	adds    	r5, #0x28
0x001c49:	cmp     	r0, #0
0x001c4b:	bne     	#0x1c8d
; block 0x1c4d
0x001c4d:	movs    	r1, #0
0x001c4f:	movs    	r2, #0
0x001c51:	str     	r2, [sp, #8]
0x001c53:	str     	r1, [sp]
0x001c55:	str     	r1, [sp, #4]
0x001c57:	movs    	r6, #0
0x001c59:	adds    	r3, r6, #0
0x001c5b:	movs    	r1, #0xe1
0x001c5d:	movs    	r2, #0x24
0x001c5f:	movs    	r0, #0xf1
0x001c61:	lsls    	r0, r0, #9
0x001c63:	bl      	#0x5159
; block 0x1c67
0x001c67:	ldr     	r7, [pc, #0x290]
0x001c69:	movs    	r2, #0
0x001c6b:	add     	r7, sb
0x001c6d:	ldr     	r1, [r7, #0x1c]
0x001c6f:	lsls    	r1, r1, #2
0x001c71:	ldr     	r0, [r0, r1]
0x001c73:	movs    	r1, #0
0x001c75:	ldr     	r3, [r0, #0x18]
0x001c77:	str     	r1, [sp]
0x001c79:	str     	r1, [sp, #4]
0x001c7b:	str     	r2, [sp, #8]
0x001c7d:	movs    	r0, #0xf1
0x001c7f:	lsls    	r0, r0, #9
0x001c81:	adds    	r2, r3, #0
0x001c83:	movs    	r1, #0x37
0x001c85:	adds    	r3, r6, #0
0x001c87:	bl      	#0x5159
; block 0x1c8b
0x001c8b:	str     	r0, [r7]
0x001c8d:	ldr     	r6, [pc, #0x268]
0x001c8f:	movs    	r1, #0
0x001c91:	add     	r6, sb
0x001c93:	ldr     	r0, [r6]
0x001c95:	str     	r5, [sp, #0x24]
0x001c97:	str     	r0, [sp, #0x20]
0x001c99:	str     	r4, [sp, #0x28]
0x001c9b:	movs    	r2, #0
0x001c9d:	str     	r2, [sp, #8]
0x001c9f:	str     	r1, [sp]
0x001ca1:	str     	r1, [sp, #4]
0x001ca3:	movs    	r7, #2
0x001ca5:	movs    	r1, #0xe1
0x001ca7:	movs    	r2, #0x27
0x001ca9:	movs    	r0, #0xf1
0x001cab:	movs    	r3, #0
0x001cad:	lsls    	r0, r0, #9
0x001caf:	str     	r7, [sp, #0x2c]
0x001cb1:	bl      	#0x5159
; block 0x1c8d
0x001c8d:	ldr     	r6, [pc, #0x268]
0x001c8f:	movs    	r1, #0
0x001c91:	add     	r6, sb
0x001c93:	ldr     	r0, [r6]
0x001c95:	str     	r5, [sp, #0x24]
0x001c97:	str     	r0, [sp, #0x20]
0x001c99:	str     	r4, [sp, #0x28]
0x001c9b:	movs    	r2, #0
0x001c9d:	str     	r2, [sp, #8]
0x001c9f:	str     	r1, [sp]
0x001ca1:	str     	r1, [sp, #4]
0x001ca3:	movs    	r7, #2
0x001ca5:	movs    	r1, #0xe1
0x001ca7:	movs    	r2, #0x27
0x001ca9:	movs    	r0, #0xf1
0x001cab:	movs    	r3, #0
0x001cad:	lsls    	r0, r0, #9
0x001caf:	str     	r7, [sp, #0x2c]
0x001cb1:	bl      	#0x5159
; block 0x1cb5
0x001cb5:	lsrs    	r1, r0, #0x1f
0x001cb7:	adds    	r0, r1, r0
0x001cb9:	movs    	r1, #0
0x001cbb:	asrs    	r0, r0, #1
0x001cbd:	str     	r0, [sp, #0x58]
0x001cbf:	str     	r1, [sp]
0x001cc1:	str     	r1, [sp, #4]
0x001cc3:	movs    	r2, #0
0x001cc5:	str     	r2, [sp, #8]
0x001cc7:	movs    	r1, #0x38
0x001cc9:	movs    	r0, #0xf1
0x001ccb:	adds    	r3, r7, #0
0x001ccd:	lsls    	r0, r0, #9
0x001ccf:	ldr     	r2, [r6]
0x001cd1:	bl      	#0x5159
; block 0x1cd5
0x001cd5:	ldr     	r1, [sp, #0x58]
0x001cd7:	blx     	#0x20
; block 0x1cdb
0x001cdb:	str     	r1, [sp, #0x30]
0x001cdd:	movs    	r1, #0
0x001cdf:	movs    	r2, #0
0x001ce1:	str     	r1, [sp]
0x001ce3:	str     	r1, [sp, #4]
0x001ce5:	movs    	r3, #0
0x001ce7:	movs    	r1, #0x39
0x001ce9:	str     	r2, [sp, #8]
0x001ceb:	movs    	r0, #0xf1
0x001ced:	lsls    	r0, r0, #9
0x001cef:	add     	r2, sp, #0x20
0x001cf1:	str     	r3, [sp, #0x34]
0x001cf3:	bl      	#0x5159
; block 0x1cf7
0x001cf7:	adds    	r1, r4, #0
0x001cf9:	adds    	r1, #0x14
0x001cfb:	adds    	r0, r5, #0
0x001cfd:	adds    	r0, #0x46
0x001cff:	bl      	#0x2b59
; block 0x1d03
0x001d03:	ldr     	r0, [r6, #8]
0x001d05:	cmp     	r0, #3
0x001d07:	bne     	#0x1def
; block 0x1d09
0x001d09:	movs    	r1, #0
0x001d0b:	movs    	r2, #0
0x001d0d:	str     	r2, [sp, #8]
0x001d0f:	str     	r1, [sp]
0x001d11:	str     	r1, [sp, #4]
0x001d13:	movs    	r7, #0
0x001d15:	adds    	r3, r7, #0
0x001d17:	movs    	r1, #0xe1
0x001d19:	movs    	r2, #0x26
0x001d1b:	movs    	r0, #0xf1
0x001d1d:	lsls    	r0, r0, #9
0x001d1f:	bl      	#0x5159
; block 0x1d23
0x001d23:	str     	r0, [sp, #0x20]
0x001d25:	movs    	r1, #0
0x001d27:	movs    	r2, #0
0x001d29:	str     	r2, [sp, #8]
0x001d2b:	str     	r1, [sp]
0x001d2d:	str     	r1, [sp, #4]
0x001d2f:	movs    	r1, #0xe1
0x001d31:	movs    	r2, #0x27
0x001d33:	movs    	r0, #0xf1
0x001d35:	adds    	r3, r7, #0
0x001d37:	lsls    	r0, r0, #9
0x001d39:	bl      	#0x5159
; block 0x1d3d
0x001d3d:	lsrs    	r1, r0, #0x1f
0x001d3f:	adds    	r1, r1, r0
0x001d41:	asrs    	r1, r1, #1
0x001d43:	lsls    	r1, r1, #1
0x001d45:	subs    	r0, r0, r1
0x001d47:	adds    	r1, r5, #0
0x001d49:	subs    	r1, #0x1e
0x001d4b:	lsls    	r0, r0, #1
0x001d4d:	subs    	r0, r1, r0
0x001d4f:	str     	r0, [sp, #0x24]
0x001d51:	subs    	r0, r4, #6
0x001d53:	str     	r0, [sp, #0x28]
0x001d55:	adds    	r6, r0, #0
0x001d57:	str     	r1, [sp, #0x54]
0x001d59:	movs    	r0, #8
0x001d5b:	str     	r0, [sp, #0x2c]
0x001d5d:	movs    	r1, #0
0x001d5f:	movs    	r0, #0xe
0x001d61:	movs    	r2, #0
0x001d63:	str     	r0, [sp, #0x30]
0x001d65:	str     	r1, [sp]
0x001d67:	str     	r1, [sp, #4]
0x001d69:	movs    	r1, #0x22
0x001d6b:	movs    	r0, #0xf1
0x001d6d:	str     	r2, [sp, #8]
0x001d6f:	adds    	r3, r7, #0
0x001d71:	lsls    	r0, r0, #9
0x001d73:	add     	r2, sp, #0x20
0x001d75:	str     	r7, [sp, #0x34]
0x001d77:	bl      	#0x5159
; block 0x1d7b
0x001d7b:	movs    	r1, #0
0x001d7d:	movs    	r2, #0
0x001d7f:	str     	r2, [sp, #8]
0x001d81:	str     	r1, [sp]
0x001d83:	str     	r1, [sp, #4]
0x001d85:	movs    	r1, #0xe1
0x001d87:	movs    	r2, #0x27
0x001d89:	adds    	r3, r7, #0
0x001d8b:	movs    	r0, #0xf1
0x001d8d:	lsls    	r0, r0, #9
0x001d8f:	bl      	#0x5159
; block 0x1d93
0x001d93:	lsrs    	r1, r0, #0x1f
0x001d95:	adds    	r1, r1, r0
0x001d97:	asrs    	r1, r1, #1
0x001d99:	lsls    	r1, r1, #1
0x001d9b:	subs    	r0, r0, r1
0x001d9d:	ldr     	r1, [sp, #0x54]
0x001d9f:	lsls    	r0, r0, #1
0x001da1:	subs    	r3, r1, r0
0x001da3:	movs    	r1, #0x1e
0x001da5:	movs    	r2, #0x14
0x001da7:	str     	r2, [sp, #8]
0x001da9:	str     	r1, [sp, #4]
0x001dab:	movs    	r1, #0x23
0x001dad:	movs    	r2, #2
0x001daf:	subs    	r3, #0x14
0x001db1:	movs    	r0, #0xf1
0x001db3:	lsls    	r0, r0, #9
0x001db5:	str     	r6, [sp]
0x001db7:	bl      	#0x5159
; block 0x1dbb
0x001dbb:	movs    	r1, #0
0x001dbd:	movs    	r2, #0
0x001dbf:	str     	r2, [sp, #8]
0x001dc1:	str     	r1, [sp]
0x001dc3:	str     	r1, [sp, #4]
0x001dc5:	movs    	r1, #0xe1
0x001dc7:	movs    	r2, #0x26
0x001dc9:	adds    	r3, r7, #0
0x001dcb:	movs    	r0, #0xf1
0x001dcd:	lsls    	r0, r0, #9
0x001dcf:	bl      	#0x5159
; block 0x1dd3
0x001dd3:	str     	r0, [sp, #0x20]
0x001dd5:	movs    	r1, #0
0x001dd7:	movs    	r2, #0
0x001dd9:	str     	r2, [sp, #8]
0x001ddb:	str     	r1, [sp]
0x001ddd:	str     	r1, [sp, #4]
0x001ddf:	movs    	r1, #0xe1
0x001de1:	movs    	r2, #0x27
0x001de3:	movs    	r0, #0xf1
0x001de5:	adds    	r3, r7, #0
0x001de7:	lsls    	r0, r0, #9
0x001de9:	bl      	#0x5159
; block 0x1ded
0x001ded:	b       	#0x1df1
; block 0x1def
0x001def:	b       	#0x1e67
; block 0x1df1
0x001df1:	lsrs    	r1, r0, #0x1f
0x001df3:	adds    	r1, r1, r0
0x001df5:	asrs    	r1, r1, #1
0x001df7:	lsls    	r1, r1, #1
0x001df9:	subs    	r0, r0, r1
0x001dfb:	lsls    	r0, r0, #1
0x001dfd:	adds    	r0, r0, r5
0x001dff:	adds    	r0, #0x1e
0x001e01:	str     	r0, [sp, #0x24]
0x001e03:	movs    	r0, #8
0x001e05:	str     	r0, [sp, #0x2c]
0x001e07:	movs    	r0, #0xe
0x001e09:	str     	r0, [sp, #0x30]
0x001e0b:	movs    	r1, #0
0x001e0d:	movs    	r0, #1
0x001e0f:	movs    	r2, #0
0x001e11:	str     	r0, [sp, #0x34]
0x001e13:	str     	r1, [sp]
0x001e15:	str     	r1, [sp, #4]
0x001e17:	str     	r6, [sp, #0x28]
0x001e19:	str     	r2, [sp, #8]
0x001e1b:	movs    	r1, #0x22
0x001e1d:	movs    	r0, #0xf1
0x001e1f:	adds    	r3, r7, #0
0x001e21:	lsls    	r0, r0, #9
0x001e23:	add     	r2, sp, #0x20
0x001e25:	bl      	#0x5159
; block 0x1e29
0x001e29:	movs    	r1, #0
0x001e2b:	movs    	r2, #0
0x001e2d:	str     	r2, [sp, #8]
0x001e2f:	str     	r1, [sp]
0x001e31:	str     	r1, [sp, #4]
0x001e33:	movs    	r1, #0xe1
0x001e35:	movs    	r2, #0x27
0x001e37:	adds    	r3, r7, #0
0x001e39:	movs    	r0, #0xf1
0x001e3b:	lsls    	r0, r0, #9
0x001e3d:	bl      	#0x5159
; block 0x1e41
0x001e41:	lsrs    	r1, r0, #0x1f
0x001e43:	adds    	r1, r1, r0
0x001e45:	asrs    	r1, r1, #1
0x001e47:	lsls    	r1, r1, #1
0x001e49:	subs    	r0, r0, r1
0x001e4b:	lsls    	r0, r0, #1
0x001e4d:	adds    	r3, r0, r5
0x001e4f:	movs    	r1, #0x1e
0x001e51:	movs    	r2, #0x14
0x001e53:	str     	r2, [sp, #8]
0x001e55:	str     	r1, [sp, #4]
0x001e57:	movs    	r1, #0x23
0x001e59:	movs    	r2, #3
0x001e5b:	adds    	r3, #0x1e
0x001e5d:	movs    	r0, #0xf1
0x001e5f:	lsls    	r0, r0, #9
0x001e61:	str     	r6, [sp]
0x001e63:	bl      	#0x5159
; block 0x1e67
0x001e67:	movs    	r1, #0
0x001e69:	movs    	r5, #0xa
0x001e6b:	movs    	r2, #0
0x001e6d:	str     	r2, [sp, #8]
0x001e6f:	adds    	r4, r4, r5
0x001e71:	str     	r1, [sp]
0x001e73:	str     	r1, [sp, #4]
0x001e75:	movs    	r7, #0
0x001e77:	adds    	r3, r7, #0
0x001e79:	movs    	r1, #0xe1
0x001e7b:	movs    	r2, #0x24
0x001e7d:	movs    	r0, #0xf1
0x001e7f:	lsls    	r0, r0, #9
0x001e81:	bl      	#0x5159
; block 0x1e85
0x001e85:	ldr     	r6, [pc, #0x70]
0x001e87:	add     	r6, sb
0x001e89:	ldr     	r1, [r6, #0x1c]
0x001e8b:	lsls    	r1, r1, #2
0x001e8d:	ldr     	r0, [r0, r1]
0x001e8f:	ldrb    	r0, [r0, #0x14]
0x001e91:	cmp     	r0, #0
0x001e93:	bne     	#0x1e9b
; block 0x1e95
0x001e95:	ldr     	r3, [pc, #0x68]
0x001e97:	add     	r3, pc
0x001e99:	b       	#0x1e9f
; block 0x1e9b
0x001e9b:	ldr     	r3, [pc, #0x68]
0x001e9d:	add     	r3, pc
0x001e9f:	movs    	r2, #0
0x001ea1:	str     	r2, [sp, #8]
0x001ea3:	ldr     	r2, [pc, #0x64]
0x001ea5:	str     	r5, [sp]
0x001ea7:	str     	r4, [sp, #4]
0x001ea9:	add     	r2, pc
0x001eab:	movs    	r1, #0x3c
0x001ead:	movs    	r0, #0xf1
0x001eaf:	lsls    	r0, r0, #9
0x001eb1:	bl      	#0x5159
; block 0x1e9f
0x001e9f:	movs    	r2, #0
0x001ea1:	str     	r2, [sp, #8]
0x001ea3:	ldr     	r2, [pc, #0x64]
0x001ea5:	str     	r5, [sp]
0x001ea7:	str     	r4, [sp, #4]
0x001ea9:	add     	r2, pc
0x001eab:	movs    	r1, #0x3c
0x001ead:	movs    	r0, #0xf1
0x001eaf:	lsls    	r0, r0, #9
0x001eb1:	bl      	#0x5159
; block 0x1eb5
0x001eb5:	movs    	r1, #0
0x001eb7:	movs    	r2, #0
0x001eb9:	str     	r2, [sp, #8]
0x001ebb:	str     	r1, [sp]
0x001ebd:	str     	r1, [sp, #4]
0x001ebf:	movs    	r7, #0
0x001ec1:	adds    	r3, r7, #0
0x001ec3:	movs    	r1, #0xe1
0x001ec5:	movs    	r2, #0x24
0x001ec7:	movs    	r0, #0xf1
0x001ec9:	lsls    	r0, r0, #9
0x001ecb:	bl      	#0x5159
; block 0x1ecf
0x001ecf:	ldr     	r1, [pc, #0x28]
0x001ed1:	movs    	r3, #0x14
0x001ed3:	add     	r1, sb
0x001ed5:	ldr     	r1, [r1, #0x1c]
0x001ed7:	movs    	r2, #0
0x001ed9:	lsls    	r1, r1, #2
0x001edb:	ldr     	r0, [r0, r1]
0x001edd:	movs    	r1, #1
0x001edf:	ldrsb   	r6, [r0, r3]
0x001ee1:	str     	r1, [sp, #4]
0x001ee3:	str     	r2, [sp, #8]
0x001ee5:	adds    	r2, r6, #0
0x001ee7:	movs    	r1, #0x3d
0x001ee9:	movs    	r0, #0xf1
0x001eeb:	movs    	r3, #0x46
0x001eed:	lsls    	r0, r0, #9
0x001eef:	str     	r4, [sp]
0x001ef1:	bl      	#0x5159
; block 0x1ef5
0x001ef5:	b       	#0x1f0d
; block 0x1f0d
0x001f0d:	ldr     	r0, [sp, #0x4c]
0x001f0f:	movs    	r1, #0
0x001f11:	adds    	r3, r4, r0
0x001f13:	adds    	r4, r3, #5
0x001f15:	str     	r1, [sp]
0x001f17:	str     	r1, [sp, #4]
0x001f19:	movs    	r2, #0
0x001f1b:	movs    	r1, #0x1c
0x001f1d:	adds    	r3, r7, #0
0x001f1f:	movs    	r0, #0xf1
0x001f21:	lsls    	r0, r0, #9
0x001f23:	str     	r2, [sp, #8]
0x001f25:	bl      	#0x5159
; block 0x1f29
0x001f29:	adds    	r6, r0, #0
0x001f2b:	movs    	r1, #0
0x001f2d:	str     	r1, [sp]
0x001f2f:	str     	r1, [sp, #4]
0x001f31:	subs    	r6, #0x14
0x001f33:	movs    	r2, #0
0x001f35:	adds    	r3, r7, #0
0x001f37:	movs    	r1, #0x1d
0x001f39:	movs    	r0, #0xf1
0x001f3b:	lsls    	r0, r0, #9
0x001f3d:	str     	r2, [sp, #8]
0x001f3f:	bl      	#0x5159
; block 0x1f43
0x001f43:	subs    	r7, r0, r4
0x001f45:	subs    	r7, #0x28
0x001f47:	movs    	r2, #0
0x001f49:	str     	r2, [sp, #8]
0x001f4b:	adds    	r3, r4, #0
0x001f4d:	adds    	r2, r5, #0
0x001f4f:	movs    	r0, #0xf1
0x001f51:	movs    	r1, #0x2e
0x001f53:	lsls    	r0, r0, #9
0x001f55:	str     	r7, [sp, #4]
0x001f57:	str     	r6, [sp]
0x001f59:	bl      	#0x5159
; block 0x1f5d
0x001f5d:	ldr     	r1, [pc, #0x8c]
0x001f5f:	add     	r1, sb
0x001f61:	ldr     	r0, [r1, #0x44]
0x001f63:	cmp     	r0, #0
0x001f65:	bne     	#0x1fb3
; block 0x1f67
0x001f67:	movs    	r1, #0
0x001f69:	movs    	r2, #0
0x001f6b:	str     	r2, [sp, #8]
0x001f6d:	str     	r1, [sp]
0x001f6f:	str     	r1, [sp, #4]
0x001f71:	movs    	r1, #0xe1
0x001f73:	movs    	r2, #0x2c
0x001f75:	movs    	r3, #0
0x001f77:	movs    	r0, #0xf1
0x001f79:	lsls    	r0, r0, #9
0x001f7b:	bl      	#0x5159
; block 0x1f7f
0x001f7f:	ldr     	r1, [pc, #0x6c]
0x001f81:	movs    	r2, #0
0x001f83:	add     	r1, sb
0x001f85:	adds    	r1, #0x80
0x001f87:	ldr     	r1, [r1, #4]
0x001f89:	lsls    	r1, r1, #2
0x001f8b:	ldr     	r3, [r0, r1]
0x001f8d:	adds    	r0, r6, #0
0x001f8f:	subs    	r0, #0xa
0x001f91:	movs    	r1, #0
0x001f93:	mov     	ip, r0
0x001f95:	str     	r2, [sp, #8]
0x001f97:	adds    	r2, r3, #0
0x001f99:	str     	r1, [sp]
0x001f9b:	str     	r1, [sp, #4]
0x001f9d:	movs    	r1, #0x42
0x001f9f:	movs    	r0, #0xf1
0x001fa1:	lsls    	r0, r0, #9
0x001fa3:	mov     	r3, ip
0x001fa5:	bl      	#0x5159
; block 0x1fa9
0x001fa9:	ldr     	r1, [pc, #0x40]
0x001fab:	movs    	r3, #0
0x001fad:	add     	r1, sb
0x001faf:	str     	r0, [r1, #0x44]
0x001fb1:	str     	r3, [r1, #0x48]
0x001fb3:	ldr     	r1, [pc, #0x38]
0x001fb5:	add     	r3, sp, #0x20
0x001fb7:	add     	r1, sb
0x001fb9:	ldr     	r0, [r1, #0x44]
0x001fbb:	movs    	r2, #0
0x001fbd:	str     	r0, [sp, #0x1c]
0x001fbf:	ldr     	r0, [r1, #0x48]
0x001fc1:	str     	r7, [sp, #0x30]
0x001fc3:	str     	r0, [sp, #0x20]
0x001fc5:	movs    	r0, #1
0x001fc7:	str     	r5, [sp, #0x24]
0x001fc9:	str     	r4, [sp, #0x28]
0x001fcb:	str     	r6, [sp, #0x2c]
0x001fcd:	strb    	r0, [r3, #0x14]
0x001fcf:	movs    	r7, #0
0x001fd1:	strb    	r7, [r3, #0x15]
0x001fd3:	movs    	r1, #0
0x001fd5:	str     	r1, [sp]
0x001fd7:	str     	r1, [sp, #4]
0x001fd9:	movs    	r1, #0x43
0x001fdb:	str     	r2, [sp, #8]
0x001fdd:	adds    	r3, r7, #0
0x001fdf:	movs    	r0, #0xf1
0x001fe1:	lsls    	r0, r0, #9
0x001fe3:	add     	r2, sp, #0x1c
0x001fe5:	bl      	#0x5159
; block 0x1fb3
0x001fb3:	ldr     	r1, [pc, #0x38]
0x001fb5:	add     	r3, sp, #0x20
0x001fb7:	add     	r1, sb
0x001fb9:	ldr     	r0, [r1, #0x44]
0x001fbb:	movs    	r2, #0
0x001fbd:	str     	r0, [sp, #0x1c]
0x001fbf:	ldr     	r0, [r1, #0x48]
0x001fc1:	str     	r7, [sp, #0x30]
0x001fc3:	str     	r0, [sp, #0x20]
0x001fc5:	movs    	r0, #1
0x001fc7:	str     	r5, [sp, #0x24]
0x001fc9:	str     	r4, [sp, #0x28]
0x001fcb:	str     	r6, [sp, #0x2c]
0x001fcd:	strb    	r0, [r3, #0x14]
0x001fcf:	movs    	r7, #0
0x001fd1:	strb    	r7, [r3, #0x15]
0x001fd3:	movs    	r1, #0
0x001fd5:	str     	r1, [sp]
0x001fd7:	str     	r1, [sp, #4]
0x001fd9:	movs    	r1, #0x43
0x001fdb:	str     	r2, [sp, #8]
0x001fdd:	adds    	r3, r7, #0
0x001fdf:	movs    	r0, #0xf1
0x001fe1:	lsls    	r0, r0, #9
0x001fe3:	add     	r2, sp, #0x1c
0x001fe5:	bl      	#0x5159
; block 0x1fe9
0x001fe9:	add     	sp, #0x64
0x001feb:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_1fed @ 0x1fed offset=0x1fec size=4 blocks=1 cc=1 =====
; block 0x1fed
0x001fed:	movs    	r4, r1
0x001fef:	movs    	r0, r0
0x001ff1:	ldr     	r0, [pc, #0x3e0]
0x001ff3:	push    	{r4, r5, r6, lr}
0x001ff5:	add     	r0, sb
0x001ff7:	ldr     	r0, [r0, #0x5c]
0x001ff9:	movs    	r3, #0xa
0x001ffb:	ldrsh   	r5, [r0, r3]
0x001ffd:	sub     	sp, #0x58
0x001fff:	movs    	r1, #0
0x002001:	str     	r1, [sp]
0x002003:	str     	r1, [sp, #4]
0x002005:	movs    	r2, #0
0x002007:	movs    	r1, #0x1d
0x002009:	movs    	r0, #0xf1
0x00200b:	movs    	r3, #0
0x00200d:	adds    	r5, #0xa
0x00200f:	lsls    	r0, r0, #9
0x002011:	str     	r2, [sp, #8]
0x002013:	bl      	#0x5159

; ===== sub_1ff1 @ 0x1ff1 offset=0x1ff0 size=64 blocks=4 cc=2 =====
; block 0x1ff1
0x001ff1:	ldr     	r0, [pc, #0x3e0]
0x001ff3:	push    	{r4, r5, r6, lr}
0x001ff5:	add     	r0, sb
0x001ff7:	ldr     	r0, [r0, #0x5c]
0x001ff9:	movs    	r3, #0xa
0x001ffb:	ldrsh   	r5, [r0, r3]
0x001ffd:	sub     	sp, #0x58
0x001fff:	movs    	r1, #0
0x002001:	str     	r1, [sp]
0x002003:	str     	r1, [sp, #4]
0x002005:	movs    	r2, #0
0x002007:	movs    	r1, #0x1d
0x002009:	movs    	r0, #0xf1
0x00200b:	movs    	r3, #0
0x00200d:	adds    	r5, #0xa
0x00200f:	lsls    	r0, r0, #9
0x002011:	str     	r2, [sp, #8]
0x002013:	bl      	#0x5159
; block 0x2017
0x002017:	ldr     	r1, [pc, #0x3c0]
0x002019:	subs    	r0, r0, r5
0x00201b:	add     	r1, sb
0x00201d:	ldr     	r1, [r1]
0x00201f:	asrs    	r0, r0, #1
0x002021:	cmp     	r1, #0xb
0x002023:	bhs     	#0x202f
; block 0x2025
0x002025:	adr     	r3, #8
0x002027:	adds    	r3, r3, r1
0x002029:	ldrh    	r3, [r3, r1]
0x00202b:	lsls    	r3, r3, #1
0x00202d:	add     	pc, r3
; block 0x202f
0x00202f:	b       	#0x23a7

; ===== sub_2031 @ 0x2031 offset=0x2030 size=22 blocks=1 cc=1 =====
; block 0x2031
0x002031:	lsls    	r1, r7, #1
0x002033:	lsls    	r6, r0, #3
0x002035:	lsls    	r3, r2, #4
0x002037:	lsls    	r4, r1, #6
0x002039:	lsls    	r3, r7, #6
0x00203b:	lsls    	r3, r7, #6
0x00203d:	lsls    	r3, r7, #6
0x00203f:	lsls    	r3, r7, #6
0x002041:	lsls    	r3, r7, #6
0x002043:	movs    	r3, r1
0x002045:	movs    	r3, r1
0x002047:	movs    	r1, #0
0x002049:	str     	r1, [sp]
0x00204b:	str     	r1, [sp, #4]
0x00204d:	movs    	r2, #0
0x00204f:	movs    	r4, #0
0x002051:	movs    	r5, #0xf1
0x002053:	lsls    	r5, r5, #9
0x002055:	adds    	r3, r4, #0
0x002057:	movs    	r1, #0x1d
0x002059:	adds    	r0, r5, #0
0x00205b:	str     	r2, [sp, #8]
0x00205d:	bl      	#0x5159

; ===== sub_2047 @ 0x2047 offset=0x2046 size=220 blocks=10 cc=7 =====
; block 0x2047
0x002047:	movs    	r1, #0
0x002049:	str     	r1, [sp]
0x00204b:	str     	r1, [sp, #4]
0x00204d:	movs    	r2, #0
0x00204f:	movs    	r4, #0
0x002051:	movs    	r5, #0xf1
0x002053:	lsls    	r5, r5, #9
0x002055:	adds    	r3, r4, #0
0x002057:	movs    	r1, #0x1d
0x002059:	adds    	r0, r5, #0
0x00205b:	str     	r2, [sp, #8]
0x00205d:	bl      	#0x5159
; block 0x2061
0x002061:	movs    	r1, #0xff
0x002063:	adds    	r1, #0xe1
0x002065:	cmp     	r0, r1
0x002067:	bge     	#0x20c3
; block 0x2069
0x002069:	movs    	r1, #0
0x00206b:	str     	r1, [sp]
0x00206d:	str     	r1, [sp, #4]
0x00206f:	movs    	r2, #0
0x002071:	movs    	r1, #0x1d
0x002073:	adds    	r3, r4, #0
0x002075:	adds    	r0, r5, #0
0x002077:	str     	r2, [sp, #8]
0x002079:	bl      	#0x5159
; block 0x207d
0x00207d:	subs    	r0, #0xff
0x00207f:	subs    	r0, #0x41
0x002081:	lsrs    	r1, r0, #0x1f
0x002083:	adds    	r0, r1, r0
0x002085:	movs    	r1, #0
0x002087:	str     	r1, [sp]
0x002089:	str     	r1, [sp, #4]
0x00208b:	asrs    	r5, r0, #1
0x00208d:	movs    	r2, #0
0x00208f:	movs    	r0, #0xf1
0x002091:	movs    	r1, #0x1c
0x002093:	adds    	r3, r4, #0
0x002095:	lsls    	r0, r0, #9
0x002097:	str     	r2, [sp, #8]
0x002099:	bl      	#0x5159
; block 0x209d
0x00209d:	subs    	r0, #0xf0
0x00209f:	lsrs    	r1, r0, #0x1f
0x0020a1:	adds    	r0, r1, r0
0x0020a3:	asrs    	r0, r0, #1
0x0020a5:	str     	r0, [sp]
0x0020a7:	ldr     	r0, [pc, #0x32c]
0x0020a9:	movs    	r1, #0
0x0020ab:	movs    	r2, #0
0x0020ad:	add     	r0, sb
0x0020af:	adds    	r0, #0x24
0x0020b1:	str     	r2, [sp, #0x14]
0x0020b3:	str     	r2, [sp, #8]
0x0020b5:	str     	r1, [sp, #0xc]
0x0020b7:	str     	r1, [sp, #0x10]
0x0020b9:	str     	r5, [sp, #4]
0x0020bb:	ldm     	r0, {r0, r1, r2, r3}
0x0020bd:	bl      	#0x24cd
; block 0x20c1
0x0020c1:	b       	#0x23a7
; block 0x20c3
0x0020c3:	movs    	r1, #0
0x0020c5:	str     	r1, [sp]
0x0020c7:	str     	r1, [sp, #4]
0x0020c9:	movs    	r2, #0
0x0020cb:	movs    	r1, #0x1d
0x0020cd:	adds    	r3, r4, #0
0x0020cf:	adds    	r0, r5, #0
0x0020d1:	str     	r2, [sp, #8]
0x0020d3:	bl      	#0x5159
; block 0x20d7
0x0020d7:	subs    	r0, #0xff
0x0020d9:	subs    	r0, #0xe1
0x0020db:	lsrs    	r1, r0, #0x1f
0x0020dd:	adds    	r0, r1, r0
0x0020df:	movs    	r1, #0
0x0020e1:	str     	r1, [sp]
0x0020e3:	str     	r1, [sp, #4]
0x0020e5:	asrs    	r5, r0, #1
0x0020e7:	movs    	r2, #0
0x0020e9:	movs    	r0, #0xf1
0x0020eb:	movs    	r1, #0x1c
0x0020ed:	adds    	r3, r4, #0
0x0020ef:	lsls    	r0, r0, #9
0x0020f1:	str     	r2, [sp, #8]
0x0020f3:	bl      	#0x5159
; block 0x20f7
0x0020f7:	subs    	r0, #0xff
0x0020f9:	subs    	r0, #0x41
0x0020fb:	ldr     	r4, [pc, #0x2d8]
0x0020fd:	lsrs    	r1, r0, #0x1f
0x0020ff:	adds    	r0, r1, r0
0x002101:	add     	r4, sb
0x002103:	adds    	r4, #0x38
0x002105:	asrs    	r3, r0, #1
0x002107:	ldm     	r4!, {r0, r1, r2}
0x002109:	subs    	r4, #0x44
0x00210b:	str     	r0, [sp, #0xc]
0x00210d:	str     	r1, [sp, #0x10]
0x00210f:	str     	r2, [sp, #0x14]
0x002111:	ldr     	r2, [r4, #0x34]
0x002113:	str     	r3, [sp]
0x002115:	str     	r5, [sp, #4]
0x002117:	adds    	r4, #0x24
0x002119:	str     	r2, [sp, #8]
0x00211b:	ldm     	r4!, {r0, r1, r2, r3}
0x00211d:	bl      	#0x24cd
; block 0x2121
0x002121:	b       	#0x23a7

; ===== sub_2123 @ 0x2123 offset=0x2122 size=154 blocks=5 cc=4 =====
; block 0x2123
0x002123:	str     	r0, [sp, #0x40]
0x002125:	movs    	r1, #0
0x002127:	movs    	r4, #0
0x002129:	str     	r1, [sp]
0x00212b:	str     	r1, [sp, #4]
0x00212d:	movs    	r2, #0
0x00212f:	movs    	r1, #0x1c
0x002131:	adds    	r3, r4, #0
0x002133:	movs    	r0, #0xf1
0x002135:	lsls    	r0, r0, #9
0x002137:	str     	r2, [sp, #8]
0x002139:	str     	r4, [sp, #0x3c]
0x00213b:	bl      	#0x5159
; block 0x213f
0x00213f:	str     	r0, [sp, #0x44]
0x002141:	movs    	r1, #0
0x002143:	movs    	r2, #0
0x002145:	str     	r1, [sp]
0x002147:	str     	r1, [sp, #4]
0x002149:	str     	r5, [sp, #0x48]
0x00214b:	str     	r2, [sp, #8]
0x00214d:	movs    	r1, #0x1f
0x00214f:	movs    	r0, #0xf1
0x002151:	adds    	r3, r4, #0
0x002153:	lsls    	r0, r0, #9
0x002155:	add     	r2, sp, #0x3c
0x002157:	str     	r4, [sp, #0x4c]
0x002159:	str     	r4, [sp, #0x50]
0x00215b:	str     	r4, [sp, #0x54]
0x00215d:	bl      	#0x5159
; block 0x2161
0x002161:	ldr     	r5, [pc, #0x270]
0x002163:	movs    	r1, #0
0x002165:	add     	r5, sb
0x002167:	ldr     	r0, [r5, #0x58]
0x002169:	movs    	r2, #0
0x00216b:	str     	r0, [sp, #0x18]
0x00216d:	ldr     	r0, [r5, #0x60]
0x00216f:	str     	r1, [sp]
0x002171:	str     	r1, [sp, #4]
0x002173:	str     	r0, [sp, #0x1c]
0x002175:	movs    	r0, #0xf1
0x002177:	movs    	r1, #0x1d
0x002179:	adds    	r3, r4, #0
0x00217b:	lsls    	r0, r0, #9
0x00217d:	str     	r2, [sp, #8]
0x00217f:	bl      	#0x5159
; block 0x2183
0x002183:	ldr     	r1, [r5, #0x58]
0x002185:	movs    	r3, #0xa
0x002187:	ldrsh   	r2, [r1, r3]
0x002189:	str     	r4, [sp, #0x24]
0x00218b:	str     	r4, [sp, #0x28]
0x00218d:	subs    	r0, r0, r2
0x00218f:	asrs    	r0, r0, #1
0x002191:	str     	r0, [sp, #0x20]
0x002193:	movs    	r3, #8
0x002195:	ldrsh   	r0, [r1, r3]
0x002197:	movs    	r3, #0xa
0x002199:	movs    	r2, #0
0x00219b:	str     	r0, [sp, #0x2c]
0x00219d:	ldrsh   	r0, [r1, r3]
0x00219f:	movs    	r1, #0
0x0021a1:	str     	r1, [sp]
0x0021a3:	str     	r1, [sp, #4]
0x0021a5:	str     	r0, [sp, #0x30]
0x0021a7:	movs    	r0, #0xf1
0x0021a9:	movs    	r1, #0x20
0x0021ab:	str     	r2, [sp, #8]
0x0021ad:	adds    	r3, r4, #0
0x0021af:	lsls    	r0, r0, #9
0x0021b1:	add     	r2, sp, #0x18
0x0021b3:	str     	r4, [sp, #0x34]
0x0021b5:	str     	r4, [sp, #0x38]
0x0021b7:	bl      	#0x5159
; block 0x21bb
0x0021bb:	b       	#0x23a7

; ===== sub_21bd @ 0x21bd offset=0x21bc size=154 blocks=5 cc=4 =====
; block 0x21bd
0x0021bd:	str     	r0, [sp, #0x40]
0x0021bf:	movs    	r1, #0
0x0021c1:	movs    	r4, #0
0x0021c3:	str     	r1, [sp]
0x0021c5:	str     	r1, [sp, #4]
0x0021c7:	movs    	r2, #0
0x0021c9:	movs    	r1, #0x1c
0x0021cb:	adds    	r3, r4, #0
0x0021cd:	movs    	r0, #0xf1
0x0021cf:	lsls    	r0, r0, #9
0x0021d1:	str     	r2, [sp, #8]
0x0021d3:	str     	r4, [sp, #0x3c]
0x0021d5:	bl      	#0x5159
; block 0x21d9
0x0021d9:	str     	r0, [sp, #0x44]
0x0021db:	movs    	r1, #0
0x0021dd:	movs    	r2, #0
0x0021df:	str     	r1, [sp]
0x0021e1:	str     	r1, [sp, #4]
0x0021e3:	str     	r5, [sp, #0x48]
0x0021e5:	str     	r2, [sp, #8]
0x0021e7:	movs    	r1, #0x1f
0x0021e9:	movs    	r0, #0xf1
0x0021eb:	adds    	r3, r4, #0
0x0021ed:	lsls    	r0, r0, #9
0x0021ef:	add     	r2, sp, #0x3c
0x0021f1:	str     	r4, [sp, #0x4c]
0x0021f3:	str     	r4, [sp, #0x50]
0x0021f5:	str     	r4, [sp, #0x54]
0x0021f7:	bl      	#0x5159
; block 0x21fb
0x0021fb:	ldr     	r5, [pc, #0x1d8]
0x0021fd:	movs    	r1, #0
0x0021ff:	add     	r5, sb
0x002201:	ldr     	r0, [r5, #0x5c]
0x002203:	movs    	r2, #0
0x002205:	str     	r0, [sp, #0x18]
0x002207:	ldr     	r0, [r5, #0x64]
0x002209:	str     	r1, [sp]
0x00220b:	str     	r1, [sp, #4]
0x00220d:	str     	r0, [sp, #0x1c]
0x00220f:	movs    	r0, #0xf1
0x002211:	movs    	r1, #0x1d
0x002213:	adds    	r3, r4, #0
0x002215:	lsls    	r0, r0, #9
0x002217:	str     	r2, [sp, #8]
0x002219:	bl      	#0x5159
; block 0x221d
0x00221d:	ldr     	r1, [r5, #0x5c]
0x00221f:	movs    	r3, #0xa
0x002221:	ldrsh   	r2, [r1, r3]
0x002223:	str     	r4, [sp, #0x24]
0x002225:	str     	r4, [sp, #0x28]
0x002227:	subs    	r0, r0, r2
0x002229:	asrs    	r0, r0, #1
0x00222b:	str     	r0, [sp, #0x20]
0x00222d:	movs    	r3, #8
0x00222f:	ldrsh   	r0, [r1, r3]
0x002231:	movs    	r3, #0xa
0x002233:	movs    	r2, #0
0x002235:	str     	r0, [sp, #0x2c]
0x002237:	ldrsh   	r0, [r1, r3]
0x002239:	movs    	r1, #0
0x00223b:	str     	r1, [sp]
0x00223d:	str     	r1, [sp, #4]
0x00223f:	str     	r0, [sp, #0x30]
0x002241:	movs    	r0, #0xf1
0x002243:	movs    	r1, #0x20
0x002245:	str     	r2, [sp, #8]
0x002247:	adds    	r3, r4, #0
0x002249:	lsls    	r0, r0, #9
0x00224b:	add     	r2, sp, #0x18
0x00224d:	str     	r4, [sp, #0x34]
0x00224f:	str     	r4, [sp, #0x38]
0x002251:	bl      	#0x5159
; block 0x2255
0x002255:	b       	#0x23a7

; ===== sub_2257 @ 0x2257 offset=0x2256 size=242 blocks=7 cc=6 =====
; block 0x2257
0x002257:	str     	r0, [sp, #0x40]
0x002259:	movs    	r1, #0
0x00225b:	movs    	r4, #0
0x00225d:	str     	r1, [sp]
0x00225f:	str     	r1, [sp, #4]
0x002261:	movs    	r2, #0
0x002263:	movs    	r1, #0x1c
0x002265:	adds    	r3, r4, #0
0x002267:	movs    	r0, #0xf1
0x002269:	lsls    	r0, r0, #9
0x00226b:	str     	r2, [sp, #8]
0x00226d:	str     	r4, [sp, #0x3c]
0x00226f:	bl      	#0x5159
; block 0x2273
0x002273:	str     	r0, [sp, #0x44]
0x002275:	movs    	r1, #0
0x002277:	movs    	r2, #0
0x002279:	str     	r1, [sp]
0x00227b:	str     	r1, [sp, #4]
0x00227d:	str     	r5, [sp, #0x48]
0x00227f:	str     	r2, [sp, #8]
0x002281:	movs    	r1, #0x1f
0x002283:	movs    	r0, #0xf1
0x002285:	adds    	r3, r4, #0
0x002287:	lsls    	r0, r0, #9
0x002289:	add     	r2, sp, #0x3c
0x00228b:	str     	r4, [sp, #0x4c]
0x00228d:	str     	r4, [sp, #0x50]
0x00228f:	str     	r4, [sp, #0x54]
0x002291:	bl      	#0x5159
; block 0x2295
0x002295:	ldr     	r5, [pc, #0x13c]
0x002297:	movs    	r1, #0
0x002299:	add     	r5, sb
0x00229b:	ldr     	r0, [r5, #0x58]
0x00229d:	movs    	r2, #0
0x00229f:	str     	r0, [sp, #0x18]
0x0022a1:	ldr     	r0, [r5, #0x60]
0x0022a3:	str     	r1, [sp]
0x0022a5:	str     	r1, [sp, #4]
0x0022a7:	str     	r0, [sp, #0x1c]
0x0022a9:	movs    	r0, #0xf1
0x0022ab:	movs    	r1, #0x1d
0x0022ad:	adds    	r3, r4, #0
0x0022af:	lsls    	r0, r0, #9
0x0022b1:	str     	r2, [sp, #8]
0x0022b3:	bl      	#0x5159
; block 0x22b7
0x0022b7:	ldr     	r1, [r5, #0x58]
0x0022b9:	movs    	r3, #0xa
0x0022bb:	ldrsh   	r2, [r1, r3]
0x0022bd:	str     	r4, [sp, #0x24]
0x0022bf:	str     	r4, [sp, #0x28]
0x0022c1:	subs    	r0, r0, r2
0x0022c3:	asrs    	r0, r0, #1
0x0022c5:	str     	r0, [sp, #0x20]
0x0022c7:	movs    	r3, #8
0x0022c9:	ldrsh   	r0, [r1, r3]
0x0022cb:	movs    	r3, #0xa
0x0022cd:	movs    	r2, #0
0x0022cf:	str     	r0, [sp, #0x2c]
0x0022d1:	ldrsh   	r0, [r1, r3]
0x0022d3:	movs    	r1, #0
0x0022d5:	str     	r1, [sp]
0x0022d7:	str     	r1, [sp, #4]
0x0022d9:	str     	r2, [sp, #8]
0x0022db:	adds    	r3, r4, #0
0x0022dd:	add     	r6, sp, #0x18
0x0022df:	str     	r0, [sp, #0x30]
0x0022e1:	movs    	r0, #0xf1
0x0022e3:	adds    	r2, r6, #0
0x0022e5:	movs    	r1, #0x20
0x0022e7:	lsls    	r0, r0, #9
0x0022e9:	str     	r4, [sp, #0x34]
0x0022eb:	str     	r4, [sp, #0x38]
0x0022ed:	bl      	#0x5159
; block 0x22f1
0x0022f1:	ldr     	r0, [r5, #0x5c]
0x0022f3:	movs    	r1, #0
0x0022f5:	str     	r0, [sp, #0x18]
0x0022f7:	ldr     	r0, [r5, #0x64]
0x0022f9:	str     	r1, [sp]
0x0022fb:	str     	r1, [sp, #4]
0x0022fd:	movs    	r2, #0
0x0022ff:	str     	r0, [sp, #0x1c]
0x002301:	movs    	r0, #0xf1
0x002303:	movs    	r1, #0x1d
0x002305:	adds    	r3, r4, #0
0x002307:	lsls    	r0, r0, #9
0x002309:	str     	r2, [sp, #8]
0x00230b:	bl      	#0x5159
; block 0x230f
0x00230f:	ldr     	r1, [r5, #0x5c]
0x002311:	movs    	r3, #0xa
0x002313:	ldrsh   	r2, [r1, r3]
0x002315:	str     	r4, [sp, #0x24]
0x002317:	str     	r4, [sp, #0x28]
0x002319:	subs    	r0, r0, r2
0x00231b:	asrs    	r0, r0, #1
0x00231d:	str     	r0, [sp, #0x20]
0x00231f:	movs    	r3, #8
0x002321:	ldrsh   	r0, [r1, r3]
0x002323:	movs    	r3, #0xa
0x002325:	movs    	r2, #0
0x002327:	str     	r0, [sp, #0x2c]
0x002329:	ldrsh   	r0, [r1, r3]
0x00232b:	movs    	r1, #0
0x00232d:	str     	r1, [sp]
0x00232f:	str     	r1, [sp, #4]
0x002331:	str     	r2, [sp, #8]
0x002333:	adds    	r3, r4, #0
0x002335:	str     	r0, [sp, #0x30]
0x002337:	movs    	r0, #0xf1
0x002339:	adds    	r2, r6, #0
0x00233b:	movs    	r1, #0x20
0x00233d:	lsls    	r0, r0, #9
0x00233f:	str     	r4, [sp, #0x34]
0x002341:	str     	r4, [sp, #0x38]
0x002343:	bl      	#0x5159
; block 0x2347
0x002347:	b       	#0x23a7

; ===== sub_2349 @ 0x2349 offset=0x2348 size=94 blocks=3 cc=3 =====
; block 0x2349
0x002349:	movs    	r4, #0
0x00234b:	movs    	r1, #0
0x00234d:	str     	r4, [sp, #0x40]
0x00234f:	str     	r1, [sp]
0x002351:	str     	r1, [sp, #4]
0x002353:	movs    	r2, #0
0x002355:	movs    	r1, #0x1c
0x002357:	adds    	r3, r4, #0
0x002359:	movs    	r0, #0xf1
0x00235b:	lsls    	r0, r0, #9
0x00235d:	str     	r2, [sp, #8]
0x00235f:	str     	r4, [sp, #0x3c]
0x002361:	bl      	#0x5159
; block 0x2365
0x002365:	str     	r0, [sp, #0x44]
0x002367:	movs    	r1, #0
0x002369:	str     	r1, [sp]
0x00236b:	str     	r1, [sp, #4]
0x00236d:	movs    	r2, #0
0x00236f:	movs    	r1, #0x1d
0x002371:	movs    	r0, #0xf1
0x002373:	adds    	r3, r4, #0
0x002375:	lsls    	r0, r0, #9
0x002377:	str     	r2, [sp, #8]
0x002379:	bl      	#0x5159
; block 0x237d
0x00237d:	str     	r0, [sp, #0x48]
0x00237f:	ldr     	r0, [pc, #0x54]
0x002381:	movs    	r2, #0
0x002383:	add     	r0, sb
0x002385:	ldr     	r1, [r0, #0x6c]
0x002387:	adds    	r3, r4, #0
0x002389:	str     	r1, [sp, #0x4c]
0x00238b:	ldr     	r1, [r0, #0x70]
0x00238d:	str     	r1, [sp, #0x50]
0x00238f:	ldr     	r0, [r0, #0x74]
0x002391:	movs    	r1, #0
0x002393:	str     	r1, [sp]
0x002395:	str     	r1, [sp, #4]
0x002397:	str     	r0, [sp, #0x54]
0x002399:	movs    	r0, #0xf1
0x00239b:	movs    	r1, #0x1f
0x00239d:	str     	r2, [sp, #8]
0x00239f:	add     	r2, sp, #0x3c
0x0023a1:	lsls    	r0, r0, #9
0x0023a3:	bl      	#0x5159

; ===== sub_23a7 @ 0x23a7 offset=0x23a6 size=78 blocks=5 cc=3 =====
; block 0x23a7
0x0023a7:	movs    	r1, #0
0x0023a9:	str     	r1, [sp]
0x0023ab:	str     	r1, [sp, #4]
0x0023ad:	movs    	r2, #0
0x0023af:	movs    	r4, #0
0x0023b1:	adds    	r3, r4, #0
0x0023b3:	movs    	r1, #0x1d
0x0023b5:	movs    	r0, #0xf1
0x0023b7:	lsls    	r0, r0, #9
0x0023b9:	str     	r2, [sp, #8]
0x0023bb:	bl      	#0x5159
; block 0x23bf
0x0023bf:	movs    	r1, #0
0x0023c1:	adds    	r5, r0, #0
0x0023c3:	str     	r1, [sp]
0x0023c5:	str     	r1, [sp, #4]
0x0023c7:	movs    	r2, #0
0x0023c9:	movs    	r1, #0x1c
0x0023cb:	movs    	r0, #0xf1
0x0023cd:	adds    	r3, r4, #0
0x0023cf:	lsls    	r0, r0, #9
0x0023d1:	str     	r2, [sp, #8]
0x0023d3:	b       	#0x23dd
; block 0x23dd
0x0023dd:	bl      	#0x5159
; block 0x23e1
0x0023e1:	adds    	r1, r0, #0
0x0023e3:	movs    	r0, #0
0x0023e5:	str     	r0, [sp]
0x0023e7:	str     	r1, [sp, #4]
0x0023e9:	movs    	r1, #0x23
0x0023eb:	movs    	r0, #0xf1
0x0023ed:	adds    	r3, r4, #0
0x0023ef:	movs    	r2, #4
0x0023f1:	lsls    	r0, r0, #9
0x0023f3:	str     	r5, [sp, #8]
0x0023f5:	bl      	#0x5159
; block 0x23f9
0x0023f9:	add     	sp, #0x58
0x0023fb:	pop     	{r4, r5, r6, pc}

; ===== sub_23d5 @ 0x23d5 offset=0x23d4 size=8 blocks=1 cc=1 =====
; block 0x23d5
0x0023d5:	movs    	r4, r1
0x0023d7:	movs    	r0, r0
0x0023d9:	movs    	r4, r0
0x0023db:	movs    	r0, r0
0x0023dd:	bl      	#0x5159

; ===== sub_23fd @ 0x23fd offset=0x23fc size=200 blocks=7 cc=5 =====
; block 0x23fd
0x0023fd:	push    	{r4, r5, r6, r7, lr}
0x0023ff:	ldr     	r6, [pc, #0xc4]
0x002401:	adds    	r5, r1, #0
0x002403:	add     	r6, sb
0x002405:	ldr     	r4, [r6]
0x002407:	sub     	sp, #0x34
0x002409:	cmp     	r4, #0
0x00240b:	bne     	#0x2429
; block 0x240d
0x00240d:	movs    	r2, #0
0x00240f:	mvns    	r1, r2
0x002411:	ldr     	r3, [pc, #0xb4]
0x002413:	str     	r1, [sp]
0x002415:	str     	r1, [sp, #4]
0x002417:	str     	r2, [sp, #8]
0x002419:	add     	r3, pc
0x00241b:	adds    	r2, r4, #0
0x00241d:	movs    	r1, #5
0x00241f:	movs    	r0, #0xf1
0x002421:	lsls    	r0, r0, #9
0x002423:	bl      	#0x5159
; block 0x2427
0x002427:	str     	r0, [r6]
0x002429:	ldr     	r0, [r6]
0x00242b:	movs    	r3, #8
0x00242d:	ldrsh   	r0, [r0, r3]
0x00242f:	movs    	r1, #0
0x002431:	str     	r1, [sp]
0x002433:	str     	r1, [sp, #4]
0x002435:	movs    	r2, #0
0x002437:	movs    	r4, #0
0x002439:	lsls    	r7, r0, #1
0x00243b:	movs    	r0, #0xf1
0x00243d:	adds    	r3, r4, #0
0x00243f:	movs    	r1, #0x1c
0x002441:	lsls    	r0, r0, #9
0x002443:	str     	r2, [sp, #8]
0x002445:	bl      	#0x5159
; block 0x2429
0x002429:	ldr     	r0, [r6]
0x00242b:	movs    	r3, #8
0x00242d:	ldrsh   	r0, [r0, r3]
0x00242f:	movs    	r1, #0
0x002431:	str     	r1, [sp]
0x002433:	str     	r1, [sp, #4]
0x002435:	movs    	r2, #0
0x002437:	movs    	r4, #0
0x002439:	lsls    	r7, r0, #1
0x00243b:	movs    	r0, #0xf1
0x00243d:	adds    	r3, r4, #0
0x00243f:	movs    	r1, #0x1c
0x002441:	lsls    	r0, r0, #9
0x002443:	str     	r2, [sp, #8]
0x002445:	bl      	#0x5159
; block 0x2449
0x002449:	subs    	r0, r0, r7
0x00244b:	lsrs    	r1, r0, #0x1f
0x00244d:	adds    	r0, r1, r0
0x00244f:	asrs    	r7, r0, #1
0x002451:	ldr     	r0, [r6]
0x002453:	str     	r7, [sp, #0x14]
0x002455:	str     	r5, [sp, #0x18]
0x002457:	str     	r4, [sp, #0x1c]
0x002459:	str     	r4, [sp, #0x20]
0x00245b:	movs    	r3, #8
0x00245d:	str     	r0, [sp, #0x10]
0x00245f:	ldrsh   	r1, [r0, r3]
0x002461:	movs    	r3, #0xa
0x002463:	movs    	r2, #0
0x002465:	str     	r1, [sp, #0x24]
0x002467:	ldrsh   	r0, [r0, r3]
0x002469:	movs    	r1, #0
0x00246b:	str     	r1, [sp]
0x00246d:	str     	r0, [sp, #0x28]
0x00246f:	str     	r1, [sp, #4]
0x002471:	movs    	r1, #0x20
0x002473:	str     	r2, [sp, #8]
0x002475:	movs    	r0, #0xf1
0x002477:	adds    	r3, r4, #0
0x002479:	lsls    	r0, r0, #9
0x00247b:	add     	r2, sp, #0x10
0x00247d:	str     	r4, [sp, #0x2c]
0x00247f:	str     	r4, [sp, #0x30]
0x002481:	bl      	#0x5159
; block 0x2485
0x002485:	ldr     	r0, [r6]
0x002487:	movs    	r3, #8
0x002489:	str     	r0, [sp, #0x10]
0x00248b:	ldrsh   	r1, [r0, r3]
0x00248d:	str     	r5, [sp, #0x18]
0x00248f:	str     	r4, [sp, #0x1c]
0x002491:	adds    	r1, r1, r7
0x002493:	str     	r1, [sp, #0x14]
0x002495:	str     	r4, [sp, #0x20]
0x002497:	ldrsh   	r1, [r0, r3]
0x002499:	movs    	r3, #0xa
0x00249b:	movs    	r2, #0
0x00249d:	str     	r1, [sp, #0x24]
0x00249f:	ldrsh   	r0, [r0, r3]
0x0024a1:	movs    	r1, #0
0x0024a3:	str     	r1, [sp]
0x0024a5:	str     	r0, [sp, #0x28]
0x0024a7:	movs    	r0, #0xff
0x0024a9:	adds    	r0, #1
0x0024ab:	str     	r0, [sp, #0x2c]
0x0024ad:	str     	r1, [sp, #4]
0x0024af:	movs    	r1, #0x20
0x0024b1:	movs    	r0, #0xf1
0x0024b3:	adds    	r3, r4, #0
0x0024b5:	str     	r2, [sp, #8]
0x0024b7:	add     	r2, sp, #0x10
0x0024b9:	lsls    	r0, r0, #9
0x0024bb:	str     	r4, [sp, #0x30]
0x0024bd:	bl      	#0x5159
; block 0x24c1
0x0024c1:	add     	sp, #0x34
0x0024c3:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_24cd @ 0x24cd offset=0x24cc size=922 blocks=25 cc=19 =====
; block 0x24cd
0x0024cd:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0024cf:	adds    	r4, r0, #0
0x0024d1:	adds    	r7, r1, #0
0x0024d3:	sub     	sp, #0x34
0x0024d5:	movs    	r1, #0
0x0024d7:	movs    	r2, #0
0x0024d9:	movs    	r0, #0
0x0024db:	ldr     	r5, [sp, #0x58]
0x0024dd:	ldr     	r6, [sp, #0x5c]
0x0024df:	bl      	#0x5109
; block 0x24e3
0x0024e3:	cmp     	r4, #0
0x0024e5:	beq     	#0x24f7
; block 0x24e7
0x0024e7:	cmp     	r7, #0
0x0024e9:	beq     	#0x24f7
; block 0x24eb
0x0024eb:	ldr     	r0, [sp, #0x3c]
0x0024ed:	cmp     	r0, #0
0x0024ef:	beq     	#0x24f7
; block 0x24f1
0x0024f1:	ldr     	r0, [sp, #0x40]
0x0024f3:	cmp     	r0, #0
0x0024f5:	bne     	#0x2505
; block 0x24f7
0x0024f7:	movs    	r2, #0x64
0x0024f9:	movs    	r1, #0x64
0x0024fb:	movs    	r0, #0x64
0x0024fd:	bl      	#0x5109
; block 0x2501
0x002501:	add     	sp, #0x44
0x002503:	pop     	{r4, r5, r6, r7, pc}
; block 0x2505
0x002505:	movs    	r1, #0
0x002507:	str     	r1, [sp]
0x002509:	str     	r1, [sp, #4]
0x00250b:	movs    	r2, #0
0x00250d:	movs    	r1, #0x1d
0x00250f:	movs    	r3, #0
0x002511:	movs    	r0, #0xf1
0x002513:	lsls    	r0, r0, #9
0x002515:	str     	r2, [sp, #8]
0x002517:	bl      	#0x5159
; block 0x251b
0x00251b:	movs    	r2, #0xff
0x00251d:	adds    	r2, #0xe1
0x00251f:	movs    	r1, #2
0x002521:	cmp     	r0, r2
0x002523:	bge     	#0x2609
; block 0x2525
0x002525:	ldr     	r0, [sp, #0x40]
0x002527:	movs    	r3, #8
0x002529:	ldr     	r0, [r0, #4]
0x00252b:	movs    	r2, #0
0x00252d:	str     	r0, [sp, #0x10]
0x00252f:	ldrsh   	r0, [r4, r3]
0x002531:	movs    	r3, #0xa
0x002533:	adds    	r0, r0, r5
0x002535:	str     	r0, [sp, #0x14]
0x002537:	ldrsh   	r0, [r7, r3]
0x002539:	movs    	r3, #8
0x00253b:	adds    	r0, r0, r6
0x00253d:	str     	r0, [sp, #0x18]
0x00253f:	ldr     	r0, [sp, #0x40]
0x002541:	ldrsh   	r0, [r0, r3]
0x002543:	str     	r0, [sp, #0x1c]
0x002545:	ldr     	r0, [sp, #0x40]
0x002547:	ldrsh   	r0, [r0, r3]
0x002549:	movs    	r3, #0xa
0x00254b:	str     	r0, [sp, #0x20]
0x00254d:	ldr     	r0, [sp, #0x40]
0x00254f:	ldrsh   	r0, [r0, r3]
0x002551:	str     	r1, [sp, #0x28]
0x002553:	movs    	r1, #0
0x002555:	str     	r0, [sp, #0x24]
0x002557:	movs    	r3, #0
0x002559:	str     	r1, [sp, #4]
0x00255b:	str     	r1, [sp]
0x00255d:	movs    	r1, #0x1e
0x00255f:	movs    	r0, #0xf1
0x002561:	str     	r2, [sp, #8]
0x002563:	add     	r2, sp, #0x10
0x002565:	lsls    	r0, r0, #9
0x002567:	str     	r3, [sp, #0x2c]
0x002569:	str     	r3, [sp, #0x30]
0x00256b:	bl      	#0x5159
; block 0x256f
0x00256f:	ldr     	r0, [sp, #0x3c]
0x002571:	movs    	r3, #0xa
0x002573:	ldr     	r0, [r0, #4]
0x002575:	str     	r5, [sp, #0x14]
0x002577:	str     	r0, [sp, #0x10]
0x002579:	ldrsh   	r0, [r4, r3]
0x00257b:	movs    	r3, #8
0x00257d:	movs    	r1, #2
0x00257f:	adds    	r0, r0, r6
0x002581:	str     	r0, [sp, #0x18]
0x002583:	ldr     	r0, [sp, #0x3c]
0x002585:	movs    	r2, #0
0x002587:	ldrsh   	r0, [r0, r3]
0x002589:	str     	r0, [sp, #0x1c]
0x00258b:	ldr     	r0, [sp, #0x3c]
0x00258d:	ldrsh   	r0, [r0, r3]
0x00258f:	movs    	r3, #0xa
0x002591:	str     	r0, [sp, #0x20]
0x002593:	ldr     	r0, [sp, #0x3c]
0x002595:	ldrsh   	r0, [r0, r3]
0x002597:	str     	r1, [sp, #0x28]
0x002599:	movs    	r1, #0
0x00259b:	str     	r0, [sp, #0x24]
0x00259d:	movs    	r3, #0
0x00259f:	str     	r1, [sp, #4]
0x0025a1:	str     	r1, [sp]
0x0025a3:	movs    	r1, #0x1e
0x0025a5:	movs    	r0, #0xf1
0x0025a7:	str     	r2, [sp, #8]
0x0025a9:	add     	r2, sp, #0x10
0x0025ab:	lsls    	r0, r0, #9
0x0025ad:	str     	r3, [sp, #0x2c]
0x0025af:	str     	r3, [sp, #0x30]
0x0025b1:	bl      	#0x5159
; block 0x25b5
0x0025b5:	ldr     	r0, [r4, #4]
0x0025b7:	str     	r5, [sp, #0x14]
0x0025b9:	str     	r6, [sp, #0x18]
0x0025bb:	movs    	r3, #8
0x0025bd:	str     	r0, [sp, #0x10]
0x0025bf:	ldrsh   	r0, [r4, r3]
0x0025c1:	movs    	r1, #2
0x0025c3:	movs    	r2, #0
0x0025c5:	str     	r0, [sp, #0x1c]
0x0025c7:	ldrsh   	r0, [r4, r3]
0x0025c9:	movs    	r3, #0xa
0x0025cb:	str     	r0, [sp, #0x20]
0x0025cd:	ldrsh   	r0, [r4, r3]
0x0025cf:	str     	r1, [sp, #0x28]
0x0025d1:	movs    	r1, #0
0x0025d3:	str     	r0, [sp, #0x24]
0x0025d5:	movs    	r3, #0
0x0025d7:	str     	r1, [sp, #4]
0x0025d9:	str     	r1, [sp]
0x0025db:	movs    	r1, #0x1e
0x0025dd:	movs    	r0, #0xf1
0x0025df:	str     	r2, [sp, #8]
0x0025e1:	add     	r2, sp, #0x10
0x0025e3:	lsls    	r0, r0, #9
0x0025e5:	str     	r3, [sp, #0x2c]
0x0025e7:	str     	r3, [sp, #0x30]
0x0025e9:	bl      	#0x5159
; block 0x25ed
0x0025ed:	ldr     	r0, [r7, #4]
0x0025ef:	movs    	r3, #8
0x0025f1:	str     	r0, [sp, #0x10]
0x0025f3:	ldrsh   	r0, [r4, r3]
0x0025f5:	str     	r6, [sp, #0x18]
0x0025f7:	adds    	r0, r0, r5
0x0025f9:	str     	r0, [sp, #0x14]
0x0025fb:	ldrsh   	r0, [r7, r3]
0x0025fd:	str     	r0, [sp, #0x1c]
0x0025ff:	ldrsh   	r0, [r7, r3]
0x002601:	movs    	r3, #0xa
0x002603:	str     	r0, [sp, #0x20]
0x002605:	ldrsh   	r0, [r7, r3]
0x002607:	b       	#0x260b
; block 0x2609
0x002609:	b       	#0x262f
; block 0x260b
0x00260b:	movs    	r1, #2
0x00260d:	str     	r1, [sp, #0x28]
0x00260f:	movs    	r1, #0
0x002611:	str     	r0, [sp, #0x24]
0x002613:	movs    	r3, #0
0x002615:	movs    	r2, #0
0x002617:	str     	r1, [sp, #4]
0x002619:	str     	r1, [sp]
0x00261b:	movs    	r1, #0x1e
0x00261d:	str     	r2, [sp, #8]
0x00261f:	movs    	r0, #0xf1
0x002621:	lsls    	r0, r0, #9
0x002623:	add     	r2, sp, #0x10
0x002625:	str     	r3, [sp, #0x2c]
0x002627:	str     	r3, [sp, #0x30]
0x002629:	bl      	#0x5159
; block 0x262d
0x00262d:	b       	#0x2501
; block 0x262f
0x00262f:	ldr     	r0, [r4, #4]
0x002631:	str     	r5, [sp, #0x14]
0x002633:	str     	r6, [sp, #0x18]
0x002635:	movs    	r3, #8
0x002637:	str     	r0, [sp, #0x10]
0x002639:	ldrsh   	r0, [r4, r3]
0x00263b:	movs    	r1, #2
0x00263d:	movs    	r2, #0
0x00263f:	str     	r0, [sp, #0x1c]
0x002641:	ldrsh   	r0, [r4, r3]
0x002643:	movs    	r3, #0xa
0x002645:	str     	r0, [sp, #0x20]
0x002647:	ldrsh   	r0, [r4, r3]
0x002649:	str     	r1, [sp, #0x28]
0x00264b:	movs    	r1, #0
0x00264d:	str     	r0, [sp, #0x24]
0x00264f:	movs    	r3, #0
0x002651:	str     	r1, [sp, #4]
0x002653:	str     	r1, [sp]
0x002655:	movs    	r1, #0x1e
0x002657:	movs    	r0, #0xf1
0x002659:	str     	r2, [sp, #8]
0x00265b:	add     	r2, sp, #0x10
0x00265d:	lsls    	r0, r0, #9
0x00265f:	str     	r3, [sp, #0x2c]
0x002661:	str     	r3, [sp, #0x30]
0x002663:	bl      	#0x5159
; block 0x2667
0x002667:	ldr     	r0, [r7, #4]
0x002669:	movs    	r3, #8
0x00266b:	str     	r0, [sp, #0x10]
0x00266d:	ldrsh   	r0, [r4, r3]
0x00266f:	str     	r6, [sp, #0x18]
0x002671:	movs    	r1, #2
0x002673:	adds    	r0, r0, r5
0x002675:	str     	r0, [sp, #0x14]
0x002677:	ldrsh   	r0, [r7, r3]
0x002679:	movs    	r2, #0
0x00267b:	str     	r0, [sp, #0x1c]
0x00267d:	ldrsh   	r0, [r7, r3]
0x00267f:	movs    	r3, #0xa
0x002681:	str     	r0, [sp, #0x20]
0x002683:	ldrsh   	r0, [r7, r3]
0x002685:	str     	r1, [sp, #0x28]
0x002687:	movs    	r1, #0
0x002689:	str     	r0, [sp, #0x24]
0x00268b:	movs    	r3, #0
0x00268d:	str     	r1, [sp, #4]
0x00268f:	str     	r1, [sp]
0x002691:	movs    	r1, #0x1e
0x002693:	movs    	r0, #0xf1
0x002695:	str     	r2, [sp, #8]
0x002697:	add     	r2, sp, #0x10
0x002699:	lsls    	r0, r0, #9
0x00269b:	str     	r3, [sp, #0x2c]
0x00269d:	str     	r3, [sp, #0x30]
0x00269f:	bl      	#0x5159
; block 0x26a3
0x0026a3:	ldr     	r0, [sp, #0x3c]
0x0026a5:	movs    	r3, #0xa
0x0026a7:	ldr     	r0, [r0, #4]
0x0026a9:	str     	r5, [sp, #0x14]
0x0026ab:	str     	r0, [sp, #0x10]
0x0026ad:	ldrsh   	r0, [r4, r3]
0x0026af:	movs    	r3, #8
0x0026b1:	movs    	r1, #2
0x0026b3:	adds    	r0, r0, r6
0x0026b5:	str     	r0, [sp, #0x18]
0x0026b7:	ldr     	r0, [sp, #0x3c]
0x0026b9:	movs    	r2, #0
0x0026bb:	ldrsh   	r0, [r0, r3]
0x0026bd:	str     	r0, [sp, #0x1c]
0x0026bf:	ldr     	r0, [sp, #0x3c]
0x0026c1:	ldrsh   	r0, [r0, r3]
0x0026c3:	movs    	r3, #0xa
0x0026c5:	str     	r0, [sp, #0x20]
0x0026c7:	ldr     	r0, [sp, #0x3c]
0x0026c9:	ldrsh   	r0, [r0, r3]
0x0026cb:	str     	r1, [sp, #0x28]
0x0026cd:	movs    	r1, #0
0x0026cf:	str     	r0, [sp, #0x24]
0x0026d1:	movs    	r3, #0
0x0026d3:	str     	r1, [sp, #4]
0x0026d5:	str     	r1, [sp]
0x0026d7:	movs    	r1, #0x1e
0x0026d9:	movs    	r0, #0xf1
0x0026db:	str     	r2, [sp, #8]
0x0026dd:	add     	r2, sp, #0x10
0x0026df:	lsls    	r0, r0, #9
0x0026e1:	str     	r3, [sp, #0x2c]
0x0026e3:	str     	r3, [sp, #0x30]
0x0026e5:	bl      	#0x5159
; block 0x26e9
0x0026e9:	ldr     	r0, [sp, #0x40]
0x0026eb:	movs    	r3, #8
0x0026ed:	ldr     	r0, [r0, #4]
0x0026ef:	movs    	r1, #2
0x0026f1:	str     	r0, [sp, #0x10]
0x0026f3:	ldrsh   	r0, [r4, r3]
0x0026f5:	movs    	r3, #0xa
0x0026f7:	movs    	r2, #0
0x0026f9:	adds    	r0, r0, r5
0x0026fb:	str     	r0, [sp, #0x14]
0x0026fd:	ldrsh   	r0, [r4, r3]
0x0026ff:	movs    	r3, #8
0x002701:	adds    	r0, r0, r6
0x002703:	str     	r0, [sp, #0x18]
0x002705:	ldr     	r0, [sp, #0x40]
0x002707:	ldrsh   	r0, [r0, r3]
0x002709:	str     	r0, [sp, #0x1c]
0x00270b:	ldr     	r0, [sp, #0x40]
0x00270d:	ldrsh   	r0, [r0, r3]
0x00270f:	movs    	r3, #0xa
0x002711:	str     	r0, [sp, #0x20]
0x002713:	ldr     	r0, [sp, #0x40]
0x002715:	ldrsh   	r0, [r0, r3]
0x002717:	str     	r1, [sp, #0x28]
0x002719:	movs    	r1, #0
0x00271b:	str     	r0, [sp, #0x24]
0x00271d:	movs    	r3, #0
0x00271f:	str     	r1, [sp, #4]
0x002721:	str     	r1, [sp]
0x002723:	movs    	r1, #0x1e
0x002725:	movs    	r0, #0xf1
0x002727:	str     	r2, [sp, #8]
0x002729:	add     	r2, sp, #0x10
0x00272b:	lsls    	r0, r0, #9
0x00272d:	str     	r3, [sp, #0x2c]
0x00272f:	str     	r3, [sp, #0x30]
0x002731:	bl      	#0x5159
; block 0x2735
0x002735:	ldr     	r0, [sp, #0x60]
0x002737:	movs    	r3, #0xa
0x002739:	ldr     	r0, [r0, #4]
0x00273b:	str     	r5, [sp, #0x14]
0x00273d:	str     	r0, [sp, #0x10]
0x00273f:	ldrsh   	r0, [r4, r3]
0x002741:	movs    	r3, #8
0x002743:	movs    	r1, #2
0x002745:	lsls    	r0, r0, #1
0x002747:	adds    	r0, r0, r6
0x002749:	str     	r0, [sp, #0x18]
0x00274b:	ldr     	r0, [sp, #0x60]
0x00274d:	movs    	r2, #0
0x00274f:	ldrsh   	r0, [r0, r3]
0x002751:	str     	r0, [sp, #0x1c]
0x002753:	ldr     	r0, [sp, #0x60]
0x002755:	ldrsh   	r0, [r0, r3]
0x002757:	movs    	r3, #0xa
0x002759:	str     	r0, [sp, #0x20]
0x00275b:	ldr     	r0, [sp, #0x60]
0x00275d:	ldrsh   	r0, [r0, r3]
0x00275f:	str     	r1, [sp, #0x28]
0x002761:	movs    	r1, #0
0x002763:	str     	r0, [sp, #0x24]
0x002765:	movs    	r3, #0
0x002767:	str     	r1, [sp, #4]
0x002769:	str     	r1, [sp]
0x00276b:	movs    	r1, #0x1e
0x00276d:	movs    	r0, #0xf1
0x00276f:	str     	r2, [sp, #8]
0x002771:	add     	r2, sp, #0x10
0x002773:	lsls    	r0, r0, #9
0x002775:	str     	r3, [sp, #0x2c]
0x002777:	str     	r3, [sp, #0x30]
0x002779:	bl      	#0x5159
; block 0x277d
0x00277d:	ldr     	r0, [sp, #0x64]
0x00277f:	movs    	r3, #8
0x002781:	ldr     	r0, [r0, #4]
0x002783:	movs    	r1, #2
0x002785:	str     	r0, [sp, #0x10]
0x002787:	ldrsh   	r0, [r4, r3]
0x002789:	movs    	r3, #0xa
0x00278b:	movs    	r2, #0
0x00278d:	adds    	r0, r0, r5
0x00278f:	str     	r0, [sp, #0x14]
0x002791:	ldrsh   	r0, [r4, r3]
0x002793:	movs    	r3, #8
0x002795:	lsls    	r0, r0, #1
0x002797:	adds    	r0, r0, r6
0x002799:	str     	r0, [sp, #0x18]
0x00279b:	ldr     	r0, [sp, #0x64]
0x00279d:	ldrsh   	r0, [r0, r3]
0x00279f:	str     	r0, [sp, #0x1c]
0x0027a1:	ldr     	r0, [sp, #0x64]
0x0027a3:	ldrsh   	r0, [r0, r3]
0x0027a5:	movs    	r3, #0xa
0x0027a7:	str     	r0, [sp, #0x20]
0x0027a9:	ldr     	r0, [sp, #0x64]
0x0027ab:	ldrsh   	r0, [r0, r3]
0x0027ad:	str     	r1, [sp, #0x28]
0x0027af:	movs    	r1, #0
0x0027b1:	str     	r0, [sp, #0x24]
0x0027b3:	movs    	r3, #0
0x0027b5:	str     	r1, [sp, #4]
0x0027b7:	str     	r1, [sp]
0x0027b9:	movs    	r1, #0x1e
0x0027bb:	movs    	r0, #0xf1
0x0027bd:	str     	r2, [sp, #8]
0x0027bf:	add     	r2, sp, #0x10
0x0027c1:	lsls    	r0, r0, #9
0x0027c3:	str     	r3, [sp, #0x2c]
0x0027c5:	str     	r3, [sp, #0x30]
0x0027c7:	bl      	#0x5159
; block 0x27cb
0x0027cb:	ldr     	r0, [sp, #0x68]
0x0027cd:	movs    	r3, #0xa
0x0027cf:	ldr     	r0, [r0, #4]
0x0027d1:	str     	r5, [sp, #0x14]
0x0027d3:	str     	r0, [sp, #0x10]
0x0027d5:	ldrsh   	r0, [r4, r3]
0x0027d7:	movs    	r1, #2
0x0027d9:	movs    	r2, #0
0x0027db:	lsls    	r3, r0, #1
0x0027dd:	adds    	r0, r3, r0
0x0027df:	adds    	r0, r0, r6
0x0027e1:	str     	r0, [sp, #0x18]
0x0027e3:	ldr     	r0, [sp, #0x68]
0x0027e5:	movs    	r3, #8
0x0027e7:	ldrsh   	r0, [r0, r3]
0x0027e9:	str     	r0, [sp, #0x1c]
0x0027eb:	ldr     	r0, [sp, #0x68]
0x0027ed:	ldrsh   	r0, [r0, r3]
0x0027ef:	movs    	r3, #0xa
0x0027f1:	str     	r0, [sp, #0x20]
0x0027f3:	ldr     	r0, [sp, #0x68]
0x0027f5:	ldrsh   	r0, [r0, r3]
0x0027f7:	str     	r1, [sp, #0x28]
0x0027f9:	movs    	r1, #0
0x0027fb:	str     	r0, [sp, #0x24]
0x0027fd:	movs    	r3, #0
0x0027ff:	str     	r1, [sp, #4]
0x002801:	str     	r1, [sp]
0x002803:	movs    	r1, #0x1e
0x002805:	movs    	r0, #0xf1
0x002807:	str     	r2, [sp, #8]
0x002809:	add     	r2, sp, #0x10
0x00280b:	lsls    	r0, r0, #9
0x00280d:	str     	r3, [sp, #0x2c]
0x00280f:	str     	r3, [sp, #0x30]
0x002811:	bl      	#0x5159
; block 0x2815
0x002815:	ldr     	r0, [sp, #0x6c]
0x002817:	movs    	r3, #8
0x002819:	ldr     	r0, [r0, #4]
0x00281b:	movs    	r1, #2
0x00281d:	str     	r0, [sp, #0x10]
0x00281f:	ldrsh   	r0, [r4, r3]
0x002821:	movs    	r3, #0xa
0x002823:	movs    	r2, #0
0x002825:	adds    	r0, r0, r5
0x002827:	str     	r0, [sp, #0x14]
0x002829:	ldrsh   	r0, [r4, r3]
0x00282b:	lsls    	r3, r0, #1
0x00282d:	adds    	r0, r3, r0
0x00282f:	adds    	r0, r0, r6
0x002831:	str     	r0, [sp, #0x18]
0x002833:	ldr     	r0, [sp, #0x6c]
0x002835:	movs    	r3, #8
0x002837:	ldrsh   	r0, [r0, r3]
0x002839:	str     	r0, [sp, #0x1c]
0x00283b:	ldr     	r0, [sp, #0x6c]
0x00283d:	ldrsh   	r0, [r0, r3]
0x00283f:	movs    	r3, #0xa
0x002841:	str     	r0, [sp, #0x20]
0x002843:	ldr     	r0, [sp, #0x6c]
0x002845:	ldrsh   	r0, [r0, r3]
0x002847:	str     	r1, [sp, #0x28]
0x002849:	movs    	r1, #0
0x00284b:	str     	r0, [sp, #0x24]
0x00284d:	movs    	r3, #0
0x00284f:	str     	r1, [sp, #4]
0x002851:	str     	r1, [sp]
0x002853:	movs    	r1, #0x1e
0x002855:	movs    	r0, #0xf1
0x002857:	str     	r2, [sp, #8]
0x002859:	add     	r2, sp, #0x10
0x00285b:	lsls    	r0, r0, #9
0x00285d:	str     	r3, [sp, #0x2c]
0x00285f:	str     	r3, [sp, #0x30]
0x002861:	bl      	#0x5159
; block 0x2865
0x002865:	b       	#0x2501

; ===== sub_2869 @ 0x2869 offset=0x2868 size=516 blocks=19 cc=17 =====
; block 0x2869
0x002869:	push    	{r4, r5, r6, r7, lr}
0x00286b:	sub     	sp, #0x24
0x00286d:	movs    	r1, #0
0x00286f:	str     	r1, [sp]
0x002871:	str     	r1, [sp, #4]
0x002873:	movs    	r4, #0
0x002875:	movs    	r2, #0
0x002877:	adds    	r3, r4, #0
0x002879:	movs    	r1, #0x1c
0x00287b:	movs    	r0, #0xf1
0x00287d:	lsls    	r0, r0, #9
0x00287f:	str     	r2, [sp, #8]
0x002881:	bl      	#0x5159
; block 0x2885
0x002885:	ldr     	r7, [pc, #0x1e4]
0x002887:	movs    	r3, #8
0x002889:	add     	r7, sb
0x00288b:	ldr     	r1, [r7, #0xc]
0x00288d:	movs    	r2, #0
0x00288f:	ldrsh   	r1, [r1, r3]
0x002891:	str     	r2, [sp, #8]
0x002893:	subs    	r0, r0, r1
0x002895:	movs    	r1, #0
0x002897:	str     	r1, [sp]
0x002899:	str     	r1, [sp, #4]
0x00289b:	asrs    	r6, r0, #1
0x00289d:	movs    	r0, #0xf1
0x00289f:	movs    	r1, #0x1d
0x0028a1:	adds    	r3, r4, #0
0x0028a3:	lsls    	r0, r0, #9
0x0028a5:	bl      	#0x5159
; block 0x28a9
0x0028a9:	adds    	r5, r0, #0
0x0028ab:	ldr     	r0, [r7, #0xc]
0x0028ad:	subs    	r5, #0x19
0x0028af:	str     	r5, [sp, #0x14]
0x0028b1:	str     	r6, [sp, #0x10]
0x0028b3:	movs    	r3, #8
0x0028b5:	str     	r0, [sp, #0xc]
0x0028b7:	ldrsh   	r0, [r0, r3]
0x0028b9:	movs    	r1, #0
0x0028bb:	movs    	r2, #0
0x0028bd:	str     	r0, [sp, #0x18]
0x0028bf:	movs    	r0, #0x14
0x0028c1:	str     	r0, [sp, #0x1c]
0x0028c3:	ldr     	r0, [pc, #0x1a8]
0x0028c5:	add     	r0, sb
0x0028c7:	subs    	r0, #0x80
0x0028c9:	ldr     	r0, [r0, #0x20]
0x0028cb:	str     	r1, [sp, #4]
0x0028cd:	str     	r0, [sp, #0x20]
0x0028cf:	str     	r1, [sp]
0x0028d1:	movs    	r1, #0x22
0x0028d3:	movs    	r0, #0xf1
0x0028d5:	str     	r2, [sp, #8]
0x0028d7:	adds    	r3, r4, #0
0x0028d9:	lsls    	r0, r0, #9
0x0028db:	add     	r2, sp, #0xc
0x0028dd:	bl      	#0x5159
; block 0x28e1
0x0028e1:	ldr     	r0, [r7, #0xc]
0x0028e3:	movs    	r3, #8
0x0028e5:	ldrsh   	r1, [r0, r3]
0x0028e7:	movs    	r2, #0x14
0x0028e9:	str     	r2, [sp, #8]
0x0028eb:	str     	r1, [sp, #4]
0x0028ed:	movs    	r1, #0x23
0x0028ef:	movs    	r2, #4
0x0028f1:	movs    	r0, #0xf1
0x0028f3:	adds    	r3, r6, #0
0x0028f5:	lsls    	r0, r0, #9
0x0028f7:	str     	r5, [sp]
0x0028f9:	bl      	#0x5159
; block 0x28fd
0x0028fd:	movs    	r1, #0
0x0028ff:	movs    	r2, #0
0x002901:	str     	r2, [sp, #8]
0x002903:	str     	r1, [sp]
0x002905:	str     	r1, [sp, #4]
0x002907:	subs    	r6, #0xd
0x002909:	adds    	r3, r4, #0
0x00290b:	movs    	r1, #0xe1
0x00290d:	movs    	r2, #0x26
0x00290f:	movs    	r0, #0xf1
0x002911:	lsls    	r0, r0, #9
0x002913:	bl      	#0x5159
; block 0x2917
0x002917:	movs    	r1, #0
0x002919:	movs    	r2, #0
0x00291b:	str     	r2, [sp, #8]
0x00291d:	str     	r1, [sp]
0x00291f:	str     	r1, [sp, #4]
0x002921:	str     	r0, [sp, #0xc]
0x002923:	movs    	r0, #0xf1
0x002925:	movs    	r1, #0xe1
0x002927:	movs    	r2, #0x27
0x002929:	adds    	r3, r4, #0
0x00292b:	lsls    	r0, r0, #9
0x00292d:	bl      	#0x5159
; block 0x2931
0x002931:	blx     	#0x2e8
; block 0x2935
0x002935:	lsrs    	r0, r1, #0x1f
0x002937:	adds    	r0, r0, r1
0x002939:	asrs    	r0, r0, #1
0x00293b:	lsls    	r0, r0, #1
0x00293d:	subs    	r0, r1, r0
0x00293f:	lsls    	r0, r0, #1
0x002941:	subs    	r0, r6, r0
0x002943:	str     	r0, [sp, #0x10]
0x002945:	adds    	r0, r5, #2
0x002947:	adds    	r5, r0, #0
0x002949:	str     	r0, [sp, #0x14]
0x00294b:	movs    	r0, #8
0x00294d:	str     	r0, [sp, #0x18]
0x00294f:	movs    	r1, #0
0x002951:	movs    	r0, #0xe
0x002953:	str     	r4, [sp, #0x20]
0x002955:	movs    	r2, #0
0x002957:	str     	r1, [sp]
0x002959:	str     	r0, [sp, #0x1c]
0x00295b:	str     	r1, [sp, #4]
0x00295d:	movs    	r1, #0x22
0x00295f:	movs    	r0, #0xf1
0x002961:	str     	r2, [sp, #8]
0x002963:	adds    	r3, r4, #0
0x002965:	lsls    	r0, r0, #9
0x002967:	add     	r2, sp, #0xc
0x002969:	bl      	#0x5159
; block 0x296d
0x00296d:	movs    	r1, #0
0x00296f:	movs    	r2, #0
0x002971:	str     	r2, [sp, #8]
0x002973:	str     	r1, [sp]
0x002975:	str     	r1, [sp, #4]
0x002977:	movs    	r1, #0xe1
0x002979:	movs    	r2, #0x27
0x00297b:	adds    	r3, r4, #0
0x00297d:	movs    	r0, #0xf1
0x00297f:	lsls    	r0, r0, #9
0x002981:	bl      	#0x5159
; block 0x2985
0x002985:	blx     	#0x2e8
; block 0x2989
0x002989:	lsrs    	r0, r1, #0x1f
0x00298b:	adds    	r0, r0, r1
0x00298d:	asrs    	r0, r0, #1
0x00298f:	lsls    	r0, r0, #1
0x002991:	subs    	r0, r1, r0
0x002993:	lsls    	r0, r0, #1
0x002995:	subs    	r3, r6, r0
0x002997:	movs    	r1, #0x1e
0x002999:	movs    	r2, #0x14
0x00299b:	str     	r2, [sp, #8]
0x00299d:	str     	r1, [sp, #4]
0x00299f:	movs    	r1, #0x23
0x0029a1:	movs    	r2, #2
0x0029a3:	subs    	r3, #0x14
0x0029a5:	movs    	r0, #0xf1
0x0029a7:	lsls    	r0, r0, #9
0x0029a9:	str     	r5, [sp]
0x0029ab:	bl      	#0x5159
; block 0x29af
0x0029af:	ldr     	r1, [r7, #0xc]
0x0029b1:	movs    	r3, #8
0x0029b3:	ldrsh   	r1, [r1, r3]
0x0029b5:	adds    	r0, r6, #0
0x0029b7:	adds    	r0, #0xd
0x0029b9:	adds    	r0, r1, r0
0x0029bb:	movs    	r1, #0
0x0029bd:	adds    	r6, r0, #5
0x0029bf:	movs    	r2, #0
0x0029c1:	str     	r2, [sp, #8]
0x0029c3:	str     	r1, [sp]
0x0029c5:	str     	r1, [sp, #4]
0x0029c7:	movs    	r1, #0xe1
0x0029c9:	movs    	r2, #0x26
0x0029cb:	movs    	r0, #0xf1
0x0029cd:	adds    	r3, r4, #0
0x0029cf:	lsls    	r0, r0, #9
0x0029d1:	bl      	#0x5159
; block 0x29d5
0x0029d5:	movs    	r1, #0
0x0029d7:	movs    	r2, #0
0x0029d9:	str     	r2, [sp, #8]
0x0029db:	str     	r1, [sp]
0x0029dd:	str     	r1, [sp, #4]
0x0029df:	str     	r0, [sp, #0xc]
0x0029e1:	movs    	r0, #0xf1
0x0029e3:	movs    	r1, #0xe1
0x0029e5:	movs    	r2, #0x27
0x0029e7:	adds    	r3, r4, #0
0x0029e9:	lsls    	r0, r0, #9
0x0029eb:	bl      	#0x5159
; block 0x29ef
0x0029ef:	blx     	#0x2e8
; block 0x29f3
0x0029f3:	lsrs    	r0, r1, #0x1f
0x0029f5:	adds    	r0, r0, r1
0x0029f7:	asrs    	r0, r0, #1
0x0029f9:	lsls    	r0, r0, #1
0x0029fb:	subs    	r0, r1, r0
0x0029fd:	lsls    	r0, r0, #1
0x0029ff:	adds    	r0, r0, r6
0x002a01:	str     	r0, [sp, #0x10]
0x002a03:	movs    	r0, #8
0x002a05:	str     	r0, [sp, #0x18]
0x002a07:	movs    	r0, #0xe
0x002a09:	str     	r0, [sp, #0x1c]
0x002a0b:	movs    	r0, #1
0x002a0d:	str     	r0, [sp, #0x20]
0x002a0f:	movs    	r1, #0
0x002a11:	movs    	r2, #0
0x002a13:	str     	r1, [sp]
0x002a15:	str     	r1, [sp, #4]
0x002a17:	movs    	r1, #0x22
0x002a19:	str     	r2, [sp, #8]
0x002a1b:	movs    	r0, #0xf1
0x002a1d:	adds    	r3, r4, #0
0x002a1f:	lsls    	r0, r0, #9
0x002a21:	add     	r2, sp, #0xc
0x002a23:	str     	r5, [sp, #0x14]
0x002a25:	bl      	#0x5159
; block 0x2a29
0x002a29:	movs    	r1, #0
0x002a2b:	movs    	r2, #0
0x002a2d:	str     	r2, [sp, #8]
0x002a2f:	str     	r1, [sp]
0x002a31:	str     	r1, [sp, #4]
0x002a33:	movs    	r1, #0xe1
0x002a35:	movs    	r2, #0x27
0x002a37:	adds    	r3, r4, #0
0x002a39:	movs    	r0, #0xf1
0x002a3b:	lsls    	r0, r0, #9
0x002a3d:	bl      	#0x5159
; block 0x2a41
0x002a41:	blx     	#0x2e8
; block 0x2a45
0x002a45:	lsrs    	r0, r1, #0x1f
0x002a47:	adds    	r0, r0, r1
0x002a49:	asrs    	r0, r0, #1
0x002a4b:	lsls    	r0, r0, #1
0x002a4d:	subs    	r0, r1, r0
0x002a4f:	lsls    	r0, r0, #1
0x002a51:	movs    	r1, #0x1e
0x002a53:	movs    	r2, #0x14
0x002a55:	str     	r2, [sp, #8]
0x002a57:	str     	r1, [sp, #4]
0x002a59:	adds    	r3, r0, r6
0x002a5b:	movs    	r0, #0xf1
0x002a5d:	movs    	r1, #0x23
0x002a5f:	movs    	r2, #3
0x002a61:	lsls    	r0, r0, #9
0x002a63:	str     	r5, [sp]
0x002a65:	bl      	#0x5159
; block 0x2a69
0x002a69:	add     	sp, #0x24
0x002a6b:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_2a6d @ 0x2a6d offset=0x2a6c size=4 blocks=1 cc=1 =====
; block 0x2a6d
0x002a6d:	lsls    	r4, r1, #2
0x002a6f:	movs    	r0, r0
0x002a71:	push    	{r4, r5, r6, lr}
0x002a73:	sub     	sp, #0x18
0x002a75:	bl      	#0x4a9d

; ===== sub_2a71 @ 0x2a71 offset=0x2a70 size=226 blocks=11 cc=7 =====
; block 0x2a71
0x002a71:	push    	{r4, r5, r6, lr}
0x002a73:	sub     	sp, #0x18
0x002a75:	bl      	#0x4a9d
; block 0x2a79
0x002a79:	movs    	r1, #0
0x002a7b:	str     	r1, [sp]
0x002a7d:	str     	r1, [sp, #4]
0x002a7f:	movs    	r2, #0
0x002a81:	movs    	r4, #0
0x002a83:	movs    	r5, #0xf1
0x002a85:	lsls    	r5, r5, #9
0x002a87:	adds    	r3, r4, #0
0x002a89:	movs    	r1, #0x1d
0x002a8b:	adds    	r0, r5, #0
0x002a8d:	str     	r2, [sp, #8]
0x002a8f:	bl      	#0x5159
; block 0x2a93
0x002a93:	movs    	r1, #0xff
0x002a95:	ldr     	r6, [pc, #0xbc]
0x002a97:	adds    	r1, #0xe1
0x002a99:	cmp     	r0, r1
0x002a9b:	add     	r6, sb
0x002a9d:	bge     	#0x2af7
; block 0x2a9f
0x002a9f:	movs    	r1, #0
0x002aa1:	str     	r1, [sp]
0x002aa3:	str     	r1, [sp, #4]
0x002aa5:	movs    	r2, #0
0x002aa7:	movs    	r1, #0x1d
0x002aa9:	adds    	r3, r4, #0
0x002aab:	adds    	r0, r5, #0
0x002aad:	str     	r2, [sp, #8]
0x002aaf:	bl      	#0x5159
; block 0x2ab3
0x002ab3:	subs    	r0, #0xff
0x002ab5:	subs    	r0, #0x41
0x002ab7:	lsrs    	r1, r0, #0x1f
0x002ab9:	adds    	r0, r1, r0
0x002abb:	movs    	r1, #0
0x002abd:	str     	r1, [sp]
0x002abf:	str     	r1, [sp, #4]
0x002ac1:	asrs    	r5, r0, #1
0x002ac3:	movs    	r2, #0
0x002ac5:	movs    	r0, #0xf1
0x002ac7:	movs    	r1, #0x1c
0x002ac9:	adds    	r3, r4, #0
0x002acb:	lsls    	r0, r0, #9
0x002acd:	str     	r2, [sp, #8]
0x002acf:	bl      	#0x5159
; block 0x2ad3
0x002ad3:	subs    	r0, #0xf0
0x002ad5:	lsrs    	r1, r0, #0x1f
0x002ad7:	adds    	r0, r1, r0
0x002ad9:	movs    	r1, #0
0x002adb:	movs    	r2, #0
0x002add:	asrs    	r0, r0, #1
0x002adf:	str     	r0, [sp]
0x002ae1:	adds    	r6, #0x24
0x002ae3:	str     	r2, [sp, #0x14]
0x002ae5:	str     	r2, [sp, #8]
0x002ae7:	str     	r1, [sp, #0xc]
0x002ae9:	str     	r1, [sp, #0x10]
0x002aeb:	str     	r5, [sp, #4]
0x002aed:	ldm     	r6!, {r0, r1, r2, r3}
0x002aef:	bl      	#0x24cd
; block 0x2af3
0x002af3:	add     	sp, #0x18
0x002af5:	pop     	{r4, r5, r6, pc}
; block 0x2af7
0x002af7:	movs    	r1, #0
0x002af9:	str     	r1, [sp]
0x002afb:	str     	r1, [sp, #4]
0x002afd:	movs    	r2, #0
0x002aff:	movs    	r1, #0x1d
0x002b01:	adds    	r3, r4, #0
0x002b03:	adds    	r0, r5, #0
0x002b05:	str     	r2, [sp, #8]
0x002b07:	bl      	#0x5159
; block 0x2b0b
0x002b0b:	subs    	r0, #0xff
0x002b0d:	subs    	r0, #0xe1
0x002b0f:	lsrs    	r1, r0, #0x1f
0x002b11:	adds    	r0, r1, r0
0x002b13:	movs    	r1, #0
0x002b15:	str     	r1, [sp]
0x002b17:	str     	r1, [sp, #4]
0x002b19:	asrs    	r5, r0, #1
0x002b1b:	movs    	r2, #0
0x002b1d:	movs    	r0, #0xf1
0x002b1f:	movs    	r1, #0x1c
0x002b21:	adds    	r3, r4, #0
0x002b23:	lsls    	r0, r0, #9
0x002b25:	str     	r2, [sp, #8]
0x002b27:	bl      	#0x5159
; block 0x2b2b
0x002b2b:	subs    	r0, #0xff
0x002b2d:	subs    	r0, #0x41
0x002b2f:	lsrs    	r1, r0, #0x1f
0x002b31:	adds    	r0, r1, r0
0x002b33:	asrs    	r3, r0, #1
0x002b35:	adds    	r6, #0x38
0x002b37:	ldm     	r6!, {r0, r1, r2}
0x002b39:	subs    	r6, #0x44
0x002b3b:	str     	r0, [sp, #0xc]
0x002b3d:	str     	r1, [sp, #0x10]
0x002b3f:	str     	r2, [sp, #0x14]
0x002b41:	ldr     	r2, [r6, #0x34]
0x002b43:	str     	r3, [sp]
0x002b45:	str     	r5, [sp, #4]
0x002b47:	adds    	r6, #0x24
0x002b49:	str     	r2, [sp, #8]
0x002b4b:	ldm     	r6!, {r0, r1, r2, r3}
0x002b4d:	bl      	#0x24cd
; block 0x2b51
0x002b51:	b       	#0x2af3

; ===== sub_2b55 @ 0x2b55 offset=0x2b54 size=4 blocks=1 cc=1 =====
; block 0x2b55
0x002b55:	movs    	r4, r1
0x002b57:	movs    	r0, r0
0x002b59:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x002b5b:	sub     	sp, #0x4c
0x002b5d:	movs    	r1, #0
0x002b5f:	movs    	r2, #0
0x002b61:	str     	r2, [sp, #8]
0x002b63:	str     	r1, [sp]
0x002b65:	str     	r1, [sp, #4]
0x002b67:	movs    	r1, #0xe1
0x002b69:	movs    	r2, #0x24
0x002b6b:	movs    	r0, #0xf1
0x002b6d:	movs    	r3, #0
0x002b6f:	lsls    	r0, r0, #9
0x002b71:	bl      	#0x5159

; ===== sub_2b59 @ 0x2b59 offset=0x2b58 size=570 blocks=23 cc=18 =====
; block 0x2b59
0x002b59:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x002b5b:	sub     	sp, #0x4c
0x002b5d:	movs    	r1, #0
0x002b5f:	movs    	r2, #0
0x002b61:	str     	r2, [sp, #8]
0x002b63:	str     	r1, [sp]
0x002b65:	str     	r1, [sp, #4]
0x002b67:	movs    	r1, #0xe1
0x002b69:	movs    	r2, #0x24
0x002b6b:	movs    	r0, #0xf1
0x002b6d:	movs    	r3, #0
0x002b6f:	lsls    	r0, r0, #9
0x002b71:	bl      	#0x5159
; block 0x2b75
0x002b75:	ldr     	r5, [pc, #0x21c]
0x002b77:	movs    	r2, #0
0x002b79:	add     	r5, sb
0x002b7b:	ldr     	r1, [r5, #0x1c]
0x002b7d:	movs    	r4, #0
0x002b7f:	lsls    	r1, r1, #2
0x002b81:	ldr     	r0, [r0, r1]
0x002b83:	movs    	r6, #0
0x002b85:	ldr     	r1, [r0, #4]
0x002b87:	movs    	r7, #0
0x002b89:	str     	r1, [sp, #0x48]
0x002b8b:	ldr     	r1, [r0, #8]
0x002b8d:	movs    	r3, #0
0x002b8f:	str     	r1, [sp, #0x44]
0x002b91:	ldr     	r1, [r0, #0xc]
0x002b93:	str     	r1, [sp, #0x40]
0x002b95:	ldr     	r0, [r0, #0x10]
0x002b97:	movs    	r1, #0
0x002b99:	str     	r0, [sp, #0x3c]
0x002b9b:	ldr     	r0, [r5]
0x002b9d:	ldr     	r0, [r0]
0x002b9f:	str     	r2, [sp, #8]
0x002ba1:	movs    	r2, #0xff
0x002ba3:	str     	r1, [sp]
0x002ba5:	str     	r1, [sp, #4]
0x002ba7:	str     	r0, [sp, #0x38]
0x002ba9:	movs    	r0, #0xf1
0x002bab:	movs    	r1, #0xe1
0x002bad:	adds    	r2, #0x22
0x002baf:	lsls    	r0, r0, #9
0x002bb1:	bl      	#0x5159
; block 0x2bb5
0x002bb5:	ldr     	r1, [r5, #0x20]
0x002bb7:	lsls    	r1, r1, #2
0x002bb9:	ldr     	r0, [r0, r1]
0x002bbb:	ldr     	r0, [r0, #0xc]
0x002bbd:	cmp     	r0, #0
0x002bbf:	bne     	#0x2c2b
; block 0x2bc1
0x002bc1:	movs    	r2, #0
0x002bc3:	movs    	r1, #0
0x002bc5:	str     	r2, [sp, #8]
0x002bc7:	movs    	r5, #0
0x002bc9:	adds    	r3, r5, #0
0x002bcb:	movs    	r2, #0xff
0x002bcd:	str     	r1, [sp]
0x002bcf:	str     	r1, [sp, #4]
0x002bd1:	movs    	r1, #0xe1
0x002bd3:	adds    	r2, #0x22
0x002bd5:	movs    	r0, #0xf1
0x002bd7:	lsls    	r0, r0, #9
0x002bd9:	bl      	#0x5159
; block 0x2bdd
0x002bdd:	ldr     	r1, [pc, #0x1b4]
0x002bdf:	movs    	r2, #0
0x002be1:	add     	r1, sb
0x002be3:	ldr     	r1, [r1, #0x20]
0x002be5:	lsls    	r1, r1, #2
0x002be7:	ldr     	r0, [r0, r1]
0x002be9:	movs    	r1, #0
0x002beb:	ldr     	r3, [r0, #4]
0x002bed:	str     	r1, [sp]
0x002bef:	str     	r1, [sp, #4]
0x002bf1:	str     	r2, [sp, #8]
0x002bf3:	movs    	r0, #0xf1
0x002bf5:	lsls    	r0, r0, #9
0x002bf7:	adds    	r2, r3, #0
0x002bf9:	movs    	r1, #0x37
0x002bfb:	adds    	r3, r5, #0
0x002bfd:	bl      	#0x5159
; block 0x2c01
0x002c01:	movs    	r2, #0
0x002c03:	movs    	r1, #0
0x002c05:	str     	r2, [sp, #8]
0x002c07:	movs    	r2, #0xff
0x002c09:	str     	r1, [sp]
0x002c0b:	str     	r1, [sp, #4]
0x002c0d:	str     	r0, [sp, #0x2c]
0x002c0f:	adds    	r3, r5, #0
0x002c11:	adds    	r2, #0x22
0x002c13:	movs    	r0, #0xf1
0x002c15:	movs    	r1, #0xe1
0x002c17:	lsls    	r0, r0, #9
0x002c19:	bl      	#0x5159
; block 0x2c1d
0x002c1d:	ldr     	r1, [pc, #0x174]
0x002c1f:	add     	r1, sb
0x002c21:	ldr     	r1, [r1, #0x20]
0x002c23:	lsls    	r1, r1, #2
0x002c25:	ldr     	r1, [r0, r1]
0x002c27:	ldr     	r0, [sp, #0x2c]
0x002c29:	str     	r0, [r1, #0xc]
0x002c2b:	movs    	r2, #0
0x002c2d:	movs    	r1, #0
0x002c2f:	str     	r2, [sp, #8]
0x002c31:	movs    	r2, #0xff
0x002c33:	str     	r1, [sp]
0x002c35:	str     	r1, [sp, #4]
0x002c37:	movs    	r1, #0xe1
0x002c39:	adds    	r2, #0x22
0x002c3b:	movs    	r3, #0
0x002c3d:	movs    	r0, #0xf1
0x002c3f:	lsls    	r0, r0, #9
0x002c41:	bl      	#0x5159
; block 0x2c2b
0x002c2b:	movs    	r2, #0
0x002c2d:	movs    	r1, #0
0x002c2f:	str     	r2, [sp, #8]
0x002c31:	movs    	r2, #0xff
0x002c33:	str     	r1, [sp]
0x002c35:	str     	r1, [sp, #4]
0x002c37:	movs    	r1, #0xe1
0x002c39:	adds    	r2, #0x22
0x002c3b:	movs    	r3, #0
0x002c3d:	movs    	r0, #0xf1
0x002c3f:	lsls    	r0, r0, #9
0x002c41:	bl      	#0x5159
; block 0x2c45
0x002c45:	ldr     	r1, [pc, #0x14c]
0x002c47:	movs    	r2, #0
0x002c49:	add     	r1, sb
0x002c4b:	ldr     	r1, [r1, #0x20]
0x002c4d:	movs    	r3, #0
0x002c4f:	lsls    	r1, r1, #2
0x002c51:	ldr     	r0, [r0, r1]
0x002c53:	movs    	r1, #0
0x002c55:	ldr     	r5, [r0, #0xc]
0x002c57:	str     	r1, [sp]
0x002c59:	str     	r1, [sp, #4]
0x002c5b:	str     	r2, [sp, #8]
0x002c5d:	adds    	r2, r5, #0
0x002c5f:	movs    	r1, #0xe3
0x002c61:	movs    	r0, #0xf1
0x002c63:	lsls    	r0, r0, #9
0x002c65:	bl      	#0x5159
; block 0x2c69
0x002c69:	cmp     	r0, #2
0x002c6b:	ble     	#0x2c75
; block 0x2c6d
0x002c6d:	movs    	r4, #3
0x002c6f:	movs    	r0, #1
0x002c71:	str     	r0, [sp, #0x34]
0x002c73:	b       	#0x2c79
; block 0x2c75
0x002c75:	movs    	r0, #1
0x002c77:	str     	r0, [sp, #0x34]
0x002c79:	movs    	r1, #0
0x002c7b:	movs    	r2, #0
0x002c7d:	str     	r2, [sp, #8]
0x002c7f:	str     	r1, [sp]
0x002c81:	str     	r1, [sp, #4]
0x002c83:	movs    	r1, #0xe1
0x002c85:	movs    	r2, #0x27
0x002c87:	movs    	r3, #0
0x002c89:	movs    	r0, #0xf1
0x002c8b:	lsls    	r0, r0, #9
0x002c8d:	bl      	#0x5159
; block 0x2c79
0x002c79:	movs    	r1, #0
0x002c7b:	movs    	r2, #0
0x002c7d:	str     	r2, [sp, #8]
0x002c7f:	str     	r1, [sp]
0x002c81:	str     	r1, [sp, #4]
0x002c83:	movs    	r1, #0xe1
0x002c85:	movs    	r2, #0x27
0x002c87:	movs    	r3, #0
0x002c89:	movs    	r0, #0xf1
0x002c8b:	lsls    	r0, r0, #9
0x002c8d:	bl      	#0x5159
; block 0x2c91
0x002c91:	movs    	r1, #0
0x002c93:	movs    	r2, #0
0x002c95:	str     	r2, [sp, #8]
0x002c97:	str     	r1, [sp]
0x002c99:	str     	r1, [sp, #4]
0x002c9b:	str     	r0, [sp, #0x2c]
0x002c9d:	adds    	r3, r4, #0
0x002c9f:	adds    	r2, r5, #0
0x002ca1:	movs    	r0, #0xf1
0x002ca3:	movs    	r1, #0x38
0x002ca5:	lsls    	r0, r0, #9
0x002ca7:	bl      	#0x5159
; block 0x2cab
0x002cab:	ldr     	r1, [sp, #0x2c]
0x002cad:	blx     	#0x20
; block 0x2cb1
0x002cb1:	ldr     	r0, [sp, #0x4c]
0x002cb3:	str     	r1, [sp, #0x30]
0x002cb5:	str     	r0, [sp, #0x1c]
0x002cb7:	ldr     	r0, [sp, #0x50]
0x002cb9:	str     	r1, [sp, #0x28]
0x002cbb:	str     	r0, [sp, #0x20]
0x002cbd:	ldr     	r0, [sp, #0x34]
0x002cbf:	movs    	r1, #0
0x002cc1:	str     	r4, [sp, #0x24]
0x002cc3:	movs    	r2, #0
0x002cc5:	str     	r1, [sp, #4]
0x002cc7:	str     	r1, [sp]
0x002cc9:	str     	r0, [sp, #0x2c]
0x002ccb:	movs    	r0, #0xf1
0x002ccd:	movs    	r1, #0x39
0x002ccf:	str     	r2, [sp, #8]
0x002cd1:	movs    	r3, #0
0x002cd3:	lsls    	r0, r0, #9
0x002cd5:	add     	r2, sp, #0x18
0x002cd7:	str     	r5, [sp, #0x18]
0x002cd9:	bl      	#0x5159
; block 0x2cdd
0x002cdd:	movs    	r2, #0
0x002cdf:	movs    	r1, #0
0x002ce1:	ldr     	r0, [sp, #0x30]
0x002ce3:	str     	r1, [sp, #4]
0x002ce5:	str     	r2, [sp, #8]
0x002ce7:	adds    	r2, r5, #0
0x002ce9:	movs    	r1, #0xff
0x002ceb:	adds    	r3, r4, #0
0x002ced:	str     	r0, [sp]
0x002cef:	movs    	r0, #0xf1
0x002cf1:	adds    	r1, #0x57
0x002cf3:	lsls    	r0, r0, #9
0x002cf5:	bl      	#0x5159
; block 0x2cf9
0x002cf9:	movs    	r2, #0
0x002cfb:	movs    	r1, #0
0x002cfd:	str     	r2, [sp, #8]
0x002cff:	adds    	r4, r0, #0
0x002d01:	movs    	r2, #0xff
0x002d03:	str     	r1, [sp]
0x002d05:	str     	r1, [sp, #4]
0x002d07:	movs    	r1, #0xe1
0x002d09:	adds    	r2, #0x22
0x002d0b:	movs    	r0, #0xf1
0x002d0d:	movs    	r3, #0
0x002d0f:	lsls    	r0, r0, #9
0x002d11:	bl      	#0x5159
; block 0x2d15
0x002d15:	ldr     	r1, [pc, #0x7c]
0x002d17:	movs    	r2, #0
0x002d19:	add     	r1, sb
0x002d1b:	ldr     	r1, [r1, #0x20]
0x002d1d:	adds    	r3, r4, #0
0x002d1f:	lsls    	r1, r1, #2
0x002d21:	ldr     	r5, [r0, r1]
0x002d23:	movs    	r1, #0
0x002d25:	str     	r1, [sp]
0x002d27:	str     	r1, [sp, #4]
0x002d29:	str     	r2, [sp, #8]
0x002d2b:	adds    	r2, r5, #0
0x002d2d:	movs    	r1, #0xff
0x002d2f:	adds    	r1, #0x56
0x002d31:	movs    	r0, #0xf1
0x002d33:	lsls    	r0, r0, #9
0x002d35:	bl      	#0x5159
; block 0x2d39
0x002d39:	cmp     	r0, #0
0x002d3b:	beq     	#0x2d45
; block 0x2d3d
0x002d3d:	movs    	r3, #1
0x002d3f:	ldrsb   	r6, [r0, r3]
0x002d41:	movs    	r3, #2
0x002d43:	ldrsb   	r7, [r0, r3]
0x002d45:	ldr     	r0, [sp, #0x38]
0x002d47:	ldr     	r1, [sp, #0x40]
0x002d49:	str     	r0, [sp, #0xc]
0x002d4b:	lsrs    	r0, r1, #0x1f
0x002d4d:	adds    	r0, r0, r1
0x002d4f:	ldr     	r1, [sp, #0x4c]
0x002d51:	asrs    	r0, r0, #1
0x002d53:	adds    	r1, r1, r6
0x002d55:	subs    	r0, r1, r0
0x002d57:	str     	r0, [sp, #0x10]
0x002d59:	ldr     	r0, [sp, #0x50]
0x002d5b:	ldr     	r1, [sp, #0x3c]
0x002d5d:	adds    	r0, r0, r7
0x002d5f:	subs    	r0, r0, r1
0x002d61:	ldr     	r1, [sp, #0x48]
0x002d63:	str     	r0, [sp, #0x14]
0x002d65:	str     	r1, [sp, #0x18]
0x002d67:	ldr     	r1, [sp, #0x44]
0x002d69:	movs    	r3, #0
0x002d6b:	str     	r1, [sp, #0x1c]
0x002d6d:	ldr     	r1, [sp, #0x40]
0x002d6f:	ldr     	r0, [sp, #0x3c]
0x002d71:	str     	r1, [sp, #0x20]
0x002d73:	movs    	r1, #0
0x002d75:	str     	r0, [sp, #0x24]
0x002d77:	movs    	r2, #0
0x002d79:	str     	r1, [sp, #4]
0x002d7b:	str     	r1, [sp]
0x002d7d:	str     	r3, [sp, #0x28]
0x002d7f:	str     	r2, [sp, #8]
0x002d81:	movs    	r1, #0x20
0x002d83:	movs    	r0, #0xf1
0x002d85:	lsls    	r0, r0, #9
0x002d87:	add     	r2, sp, #0xc
0x002d89:	str     	r3, [sp, #0x2c]
0x002d8b:	bl      	#0x5159
; block 0x2d45
0x002d45:	ldr     	r0, [sp, #0x38]
0x002d47:	ldr     	r1, [sp, #0x40]
0x002d49:	str     	r0, [sp, #0xc]
0x002d4b:	lsrs    	r0, r1, #0x1f
0x002d4d:	adds    	r0, r0, r1
0x002d4f:	ldr     	r1, [sp, #0x4c]
0x002d51:	asrs    	r0, r0, #1
0x002d53:	adds    	r1, r1, r6
0x002d55:	subs    	r0, r1, r0
0x002d57:	str     	r0, [sp, #0x10]
0x002d59:	ldr     	r0, [sp, #0x50]
0x002d5b:	ldr     	r1, [sp, #0x3c]
0x002d5d:	adds    	r0, r0, r7
0x002d5f:	subs    	r0, r0, r1
0x002d61:	ldr     	r1, [sp, #0x48]
0x002d63:	str     	r0, [sp, #0x14]
0x002d65:	str     	r1, [sp, #0x18]
0x002d67:	ldr     	r1, [sp, #0x44]
0x002d69:	movs    	r3, #0
0x002d6b:	str     	r1, [sp, #0x1c]
0x002d6d:	ldr     	r1, [sp, #0x40]
0x002d6f:	ldr     	r0, [sp, #0x3c]
0x002d71:	str     	r1, [sp, #0x20]
0x002d73:	movs    	r1, #0
0x002d75:	str     	r0, [sp, #0x24]
0x002d77:	movs    	r2, #0
0x002d79:	str     	r1, [sp, #4]
0x002d7b:	str     	r1, [sp]
0x002d7d:	str     	r3, [sp, #0x28]
0x002d7f:	str     	r2, [sp, #8]
0x002d81:	movs    	r1, #0x20
0x002d83:	movs    	r0, #0xf1
0x002d85:	lsls    	r0, r0, #9
0x002d87:	add     	r2, sp, #0xc
0x002d89:	str     	r3, [sp, #0x2c]
0x002d8b:	bl      	#0x5159
; block 0x2d8f
0x002d8f:	add     	sp, #0x54
0x002d91:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_2d95 @ 0x2d95 offset=0x2d94 size=4 blocks=1 cc=1 =====
; block 0x2d95
0x002d95:	lsls    	r4, r1, #2
0x002d97:	movs    	r0, r0
0x002d99:	push    	{r4, r5, r6, r7, lr}
0x002d9b:	ldr     	r4, [pc, #0x100]
0x002d9d:	sub     	sp, #0x2c
0x002d9f:	add     	r4, pc
0x002da1:	movs    	r1, #0
0x002da3:	movs    	r2, #0
0x002da5:	str     	r2, [sp, #8]
0x002da7:	str     	r1, [sp]
0x002da9:	str     	r1, [sp, #4]
0x002dab:	movs    	r6, #0
0x002dad:	adds    	r3, r6, #0
0x002daf:	movs    	r1, #0xe1
0x002db1:	movs    	r2, #0x28
0x002db3:	movs    	r0, #0xf1
0x002db5:	lsls    	r0, r0, #9
0x002db7:	bl      	#0x5159

; ===== sub_2d99 @ 0x2d99 offset=0x2d98 size=260 blocks=9 cc=8 =====
; block 0x2d99
0x002d99:	push    	{r4, r5, r6, r7, lr}
0x002d9b:	ldr     	r4, [pc, #0x100]
0x002d9d:	sub     	sp, #0x2c
0x002d9f:	add     	r4, pc
0x002da1:	movs    	r1, #0
0x002da3:	movs    	r2, #0
0x002da5:	str     	r2, [sp, #8]
0x002da7:	str     	r1, [sp]
0x002da9:	str     	r1, [sp, #4]
0x002dab:	movs    	r6, #0
0x002dad:	adds    	r3, r6, #0
0x002daf:	movs    	r1, #0xe1
0x002db1:	movs    	r2, #0x28
0x002db3:	movs    	r0, #0xf1
0x002db5:	lsls    	r0, r0, #9
0x002db7:	bl      	#0x5159
; block 0x2dbb
0x002dbb:	movs    	r1, #0
0x002dbd:	adds    	r5, r0, #0
0x002dbf:	movs    	r2, #0
0x002dc1:	str     	r2, [sp, #8]
0x002dc3:	str     	r1, [sp]
0x002dc5:	str     	r1, [sp, #4]
0x002dc7:	movs    	r1, #0xe1
0x002dc9:	movs    	r2, #0x29
0x002dcb:	movs    	r0, #0xf1
0x002dcd:	adds    	r3, r6, #0
0x002dcf:	lsls    	r0, r0, #9
0x002dd1:	bl      	#0x5159
; block 0x2dd5
0x002dd5:	adds    	r3, r0, #0
0x002dd7:	add     	r2, sp, #0x24
0x002dd9:	add     	r1, sp, #0x28
0x002ddb:	str     	r1, [sp, #4]
0x002ddd:	str     	r2, [sp, #8]
0x002ddf:	adds    	r2, r4, #0
0x002de1:	movs    	r1, #0x2a
0x002de3:	movs    	r0, #0xf1
0x002de5:	lsls    	r0, r0, #9
0x002de7:	str     	r5, [sp]
0x002de9:	bl      	#0x5159
; block 0x2ded
0x002ded:	movs    	r1, #0
0x002def:	str     	r1, [sp]
0x002df1:	str     	r1, [sp, #4]
0x002df3:	ldr     	r1, [pc, #0xac]
0x002df5:	ldr     	r4, [sp, #0x28]
0x002df7:	movs    	r2, #0
0x002df9:	str     	r2, [sp, #8]
0x002dfb:	add     	r1, sb
0x002dfd:	ldr     	r2, [r1, #0x1c]
0x002dff:	movs    	r1, #0x11
0x002e01:	movs    	r3, #4
0x002e03:	movs    	r0, #0xf1
0x002e05:	adds    	r4, #0x28
0x002e07:	lsls    	r0, r0, #9
0x002e09:	bl      	#0x5159
; block 0x2e0d
0x002e0d:	ldr     	r1, [sp, #0x24]
0x002e0f:	movs    	r2, #0
0x002e11:	muls    	r0, r1, r0
0x002e13:	movs    	r1, #0
0x002e15:	adds    	r5, r0, #0
0x002e17:	adds    	r5, #0xa
0x002e19:	str     	r1, [sp]
0x002e1b:	str     	r1, [sp, #4]
0x002e1d:	movs    	r1, #0x1c
0x002e1f:	adds    	r3, r6, #0
0x002e21:	movs    	r0, #0xf1
0x002e23:	lsls    	r0, r0, #9
0x002e25:	str     	r2, [sp, #8]
0x002e27:	bl      	#0x5159
; block 0x2e2b
0x002e2b:	subs    	r0, r0, r4
0x002e2d:	lsrs    	r1, r0, #0x1f
0x002e2f:	adds    	r0, r1, r0
0x002e31:	movs    	r1, #0
0x002e33:	str     	r1, [sp]
0x002e35:	str     	r1, [sp, #4]
0x002e37:	asrs    	r7, r0, #1
0x002e39:	movs    	r2, #0
0x002e3b:	movs    	r0, #0xf1
0x002e3d:	movs    	r1, #0x1d
0x002e3f:	adds    	r3, r6, #0
0x002e41:	lsls    	r0, r0, #9
0x002e43:	str     	r2, [sp, #8]
0x002e45:	bl      	#0x5159
; block 0x2e49
0x002e49:	subs    	r0, r0, r5
0x002e4b:	lsrs    	r1, r0, #0x1f
0x002e4d:	adds    	r0, r1, r0
0x002e4f:	ldr     	r1, [pc, #0x50]
0x002e51:	asrs    	r0, r0, #1
0x002e53:	add     	r1, sb
0x002e55:	ldr     	r1, [r1, #0x1c]
0x002e57:	str     	r0, [sp, #0x14]
0x002e59:	ldr     	r0, [pc, #0x44]
0x002e5b:	str     	r1, [sp, #0xc]
0x002e5d:	add     	r0, sb
0x002e5f:	adds    	r0, #0x14
0x002e61:	str     	r0, [sp, #0x20]
0x002e63:	movs    	r1, #0
0x002e65:	movs    	r2, #0
0x002e67:	str     	r1, [sp]
0x002e69:	str     	r1, [sp, #4]
0x002e6b:	movs    	r1, #0x2b
0x002e6d:	str     	r2, [sp, #8]
0x002e6f:	movs    	r0, #0xf1
0x002e71:	adds    	r3, r6, #0
0x002e73:	lsls    	r0, r0, #9
0x002e75:	add     	r2, sp, #0xc
0x002e77:	str     	r7, [sp, #0x10]
0x002e79:	str     	r4, [sp, #0x18]
0x002e7b:	str     	r5, [sp, #0x1c]
0x002e7d:	bl      	#0x5159
; block 0x2e81
0x002e81:	movs    	r1, #0
0x002e83:	movs    	r2, #0
0x002e85:	str     	r2, [sp, #8]
0x002e87:	str     	r1, [sp]
0x002e89:	str     	r1, [sp, #4]
0x002e8b:	movs    	r1, #0x24
0x002e8d:	movs    	r2, #1
0x002e8f:	movs    	r3, #1
0x002e91:	movs    	r0, #0xf1
0x002e93:	lsls    	r0, r0, #9
0x002e95:	bl      	#0x5159
; block 0x2e99
0x002e99:	add     	sp, #0x2c
0x002e9b:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_2e9d @ 0x2e9d offset=0x2e9c size=8 blocks=1 cc=0 =====
; block 0x2e9d
0x002e9d:	subs    	r3, #2
0x002e9f:	movs    	r0, r0
0x002ea1:	movs    	r4, r1
0x002ea3:	movs    	r0, r0
0x002ea5:	push    	{r4, r5, r6, r7, lr}
0x002ea7:	sub     	sp, #0x84
0x002ea9:	movs    	r1, #0xaa
0x002eab:	str     	r1, [sp, #0x50]
0x002ead:	movs    	r1, #0x1a
0x002eaf:	str     	r1, [sp, #0x48]
0x002eb1:	movs    	r1, #0
0x002eb3:	movs    	r2, #0
0x002eb5:	movs    	r0, #0x2e
0x002eb7:	str     	r0, [sp]
0x002eb9:	str     	r2, [sp, #8]
0x002ebb:	str     	r1, [sp, #4]
0x002ebd:	movs    	r1, #0x40
0x002ebf:	movs    	r2, #0x18
0x002ec1:	movs    	r0, #0xf1
0x002ec3:	movs    	r7, #0x32
0x002ec5:	movs    	r6, #0x50
0x002ec7:	movs    	r4, #0
0x002ec9:	movs    	r3, #0x2e
0x002ecb:	lsls    	r0, r0, #9
0x002ecd:	bl      	#0x5159

; ===== sub_2ea5 @ 0x2ea5 offset=0x2ea4 size=2228 blocks=101 cc=82 =====
; block 0x2ea5
0x002ea5:	push    	{r4, r5, r6, r7, lr}
0x002ea7:	sub     	sp, #0x84
0x002ea9:	movs    	r1, #0xaa
0x002eab:	str     	r1, [sp, #0x50]
0x002ead:	movs    	r1, #0x1a
0x002eaf:	str     	r1, [sp, #0x48]
0x002eb1:	movs    	r1, #0
0x002eb3:	movs    	r2, #0
0x002eb5:	movs    	r0, #0x2e
0x002eb7:	str     	r0, [sp]
0x002eb9:	str     	r2, [sp, #8]
0x002ebb:	str     	r1, [sp, #4]
0x002ebd:	movs    	r1, #0x40
0x002ebf:	movs    	r2, #0x18
0x002ec1:	movs    	r0, #0xf1
0x002ec3:	movs    	r7, #0x32
0x002ec5:	movs    	r6, #0x50
0x002ec7:	movs    	r4, #0
0x002ec9:	movs    	r3, #0x2e
0x002ecb:	lsls    	r0, r0, #9
0x002ecd:	bl      	#0x5159
; block 0x2ed1
0x002ed1:	ldr     	r5, [pc, #0x3dc]
0x002ed3:	add     	r5, pc
0x002ed5:	movs    	r1, #1
0x002ed7:	movs    	r0, #0
0x002ed9:	str     	r0, [sp]
0x002edb:	str     	r1, [sp, #4]
0x002edd:	movs    	r2, #0
0x002edf:	movs    	r1, #0x55
0x002ee1:	movs    	r0, #0xf1
0x002ee3:	movs    	r3, #0
0x002ee5:	lsls    	r0, r0, #9
0x002ee7:	str     	r2, [sp, #8]
0x002ee9:	bl      	#0x5159
; block 0x2eed
0x002eed:	movs    	r1, #0
0x002eef:	movs    	r2, #0
0x002ef1:	str     	r2, [sp, #8]
0x002ef3:	str     	r1, [sp]
0x002ef5:	str     	r1, [sp, #4]
0x002ef7:	movs    	r1, #0xe1
0x002ef9:	movs    	r2, #0x28
0x002efb:	movs    	r3, #0
0x002efd:	movs    	r0, #0xf1
0x002eff:	lsls    	r0, r0, #9
0x002f01:	bl      	#0x5159
; block 0x2f05
0x002f05:	str     	r0, [sp, #0x44]
0x002f07:	movs    	r1, #0
0x002f09:	movs    	r2, #0
0x002f0b:	str     	r2, [sp, #8]
0x002f0d:	str     	r1, [sp]
0x002f0f:	str     	r1, [sp, #4]
0x002f11:	movs    	r1, #0xe1
0x002f13:	movs    	r2, #0x29
0x002f15:	movs    	r0, #0xf1
0x002f17:	movs    	r3, #0
0x002f19:	lsls    	r0, r0, #9
0x002f1b:	bl      	#0x5159
; block 0x2f1f
0x002f1f:	adds    	r3, r0, #0
0x002f21:	ldr     	r0, [sp, #0x44]
0x002f23:	add     	r2, sp, #0x64
0x002f25:	add     	r1, sp, #0x68
0x002f27:	str     	r1, [sp, #4]
0x002f29:	str     	r2, [sp, #8]
0x002f2b:	str     	r0, [sp]
0x002f2d:	movs    	r0, #0xf1
0x002f2f:	adds    	r2, r5, #0
0x002f31:	movs    	r1, #0x2a
0x002f33:	lsls    	r0, r0, #9
0x002f35:	bl      	#0x5159
; block 0x2f39
0x002f39:	movs    	r1, #0
0x002f3b:	movs    	r2, #0
0x002f3d:	str     	r2, [sp, #8]
0x002f3f:	str     	r1, [sp]
0x002f41:	str     	r1, [sp, #4]
0x002f43:	movs    	r1, #0xe1
0x002f45:	movs    	r2, #0x2a
0x002f47:	movs    	r3, #0
0x002f49:	movs    	r0, #0xf1
0x002f4b:	lsls    	r0, r0, #9
0x002f4d:	bl      	#0x5159
; block 0x2f51
0x002f51:	ldr     	r1, [sp, #0x64]
0x002f53:	adds    	r0, r0, r1
0x002f55:	str     	r0, [sp, #0x54]
0x002f57:	movs    	r0, #0
0x002f59:	ldr     	r1, [sp, #0x48]
0x002f5b:	bl      	#0x23fd
; block 0x2f5f
0x002f5f:	movs    	r1, #0
0x002f61:	str     	r5, [sp, #0x20]
0x002f63:	str     	r1, [sp]
0x002f65:	str     	r1, [sp, #4]
0x002f67:	movs    	r2, #0
0x002f69:	movs    	r1, #0x1c
0x002f6b:	movs    	r3, #0
0x002f6d:	movs    	r0, #0xf1
0x002f6f:	lsls    	r0, r0, #9
0x002f71:	str     	r2, [sp, #8]
0x002f73:	bl      	#0x5159
; block 0x2f77
0x002f77:	ldr     	r1, [sp, #0x68]
0x002f79:	movs    	r3, #0
0x002f7b:	subs    	r0, r0, r1
0x002f7d:	lsrs    	r1, r0, #0x1f
0x002f7f:	adds    	r0, r1, r0
0x002f81:	asrs    	r0, r0, #1
0x002f83:	str     	r0, [sp, #0x24]
0x002f85:	ldr     	r1, [sp, #0x64]
0x002f87:	ldr     	r0, [sp, #0x54]
0x002f89:	str     	r3, [sp, #0x2c]
0x002f8b:	subs    	r0, r0, r1
0x002f8d:	lsrs    	r1, r0, #0x1f
0x002f8f:	adds    	r0, r1, r0
0x002f91:	asrs    	r0, r0, #1
0x002f93:	adds    	r0, #0x1c
0x002f95:	str     	r0, [sp, #0x28]
0x002f97:	movs    	r0, #0xff
0x002f99:	str     	r0, [sp, #0x34]
0x002f9b:	str     	r0, [sp, #0x38]
0x002f9d:	str     	r0, [sp, #0x3c]
0x002f9f:	movs    	r0, #1
0x002fa1:	movs    	r1, #0x20
0x002fa3:	str     	r3, [sp, #0x30]
0x002fa5:	add     	r5, sp, #0x20
0x002fa7:	strb    	r0, [r1, r5]
0x002fa9:	str     	r0, [sp, #0x44]
0x002fab:	movs    	r1, #0
0x002fad:	movs    	r2, #0
0x002faf:	str     	r2, [sp, #8]
0x002fb1:	str     	r1, [sp]
0x002fb3:	str     	r1, [sp, #4]
0x002fb5:	movs    	r1, #0x25
0x002fb7:	adds    	r2, r5, #0
0x002fb9:	movs    	r0, #0xf1
0x002fbb:	lsls    	r0, r0, #9
0x002fbd:	bl      	#0x5159
; block 0x2fc1
0x002fc1:	movs    	r1, #0
0x002fc3:	str     	r1, [sp]
0x002fc5:	str     	r1, [sp, #4]
0x002fc7:	movs    	r2, #0
0x002fc9:	movs    	r1, #0x1d
0x002fcb:	movs    	r3, #0
0x002fcd:	movs    	r0, #0xf1
0x002fcf:	lsls    	r0, r0, #9
0x002fd1:	str     	r2, [sp, #8]
0x002fd3:	bl      	#0x5159
; block 0x2fd7
0x002fd7:	ldr     	r1, [sp, #0x54]
0x002fd9:	movs    	r2, #0
0x002fdb:	subs    	r5, r0, r1
0x002fdd:	movs    	r1, #0
0x002fdf:	str     	r1, [sp]
0x002fe1:	str     	r1, [sp, #4]
0x002fe3:	movs    	r1, #0x1c
0x002fe5:	subs    	r5, #0x1d
0x002fe7:	movs    	r0, #0xf1
0x002fe9:	movs    	r3, #0
0x002feb:	lsls    	r0, r0, #9
0x002fed:	str     	r2, [sp, #8]
0x002fef:	bl      	#0x5159
; block 0x2ff3
0x002ff3:	str     	r5, [sp, #4]
0x002ff5:	ldr     	r5, [sp, #0x54]
0x002ff7:	movs    	r2, #0
0x002ff9:	str     	r0, [sp]
0x002ffb:	adds    	r5, #0x1a
0x002ffd:	adds    	r3, r5, #3
0x002fff:	movs    	r0, #0xf1
0x003001:	movs    	r1, #0x31
0x003003:	lsls    	r0, r0, #9
0x003005:	str     	r2, [sp, #8]
0x003007:	bl      	#0x5159
; block 0x300b
0x00300b:	movs    	r1, #0
0x00300d:	str     	r1, [sp]
0x00300f:	str     	r1, [sp, #4]
0x003011:	adds    	r5, #5
0x003013:	movs    	r2, #0
0x003015:	movs    	r1, #0x1c
0x003017:	movs    	r3, #0
0x003019:	movs    	r0, #0xf1
0x00301b:	lsls    	r0, r0, #9
0x00301d:	str     	r2, [sp, #8]
0x00301f:	str     	r5, [sp, #0x5c]
0x003021:	bl      	#0x5159
; block 0x3025
0x003025:	subs    	r0, #0xaa
0x003027:	lsrs    	r1, r0, #0x1f
0x003029:	adds    	r0, r1, r0
0x00302b:	asrs    	r5, r0, #1
0x00302d:	movs    	r1, #0
0x00302f:	ldr     	r0, [pc, #0x284]
0x003031:	str     	r1, [sp]
0x003033:	str     	r1, [sp, #4]
0x003035:	movs    	r2, #0
0x003037:	str     	r2, [sp, #8]
0x003039:	str     	r5, [sp, #0x58]
0x00303b:	add     	r0, sb
0x00303d:	ldr     	r2, [r0, #0x18]
0x00303f:	movs    	r0, #0xf1
0x003041:	movs    	r1, #0x26
0x003043:	movs    	r3, #0
0x003045:	lsls    	r0, r0, #9
0x003047:	bl      	#0x5159
; block 0x304b
0x00304b:	ldr     	r3, [sp, #0x5c]
0x00304d:	str     	r0, [sp, #0x60]
0x00304f:	adds    	r0, r3, r6
0x003051:	str     	r0, [sp, #0x7c]
0x003053:	subs    	r0, #0x14
0x003055:	str     	r0, [sp, #0x80]
0x003057:	lsrs    	r0, r7, #0x1f
0x003059:	adds    	r0, r0, r7
0x00305b:	asrs    	r0, r0, #1
0x00305d:	str     	r0, [sp, #0x78]
0x00305f:	ldr     	r1, [pc, #0x254]
0x003061:	add     	r1, sb
0x003063:	ldr     	r0, [r1, #0x10]
0x003065:	cmp     	r0, r4
0x003067:	beq     	#0x3099
; block 0x305f
0x00305f:	ldr     	r1, [pc, #0x254]
0x003061:	add     	r1, sb
0x003063:	ldr     	r0, [r1, #0x10]
0x003065:	cmp     	r0, r4
0x003067:	beq     	#0x3099
; block 0x3069
0x003069:	ldr     	r3, [sp, #0x5c]
0x00306b:	movs    	r0, #0xff
0x00306d:	str     	r0, [sp, #0x38]
0x00306f:	str     	r0, [sp, #0x3c]
0x003071:	movs    	r0, #0xc8
0x003073:	str     	r0, [sp, #0x40]
0x003075:	movs    	r0, #2
0x003077:	str     	r0, [sp, #0x44]
0x003079:	movs    	r1, #0
0x00307b:	movs    	r2, #0
0x00307d:	str     	r1, [sp]
0x00307f:	str     	r1, [sp, #4]
0x003081:	str     	r5, [sp, #0x28]
0x003083:	str     	r3, [sp, #0x2c]
0x003085:	movs    	r3, #0
0x003087:	str     	r2, [sp, #8]
0x003089:	movs    	r1, #0x57
0x00308b:	movs    	r0, #0xf1
0x00308d:	lsls    	r0, r0, #9
0x00308f:	add     	r2, sp, #0x28
0x003091:	str     	r7, [sp, #0x30]
0x003093:	str     	r6, [sp, #0x34]
0x003095:	bl      	#0x5159
; block 0x3099
0x003099:	movs    	r2, #0
0x00309b:	str     	r2, [sp, #8]
0x00309d:	adds    	r2, r5, #0
0x00309f:	movs    	r1, #0x2f
0x0030a1:	movs    	r0, #0xf1
0x0030a3:	lsls    	r0, r0, #9
0x0030a5:	str     	r7, [sp]
0x0030a7:	str     	r6, [sp, #4]
0x0030a9:	ldr     	r3, [sp, #0x5c]
0x0030ab:	bl      	#0x5159
; block 0x30af
0x0030af:	cmp     	r0, #1
0x0030b1:	bne     	#0x30d7
; block 0x30b3
0x0030b3:	ldr     	r1, [pc, #0x200]
0x0030b5:	add     	r1, sb
0x0030b7:	ldr     	r0, [r1, #0x10]
0x0030b9:	cmp     	r0, r4
0x0030bb:	beq     	#0x30c1
; block 0x30bd
0x0030bd:	str     	r4, [r1, #0x10]
0x0030bf:	b       	#0x30d7
; block 0x30c1
0x0030c1:	ldr     	r0, [sp, #0x5c]
0x0030c3:	adds    	r3, r5, #0
0x0030c5:	str     	r0, [sp]
0x0030c7:	movs    	r0, #0xf1
0x0030c9:	movs    	r2, #4
0x0030cb:	movs    	r1, #0x23
0x0030cd:	lsls    	r0, r0, #9
0x0030cf:	str     	r7, [sp, #4]
0x0030d1:	str     	r6, [sp, #8]
0x0030d3:	bl      	#0x5159
; block 0x30d7
0x0030d7:	ldr     	r0, [pc, #0x1dc]
0x0030d9:	add     	r0, sb
0x0030db:	ldr     	r0, [r0, #0x10]
0x0030dd:	cmp     	r0, r4
0x0030df:	bne     	#0x3111
; block 0x30e1
0x0030e1:	ldr     	r3, [sp, #0x5c]
0x0030e3:	movs    	r0, #0xff
0x0030e5:	str     	r0, [sp, #0x38]
0x0030e7:	str     	r0, [sp, #0x3c]
0x0030e9:	movs    	r0, #0xc8
0x0030eb:	str     	r0, [sp, #0x40]
0x0030ed:	movs    	r0, #3
0x0030ef:	str     	r0, [sp, #0x44]
0x0030f1:	movs    	r1, #0
0x0030f3:	movs    	r2, #0
0x0030f5:	str     	r1, [sp]
0x0030f7:	str     	r1, [sp, #4]
0x0030f9:	str     	r5, [sp, #0x28]
0x0030fb:	str     	r3, [sp, #0x2c]
0x0030fd:	movs    	r3, #0
0x0030ff:	str     	r2, [sp, #8]
0x003101:	movs    	r1, #0x57
0x003103:	movs    	r0, #0xf1
0x003105:	lsls    	r0, r0, #9
0x003107:	add     	r2, sp, #0x28
0x003109:	str     	r7, [sp, #0x30]
0x00310b:	str     	r6, [sp, #0x34]
0x00310d:	bl      	#0x5159
; block 0x3111
0x003111:	ldr     	r0, [sp, #0x60]
0x003113:	cmp     	r4, r0
0x003115:	bge     	#0x31eb
; block 0x3117
0x003117:	ldr     	r2, [pc, #0x19c]
0x003119:	lsls    	r1, r4, #2
0x00311b:	add     	r2, sb
0x00311d:	adds    	r2, #0xa4
0x00311f:	str     	r1, [sp, #0x74]
0x003121:	ldr     	r0, [r2, r1]
0x003123:	cmp     	r0, #0
0x003125:	bne     	#0x3169
; block 0x3127
0x003127:	movs    	r1, #0
0x003129:	ldr     	r0, [pc, #0x188]
0x00312b:	str     	r1, [sp]
0x00312d:	str     	r1, [sp, #4]
0x00312f:	movs    	r2, #0
0x003131:	str     	r2, [sp, #8]
0x003133:	add     	r0, sb
0x003135:	ldr     	r2, [r0, #0x18]
0x003137:	movs    	r0, #0xf1
0x003139:	movs    	r1, #0x27
0x00313b:	adds    	r3, r4, #0
0x00313d:	lsls    	r0, r0, #9
0x00313f:	bl      	#0x5159
; block 0x3143
0x003143:	ldr     	r0, [r0, #0x14]
0x003145:	movs    	r2, #0
0x003147:	ldr     	r0, [r0, #4]
0x003149:	movs    	r1, #0
0x00314b:	str     	r2, [sp, #8]
0x00314d:	adds    	r2, r0, #0
0x00314f:	str     	r1, [sp]
0x003151:	str     	r1, [sp, #4]
0x003153:	movs    	r1, #0x37
0x003155:	movs    	r0, #0xf1
0x003157:	movs    	r3, #0
0x003159:	lsls    	r0, r0, #9
0x00315b:	bl      	#0x5159
; block 0x315f
0x00315f:	ldr     	r2, [pc, #0x154]
0x003161:	ldr     	r1, [sp, #0x74]
0x003163:	add     	r2, sb
0x003165:	adds    	r2, #0xa4
0x003167:	str     	r0, [r2, r1]
0x003169:	ldr     	r2, [pc, #0x148]
0x00316b:	ldr     	r1, [sp, #0x74]
0x00316d:	add     	r2, sb
0x00316f:	adds    	r2, #0xa4
0x003171:	ldr     	r0, [r2, r1]
0x003173:	str     	r0, [sp, #0x44]
0x003175:	ldr     	r0, [pc, #0x13c]
0x003177:	add     	r0, sb
0x003179:	ldr     	r0, [r0, #0x10]
0x00317b:	cmp     	r0, r4
0x00317d:	bne     	#0x31ed
; block 0x3169
0x003169:	ldr     	r2, [pc, #0x148]
0x00316b:	ldr     	r1, [sp, #0x74]
0x00316d:	add     	r2, sb
0x00316f:	adds    	r2, #0xa4
0x003171:	ldr     	r0, [r2, r1]
0x003173:	str     	r0, [sp, #0x44]
0x003175:	ldr     	r0, [pc, #0x13c]
0x003177:	add     	r0, sb
0x003179:	ldr     	r0, [r0, #0x10]
0x00317b:	cmp     	r0, r4
0x00317d:	bne     	#0x31ed
; block 0x317f
0x00317f:	ldr     	r0, [sp, #0x44]
0x003181:	movs    	r1, #0
0x003183:	str     	r0, [sp, #0x2c]
0x003185:	ldr     	r0, [sp, #0x78]
0x003187:	movs    	r3, #2
0x003189:	adds    	r0, r0, r5
0x00318b:	str     	r0, [sp, #0x30]
0x00318d:	ldr     	r0, [sp, #0x80]
0x00318f:	movs    	r2, #0
0x003191:	str     	r2, [sp, #8]
0x003193:	str     	r1, [sp]
0x003195:	str     	r3, [sp, #0x38]
0x003197:	str     	r1, [sp, #4]
0x003199:	str     	r0, [sp, #0x34]
0x00319b:	movs    	r0, #0xf1
0x00319d:	movs    	r1, #0xe1
0x00319f:	movs    	r3, #0
0x0031a1:	movs    	r2, #0x27
0x0031a3:	lsls    	r0, r0, #9
0x0031a5:	bl      	#0x5159
; block 0x31a9
0x0031a9:	lsrs    	r1, r0, #0x1f
0x0031ab:	adds    	r0, r1, r0
0x0031ad:	movs    	r1, #0
0x0031af:	str     	r1, [sp, #4]
0x0031b1:	asrs    	r0, r0, #1
0x0031b3:	movs    	r2, #0
0x0031b5:	str     	r0, [sp, #0x70]
0x0031b7:	str     	r1, [sp]
0x0031b9:	movs    	r1, #0x38
0x0031bb:	movs    	r0, #0xf1
0x0031bd:	str     	r2, [sp, #8]
0x0031bf:	movs    	r3, #2
0x0031c1:	lsls    	r0, r0, #9
0x0031c3:	ldr     	r2, [sp, #0x44]
0x0031c5:	bl      	#0x5159
; block 0x31c9
0x0031c9:	ldr     	r1, [sp, #0x70]
0x0031cb:	blx     	#0x20
; block 0x31cf
0x0031cf:	str     	r1, [sp, #0x3c]
0x0031d1:	movs    	r1, #0
0x0031d3:	movs    	r3, #0
0x0031d5:	str     	r3, [sp, #0x40]
0x0031d7:	movs    	r2, #0
0x0031d9:	str     	r1, [sp]
0x0031db:	str     	r1, [sp, #4]
0x0031dd:	movs    	r1, #0x39
0x0031df:	str     	r2, [sp, #8]
0x0031e1:	movs    	r0, #0xf1
0x0031e3:	lsls    	r0, r0, #9
0x0031e5:	add     	r2, sp, #0x2c
0x0031e7:	bl      	#0x5159
; block 0x31eb
0x0031eb:	b       	#0x3219
; block 0x31ed
0x0031ed:	ldr     	r0, [sp, #0x44]
0x0031ef:	movs    	r3, #0
0x0031f1:	str     	r0, [sp, #0x2c]
0x0031f3:	ldr     	r0, [sp, #0x78]
0x0031f5:	movs    	r1, #0
0x0031f7:	adds    	r0, r0, r5
0x0031f9:	str     	r0, [sp, #0x30]
0x0031fb:	ldr     	r0, [sp, #0x80]
0x0031fd:	str     	r3, [sp, #0x40]
0x0031ff:	movs    	r2, #0
0x003201:	str     	r1, [sp]
0x003203:	str     	r1, [sp, #4]
0x003205:	str     	r0, [sp, #0x34]
0x003207:	movs    	r0, #0xf1
0x003209:	movs    	r1, #0x39
0x00320b:	str     	r2, [sp, #8]
0x00320d:	add     	r2, sp, #0x2c
0x00320f:	lsls    	r0, r0, #9
0x003211:	str     	r3, [sp, #0x38]
0x003213:	str     	r3, [sp, #0x3c]
0x003215:	bl      	#0x5159
; block 0x3219
0x003219:	adds    	r5, r5, r7
0x00321b:	adds    	r5, #0xa
0x00321d:	adds    	r4, #1
0x00321f:	cmp     	r4, #3
0x003221:	bge     	#0x3225
; block 0x3223
0x003223:	b       	#0x305f
; block 0x3225
0x003225:	movs    	r1, #0
0x003227:	str     	r1, [sp]
0x003229:	str     	r1, [sp, #4]
0x00322b:	movs    	r2, #0
0x00322d:	movs    	r4, #0
0x00322f:	adds    	r3, r4, #0
0x003231:	movs    	r1, #0x1d
0x003233:	movs    	r0, #0xf1
0x003235:	lsls    	r0, r0, #9
0x003237:	str     	r2, [sp, #8]
0x003239:	bl      	#0x5159
; block 0x323d
0x00323d:	ldr     	r1, [sp, #0x54]
0x00323f:	ldr     	r5, [pc, #0x74]
0x003241:	subs    	r0, r0, r1
0x003243:	subs    	r0, r0, r6
0x003245:	ldr     	r1, [sp, #0x48]
0x003247:	subs    	r0, #0x14
0x003249:	subs    	r0, r0, r1
0x00324b:	str     	r0, [sp, #0x4c]
0x00324d:	add     	r5, sb
0x00324f:	ldr     	r0, [r5, #0x10]
0x003251:	ldr     	r1, [sp, #0x60]
0x003253:	cmp     	r0, r1
0x003255:	bge     	#0x333d
; block 0x3257
0x003257:	movs    	r1, #0
0x003259:	str     	r1, [sp]
0x00325b:	str     	r1, [sp, #4]
0x00325d:	movs    	r2, #0
0x00325f:	movs    	r1, #0x1c
0x003261:	movs    	r3, #0
0x003263:	movs    	r0, #0xf1
0x003265:	lsls    	r0, r0, #9
0x003267:	str     	r2, [sp, #8]
0x003269:	bl      	#0x5159
; block 0x326d
0x00326d:	movs    	r1, #0
0x00326f:	subs    	r0, #0x14
0x003271:	str     	r0, [sp, #0x38]
0x003273:	str     	r1, [sp]
0x003275:	str     	r1, [sp, #4]
0x003277:	movs    	r2, #0
0x003279:	str     	r2, [sp, #8]
0x00327b:	ldr     	r2, [r5, #0x18]
0x00327d:	movs    	r1, #0x27
0x00327f:	movs    	r0, #0xf1
0x003281:	lsls    	r0, r0, #9
0x003283:	ldr     	r3, [r5, #0x10]
0x003285:	bl      	#0x5159
; block 0x3289
0x003289:	adds    	r4, r0, #0
0x00328b:	movs    	r0, #0xa
0x00328d:	mov     	ip, r0
0x00328f:	ldr     	r0, [sp, #0x7c]
0x003291:	ldr     	r1, [sp, #0x48]
0x003293:	adds    	r0, #0x14
0x003295:	str     	r0, [sp, #0x5c]
0x003297:	ldr     	r0, [sp, #0x54]
0x003299:	movs    	r5, #0x19
0x00329b:	adds    	r0, r0, r6
0x00329d:	adds    	r7, r0, r1
0x00329f:	ldr     	r0, [sp, #0x64]
0x0032a1:	adds    	r7, #0x14
0x0032a3:	lsls    	r3, r0, #1
0x0032a5:	adds    	r0, r3, r0
0x0032a7:	lsls    	r0, r0, #1
0x0032a9:	adds    	r0, #0x1e
0x0032ab:	ldr     	r1, [sp, #0x50]
0x0032ad:	b       	#0x32b9
; block 0x32b9
0x0032b9:	cmp     	r0, r1
0x0032bb:	bge     	#0x32df
; block 0x32bd
0x0032bd:	ldr     	r0, [sp, #0x38]
0x0032bf:	ldr     	r1, [sp, #0x4c]
0x0032c1:	movs    	r2, #0
0x0032c3:	str     	r0, [sp]
0x0032c5:	ldr     	r0, [sp, #0x54]
0x0032c7:	str     	r2, [sp, #8]
0x0032c9:	str     	r1, [sp, #4]
0x0032cb:	ldr     	r1, [sp, #0x48]
0x0032cd:	adds    	r0, r6, r0
0x0032cf:	adds    	r3, r0, r1
0x0032d1:	adds    	r3, #0xa
0x0032d3:	movs    	r0, #0xf1
0x0032d5:	movs    	r1, #0x32
0x0032d7:	lsls    	r0, r0, #9
0x0032d9:	mov     	r2, ip
0x0032db:	bl      	#0x5159
; block 0x32df
0x0032df:	ldr     	r6, [r4]
0x0032e1:	ldr     	r0, [sp, #0x5c]
0x0032e3:	cmp     	r0, r7
0x0032e5:	ble     	#0x33cb
; block 0x32e7
0x0032e7:	movs    	r2, #0
0x0032e9:	str     	r2, [sp, #8]
0x0032eb:	ldr     	r1, [sp, #0x5c]
0x0032ed:	ldr     	r2, [pc, #0x3e0]
0x0032ef:	adds    	r3, r6, #0
0x0032f1:	str     	r5, [sp]
0x0032f3:	str     	r1, [sp, #4]
0x0032f5:	add     	r2, pc
0x0032f7:	movs    	r1, #0x3c
0x0032f9:	movs    	r0, #0xf1
0x0032fb:	lsls    	r0, r0, #9
0x0032fd:	bl      	#0x5159
; block 0x3301
0x003301:	add     	r2, sp, #0x64
0x003303:	str     	r2, [sp, #8]
0x003305:	movs    	r0, #0
0x003307:	ldr     	r2, [pc, #0x3cc]
0x003309:	add     	r1, sp, #0x68
0x00330b:	str     	r1, [sp, #4]
0x00330d:	str     	r0, [sp]
0x00330f:	movs    	r3, #0
0x003311:	add     	r2, pc
0x003313:	movs    	r1, #0x2a
0x003315:	movs    	r0, #0xf1
0x003317:	lsls    	r0, r0, #9
0x003319:	bl      	#0x5159
; block 0x331d
0x00331d:	ldr     	r0, [sp, #0x68]
0x00331f:	add     	r2, sp, #0x64
0x003321:	str     	r0, [sp, #0x3c]
0x003323:	movs    	r0, #0
0x003325:	add     	r1, sp, #0x68
0x003327:	str     	r1, [sp, #4]
0x003329:	str     	r0, [sp]
0x00332b:	str     	r2, [sp, #8]
0x00332d:	adds    	r2, r6, #0
0x00332f:	movs    	r0, #0xf1
0x003331:	movs    	r1, #0x2a
0x003333:	movs    	r3, #0
0x003335:	lsls    	r0, r0, #9
0x003337:	bl      	#0x5159
; block 0x333b
0x00333b:	b       	#0x333f
; block 0x333d
0x00333d:	b       	#0x366f
; block 0x333f
0x00333f:	ldr     	r0, [sp, #0x3c]
0x003341:	ldr     	r1, [sp, #0x68]
0x003343:	adds    	r6, r0, r1
0x003345:	adds    	r0, r4, #0
0x003347:	adds    	r0, #0x40
0x003349:	str     	r0, [sp, #0x6c]
0x00334b:	ldrb    	r0, [r0]
0x00334d:	adds    	r6, #5
0x00334f:	cmp     	r0, #0
0x003351:	beq     	#0x33a3
; block 0x3353
0x003353:	movs    	r2, #0
0x003355:	movs    	r1, #0
0x003357:	str     	r2, [sp, #8]
0x003359:	movs    	r2, #0xff
0x00335b:	str     	r1, [sp]
0x00335d:	str     	r1, [sp, #4]
0x00335f:	movs    	r1, #0xe1
0x003361:	adds    	r2, #0x12
0x003363:	movs    	r3, #0
0x003365:	movs    	r0, #0xf1
0x003367:	lsls    	r0, r0, #9
0x003369:	bl      	#0x5159
; block 0x336d
0x00336d:	str     	r0, [sp, #0x20]
0x00336f:	adds    	r0, r6, #0
0x003371:	adds    	r0, #0x19
0x003373:	str     	r0, [sp, #0x24]
0x003375:	ldr     	r0, [sp, #0x5c]
0x003377:	movs    	r3, #0
0x003379:	str     	r0, [sp, #0x28]
0x00337b:	movs    	r0, #0x11
0x00337d:	str     	r0, [sp, #0x2c]
0x00337f:	movs    	r0, #0xc
0x003381:	str     	r0, [sp, #0x30]
0x003383:	ldr     	r0, [sp, #0x6c]
0x003385:	movs    	r1, #0
0x003387:	ldrsb   	r0, [r0, r3]
0x003389:	movs    	r2, #0
0x00338b:	str     	r1, [sp]
0x00338d:	subs    	r0, #1
0x00338f:	str     	r0, [sp, #0x34]
0x003391:	str     	r1, [sp, #4]
0x003393:	movs    	r1, #0x22
0x003395:	movs    	r0, #0xf1
0x003397:	str     	r2, [sp, #8]
0x003399:	add     	r2, sp, #0x20
0x00339b:	lsls    	r0, r0, #9
0x00339d:	bl      	#0x5159
; block 0x33a1
0x0033a1:	adds    	r6, #0x11
0x0033a3:	ldr     	r0, [sp, #0x5c]
0x0033a5:	movs    	r1, #1
0x0033a7:	str     	r1, [sp, #4]
0x0033a9:	movs    	r2, #0
0x0033ab:	str     	r0, [sp]
0x0033ad:	str     	r2, [sp, #8]
0x0033af:	movs    	r1, #0x24
0x0033b1:	adds    	r6, #5
0x0033b3:	adds    	r3, r6, #0
0x0033b5:	ldrsb   	r2, [r1, r4]
0x0033b7:	movs    	r1, #0x3d
0x0033b9:	adds    	r3, #0x19
0x0033bb:	movs    	r0, #0xf1
0x0033bd:	lsls    	r0, r0, #9
0x0033bf:	bl      	#0x5159
; block 0x33a3
0x0033a3:	ldr     	r0, [sp, #0x5c]
0x0033a5:	movs    	r1, #1
0x0033a7:	str     	r1, [sp, #4]
0x0033a9:	movs    	r2, #0
0x0033ab:	str     	r0, [sp]
0x0033ad:	str     	r2, [sp, #8]
0x0033af:	movs    	r1, #0x24
0x0033b1:	adds    	r6, #5
0x0033b3:	adds    	r3, r6, #0
0x0033b5:	ldrsb   	r2, [r1, r4]
0x0033b7:	movs    	r1, #0x3d
0x0033b9:	adds    	r3, #0x19
0x0033bb:	movs    	r0, #0xf1
0x0033bd:	lsls    	r0, r0, #9
0x0033bf:	bl      	#0x5159
; block 0x33c3
0x0033c3:	adds    	r6, #0x14
0x0033c5:	str     	r6, [sp, #0x3c]
0x0033c7:	movs    	r2, #0
0x0033c9:	b       	#0x33cd
; block 0x33cb
0x0033cb:	b       	#0x3427
; block 0x33cd
0x0033cd:	movs    	r1, #0
0x0033cf:	str     	r1, [sp]
0x0033d1:	str     	r1, [sp, #4]
0x0033d3:	str     	r2, [sp, #8]
0x0033d5:	movs    	r6, #0
0x0033d7:	adds    	r3, r6, #0
0x0033d9:	movs    	r2, #0x25
0x0033db:	movs    	r1, #0xe1
0x0033dd:	movs    	r0, #0xf1
0x0033df:	lsls    	r0, r0, #9
0x0033e1:	bl      	#0x5159
; block 0x33e5
0x0033e5:	movs    	r1, #0x30
0x0033e7:	ldrsb   	r1, [r1, r4]
0x0033e9:	add     	r3, sp, #0x10
0x0033eb:	movs    	r2, #0
0x0033ed:	lsls    	r1, r1, #2
0x0033ef:	ldr     	r0, [r0, r1]
0x0033f1:	str     	r6, [sp, #0x20]
0x0033f3:	str     	r0, [sp, #0x10]
0x0033f5:	ldr     	r0, [sp, #0x3c]
0x0033f7:	str     	r6, [sp, #0x28]
0x0033f9:	adds    	r0, #0x19
0x0033fb:	str     	r0, [sp, #0x14]
0x0033fd:	ldr     	r0, [sp, #0x5c]
0x0033ff:	str     	r6, [sp, #0x1c]
0x003401:	str     	r0, [sp, #0x18]
0x003403:	movs    	r0, #0xc8
0x003405:	str     	r0, [sp, #0x24]
0x003407:	movs    	r0, #1
0x003409:	str     	r6, [sp, #0x2c]
0x00340b:	movs    	r1, #0x20
0x00340d:	strb    	r0, [r1, r3]
0x00340f:	movs    	r1, #0
0x003411:	str     	r1, [sp]
0x003413:	str     	r1, [sp, #4]
0x003415:	str     	r2, [sp, #8]
0x003417:	movs    	r0, #0xf1
0x003419:	lsls    	r0, r0, #9
0x00341b:	adds    	r2, r3, #0
0x00341d:	movs    	r1, #0x25
0x00341f:	adds    	r3, r6, #0
0x003421:	str     	r6, [sp, #0x34]
0x003423:	bl      	#0x5159
; block 0x3427
0x003427:	ldr     	r0, [sp, #0x5c]
0x003429:	ldr     	r1, [sp, #0x64]
0x00342b:	adds    	r6, r0, r1
0x00342d:	adds    	r6, #5
0x00342f:	cmp     	r6, r7
0x003431:	ble     	#0x34a7
; block 0x3433
0x003433:	ldr     	r0, [r4, #0x34]
0x003435:	adds    	r3, r0, #1
0x003437:	bne     	#0x3455
; block 0x3439
0x003439:	movs    	r2, #0
0x00343b:	ldr     	r3, [pc, #0x29c]
0x00343d:	str     	r2, [sp, #8]
0x00343f:	str     	r5, [sp]
0x003441:	str     	r6, [sp, #4]
0x003443:	add     	r3, pc
0x003445:	adds    	r2, r3, #0
0x003447:	subs    	r2, #8
0x003449:	movs    	r1, #0x3c
0x00344b:	movs    	r0, #0xf1
0x00344d:	lsls    	r0, r0, #9
0x00344f:	bl      	#0x5159
; block 0x3453
0x003453:	b       	#0x34a7
; block 0x3455
0x003455:	movs    	r2, #0
0x003457:	str     	r2, [sp, #8]
0x003459:	ldr     	r2, [pc, #0x280]
0x00345b:	str     	r5, [sp]
0x00345d:	str     	r6, [sp, #4]
0x00345f:	add     	r2, pc
0x003461:	movs    	r1, #0x3c
0x003463:	movs    	r0, #0xf1
0x003465:	lsls    	r0, r0, #9
0x003467:	ldr     	r3, [r4, #0x3c]
0x003469:	bl      	#0x5159
; block 0x346d
0x00346d:	str     	r0, [sp, #0x40]
0x00346f:	movs    	r1, #0
0x003471:	str     	r1, [sp]
0x003473:	str     	r1, [sp, #4]
0x003475:	movs    	r2, #0
0x003477:	str     	r2, [sp, #8]
0x003479:	movs    	r0, #0x38
0x00347b:	ldrsb   	r2, [r0, r4]
0x00347d:	movs    	r1, #0xff
0x00347f:	adds    	r1, #0x1c
0x003481:	movs    	r0, #0xf1
0x003483:	movs    	r3, #0
0x003485:	lsls    	r0, r0, #9
0x003487:	bl      	#0x5159
; block 0x348b
0x00348b:	adds    	r3, r0, #0
0x00348d:	movs    	r2, #0
0x00348f:	ldr     	r0, [sp, #0x40]
0x003491:	str     	r2, [sp, #8]
0x003493:	ldr     	r2, [pc, #0x24c]
0x003495:	adds    	r0, #0x23
0x003497:	str     	r0, [sp]
0x003499:	str     	r6, [sp, #4]
0x00349b:	add     	r2, pc
0x00349d:	movs    	r1, #0x3c
0x00349f:	movs    	r0, #0xf1
0x0034a1:	lsls    	r0, r0, #9
0x0034a3:	bl      	#0x5159
; block 0x34a7
0x0034a7:	ldr     	r0, [sp, #0x64]
0x0034a9:	adds    	r6, r6, r0
0x0034ab:	adds    	r6, #5
0x0034ad:	cmp     	r6, r7
0x0034af:	ble     	#0x34fb
; block 0x34b1
0x0034b1:	movs    	r1, #0
0x0034b3:	str     	r1, [sp]
0x0034b5:	str     	r1, [sp, #4]
0x0034b7:	movs    	r2, #0
0x0034b9:	str     	r2, [sp, #8]
0x0034bb:	movs    	r1, #0x3f
0x0034bd:	movs    	r3, #0
0x0034bf:	movs    	r0, #0xf1
0x0034c1:	lsls    	r0, r0, #9
0x0034c3:	ldr     	r2, [r4, #0xc]
0x0034c5:	bl      	#0x5159
; block 0x34c9
0x0034c9:	movs    	r2, #0
0x0034cb:	str     	r2, [sp, #8]
0x0034cd:	ldr     	r2, [pc, #0x214]
0x0034cf:	str     	r0, [sp, #0x44]
0x0034d1:	str     	r6, [sp, #4]
0x0034d3:	adds    	r3, r0, #0
0x0034d5:	str     	r5, [sp]
0x0034d7:	add     	r2, pc
0x0034d9:	movs    	r1, #0x3c
0x0034db:	movs    	r0, #0xf1
0x0034dd:	lsls    	r0, r0, #9
0x0034df:	bl      	#0x5159
; block 0x34e3
0x0034e3:	movs    	r1, #0
0x0034e5:	str     	r1, [sp, #4]
0x0034e7:	movs    	r2, #0
0x0034e9:	str     	r1, [sp]
0x0034eb:	movs    	r1, #9
0x0034ed:	str     	r2, [sp, #8]
0x0034ef:	movs    	r3, #0
0x0034f1:	movs    	r0, #0xf1
0x0034f3:	lsls    	r0, r0, #9
0x0034f5:	ldr     	r2, [sp, #0x44]
0x0034f7:	bl      	#0x5159
; block 0x34fb
0x0034fb:	ldr     	r0, [sp, #0x64]
0x0034fd:	adds    	r6, r6, r0
0x0034ff:	adds    	r6, #5
0x003501:	cmp     	r6, r7
0x003503:	ble     	#0x354f
; block 0x3505
0x003505:	movs    	r1, #0
0x003507:	str     	r1, [sp]
0x003509:	str     	r1, [sp, #4]
0x00350b:	movs    	r2, #0
0x00350d:	str     	r2, [sp, #8]
0x00350f:	movs    	r1, #0x3f
0x003511:	movs    	r3, #0
0x003513:	movs    	r0, #0xf1
0x003515:	lsls    	r0, r0, #9
0x003517:	ldr     	r2, [r4, #0x2c]
0x003519:	bl      	#0x5159
; block 0x351d
0x00351d:	movs    	r2, #0
0x00351f:	str     	r2, [sp, #8]
0x003521:	ldr     	r2, [pc, #0x1c4]
0x003523:	str     	r0, [sp, #0x44]
0x003525:	str     	r6, [sp, #4]
0x003527:	adds    	r3, r0, #0
0x003529:	str     	r5, [sp]
0x00352b:	add     	r2, pc
0x00352d:	movs    	r1, #0x3c
0x00352f:	movs    	r0, #0xf1
0x003531:	lsls    	r0, r0, #9
0x003533:	bl      	#0x5159
; block 0x3537
0x003537:	movs    	r1, #0
0x003539:	str     	r1, [sp, #4]
0x00353b:	movs    	r2, #0
0x00353d:	str     	r1, [sp]
0x00353f:	movs    	r1, #9
0x003541:	str     	r2, [sp, #8]
0x003543:	movs    	r3, #0
0x003545:	movs    	r0, #0xf1
0x003547:	lsls    	r0, r0, #9
0x003549:	ldr     	r2, [sp, #0x44]
0x00354b:	bl      	#0x5159
; block 0x354f
0x00354f:	ldr     	r0, [sp, #0x64]
0x003551:	adds    	r6, r6, r0
0x003553:	adds    	r6, #5
0x003555:	cmp     	r6, r7
0x003557:	ble     	#0x35a3
; block 0x3559
0x003559:	movs    	r1, #0
0x00355b:	str     	r1, [sp]
0x00355d:	str     	r1, [sp, #4]
0x00355f:	movs    	r2, #0
0x003561:	str     	r2, [sp, #8]
0x003563:	movs    	r1, #0x3f
0x003565:	movs    	r3, #0
0x003567:	movs    	r0, #0xf1
0x003569:	lsls    	r0, r0, #9
0x00356b:	ldr     	r2, [r4, #0x20]
0x00356d:	bl      	#0x5159
; block 0x3571
0x003571:	movs    	r2, #0
0x003573:	str     	r2, [sp, #8]
0x003575:	ldr     	r2, [pc, #0x174]
0x003577:	str     	r0, [sp, #0x44]
0x003579:	str     	r6, [sp, #4]
0x00357b:	adds    	r3, r0, #0
0x00357d:	str     	r5, [sp]
0x00357f:	add     	r2, pc
0x003581:	movs    	r1, #0x3c
0x003583:	movs    	r0, #0xf1
0x003585:	lsls    	r0, r0, #9
0x003587:	bl      	#0x5159
; block 0x358b
0x00358b:	movs    	r1, #0
0x00358d:	str     	r1, [sp, #4]
0x00358f:	movs    	r2, #0
0x003591:	str     	r1, [sp]
0x003593:	movs    	r1, #9
0x003595:	str     	r2, [sp, #8]
0x003597:	movs    	r3, #0
0x003599:	movs    	r0, #0xf1
0x00359b:	lsls    	r0, r0, #9
0x00359d:	ldr     	r2, [sp, #0x44]
0x00359f:	bl      	#0x5159
; block 0x35a3
0x0035a3:	ldr     	r0, [sp, #0x64]
0x0035a5:	adds    	r6, r6, r0
0x0035a7:	adds    	r6, #5
0x0035a9:	cmp     	r6, r7
0x0035ab:	ble     	#0x35f7
; block 0x35ad
0x0035ad:	movs    	r1, #0
0x0035af:	str     	r1, [sp]
0x0035b1:	str     	r1, [sp, #4]
0x0035b3:	movs    	r2, #0
0x0035b5:	str     	r2, [sp, #8]
0x0035b7:	movs    	r1, #0x3f
0x0035b9:	movs    	r3, #0
0x0035bb:	movs    	r0, #0xf1
0x0035bd:	lsls    	r0, r0, #9
0x0035bf:	ldr     	r2, [r4, #8]
0x0035c1:	bl      	#0x5159
; block 0x35c5
0x0035c5:	movs    	r2, #0
0x0035c7:	str     	r2, [sp, #8]
0x0035c9:	ldr     	r2, [pc, #0x124]
0x0035cb:	str     	r0, [sp, #0x44]
0x0035cd:	str     	r6, [sp, #4]
0x0035cf:	adds    	r3, r0, #0
0x0035d1:	str     	r5, [sp]
0x0035d3:	add     	r2, pc
0x0035d5:	movs    	r1, #0x3c
0x0035d7:	movs    	r0, #0xf1
0x0035d9:	lsls    	r0, r0, #9
0x0035db:	bl      	#0x5159
; block 0x35df
0x0035df:	movs    	r1, #0
0x0035e1:	str     	r1, [sp, #4]
0x0035e3:	movs    	r2, #0
0x0035e5:	str     	r1, [sp]
0x0035e7:	movs    	r1, #9
0x0035e9:	str     	r2, [sp, #8]
0x0035eb:	movs    	r3, #0
0x0035ed:	movs    	r0, #0xf1
0x0035ef:	lsls    	r0, r0, #9
0x0035f1:	ldr     	r2, [sp, #0x44]
0x0035f3:	bl      	#0x5159
; block 0x35f7
0x0035f7:	ldr     	r0, [sp, #0x64]
0x0035f9:	adds    	r6, r6, r0
0x0035fb:	adds    	r6, #5
0x0035fd:	cmp     	r6, r7
0x0035ff:	ble     	#0x364b
; block 0x3601
0x003601:	movs    	r1, #0
0x003603:	str     	r1, [sp]
0x003605:	str     	r1, [sp, #4]
0x003607:	movs    	r2, #0
0x003609:	str     	r2, [sp, #8]
0x00360b:	movs    	r1, #0x3f
0x00360d:	movs    	r3, #0
0x00360f:	movs    	r0, #0xf1
0x003611:	lsls    	r0, r0, #9
0x003613:	ldr     	r2, [r4, #0x18]
0x003615:	bl      	#0x5159
; block 0x3619
0x003619:	movs    	r2, #0
0x00361b:	str     	r2, [sp, #8]
0x00361d:	ldr     	r2, [pc, #0xd4]
0x00361f:	str     	r0, [sp, #0x44]
0x003621:	str     	r6, [sp, #4]
0x003623:	adds    	r3, r0, #0
0x003625:	str     	r5, [sp]
0x003627:	add     	r2, pc
0x003629:	movs    	r1, #0x3c
0x00362b:	movs    	r0, #0xf1
0x00362d:	lsls    	r0, r0, #9
0x00362f:	bl      	#0x5159
; block 0x3633
0x003633:	movs    	r1, #0
0x003635:	str     	r1, [sp, #4]
0x003637:	movs    	r2, #0
0x003639:	str     	r1, [sp]
0x00363b:	movs    	r1, #9
0x00363d:	str     	r2, [sp, #8]
0x00363f:	movs    	r3, #0
0x003641:	movs    	r0, #0xf1
0x003643:	lsls    	r0, r0, #9
0x003645:	ldr     	r2, [sp, #0x44]
0x003647:	bl      	#0x5159
; block 0x364b
0x00364b:	ldr     	r0, [sp, #0x64]
0x00364d:	adds    	r1, r6, r0
0x00364f:	adds    	r1, #5
0x003651:	cmp     	r1, r7
0x003653:	ble     	#0x3739
; block 0x3655
0x003655:	movs    	r2, #0
0x003657:	str     	r2, [sp, #8]
0x003659:	ldr     	r2, [pc, #0x9c]
0x00365b:	str     	r5, [sp]
0x00365d:	str     	r1, [sp, #4]
0x00365f:	add     	r2, pc
0x003661:	movs    	r1, #0x3c
0x003663:	movs    	r0, #0xf1
0x003665:	lsls    	r0, r0, #9
0x003667:	ldr     	r3, [r4, #0x28]
0x003669:	bl      	#0x5159
; block 0x366d
0x00366d:	b       	#0x3739
; block 0x366f
0x00366f:	ldr     	r5, [pc, #0x8c]
0x003671:	add     	r5, pc
0x003673:	ldr     	r0, [sp, #0x58]
0x003675:	str     	r4, [sp, #0x40]
0x003677:	str     	r0, [sp, #0x28]
0x003679:	ldr     	r0, [sp, #0x54]
0x00367b:	ldr     	r1, [sp, #0x48]
0x00367d:	adds    	r0, r6, r0
0x00367f:	adds    	r6, r0, r1
0x003681:	adds    	r0, r6, #0
0x003683:	ldr     	r1, [sp, #0x50]
0x003685:	adds    	r0, #0xa
0x003687:	str     	r0, [sp, #0x2c]
0x003689:	str     	r1, [sp, #0x30]
0x00368b:	movs    	r1, #0
0x00368d:	ldr     	r0, [sp, #0x4c]
0x00368f:	str     	r4, [sp, #0x44]
0x003691:	movs    	r2, #0
0x003693:	str     	r1, [sp, #4]
0x003695:	str     	r1, [sp]
0x003697:	str     	r0, [sp, #0x34]
0x003699:	movs    	r0, #0xf1
0x00369b:	movs    	r1, #0x3a
0x00369d:	str     	r2, [sp, #8]
0x00369f:	adds    	r3, r4, #0
0x0036a1:	lsls    	r0, r0, #9
0x0036a3:	add     	r2, sp, #0x28
0x0036a5:	str     	r4, [sp, #0x38]
0x0036a7:	str     	r4, [sp, #0x3c]
0x0036a9:	bl      	#0x5159
; block 0x36ad
0x0036ad:	movs    	r1, #0
0x0036af:	movs    	r2, #0
0x0036b1:	str     	r2, [sp, #8]
0x0036b3:	str     	r1, [sp]
0x0036b5:	str     	r1, [sp, #4]
0x0036b7:	movs    	r1, #0xe1
0x0036b9:	movs    	r2, #0x28
0x0036bb:	adds    	r3, r4, #0
0x0036bd:	movs    	r0, #0xf1
0x0036bf:	lsls    	r0, r0, #9
0x0036c1:	bl      	#0x5159
; block 0x36c5
0x0036c5:	adds    	r7, r0, #0
0x0036c7:	movs    	r2, #0
0x0036c9:	movs    	r1, #0
0x0036cb:	str     	r1, [sp]
0x0036cd:	str     	r1, [sp, #4]
0x0036cf:	b       	#0x3701
; block 0x3701
0x003701:	str     	r2, [sp, #8]
0x003703:	movs    	r2, #0x29
0x003705:	adds    	r3, r4, #0
0x003707:	movs    	r1, #0xe1
0x003709:	movs    	r0, #0xf1
0x00370b:	lsls    	r0, r0, #9
0x00370d:	bl      	#0x5159
; block 0x3711
0x003711:	adds    	r3, r0, #0
0x003713:	add     	r2, sp, #0x64
0x003715:	add     	r1, sp, #0x68
0x003717:	str     	r1, [sp, #4]
0x003719:	str     	r2, [sp, #8]
0x00371b:	adds    	r2, r5, #0
0x00371d:	movs    	r1, #0x2a
0x00371f:	movs    	r0, #0xf1
0x003721:	lsls    	r0, r0, #9
0x003723:	str     	r7, [sp]
0x003725:	bl      	#0x5159
; block 0x3729
0x003729:	movs    	r1, #0
0x00372b:	movs    	r2, #0
0x00372d:	str     	r5, [sp, #0x28]
0x00372f:	str     	r2, [sp, #8]
0x003731:	adds    	r3, r4, #0
0x003733:	str     	r1, [sp]
0x003735:	str     	r1, [sp, #4]
0x003737:	b       	#0x373b
; block 0x3739
0x003739:	b       	#0x3777
; block 0x373b
0x00373b:	movs    	r1, #0x1c
0x00373d:	movs    	r0, #0xf1
0x00373f:	lsls    	r0, r0, #9
0x003741:	bl      	#0x5159
; block 0x3745
0x003745:	ldr     	r1, [sp, #0x68]
0x003747:	adds    	r6, #0x14
0x003749:	subs    	r0, r0, r1
0x00374b:	asrs    	r0, r0, #1
0x00374d:	str     	r0, [sp, #0x2c]
0x00374f:	movs    	r0, #0xff
0x003751:	str     	r0, [sp, #0x34]
0x003753:	str     	r0, [sp, #0x38]
0x003755:	movs    	r1, #0
0x003757:	movs    	r0, #0xc8
0x003759:	str     	r4, [sp, #0x40]
0x00375b:	str     	r4, [sp, #0x44]
0x00375d:	movs    	r2, #0
0x00375f:	str     	r1, [sp, #4]
0x003761:	str     	r1, [sp]
0x003763:	str     	r0, [sp, #0x3c]
0x003765:	movs    	r0, #0xf1
0x003767:	movs    	r1, #0x56
0x003769:	str     	r2, [sp, #8]
0x00376b:	adds    	r3, r4, #0
0x00376d:	lsls    	r0, r0, #9
0x00376f:	add     	r2, sp, #0x28
0x003771:	str     	r6, [sp, #0x30]
0x003773:	bl      	#0x5159
; block 0x3777
0x003777:	movs    	r1, #0
0x003779:	movs    	r2, #0
0x00377b:	str     	r2, [sp, #8]
0x00377d:	str     	r1, [sp]
0x00377f:	str     	r1, [sp, #4]
0x003781:	movs    	r1, #0x24
0x003783:	movs    	r2, #1
0x003785:	movs    	r3, #1
0x003787:	movs    	r0, #0xf1
0x003789:	lsls    	r0, r0, #9
0x00378b:	bl      	#0x5159
; block 0x378f
0x00378f:	add     	sp, #0x84
0x003791:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_32b1 @ 0x32b1 offset=0x32b0 size=8 blocks=1 cc=1 =====
; block 0x32b1
0x0032b1:	subs    	r4, #0x5a
0x0032b3:	movs    	r0, r0
0x0032b5:	movs    	r4, r1
0x0032b7:	movs    	r0, r0
0x0032b9:	cmp     	r0, r1
0x0032bb:	bge     	#0x32df

; ===== sub_3795 @ 0x3795 offset=0x3794 size=2144 blocks=102 cc=85 =====
; block 0x3795
0x003795:	push    	{r4, r5, r6, r7, lr}
0x003797:	sub     	sp, #0x84
0x003799:	movs    	r1, #0x5a
0x00379b:	str     	r1, [sp, #0x6c]
0x00379d:	movs    	r1, #0
0x00379f:	str     	r1, [sp]
0x0037a1:	str     	r1, [sp, #4]
0x0037a3:	movs    	r5, #0xf1
0x0037a5:	movs    	r4, #0
0x0037a7:	movs    	r2, #0
0x0037a9:	adds    	r3, r4, #0
0x0037ab:	lsls    	r5, r5, #9
0x0037ad:	movs    	r1, #0x1c
0x0037af:	movs    	r6, #0x19
0x0037b1:	adds    	r0, r5, #0
0x0037b3:	str     	r2, [sp, #8]
0x0037b5:	bl      	#0x5159
; block 0x37b9
0x0037b9:	movs    	r1, #0
0x0037bb:	str     	r1, [sp]
0x0037bd:	str     	r1, [sp, #4]
0x0037bf:	movs    	r1, #0xff
0x0037c1:	movs    	r2, #0
0x0037c3:	adds    	r1, #0x26
0x0037c5:	adds    	r7, r0, #0
0x0037c7:	adds    	r3, r4, #0
0x0037c9:	adds    	r0, r5, #0
0x0037cb:	str     	r2, [sp, #8]
0x0037cd:	bl      	#0x5159
; block 0x37d1
0x0037d1:	movs    	r1, #0
0x0037d3:	movs    	r2, #0
0x0037d5:	str     	r2, [sp, #8]
0x0037d7:	str     	r1, [sp]
0x0037d9:	str     	r1, [sp, #4]
0x0037db:	movs    	r1, #0xe1
0x0037dd:	movs    	r2, #0xed
0x0037df:	adds    	r3, r4, #0
0x0037e1:	adds    	r0, r5, #0
0x0037e3:	bl      	#0x5159
; block 0x37e7
0x0037e7:	cmp     	r0, #0
0x0037e9:	ble     	#0x38cf
; block 0x37eb
0x0037eb:	movs    	r1, #0
0x0037ed:	str     	r1, [sp]
0x0037ef:	str     	r1, [sp, #4]
0x0037f1:	movs    	r1, #0xff
0x0037f3:	movs    	r2, #0
0x0037f5:	adds    	r1, #0x25
0x0037f7:	adds    	r3, r4, #0
0x0037f9:	adds    	r0, r5, #0
0x0037fb:	str     	r2, [sp, #8]
0x0037fd:	bl      	#0x5159
; block 0x3801
0x003801:	movs    	r2, #0
0x003803:	movs    	r1, #0
0x003805:	str     	r1, [sp, #4]
0x003807:	str     	r2, [sp, #8]
0x003809:	movs    	r0, #0x2e
0x00380b:	str     	r0, [sp]
0x00380d:	movs    	r2, #0x18
0x00380f:	movs    	r1, #0x40
0x003811:	movs    	r3, #0x2e
0x003813:	adds    	r0, r5, #0
0x003815:	bl      	#0x5159
; block 0x3819
0x003819:	ldr     	r5, [pc, #0x3dc]
0x00381b:	add     	r5, pc
0x00381d:	movs    	r1, #0
0x00381f:	movs    	r2, #0
0x003821:	str     	r2, [sp, #8]
0x003823:	str     	r1, [sp]
0x003825:	str     	r1, [sp, #4]
0x003827:	movs    	r1, #0xe1
0x003829:	movs    	r2, #0x28
0x00382b:	adds    	r3, r4, #0
0x00382d:	movs    	r0, #0xf1
0x00382f:	lsls    	r0, r0, #9
0x003831:	bl      	#0x5159
; block 0x3835
0x003835:	movs    	r1, #0
0x003837:	movs    	r2, #0
0x003839:	str     	r2, [sp, #8]
0x00383b:	str     	r1, [sp]
0x00383d:	str     	r1, [sp, #4]
0x00383f:	str     	r0, [sp, #0x4c]
0x003841:	movs    	r0, #0xf1
0x003843:	movs    	r1, #0xe1
0x003845:	movs    	r2, #0x29
0x003847:	adds    	r3, r4, #0
0x003849:	lsls    	r0, r0, #9
0x00384b:	bl      	#0x5159
; block 0x384f
0x00384f:	adds    	r3, r0, #0
0x003851:	ldr     	r0, [sp, #0x4c]
0x003853:	add     	r2, sp, #0x70
0x003855:	add     	r1, sp, #0x74
0x003857:	str     	r1, [sp, #4]
0x003859:	str     	r2, [sp, #8]
0x00385b:	str     	r0, [sp]
0x00385d:	movs    	r0, #0xf1
0x00385f:	adds    	r2, r5, #0
0x003861:	movs    	r1, #0x2a
0x003863:	lsls    	r0, r0, #9
0x003865:	bl      	#0x5159
; block 0x3869
0x003869:	movs    	r1, #0
0x00386b:	movs    	r2, #0
0x00386d:	str     	r2, [sp, #8]
0x00386f:	str     	r1, [sp]
0x003871:	str     	r1, [sp, #4]
0x003873:	movs    	r1, #0xe1
0x003875:	movs    	r2, #0x2a
0x003877:	adds    	r3, r4, #0
0x003879:	movs    	r0, #0xf1
0x00387b:	lsls    	r0, r0, #9
0x00387d:	bl      	#0x5159
; block 0x3881
0x003881:	ldr     	r1, [sp, #0x70]
0x003883:	adds    	r3, r0, r1
0x003885:	movs    	r1, #0
0x003887:	movs    	r0, #0
0x003889:	str     	r3, [sp, #0x68]
0x00388b:	bl      	#0x23fd
; block 0x388f
0x00388f:	movs    	r1, #0
0x003891:	str     	r1, [sp]
0x003893:	str     	r1, [sp, #4]
0x003895:	movs    	r2, #0
0x003897:	movs    	r1, #0x1c
0x003899:	str     	r5, [sp, #0x28]
0x00389b:	adds    	r3, r4, #0
0x00389d:	movs    	r0, #0xf1
0x00389f:	lsls    	r0, r0, #9
0x0038a1:	str     	r2, [sp, #8]
0x0038a3:	bl      	#0x5159
; block 0x38a7
0x0038a7:	ldr     	r1, [sp, #0x74]
0x0038a9:	movs    	r2, #0
0x0038ab:	subs    	r0, r0, r1
0x0038ad:	lsrs    	r1, r0, #0x1f
0x0038af:	adds    	r0, r1, r0
0x0038b1:	movs    	r1, #0
0x0038b3:	asrs    	r0, r0, #1
0x0038b5:	str     	r0, [sp, #0x2c]
0x0038b7:	str     	r1, [sp]
0x0038b9:	str     	r1, [sp, #4]
0x0038bb:	str     	r2, [sp, #8]
0x0038bd:	movs    	r2, #0x2a
0x0038bf:	movs    	r1, #0xe1
0x0038c1:	movs    	r0, #0xf1
0x0038c3:	adds    	r3, r4, #0
0x0038c5:	lsls    	r0, r0, #9
0x0038c7:	bl      	#0x5159
; block 0x38cb
0x0038cb:	lsrs    	r1, r0, #0x1f
0x0038cd:	b       	#0x38d1
; block 0x38cf
0x0038cf:	b       	#0x400f
; block 0x38d1
0x0038d1:	adds    	r0, r1, r0
0x0038d3:	asrs    	r0, r0, #1
0x0038d5:	adds    	r0, #2
0x0038d7:	str     	r0, [sp, #0x30]
0x0038d9:	movs    	r0, #0xff
0x0038db:	str     	r0, [sp, #0x3c]
0x0038dd:	str     	r0, [sp, #0x40]
0x0038df:	str     	r0, [sp, #0x44]
0x0038e1:	movs    	r0, #1
0x0038e3:	add     	r1, sp, #0x48
0x0038e5:	str     	r4, [sp, #0x34]
0x0038e7:	str     	r4, [sp, #0x38]
0x0038e9:	strb    	r0, [r1]
0x0038eb:	movs    	r1, #0
0x0038ed:	movs    	r2, #0
0x0038ef:	str     	r1, [sp]
0x0038f1:	str     	r1, [sp, #4]
0x0038f3:	str     	r0, [sp, #0x4c]
0x0038f5:	movs    	r0, #0xf1
0x0038f7:	movs    	r1, #0x25
0x0038f9:	str     	r2, [sp, #8]
0x0038fb:	adds    	r3, r4, #0
0x0038fd:	lsls    	r0, r0, #9
0x0038ff:	add     	r2, sp, #0x28
0x003901:	bl      	#0x5159
; block 0x3905
0x003905:	movs    	r1, #0
0x003907:	str     	r1, [sp]
0x003909:	str     	r1, [sp, #4]
0x00390b:	movs    	r2, #0
0x00390d:	movs    	r1, #0x1d
0x00390f:	adds    	r3, r4, #0
0x003911:	movs    	r0, #0xf1
0x003913:	lsls    	r0, r0, #9
0x003915:	str     	r2, [sp, #8]
0x003917:	bl      	#0x5159
; block 0x391b
0x00391b:	ldr     	r3, [sp, #0x68]
0x00391d:	movs    	r2, #0
0x00391f:	subs    	r1, r0, r3
0x003921:	subs    	r1, #0x5a
0x003923:	str     	r1, [sp, #0x54]
0x003925:	movs    	r1, #0
0x003927:	ldr     	r0, [pc, #0x2d4]
0x003929:	str     	r1, [sp]
0x00392b:	str     	r1, [sp, #4]
0x00392d:	str     	r2, [sp, #8]
0x00392f:	add     	r0, sb
0x003931:	ldr     	r2, [r0, #0xc]
0x003933:	movs    	r0, #0xf1
0x003935:	movs    	r1, #0x26
0x003937:	adds    	r3, r4, #0
0x003939:	lsls    	r0, r0, #9
0x00393b:	bl      	#0x5159
; block 0x393f
0x00393f:	movs    	r1, #0
0x003941:	adds    	r5, r0, #0
0x003943:	str     	r1, [sp]
0x003945:	str     	r1, [sp, #4]
0x003947:	movs    	r2, #0
0x003949:	movs    	r1, #0x1c
0x00394b:	movs    	r0, #0xf1
0x00394d:	adds    	r3, r4, #0
0x00394f:	lsls    	r0, r0, #9
0x003951:	str     	r2, [sp, #8]
0x003953:	bl      	#0x5159
; block 0x3957
0x003957:	subs    	r0, #0xc
0x003959:	mov     	ip, r0
0x00395b:	ldr     	r0, [pc, #0x2a0]
0x00395d:	movs    	r1, #0x3b
0x00395f:	add     	r0, sb
0x003961:	ldr     	r2, [r0, #0x7c]
0x003963:	ldr     	r0, [sp, #0x54]
0x003965:	str     	r2, [sp, #8]
0x003967:	str     	r0, [sp]
0x003969:	movs    	r0, #0xf1
0x00396b:	lsls    	r0, r0, #9
0x00396d:	ldr     	r3, [sp, #0x68]
0x00396f:	mov     	r2, ip
0x003971:	str     	r5, [sp, #4]
0x003973:	bl      	#0x5159
; block 0x3977
0x003977:	movs    	r1, #0
0x003979:	subs    	r7, #0xc
0x00397b:	movs    	r2, #0
0x00397d:	str     	r2, [sp, #8]
0x00397f:	str     	r1, [sp]
0x003981:	str     	r1, [sp, #4]
0x003983:	movs    	r1, #0xe1
0x003985:	movs    	r2, #0x2d
0x003987:	adds    	r3, r4, #0
0x003989:	movs    	r0, #0xf1
0x00398b:	lsls    	r0, r0, #9
0x00398d:	str     	r7, [sp, #0x50]
0x00398f:	bl      	#0x5159
; block 0x3993
0x003993:	movs    	r1, #0
0x003995:	movs    	r2, #0
0x003997:	str     	r2, [sp, #8]
0x003999:	str     	r1, [sp]
0x00399b:	str     	r1, [sp, #4]
0x00399d:	str     	r0, [sp, #0x74]
0x00399f:	movs    	r0, #0xf1
0x0039a1:	movs    	r1, #0xe1
0x0039a3:	movs    	r2, #0x2e
0x0039a5:	adds    	r3, r4, #0
0x0039a7:	lsls    	r0, r0, #9
0x0039a9:	bl      	#0x5159
; block 0x39ad
0x0039ad:	ldr     	r1, [sp, #0x54]
0x0039af:	str     	r0, [sp, #0x70]
0x0039b1:	subs    	r1, #0x14
0x0039b3:	adds    	r0, r6, #0
0x0039b5:	blx     	#0x20
; block 0x39b9
0x0039b9:	adds    	r4, r0, #0
0x0039bb:	ldr     	r0, [pc, #0x240]
0x0039bd:	str     	r5, [sp, #0x60]
0x0039bf:	add     	r0, sb
0x0039c1:	ldr     	r1, [r0, #0x7c]
0x0039c3:	adds    	r0, r4, #0
0x0039c5:	blx     	#0x20
; block 0x39c9
0x0039c9:	muls    	r0, r4, r0
0x0039cb:	str     	r0, [sp, #0x5c]
0x0039cd:	ldr     	r1, [sp, #0x5c]
0x0039cf:	ldr     	r0, [sp, #0x60]
0x0039d1:	adds    	r1, r1, r4
0x0039d3:	cmp     	r1, r0
0x0039d5:	bge     	#0x39d9
; block 0x39d7
0x0039d7:	adds    	r0, r1, #0
0x0039d9:	ldr     	r5, [sp, #0x68]
0x0039db:	ldr     	r4, [sp, #0x5c]
0x0039dd:	adds    	r5, #0xa
0x0039df:	cmp     	r4, r0
0x0039e1:	str     	r0, [sp, #0x58]
0x0039e3:	bge     	#0x3ac9
; block 0x39d9
0x0039d9:	ldr     	r5, [sp, #0x68]
0x0039db:	ldr     	r4, [sp, #0x5c]
0x0039dd:	adds    	r5, #0xa
0x0039df:	cmp     	r4, r0
0x0039e1:	str     	r0, [sp, #0x58]
0x0039e3:	bge     	#0x3ac9
; block 0x39e5
0x0039e5:	add     	r1, sp, #0x2c
0x0039e7:	str     	r1, [sp, #0x80]
0x0039e9:	movs    	r1, #0
0x0039eb:	str     	r1, [sp]
0x0039ed:	str     	r1, [sp, #4]
0x0039ef:	ldr     	r1, [pc, #0x20c]
0x0039f1:	movs    	r2, #0
0x0039f3:	str     	r2, [sp, #8]
0x0039f5:	add     	r1, sb
0x0039f7:	ldr     	r2, [r1, #0xc]
0x0039f9:	movs    	r1, #0x27
0x0039fb:	adds    	r3, r4, #0
0x0039fd:	movs    	r0, #0xf1
0x0039ff:	lsls    	r0, r0, #9
0x003a01:	bl      	#0x5159
; block 0x39e9
0x0039e9:	movs    	r1, #0
0x0039eb:	str     	r1, [sp]
0x0039ed:	str     	r1, [sp, #4]
0x0039ef:	ldr     	r1, [pc, #0x20c]
0x0039f1:	movs    	r2, #0
0x0039f3:	str     	r2, [sp, #8]
0x0039f5:	add     	r1, sb
0x0039f7:	ldr     	r2, [r1, #0xc]
0x0039f9:	movs    	r1, #0x27
0x0039fb:	adds    	r3, r4, #0
0x0039fd:	movs    	r0, #0xf1
0x0039ff:	lsls    	r0, r0, #9
0x003a01:	bl      	#0x5159
; block 0x3a05
0x003a05:	movs    	r1, #0
0x003a07:	str     	r1, [sp]
0x003a09:	str     	r1, [sp, #4]
0x003a0b:	movs    	r2, #0
0x003a0d:	str     	r2, [sp, #8]
0x003a0f:	movs    	r3, #9
0x003a11:	ldrsb   	r2, [r0, r3]
0x003a13:	adds    	r7, r0, #0
0x003a15:	movs    	r0, #0xf1
0x003a17:	movs    	r3, #0
0x003a19:	movs    	r1, #0x3f
0x003a1b:	lsls    	r0, r0, #9
0x003a1d:	bl      	#0x5159
; block 0x3a21
0x003a21:	str     	r0, [sp, #0x4c]
0x003a23:	ldr     	r3, [r7]
0x003a25:	movs    	r2, #0
0x003a27:	movs    	r1, #0
0x003a29:	str     	r3, [sp, #0x48]
0x003a2b:	ldr     	r3, [pc, #0x1d4]
0x003a2d:	str     	r2, [sp, #8]
0x003a2f:	str     	r1, [sp]
0x003a31:	str     	r1, [sp, #4]
0x003a33:	add     	r3, pc
0x003a35:	adds    	r2, r0, #0
0x003a37:	movs    	r0, #0xf1
0x003a39:	movs    	r1, #0x2d
0x003a3b:	lsls    	r0, r0, #9
0x003a3d:	bl      	#0x5159
; block 0x3a41
0x003a41:	movs    	r2, #0
0x003a43:	movs    	r1, #0
0x003a45:	ldr     	r3, [pc, #0x1bc]
0x003a47:	str     	r1, [sp]
0x003a49:	str     	r1, [sp, #4]
0x003a4b:	str     	r2, [sp, #8]
0x003a4d:	add     	r3, pc
0x003a4f:	adds    	r2, r0, #0
0x003a51:	movs    	r0, #0xf1
0x003a53:	movs    	r1, #0x2d
0x003a55:	lsls    	r0, r0, #9
0x003a57:	bl      	#0x5159
; block 0x3a5b
0x003a5b:	movs    	r2, #0
0x003a5d:	str     	r2, [sp, #8]
0x003a5f:	movs    	r1, #0
0x003a61:	str     	r1, [sp]
0x003a63:	str     	r1, [sp, #4]
0x003a65:	adds    	r2, r0, #0
0x003a67:	movs    	r0, #0xf1
0x003a69:	movs    	r1, #0x2d
0x003a6b:	lsls    	r0, r0, #9
0x003a6d:	ldr     	r3, [sp, #0x48]
0x003a6f:	bl      	#0x5159
; block 0x3a73
0x003a73:	movs    	r2, #0
0x003a75:	movs    	r1, #0
0x003a77:	ldr     	r3, [pc, #0x190]
0x003a79:	str     	r1, [sp]
0x003a7b:	str     	r1, [sp, #4]
0x003a7d:	str     	r2, [sp, #8]
0x003a7f:	add     	r3, pc
0x003a81:	adds    	r2, r0, #0
0x003a83:	movs    	r0, #0xf1
0x003a85:	movs    	r1, #0x2d
0x003a87:	lsls    	r0, r0, #9
0x003a89:	bl      	#0x5159
; block 0x3a8d
0x003a8d:	str     	r0, [sp, #0x44]
0x003a8f:	movs    	r1, #0
0x003a91:	movs    	r2, #0
0x003a93:	str     	r1, [sp]
0x003a95:	str     	r1, [sp, #4]
0x003a97:	movs    	r1, #9
0x003a99:	str     	r2, [sp, #8]
0x003a9b:	movs    	r0, #0xf1
0x003a9d:	movs    	r3, #0
0x003a9f:	lsls    	r0, r0, #9
0x003aa1:	ldr     	r2, [sp, #0x4c]
0x003aa3:	bl      	#0x5159
; block 0x3aa7
0x003aa7:	movs    	r0, #0xa
0x003aa9:	str     	r0, [sp, #0x64]
0x003aab:	ldr     	r0, [sp, #0x50]
0x003aad:	subs    	r3, r5, #5
0x003aaf:	movs    	r2, #0
0x003ab1:	str     	r0, [sp]
0x003ab3:	movs    	r0, #0xf1
0x003ab5:	movs    	r1, #0x2e
0x003ab7:	lsls    	r0, r0, #9
0x003ab9:	str     	r2, [sp, #8]
0x003abb:	str     	r3, [sp, #0x7c]
0x003abd:	str     	r3, [sp, #0x78]
0x003abf:	str     	r6, [sp, #4]
0x003ac1:	bl      	#0x5159
; block 0x3ac5
0x003ac5:	movs    	r2, #0
0x003ac7:	b       	#0x3acb
; block 0x3ac9
0x003ac9:	b       	#0x3d39
; block 0x3acb
0x003acb:	ldr     	r0, [sp, #0x50]
0x003acd:	movs    	r1, #0x2f
0x003acf:	str     	r0, [sp]
0x003ad1:	movs    	r0, #0xf1
0x003ad3:	lsls    	r0, r0, #9
0x003ad5:	str     	r6, [sp, #4]
0x003ad7:	str     	r2, [sp, #8]
0x003ad9:	ldr     	r3, [sp, #0x78]
0x003adb:	bl      	#0x5159
; block 0x3adf
0x003adf:	cmp     	r0, #1
0x003ae1:	bne     	#0x3b09
; block 0x3ae3
0x003ae3:	ldr     	r1, [pc, #0x118]
0x003ae5:	add     	r1, sb
0x003ae7:	ldr     	r0, [r1, #0x7c]
0x003ae9:	cmp     	r0, r4
0x003aeb:	bne     	#0x3b07
; block 0x3aed
0x003aed:	ldr     	r0, [sp, #0x7c]
0x003aef:	ldr     	r1, [sp, #0x50]
0x003af1:	str     	r0, [sp]
0x003af3:	str     	r1, [sp, #4]
0x003af5:	movs    	r1, #0x23
0x003af7:	movs    	r0, #0xf1
0x003af9:	movs    	r3, #0
0x003afb:	movs    	r2, #4
0x003afd:	lsls    	r0, r0, #9
0x003aff:	str     	r6, [sp, #8]
0x003b01:	bl      	#0x5159
; block 0x3b05
0x003b05:	b       	#0x3b09
; block 0x3b07
0x003b07:	str     	r4, [r1, #0x7c]
0x003b09:	ldr     	r1, [pc, #0xf0]
0x003b0b:	add     	r1, sb
0x003b0d:	ldr     	r0, [r1, #0x7c]
0x003b0f:	cmp     	r0, r4
0x003b11:	bne     	#0x3b29
; block 0x3b09
0x003b09:	ldr     	r1, [pc, #0xf0]
0x003b0b:	add     	r1, sb
0x003b0d:	ldr     	r0, [r1, #0x7c]
0x003b0f:	cmp     	r0, r4
0x003b11:	bne     	#0x3b29
; block 0x3b13
0x003b13:	ldr     	r0, [sp, #0x50]
0x003b15:	movs    	r2, #0
0x003b17:	str     	r0, [sp]
0x003b19:	movs    	r0, #0xf1
0x003b1b:	movs    	r1, #0x30
0x003b1d:	lsls    	r0, r0, #9
0x003b1f:	str     	r2, [sp, #8]
0x003b21:	str     	r6, [sp, #4]
0x003b23:	ldr     	r3, [sp, #0x7c]
0x003b25:	bl      	#0x5159
; block 0x3b29
0x003b29:	ldr     	r0, [r7, #0x10]
0x003b2b:	str     	r0, [sp, #0x3c]
0x003b2d:	ldr     	r0, [r7, #0x14]
0x003b2f:	str     	r0, [sp, #0x38]
0x003b31:	ldr     	r0, [r7, #0x18]
0x003b33:	str     	r0, [sp, #0x34]
0x003b35:	ldr     	r0, [r7, #0xc]
0x003b37:	str     	r0, [sp, #0x40]
0x003b39:	ldrb    	r0, [r7, #8]
0x003b3b:	cmp     	r0, #4
0x003b3d:	bne     	#0x3b51
; block 0x3b3f
0x003b3f:	movs    	r0, #0xff
0x003b41:	str     	r0, [sp, #0x3c]
0x003b43:	movs    	r0, #0
0x003b45:	str     	r0, [sp, #0x38]
0x003b47:	str     	r0, [sp, #0x34]
0x003b49:	ldr     	r0, [pc, #0xc0]
0x003b4b:	add     	r0, pc
0x003b4d:	str     	r0, [sp, #0x40]
0x003b4f:	b       	#0x3b63
; block 0x3b51
0x003b51:	cmp     	r0, #0
0x003b53:	bne     	#0x3b63
; block 0x3b55
0x003b55:	movs    	r0, #0x96
0x003b57:	str     	r0, [sp, #0x3c]
0x003b59:	str     	r0, [sp, #0x38]
0x003b5b:	str     	r0, [sp, #0x34]
0x003b5d:	ldr     	r0, [pc, #0xb0]
0x003b5f:	add     	r0, pc
0x003b61:	str     	r0, [sp, #0x40]
0x003b63:	ldr     	r0, [sp, #0x44]
0x003b65:	movs    	r1, #0
0x003b67:	str     	r0, [sp, #0x14]
0x003b69:	ldr     	r0, [sp, #0x64]
0x003b6b:	movs    	r2, #0
0x003b6d:	str     	r0, [sp, #0x18]
0x003b6f:	movs    	r0, #0xff
0x003b71:	str     	r0, [sp, #0x20]
0x003b73:	str     	r0, [sp, #0x24]
0x003b75:	movs    	r0, #0xc8
0x003b77:	str     	r0, [sp, #0x28]
0x003b79:	str     	r2, [sp, #8]
0x003b7b:	str     	r1, [sp, #4]
0x003b7d:	str     	r1, [sp]
0x003b7f:	movs    	r1, #0xe1
0x003b81:	movs    	r2, #0x29
0x003b83:	movs    	r0, #0xf1
0x003b85:	movs    	r3, #0
0x003b87:	lsls    	r0, r0, #9
0x003b89:	str     	r5, [sp, #0x1c]
0x003b8b:	bl      	#0x5159
; block 0x3b63
0x003b63:	ldr     	r0, [sp, #0x44]
0x003b65:	movs    	r1, #0
0x003b67:	str     	r0, [sp, #0x14]
0x003b69:	ldr     	r0, [sp, #0x64]
0x003b6b:	movs    	r2, #0
0x003b6d:	str     	r0, [sp, #0x18]
0x003b6f:	movs    	r0, #0xff
0x003b71:	str     	r0, [sp, #0x20]
0x003b73:	str     	r0, [sp, #0x24]
0x003b75:	movs    	r0, #0xc8
0x003b77:	str     	r0, [sp, #0x28]
0x003b79:	str     	r2, [sp, #8]
0x003b7b:	str     	r1, [sp, #4]
0x003b7d:	str     	r1, [sp]
0x003b7f:	movs    	r1, #0xe1
0x003b81:	movs    	r2, #0x29
0x003b83:	movs    	r0, #0xf1
0x003b85:	movs    	r3, #0
0x003b87:	lsls    	r0, r0, #9
0x003b89:	str     	r5, [sp, #0x1c]
0x003b8b:	bl      	#0x5159
; block 0x3b8f
0x003b8f:	movs    	r1, #0
0x003b91:	movs    	r2, #0
0x003b93:	str     	r2, [sp, #8]
0x003b95:	str     	r1, [sp]
0x003b97:	str     	r1, [sp, #4]
0x003b99:	str     	r0, [sp, #0x2c]
0x003b9b:	movs    	r0, #0xf1
0x003b9d:	movs    	r1, #0xe1
0x003b9f:	movs    	r2, #0x28
0x003ba1:	movs    	r3, #0
0x003ba3:	lsls    	r0, r0, #9
0x003ba5:	bl      	#0x5159
; block 0x3ba9
0x003ba9:	movs    	r1, #0
0x003bab:	movs    	r2, #0
0x003bad:	str     	r1, [sp]
0x003baf:	str     	r1, [sp, #4]
0x003bb1:	str     	r0, [sp, #0x30]
0x003bb3:	movs    	r0, #0xf1
0x003bb5:	movs    	r1, #0x56
0x003bb7:	str     	r2, [sp, #8]
0x003bb9:	movs    	r3, #0
0x003bbb:	lsls    	r0, r0, #9
0x003bbd:	add     	r2, sp, #0x14
0x003bbf:	bl      	#0x5159
; block 0x3bc3
0x003bc3:	movs    	r1, #0
0x003bc5:	movs    	r2, #0
0x003bc7:	str     	r2, [sp, #8]
0x003bc9:	str     	r1, [sp]
0x003bcb:	str     	r1, [sp, #4]
0x003bcd:	movs    	r1, #0xe1
0x003bcf:	movs    	r2, #0x28
0x003bd1:	movs    	r3, #0
0x003bd3:	movs    	r0, #0xf1
0x003bd5:	lsls    	r0, r0, #9
0x003bd7:	bl      	#0x5159
; block 0x3bdb
0x003bdb:	movs    	r1, #0
0x003bdd:	movs    	r2, #0
0x003bdf:	str     	r2, [sp, #8]
0x003be1:	str     	r1, [sp]
0x003be3:	str     	r1, [sp, #4]
0x003be5:	adds    	r7, r0, #0
0x003be7:	movs    	r0, #0xf1
0x003be9:	movs    	r1, #0xe1
0x003beb:	movs    	r2, #0x29
0x003bed:	movs    	r3, #0
0x003bef:	lsls    	r0, r0, #9
0x003bf1:	bl      	#0x5159
; block 0x3bf5
0x003bf5:	b       	#0x3c15
; block 0x3c15
0x003c15:	add     	r1, sp, #0x74
0x003c17:	str     	r1, [sp, #4]
0x003c19:	adds    	r3, r0, #0
0x003c1b:	add     	r2, sp, #0x70
0x003c1d:	str     	r2, [sp, #8]
0x003c1f:	movs    	r0, #0xf1
0x003c21:	movs    	r1, #0x2a
0x003c23:	lsls    	r0, r0, #9
0x003c25:	ldr     	r2, [sp, #0x44]
0x003c27:	str     	r7, [sp]
0x003c29:	bl      	#0x5159
; block 0x3c2d
0x003c2d:	ldr     	r0, [sp, #0x74]
0x003c2f:	str     	r5, [sp, #0x1c]
0x003c31:	adds    	r0, #0xf
0x003c33:	str     	r0, [sp, #0x64]
0x003c35:	ldr     	r0, [sp, #0x40]
0x003c37:	movs    	r1, #0
0x003c39:	str     	r0, [sp, #0x14]
0x003c3b:	ldr     	r0, [sp, #0x64]
0x003c3d:	movs    	r2, #0
0x003c3f:	str     	r0, [sp, #0x18]
0x003c41:	ldr     	r0, [sp, #0x3c]
0x003c43:	movs    	r3, #0
0x003c45:	str     	r0, [sp, #0x20]
0x003c47:	ldr     	r0, [sp, #0x38]
0x003c49:	str     	r1, [sp]
0x003c4b:	str     	r0, [sp, #0x24]
0x003c4d:	ldr     	r0, [sp, #0x34]
0x003c4f:	str     	r1, [sp, #4]
0x003c51:	str     	r0, [sp, #0x28]
0x003c53:	str     	r2, [sp, #8]
0x003c55:	movs    	r2, #0x29
0x003c57:	movs    	r0, #0xf1
0x003c59:	movs    	r1, #0xe1
0x003c5b:	lsls    	r0, r0, #9
0x003c5d:	bl      	#0x5159
; block 0x3c61
0x003c61:	movs    	r1, #0
0x003c63:	movs    	r2, #0
0x003c65:	str     	r2, [sp, #8]
0x003c67:	str     	r1, [sp]
0x003c69:	str     	r1, [sp, #4]
0x003c6b:	str     	r0, [sp, #0x2c]
0x003c6d:	movs    	r0, #0xf1
0x003c6f:	movs    	r1, #0xe1
0x003c71:	movs    	r2, #0x28
0x003c73:	movs    	r3, #0
0x003c75:	lsls    	r0, r0, #9
0x003c77:	bl      	#0x5159
; block 0x3c7b
0x003c7b:	movs    	r1, #0
0x003c7d:	movs    	r2, #0
0x003c7f:	str     	r1, [sp]
0x003c81:	str     	r1, [sp, #4]
0x003c83:	str     	r0, [sp, #0x30]
0x003c85:	movs    	r0, #0xf1
0x003c87:	movs    	r1, #0x56
0x003c89:	str     	r2, [sp, #8]
0x003c8b:	movs    	r3, #0
0x003c8d:	lsls    	r0, r0, #9
0x003c8f:	add     	r2, sp, #0x14
0x003c91:	bl      	#0x5159
; block 0x3c95
0x003c95:	movs    	r1, #0
0x003c97:	movs    	r2, #0
0x003c99:	str     	r2, [sp, #8]
0x003c9b:	str     	r1, [sp]
0x003c9d:	str     	r1, [sp, #4]
0x003c9f:	movs    	r1, #0xe1
0x003ca1:	movs    	r2, #0x28
0x003ca3:	movs    	r3, #0
0x003ca5:	movs    	r0, #0xf1
0x003ca7:	lsls    	r0, r0, #9
0x003ca9:	bl      	#0x5159
; block 0x3cad
0x003cad:	movs    	r1, #0
0x003caf:	movs    	r2, #0
0x003cb1:	str     	r2, [sp, #8]
0x003cb3:	str     	r1, [sp]
0x003cb5:	str     	r1, [sp, #4]
0x003cb7:	adds    	r7, r0, #0
0x003cb9:	movs    	r0, #0xf1
0x003cbb:	movs    	r1, #0xe1
0x003cbd:	movs    	r2, #0x29
0x003cbf:	movs    	r3, #0
0x003cc1:	lsls    	r0, r0, #9
0x003cc3:	bl      	#0x5159
; block 0x3cc7
0x003cc7:	add     	r1, sp, #0x74
0x003cc9:	str     	r1, [sp, #4]
0x003ccb:	adds    	r3, r0, #0
0x003ccd:	add     	r2, sp, #0x70
0x003ccf:	str     	r2, [sp, #8]
0x003cd1:	movs    	r0, #0xf1
0x003cd3:	movs    	r1, #0x2a
0x003cd5:	str     	r7, [sp]
0x003cd7:	ldr     	r2, [sp, #0x40]
0x003cd9:	lsls    	r0, r0, #9
0x003cdb:	bl      	#0x5159
; block 0x3cdf
0x003cdf:	ldr     	r0, [sp, #0x64]
0x003ce1:	ldr     	r1, [sp, #0x74]
0x003ce3:	adds    	r0, r0, r1
0x003ce5:	ldr     	r1, [pc, #0x32c]
0x003ce7:	adds    	r0, #0xa
0x003ce9:	add     	r1, sb
0x003ceb:	ldr     	r1, [r1, #4]
0x003ced:	adds    	r3, r1, #1
0x003cef:	beq     	#0x3d2d
; block 0x3cf1
0x003cf1:	cmp     	r1, r4
0x003cf3:	bne     	#0x3d2d
; block 0x3cf5
0x003cf5:	ldr     	r1, [pc, #0x320]
0x003cf7:	add     	r1, pc
0x003cf9:	str     	r0, [sp, #0x10]
0x003cfb:	movs    	r3, #0
0x003cfd:	movs    	r0, #0xc8
0x003cff:	str     	r0, [sp, #0x20]
0x003d01:	str     	r1, [sp, #0xc]
0x003d03:	ldr     	r1, [sp, #0x80]
0x003d05:	movs    	r0, #1
0x003d07:	str     	r3, [sp, #0x18]
0x003d09:	str     	r3, [sp, #0x1c]
0x003d0b:	str     	r3, [sp, #0x24]
0x003d0d:	str     	r3, [sp, #0x28]
0x003d0f:	str     	r5, [sp, #0x14]
0x003d11:	strb    	r0, [r1]
0x003d13:	movs    	r1, #0
0x003d15:	movs    	r2, #0
0x003d17:	str     	r2, [sp, #8]
0x003d19:	str     	r1, [sp]
0x003d1b:	str     	r1, [sp, #4]
0x003d1d:	add     	r7, sp, #0xc
0x003d1f:	adds    	r2, r7, #0
0x003d21:	movs    	r1, #0x25
0x003d23:	movs    	r0, #0xf1
0x003d25:	lsls    	r0, r0, #9
0x003d27:	str     	r3, [sp, #0x30]
0x003d29:	bl      	#0x5159
; block 0x3d2d
0x003d2d:	ldr     	r0, [sp, #0x58]
0x003d2f:	adds    	r5, r5, r6
0x003d31:	adds    	r4, #1
0x003d33:	cmp     	r4, r0
0x003d35:	bge     	#0x3d39
; block 0x3d37
0x003d37:	b       	#0x39e9
; block 0x3d39
0x003d39:	ldr     	r0, [sp, #0x5c]
0x003d3b:	movs    	r5, #8
0x003d3d:	movs    	r6, #0xe
0x003d3f:	cmp     	r0, #0
0x003d41:	ble     	#0x3e23
; block 0x3d43
0x003d43:	movs    	r1, #0
0x003d45:	movs    	r2, #0
0x003d47:	str     	r2, [sp, #8]
0x003d49:	str     	r1, [sp]
0x003d4b:	str     	r1, [sp, #4]
0x003d4d:	movs    	r7, #0
0x003d4f:	adds    	r3, r7, #0
0x003d51:	movs    	r1, #0xe1
0x003d53:	movs    	r2, #0x2f
0x003d55:	movs    	r0, #0xf1
0x003d57:	lsls    	r0, r0, #9
0x003d59:	bl      	#0x5159
; block 0x3d5d
0x003d5d:	movs    	r1, #0
0x003d5f:	str     	r1, [sp]
0x003d61:	str     	r1, [sp, #4]
0x003d63:	str     	r0, [sp, #0x38]
0x003d65:	movs    	r2, #0
0x003d67:	movs    	r0, #0xf1
0x003d69:	movs    	r1, #0x1c
0x003d6b:	adds    	r3, r7, #0
0x003d6d:	lsls    	r0, r0, #9
0x003d6f:	str     	r2, [sp, #8]
0x003d71:	bl      	#0x5159
; block 0x3d75
0x003d75:	subs    	r0, #0xe
0x003d77:	movs    	r1, #0
0x003d79:	asrs    	r0, r0, #1
0x003d7b:	movs    	r2, #0
0x003d7d:	str     	r2, [sp, #8]
0x003d7f:	str     	r0, [sp, #0x3c]
0x003d81:	str     	r1, [sp]
0x003d83:	str     	r1, [sp, #4]
0x003d85:	movs    	r1, #0xe1
0x003d87:	movs    	r0, #0xf1
0x003d89:	movs    	r2, #0x27
0x003d8b:	adds    	r3, r7, #0
0x003d8d:	lsls    	r0, r0, #9
0x003d8f:	bl      	#0x5159
; block 0x3d93
0x003d93:	blx     	#0x308
; block 0x3d97
0x003d97:	lsrs    	r0, r1, #0x1f
0x003d99:	adds    	r0, r0, r1
0x003d9b:	asrs    	r0, r0, #1
0x003d9d:	lsls    	r0, r0, #1
0x003d9f:	ldr     	r4, [sp, #0x68]
0x003da1:	subs    	r0, r1, r0
0x003da3:	lsls    	r0, r0, #1
0x003da5:	subs    	r4, #6
0x003da7:	subs    	r0, r4, r0
0x003da9:	str     	r0, [sp, #0x40]
0x003dab:	movs    	r1, #0
0x003dad:	str     	r6, [sp, #0x44]
0x003daf:	movs    	r2, #0
0x003db1:	str     	r1, [sp, #4]
0x003db3:	str     	r1, [sp]
0x003db5:	str     	r5, [sp, #0x48]
0x003db7:	str     	r2, [sp, #8]
0x003db9:	movs    	r1, #0x22
0x003dbb:	movs    	r0, #0xf1
0x003dbd:	adds    	r3, r7, #0
0x003dbf:	lsls    	r0, r0, #9
0x003dc1:	add     	r2, sp, #0x38
0x003dc3:	str     	r7, [sp, #0x4c]
0x003dc5:	bl      	#0x5159
; block 0x3dc9
0x003dc9:	movs    	r1, #0
0x003dcb:	movs    	r2, #0
0x003dcd:	str     	r2, [sp, #8]
0x003dcf:	str     	r1, [sp]
0x003dd1:	str     	r1, [sp, #4]
0x003dd3:	movs    	r1, #0xe1
0x003dd5:	movs    	r2, #0x27
0x003dd7:	adds    	r3, r7, #0
0x003dd9:	movs    	r0, #0xf1
0x003ddb:	lsls    	r0, r0, #9
0x003ddd:	bl      	#0x5159
; block 0x3de1
0x003de1:	blx     	#0x308
; block 0x3de5
0x003de5:	lsrs    	r0, r1, #0x1f
0x003de7:	adds    	r0, r0, r1
0x003de9:	asrs    	r0, r0, #1
0x003deb:	lsls    	r0, r0, #1
0x003ded:	subs    	r0, r1, r0
0x003def:	lsls    	r0, r0, #1
0x003df1:	movs    	r1, #0
0x003df3:	subs    	r4, r4, r0
0x003df5:	str     	r1, [sp]
0x003df7:	str     	r1, [sp, #4]
0x003df9:	movs    	r2, #0
0x003dfb:	movs    	r1, #0x1c
0x003dfd:	movs    	r0, #0xf1
0x003dff:	adds    	r3, r7, #0
0x003e01:	lsls    	r0, r0, #9
0x003e03:	str     	r2, [sp, #8]
0x003e05:	bl      	#0x5159
; block 0x3e09
0x003e09:	subs    	r0, #0xe
0x003e0b:	movs    	r2, #8
0x003e0d:	movs    	r1, #0xe
0x003e0f:	str     	r1, [sp, #4]
0x003e11:	str     	r2, [sp, #8]
0x003e13:	asrs    	r3, r0, #1
0x003e15:	movs    	r0, #0xf1
0x003e17:	movs    	r2, #0
0x003e19:	movs    	r1, #0x23
0x003e1b:	lsls    	r0, r0, #9
0x003e1d:	str     	r4, [sp]
0x003e1f:	bl      	#0x5159
; block 0x3e23
0x003e23:	ldr     	r0, [sp, #0x58]
0x003e25:	ldr     	r1, [sp, #0x60]
0x003e27:	cmp     	r0, r1
0x003e29:	bge     	#0x3f0f
; block 0x3e2b
0x003e2b:	movs    	r1, #0
0x003e2d:	movs    	r2, #0
0x003e2f:	str     	r2, [sp, #8]
0x003e31:	str     	r1, [sp]
0x003e33:	str     	r1, [sp, #4]
0x003e35:	movs    	r4, #0
0x003e37:	adds    	r3, r4, #0
0x003e39:	movs    	r1, #0xe1
0x003e3b:	movs    	r2, #0x2f
0x003e3d:	movs    	r0, #0xf1
0x003e3f:	lsls    	r0, r0, #9
0x003e41:	bl      	#0x5159
; block 0x3e45
0x003e45:	movs    	r1, #0
0x003e47:	str     	r1, [sp]
0x003e49:	str     	r1, [sp, #4]
0x003e4b:	str     	r0, [sp, #0x38]
0x003e4d:	movs    	r2, #0
0x003e4f:	movs    	r0, #0xf1
0x003e51:	movs    	r1, #0x1c
0x003e53:	adds    	r3, r4, #0
0x003e55:	lsls    	r0, r0, #9
0x003e57:	str     	r2, [sp, #8]
0x003e59:	bl      	#0x5159
; block 0x3e5d
0x003e5d:	subs    	r0, #0xe
0x003e5f:	movs    	r1, #0
0x003e61:	asrs    	r0, r0, #1
0x003e63:	movs    	r2, #0
0x003e65:	str     	r2, [sp, #8]
0x003e67:	str     	r0, [sp, #0x3c]
0x003e69:	str     	r1, [sp]
0x003e6b:	str     	r1, [sp, #4]
0x003e6d:	movs    	r1, #0xe1
0x003e6f:	movs    	r0, #0xf1
0x003e71:	movs    	r2, #0x27
0x003e73:	adds    	r3, r4, #0
0x003e75:	lsls    	r0, r0, #9
0x003e77:	bl      	#0x5159
; block 0x3e7b
0x003e7b:	blx     	#0x308
; block 0x3e7f
0x003e7f:	lsrs    	r0, r1, #0x1f
0x003e81:	adds    	r0, r0, r1
0x003e83:	asrs    	r0, r0, #1
0x003e85:	lsls    	r0, r0, #1
0x003e87:	ldr     	r3, [sp, #0x68]
0x003e89:	subs    	r0, r1, r0
0x003e8b:	ldr     	r1, [sp, #0x54]
0x003e8d:	lsls    	r0, r0, #1
0x003e8f:	adds    	r7, r3, r1
0x003e91:	subs    	r7, #4
0x003e93:	subs    	r0, r7, r0
0x003e95:	str     	r0, [sp, #0x40]
0x003e97:	movs    	r1, #0
0x003e99:	movs    	r0, #1
0x003e9b:	str     	r6, [sp, #0x44]
0x003e9d:	movs    	r2, #0
0x003e9f:	str     	r1, [sp, #4]
0x003ea1:	str     	r0, [sp, #0x4c]
0x003ea3:	str     	r1, [sp]
0x003ea5:	str     	r5, [sp, #0x48]
0x003ea7:	str     	r2, [sp, #8]
0x003ea9:	movs    	r1, #0x22
0x003eab:	movs    	r0, #0xf1
0x003ead:	adds    	r3, r4, #0
0x003eaf:	lsls    	r0, r0, #9
0x003eb1:	add     	r2, sp, #0x38
0x003eb3:	bl      	#0x5159
; block 0x3eb7
0x003eb7:	movs    	r1, #0
0x003eb9:	movs    	r2, #0
0x003ebb:	str     	r2, [sp, #8]
0x003ebd:	str     	r1, [sp]
0x003ebf:	str     	r1, [sp, #4]
0x003ec1:	movs    	r1, #0xe1
0x003ec3:	movs    	r2, #0x27
0x003ec5:	adds    	r3, r4, #0
0x003ec7:	movs    	r0, #0xf1
0x003ec9:	lsls    	r0, r0, #9
0x003ecb:	bl      	#0x5159
; block 0x3ecf
0x003ecf:	blx     	#0x308
; block 0x3ed3
0x003ed3:	lsrs    	r0, r1, #0x1f
0x003ed5:	adds    	r0, r0, r1
0x003ed7:	asrs    	r0, r0, #1
0x003ed9:	lsls    	r0, r0, #1
0x003edb:	subs    	r0, r1, r0
0x003edd:	lsls    	r0, r0, #1
0x003edf:	movs    	r1, #0
0x003ee1:	subs    	r5, r7, r0
0x003ee3:	str     	r1, [sp]
0x003ee5:	str     	r1, [sp, #4]
0x003ee7:	movs    	r2, #0
0x003ee9:	movs    	r1, #0x1c
0x003eeb:	movs    	r0, #0xf1
0x003eed:	adds    	r3, r4, #0
0x003eef:	lsls    	r0, r0, #9
0x003ef1:	str     	r2, [sp, #8]
0x003ef3:	bl      	#0x5159
; block 0x3ef7
0x003ef7:	subs    	r0, #0xe
0x003ef9:	movs    	r2, #8
0x003efb:	movs    	r1, #0xe
0x003efd:	str     	r1, [sp, #4]
0x003eff:	str     	r2, [sp, #8]
0x003f01:	asrs    	r3, r0, #1
0x003f03:	movs    	r0, #0xf1
0x003f05:	movs    	r2, #1
0x003f07:	movs    	r1, #0x23
0x003f09:	lsls    	r0, r0, #9
0x003f0b:	str     	r5, [sp]
0x003f0d:	b       	#0x3f11
; block 0x3f0f
0x003f0f:	b       	#0x3f15
; block 0x3f11
0x003f11:	bl      	#0x5159
; block 0x3f15
0x003f15:	movs    	r1, #0
0x003f17:	str     	r1, [sp]
0x003f19:	str     	r1, [sp, #4]
0x003f1b:	movs    	r2, #0
0x003f1d:	movs    	r4, #0
0x003f1f:	movs    	r5, #0xf1
0x003f21:	lsls    	r5, r5, #9
0x003f23:	adds    	r3, r4, #0
0x003f25:	movs    	r1, #0x1c
0x003f27:	adds    	r0, r5, #0
0x003f29:	str     	r2, [sp, #8]
0x003f2b:	bl      	#0x5159
; block 0x3f2f
0x003f2f:	movs    	r1, #0
0x003f31:	str     	r1, [sp]
0x003f33:	str     	r1, [sp, #4]
0x003f35:	movs    	r2, #0
0x003f37:	movs    	r1, #0x1d
0x003f39:	adds    	r6, r0, #0
0x003f3b:	adds    	r3, r4, #0
0x003f3d:	adds    	r0, r5, #0
0x003f3f:	str     	r2, [sp, #8]
0x003f41:	bl      	#0x5159
; block 0x3f45
0x003f45:	ldr     	r1, [sp, #0x6c]
0x003f47:	movs    	r2, #0
0x003f49:	subs    	r3, r0, r1
0x003f4b:	str     	r1, [sp, #4]
0x003f4d:	movs    	r1, #0x32
0x003f4f:	adds    	r0, r5, #0
0x003f51:	str     	r2, [sp, #8]
0x003f53:	str     	r6, [sp]
0x003f55:	bl      	#0x5159
; block 0x3f59
0x003f59:	ldr     	r6, [pc, #0xc0]
0x003f5b:	add     	r6, sb
0x003f5d:	ldr     	r0, [r6, #8]
0x003f5f:	cmp     	r0, #0
0x003f61:	bne     	#0x3f91
; block 0x3f63
0x003f63:	movs    	r1, #0
0x003f65:	str     	r1, [sp]
0x003f67:	str     	r1, [sp, #4]
0x003f69:	movs    	r2, #0
0x003f6b:	movs    	r1, #0x1c
0x003f6d:	adds    	r3, r4, #0
0x003f6f:	adds    	r0, r5, #0
0x003f71:	str     	r2, [sp, #8]
0x003f73:	bl      	#0x5159
; block 0x3f77
0x003f77:	movs    	r1, #0
0x003f79:	str     	r1, [sp]
0x003f7b:	str     	r1, [sp, #4]
0x003f7d:	movs    	r2, #0
0x003f7f:	adds    	r3, r0, #0
0x003f81:	subs    	r3, #0x28
0x003f83:	str     	r2, [sp, #8]
0x003f85:	movs    	r1, #0x42
0x003f87:	adds    	r0, r5, #0
0x003f89:	ldr     	r2, [r6, #4]
0x003f8b:	bl      	#0x5159
; block 0x3f8f
0x003f8f:	str     	r0, [r6, #8]
0x003f91:	ldr     	r0, [r6, #8]
0x003f93:	movs    	r1, #0
0x003f95:	str     	r0, [sp, #0x34]
0x003f97:	movs    	r0, #0x14
0x003f99:	str     	r1, [sp]
0x003f9b:	str     	r1, [sp, #4]
0x003f9d:	movs    	r2, #0
0x003f9f:	movs    	r1, #0x1d
0x003fa1:	str     	r0, [sp, #0x3c]
0x003fa3:	adds    	r3, r4, #0
0x003fa5:	adds    	r0, r5, #0
0x003fa7:	str     	r2, [sp, #8]
0x003fa9:	str     	r4, [sp, #0x38]
0x003fab:	bl      	#0x5159
; block 0x3f91
0x003f91:	ldr     	r0, [r6, #8]
0x003f93:	movs    	r1, #0
0x003f95:	str     	r0, [sp, #0x34]
0x003f97:	movs    	r0, #0x14
0x003f99:	str     	r1, [sp]
0x003f9b:	str     	r1, [sp, #4]
0x003f9d:	movs    	r2, #0
0x003f9f:	movs    	r1, #0x1d
0x003fa1:	str     	r0, [sp, #0x3c]
0x003fa3:	adds    	r3, r4, #0
0x003fa5:	adds    	r0, r5, #0
0x003fa7:	str     	r2, [sp, #8]
0x003fa9:	str     	r4, [sp, #0x38]
0x003fab:	bl      	#0x5159
; block 0x3faf
0x003faf:	ldr     	r1, [sp, #0x6c]
0x003fb1:	movs    	r2, #0
0x003fb3:	subs    	r0, r0, r1
0x003fb5:	adds    	r0, #0xa
0x003fb7:	str     	r0, [sp, #0x40]
0x003fb9:	movs    	r1, #0
0x003fbb:	str     	r1, [sp]
0x003fbd:	str     	r1, [sp, #4]
0x003fbf:	movs    	r1, #0x1c
0x003fc1:	movs    	r0, #0xf1
0x003fc3:	adds    	r3, r4, #0
0x003fc5:	lsls    	r0, r0, #9
0x003fc7:	str     	r2, [sp, #8]
0x003fc9:	bl      	#0x5159
; block 0x3fcd
0x003fcd:	ldr     	r1, [sp, #0x6c]
0x003fcf:	subs    	r0, #0x28
0x003fd1:	subs    	r1, #0x14
0x003fd3:	str     	r1, [sp, #0x48]
0x003fd5:	str     	r0, [sp, #0x44]
0x003fd7:	add     	r3, sp, #0x40
0x003fd9:	strb    	r4, [r3, #0xc]
0x003fdb:	movs    	r5, #1
0x003fdd:	strb    	r5, [r3, #0xd]
0x003fdf:	movs    	r1, #0
0x003fe1:	movs    	r2, #0
0x003fe3:	str     	r1, [sp]
0x003fe5:	str     	r1, [sp, #4]
0x003fe7:	movs    	r1, #0x43
0x003fe9:	str     	r2, [sp, #8]
0x003feb:	adds    	r3, r4, #0
0x003fed:	movs    	r0, #0xf1
0x003fef:	lsls    	r0, r0, #9
0x003ff1:	add     	r2, sp, #0x34
0x003ff3:	bl      	#0x5159
; block 0x3ff7
0x003ff7:	movs    	r1, #0
0x003ff9:	movs    	r2, #0
0x003ffb:	str     	r2, [sp, #8]
0x003ffd:	str     	r1, [sp]
0x003fff:	str     	r1, [sp, #4]
0x004001:	movs    	r1, #0x24
0x004003:	movs    	r2, #1
0x004005:	adds    	r3, r5, #0
0x004007:	movs    	r0, #0xf1
0x004009:	lsls    	r0, r0, #9
0x00400b:	bl      	#0x5159
; block 0x400f
0x00400f:	add     	sp, #0x84
0x004011:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_4015 @ 0x4015 offset=0x4014 size=12 blocks=1 cc=1 =====
; block 0x4015
0x004015:	movs    	r4, r0
0x004017:	movs    	r0, r0
0x004019:	cmp     	r7, #6
0x00401b:	movs    	r0, r0
0x00401d:	movs    	r4, r1
0x00401f:	movs    	r0, r0
0x004021:	push    	{lr}
0x004023:	ldr     	r3, [pc, #0x5c]
0x004025:	sub     	sp, #0xc
0x004027:	add     	r3, pc
0x004029:	movs    	r2, #0
0x00402b:	movs    	r1, #0
0x00402d:	movs    	r0, #2
0x00402f:	str     	r0, [sp]
0x004031:	str     	r1, [sp, #4]
0x004033:	str     	r2, [sp, #8]
0x004035:	movs    	r2, #0x21
0x004037:	movs    	r1, #0x14
0x004039:	movs    	r0, #0xf1
0x00403b:	lsls    	r0, r0, #9
0x00403d:	bl      	#0x5159

; ===== sub_4021 @ 0x4021 offset=0x4020 size=94 blocks=4 cc=3 =====
; block 0x4021
0x004021:	push    	{lr}
0x004023:	ldr     	r3, [pc, #0x5c]
0x004025:	sub     	sp, #0xc
0x004027:	add     	r3, pc
0x004029:	movs    	r2, #0
0x00402b:	movs    	r1, #0
0x00402d:	movs    	r0, #2
0x00402f:	str     	r0, [sp]
0x004031:	str     	r1, [sp, #4]
0x004033:	str     	r2, [sp, #8]
0x004035:	movs    	r2, #0x21
0x004037:	movs    	r1, #0x14
0x004039:	movs    	r0, #0xf1
0x00403b:	lsls    	r0, r0, #9
0x00403d:	bl      	#0x5159
; block 0x4041
0x004041:	ldr     	r0, [pc, #0x40]
0x004043:	movs    	r3, #0
0x004045:	add     	r0, sb
0x004047:	str     	r3, [r0, #0x44]
0x004049:	str     	r3, [r0, #0x48]
0x00404b:	str     	r3, [r0, #0x4c]
0x00404d:	movs    	r1, #0
0x00404f:	str     	r1, [sp]
0x004051:	str     	r1, [sp, #4]
0x004053:	movs    	r2, #0
0x004055:	movs    	r1, #0x34
0x004057:	movs    	r0, #0xf1
0x004059:	lsls    	r0, r0, #9
0x00405b:	str     	r2, [sp, #8]
0x00405d:	bl      	#0x5159
; block 0x4061
0x004061:	movs    	r2, #0
0x004063:	movs    	r1, #0
0x004065:	movs    	r0, #2
0x004067:	str     	r0, [sp]
0x004069:	str     	r1, [sp, #4]
0x00406b:	str     	r2, [sp, #8]
0x00406d:	movs    	r2, #0x17
0x00406f:	movs    	r1, #0x14
0x004071:	movs    	r0, #0xf1
0x004073:	movs    	r3, #5
0x004075:	lsls    	r0, r0, #9
0x004077:	bl      	#0x5159
; block 0x407b
0x00407b:	add     	sp, #0xc
0x00407d:	pop     	{pc}

; ===== sub_4081 @ 0x4081 offset=0x4080 size=8 blocks=1 cc=1 =====
; block 0x4081
0x004081:	cmp     	r0, #0xca
0x004083:	movs    	r0, r0
0x004085:	movs    	r4, r1
0x004087:	movs    	r0, r0
0x004089:	push    	{r4, r5, r6, r7, lr}
0x00408b:	sub     	sp, #0xc
0x00408d:	movs    	r1, #0
0x00408f:	movs    	r2, #0
0x004091:	str     	r2, [sp, #8]
0x004093:	str     	r1, [sp]
0x004095:	str     	r1, [sp, #4]
0x004097:	movs    	r4, #0
0x004099:	adds    	r3, r4, #0
0x00409b:	movs    	r1, #0xe1
0x00409d:	movs    	r2, #0x24
0x00409f:	movs    	r0, #0xf1
0x0040a1:	lsls    	r0, r0, #9
0x0040a3:	bl      	#0x5159

; ===== sub_4089 @ 0x4089 offset=0x4088 size=258 blocks=12 cc=9 =====
; block 0x4089
0x004089:	push    	{r4, r5, r6, r7, lr}
0x00408b:	sub     	sp, #0xc
0x00408d:	movs    	r1, #0
0x00408f:	movs    	r2, #0
0x004091:	str     	r2, [sp, #8]
0x004093:	str     	r1, [sp]
0x004095:	str     	r1, [sp, #4]
0x004097:	movs    	r4, #0
0x004099:	adds    	r3, r4, #0
0x00409b:	movs    	r1, #0xe1
0x00409d:	movs    	r2, #0x24
0x00409f:	movs    	r0, #0xf1
0x0040a1:	lsls    	r0, r0, #9
0x0040a3:	bl      	#0x5159
; block 0x40a7
0x0040a7:	movs    	r2, #0
0x0040a9:	movs    	r1, #0
0x0040ab:	str     	r2, [sp, #8]
0x0040ad:	adds    	r2, r0, #0
0x0040af:	str     	r1, [sp]
0x0040b1:	str     	r1, [sp, #4]
0x0040b3:	movs    	r1, #0x11
0x0040b5:	movs    	r0, #0xf1
0x0040b7:	movs    	r3, #0x1c
0x0040b9:	lsls    	r0, r0, #9
0x0040bb:	bl      	#0x5159
; block 0x40bf
0x0040bf:	movs    	r1, #0
0x0040c1:	str     	r1, [sp]
0x0040c3:	str     	r1, [sp, #4]
0x0040c5:	adds    	r6, r0, #0
0x0040c7:	movs    	r1, #0xff
0x0040c9:	movs    	r2, #0
0x0040cb:	adds    	r3, r4, #0
0x0040cd:	adds    	r1, #0x55
0x0040cf:	movs    	r0, #0xf1
0x0040d1:	lsls    	r0, r0, #9
0x0040d3:	str     	r2, [sp, #8]
0x0040d5:	bl      	#0x5159
; block 0x40d9
0x0040d9:	bl      	#0x49bd
; block 0x40dd
0x0040dd:	movs    	r2, #0
0x0040df:	movs    	r1, #0
0x0040e1:	movs    	r0, #2
0x0040e3:	str     	r0, [sp]
0x0040e5:	str     	r1, [sp, #4]
0x0040e7:	str     	r2, [sp, #8]
0x0040e9:	movs    	r2, #0x1e
0x0040eb:	movs    	r1, #0x14
0x0040ed:	movs    	r0, #0xf1
0x0040ef:	adds    	r3, r4, #0
0x0040f1:	lsls    	r0, r0, #9
0x0040f3:	bl      	#0x5159
; block 0x40f7
0x0040f7:	ldr     	r5, [pc, #0x94]
0x0040f9:	movs    	r1, #0
0x0040fb:	add     	r5, sb
0x0040fd:	str     	r4, [r5]
0x0040ff:	movs    	r2, #0
0x004101:	str     	r2, [sp, #8]
0x004103:	str     	r1, [sp]
0x004105:	str     	r1, [sp, #4]
0x004107:	movs    	r1, #0xe1
0x004109:	movs    	r2, #0x25
0x00410b:	adds    	r3, r4, #0
0x00410d:	movs    	r0, #0xf1
0x00410f:	lsls    	r0, r0, #9
0x004111:	bl      	#0x5159
; block 0x4115
0x004115:	movs    	r2, #0
0x004117:	movs    	r1, #0
0x004119:	str     	r2, [sp, #8]
0x00411b:	adds    	r2, r0, #0
0x00411d:	str     	r1, [sp]
0x00411f:	str     	r1, [sp, #4]
0x004121:	movs    	r1, #0x11
0x004123:	movs    	r0, #0xf1
0x004125:	movs    	r3, #4
0x004127:	lsls    	r0, r0, #9
0x004129:	bl      	#0x5159
; block 0x412d
0x00412d:	movs    	r2, #0
0x00412f:	movs    	r1, #0
0x004131:	str     	r2, [sp, #8]
0x004133:	adds    	r3, r4, #0
0x004135:	adds    	r2, r0, #0
0x004137:	str     	r1, [sp]
0x004139:	str     	r1, [sp, #4]
0x00413b:	movs    	r1, #3
0x00413d:	movs    	r0, #0xf1
0x00413f:	lsls    	r0, r0, #9
0x004141:	bl      	#0x5159
; block 0x4145
0x004145:	str     	r0, [r5, #4]
0x004147:	movs    	r1, #0
0x004149:	movs    	r2, #0
0x00414b:	str     	r2, [sp, #8]
0x00414d:	str     	r1, [sp]
0x00414f:	str     	r1, [sp, #4]
0x004151:	adds    	r3, r4, #0
0x004153:	adds    	r2, r6, #0
0x004155:	movs    	r1, #3
0x004157:	movs    	r0, #0xf1
0x004159:	lsls    	r0, r0, #9
0x00415b:	bl      	#0x5159
; block 0x415f
0x00415f:	str     	r0, [r5, #0x1c]
0x004161:	movs    	r0, #2
0x004163:	movs    	r2, #0
0x004165:	movs    	r1, #0
0x004167:	str     	r1, [sp, #4]
0x004169:	str     	r2, [sp, #8]
0x00416b:	str     	r0, [sp]
0x00416d:	movs    	r0, #0xf1
0x00416f:	movs    	r2, #0x17
0x004171:	movs    	r1, #0x14
0x004173:	movs    	r3, #0xcd
0x004175:	lsls    	r0, r0, #9
0x004177:	bl      	#0x5159
; block 0x417b
0x00417b:	bl      	#0x6005
; block 0x417f
0x00417f:	ldr     	r0, [pc, #0xc]
0x004181:	add     	r0, sb
0x004183:	subs    	r0, #0x80
0x004185:	str     	r4, [r0, #0x44]
0x004187:	add     	sp, #0xc
0x004189:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_418d @ 0x418d offset=0x418c size=4 blocks=1 cc=1 =====
; block 0x418d
0x00418d:	lsls    	r4, r1, #2
0x00418f:	movs    	r0, r0
0x004191:	push    	{r4, r5, r6, lr}
0x004193:	sub     	sp, #0x10
0x004195:	adds    	r4, r1, #0
0x004197:	movs    	r1, #0
0x004199:	str     	r1, [sp]
0x00419b:	str     	r1, [sp, #4]
0x00419d:	movs    	r2, #0
0x00419f:	str     	r2, [sp, #8]
0x0041a1:	movs    	r1, #0xff
0x0041a3:	movs    	r6, #0xf1
0x0041a5:	lsls    	r6, r6, #9
0x0041a7:	adds    	r1, #0x31
0x0041a9:	adds    	r2, r0, #0
0x0041ab:	adds    	r3, r4, #0
0x0041ad:	adds    	r5, r0, #0
0x0041af:	adds    	r0, r6, #0
0x0041b1:	bl      	#0x5159

; ===== sub_4191 @ 0x4191 offset=0x4190 size=86 blocks=5 cc=4 =====
; block 0x4191
0x004191:	push    	{r4, r5, r6, lr}
0x004193:	sub     	sp, #0x10
0x004195:	adds    	r4, r1, #0
0x004197:	movs    	r1, #0
0x004199:	str     	r1, [sp]
0x00419b:	str     	r1, [sp, #4]
0x00419d:	movs    	r2, #0
0x00419f:	str     	r2, [sp, #8]
0x0041a1:	movs    	r1, #0xff
0x0041a3:	movs    	r6, #0xf1
0x0041a5:	lsls    	r6, r6, #9
0x0041a7:	adds    	r1, #0x31
0x0041a9:	adds    	r2, r0, #0
0x0041ab:	adds    	r3, r4, #0
0x0041ad:	adds    	r5, r0, #0
0x0041af:	adds    	r0, r6, #0
0x0041b1:	bl      	#0x5159
; block 0x41b5
0x0041b5:	cmp     	r0, #0
0x0041b7:	bne     	#0x41cf
; block 0x41b9
0x0041b9:	movs    	r1, #0
0x0041bb:	movs    	r2, #0
0x0041bd:	str     	r2, [sp, #8]
0x0041bf:	str     	r1, [sp]
0x0041c1:	str     	r1, [sp, #4]
0x0041c3:	movs    	r1, #0x4d
0x0041c5:	adds    	r2, r5, #0
0x0041c7:	adds    	r3, r4, #0
0x0041c9:	adds    	r0, r6, #0
0x0041cb:	bl      	#0x5159
; block 0x41cf
0x0041cf:	movs    	r1, #0
0x0041d1:	str     	r1, [sp]
0x0041d3:	str     	r1, [sp, #4]
0x0041d5:	movs    	r2, #0
0x0041d7:	movs    	r1, #0x21
0x0041d9:	movs    	r3, #0
0x0041db:	adds    	r0, r6, #0
0x0041dd:	str     	r2, [sp, #8]
0x0041df:	bl      	#0x5159
; block 0x41e3
0x0041e3:	add     	sp, #0x10
0x0041e5:	pop     	{r4, r5, r6, pc}

; ===== sub_41e9 @ 0x41e9 offset=0x41e8 size=262 blocks=11 cc=9 =====
; block 0x41e9
0x0041e9:	push    	{r4, r5, lr}
0x0041eb:	sub     	sp, #0xc
0x0041ed:	movs    	r1, #0
0x0041ef:	movs    	r2, #0
0x0041f1:	str     	r2, [sp, #8]
0x0041f3:	str     	r1, [sp]
0x0041f5:	str     	r1, [sp, #4]
0x0041f7:	movs    	r5, #0
0x0041f9:	adds    	r3, r5, #0
0x0041fb:	movs    	r1, #0x15
0x0041fd:	movs    	r2, #5
0x0041ff:	movs    	r0, #0xf1
0x004201:	lsls    	r0, r0, #9
0x004203:	bl      	#0x5159
; block 0x4207
0x004207:	movs    	r2, #0
0x004209:	mvns    	r1, r2
0x00420b:	ldr     	r3, [pc, #0xe4]
0x00420d:	str     	r1, [sp]
0x00420f:	str     	r1, [sp, #4]
0x004211:	str     	r2, [sp, #8]
0x004213:	add     	r3, pc
0x004215:	ldr     	r4, [pc, #0xdc]
0x004217:	movs    	r1, #5
0x004219:	movs    	r0, #0xf1
0x00421b:	add     	r4, sb
0x00421d:	ldr     	r2, [r4, #0x58]
0x00421f:	lsls    	r0, r0, #9
0x004221:	bl      	#0x5159
; block 0x4225
0x004225:	str     	r0, [r4, #0x58]
0x004227:	movs    	r1, #0
0x004229:	movs    	r2, #0
0x00422b:	str     	r2, [sp, #8]
0x00422d:	str     	r1, [sp]
0x00422f:	str     	r1, [sp, #4]
0x004231:	movs    	r1, #0x15
0x004233:	movs    	r2, #5
0x004235:	movs    	r0, #0xf1
0x004237:	adds    	r3, r5, #0
0x004239:	lsls    	r0, r0, #9
0x00423b:	bl      	#0x5159
; block 0x423f
0x00423f:	movs    	r2, #0
0x004241:	mvns    	r1, r2
0x004243:	ldr     	r3, [pc, #0xb4]
0x004245:	str     	r1, [sp]
0x004247:	str     	r1, [sp, #4]
0x004249:	str     	r2, [sp, #8]
0x00424b:	add     	r3, pc
0x00424d:	movs    	r1, #5
0x00424f:	movs    	r0, #0xf1
0x004251:	lsls    	r0, r0, #9
0x004253:	ldr     	r2, [r4, #0x5c]
0x004255:	bl      	#0x5159
; block 0x4259
0x004259:	str     	r0, [r4, #0x5c]
0x00425b:	movs    	r1, #0
0x00425d:	movs    	r2, #0
0x00425f:	str     	r2, [sp, #8]
0x004261:	str     	r1, [sp]
0x004263:	str     	r1, [sp, #4]
0x004265:	movs    	r1, #0x15
0x004267:	movs    	r2, #5
0x004269:	movs    	r0, #0xf1
0x00426b:	adds    	r3, r5, #0
0x00426d:	lsls    	r0, r0, #9
0x00426f:	bl      	#0x5159
; block 0x4273
0x004273:	bl      	#0x4a9d
; block 0x4277
0x004277:	movs    	r1, #0
0x004279:	movs    	r2, #0
0x00427b:	str     	r2, [sp, #8]
0x00427d:	str     	r1, [sp]
0x00427f:	str     	r1, [sp, #4]
0x004281:	movs    	r1, #0x15
0x004283:	movs    	r2, #5
0x004285:	adds    	r3, r5, #0
0x004287:	movs    	r0, #0xf1
0x004289:	lsls    	r0, r0, #9
0x00428b:	bl      	#0x5159
; block 0x428f
0x00428f:	ldr     	r0, [r4, #0x58]
0x004291:	movs    	r3, #8
0x004293:	ldrsh   	r0, [r0, r3]
0x004295:	movs    	r1, #0
0x004297:	movs    	r2, #0
0x004299:	rsbs    	r0, r0, #0
0x00429b:	str     	r0, [r4, #0x60]
0x00429d:	str     	r1, [sp]
0x00429f:	str     	r1, [sp, #4]
0x0042a1:	movs    	r1, #0x1c
0x0042a3:	movs    	r0, #0xf1
0x0042a5:	adds    	r3, r5, #0
0x0042a7:	lsls    	r0, r0, #9
0x0042a9:	str     	r2, [sp, #8]
0x0042ab:	bl      	#0x5159
; block 0x42af
0x0042af:	str     	r0, [r4, #0x64]
0x0042b1:	movs    	r1, #0
0x0042b3:	movs    	r2, #0
0x0042b5:	str     	r2, [sp, #8]
0x0042b7:	str     	r1, [sp]
0x0042b9:	str     	r1, [sp, #4]
0x0042bb:	movs    	r1, #0x15
0x0042bd:	movs    	r2, #5
0x0042bf:	movs    	r0, #0xf1
0x0042c1:	movs    	r3, #1
0x0042c3:	lsls    	r0, r0, #9
0x0042c5:	bl      	#0x5159
; block 0x42c9
0x0042c9:	movs    	r2, #0
0x0042cb:	movs    	r1, #0
0x0042cd:	movs    	r0, #2
0x0042cf:	str     	r0, [sp]
0x0042d1:	str     	r1, [sp, #4]
0x0042d3:	str     	r2, [sp, #8]
0x0042d5:	movs    	r2, #0x17
0x0042d7:	movs    	r1, #0x14
0x0042d9:	movs    	r0, #0xf1
0x0042db:	movs    	r3, #0xfe
0x0042dd:	lsls    	r0, r0, #9
0x0042df:	bl      	#0x5159
; block 0x42e3
0x0042e3:	ldr     	r1, [pc, #0x18]
0x0042e5:	movs    	r0, #9
0x0042e7:	add     	r1, sb
0x0042e9:	str     	r0, [r1]
0x0042eb:	add     	sp, #0xc
0x0042ed:	pop     	{r4, r5, pc}

; ===== sub_4301 @ 0x4301 offset=0x4300 size=96 blocks=4 cc=3 =====
; block 0x4301
0x004301:	push    	{r4, lr}
0x004303:	sub     	sp, #0x10
0x004305:	movs    	r1, #0
0x004307:	str     	r1, [sp]
0x004309:	str     	r1, [sp, #4]
0x00430b:	movs    	r4, #0
0x00430d:	movs    	r2, #0
0x00430f:	adds    	r3, r4, #0
0x004311:	movs    	r1, #0x34
0x004313:	movs    	r0, #0xf1
0x004315:	lsls    	r0, r0, #9
0x004317:	str     	r2, [sp, #8]
0x004319:	bl      	#0x5159
; block 0x431d
0x00431d:	ldr     	r0, [pc, #0x40]
0x00431f:	ldr     	r3, [pc, #0x44]
0x004321:	add     	r0, sb
0x004323:	str     	r4, [r0, #0x44]
0x004325:	str     	r4, [r0, #0x48]
0x004327:	add     	r3, pc
0x004329:	str     	r4, [r0, #0x4c]
0x00432b:	movs    	r0, #2
0x00432d:	movs    	r2, #0
0x00432f:	movs    	r1, #0
0x004331:	str     	r1, [sp, #4]
0x004333:	str     	r2, [sp, #8]
0x004335:	str     	r0, [sp]
0x004337:	movs    	r0, #0xf1
0x004339:	movs    	r2, #0x22
0x00433b:	movs    	r1, #0x14
0x00433d:	lsls    	r0, r0, #9
0x00433f:	bl      	#0x5159
; block 0x4343
0x004343:	movs    	r2, #0
0x004345:	movs    	r1, #0
0x004347:	movs    	r0, #2
0x004349:	str     	r0, [sp]
0x00434b:	str     	r1, [sp, #4]
0x00434d:	str     	r2, [sp, #8]
0x00434f:	movs    	r2, #0x17
0x004351:	movs    	r1, #0x14
0x004353:	movs    	r0, #0xf1
0x004355:	movs    	r3, #4
0x004357:	lsls    	r0, r0, #9
0x004359:	bl      	#0x5159
; block 0x435d
0x00435d:	add     	sp, #0x10
0x00435f:	pop     	{r4, pc}

; ===== sub_4361 @ 0x4361 offset=0x4360 size=8 blocks=1 cc=1 =====
; block 0x4361
0x004361:	movs    	r4, r1
0x004363:	movs    	r0, r0
0x004365:	movs    	r6, #2
0x004367:	movs    	r0, r0
0x004369:	push    	{r4, r5, lr}
0x00436b:	sub     	sp, #0xc
0x00436d:	movs    	r1, #0
0x00436f:	movs    	r2, #0
0x004371:	str     	r2, [sp, #8]
0x004373:	str     	r1, [sp]
0x004375:	str     	r1, [sp, #4]
0x004377:	movs    	r1, #0x14
0x004379:	movs    	r2, #0xd
0x00437b:	movs    	r3, #1
0x00437d:	movs    	r0, #0xf1
0x00437f:	lsls    	r0, r0, #9
0x004381:	bl      	#0x5159

; ===== sub_4369 @ 0x4369 offset=0x4368 size=70 blocks=4 cc=1 =====
; block 0x4369
0x004369:	push    	{r4, r5, lr}
0x00436b:	sub     	sp, #0xc
0x00436d:	movs    	r1, #0
0x00436f:	movs    	r2, #0
0x004371:	str     	r2, [sp, #8]
0x004373:	str     	r1, [sp]
0x004375:	str     	r1, [sp, #4]
0x004377:	movs    	r1, #0x14
0x004379:	movs    	r2, #0xd
0x00437b:	movs    	r3, #1
0x00437d:	movs    	r0, #0xf1
0x00437f:	lsls    	r0, r0, #9
0x004381:	bl      	#0x5159
; block 0x4385
0x004385:	ldr     	r5, [pc, #0x28]
0x004387:	movs    	r4, #0
0x004389:	movs    	r2, #0
0x00438b:	movs    	r1, #0
0x00438d:	add     	r5, sb
0x00438f:	str     	r4, [r5, #0x50]
0x004391:	movs    	r0, #0
0x004393:	bl      	#0x5109
; block 0x4397
0x004397:	str     	r4, [r5, #0x24]
0x004399:	str     	r4, [r5, #0x28]
0x00439b:	str     	r4, [r5, #0x2c]
0x00439d:	str     	r4, [r5, #0x30]
0x00439f:	str     	r4, [r5, #0x34]
0x0043a1:	str     	r4, [r5, #0x38]
0x0043a3:	str     	r4, [r5, #0x3c]
0x0043a5:	str     	r4, [r5, #0x40]
0x0043a7:	bl      	#0x61bd
; block 0x43ab
0x0043ab:	add     	sp, #0xc
0x0043ad:	pop     	{r4, r5, pc}

; ===== sub_43b1 @ 0x43b1 offset=0x43b0 size=4 blocks=1 cc=1 =====
; block 0x43b1
0x0043b1:	movs    	r4, r1
0x0043b3:	movs    	r0, r0
0x0043b5:	push    	{r4, r5, r6, r7, lr}
0x0043b7:	sub     	sp, #0xc
0x0043b9:	movs    	r1, #0
0x0043bb:	str     	r1, [sp]
0x0043bd:	str     	r1, [sp, #4]
0x0043bf:	movs    	r1, #0xff
0x0043c1:	movs    	r6, #0xf1
0x0043c3:	movs    	r4, #0
0x0043c5:	movs    	r2, #0
0x0043c7:	adds    	r3, r4, #0
0x0043c9:	lsls    	r6, r6, #9
0x0043cb:	adds    	r1, #0x4d
0x0043cd:	adds    	r0, r6, #0
0x0043cf:	str     	r2, [sp, #8]
0x0043d1:	bl      	#0x5159

; ===== sub_43b5 @ 0x43b5 offset=0x43b4 size=490 blocks=23 cc=20 =====
; block 0x43b5
0x0043b5:	push    	{r4, r5, r6, r7, lr}
0x0043b7:	sub     	sp, #0xc
0x0043b9:	movs    	r1, #0
0x0043bb:	str     	r1, [sp]
0x0043bd:	str     	r1, [sp, #4]
0x0043bf:	movs    	r1, #0xff
0x0043c1:	movs    	r6, #0xf1
0x0043c3:	movs    	r4, #0
0x0043c5:	movs    	r2, #0
0x0043c7:	adds    	r3, r4, #0
0x0043c9:	lsls    	r6, r6, #9
0x0043cb:	adds    	r1, #0x4d
0x0043cd:	adds    	r0, r6, #0
0x0043cf:	str     	r2, [sp, #8]
0x0043d1:	bl      	#0x5159
; block 0x43d5
0x0043d5:	movs    	r1, #0
0x0043d7:	str     	r1, [sp]
0x0043d9:	str     	r1, [sp, #4]
0x0043db:	movs    	r1, #0xff
0x0043dd:	movs    	r2, #0
0x0043df:	adds    	r1, #0x44
0x0043e1:	adds    	r3, r4, #0
0x0043e3:	adds    	r0, r6, #0
0x0043e5:	str     	r2, [sp, #8]
0x0043e7:	bl      	#0x5159
; block 0x43eb
0x0043eb:	movs    	r1, #0
0x0043ed:	movs    	r2, #0
0x0043ef:	str     	r2, [sp, #8]
0x0043f1:	str     	r1, [sp]
0x0043f3:	str     	r1, [sp, #4]
0x0043f5:	movs    	r1, #0x14
0x0043f7:	movs    	r2, #0xf5
0x0043f9:	adds    	r3, r4, #0
0x0043fb:	adds    	r0, r6, #0
0x0043fd:	bl      	#0x5159
; block 0x4401
0x004401:	movs    	r1, #0
0x004403:	str     	r1, [sp]
0x004405:	str     	r1, [sp, #4]
0x004407:	movs    	r2, #0
0x004409:	movs    	r1, #0xbb
0x00440b:	adds    	r3, r4, #0
0x00440d:	adds    	r0, r6, #0
0x00440f:	str     	r2, [sp, #8]
0x004411:	bl      	#0x5159
; block 0x4415
0x004415:	movs    	r1, #0
0x004417:	str     	r1, [sp]
0x004419:	str     	r1, [sp, #4]
0x00441b:	movs    	r2, #0
0x00441d:	movs    	r1, #0xcc
0x00441f:	adds    	r3, r4, #0
0x004421:	adds    	r0, r6, #0
0x004423:	str     	r2, [sp, #8]
0x004425:	bl      	#0x5159
; block 0x4429
0x004429:	movs    	r1, #0
0x00442b:	movs    	r2, #0
0x00442d:	str     	r2, [sp, #8]
0x00442f:	str     	r1, [sp]
0x004431:	str     	r1, [sp, #4]
0x004433:	movs    	r1, #0x14
0x004435:	movs    	r2, #0xd
0x004437:	movs    	r3, #1
0x004439:	adds    	r0, r6, #0
0x00443b:	bl      	#0x5159
; block 0x443f
0x00443f:	movs    	r2, #0
0x004441:	movs    	r1, #0
0x004443:	str     	r1, [sp, #4]
0x004445:	str     	r2, [sp, #8]
0x004447:	movs    	r0, #2
0x004449:	str     	r0, [sp]
0x00444b:	movs    	r2, #0xe
0x00444d:	movs    	r1, #0x14
0x00444f:	movs    	r3, #1
0x004451:	adds    	r0, r6, #0
0x004453:	bl      	#0x5159
; block 0x4457
0x004457:	movs    	r1, #0
0x004459:	movs    	r2, #0
0x00445b:	str     	r2, [sp, #8]
0x00445d:	str     	r1, [sp]
0x00445f:	str     	r1, [sp, #4]
0x004461:	movs    	r1, #0x14
0x004463:	movs    	r2, #0xf
0x004465:	adds    	r3, r4, #0
0x004467:	adds    	r0, r6, #0
0x004469:	bl      	#0x5159
; block 0x446d
0x00446d:	ldr     	r5, [pc, #0x130]
0x00446f:	movs    	r2, #0
0x004471:	add     	r5, sb
0x004473:	str     	r4, [r5, #0x20]
0x004475:	movs    	r1, #0
0x004477:	str     	r1, [sp, #4]
0x004479:	str     	r2, [sp, #8]
0x00447b:	movs    	r0, #2
0x00447d:	str     	r0, [sp]
0x00447f:	movs    	r2, #0x10
0x004481:	movs    	r1, #0x14
0x004483:	adds    	r3, r4, #0
0x004485:	adds    	r0, r6, #0
0x004487:	bl      	#0x5159
; block 0x448b
0x00448b:	movs    	r1, #0
0x00448d:	movs    	r2, #0
0x00448f:	str     	r2, [sp, #8]
0x004491:	str     	r1, [sp]
0x004493:	str     	r1, [sp, #4]
0x004495:	movs    	r1, #0x15
0x004497:	movs    	r2, #5
0x004499:	adds    	r3, r4, #0
0x00449b:	adds    	r0, r6, #0
0x00449d:	bl      	#0x5159
; block 0x44a1
0x0044a1:	movs    	r1, #0
0x0044a3:	movs    	r2, #0
0x0044a5:	str     	r2, [sp, #8]
0x0044a7:	str     	r1, [sp]
0x0044a9:	str     	r1, [sp, #4]
0x0044ab:	movs    	r1, #0xe1
0x0044ad:	movs    	r2, #0x15
0x0044af:	adds    	r3, r4, #0
0x0044b1:	adds    	r0, r6, #0
0x0044b3:	bl      	#0x5159
; block 0x44b7
0x0044b7:	movs    	r1, #0
0x0044b9:	movs    	r2, #0
0x0044bb:	str     	r2, [sp, #8]
0x0044bd:	str     	r1, [sp]
0x0044bf:	str     	r1, [sp, #4]
0x0044c1:	movs    	r1, #0x16
0x0044c3:	adds    	r2, r0, #0
0x0044c5:	adds    	r3, r4, #0
0x0044c7:	adds    	r0, r6, #0
0x0044c9:	bl      	#0x5159
; block 0x44cd
0x0044cd:	movs    	r1, #0
0x0044cf:	movs    	r2, #0
0x0044d1:	str     	r2, [sp, #8]
0x0044d3:	str     	r1, [sp]
0x0044d5:	str     	r1, [sp, #4]
0x0044d7:	movs    	r1, #0x15
0x0044d9:	movs    	r2, #5
0x0044db:	adds    	r3, r4, #0
0x0044dd:	adds    	r0, r6, #0
0x0044df:	bl      	#0x5159
; block 0x44e3
0x0044e3:	movs    	r1, #0
0x0044e5:	movs    	r2, #0
0x0044e7:	str     	r2, [sp, #8]
0x0044e9:	str     	r1, [sp]
0x0044eb:	str     	r1, [sp, #4]
0x0044ed:	movs    	r1, #0x15
0x0044ef:	movs    	r2, #5
0x0044f1:	adds    	r3, r4, #0
0x0044f3:	adds    	r0, r6, #0
0x0044f5:	bl      	#0x5159
; block 0x44f9
0x0044f9:	movs    	r2, #0
0x0044fb:	mvns    	r1, r2
0x0044fd:	ldr     	r3, [pc, #0xa4]
0x0044ff:	str     	r1, [sp]
0x004501:	str     	r1, [sp, #4]
0x004503:	str     	r2, [sp, #8]
0x004505:	add     	r3, pc
0x004507:	ldr     	r0, [pc, #0x98]
0x004509:	movs    	r1, #5
0x00450b:	add     	r0, sb
0x00450d:	adds    	r0, #0x80
0x00450f:	ldr     	r2, [r0, #0xc]
0x004511:	adds    	r0, r6, #0
0x004513:	bl      	#0x5159
; block 0x4517
0x004517:	ldr     	r1, [pc, #0x88]
0x004519:	movs    	r2, #0
0x00451b:	add     	r1, sb
0x00451d:	adds    	r1, #0x80
0x00451f:	str     	r0, [r1, #0xc]
0x004521:	movs    	r1, #0
0x004523:	str     	r1, [sp]
0x004525:	str     	r1, [sp, #4]
0x004527:	str     	r2, [sp, #8]
0x004529:	movs    	r2, #5
0x00452b:	movs    	r1, #0x15
0x00452d:	movs    	r3, #1
0x00452f:	adds    	r0, r6, #0
0x004531:	bl      	#0x5159
; block 0x4535
0x004535:	ldr     	r1, [pc, #0x68]
0x004537:	movs    	r0, #1
0x004539:	add     	r1, sb
0x00453b:	adds    	r1, #0x80
0x00453d:	str     	r0, [r1, #0x10]
0x00453f:	movs    	r0, #0xa
0x004541:	str     	r0, [r5, #0x78]
0x004543:	movs    	r1, #0
0x004545:	movs    	r2, #0
0x004547:	str     	r2, [sp, #8]
0x004549:	str     	r1, [sp, #4]
0x00454b:	movs    	r0, #2
0x00454d:	str     	r0, [sp]
0x00454f:	movs    	r1, #0x14
0x004551:	movs    	r2, #0x17
0x004553:	movs    	r3, #0x46
0x004555:	adds    	r0, r6, #0
0x004557:	bl      	#0x5159
; block 0x455b
0x00455b:	str     	r4, [r5, #0x10]
0x00455d:	str     	r4, [r5, #0x14]
0x00455f:	str     	r4, [r5, #0x18]
0x004561:	str     	r4, [r5, #0x1c]
0x004563:	ldr     	r0, [r5, #0xc]
0x004565:	cmp     	r0, #0
0x004567:	bne     	#0x4581
; block 0x4569
0x004569:	movs    	r1, #0
0x00456b:	str     	r1, [sp]
0x00456d:	str     	r1, [sp, #4]
0x00456f:	movs    	r2, #0
0x004571:	movs    	r1, #0x13
0x004573:	adds    	r3, r4, #0
0x004575:	adds    	r0, r6, #0
0x004577:	str     	r2, [sp, #8]
0x004579:	bl      	#0x5159
; block 0x457d
0x00457d:	str     	r0, [r5, #0xc]
0x00457f:	b       	#0x4585
; block 0x4581
0x004581:	bl      	#0x5ebd
; block 0x4585
0x004585:	movs    	r1, #0
0x004587:	str     	r1, [sp]
0x004589:	str     	r1, [sp, #4]
0x00458b:	movs    	r1, #0xff
0x00458d:	movs    	r2, #0
0x00458f:	adds    	r1, #0x54
0x004591:	adds    	r3, r4, #0
0x004593:	adds    	r0, r6, #0
0x004595:	str     	r2, [sp, #8]
0x004597:	bl      	#0x5159
; block 0x459b
0x00459b:	add     	sp, #0xc
0x00459d:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_45a1 @ 0x45a1 offset=0x45a0 size=8 blocks=1 cc=1 =====
; block 0x45a1
0x0045a1:	movs    	r4, r1
0x0045a3:	movs    	r0, r0
0x0045a5:	movs    	r7, #0x3c
0x0045a7:	movs    	r0, r0
0x0045a9:	push    	{r4, r5, r6, r7, lr}
0x0045ab:	sub     	sp, #0xc
0x0045ad:	movs    	r1, #0
0x0045af:	str     	r1, [sp]
0x0045b1:	str     	r1, [sp, #4]
0x0045b3:	movs    	r4, #0xf1
0x0045b5:	movs    	r2, #0
0x0045b7:	lsls    	r4, r4, #9
0x0045b9:	movs    	r1, #0x13
0x0045bb:	movs    	r3, #0
0x0045bd:	adds    	r0, r4, #0
0x0045bf:	str     	r2, [sp, #8]
0x0045c1:	bl      	#0x5159

; ===== sub_45a9 @ 0x45a9 offset=0x45a8 size=464 blocks=23 cc=21 =====
; block 0x45a9
0x0045a9:	push    	{r4, r5, r6, r7, lr}
0x0045ab:	sub     	sp, #0xc
0x0045ad:	movs    	r1, #0
0x0045af:	str     	r1, [sp]
0x0045b1:	str     	r1, [sp, #4]
0x0045b3:	movs    	r4, #0xf1
0x0045b5:	movs    	r2, #0
0x0045b7:	lsls    	r4, r4, #9
0x0045b9:	movs    	r1, #0x13
0x0045bb:	movs    	r3, #0
0x0045bd:	adds    	r0, r4, #0
0x0045bf:	str     	r2, [sp, #8]
0x0045c1:	bl      	#0x5159
; block 0x45c5
0x0045c5:	movs    	r1, #0
0x0045c7:	str     	r1, [sp]
0x0045c9:	str     	r1, [sp, #4]
0x0045cb:	movs    	r2, #0
0x0045cd:	movs    	r1, #0x34
0x0045cf:	adds    	r5, r0, #0
0x0045d1:	movs    	r3, #0
0x0045d3:	adds    	r0, r4, #0
0x0045d5:	str     	r2, [sp, #8]
0x0045d7:	bl      	#0x5159
; block 0x45db
0x0045db:	movs    	r1, #0
0x0045dd:	str     	r1, [sp]
0x0045df:	str     	r1, [sp, #4]
0x0045e1:	movs    	r2, #0
0x0045e3:	ldr     	r7, [pc, #0x194]
0x0045e5:	str     	r2, [sp, #8]
0x0045e7:	movs    	r1, #0x26
0x0045e9:	movs    	r3, #0
0x0045eb:	add     	r7, sb
0x0045ed:	ldr     	r2, [r7, #0x18]
0x0045ef:	adds    	r0, r4, #0
0x0045f1:	bl      	#0x5159
; block 0x45f5
0x0045f5:	ldr     	r6, [pc, #0x184]
0x0045f7:	add     	r6, pc
0x0045f9:	cmp     	r0, #0
0x0045fb:	beq     	#0x4603
; block 0x45fd
0x0045fd:	ldr     	r1, [r7, #0x10]
0x0045ff:	cmp     	r1, r0
0x004601:	blt     	#0x4635
; block 0x4603
0x004603:	movs    	r2, #0
0x004605:	movs    	r1, #0
0x004607:	str     	r2, [sp, #8]
0x004609:	ldr     	r2, [pc, #0x174]
0x00460b:	str     	r1, [sp]
0x00460d:	str     	r1, [sp, #4]
0x00460f:	adds    	r3, r6, #0
0x004611:	add     	r2, pc
0x004613:	movs    	r1, #0x35
0x004615:	adds    	r0, r4, #0
0x004617:	bl      	#0x5159
; block 0x461b
0x00461b:	movs    	r1, #0
0x00461d:	adds    	r3, r0, #0
0x00461f:	movs    	r2, #0
0x004621:	str     	r2, [sp, #8]
0x004623:	str     	r1, [sp]
0x004625:	str     	r1, [sp, #4]
0x004627:	movs    	r1, #0x36
0x004629:	adds    	r2, r5, #0
0x00462b:	movs    	r0, #0xf1
0x00462d:	lsls    	r0, r0, #9
0x00462f:	bl      	#0x5159
; block 0x4633
0x004633:	b       	#0x4697
; block 0x4635
0x004635:	movs    	r2, #0
0x004637:	movs    	r1, #0
0x004639:	str     	r2, [sp, #8]
0x00463b:	ldr     	r2, [pc, #0x148]
0x00463d:	str     	r1, [sp]
0x00463f:	str     	r1, [sp, #4]
0x004641:	adds    	r3, r6, #0
0x004643:	add     	r2, pc
0x004645:	movs    	r1, #0x35
0x004647:	adds    	r0, r4, #0
0x004649:	bl      	#0x5159
; block 0x464d
0x00464d:	movs    	r1, #0
0x00464f:	adds    	r3, r0, #0
0x004651:	movs    	r2, #0
0x004653:	str     	r2, [sp, #8]
0x004655:	str     	r1, [sp]
0x004657:	str     	r1, [sp, #4]
0x004659:	movs    	r1, #0x36
0x00465b:	adds    	r2, r5, #0
0x00465d:	movs    	r0, #0xf1
0x00465f:	lsls    	r0, r0, #9
0x004661:	bl      	#0x5159
; block 0x4665
0x004665:	movs    	r2, #0
0x004667:	movs    	r1, #0
0x004669:	str     	r2, [sp, #8]
0x00466b:	ldr     	r2, [pc, #0x11c]
0x00466d:	str     	r1, [sp]
0x00466f:	str     	r1, [sp, #4]
0x004671:	adds    	r3, r6, #0
0x004673:	add     	r2, pc
0x004675:	movs    	r1, #0x35
0x004677:	movs    	r0, #0xf1
0x004679:	lsls    	r0, r0, #9
0x00467b:	bl      	#0x5159
; block 0x467f
0x00467f:	movs    	r1, #0
0x004681:	adds    	r3, r0, #0
0x004683:	movs    	r2, #0
0x004685:	str     	r2, [sp, #8]
0x004687:	str     	r1, [sp]
0x004689:	str     	r1, [sp, #4]
0x00468b:	movs    	r1, #0x36
0x00468d:	adds    	r2, r5, #0
0x00468f:	movs    	r0, #0xf1
0x004691:	lsls    	r0, r0, #9
0x004693:	bl      	#0x5159
; block 0x4697
0x004697:	movs    	r2, #0
0x004699:	movs    	r1, #0
0x00469b:	str     	r2, [sp, #8]
0x00469d:	ldr     	r2, [pc, #0xec]
0x00469f:	str     	r1, [sp]
0x0046a1:	str     	r1, [sp, #4]
0x0046a3:	adds    	r3, r6, #0
0x0046a5:	add     	r2, pc
0x0046a7:	movs    	r1, #0x35
0x0046a9:	movs    	r0, #0xf1
0x0046ab:	lsls    	r0, r0, #9
0x0046ad:	bl      	#0x5159
; block 0x46b1
0x0046b1:	movs    	r1, #0
0x0046b3:	adds    	r3, r0, #0
0x0046b5:	movs    	r2, #0
0x0046b7:	str     	r2, [sp, #8]
0x0046b9:	str     	r1, [sp]
0x0046bb:	str     	r1, [sp, #4]
0x0046bd:	movs    	r1, #0x36
0x0046bf:	adds    	r2, r5, #0
0x0046c1:	movs    	r0, #0xf1
0x0046c3:	lsls    	r0, r0, #9
0x0046c5:	bl      	#0x5159
; block 0x46c9
0x0046c9:	movs    	r1, #0
0x0046cb:	movs    	r2, #0
0x0046cd:	str     	r2, [sp, #8]
0x0046cf:	str     	r1, [sp]
0x0046d1:	str     	r1, [sp, #4]
0x0046d3:	movs    	r1, #0x26
0x0046d5:	adds    	r2, r5, #0
0x0046d7:	movs    	r3, #0
0x0046d9:	movs    	r0, #0xf1
0x0046db:	lsls    	r0, r0, #9
0x0046dd:	bl      	#0x5159
; block 0x46e1
0x0046e1:	movs    	r2, #0
0x0046e3:	movs    	r1, #0
0x0046e5:	str     	r2, [sp, #8]
0x0046e7:	adds    	r6, r0, #0
0x0046e9:	adds    	r2, r0, #0
0x0046eb:	str     	r1, [sp]
0x0046ed:	str     	r1, [sp, #4]
0x0046ef:	movs    	r1, #0xa
0x0046f1:	movs    	r0, #0xf1
0x0046f3:	movs    	r3, #4
0x0046f5:	lsls    	r0, r0, #9
0x0046f7:	bl      	#0x5159
; block 0x46fb
0x0046fb:	movs    	r4, #0
0x0046fd:	cmp     	r6, #0
0x0046ff:	str     	r0, [r7, #0x1c]
0x004701:	ble     	#0x4727
; block 0x4703
0x004703:	movs    	r1, #0
0x004705:	movs    	r2, #0
0x004707:	str     	r2, [sp, #8]
0x004709:	str     	r1, [sp]
0x00470b:	str     	r1, [sp, #4]
0x00470d:	adds    	r3, r4, #0
0x00470f:	adds    	r2, r5, #0
0x004711:	movs    	r1, #0x27
0x004713:	movs    	r0, #0xf1
0x004715:	lsls    	r0, r0, #9
0x004717:	bl      	#0x5159
; block 0x471b
0x00471b:	lsls    	r1, r4, #2
0x00471d:	ldr     	r2, [r7, #0x1c]
0x00471f:	adds    	r4, #1
0x004721:	cmp     	r4, r6
0x004723:	str     	r0, [r2, r1]
0x004725:	blt     	#0x4703
; block 0x4727
0x004727:	movs    	r1, #0
0x004729:	movs    	r2, #0
0x00472b:	movs    	r4, #0
0x00472d:	adds    	r3, r4, #0
0x00472f:	str     	r2, [sp, #8]
0x004731:	str     	r1, [sp]
0x004733:	str     	r1, [sp, #4]
0x004735:	movs    	r1, #0x28
0x004737:	adds    	r2, r5, #0
0x004739:	movs    	r0, #0xf1
0x00473b:	lsls    	r0, r0, #9
0x00473d:	bl      	#0x5159
; block 0x4741
0x004741:	movs    	r1, #0
0x004743:	movs    	r2, #0
0x004745:	str     	r2, [sp, #8]
0x004747:	str     	r1, [sp]
0x004749:	str     	r1, [sp, #4]
0x00474b:	adds    	r3, r4, #0
0x00474d:	adds    	r2, r5, #0
0x00474f:	movs    	r1, #9
0x004751:	movs    	r0, #0xf1
0x004753:	lsls    	r0, r0, #9
0x004755:	bl      	#0x5159
; block 0x4759
0x004759:	movs    	r2, #0
0x00475b:	movs    	r1, #0
0x00475d:	movs    	r0, #2
0x00475f:	str     	r0, [sp]
0x004761:	str     	r1, [sp, #4]
0x004763:	str     	r2, [sp, #8]
0x004765:	movs    	r2, #0x17
0x004767:	movs    	r1, #0x14
0x004769:	movs    	r0, #0xf1
0x00476b:	movs    	r3, #0xcc
0x00476d:	lsls    	r0, r0, #9
0x00476f:	bl      	#0x5159
; block 0x4773
0x004773:	str     	r4, [r7, #0x14]
0x004775:	add     	sp, #0xc
0x004777:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_4791 @ 0x4791 offset=0x4790 size=138 blocks=7 cc=5 =====
; block 0x4791
0x004791:	push    	{r4, lr}
0x004793:	ldr     	r3, [pc, #0x88]
0x004795:	movs    	r1, #0
0x004797:	movs    	r4, #0
0x004799:	sub     	sp, #0x10
0x00479b:	add     	r3, sb
0x00479d:	lsls    	r2, r1, #2
0x00479f:	adds    	r1, #1
0x0047a1:	cmp     	r1, #3
0x0047a3:	str     	r4, [r3, r2]
0x0047a5:	blt     	#0x479d
; block 0x479d
0x00479d:	lsls    	r2, r1, #2
0x00479f:	adds    	r1, #1
0x0047a1:	cmp     	r1, #3
0x0047a3:	str     	r4, [r3, r2]
0x0047a5:	blt     	#0x479d
; block 0x47a7
0x0047a7:	ldr     	r1, [pc, #0x74]
0x0047a9:	movs    	r2, #0
0x0047ab:	add     	r1, sb
0x0047ad:	subs    	r1, #0xa4
0x0047af:	str     	r0, [r1, #0x18]
0x0047b1:	str     	r4, [r1, #0x10]
0x0047b3:	movs    	r0, #2
0x0047b5:	movs    	r1, #0
0x0047b7:	str     	r1, [sp, #4]
0x0047b9:	str     	r0, [sp]
0x0047bb:	subs    	r3, r0, #3
0x0047bd:	str     	r2, [sp, #8]
0x0047bf:	movs    	r2, #0x1a
0x0047c1:	movs    	r0, #0xf1
0x0047c3:	movs    	r1, #0x14
0x0047c5:	lsls    	r0, r0, #9
0x0047c7:	bl      	#0x5159
; block 0x47cb
0x0047cb:	movs    	r2, #0
0x0047cd:	movs    	r1, #0
0x0047cf:	movs    	r0, #2
0x0047d1:	str     	r0, [sp]
0x0047d3:	str     	r1, [sp, #4]
0x0047d5:	str     	r2, [sp, #8]
0x0047d7:	movs    	r2, #0x1b
0x0047d9:	movs    	r1, #0x14
0x0047db:	movs    	r0, #0xf1
0x0047dd:	adds    	r3, r4, #0
0x0047df:	lsls    	r0, r0, #9
0x0047e1:	bl      	#0x5159
; block 0x47e5
0x0047e5:	movs    	r2, #0
0x0047e7:	movs    	r1, #0
0x0047e9:	movs    	r0, #2
0x0047eb:	str     	r0, [sp]
0x0047ed:	str     	r1, [sp, #4]
0x0047ef:	str     	r2, [sp, #8]
0x0047f1:	movs    	r2, #0x17
0x0047f3:	movs    	r1, #0x14
0x0047f5:	movs    	r0, #0xf1
0x0047f7:	movs    	r3, #0xcb
0x0047f9:	lsls    	r0, r0, #9
0x0047fb:	bl      	#0x5159
; block 0x47ff
0x0047ff:	movs    	r1, #0
0x004801:	str     	r1, [sp]
0x004803:	str     	r1, [sp, #4]
0x004805:	movs    	r1, #0xff
0x004807:	movs    	r2, #0
0x004809:	adds    	r3, r4, #0
0x00480b:	adds    	r1, #0x55
0x00480d:	movs    	r0, #0xf1
0x00480f:	lsls    	r0, r0, #9
0x004811:	str     	r2, [sp, #8]
0x004813:	bl      	#0x5159
; block 0x4817
0x004817:	add     	sp, #0x10
0x004819:	pop     	{r4, pc}

; ===== sub_481d @ 0x481d offset=0x481c size=4 blocks=1 cc=1 =====
; block 0x481d
0x00481d:	lsls    	r0, r6, #2
0x00481f:	movs    	r0, r0
0x004821:	push    	{r0, r4, r5, r6, r7, lr}
0x004823:	sub     	sp, #0x10
0x004825:	movs    	r2, #0
0x004827:	movs    	r1, #0
0x004829:	str     	r2, [sp, #8]
0x00482b:	ldr     	r2, [pc, #0x180]
0x00482d:	str     	r1, [sp]
0x00482f:	str     	r1, [sp, #4]
0x004831:	movs    	r3, #0
0x004833:	add     	r2, pc
0x004835:	movs    	r1, #0x58
0x004837:	movs    	r0, #0xf1
0x004839:	lsls    	r0, r0, #9
0x00483b:	bl      	#0x5159

; ===== sub_4821 @ 0x4821 offset=0x4820 size=396 blocks=26 cc=19 =====
; block 0x4821
0x004821:	push    	{r0, r4, r5, r6, r7, lr}
0x004823:	sub     	sp, #0x10
0x004825:	movs    	r2, #0
0x004827:	movs    	r1, #0
0x004829:	str     	r2, [sp, #8]
0x00482b:	ldr     	r2, [pc, #0x180]
0x00482d:	str     	r1, [sp]
0x00482f:	str     	r1, [sp, #4]
0x004831:	movs    	r3, #0
0x004833:	add     	r2, pc
0x004835:	movs    	r1, #0x58
0x004837:	movs    	r0, #0xf1
0x004839:	lsls    	r0, r0, #9
0x00483b:	bl      	#0x5159
; block 0x483f
0x00483f:	adds    	r7, r0, #0
0x004841:	cmp     	r0, #0
0x004843:	blt     	#0x4929
; block 0x4845
0x004845:	movs    	r1, #0
0x004847:	str     	r1, [sp]
0x004849:	str     	r1, [sp, #4]
0x00484b:	movs    	r2, #0
0x00484d:	ldr     	r6, [pc, #0x160]
0x00484f:	movs    	r4, #0xf1
0x004851:	lsls    	r4, r4, #9
0x004853:	str     	r2, [sp, #8]
0x004855:	movs    	r1, #0x26
0x004857:	movs    	r3, #0
0x004859:	add     	r6, sb
0x00485b:	ldr     	r2, [r6, #0xc]
0x00485d:	adds    	r0, r4, #0
0x00485f:	bl      	#0x5159
; block 0x4863
0x004863:	str     	r0, [sp, #0xc]
0x004865:	movs    	r5, #0
0x004867:	ldr     	r1, [pc, #0x14c]
0x004869:	mvns    	r0, r5
0x00486b:	str     	r5, [r6, #0x7c]
0x00486d:	add     	r1, sb
0x00486f:	str     	r0, [r1, #4]
0x004871:	ldr     	r0, [sp, #0xc]
0x004873:	cmp     	r0, #0
0x004875:	ble     	#0x4941
; block 0x4877
0x004877:	movs    	r1, #0
0x004879:	ldr     	r0, [pc, #0x134]
0x00487b:	str     	r1, [sp]
0x00487d:	str     	r1, [sp, #4]
0x00487f:	movs    	r2, #0
0x004881:	str     	r2, [sp, #8]
0x004883:	add     	r0, sb
0x004885:	ldr     	r2, [r0, #0xc]
0x004887:	movs    	r0, #0xf1
0x004889:	movs    	r1, #0x27
0x00488b:	adds    	r3, r5, #0
0x00488d:	lsls    	r0, r0, #9
0x00488f:	bl      	#0x5159
; block 0x4893
0x004893:	movs    	r3, #9
0x004895:	ldrsb   	r1, [r0, r3]
0x004897:	cmp     	r1, r7
0x004899:	beq     	#0x48cd
; block 0x489b
0x00489b:	ldr     	r6, [r0, #0x1c]
0x00489d:	movs    	r4, #0
0x00489f:	cmp     	r6, #0
0x0048a1:	beq     	#0x48d9
; block 0x48a3
0x0048a3:	movs    	r1, #0
0x0048a5:	movs    	r2, #0
0x0048a7:	str     	r2, [sp, #8]
0x0048a9:	str     	r1, [sp]
0x0048ab:	str     	r1, [sp, #4]
0x0048ad:	movs    	r1, #0x11
0x0048af:	adds    	r2, r6, #0
0x0048b1:	movs    	r3, #1
0x0048b3:	movs    	r0, #0xf1
0x0048b5:	lsls    	r0, r0, #9
0x0048b7:	bl      	#0x5159
; block 0x48bb
0x0048bb:	cmp     	r0, #0
0x0048bd:	ble     	#0x48d9
; block 0x48bf
0x0048bf:	ldrsb   	r1, [r6, r4]
0x0048c1:	cmp     	r1, r7
0x0048c3:	beq     	#0x48cd
; block 0x48c5
0x0048c5:	adds    	r4, #1
0x0048c7:	cmp     	r4, r0
0x0048c9:	blt     	#0x48bf
; block 0x48cb
0x0048cb:	b       	#0x48d9
; block 0x48cd
0x0048cd:	ldr     	r0, [pc, #0xe0]
0x0048cf:	ldr     	r1, [pc, #0xe4]
0x0048d1:	add     	r0, sb
0x0048d3:	str     	r5, [r0, #0x7c]
0x0048d5:	add     	r1, sb
0x0048d7:	str     	r5, [r1, #4]
0x0048d9:	ldr     	r0, [sp, #0xc]
0x0048db:	adds    	r5, #1
0x0048dd:	cmp     	r5, r0
0x0048df:	blt     	#0x4877
; block 0x48d9
0x0048d9:	ldr     	r0, [sp, #0xc]
0x0048db:	adds    	r5, #1
0x0048dd:	cmp     	r5, r0
0x0048df:	blt     	#0x4877
; block 0x48e1
0x0048e1:	ldr     	r4, [pc, #0xcc]
0x0048e3:	add     	r4, sb
0x0048e5:	ldr     	r3, [r4, #0x7c]
0x0048e7:	cmp     	r3, #0
0x0048e9:	beq     	#0x4941
; block 0x48eb
0x0048eb:	movs    	r1, #0
0x0048ed:	str     	r1, [sp]
0x0048ef:	str     	r1, [sp, #4]
0x0048f1:	movs    	r2, #0
0x0048f3:	str     	r2, [sp, #8]
0x0048f5:	movs    	r1, #0x27
0x0048f7:	movs    	r0, #0xf1
0x0048f9:	lsls    	r0, r0, #9
0x0048fb:	ldr     	r2, [r4, #0xc]
0x0048fd:	bl      	#0x5159
; block 0x4901
0x004901:	movs    	r1, #0
0x004903:	str     	r1, [sp]
0x004905:	str     	r1, [sp, #4]
0x004907:	movs    	r2, #0
0x004909:	str     	r2, [sp, #8]
0x00490b:	adds    	r5, r0, #0
0x00490d:	movs    	r0, #0xf1
0x00490f:	ldr     	r2, [r4, #0xc]
0x004911:	movs    	r1, #0x4b
0x004913:	lsls    	r0, r0, #9
0x004915:	ldr     	r3, [r4, #0x7c]
0x004917:	bl      	#0x5159
; block 0x491b
0x00491b:	movs    	r1, #0
0x00491d:	movs    	r2, #0
0x00491f:	str     	r2, [sp, #8]
0x004921:	adds    	r3, r5, #0
0x004923:	str     	r1, [sp]
0x004925:	str     	r1, [sp, #4]
0x004927:	b       	#0x492b
; block 0x4929
0x004929:	b       	#0x499b
; block 0x492b
0x00492b:	movs    	r1, #0xf7
0x00492d:	movs    	r0, #0xf1
0x00492f:	lsls    	r0, r0, #9
0x004931:	ldr     	r2, [r4, #0xc]
0x004933:	bl      	#0x5159
; block 0x4937
0x004937:	ldr     	r1, [pc, #0x7c]
0x004939:	movs    	r0, #0
0x00493b:	str     	r0, [r4, #0x7c]
0x00493d:	add     	r1, sb
0x00493f:	str     	r0, [r1, #4]
0x004941:	ldr     	r6, [pc, #0x6c]
0x004943:	ldr     	r0, [sp, #0x10]
0x004945:	movs    	r2, #0
0x004947:	add     	r6, sb
0x004949:	str     	r0, [r6, #4]
0x00494b:	mvns    	r1, r2
0x00494d:	ldr     	r3, [pc, #0x68]
0x00494f:	str     	r1, [sp]
0x004951:	str     	r1, [sp, #4]
0x004953:	str     	r2, [sp, #8]
0x004955:	add     	r3, pc
0x004957:	movs    	r1, #5
0x004959:	movs    	r0, #0xf1
0x00495b:	lsls    	r0, r0, #9
0x00495d:	ldr     	r2, [r6]
0x00495f:	bl      	#0x5159
; block 0x4941
0x004941:	ldr     	r6, [pc, #0x6c]
0x004943:	ldr     	r0, [sp, #0x10]
0x004945:	movs    	r2, #0
0x004947:	add     	r6, sb
0x004949:	str     	r0, [r6, #4]
0x00494b:	mvns    	r1, r2
0x00494d:	ldr     	r3, [pc, #0x68]
0x00494f:	str     	r1, [sp]
0x004951:	str     	r1, [sp, #4]
0x004953:	str     	r2, [sp, #8]
0x004955:	add     	r3, pc
0x004957:	movs    	r1, #5
0x004959:	movs    	r0, #0xf1
0x00495b:	lsls    	r0, r0, #9
0x00495d:	ldr     	r2, [r6]
0x00495f:	bl      	#0x5159
; block 0x4963
0x004963:	str     	r0, [r6]
0x004965:	movs    	r0, #2
0x004967:	movs    	r2, #0
0x004969:	movs    	r1, #0
0x00496b:	str     	r1, [sp, #4]
0x00496d:	str     	r2, [sp, #8]
0x00496f:	str     	r0, [sp]
0x004971:	movs    	r0, #0xf1
0x004973:	movs    	r2, #0x17
0x004975:	movs    	r1, #0x14
0x004977:	movs    	r3, #0xc9
0x004979:	lsls    	r0, r0, #9
0x00497b:	bl      	#0x5159
; block 0x497f
0x00497f:	movs    	r1, #0
0x004981:	str     	r1, [sp]
0x004983:	str     	r1, [sp, #4]
0x004985:	movs    	r1, #0xff
0x004987:	movs    	r2, #0
0x004989:	adds    	r1, #0x55
0x00498b:	movs    	r3, #0
0x00498d:	movs    	r0, #0xf1
0x00498f:	lsls    	r0, r0, #9
0x004991:	str     	r2, [sp, #8]
0x004993:	bl      	#0x5159
; block 0x4997
0x004997:	add     	sp, #0x14
0x004999:	pop     	{r4, r5, r6, r7, pc}
; block 0x499b
0x00499b:	ldr     	r6, [pc, #0x14]
0x00499d:	movs    	r3, #0
0x00499f:	ldr     	r1, [pc, #0x14]
0x0049a1:	add     	r6, sb
0x0049a3:	str     	r3, [r6, #0x7c]
0x0049a5:	mvns    	r0, r3
0x0049a7:	add     	r1, sb
0x0049a9:	str     	r0, [r1, #4]
0x0049ab:	b       	#0x4941

; ===== sub_49bd @ 0x49bd offset=0x49bc size=220 blocks=11 cc=9 =====
; block 0x49bd
0x0049bd:	push    	{r4, r5, r6, r7, lr}
0x0049bf:	sub     	sp, #0xc
0x0049c1:	movs    	r2, #0
0x0049c3:	movs    	r1, #0
0x0049c5:	str     	r2, [sp, #8]
0x0049c7:	movs    	r2, #0xff
0x0049c9:	str     	r1, [sp]
0x0049cb:	str     	r1, [sp, #4]
0x0049cd:	movs    	r7, #0xf1
0x0049cf:	movs    	r5, #0
0x0049d1:	adds    	r3, r5, #0
0x0049d3:	lsls    	r7, r7, #9
0x0049d5:	movs    	r1, #0xe1
0x0049d7:	adds    	r2, #0x22
0x0049d9:	adds    	r0, r7, #0
0x0049db:	bl      	#0x5159
; block 0x49df
0x0049df:	movs    	r1, #0
0x0049e1:	movs    	r2, #0
0x0049e3:	str     	r2, [sp, #8]
0x0049e5:	str     	r1, [sp]
0x0049e7:	str     	r1, [sp, #4]
0x0049e9:	movs    	r1, #0x11
0x0049eb:	adds    	r2, r0, #0
0x0049ed:	movs    	r3, #4
0x0049ef:	adds    	r0, r7, #0
0x0049f1:	bl      	#0x5159
; block 0x49f5
0x0049f5:	movs    	r1, #0
0x0049f7:	movs    	r2, #0
0x0049f9:	str     	r2, [sp, #8]
0x0049fb:	str     	r1, [sp]
0x0049fd:	str     	r1, [sp, #4]
0x0049ff:	movs    	r1, #0x6b
0x004a01:	movs    	r2, #1
0x004a03:	adds    	r4, r0, #0
0x004a05:	adds    	r3, r5, #0
0x004a07:	adds    	r0, r7, #0
0x004a09:	bl      	#0x5159
; block 0x4a0d
0x004a0d:	movs    	r1, #0
0x004a0f:	movs    	r2, #0
0x004a11:	str     	r2, [sp, #8]
0x004a13:	str     	r1, [sp]
0x004a15:	str     	r1, [sp, #4]
0x004a17:	movs    	r1, #3
0x004a19:	adds    	r2, r4, #0
0x004a1b:	adds    	r3, r5, #0
0x004a1d:	adds    	r0, r7, #0
0x004a1f:	bl      	#0x5159
; block 0x4a23
0x004a23:	ldr     	r6, [pc, #0x74]
0x004a25:	movs    	r2, #0
0x004a27:	add     	r6, sb
0x004a29:	str     	r0, [r6, #0x20]
0x004a2b:	movs    	r1, #0
0x004a2d:	str     	r2, [sp, #8]
0x004a2f:	movs    	r2, #0xff
0x004a31:	str     	r1, [sp]
0x004a33:	str     	r1, [sp, #4]
0x004a35:	movs    	r1, #0xe1
0x004a37:	adds    	r2, #0x22
0x004a39:	adds    	r3, r5, #0
0x004a3b:	adds    	r0, r7, #0
0x004a3d:	bl      	#0x5159
; block 0x4a41
0x004a41:	ldr     	r1, [r6, #0x20]
0x004a43:	lsls    	r1, r1, #2
0x004a45:	ldr     	r0, [r0, r1]
0x004a47:	ldrb    	r0, [r0, #0x14]
0x004a49:	cmp     	r0, #0
0x004a4b:	bne     	#0x4a95
; block 0x4a4d
0x004a4d:	movs    	r5, #0xff
0x004a4f:	adds    	r5, #0x22
0x004a51:	movs    	r6, #0
0x004a53:	movs    	r1, #0
0x004a55:	movs    	r2, #0
0x004a57:	str     	r2, [sp, #8]
0x004a59:	str     	r1, [sp]
0x004a5b:	str     	r1, [sp, #4]
0x004a5d:	adds    	r3, r6, #0
0x004a5f:	adds    	r2, r4, #0
0x004a61:	movs    	r1, #3
0x004a63:	movs    	r0, #0xf1
0x004a65:	lsls    	r0, r0, #9
0x004a67:	bl      	#0x5159
; block 0x4a53
0x004a53:	movs    	r1, #0
0x004a55:	movs    	r2, #0
0x004a57:	str     	r2, [sp, #8]
0x004a59:	str     	r1, [sp]
0x004a5b:	str     	r1, [sp, #4]
0x004a5d:	adds    	r3, r6, #0
0x004a5f:	adds    	r2, r4, #0
0x004a61:	movs    	r1, #3
0x004a63:	movs    	r0, #0xf1
0x004a65:	lsls    	r0, r0, #9
0x004a67:	bl      	#0x5159
; block 0x4a6b
0x004a6b:	ldr     	r7, [pc, #0x2c]
0x004a6d:	movs    	r1, #0
0x004a6f:	add     	r7, sb
0x004a71:	str     	r0, [r7, #0x20]
0x004a73:	movs    	r2, #0
0x004a75:	str     	r2, [sp, #8]
0x004a77:	str     	r1, [sp]
0x004a79:	str     	r1, [sp, #4]
0x004a7b:	adds    	r3, r6, #0
0x004a7d:	adds    	r2, r5, #0
0x004a7f:	movs    	r1, #0xe1
0x004a81:	movs    	r0, #0xf1
0x004a83:	lsls    	r0, r0, #9
0x004a85:	bl      	#0x5159
; block 0x4a89
0x004a89:	ldr     	r1, [r7, #0x20]
0x004a8b:	lsls    	r1, r1, #2
0x004a8d:	ldr     	r0, [r0, r1]
0x004a8f:	ldrb    	r0, [r0, #0x14]
0x004a91:	cmp     	r0, #0
0x004a93:	beq     	#0x4a53
; block 0x4a95
0x004a95:	add     	sp, #0xc
0x004a97:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_4a99 @ 0x4a99 offset=0x4a98 size=4 blocks=1 cc=1 =====
; block 0x4a99
0x004a99:	lsls    	r4, r1, #2
0x004a9b:	movs    	r0, r0
0x004a9d:	push    	{r4, r5, lr}
0x004a9f:	sub     	sp, #0xc
0x004aa1:	movs    	r1, #0
0x004aa3:	str     	r1, [sp]
0x004aa5:	str     	r1, [sp, #4]
0x004aa7:	movs    	r5, #0xf1
0x004aa9:	movs    	r2, #0
0x004aab:	lsls    	r5, r5, #9
0x004aad:	movs    	r1, #0x1d
0x004aaf:	movs    	r3, #0
0x004ab1:	adds    	r0, r5, #0
0x004ab3:	str     	r2, [sp, #8]
0x004ab5:	bl      	#0x5159

; ===== sub_4a9d @ 0x4a9d offset=0x4a9c size=370 blocks=18 cc=14 =====
; block 0x4a9d
0x004a9d:	push    	{r4, r5, lr}
0x004a9f:	sub     	sp, #0xc
0x004aa1:	movs    	r1, #0
0x004aa3:	str     	r1, [sp]
0x004aa5:	str     	r1, [sp, #4]
0x004aa7:	movs    	r5, #0xf1
0x004aa9:	movs    	r2, #0
0x004aab:	lsls    	r5, r5, #9
0x004aad:	movs    	r1, #0x1d
0x004aaf:	movs    	r3, #0
0x004ab1:	adds    	r0, r5, #0
0x004ab3:	str     	r2, [sp, #8]
0x004ab5:	bl      	#0x5159
; block 0x4ab9
0x004ab9:	movs    	r2, #0xff
0x004abb:	ldr     	r4, [pc, #0x154]
0x004abd:	movs    	r1, #0
0x004abf:	mvns    	r1, r1
0x004ac1:	adds    	r2, #0xe1
0x004ac3:	cmp     	r0, r2
0x004ac5:	add     	r4, sb
0x004ac7:	blt     	#0x4b9d
; block 0x4ac9
0x004ac9:	movs    	r2, #0
0x004acb:	adds    	r0, r1, #0
0x004acd:	ldr     	r3, [pc, #0x144]
0x004acf:	str     	r0, [sp]
0x004ad1:	str     	r2, [sp, #8]
0x004ad3:	str     	r1, [sp, #4]
0x004ad5:	add     	r3, pc
0x004ad7:	movs    	r1, #5
0x004ad9:	adds    	r0, r5, #0
0x004adb:	ldr     	r2, [r4, #0x24]
0x004add:	bl      	#0x5159
; block 0x4ae1
0x004ae1:	movs    	r2, #0
0x004ae3:	str     	r0, [r4, #0x24]
0x004ae5:	mvns    	r1, r2
0x004ae7:	ldr     	r3, [pc, #0x130]
0x004ae9:	str     	r1, [sp]
0x004aeb:	str     	r1, [sp, #4]
0x004aed:	str     	r2, [sp, #8]
0x004aef:	add     	r3, pc
0x004af1:	movs    	r1, #5
0x004af3:	adds    	r0, r5, #0
0x004af5:	ldr     	r2, [r4, #0x28]
0x004af7:	bl      	#0x5159
; block 0x4afb
0x004afb:	movs    	r2, #0
0x004afd:	str     	r0, [r4, #0x28]
0x004aff:	mvns    	r1, r2
0x004b01:	ldr     	r3, [pc, #0x118]
0x004b03:	str     	r1, [sp]
0x004b05:	str     	r1, [sp, #4]
0x004b07:	str     	r2, [sp, #8]
0x004b09:	add     	r3, pc
0x004b0b:	movs    	r1, #5
0x004b0d:	adds    	r0, r5, #0
0x004b0f:	ldr     	r2, [r4, #0x2c]
0x004b11:	bl      	#0x5159
; block 0x4b15
0x004b15:	movs    	r2, #0
0x004b17:	str     	r0, [r4, #0x2c]
0x004b19:	mvns    	r1, r2
0x004b1b:	ldr     	r3, [pc, #0x104]
0x004b1d:	str     	r1, [sp]
0x004b1f:	str     	r1, [sp, #4]
0x004b21:	str     	r2, [sp, #8]
0x004b23:	add     	r3, pc
0x004b25:	movs    	r1, #5
0x004b27:	adds    	r0, r5, #0
0x004b29:	ldr     	r2, [r4, #0x30]
0x004b2b:	bl      	#0x5159
; block 0x4b2f
0x004b2f:	movs    	r2, #0
0x004b31:	str     	r0, [r4, #0x30]
0x004b33:	mvns    	r1, r2
0x004b35:	ldr     	r3, [pc, #0xec]
0x004b37:	str     	r1, [sp]
0x004b39:	str     	r1, [sp, #4]
0x004b3b:	str     	r2, [sp, #8]
0x004b3d:	add     	r3, pc
0x004b3f:	movs    	r1, #5
0x004b41:	adds    	r0, r5, #0
0x004b43:	ldr     	r2, [r4, #0x34]
0x004b45:	bl      	#0x5159
; block 0x4b49
0x004b49:	movs    	r2, #0
0x004b4b:	str     	r0, [r4, #0x34]
0x004b4d:	mvns    	r1, r2
0x004b4f:	ldr     	r3, [pc, #0xd8]
0x004b51:	str     	r1, [sp]
0x004b53:	str     	r1, [sp, #4]
0x004b55:	str     	r2, [sp, #8]
0x004b57:	add     	r3, pc
0x004b59:	movs    	r1, #5
0x004b5b:	adds    	r0, r5, #0
0x004b5d:	ldr     	r2, [r4, #0x38]
0x004b5f:	bl      	#0x5159
; block 0x4b63
0x004b63:	movs    	r2, #0
0x004b65:	str     	r0, [r4, #0x38]
0x004b67:	mvns    	r1, r2
0x004b69:	ldr     	r3, [pc, #0xc0]
0x004b6b:	str     	r1, [sp]
0x004b6d:	str     	r1, [sp, #4]
0x004b6f:	str     	r2, [sp, #8]
0x004b71:	add     	r3, pc
0x004b73:	movs    	r1, #5
0x004b75:	adds    	r0, r5, #0
0x004b77:	ldr     	r2, [r4, #0x3c]
0x004b79:	bl      	#0x5159
; block 0x4b7d
0x004b7d:	movs    	r2, #0
0x004b7f:	str     	r0, [r4, #0x3c]
0x004b81:	mvns    	r1, r2
0x004b83:	ldr     	r3, [pc, #0xac]
0x004b85:	str     	r1, [sp]
0x004b87:	str     	r1, [sp, #4]
0x004b89:	str     	r2, [sp, #8]
0x004b8b:	add     	r3, pc
0x004b8d:	movs    	r1, #5
0x004b8f:	adds    	r0, r5, #0
0x004b91:	ldr     	r2, [r4, #0x40]
0x004b93:	bl      	#0x5159
; block 0x4b97
0x004b97:	str     	r0, [r4, #0x40]
0x004b99:	add     	sp, #0xc
0x004b9b:	pop     	{r4, r5, pc}
; block 0x4b99
0x004b99:	add     	sp, #0xc
0x004b9b:	pop     	{r4, r5, pc}
; block 0x4b9d
0x004b9d:	b       	#0x4b9f
; block 0x4b9f
0x004b9f:	movs    	r2, #0
0x004ba1:	mvns    	r0, r2
0x004ba3:	ldr     	r3, [pc, #0x90]
0x004ba5:	str     	r0, [sp]
0x004ba7:	str     	r2, [sp, #8]
0x004ba9:	str     	r1, [sp, #4]
0x004bab:	add     	r3, pc
0x004bad:	movs    	r1, #5
0x004baf:	adds    	r0, r5, #0
0x004bb1:	ldr     	r2, [r4, #0x24]
0x004bb3:	bl      	#0x5159
; block 0x4bb7
0x004bb7:	movs    	r2, #0
0x004bb9:	str     	r0, [r4, #0x24]
0x004bbb:	mvns    	r1, r2
0x004bbd:	ldr     	r3, [pc, #0x78]
0x004bbf:	str     	r1, [sp]
0x004bc1:	str     	r1, [sp, #4]
0x004bc3:	str     	r2, [sp, #8]
0x004bc5:	add     	r3, pc
0x004bc7:	movs    	r1, #5
0x004bc9:	movs    	r0, #0xf1
0x004bcb:	lsls    	r0, r0, #9
0x004bcd:	ldr     	r2, [r4, #0x28]
0x004bcf:	bl      	#0x5159
; block 0x4bd3
0x004bd3:	movs    	r2, #0
0x004bd5:	str     	r0, [r4, #0x28]
0x004bd7:	mvns    	r1, r2
0x004bd9:	ldr     	r3, [pc, #0x60]
0x004bdb:	str     	r1, [sp]
0x004bdd:	str     	r1, [sp, #4]
0x004bdf:	str     	r2, [sp, #8]
0x004be1:	add     	r3, pc
0x004be3:	movs    	r1, #5
0x004be5:	movs    	r0, #0xf1
0x004be7:	lsls    	r0, r0, #9
0x004be9:	ldr     	r2, [r4, #0x2c]
0x004beb:	bl      	#0x5159
; block 0x4bef
0x004bef:	movs    	r2, #0
0x004bf1:	str     	r0, [r4, #0x2c]
0x004bf3:	mvns    	r1, r2
0x004bf5:	ldr     	r3, [pc, #0x34]
0x004bf7:	str     	r1, [sp]
0x004bf9:	str     	r1, [sp, #4]
0x004bfb:	str     	r2, [sp, #8]
0x004bfd:	add     	r3, pc
0x004bff:	movs    	r1, #5
0x004c01:	movs    	r0, #0xf1
0x004c03:	lsls    	r0, r0, #9
0x004c05:	ldr     	r2, [r4, #0x30]
0x004c07:	bl      	#0x5159
; block 0x4c0b
0x004c0b:	str     	r0, [r4, #0x30]
0x004c0d:	b       	#0x4b99

; ===== sub_4c41 @ 0x4c41 offset=0x4c40 size=272 blocks=23 cc=19 =====
; block 0x4c41
0x004c41:	push    	{r4, r5, r6, r7, lr}
0x004c43:	adds    	r4, r0, #0
0x004c45:	ldr     	r0, [pc, #0x108]
0x004c47:	movs    	r6, #0xf1
0x004c49:	lsls    	r6, r6, #9
0x004c4b:	movs    	r5, #0
0x004c4d:	movs    	r3, #4
0x004c4f:	add     	r0, sb
0x004c51:	ldr     	r7, [r0, #0x44]
0x004c53:	cmp     	r4, #0xd
0x004c55:	sub     	sp, #0xc
0x004c57:	beq     	#0x4d17
; block 0x4c59
0x004c59:	bgt     	#0x4ca5
; block 0x4c5b
0x004c5b:	cmp     	r4, #2
0x004c5d:	beq     	#0x4c6b
; block 0x4c5f
0x004c5f:	cmp     	r4, #5
0x004c61:	beq     	#0x4cb1
; block 0x4c63
0x004c63:	cmp     	r4, #8
0x004c65:	beq     	#0x4d17
; block 0x4c67
0x004c67:	cmp     	r4, #0xc
0x004c69:	bne     	#0x4cfd
; block 0x4c6b
0x004c6b:	cmp     	r7, #0
0x004c6d:	beq     	#0x4cfd
; block 0x4c6f
0x004c6f:	movs    	r1, #0
0x004c71:	movs    	r2, #0
0x004c73:	str     	r2, [sp, #8]
0x004c75:	str     	r1, [sp]
0x004c77:	str     	r1, [sp, #4]
0x004c79:	movs    	r1, #0x11
0x004c7b:	adds    	r2, r7, #0
0x004c7d:	adds    	r0, r6, #0
0x004c7f:	bl      	#0x5159
; block 0x4c83
0x004c83:	adds    	r7, r0, #0
0x004c85:	ldr     	r0, [pc, #0xc8]
0x004c87:	movs    	r2, #0
0x004c89:	add     	r0, sb
0x004c8b:	adds    	r0, #0x48
0x004c8d:	movs    	r1, #0
0x004c8f:	str     	r1, [sp, #4]
0x004c91:	str     	r0, [sp]
0x004c93:	str     	r2, [sp, #8]
0x004c95:	adds    	r3, r5, #0
0x004c97:	adds    	r2, r7, #0
0x004c99:	movs    	r0, #0xf1
0x004c9b:	movs    	r1, #0x29
0x004c9d:	lsls    	r0, r0, #9
0x004c9f:	bl      	#0x5159
; block 0x4ca3
0x004ca3:	b       	#0x4cfd
; block 0x4ca5
0x004ca5:	cmp     	r4, #0x11
0x004ca7:	beq     	#0x4cb1
; block 0x4ca9
0x004ca9:	cmp     	r4, #0x12
0x004cab:	beq     	#0x4cb1
; block 0x4cad
0x004cad:	cmp     	r4, #0x14
0x004caf:	bne     	#0x4cfd
; block 0x4cb1
0x004cb1:	movs    	r1, #0
0x004cb3:	str     	r1, [sp]
0x004cb5:	str     	r1, [sp, #4]
0x004cb7:	movs    	r2, #0
0x004cb9:	movs    	r1, #0x2c
0x004cbb:	adds    	r3, r5, #0
0x004cbd:	adds    	r0, r6, #0
0x004cbf:	str     	r2, [sp, #8]
0x004cc1:	bl      	#0x5159
; block 0x4cc5
0x004cc5:	movs    	r2, #0
0x004cc7:	movs    	r1, #0
0x004cc9:	movs    	r0, #2
0x004ccb:	str     	r0, [sp]
0x004ccd:	str     	r1, [sp, #4]
0x004ccf:	str     	r2, [sp, #8]
0x004cd1:	movs    	r2, #0x21
0x004cd3:	movs    	r1, #0x14
0x004cd5:	movs    	r0, #0xf1
0x004cd7:	adds    	r3, r5, #0
0x004cd9:	lsls    	r0, r0, #9
0x004cdb:	bl      	#0x5159
; block 0x4cdf
0x004cdf:	movs    	r2, #0
0x004ce1:	movs    	r1, #0
0x004ce3:	movs    	r0, #2
0x004ce5:	str     	r0, [sp]
0x004ce7:	str     	r1, [sp, #4]
0x004ce9:	str     	r2, [sp, #8]
0x004ceb:	movs    	r2, #0x22
0x004ced:	movs    	r1, #0x14
0x004cef:	movs    	r0, #0xf1
0x004cf1:	adds    	r3, r5, #0
0x004cf3:	lsls    	r0, r0, #9
0x004cf5:	bl      	#0x5159
; block 0x4cf9
0x004cf9:	bl      	#0x6005
; block 0x4cfd
0x004cfd:	movs    	r1, #0
0x004cff:	movs    	r2, #0
0x004d01:	str     	r2, [sp, #8]
0x004d03:	str     	r1, [sp]
0x004d05:	str     	r1, [sp, #4]
0x004d07:	movs    	r1, #0x21
0x004d09:	adds    	r2, r4, #0
0x004d0b:	adds    	r3, r5, #0
0x004d0d:	adds    	r0, r6, #0
0x004d0f:	bl      	#0x5159
; block 0x4d13
0x004d13:	add     	sp, #0xc
0x004d15:	pop     	{r4, r5, r6, r7, pc}
; block 0x4d17
0x004d17:	cmp     	r7, #0
0x004d19:	beq     	#0x4cfd
; block 0x4d1b
0x004d1b:	movs    	r1, #0
0x004d1d:	movs    	r2, #0
0x004d1f:	str     	r2, [sp, #8]
0x004d21:	str     	r1, [sp]
0x004d23:	str     	r1, [sp, #4]
0x004d25:	movs    	r1, #0x11
0x004d27:	adds    	r2, r7, #0
0x004d29:	adds    	r0, r6, #0
0x004d2b:	bl      	#0x5159
; block 0x4d2f
0x004d2f:	adds    	r7, r0, #0
0x004d31:	ldr     	r0, [pc, #0x1c]
0x004d33:	movs    	r2, #0
0x004d35:	add     	r0, sb
0x004d37:	adds    	r0, #0x48
0x004d39:	movs    	r1, #1
0x004d3b:	str     	r1, [sp, #4]
0x004d3d:	str     	r0, [sp]
0x004d3f:	str     	r2, [sp, #8]
0x004d41:	adds    	r3, r5, #0
0x004d43:	adds    	r2, r7, #0
0x004d45:	movs    	r0, #0xf1
0x004d47:	movs    	r1, #0x29
0x004d49:	lsls    	r0, r0, #9
0x004d4b:	bl      	#0x5159
; block 0x4d4f
0x004d4f:	b       	#0x4cfd

; ===== sub_4d51 @ 0x4d51 offset=0x4d50 size=4 blocks=1 cc=1 =====
; block 0x4d51
0x004d51:	movs    	r4, r1
0x004d53:	movs    	r0, r0
0x004d55:	push    	{r4, r5, lr}
0x004d57:	adds    	r4, r0, #0
0x004d59:	subs    	r0, #2
0x004d5b:	cmp     	r0, #0x13
0x004d5d:	sub     	sp, #0xc
0x004d5f:	bhs     	#0x4ddd

; ===== sub_4d55 @ 0x4d55 offset=0x4d54 size=144 blocks=12 cc=9 =====
; block 0x4d55
0x004d55:	push    	{r4, r5, lr}
0x004d57:	adds    	r4, r0, #0
0x004d59:	subs    	r0, #2
0x004d5b:	cmp     	r0, #0x13
0x004d5d:	sub     	sp, #0xc
0x004d5f:	bhs     	#0x4ddd
; block 0x4d61
0x004d61:	adr     	r3, #4
0x004d63:	ldrb    	r3, [r3, r0]
0x004d65:	lsls    	r3, r3, #1
0x004d67:	add     	pc, r3
; block 0x4d7d
0x004d7d:	bl      	#0x899
; block 0x4d81
0x004d81:	b       	#0x4ddd
; block 0x4d83
0x004d83:	ldr     	r0, [pc, #0x74]
0x004d85:	movs    	r2, #0
0x004d87:	movs    	r1, #0
0x004d89:	add     	r0, sb
0x004d8b:	str     	r0, [sp]
0x004d8d:	str     	r1, [sp, #4]
0x004d8f:	str     	r2, [sp, #8]
0x004d91:	movs    	r5, #0
0x004d93:	adds    	r3, r5, #0
0x004d95:	movs    	r2, #4
0x004d97:	movs    	r1, #0x29
0x004d99:	movs    	r0, #0xf1
0x004d9b:	lsls    	r0, r0, #9
0x004d9d:	bl      	#0x5159
; block 0x4da1
0x004da1:	ldr     	r0, [pc, #0x54]
0x004da3:	add     	r0, sb
0x004da5:	subs    	r0, #0x20
0x004da7:	ldr     	r1, [r0, #0x20]
0x004da9:	cmp     	r1, #1
0x004dab:	bne     	#0x4ddd
; block 0x4dad
0x004dad:	str     	r5, [r0, #0x20]
0x004daf:	b       	#0x4ddd
; block 0x4db1
0x004db1:	ldr     	r0, [pc, #0x44]
0x004db3:	movs    	r2, #0
0x004db5:	movs    	r1, #1
0x004db7:	add     	r0, sb
0x004db9:	str     	r0, [sp]
0x004dbb:	str     	r1, [sp, #4]
0x004dbd:	str     	r2, [sp, #8]
0x004dbf:	movs    	r2, #4
0x004dc1:	movs    	r1, #0x29
0x004dc3:	movs    	r0, #0xf1
0x004dc5:	movs    	r3, #0
0x004dc7:	lsls    	r0, r0, #9
0x004dc9:	bl      	#0x5159
; block 0x4dcd
0x004dcd:	ldr     	r1, [pc, #0x28]
0x004dcf:	add     	r1, sb
0x004dd1:	subs    	r1, #0x20
0x004dd3:	ldr     	r0, [r1, #0x20]
0x004dd5:	cmp     	r0, #1
0x004dd7:	bne     	#0x4ddd
; block 0x4dd9
0x004dd9:	movs    	r0, #2
0x004ddb:	str     	r0, [r1, #0x20]
0x004ddd:	movs    	r1, #0
0x004ddf:	movs    	r2, #0
0x004de1:	str     	r2, [sp, #8]
0x004de3:	str     	r1, [sp]
0x004de5:	str     	r1, [sp, #4]
0x004de7:	movs    	r1, #0x21
0x004de9:	adds    	r2, r4, #0
0x004deb:	movs    	r3, #0
0x004ded:	movs    	r0, #0xf1
0x004def:	lsls    	r0, r0, #9
0x004df1:	bl      	#0x5159
; block 0x4ddd
0x004ddd:	movs    	r1, #0
0x004ddf:	movs    	r2, #0
0x004de1:	str     	r2, [sp, #8]
0x004de3:	str     	r1, [sp]
0x004de5:	str     	r1, [sp, #4]
0x004de7:	movs    	r1, #0x21
0x004de9:	adds    	r2, r4, #0
0x004deb:	movs    	r3, #0
0x004ded:	movs    	r0, #0xf1
0x004def:	lsls    	r0, r0, #9
0x004df1:	bl      	#0x5159
; block 0x4df5
0x004df5:	add     	sp, #0xc
0x004df7:	pop     	{r4, r5, pc}

; ===== sub_4df9 @ 0x4df9 offset=0x4df8 size=36 blocks=5 cc=1 =====
; block 0x4df9
0x004df9:	movs    	r4, r5
0x004dfb:	movs    	r0, r0
0x004dfd:	push    	{r4, lr}
0x004dff:	adds    	r4, r1, #0
0x004e01:	cmp     	r0, #0x29
0x004e03:	sub     	sp, #0x10
0x004e05:	bhs     	#0x4e11
; block 0x4e07
0x004e07:	adr     	r3, #0xc
0x004e09:	adds    	r3, r3, r0
0x004e0b:	ldrh    	r3, [r3, r0]
0x004e0d:	lsls    	r3, r3, #1
0x004e0f:	add     	pc, r3
; block 0x4e11
0x004e11:	b       	#0x5061
; block 0x4e6d
0x004e6d:	add     	sp, #0x10
0x004e6f:	pop     	{r4, pc}
; block 0x5061
0x005061:	movs    	r0, #2
0x005063:	mvns    	r0, r0
0x005065:	b       	#0x4e6d

; ===== sub_4e15 @ 0x4e15 offset=0x4e14 size=88 blocks=2 cc=1 =====
; block 0x4e15
0x004e15:	movs    	r6, r7
0x004e17:	lsls    	r1, r1, #1
0x004e19:	lsls    	r4, r2, #1
0x004e1b:	lsls    	r0, r3, #1
0x004e1d:	lsls    	r4, r3, #1
0x004e1f:	lsls    	r0, r4, #1
0x004e21:	lsls    	r4, r4, #1
0x004e23:	lsls    	r0, r5, #1
0x004e25:	lsls    	r2, r0, #2
0x004e27:	lsls    	r3, r1, #2
0x004e29:	lsls    	r7, r1, #2
0x004e2b:	lsls    	r3, r2, #2
0x004e2d:	lsls    	r0, r3, #2
0x004e2f:	lsls    	r4, r3, #2
0x004e31:	lsls    	r1, r4, #2
0x004e33:	lsls    	r5, r4, #2
0x004e35:	lsls    	r1, r5, #2
0x004e37:	lsls    	r6, r5, #2
0x004e39:	lsls    	r2, r6, #2
0x004e3b:	lsls    	r6, r6, #2
0x004e3d:	lsls    	r0, r7, #2
0x004e3f:	lsls    	r1, r2, #3
0x004e41:	lsls    	r5, r2, #3
0x004e43:	lsls    	r1, r3, #3
0x004e45:	lsls    	r5, r3, #3
0x004e47:	lsls    	r1, r4, #3
0x004e49:	lsls    	r6, r4, #3
0x004e4b:	lsls    	r3, r5, #3
0x004e4d:	lsls    	r0, r6, #3
0x004e4f:	lsls    	r5, r6, #3
0x004e51:	lsls    	r2, r7, #3
0x004e53:	lsls    	r7, r7, #3
0x004e55:	lsls    	r4, r0, #4
0x004e57:	lsls    	r1, r1, #4
0x004e59:	lsls    	r5, r1, #4
0x004e5b:	lsls    	r1, r2, #4
0x004e5d:	lsls    	r2, r4, #4
0x004e5f:	movs    	r1, r7
0x004e61:	movs    	r4, r6
0x004e63:	movs    	r7, r5
0x004e65:	movs    	r2, r5
0x004e67:	bl      	#0x2a71
; block 0x4e6b
0x004e6b:	movs    	r0, #0
0x004e6d:	add     	sp, #0x10
0x004e6f:	pop     	{r4, pc}

; ===== sub_4e71 @ 0x4e71 offset=0x4e70 size=10 blocks=2 cc=1 =====
; block 0x4e71
0x004e71:	adds    	r0, r4, #0
0x004e73:	bl      	#0x1135
; block 0x4e77
0x004e77:	movs    	r0, #0
0x004e79:	b       	#0x4e6d

; ===== sub_4e7b @ 0x4e7b offset=0x4e7a size=10 blocks=2 cc=1 =====
; block 0x4e7b
0x004e7b:	adds    	r0, r4, #0
0x004e7d:	bl      	#0x7c5
; block 0x4e81
0x004e81:	movs    	r0, #0
0x004e83:	b       	#0x4e6d

; ===== sub_4e85 @ 0x4e85 offset=0x4e84 size=10 blocks=2 cc=1 =====
; block 0x4e85
0x004e85:	adds    	r0, r4, #0
0x004e87:	bl      	#0xeed
; block 0x4e8b
0x004e8b:	movs    	r0, #0
0x004e8d:	b       	#0x4e6d

; ===== sub_4e8f @ 0x4e8f offset=0x4e8e size=22 blocks=2 cc=1 =====
; block 0x4e8f
0x004e8f:	movs    	r1, #0
0x004e91:	movs    	r2, #0
0x004e93:	str     	r1, [sp]
0x004e95:	str     	r1, [sp, #4]
0x004e97:	ldr     	r1, [pc, #0x1d0]
0x004e99:	str     	r2, [sp, #8]
0x004e9b:	movs    	r3, #0
0x004e9d:	ldr     	r0, [pc, #0x1cc]
0x004e9f:	bl      	#0x5159
; block 0x4ea3
0x004ea3:	b       	#0x4e6d

; ===== sub_4ea5 @ 0x4ea5 offset=0x4ea4 size=22 blocks=2 cc=1 =====
; block 0x4ea5
0x004ea5:	movs    	r1, #0
0x004ea7:	movs    	r2, #0
0x004ea9:	str     	r1, [sp]
0x004eab:	str     	r1, [sp, #4]
0x004ead:	ldr     	r1, [pc, #0x1b8]
0x004eaf:	str     	r2, [sp, #8]
0x004eb1:	movs    	r3, #0
0x004eb3:	ldr     	r0, [pc, #0x1bc]
0x004eb5:	bl      	#0x5159
; block 0x4eb9
0x004eb9:	b       	#0x4e6d

; ===== sub_4ebb @ 0x4ebb offset=0x4eba size=8 blocks=2 cc=1 =====
; block 0x4ebb
0x004ebb:	bl      	#0x43b5
; block 0x4ebf
0x004ebf:	movs    	r0, #0
0x004ec1:	b       	#0x4e6d

; ===== sub_4ec3 @ 0x4ec3 offset=0x4ec2 size=8 blocks=2 cc=1 =====
; block 0x4ec3
0x004ec3:	bl      	#0x4369
; block 0x4ec7
0x004ec7:	movs    	r0, #0
0x004ec9:	b       	#0x4e6d

; ===== sub_4ecb @ 0x4ecb offset=0x4eca size=8 blocks=2 cc=1 =====
; block 0x4ecb
0x004ecb:	bl      	#0x1ff1
; block 0x4ecf
0x004ecf:	movs    	r0, #0
0x004ed1:	b       	#0x4e6d

; ===== sub_4ed3 @ 0x4ed3 offset=0x4ed2 size=8 blocks=2 cc=1 =====
; block 0x4ed3
0x004ed3:	bl      	#0x67d9
; block 0x4ed7
0x004ed7:	movs    	r0, #0
0x004ed9:	b       	#0x4e6d

; ===== sub_4edb @ 0x4edb offset=0x4eda size=8 blocks=2 cc=1 =====
; block 0x4edb
0x004edb:	bl      	#0x6699
; block 0x4edf
0x004edf:	movs    	r0, #0
0x004ee1:	b       	#0x4e6d

; ===== sub_4ee3 @ 0x4ee3 offset=0x4ee2 size=52 blocks=6 cc=5 =====
; block 0x4ee3
0x004ee3:	cmp     	r4, #0
0x004ee5:	beq     	#0x4f13
; block 0x4ee7
0x004ee7:	cmp     	r4, #5
0x004ee9:	beq     	#0x4ef3
; block 0x4eeb
0x004eeb:	cmp     	r4, #0x11
0x004eed:	beq     	#0x4ef3
; block 0x4eef
0x004eef:	cmp     	r4, #0x14
0x004ef1:	bne     	#0x4f13
; block 0x4ef3
0x004ef3:	ldr     	r1, [pc, #0x184]
0x004ef5:	ldr     	r0, [pc, #0x17c]
0x004ef7:	add     	r1, sb
0x004ef9:	str     	r0, [r1, #0x50]
0x004efb:	movs    	r1, #0
0x004efd:	movs    	r2, #0
0x004eff:	str     	r2, [sp, #8]
0x004f01:	str     	r1, [sp]
0x004f03:	str     	r1, [sp, #4]
0x004f05:	movs    	r1, #0x21
0x004f07:	adds    	r2, r4, #0
0x004f09:	movs    	r0, #0xf1
0x004f0b:	movs    	r3, #0
0x004f0d:	lsls    	r0, r0, #9
0x004f0f:	bl      	#0x5159
; block 0x4f13
0x004f13:	movs    	r0, #0
0x004f15:	b       	#0x4e6d

; ===== sub_4f17 @ 0x4f17 offset=0x4f16 size=18 blocks=3 cc=2 =====
; block 0x4f17
0x004f17:	ldr     	r1, [pc, #0x164]
0x004f19:	add     	r1, sb
0x004f1b:	ldr     	r0, [r1]
0x004f1d:	cmp     	r0, #9
0x004f1f:	beq     	#0x4f25
; block 0x4f21
0x004f21:	movs    	r0, #3
0x004f23:	str     	r0, [r1]
0x004f25:	movs    	r0, #0
0x004f27:	b       	#0x4e6d
; block 0x4f25
0x004f25:	movs    	r0, #0
0x004f27:	b       	#0x4e6d

; ===== sub_4f29 @ 0x4f29 offset=0x4f28 size=8 blocks=2 cc=1 =====
; block 0x4f29
0x004f29:	bl      	#0x56b1
; block 0x4f2d
0x004f2d:	movs    	r0, #0
0x004f2f:	b       	#0x4e6d

; ===== sub_4f31 @ 0x4f31 offset=0x4f30 size=8 blocks=2 cc=1 =====
; block 0x4f31
0x004f31:	bl      	#0x5c0d
; block 0x4f35
0x004f35:	movs    	r0, #0
0x004f37:	b       	#0x4e6d

; ===== sub_4f39 @ 0x4f39 offset=0x4f38 size=10 blocks=2 cc=1 =====
; block 0x4f39
0x004f39:	adds    	r0, r4, #0
0x004f3b:	bl      	#0x55d1
; block 0x4f3f
0x004f3f:	movs    	r0, #0
0x004f41:	b       	#0x4e6d

; ===== sub_4f43 @ 0x4f43 offset=0x4f42 size=8 blocks=2 cc=1 =====
; block 0x4f43
0x004f43:	bl      	#0x3795
; block 0x4f47
0x004f47:	movs    	r0, #0
0x004f49:	b       	#0x4e6d

; ===== sub_4f4b @ 0x4f4b offset=0x4f4a size=10 blocks=2 cc=1 =====
; block 0x4f4b
0x004f4b:	adds    	r0, r4, #0
0x004f4d:	bl      	#0x4821
; block 0x4f51
0x004f51:	movs    	r0, #0
0x004f53:	b       	#0x4e6d

; ===== sub_4f55 @ 0x4f55 offset=0x4f54 size=8 blocks=2 cc=1 =====
; block 0x4f55
0x004f55:	bl      	#0x5d2d
; block 0x4f59
0x004f59:	movs    	r0, #0
0x004f5b:	b       	#0x4e6d

; ===== sub_4f5d @ 0x4f5d offset=0x4f5c size=8 blocks=2 cc=1 =====
; block 0x4f5d
0x004f5d:	bl      	#0x4089
; block 0x4f61
0x004f61:	movs    	r0, #0
0x004f63:	b       	#0x4e6d

; ===== sub_4f65 @ 0x4f65 offset=0x4f64 size=10 blocks=2 cc=1 =====
; block 0x4f65
0x004f65:	adds    	r0, r4, #0
0x004f67:	bl      	#0x4791
; block 0x4f6b
0x004f6b:	movs    	r0, #0
0x004f6d:	b       	#0x4e6d

; ===== sub_4f6f @ 0x4f6f offset=0x4f6e size=8 blocks=2 cc=1 =====
; block 0x4f6f
0x004f6f:	bl      	#0x5e89
; block 0x4f73
0x004f73:	movs    	r0, #0
0x004f75:	b       	#0x4e6d

; ===== sub_4f77 @ 0x4f77 offset=0x4f76 size=8 blocks=2 cc=1 =====
; block 0x4f77
0x004f77:	bl      	#0x59dd
; block 0x4f7b
0x004f7b:	movs    	r0, #0
0x004f7d:	b       	#0x4e6d

; ===== sub_4f7f @ 0x4f7f offset=0x4f7e size=4 blocks=1 cc=1 =====
; block 0x4f7f
0x004f7f:	movs    	r0, #0
0x004f81:	b       	#0x4e6d

; ===== sub_4f83 @ 0x4f83 offset=0x4f82 size=50 blocks=3 cc=2 =====
; block 0x4f83
0x004f83:	ldr     	r1, [pc, #0xf4]
0x004f85:	add     	r1, sb
0x004f87:	ldr     	r0, [r1, #0x78]
0x004f89:	subs    	r0, #1
0x004f8b:	str     	r0, [r1, #0x78]
0x004f8d:	cmp     	r0, #0
0x004f8f:	bgt     	#0x4fb1
; block 0x4f91
0x004f91:	movs    	r0, #2
0x004f93:	str     	r0, [sp]
0x004f95:	ldr     	r0, [pc, #0xe0]
0x004f97:	movs    	r2, #0
0x004f99:	movs    	r1, #0
0x004f9b:	str     	r1, [sp, #4]
0x004f9d:	str     	r2, [sp, #8]
0x004f9f:	add     	r0, sb
0x004fa1:	adds    	r0, #0x80
0x004fa3:	ldr     	r3, [r0, #0x10]
0x004fa5:	movs    	r0, #0xf1
0x004fa7:	movs    	r2, #0x17
0x004fa9:	movs    	r1, #0x14
0x004fab:	lsls    	r0, r0, #9
0x004fad:	bl      	#0x5159
; block 0x4fb1
0x004fb1:	movs    	r0, #0
0x004fb3:	b       	#0x4e6d

; ===== sub_4fb5 @ 0x4fb5 offset=0x4fb4 size=8 blocks=2 cc=1 =====
; block 0x4fb5
0x004fb5:	bl      	#0x1239
; block 0x4fb9
0x004fb9:	movs    	r0, #0
0x004fbb:	b       	#0x4e6d

; ===== sub_4fbd @ 0x4fbd offset=0x4fbc size=8 blocks=2 cc=1 =====
; block 0x4fbd
0x004fbd:	bl      	#0x2d99
; block 0x4fc1
0x004fc1:	movs    	r0, #0
0x004fc3:	b       	#0x4e6d

; ===== sub_4fc5 @ 0x4fc5 offset=0x4fc4 size=8 blocks=2 cc=1 =====
; block 0x4fc5
0x004fc5:	bl      	#0x2ea5
; block 0x4fc9
0x004fc9:	movs    	r0, #0
0x004fcb:	b       	#0x4e6d

; ===== sub_4fcd @ 0x4fcd offset=0x4fcc size=8 blocks=2 cc=1 =====
; block 0x4fcd
0x004fcd:	bl      	#0x57fd
; block 0x4fd1
0x004fd1:	movs    	r0, #0
0x004fd3:	b       	#0x4e6d

; ===== sub_4fd5 @ 0x4fd5 offset=0x4fd4 size=10 blocks=2 cc=1 =====
; block 0x4fd5
0x004fd5:	adds    	r0, r4, #0
0x004fd7:	bl      	#0x3f1
; block 0x4fdb
0x004fdb:	movs    	r0, #0
0x004fdd:	b       	#0x4e6d

; ===== sub_4fdf @ 0x4fdf offset=0x4fde size=10 blocks=2 cc=2 =====
; block 0x4fdf
0x004fdf:	adds    	r0, r4, #0
0x004fe1:	bl      	#0x4d55
; block 0x4fe5
0x004fe5:	movs    	r0, #0
0x004fe7:	b       	#0x4e6d

; ===== sub_4fe9 @ 0x4fe9 offset=0x4fe8 size=10 blocks=2 cc=1 =====
; block 0x4fe9
0x004fe9:	adds    	r0, r4, #0
0x004feb:	bl      	#0x594d
; block 0x4fef
0x004fef:	movs    	r0, #0
0x004ff1:	b       	#0x4e6d

; ===== sub_4ff3 @ 0x4ff3 offset=0x4ff2 size=10 blocks=2 cc=1 =====
; block 0x4ff3
0x004ff3:	adds    	r0, r4, #0
0x004ff5:	bl      	#0x4c41
; block 0x4ff9
0x004ff9:	movs    	r0, #0
0x004ffb:	b       	#0x4e6d

; ===== sub_4ffd @ 0x4ffd offset=0x4ffc size=10 blocks=2 cc=1 =====
; block 0x4ffd
0x004ffd:	adds    	r0, r4, #0
0x004fff:	bl      	#0x589d
; block 0x5003
0x005003:	movs    	r0, #0
0x005005:	b       	#0x4e6d

; ===== sub_5007 @ 0x5007 offset=0x5006 size=10 blocks=2 cc=1 =====
; block 0x5007
0x005007:	adds    	r0, r4, #0
0x005009:	bl      	#0x6415
; block 0x500d
0x00500d:	movs    	r0, #0
0x00500f:	b       	#0x4e6d

; ===== sub_5011 @ 0x5011 offset=0x5010 size=10 blocks=2 cc=1 =====
; block 0x5011
0x005011:	adds    	r0, r4, #0
0x005013:	bl      	#0xba1
; block 0x5017
0x005017:	movs    	r0, #0
0x005019:	b       	#0x4e6d

; ===== sub_501b @ 0x501b offset=0x501a size=10 blocks=2 cc=1 =====
; block 0x501b
0x00501b:	adds    	r0, r4, #0
0x00501d:	bl      	#0x5ebd
; block 0x5021
0x005021:	movs    	r0, #0
0x005023:	b       	#0x4e6d

; ===== sub_5025 @ 0x5025 offset=0x5024 size=8 blocks=2 cc=1 =====
; block 0x5025
0x005025:	bl      	#0x634d
; block 0x5029
0x005029:	movs    	r0, #0
0x00502b:	b       	#0x4e6d

; ===== sub_502d @ 0x502d offset=0x502c size=8 blocks=2 cc=1 =====
; block 0x502d
0x00502d:	bl      	#0x6291
; block 0x5031
0x005031:	movs    	r0, #0
0x005033:	b       	#0x4e6d

; ===== sub_5035 @ 0x5035 offset=0x5034 size=34 blocks=4 cc=1 =====
; block 0x5035
0x005035:	movs    	r1, #0
0x005037:	str     	r1, [sp]
0x005039:	str     	r1, [sp, #4]
0x00503b:	movs    	r2, #0
0x00503d:	movs    	r1, #0x2c
0x00503f:	movs    	r3, #0
0x005041:	movs    	r0, #0xf1
0x005043:	lsls    	r0, r0, #9
0x005045:	str     	r2, [sp, #8]
0x005047:	bl      	#0x5159
; block 0x504b
0x00504b:	bl      	#0x5d2d
; block 0x504f
0x00504f:	bl      	#0x6291
; block 0x5053
0x005053:	movs    	r0, #0
0x005055:	b       	#0x4e6d

; ===== sub_5057 @ 0x5057 offset=0x5056 size=10 blocks=2 cc=1 =====
; block 0x5057
0x005057:	adds    	r0, r4, #0
0x005059:	bl      	#0xc1d
; block 0x505d
0x00505d:	movs    	r0, #0
0x00505f:	b       	#0x4e6d

; ===== sub_5069 @ 0x5069 offset=0x5068 size=2 blocks=1 cc=1 =====
; block 0x5069
0x005069:	b       	#0x547f

; ===== sub_506d @ 0x506d offset=0x506c size=20 blocks=1 cc=1 =====
; block 0x506d
0x00506d:	lsls    	r6, r0, #4
0x00506f:	movs    	r1, r0
0x005071:	lsls    	r7, r0, #4
0x005073:	movs    	r1, r0
0x005075:	lsls    	r7, r4, #0xf
0x005077:	movs    	r0, r0
0x005079:	movs    	r4, r1
0x00507b:	movs    	r0, r0
0x00507d:	movs    	r4, r0
0x00507f:	movs    	r0, r0
0x005081:	push    	{r3, r4, r5, lr}
0x005083:	ldr     	r4, [pc, #0x74]
0x005085:	add     	r4, pc
0x005087:	ldr     	r0, [r4, #0x38]
0x005089:	movs    	r1, #0x14
0x00508b:	ldr     	r2, [r0, #0x64]
0x00508d:	ldr     	r0, [pc, #0x6c]
0x00508f:	add     	r0, pc
0x005091:	blx     	r2

; ===== sub_5081 @ 0x5081 offset=0x5080 size=118 blocks=12 cc=6 =====
; block 0x5081
0x005081:	push    	{r3, r4, r5, lr}
0x005083:	ldr     	r4, [pc, #0x74]
0x005085:	add     	r4, pc
0x005087:	ldr     	r0, [r4, #0x38]
0x005089:	movs    	r1, #0x14
0x00508b:	ldr     	r2, [r0, #0x64]
0x00508d:	ldr     	r0, [pc, #0x6c]
0x00508f:	add     	r0, pc
0x005091:	blx     	r2
; block 0x5093
0x005093:	movs    	r5, #0
0x005095:	mvns    	r5, r5
0x005097:	cmp     	r0, r5
0x005099:	bne     	#0x509f
; block 0x509b
0x00509b:	adds    	r0, r5, #0
0x00509d:	pop     	{r3, r4, r5, pc}
; block 0x509d
0x00509d:	pop     	{r3, r4, r5, pc}
; block 0x509f
0x00509f:	ldr     	r1, [r4, #0x3c]
0x0050a1:	movs    	r0, #1
0x0050a3:	str     	r0, [r1, #8]
0x0050a5:	ldr     	r0, [pc, #0x58]
0x0050a7:	add     	r0, pc
0x0050a9:	ldr     	r1, [r4, #0x38]
0x0050ab:	str     	r0, [r1, #0x7c]
0x0050ad:	ldr     	r0, [pc, #0x54]
0x0050af:	add     	r0, pc
0x0050b1:	ldr     	r1, [r4, #0x38]
0x0050b3:	adds    	r1, #0x80
0x0050b5:	str     	r0, [r1]
0x0050b7:	blx     	#0x2c8
; block 0x50bb
0x0050bb:	ldr     	r1, [r4, #0x3c]
0x0050bd:	str     	r0, [r1, #4]
0x0050bf:	ldr     	r1, [r4, #0x38]
0x0050c1:	adds    	r0, #4
0x0050c3:	ldr     	r1, [r1]
0x0050c5:	blx     	r1
; block 0x50c7
0x0050c7:	ldr     	r1, [r4, #0x3c]
0x0050c9:	cmp     	r0, #0
0x0050cb:	str     	r0, [r1]
0x0050cd:	ldr     	r1, [r4, #0x3c]
0x0050cf:	beq     	#0x50dd
; block 0x50d1
0x0050d1:	ldr     	r1, [r1, #4]
0x0050d3:	str     	r1, [r0]
0x0050d5:	ldr     	r0, [r4, #0x3c]
0x0050d7:	ldr     	r1, [r0]
0x0050d9:	adds    	r1, #4
0x0050db:	str     	r1, [r0]
0x0050dd:	ldr     	r1, [r4, #0x3c]
0x0050df:	ldr     	r0, [r1]
0x0050e1:	cmp     	r0, #0
0x0050e3:	beq     	#0x50f3
; block 0x50dd
0x0050dd:	ldr     	r1, [r4, #0x3c]
0x0050df:	ldr     	r0, [r1]
0x0050e1:	cmp     	r0, #0
0x0050e3:	beq     	#0x50f3
; block 0x50e5
0x0050e5:	ldr     	r2, [r1, #4]
0x0050e7:	ldr     	r1, [r4, #0x38]
0x0050e9:	ldr     	r3, [r1, #0x38]
0x0050eb:	movs    	r1, #0
0x0050ed:	blx     	r3
; block 0x50ef
0x0050ef:	movs    	r0, #0
0x0050f1:	b       	#0x509d
; block 0x50f3
0x0050f3:	adds    	r0, r5, #0
0x0050f5:	b       	#0x509d

; ===== sub_50fd @ 0x50fd offset=0x50fc size=12 blocks=1 cc=1 =====
; block 0x50fd
0x0050fd:	lsls    	r3, r1, #7
0x0050ff:	movs    	r0, r0
0x005101:	lsls    	r7, r4, #3
0x005103:	movs    	r0, r0
0x005105:	lsls    	r7, r0, #4
0x005107:	movs    	r0, r0
0x005109:	push    	{r4, lr}
0x00510b:	sub     	sp, #0x10
0x00510d:	lsls    	r0, r0, #0x18
0x00510f:	lsrs    	r0, r0, #0x18
0x005111:	str     	r0, [sp]
0x005113:	ldr     	r0, [pc, #0x38]
0x005115:	lsls    	r2, r2, #0x18
0x005117:	lsls    	r1, r1, #0x18
0x005119:	lsrs    	r1, r1, #0x18
0x00511b:	lsrs    	r2, r2, #0x18
0x00511d:	str     	r2, [sp, #8]
0x00511f:	str     	r1, [sp, #4]
0x005121:	add     	r0, pc
0x005123:	ldr     	r0, [r0, #0x38]
0x005125:	adds    	r1, r0, #0
0x005127:	adds    	r1, #0xff
0x005129:	adds    	r1, #0x41
0x00512b:	ldr     	r2, [r1, #0x34]
0x00512d:	ldr     	r1, [r1, #0x30]
0x00512f:	ldr     	r2, [r2]
0x005131:	ldr     	r1, [r1]
0x005133:	lsls    	r3, r2, #0x10
0x005135:	lsls    	r2, r1, #0x10
0x005137:	asrs    	r2, r2, #0x10
0x005139:	asrs    	r3, r3, #0x10
0x00513b:	adds    	r0, #0xff
0x00513d:	adds    	r0, #0xc1
0x00513f:	ldr     	r4, [r0, #0x28]
0x005141:	movs    	r1, #0
0x005143:	movs    	r0, #0
0x005145:	blx     	r4

; ===== sub_5109 @ 0x5109 offset=0x5108 size=66 blocks=2 cc=1 =====
; block 0x5109
0x005109:	push    	{r4, lr}
0x00510b:	sub     	sp, #0x10
0x00510d:	lsls    	r0, r0, #0x18
0x00510f:	lsrs    	r0, r0, #0x18
0x005111:	str     	r0, [sp]
0x005113:	ldr     	r0, [pc, #0x38]
0x005115:	lsls    	r2, r2, #0x18
0x005117:	lsls    	r1, r1, #0x18
0x005119:	lsrs    	r1, r1, #0x18
0x00511b:	lsrs    	r2, r2, #0x18
0x00511d:	str     	r2, [sp, #8]
0x00511f:	str     	r1, [sp, #4]
0x005121:	add     	r0, pc
0x005123:	ldr     	r0, [r0, #0x38]
0x005125:	adds    	r1, r0, #0
0x005127:	adds    	r1, #0xff
0x005129:	adds    	r1, #0x41
0x00512b:	ldr     	r2, [r1, #0x34]
0x00512d:	ldr     	r1, [r1, #0x30]
0x00512f:	ldr     	r2, [r2]
0x005131:	ldr     	r1, [r1]
0x005133:	lsls    	r3, r2, #0x10
0x005135:	lsls    	r2, r1, #0x10
0x005137:	asrs    	r2, r2, #0x10
0x005139:	asrs    	r3, r3, #0x10
0x00513b:	adds    	r0, #0xff
0x00513d:	adds    	r0, #0xc1
0x00513f:	ldr     	r4, [r0, #0x28]
0x005141:	movs    	r1, #0
0x005143:	movs    	r0, #0
0x005145:	blx     	r4
; block 0x5147
0x005147:	add     	sp, #0x10
0x005149:	pop     	{r4, pc}

; ===== sub_5151 @ 0x5151 offset=0x5150 size=4 blocks=1 cc=1 =====
; block 0x5151
0x005151:	movs    	r0, #0
0x005153:	bx      	lr

; ===== sub_5155 @ 0x5155 offset=0x5154 size=4 blocks=1 cc=1 =====
; block 0x5155
0x005155:	movs    	r0, #0
0x005157:	bx      	lr

; ===== sub_5159 @ 0x5159 offset=0x5158 size=52 blocks=2 cc=1 =====
; block 0x5159
0x005159:	push    	{r4, r5, r6, r7, lr}
0x00515b:	adds    	r5, r1, #0
0x00515d:	adds    	r4, r0, #0
0x00515f:	adds    	r6, r2, #0
0x005161:	ldr     	r2, [pc, #0x28]
0x005163:	sub     	sp, #0x14
0x005165:	mov     	ip, r3
0x005167:	add     	r2, pc
0x005169:	ldr     	r0, [sp, #0x2c]
0x00516b:	ldr     	r1, [sp, #0x30]
0x00516d:	ldr     	r7, [sp, #0x28]
0x00516f:	ldr     	r3, [r2, #0x3c]
0x005171:	movs    	r2, #2
0x005173:	str     	r2, [sp, #0xc]
0x005175:	str     	r1, [sp, #8]
0x005177:	str     	r0, [sp, #4]
0x005179:	str     	r7, [sp]
0x00517b:	ldr     	r0, [r3, #0xc]
0x00517d:	adds    	r1, r5, #0
0x00517f:	adds    	r2, r6, #0
0x005181:	ldr     	r7, [r0, #0x28]
0x005183:	adds    	r0, r4, #0
0x005185:	mov     	r3, ip
0x005187:	blx     	r7
; block 0x5189
0x005189:	add     	sp, #0x14
0x00518b:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_518d @ 0x518d offset=0x518c size=40 blocks=2 cc=1 =====
; block 0x518d
0x00518d:	add     	r6, sp, #0x178
0x00518f:	vdup.8  	d17, d3[7]
0x005193:	ldr     	r0, [pc, #0x20]
0x005195:	push    	{r4, lr}
0x005197:	movs    	r2, #0
0x005199:	add     	r0, pc
0x00519b:	ldr     	r4, [r0, #0x3c]
0x00519d:	sub     	sp, #0x10
0x00519f:	movs    	r1, #0
0x0051a1:	str     	r1, [sp, #4]
0x0051a3:	str     	r1, [sp, #8]
0x0051a5:	str     	r2, [sp, #0xc]
0x0051a7:	str     	r2, [sp]
0x0051a9:	ldr     	r0, [r4, #0xc]
0x0051ab:	ldr     	r2, [r0, #0x24]
0x0051ad:	ldr     	r4, [r0, #0x28]
0x0051af:	blx     	r4
; block 0x51b1
0x0051b1:	add     	sp, #0x10
0x0051b3:	pop     	{r4, pc}

; ===== sub_51b5 @ 0x51b5 offset=0x51b4 size=42 blocks=2 cc=1 =====
; block 0x51b5
0x0051b5:	add     	r6, sp, #0xb0
0x0051b7:	vsli.32 	d27, d0, #0x1f
0x0051bb:	ldr     	r0, [pc, #0x24]
0x0051bd:	sub     	sp, #0x10
0x0051bf:	add     	r0, pc
0x0051c1:	ldr     	r3, [r0, #0x3c]
0x0051c3:	movs    	r2, #0
0x0051c5:	movs    	r1, #0
0x0051c7:	str     	r1, [sp, #4]
0x0051c9:	str     	r1, [sp, #8]
0x0051cb:	str     	r2, [sp, #0xc]
0x0051cd:	str     	r2, [sp]
0x0051cf:	ldr     	r0, [r3, #0xc]
0x0051d1:	movs    	r3, #0
0x0051d3:	ldr     	r2, [r0, #0x24]
0x0051d5:	ldr     	r4, [r0, #0x28]
0x0051d7:	movs    	r1, #1
0x0051d9:	blx     	r4
; block 0x51db
0x0051db:	add     	sp, #0x10
0x0051dd:	pop     	{r4, pc}

; ===== sub_51e5 @ 0x51e5 offset=0x51e4 size=14 blocks=1 cc=1 =====
; block 0x51e5
0x0051e5:	ldr     	r0, [pc, #0xc]
0x0051e7:	add     	r0, pc
0x0051e9:	ldr     	r0, [r0, #0x38]
0x0051eb:	adds    	r0, #0xff
0x0051ed:	adds    	r0, #0x81
0x0051ef:	ldr     	r0, [r0, #0x10]
0x0051f1:	bx      	lr

; ===== sub_51f9 @ 0x51f9 offset=0x51f8 size=70 blocks=5 cc=2 =====
; block 0x51f9
0x0051f9:	push    	{r4, lr}
0x0051fb:	sub     	sp, #0x10
0x0051fd:	movs    	r2, #0
0x0051ff:	movs    	r1, #0
0x005201:	str     	r2, [sp, #8]
0x005203:	ldr     	r2, [pc, #0x3c]
0x005205:	str     	r1, [sp]
0x005207:	str     	r1, [sp, #4]
0x005209:	movs    	r3, #0
0x00520b:	add     	r2, pc
0x00520d:	ldr     	r1, [pc, #0x34]
0x00520f:	ldr     	r0, [pc, #0x38]
0x005211:	bl      	#0x5159
; block 0x5215
0x005215:	ldr     	r3, [pc, #0x38]
0x005217:	ldr     	r4, [pc, #0x34]
0x005219:	add     	r3, sb
0x00521b:	ldr     	r3, [r3]
0x00521d:	movs    	r2, #0x41
0x00521f:	movs    	r1, #0
0x005221:	add     	r4, sb
0x005223:	adds    	r0, r4, #0
0x005225:	blx     	r3
; block 0x5227
0x005227:	bl      	#0x51e5
; block 0x522b
0x00522b:	ldr     	r3, [pc, #0x28]
0x00522d:	adds    	r1, r0, #0
0x00522f:	add     	r3, sb
0x005231:	ldr     	r3, [r3]
0x005233:	movs    	r2, #0x41
0x005235:	adds    	r0, r4, #0
0x005237:	blx     	r3
; block 0x5239
0x005239:	movs    	r0, #0
0x00523b:	add     	sp, #0x10
0x00523d:	pop     	{r4, pc}

; ===== sub_5245 @ 0x5245 offset=0x5244 size=2 blocks=1 cc=1 =====
; block 0x5245
0x005245:	b       	#0x565b

; ===== sub_5247 @ 0x5247 offset=0x5246 size=18 blocks=1 cc=1 =====
; block 0x5247
0x005247:	movs    	r1, r0
0x005249:	lsls    	r2, r0, #4
0x00524b:	movs    	r1, r0
0x00524d:	lsls    	r4, r7, #2
0x00524f:	movs    	r0, r0
0x005251:	lsls    	r4, r3, #5
0x005253:	movs    	r0, r0
0x005255:	lsls    	r4, r7, #4
0x005257:	movs    	r0, r0
0x005259:	movs    	r0, #0
0x00525b:	bx      	lr

; ===== sub_5259 @ 0x5259 offset=0x5258 size=4 blocks=1 cc=1 =====
; block 0x5259
0x005259:	movs    	r0, #0
0x00525b:	bx      	lr

; ===== sub_525d @ 0x525d offset=0x525c size=126 blocks=20 cc=11 =====
; block 0x525d
0x00525d:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00525f:	adds    	r7, r3, #0
0x005261:	adds    	r6, r2, #0
0x005263:	adds    	r5, r0, #0
0x005265:	ldr     	r0, [r0]
0x005267:	sub     	sp, #4
0x005269:	mov     	r1, sb
0x00526b:	str     	r1, [sp]
0x00526d:	movs    	r4, #0
0x00526f:	blx     	#0x2e0
; block 0x5273
0x005273:	ldr     	r0, [sp, #8]
0x005275:	cmp     	r0, #0xb
0x005277:	bhs     	#0x52e5
; block 0x5279
0x005279:	adr     	r3, #4
0x00527b:	ldrb    	r3, [r3, r0]
0x00527d:	lsls    	r3, r3, #1
0x00527f:	add     	pc, r3
; block 0x528d
0x00528d:	ldr     	r1, [pc, #0x60]
0x00528f:	ldr     	r0, [r5, #0xc]
0x005291:	add     	r1, sb
0x005293:	str     	r0, [r1, #0x14]
0x005295:	bl      	#0x329
; block 0x52a1
0x0052a1:	ldr     	r0, [r6]
0x0052a3:	cmp     	r0, #8
0x0052a5:	bne     	#0x52af
; block 0x52a7
0x0052a7:	bl      	#0x5155
; block 0x52ab
0x0052ab:	adds    	r4, r0, #0
0x0052ad:	b       	#0x52e5
; block 0x52af
0x0052af:	ldr     	r1, [r6, #4]
0x0052b1:	ldr     	r2, [r6, #8]
0x0052b3:	bl      	#0x5151
; block 0x52b7
0x0052b7:	adds    	r4, r0, #0
0x0052b9:	b       	#0x52e5
; block 0x52bb
0x0052bb:	bl      	#0x54ed
; block 0x52bf
0x0052bf:	b       	#0x52e5
; block 0x52c1
0x0052c1:	str     	r7, [r5, #0xc]
0x0052c3:	b       	#0x52e5
; block 0x52c5
0x0052c5:	bl      	#0x5259
; block 0x52c9
0x0052c9:	b       	#0x52e5
; block 0x52cb
0x0052cb:	bl      	#0x5329
; block 0x52cf
0x0052cf:	b       	#0x52e5
; block 0x52d1
0x0052d1:	ldr     	r0, [pc, #0x1c]
0x0052d3:	add     	r0, sb
0x0052d5:	str     	r7, [r0, #0x1c]
0x0052d7:	b       	#0x52e5
; block 0x52d9
0x0052d9:	ldr     	r0, [pc, #0x14]
0x0052db:	add     	r0, sb
0x0052dd:	str     	r6, [r0, #0x20]
0x0052df:	b       	#0x52e5
; block 0x52e1
0x0052e1:	ldr     	r4, [pc, #0x10]
0x0052e3:	add     	r4, pc
0x0052e5:	ldr     	r1, [sp]
0x0052e7:	add     	sp, #0x14
0x0052e9:	adds    	r0, r4, #0
0x0052eb:	mov     	sb, r1
0x0052ed:	pop     	{r4, r5, r6, r7, pc}
; block 0x52e5
0x0052e5:	ldr     	r1, [sp]
0x0052e7:	add     	sp, #0x14
0x0052e9:	adds    	r0, r4, #0
0x0052eb:	mov     	sb, r1
0x0052ed:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_5299 @ 0x5299 offset=0x5298 size=8 blocks=2 cc=1 =====
; block 0x5299
0x005299:	bl      	#0x51f9
; block 0x529d
0x00529d:	adds    	r4, r0, #0
0x00529f:	b       	#0x52e5

; ===== sub_52f3 @ 0x52f3 offset=0x52f2 size=52 blocks=5 cc=2 =====
; block 0x52f3
0x0052f3:	movs    	r0, r0
0x0052f5:	movs    	r3, r2
0x0052f7:	movs    	r0, r0
0x0052f9:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0052fb:	sub     	sp, #0xc
0x0052fd:	ldr     	r0, [sp, #0x38]
0x0052ff:	ldr     	r4, [sp, #0x3c]
0x005301:	ldr     	r6, [sp, #0x34]
0x005303:	ldr     	r0, [r0]
0x005305:	mov     	r7, sb
0x005307:	movs    	r5, #0
0x005309:	blx     	#0x2e0
; block 0x530d
0x00530d:	cmp     	r4, #0
0x00530f:	beq     	#0x531f
; block 0x5311
0x005311:	ldr     	r1, [sp, #0x30]
0x005313:	str     	r6, [sp, #4]
0x005315:	add     	r3, sp, #0xc
0x005317:	str     	r1, [sp]
0x005319:	ldm     	r3, {r0, r1, r2, r3}
0x00531b:	blx     	r4
; block 0x531d
0x00531d:	adds    	r5, r0, #0
0x00531f:	mov     	sb, r7
0x005321:	adds    	r0, r5, #0
0x005323:	add     	sp, #0x1c
0x005325:	pop     	{r4, r5, r6, r7, pc}
; block 0x531f
0x00531f:	mov     	sb, r7
0x005321:	adds    	r0, r5, #0
0x005323:	add     	sp, #0x1c
0x005325:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_5329 @ 0x5329 offset=0x5328 size=4 blocks=1 cc=1 =====
; block 0x5329
0x005329:	movs    	r0, #0
0x00532b:	bx      	lr

; ===== sub_532d @ 0x532d offset=0x532c size=90 blocks=17 cc=10 =====
; block 0x532d
0x00532d:	adds    	r1, r0, #0
0x00532f:	beq     	#0x536b
; block 0x5331
0x005331:	ldr     	r3, [pc, #0x54]
0x005333:	add     	r3, sb
0x005335:	ldr     	r2, [r3, #8]
0x005337:	cmp     	r2, r1
0x005339:	bne     	#0x5341
; block 0x533b
0x00533b:	ldr     	r0, [r1, #0x18]
0x00533d:	str     	r0, [r3, #8]
0x00533f:	b       	#0x535d
; block 0x5341
0x005341:	cmp     	r2, #0
0x005343:	beq     	#0x535d
; block 0x5345
0x005345:	ldr     	r0, [r2, #0x18]
0x005347:	cmp     	r0, #0
0x005349:	beq     	#0x535d
; block 0x534b
0x00534b:	cmp     	r0, r1
0x00534d:	bne     	#0x5355
; block 0x534f
0x00534f:	ldr     	r0, [r0, #0x18]
0x005351:	str     	r0, [r2, #0x18]
0x005353:	b       	#0x535d
; block 0x5355
0x005355:	adds    	r2, r0, #0
0x005357:	ldr     	r0, [r0, #0x18]
0x005359:	cmp     	r0, #0
0x00535b:	bne     	#0x534b
; block 0x535d
0x00535d:	ldr     	r2, [r3, #0xc]
0x00535f:	cmp     	r2, #0
0x005361:	beq     	#0x536b
; block 0x5363
0x005363:	cmp     	r2, r1
0x005365:	bne     	#0x536d
; block 0x5367
0x005367:	ldr     	r0, [r2, #0x1c]
0x005369:	str     	r0, [r3, #0xc]
0x00536b:	bx      	lr
; block 0x536b
0x00536b:	bx      	lr
; block 0x536d
0x00536d:	ldr     	r0, [r2, #0x1c]
0x00536f:	cmp     	r0, #0
0x005371:	beq     	#0x536b
; block 0x5373
0x005373:	cmp     	r0, r1
0x005375:	bne     	#0x537d
; block 0x5377
0x005377:	ldr     	r0, [r0, #0x1c]
0x005379:	str     	r0, [r2, #0x1c]
0x00537b:	bx      	lr
; block 0x537d
0x00537d:	adds    	r2, r0, #0
0x00537f:	ldr     	r0, [r0, #0x1c]
0x005381:	cmp     	r0, #0
0x005383:	bne     	#0x5373
; block 0x5385
0x005385:	bx      	lr

; ===== sub_5389 @ 0x5389 offset=0x5388 size=4 blocks=1 cc=1 =====
; block 0x5389
0x005389:	lsls    	r0, r0, #6
0x00538b:	movs    	r0, r0
0x00538d:	push    	{r3, r4, r5, r6, r7, lr}
0x00538f:	adds    	r4, r0, #0
0x005391:	ldr     	r0, [pc, #0x10c]
0x005393:	movs    	r5, #0
0x005395:	mvns    	r5, r5
0x005397:	mov     	ip, r2
0x005399:	add     	r0, pc
0x00539b:	ldr     	r2, [r0, #0x38]
0x00539d:	cmp     	r4, #0
0x00539f:	bne     	#0x53b1

; ===== sub_538d @ 0x538d offset=0x538c size=240 blocks=37 cc=19 =====
; block 0x538d
0x00538d:	push    	{r3, r4, r5, r6, r7, lr}
0x00538f:	adds    	r4, r0, #0
0x005391:	ldr     	r0, [pc, #0x10c]
0x005393:	movs    	r5, #0
0x005395:	mvns    	r5, r5
0x005397:	mov     	ip, r2
0x005399:	add     	r0, pc
0x00539b:	ldr     	r2, [r0, #0x38]
0x00539d:	cmp     	r4, #0
0x00539f:	bne     	#0x53b1
; block 0x53a1
0x0053a1:	ldr     	r0, [pc, #0x100]
0x0053a3:	ldr     	r2, [r2, #0x68]
0x0053a5:	movs    	r1, #0x7d
0x0053a7:	lsls    	r1, r1, #3
0x0053a9:	add     	r0, pc
0x0053ab:	blx     	r2
; block 0x53ad
0x0053ad:	adds    	r0, r5, #0
0x0053af:	pop     	{r3, r4, r5, r6, r7, pc}
; block 0x53b1
0x0053b1:	ldr     	r6, [r2, #0x5c]
0x0053b3:	ldr     	r6, [r6, #8]
0x0053b5:	ldr     	r6, [r6]
0x0053b7:	cmp     	r6, #3
0x0053b9:	beq     	#0x53bf
; block 0x53bb
0x0053bb:	cmp     	r6, #4
0x0053bd:	bne     	#0x53c3
; block 0x53bf
0x0053bf:	adds    	r0, r5, #0
0x0053c1:	b       	#0x53af
; block 0x53c3
0x0053c3:	ldr     	r7, [pc, #0xe4]
0x0053c5:	ldr     	r6, [r4]
0x0053c7:	cmp     	r6, r7
0x0053c9:	beq     	#0x53d9
; block 0x53cb
0x0053cb:	ldr     	r0, [pc, #0xe4]
0x0053cd:	ldr     	r2, [r2, #0x68]
0x0053cf:	ldr     	r1, [pc, #0xdc]
0x0053d1:	add     	r0, pc
0x0053d3:	blx     	r2
; block 0x53d5
0x0053d5:	adds    	r0, r5, #0
0x0053d7:	b       	#0x53af
; block 0x53d9
0x0053d9:	cmp     	r1, #0
0x0053db:	beq     	#0x53df
; block 0x53dd
0x0053dd:	str     	r1, [r4, #4]
0x0053df:	movs    	r6, #0
0x0053e1:	mov     	r2, ip
0x0053e3:	str     	r2, [r4, #0x10]
0x0053e5:	str     	r6, [r4, #8]
0x0053e7:	cmp     	r3, #0
0x0053e9:	beq     	#0x53ed
; block 0x53df
0x0053df:	movs    	r6, #0
0x0053e1:	mov     	r2, ip
0x0053e3:	str     	r2, [r4, #0x10]
0x0053e5:	str     	r6, [r4, #8]
0x0053e7:	cmp     	r3, #0
0x0053e9:	beq     	#0x53ed
; block 0x53eb
0x0053eb:	str     	r3, [r4, #0xc]
0x0053ed:	ldr     	r1, [sp, #0x18]
0x0053ef:	str     	r1, [r4, #0x14]
0x0053f1:	ldr     	r1, [r4, #4]
0x0053f3:	cmp     	r1, #0
0x0053f5:	bgt     	#0x53fb
; block 0x53ed
0x0053ed:	ldr     	r1, [sp, #0x18]
0x0053ef:	str     	r1, [r4, #0x14]
0x0053f1:	ldr     	r1, [r4, #4]
0x0053f3:	cmp     	r1, #0
0x0053f5:	bgt     	#0x53fb
; block 0x53f7
0x0053f7:	adds    	r0, r5, #0
0x0053f9:	b       	#0x53af
; block 0x53fb
0x0053fb:	cmp     	r1, #0xa
0x0053fd:	bge     	#0x5403
; block 0x53ff
0x0053ff:	movs    	r1, #0xa
0x005401:	str     	r1, [r4, #4]
0x005403:	ldr     	r1, [r4, #4]
0x005405:	ldr     	r7, [pc, #0xac]
0x005407:	str     	r1, [r4, #8]
0x005409:	add     	r7, sb
0x00540b:	ldr     	r1, [r7, #0x10]
0x00540d:	cmp     	r1, #0
0x00540f:	beq     	#0x541f
; block 0x5403
0x005403:	ldr     	r1, [r4, #4]
0x005405:	ldr     	r7, [pc, #0xac]
0x005407:	str     	r1, [r4, #8]
0x005409:	add     	r7, sb
0x00540b:	ldr     	r1, [r7, #0x10]
0x00540d:	cmp     	r1, #0
0x00540f:	beq     	#0x541f
; block 0x5411
0x005411:	ldr     	r0, [r0, #0x38]
0x005413:	adds    	r0, #0x80
0x005415:	ldr     	r0, [r0, #4]
0x005417:	blx     	r0
; block 0x5419
0x005419:	ldr     	r1, [r7, #0x10]
0x00541b:	subs    	r5, r1, r0
0x00541d:	b       	#0x5421
; block 0x541f
0x00541f:	movs    	r5, #0
0x005421:	ldr     	r0, [r7, #8]
0x005423:	cmp     	r0, #0
0x005425:	beq     	#0x542d
; block 0x5421
0x005421:	ldr     	r0, [r7, #8]
0x005423:	cmp     	r0, #0
0x005425:	beq     	#0x542d
; block 0x5427
0x005427:	cmp     	r5, #0
0x005429:	bge     	#0x542d
; block 0x542b
0x00542b:	movs    	r5, #0
0x00542d:	cmp     	r0, #0
0x00542f:	beq     	#0x543b
; block 0x542d
0x00542d:	cmp     	r0, #0
0x00542f:	beq     	#0x543b
; block 0x5431
0x005431:	ldr     	r0, [r0, #4]
0x005433:	adds    	r1, r0, #5
0x005435:	cmp     	r1, r5
0x005437:	bge     	#0x543b
; block 0x5439
0x005439:	adds    	r5, r0, #0
0x00543b:	adds    	r0, r4, #0
0x00543d:	bl      	#0x532d
; block 0x543b
0x00543b:	adds    	r0, r4, #0
0x00543d:	bl      	#0x532d
; block 0x5441
0x005441:	ldr     	r1, [r7, #8]
0x005443:	cmp     	r1, #0
0x005445:	beq     	#0x5453
; block 0x5447
0x005447:	ldr     	r0, [r4, #8]
0x005449:	cmp     	r0, r5
0x00544b:	blt     	#0x5453
; block 0x544d
0x00544d:	subs    	r0, r0, r5
0x00544f:	str     	r0, [r4, #8]
0x005451:	b       	#0x546d
; block 0x5453
0x005453:	ldr     	r0, [r4, #8]
0x005455:	str     	r6, [r4, #8]
0x005457:	subs    	r2, r5, r0
0x005459:	cmp     	r1, #0
0x00545b:	beq     	#0x5469
; block 0x545d
0x00545d:	ldr     	r3, [r1, #8]
0x00545f:	adds    	r3, r3, r2
0x005461:	str     	r3, [r1, #8]
0x005463:	ldr     	r1, [r1, #0x18]
0x005465:	cmp     	r1, #0
0x005467:	bne     	#0x545d
; block 0x5469
0x005469:	bl      	#0x54b9
; block 0x546d
0x00546d:	ldr     	r1, [r7, #8]
0x00546f:	cmp     	r1, #0
0x005471:	bne     	#0x5479
; block 0x5473
0x005473:	str     	r4, [r7, #8]
0x005475:	str     	r6, [r4, #0x18]
0x005477:	b       	#0x549d
; block 0x5479
0x005479:	ldr     	r2, [r4, #8]
0x00547b:	ldr     	r0, [r1, #8]
0x00547d:	cmp     	r2, r0
0x00547f:	bge     	#0x5487

; ===== sub_547f @ 0x547f offset=0x547e size=36 blocks=9 cc=4 =====
; block 0x53af
0x0053af:	pop     	{r3, r4, r5, r6, r7, pc}
; block 0x547f
0x00547f:	bge     	#0x5487
; block 0x5481
0x005481:	str     	r1, [r4, #0x18]
0x005483:	str     	r4, [r7, #8]
0x005485:	b       	#0x549d
; block 0x5487
0x005487:	ldr     	r0, [r1, #0x18]
0x005489:	b       	#0x548f
; block 0x548b
0x00548b:	adds    	r1, r0, #0
0x00548d:	ldr     	r0, [r0, #0x18]
0x00548f:	cmp     	r0, #0
0x005491:	beq     	#0x5499
; block 0x548f
0x00548f:	cmp     	r0, #0
0x005491:	beq     	#0x5499
; block 0x5493
0x005493:	ldr     	r3, [r0, #8]
0x005495:	cmp     	r2, r3
0x005497:	bge     	#0x548b
; block 0x5499
0x005499:	str     	r4, [r1, #0x18]
0x00549b:	str     	r0, [r4, #0x18]
0x00549d:	movs    	r0, #0
0x00549f:	b       	#0x53af
; block 0x549d
0x00549d:	movs    	r0, #0
0x00549f:	b       	#0x53af

; ===== sub_54b9 @ 0x54b9 offset=0x54b8 size=44 blocks=4 cc=3 =====
; block 0x54b9
0x0054b9:	push    	{r3, r4, r5, lr}
0x0054bb:	ldr     	r4, [pc, #0x28]
0x0054bd:	adds    	r5, r0, #0
0x0054bf:	add     	r4, pc
0x0054c1:	ldr     	r0, [r4, #0x38]
0x0054c3:	adds    	r0, #0x80
0x0054c5:	ldr     	r0, [r0, #4]
0x0054c7:	blx     	r0
; block 0x54c9
0x0054c9:	adds    	r0, r0, r5
0x0054cb:	ldr     	r1, [pc, #0x1c]
0x0054cd:	add     	r1, sb
0x0054cf:	str     	r0, [r1, #0x10]
0x0054d1:	ldr     	r0, [r4, #0x38]
0x0054d3:	adds    	r0, #0x80
0x0054d5:	ldr     	r0, [r0]
0x0054d7:	blx     	r0
; block 0x54d9
0x0054d9:	ldr     	r0, [r4, #0x38]
0x0054db:	ldr     	r1, [r0, #0x7c]
0x0054dd:	lsls    	r0, r5, #0x10
0x0054df:	lsrs    	r0, r0, #0x10
0x0054e1:	blx     	r1
; block 0x54e3
0x0054e3:	pop     	{r3, r4, r5, pc}

; ===== sub_54e9 @ 0x54e9 offset=0x54e8 size=4 blocks=1 cc=1 =====
; block 0x54e9
0x0054e9:	lsls    	r0, r0, #6
0x0054eb:	movs    	r0, r0
0x0054ed:	ldr     	r0, [pc, #0xd4]
0x0054ef:	push    	{r3, r4, r5, r6, r7, lr}
0x0054f1:	add     	r0, pc
0x0054f3:	ldr     	r0, [r0, #0x38]
0x0054f5:	adds    	r0, #0x80
0x0054f7:	ldr     	r0, [r0, #4]
0x0054f9:	blx     	r0

; ===== sub_54ed @ 0x54ed offset=0x54ec size=216 blocks=32 cc=18 =====
; block 0x54ed
0x0054ed:	ldr     	r0, [pc, #0xd4]
0x0054ef:	push    	{r3, r4, r5, r6, r7, lr}
0x0054f1:	add     	r0, pc
0x0054f3:	ldr     	r0, [r0, #0x38]
0x0054f5:	adds    	r0, #0x80
0x0054f7:	ldr     	r0, [r0, #4]
0x0054f9:	blx     	r0
; block 0x54fb
0x0054fb:	movs    	r5, #0
0x0054fd:	ldr     	r6, [pc, #0xc8]
0x0054ff:	add     	r6, sb
0x005501:	ldr     	r1, [r6, #0x10]
0x005503:	str     	r5, [r6, #0x10]
0x005505:	subs    	r1, r0, r1
0x005507:	ldr     	r0, [r6, #8]
0x005509:	adds    	r3, r1, #0
0x00550b:	cmp     	r0, #0
0x00550d:	beq     	#0x55c3
; block 0x550f
0x00550f:	ldr     	r2, [r0, #8]
0x005511:	cmp     	r2, #0
0x005513:	bne     	#0x5573
; block 0x5515
0x005515:	mvns    	r7, r2
0x005517:	str     	r7, [r0, #8]
0x005519:	ldr     	r2, [r0, #0x18]
0x00551b:	adds    	r4, r0, #0
0x00551d:	cmp     	r1, #0x32
0x00551f:	str     	r2, [r6, #8]
0x005521:	bge     	#0x5527
; block 0x5523
0x005523:	movs    	r1, #0x32
0x005525:	b       	#0x5543
; block 0x5527
0x005527:	movs    	r2, #0x7d
0x005529:	lsls    	r2, r2, #4
0x00552b:	cmp     	r1, r2
0x00552d:	ble     	#0x5543
; block 0x552f
0x00552f:	adds    	r1, r2, #0
0x005531:	b       	#0x5543
; block 0x5533
0x005533:	movs    	r7, #0
0x005535:	mvns    	r7, r7
0x005537:	str     	r7, [r2, #8]
0x005539:	ldr     	r2, [r0, #0x18]
0x00553b:	str     	r2, [r0, #0x1c]
0x00553d:	ldr     	r0, [r2, #0x18]
0x00553f:	str     	r0, [r6, #8]
0x005541:	adds    	r0, r2, #0
0x005543:	ldr     	r2, [r0, #0x18]
0x005545:	cmp     	r2, #0
0x005547:	beq     	#0x554f
; block 0x5543
0x005543:	ldr     	r2, [r0, #0x18]
0x005545:	cmp     	r2, #0
0x005547:	beq     	#0x554f
; block 0x5549
0x005549:	ldr     	r7, [r2, #8]
0x00554b:	cmp     	r7, r1
0x00554d:	blt     	#0x5533
; block 0x554f
0x00554f:	str     	r5, [r0, #0x1c]
0x005551:	ldr     	r0, [r6, #8]
0x005553:	cmp     	r0, #0
0x005555:	beq     	#0x55b7
; block 0x5557
0x005557:	cmp     	r3, #0
0x005559:	bge     	#0x555d
; block 0x555b
0x00555b:	movs    	r3, #0
0x00555d:	ldr     	r0, [r6, #8]
0x00555f:	ldr     	r1, [r0, #8]
0x005561:	cmp     	r1, #0
0x005563:	bge     	#0x5569
; block 0x555d
0x00555d:	ldr     	r0, [r6, #8]
0x00555f:	ldr     	r1, [r0, #8]
0x005561:	cmp     	r1, #0
0x005563:	bge     	#0x5569
; block 0x5565
0x005565:	movs    	r1, #0
0x005567:	str     	r5, [r0, #8]
0x005569:	ldr     	r2, [pc, #0x60]
0x00556b:	cmp     	r1, r2
0x00556d:	ble     	#0x5577
; block 0x5569
0x005569:	ldr     	r2, [pc, #0x60]
0x00556b:	cmp     	r1, r2
0x00556d:	ble     	#0x5577
; block 0x556f
0x00556f:	adds    	r1, r2, #0
0x005571:	b       	#0x5577
; block 0x5573
0x005573:	movs    	r4, #0
0x005575:	b       	#0x5557
; block 0x5577
0x005577:	ldr     	r2, [r0, #8]
0x005579:	subs    	r2, r2, r1
0x00557b:	str     	r2, [r0, #8]
0x00557d:	ldr     	r0, [r0, #0x18]
0x00557f:	cmp     	r0, #0
0x005581:	bne     	#0x5577
; block 0x5583
0x005583:	subs    	r0, r1, r3
0x005585:	cmp     	r0, #0
0x005587:	bgt     	#0x558b
; block 0x5589
0x005589:	movs    	r0, #0xa
0x00558b:	bl      	#0x54b9
; block 0x558b
0x00558b:	bl      	#0x54b9
; block 0x558f
0x00558f:	b       	#0x55b7
; block 0x5591
0x005591:	str     	r5, [r4, #8]
0x005593:	ldr     	r0, [r4, #0x1c]
0x005595:	adds    	r3, r5, #0
0x005597:	str     	r0, [r6, #0xc]
0x005599:	ldr     	r0, [r4, #0x14]
0x00559b:	cmp     	r0, #0
0x00559d:	beq     	#0x55ab
; block 0x559f
0x00559f:	str     	r0, [sp]
0x0055a1:	movs    	r1, #0
0x0055a3:	adds    	r0, r4, #0
0x0055a5:	ldr     	r2, [r4, #0x10]
0x0055a7:	bl      	#0x538d
; block 0x55ab
0x0055ab:	ldr     	r1, [r4, #0xc]
0x0055ad:	cmp     	r1, #0
0x0055af:	beq     	#0x55b5
; block 0x55b1
0x0055b1:	ldr     	r0, [r4, #0x10]
0x0055b3:	blx     	r1
; block 0x55b5
0x0055b5:	ldr     	r4, [r6, #0xc]
0x0055b7:	cmp     	r4, #0
0x0055b9:	beq     	#0x55c1
; block 0x55b7
0x0055b7:	cmp     	r4, #0
0x0055b9:	beq     	#0x55c1
; block 0x55bb
0x0055bb:	ldr     	r0, [r4, #8]
0x0055bd:	cmp     	r0, #0
0x0055bf:	blt     	#0x5591
; block 0x55c1
0x0055c1:	str     	r5, [r6, #0xc]
0x0055c3:	pop     	{r3, r4, r5, r6, r7, pc}
; block 0x55c3
0x0055c3:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== sub_55cf @ 0x55cf offset=0x55ce size=2 blocks=1 cc=1 =====
; block 0x55cf
0x0055cf:	movs    	r0, r0
0x0055d1:	push    	{r0, r4, r5, r6, r7, lr}
0x0055d3:	sub     	sp, #0x30
0x0055d5:	movs    	r1, #0
0x0055d7:	str     	r1, [sp]
0x0055d9:	str     	r1, [sp, #4]
0x0055db:	movs    	r4, #0
0x0055dd:	movs    	r2, #0
0x0055df:	adds    	r3, r4, #0
0x0055e1:	movs    	r1, #0x1c
0x0055e3:	movs    	r0, #0xf1
0x0055e5:	lsls    	r0, r0, #9
0x0055e7:	str     	r2, [sp, #8]
0x0055e9:	bl      	#0x5159

; ===== sub_55d1 @ 0x55d1 offset=0x55d0 size=138 blocks=6 cc=5 =====
; block 0x55d1
0x0055d1:	push    	{r0, r4, r5, r6, r7, lr}
0x0055d3:	sub     	sp, #0x30
0x0055d5:	movs    	r1, #0
0x0055d7:	str     	r1, [sp]
0x0055d9:	str     	r1, [sp, #4]
0x0055db:	movs    	r4, #0
0x0055dd:	movs    	r2, #0
0x0055df:	adds    	r3, r4, #0
0x0055e1:	movs    	r1, #0x1c
0x0055e3:	movs    	r0, #0xf1
0x0055e5:	lsls    	r0, r0, #9
0x0055e7:	str     	r2, [sp, #8]
0x0055e9:	bl      	#0x5159
; block 0x55ed
0x0055ed:	adds    	r5, r0, #0
0x0055ef:	movs    	r1, #0
0x0055f1:	str     	r1, [sp]
0x0055f3:	str     	r1, [sp, #4]
0x0055f5:	subs    	r5, #0x14
0x0055f7:	movs    	r2, #0
0x0055f9:	adds    	r3, r4, #0
0x0055fb:	movs    	r1, #0x1d
0x0055fd:	movs    	r0, #0xf1
0x0055ff:	lsls    	r0, r0, #9
0x005601:	str     	r2, [sp, #8]
0x005603:	bl      	#0x5159
; block 0x5607
0x005607:	adds    	r6, r0, #0
0x005609:	movs    	r1, #0
0x00560b:	str     	r1, [sp]
0x00560d:	str     	r1, [sp, #4]
0x00560f:	subs    	r6, #0x14
0x005611:	movs    	r2, #0
0x005613:	adds    	r3, r4, #0
0x005615:	movs    	r1, #0x1c
0x005617:	movs    	r0, #0xf1
0x005619:	lsls    	r0, r0, #9
0x00561b:	str     	r2, [sp, #8]
0x00561d:	bl      	#0x5159
; block 0x5621
0x005621:	subs    	r0, r0, r5
0x005623:	movs    	r1, #0
0x005625:	asrs    	r0, r0, #1
0x005627:	str     	r0, [sp, #0x2c]
0x005629:	str     	r1, [sp]
0x00562b:	str     	r1, [sp, #4]
0x00562d:	movs    	r2, #0
0x00562f:	movs    	r1, #0x1d
0x005631:	movs    	r0, #0xf1
0x005633:	adds    	r3, r4, #0
0x005635:	lsls    	r0, r0, #9
0x005637:	str     	r2, [sp, #8]
0x005639:	bl      	#0x5159
; block 0x563d
0x00563d:	subs    	r0, r0, r6
0x00563f:	movs    	r1, #0
0x005641:	str     	r1, [sp]
0x005643:	str     	r1, [sp, #4]
0x005645:	asrs    	r7, r0, #1
0x005647:	movs    	r2, #0
0x005649:	movs    	r0, #0xf1
0x00564b:	movs    	r1, #0x5a
0x00564d:	adds    	r3, r4, #0
0x00564f:	lsls    	r0, r0, #9
0x005651:	str     	r2, [sp, #8]
0x005653:	bl      	#0x5159
; block 0x5657
0x005657:	str     	r5, [sp, #0xc]
0x005659:	ldr     	r0, [sp, #0x2c]
0x00565b:	str     	r6, [sp, #0x10]
0x00565d:	str     	r0, [sp, #0x14]
0x00565f:	ldr     	r0, [pc, #0x4c]
0x005661:	str     	r7, [sp, #0x18]
0x005663:	add     	r0, sb
0x005665:	str     	r0, [sp, #0x1c]
0x005667:	ldr     	r0, [sp, #0x30]
0x005669:	add     	r3, sp, #0x20
0x00566b:	str     	r0, [sp, #0x20]
0x00566d:	ldr     	r0, [pc, #0x3c]
0x00566f:	movs    	r1, #0
0x005671:	add     	r0, sb
0x005673:	adds    	r0, #4
0x005675:	str     	r0, [sp, #0x24]
0x005677:	strb    	r4, [r3, #8]
0x005679:	movs    	r2, #0
0x00567b:	str     	r1, [sp]
0x00567d:	str     	r1, [sp, #4]
0x00567f:	movs    	r1, #0x59
0x005681:	str     	r2, [sp, #8]
0x005683:	adds    	r3, r4, #0
0x005685:	movs    	r0, #0xf1
0x005687:	lsls    	r0, r0, #9
0x005689:	add     	r2, sp, #0xc
0x00568b:	bl      	#0x5159

; ===== sub_565b @ 0x565b offset=0x565a size=80 blocks=3 cc=2 =====
; block 0x565b
0x00565b:	str     	r6, [sp, #0x10]
0x00565d:	str     	r0, [sp, #0x14]
0x00565f:	ldr     	r0, [pc, #0x4c]
0x005661:	str     	r7, [sp, #0x18]
0x005663:	add     	r0, sb
0x005665:	str     	r0, [sp, #0x1c]
0x005667:	ldr     	r0, [sp, #0x30]
0x005669:	add     	r3, sp, #0x20
0x00566b:	str     	r0, [sp, #0x20]
0x00566d:	ldr     	r0, [pc, #0x3c]
0x00566f:	movs    	r1, #0
0x005671:	add     	r0, sb
0x005673:	adds    	r0, #4
0x005675:	str     	r0, [sp, #0x24]
0x005677:	strb    	r4, [r3, #8]
0x005679:	movs    	r2, #0
0x00567b:	str     	r1, [sp]
0x00567d:	str     	r1, [sp, #4]
0x00567f:	movs    	r1, #0x59
0x005681:	str     	r2, [sp, #8]
0x005683:	adds    	r3, r4, #0
0x005685:	movs    	r0, #0xf1
0x005687:	lsls    	r0, r0, #9
0x005689:	add     	r2, sp, #0xc
0x00568b:	bl      	#0x5159
; block 0x568f
0x00568f:	movs    	r1, #0
0x005691:	movs    	r2, #0
0x005693:	str     	r2, [sp, #8]
0x005695:	str     	r1, [sp]
0x005697:	str     	r1, [sp, #4]
0x005699:	movs    	r1, #0x24
0x00569b:	movs    	r2, #1
0x00569d:	movs    	r3, #1
0x00569f:	movs    	r0, #0xf1
0x0056a1:	lsls    	r0, r0, #9
0x0056a3:	bl      	#0x5159
; block 0x56a7
0x0056a7:	add     	sp, #0x34
0x0056a9:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_56ad @ 0x56ad offset=0x56ac size=4 blocks=1 cc=1 =====
; block 0x56ad
0x0056ad:	lsls    	r0, r2, #1
0x0056af:	movs    	r0, r0
0x0056b1:	push    	{r4, r5, r6, r7, lr}
0x0056b3:	ldr     	r0, [pc, #0x144]
0x0056b5:	ldr     	r6, [pc, #0x140]
0x0056b7:	add     	r0, sb
0x0056b9:	ldr     	r0, [r0, #0x54]
0x0056bb:	movs    	r5, #0xf1
0x0056bd:	add     	r6, sb
0x0056bf:	adds    	r6, #0x80
0x0056c1:	lsls    	r5, r5, #9
0x0056c3:	sub     	sp, #0x34
0x0056c5:	movs    	r4, #0
0x0056c7:	cmp     	r0, #0
0x0056c9:	add     	r7, sp, #0x10
0x0056cb:	beq     	#0x5765

; ===== sub_56b1 @ 0x56b1 offset=0x56b0 size=326 blocks=12 cc=9 =====
; block 0x56b1
0x0056b1:	push    	{r4, r5, r6, r7, lr}
0x0056b3:	ldr     	r0, [pc, #0x144]
0x0056b5:	ldr     	r6, [pc, #0x140]
0x0056b7:	add     	r0, sb
0x0056b9:	ldr     	r0, [r0, #0x54]
0x0056bb:	movs    	r5, #0xf1
0x0056bd:	add     	r6, sb
0x0056bf:	adds    	r6, #0x80
0x0056c1:	lsls    	r5, r5, #9
0x0056c3:	sub     	sp, #0x34
0x0056c5:	movs    	r4, #0
0x0056c7:	cmp     	r0, #0
0x0056c9:	add     	r7, sp, #0x10
0x0056cb:	beq     	#0x5765
; block 0x56cd
0x0056cd:	cmp     	r0, #1
0x0056cf:	bne     	#0x5761
; block 0x56d1
0x0056d1:	movs    	r2, #0xff
0x0056d3:	movs    	r1, #0xff
0x0056d5:	movs    	r0, #0xff
0x0056d7:	bl      	#0x5109
; block 0x56db
0x0056db:	movs    	r1, #0
0x0056dd:	str     	r1, [sp]
0x0056df:	str     	r1, [sp, #4]
0x0056e1:	movs    	r2, #0
0x0056e3:	movs    	r1, #0x1c
0x0056e5:	adds    	r3, r4, #0
0x0056e7:	adds    	r0, r5, #0
0x0056e9:	str     	r2, [sp, #8]
0x0056eb:	bl      	#0x5159
; block 0x56ef
0x0056ef:	ldr     	r1, [r6, #0x18]
0x0056f1:	movs    	r3, #8
0x0056f3:	ldrsh   	r1, [r1, r3]
0x0056f5:	movs    	r2, #0
0x0056f7:	str     	r2, [sp, #8]
0x0056f9:	subs    	r0, r0, r1
0x0056fb:	lsrs    	r1, r0, #0x1f
0x0056fd:	adds    	r0, r1, r0
0x0056ff:	asrs    	r0, r0, #1
0x005701:	movs    	r1, #0
0x005703:	lsls    	r5, r0, #0x10
0x005705:	str     	r1, [sp]
0x005707:	str     	r1, [sp, #4]
0x005709:	movs    	r1, #0x1d
0x00570b:	asrs    	r5, r5, #0x10
0x00570d:	movs    	r0, #0xf1
0x00570f:	adds    	r3, r4, #0
0x005711:	lsls    	r0, r0, #9
0x005713:	bl      	#0x5159
; block 0x5717
0x005717:	ldr     	r1, [r6, #0x18]
0x005719:	movs    	r3, #0xa
0x00571b:	ldrsh   	r2, [r1, r3]
0x00571d:	movs    	r3, #8
0x00571f:	subs    	r0, r0, r2
0x005721:	lsrs    	r2, r0, #0x1f
0x005723:	adds    	r0, r2, r0
0x005725:	asrs    	r0, r0, #1
0x005727:	ldr     	r2, [r1, #4]
0x005729:	lsls    	r0, r0, #0x10
0x00572b:	asrs    	r0, r0, #0x10
0x00572d:	str     	r0, [sp, #0x18]
0x00572f:	str     	r5, [sp, #0x14]
0x005731:	str     	r2, [sp, #0x10]
0x005733:	ldrsh   	r0, [r1, r3]
0x005735:	movs    	r2, #0
0x005737:	str     	r0, [sp, #0x1c]
0x005739:	ldrsh   	r0, [r1, r3]
0x00573b:	movs    	r3, #0xa
0x00573d:	str     	r0, [sp, #0x20]
0x00573f:	ldrsh   	r0, [r1, r3]
0x005741:	movs    	r1, #0
0x005743:	str     	r1, [sp]
0x005745:	str     	r0, [sp, #0x24]
0x005747:	movs    	r0, #6
0x005749:	str     	r0, [sp, #0x28]
0x00574b:	str     	r2, [sp, #8]
0x00574d:	str     	r1, [sp, #4]
0x00574f:	adds    	r3, r4, #0
0x005751:	adds    	r2, r7, #0
0x005753:	movs    	r1, #0x1e
0x005755:	movs    	r0, #0xf1
0x005757:	lsls    	r0, r0, #9
0x005759:	str     	r4, [sp, #0x2c]
0x00575b:	str     	r4, [sp, #0x30]
0x00575d:	bl      	#0x5159
; block 0x5761
0x005761:	add     	sp, #0x34
0x005763:	pop     	{r4, r5, r6, r7, pc}
; block 0x5765
0x005765:	movs    	r2, #0
0x005767:	movs    	r1, #0
0x005769:	movs    	r0, #0
0x00576b:	bl      	#0x5109
; block 0x576f
0x00576f:	movs    	r1, #0
0x005771:	str     	r1, [sp]
0x005773:	str     	r1, [sp, #4]
0x005775:	movs    	r2, #0
0x005777:	movs    	r1, #0x1c
0x005779:	adds    	r3, r4, #0
0x00577b:	adds    	r0, r5, #0
0x00577d:	str     	r2, [sp, #8]
0x00577f:	bl      	#0x5159
; block 0x5783
0x005783:	ldr     	r1, [r6, #0x14]
0x005785:	movs    	r3, #8
0x005787:	ldrsh   	r1, [r1, r3]
0x005789:	movs    	r2, #0
0x00578b:	str     	r2, [sp, #8]
0x00578d:	subs    	r0, r0, r1
0x00578f:	lsrs    	r1, r0, #0x1f
0x005791:	adds    	r0, r1, r0
0x005793:	asrs    	r0, r0, #1
0x005795:	movs    	r1, #0
0x005797:	lsls    	r5, r0, #0x10
0x005799:	str     	r1, [sp]
0x00579b:	str     	r1, [sp, #4]
0x00579d:	movs    	r1, #0x1d
0x00579f:	asrs    	r5, r5, #0x10
0x0057a1:	movs    	r0, #0xf1
0x0057a3:	adds    	r3, r4, #0
0x0057a5:	lsls    	r0, r0, #9
0x0057a7:	bl      	#0x5159
; block 0x57ab
0x0057ab:	ldr     	r1, [r6, #0x14]
0x0057ad:	movs    	r3, #0xa
0x0057af:	ldrsh   	r2, [r1, r3]
0x0057b1:	movs    	r3, #8
0x0057b3:	subs    	r0, r0, r2
0x0057b5:	lsrs    	r2, r0, #0x1f
0x0057b7:	adds    	r0, r2, r0
0x0057b9:	asrs    	r0, r0, #1
0x0057bb:	ldr     	r2, [r1, #4]
0x0057bd:	lsls    	r0, r0, #0x10
0x0057bf:	asrs    	r0, r0, #0x10
0x0057c1:	str     	r0, [sp, #0x18]
0x0057c3:	str     	r5, [sp, #0x14]
0x0057c5:	str     	r2, [sp, #0x10]
0x0057c7:	ldrsh   	r0, [r1, r3]
0x0057c9:	movs    	r2, #0
0x0057cb:	str     	r0, [sp, #0x1c]
0x0057cd:	ldrsh   	r0, [r1, r3]
0x0057cf:	movs    	r3, #0xa
0x0057d1:	str     	r0, [sp, #0x20]
0x0057d3:	ldrsh   	r0, [r1, r3]
0x0057d5:	movs    	r1, #0
0x0057d7:	str     	r1, [sp]
0x0057d9:	str     	r0, [sp, #0x24]
0x0057db:	movs    	r0, #6
0x0057dd:	str     	r0, [sp, #0x28]
0x0057df:	str     	r2, [sp, #8]
0x0057e1:	str     	r1, [sp, #4]
0x0057e3:	adds    	r3, r4, #0
0x0057e5:	adds    	r2, r7, #0
0x0057e7:	movs    	r1, #0x1e
0x0057e9:	movs    	r0, #0xf1
0x0057eb:	lsls    	r0, r0, #9
0x0057ed:	str     	r4, [sp, #0x2c]
0x0057ef:	str     	r4, [sp, #0x30]
0x0057f1:	bl      	#0x5159
; block 0x57f5
0x0057f5:	b       	#0x5761

; ===== sub_57f9 @ 0x57f9 offset=0x57f8 size=4 blocks=1 cc=1 =====
; block 0x57f9
0x0057f9:	movs    	r4, r1
0x0057fb:	movs    	r0, r0
0x0057fd:	push    	{r4, r5, lr}
0x0057ff:	sub     	sp, #0x34
0x005801:	movs    	r1, #0
0x005803:	str     	r1, [sp]
0x005805:	str     	r1, [sp, #4]
0x005807:	movs    	r4, #0
0x005809:	adds    	r3, r4, #0
0x00580b:	movs    	r1, #0xff
0x00580d:	movs    	r2, #0
0x00580f:	adds    	r1, #0x54
0x005811:	movs    	r0, #0xf1
0x005813:	lsls    	r0, r0, #9
0x005815:	str     	r2, [sp, #8]
0x005817:	bl      	#0x5159

; ===== sub_57fd @ 0x57fd offset=0x57fc size=154 blocks=8 cc=4 =====
; block 0x57fd
0x0057fd:	push    	{r4, r5, lr}
0x0057ff:	sub     	sp, #0x34
0x005801:	movs    	r1, #0
0x005803:	str     	r1, [sp]
0x005805:	str     	r1, [sp, #4]
0x005807:	movs    	r4, #0
0x005809:	adds    	r3, r4, #0
0x00580b:	movs    	r1, #0xff
0x00580d:	movs    	r2, #0
0x00580f:	adds    	r1, #0x54
0x005811:	movs    	r0, #0xf1
0x005813:	lsls    	r0, r0, #9
0x005815:	str     	r2, [sp, #8]
0x005817:	bl      	#0x5159
; block 0x581b
0x00581b:	movs    	r1, #0x64
0x00581d:	str     	r1, [sp]
0x00581f:	str     	r1, [sp, #4]
0x005821:	movs    	r2, #0
0x005823:	movs    	r1, #0x32
0x005825:	adds    	r3, r4, #0
0x005827:	movs    	r0, #0xf1
0x005829:	lsls    	r0, r0, #9
0x00582b:	str     	r2, [sp, #8]
0x00582d:	bl      	#0x5159
; block 0x5831
0x005831:	movs    	r2, #0
0x005833:	movs    	r1, #0
0x005835:	movs    	r0, #0
0x005837:	bl      	#0x5109
; block 0x583b
0x00583b:	bl      	#0x2a71
; block 0x583f
0x00583f:	bl      	#0x2869
; block 0x5843
0x005843:	movs    	r1, #0
0x005845:	movs    	r2, #0
0x005847:	str     	r2, [sp, #8]
0x005849:	str     	r1, [sp]
0x00584b:	str     	r1, [sp, #4]
0x00584d:	movs    	r1, #0x24
0x00584f:	movs    	r2, #1
0x005851:	adds    	r3, r4, #0
0x005853:	movs    	r0, #0xf1
0x005855:	lsls    	r0, r0, #9
0x005857:	bl      	#0x5159
; block 0x585b
0x00585b:	ldr     	r0, [pc, #0x3c]
0x00585d:	add     	r0, pc
0x00585f:	str     	r0, [sp, #0xc]
0x005861:	movs    	r0, #0xff
0x005863:	str     	r0, [sp, #0x20]
0x005865:	str     	r0, [sp, #0x24]
0x005867:	str     	r0, [sp, #0x28]
0x005869:	movs    	r0, #1
0x00586b:	str     	r4, [sp, #0x10]
0x00586d:	str     	r4, [sp, #0x14]
0x00586f:	str     	r4, [sp, #0x18]
0x005871:	str     	r4, [sp, #0x1c]
0x005873:	add     	r5, sp, #0xc
0x005875:	movs    	r1, #0x20
0x005877:	strb    	r0, [r1, r5]
0x005879:	movs    	r1, #0
0x00587b:	movs    	r2, #0
0x00587d:	str     	r2, [sp, #8]
0x00587f:	str     	r1, [sp]
0x005881:	str     	r1, [sp, #4]
0x005883:	str     	r0, [sp, #0x30]
0x005885:	adds    	r3, r4, #0
0x005887:	adds    	r2, r5, #0
0x005889:	movs    	r0, #0xf1
0x00588b:	movs    	r1, #0x25
0x00588d:	lsls    	r0, r0, #9
0x00588f:	bl      	#0x5159
; block 0x5893
0x005893:	add     	sp, #0x34
0x005895:	pop     	{r4, r5, pc}

; ===== sub_5899 @ 0x5899 offset=0x5898 size=4 blocks=1 cc=1 =====
; block 0x5899
0x005899:	asrs    	r0, r7, #0xa
0x00589b:	movs    	r0, r0
0x00589d:	push    	{r4, r5, r6, r7, lr}
0x00589f:	sub     	sp, #0xc
0x0058a1:	movs    	r1, #0
0x0058a3:	str     	r1, [sp]
0x0058a5:	str     	r1, [sp, #4]
0x0058a7:	ldr     	r6, [pc, #0xa0]
0x0058a9:	movs    	r2, #0
0x0058ab:	movs    	r4, #0xf1
0x0058ad:	lsls    	r4, r4, #9
0x0058af:	str     	r2, [sp, #8]
0x0058b1:	movs    	r1, #0x11
0x0058b3:	adds    	r5, r0, #0
0x0058b5:	movs    	r3, #4
0x0058b7:	add     	r6, sb
0x0058b9:	ldr     	r2, [r6, #0x1c]
0x0058bb:	adds    	r0, r4, #0
0x0058bd:	bl      	#0x5159

; ===== sub_589d @ 0x589d offset=0x589c size=172 blocks=19 cc=13 =====
; block 0x589d
0x00589d:	push    	{r4, r5, r6, r7, lr}
0x00589f:	sub     	sp, #0xc
0x0058a1:	movs    	r1, #0
0x0058a3:	str     	r1, [sp]
0x0058a5:	str     	r1, [sp, #4]
0x0058a7:	ldr     	r6, [pc, #0xa0]
0x0058a9:	movs    	r2, #0
0x0058ab:	movs    	r4, #0xf1
0x0058ad:	lsls    	r4, r4, #9
0x0058af:	str     	r2, [sp, #8]
0x0058b1:	movs    	r1, #0x11
0x0058b3:	adds    	r5, r0, #0
0x0058b5:	movs    	r3, #4
0x0058b7:	add     	r6, sb
0x0058b9:	ldr     	r2, [r6, #0x1c]
0x0058bb:	adds    	r0, r4, #0
0x0058bd:	bl      	#0x5159
; block 0x58c1
0x0058c1:	adds    	r7, r0, #0
0x0058c3:	ldr     	r0, [pc, #0x84]
0x0058c5:	adds    	r1, r5, #0
0x0058c7:	add     	r0, sb
0x0058c9:	adds    	r0, #0x14
0x0058cb:	movs    	r5, #0
0x0058cd:	cmp     	r1, #0xd
0x0058cf:	beq     	#0x5931
; block 0x58d1
0x0058d1:	bgt     	#0x58fd
; block 0x58d3
0x0058d3:	cmp     	r1, #2
0x0058d5:	beq     	#0x58e3
; block 0x58d7
0x0058d7:	cmp     	r1, #5
0x0058d9:	beq     	#0x5909
; block 0x58db
0x0058db:	cmp     	r1, #8
0x0058dd:	beq     	#0x5931
; block 0x58df
0x0058df:	cmp     	r1, #0xc
0x0058e1:	bne     	#0x58f9
; block 0x58e3
0x0058e3:	movs    	r2, #0
0x0058e5:	movs    	r1, #0
0x0058e7:	str     	r1, [sp, #4]
0x0058e9:	str     	r2, [sp, #8]
0x0058eb:	adds    	r2, r7, #0
0x0058ed:	movs    	r1, #0x29
0x0058ef:	str     	r0, [sp]
0x0058f1:	adds    	r3, r5, #0
0x0058f3:	adds    	r0, r4, #0
0x0058f5:	bl      	#0x5159
; block 0x58f9
0x0058f9:	add     	sp, #0xc
0x0058fb:	pop     	{r4, r5, r6, r7, pc}
; block 0x58fd
0x0058fd:	cmp     	r1, #0x11
0x0058ff:	beq     	#0x5909
; block 0x5901
0x005901:	cmp     	r1, #0x12
0x005903:	beq     	#0x5917
; block 0x5905
0x005905:	cmp     	r1, #0x14
0x005907:	bne     	#0x58f9
; block 0x5909
0x005909:	ldr     	r0, [r6, #0x14]
0x00590b:	ldr     	r1, [r6, #0x1c]
0x00590d:	lsls    	r0, r0, #2
0x00590f:	ldr     	r0, [r1, r0]
0x005911:	bl      	#0xa01
; block 0x5915
0x005915:	b       	#0x58f9
; block 0x5917
0x005917:	bl      	#0x5e89
; block 0x591b
0x00591b:	movs    	r1, #0
0x00591d:	str     	r1, [sp]
0x00591f:	str     	r1, [sp, #4]
0x005921:	movs    	r2, #0
0x005923:	movs    	r1, #0x2c
0x005925:	adds    	r3, r5, #0
0x005927:	adds    	r0, r4, #0
0x005929:	str     	r2, [sp, #8]
0x00592b:	bl      	#0x5159
; block 0x592f
0x00592f:	b       	#0x58f9
; block 0x5931
0x005931:	movs    	r2, #0
0x005933:	movs    	r1, #1
0x005935:	str     	r1, [sp, #4]
0x005937:	str     	r2, [sp, #8]
0x005939:	adds    	r2, r7, #0
0x00593b:	movs    	r1, #0x29
0x00593d:	str     	r0, [sp]
0x00593f:	adds    	r3, r5, #0
0x005941:	adds    	r0, r4, #0
0x005943:	bl      	#0x5159
; block 0x5947
0x005947:	b       	#0x58f9

; ===== sub_5949 @ 0x5949 offset=0x5948 size=4 blocks=1 cc=1 =====
; block 0x5949
0x005949:	movs    	r4, r1
0x00594b:	movs    	r0, r0
0x00594d:	push    	{lr}
0x00594f:	subs    	r0, #2
0x005951:	cmp     	r0, #0x13
0x005953:	sub     	sp, #0xc
0x005955:	bhs     	#0x5991

; ===== sub_594d @ 0x594d offset=0x594c size=118 blocks=11 cc=8 =====
; block 0x594d
0x00594d:	push    	{lr}
0x00594f:	subs    	r0, #2
0x005951:	cmp     	r0, #0x13
0x005953:	sub     	sp, #0xc
0x005955:	bhs     	#0x5991
; block 0x5957
0x005957:	adr     	r3, #8
0x005959:	ldrb    	r3, [r3, r0]
0x00595b:	lsls    	r3, r3, #1
0x00595d:	add     	pc, r3
; block 0x5975
0x005975:	ldr     	r0, [pc, #0x60]
0x005977:	movs    	r2, #0
0x005979:	movs    	r1, #0
0x00597b:	add     	r0, sb
0x00597d:	str     	r0, [sp]
0x00597f:	str     	r1, [sp, #4]
0x005981:	str     	r2, [sp, #8]
0x005983:	movs    	r2, #3
0x005985:	movs    	r1, #0x29
0x005987:	movs    	r0, #0xf1
0x005989:	movs    	r3, #0
0x00598b:	lsls    	r0, r0, #9
0x00598d:	bl      	#0x5159
; block 0x5991
0x005991:	add     	sp, #0xc
0x005993:	pop     	{pc}
; block 0x5995
0x005995:	ldr     	r0, [pc, #0x40]
0x005997:	movs    	r2, #0
0x005999:	movs    	r1, #1
0x00599b:	add     	r0, sb
0x00599d:	str     	r0, [sp]
0x00599f:	str     	r1, [sp, #4]
0x0059a1:	str     	r2, [sp, #8]
0x0059a3:	movs    	r2, #3
0x0059a5:	movs    	r1, #0x29
0x0059a7:	movs    	r0, #0xf1
0x0059a9:	movs    	r3, #0
0x0059ab:	lsls    	r0, r0, #9
0x0059ad:	bl      	#0x5159
; block 0x59b1
0x0059b1:	b       	#0x5991
; block 0x59b3
0x0059b3:	bl      	#0x45a9
; block 0x59b7
0x0059b7:	b       	#0x5991
; block 0x59b9
0x0059b9:	bl      	#0x5d2d
; block 0x59bd
0x0059bd:	movs    	r2, #0
0x0059bf:	movs    	r1, #0
0x0059c1:	movs    	r0, #2
0x0059c3:	str     	r0, [sp]
0x0059c5:	str     	r1, [sp, #4]
0x0059c7:	str     	r2, [sp, #8]
0x0059c9:	movs    	r2, #0x17
0x0059cb:	movs    	r1, #0x14
0x0059cd:	movs    	r0, #0xf1
0x0059cf:	movs    	r3, #1
0x0059d1:	lsls    	r0, r0, #9
0x0059d3:	bl      	#0x5159
; block 0x59d7
0x0059d7:	b       	#0x5991

; ===== sub_59d9 @ 0x59d9 offset=0x59d8 size=4 blocks=1 cc=1 =====
; block 0x59d9
0x0059d9:	movs    	r4, r3
0x0059db:	movs    	r0, r0
0x0059dd:	push    	{r4, r5, r6, r7, lr}
0x0059df:	sub     	sp, #0xc
0x0059e1:	movs    	r1, #0
0x0059e3:	movs    	r2, #0
0x0059e5:	str     	r2, [sp, #8]
0x0059e7:	str     	r1, [sp]
0x0059e9:	str     	r1, [sp, #4]
0x0059eb:	movs    	r5, #0xf1
0x0059ed:	movs    	r4, #0
0x0059ef:	adds    	r3, r4, #0
0x0059f1:	lsls    	r5, r5, #9
0x0059f3:	movs    	r1, #0xe1
0x0059f5:	movs    	r2, #0x1e
0x0059f7:	adds    	r0, r5, #0
0x0059f9:	bl      	#0x5159

; ===== sub_59dd @ 0x59dd offset=0x59dc size=168 blocks=11 cc=8 =====
; block 0x59dd
0x0059dd:	push    	{r4, r5, r6, r7, lr}
0x0059df:	sub     	sp, #0xc
0x0059e1:	movs    	r1, #0
0x0059e3:	movs    	r2, #0
0x0059e5:	str     	r2, [sp, #8]
0x0059e7:	str     	r1, [sp]
0x0059e9:	str     	r1, [sp, #4]
0x0059eb:	movs    	r5, #0xf1
0x0059ed:	movs    	r4, #0
0x0059ef:	adds    	r3, r4, #0
0x0059f1:	lsls    	r5, r5, #9
0x0059f3:	movs    	r1, #0xe1
0x0059f5:	movs    	r2, #0x1e
0x0059f7:	adds    	r0, r5, #0
0x0059f9:	bl      	#0x5159
; block 0x59fd
0x0059fd:	cmp     	r0, #0
0x0059ff:	beq     	#0x5a2d
; block 0x5a01
0x005a01:	movs    	r1, #0
0x005a03:	movs    	r2, #0
0x005a05:	str     	r2, [sp, #8]
0x005a07:	str     	r1, [sp]
0x005a09:	str     	r1, [sp, #4]
0x005a0b:	movs    	r1, #0xe1
0x005a0d:	movs    	r2, #0x1e
0x005a0f:	adds    	r3, r4, #0
0x005a11:	adds    	r0, r5, #0
0x005a13:	bl      	#0x5159
; block 0x5a17
0x005a17:	movs    	r1, #0
0x005a19:	movs    	r2, #0
0x005a1b:	str     	r2, [sp, #8]
0x005a1d:	str     	r1, [sp]
0x005a1f:	str     	r1, [sp, #4]
0x005a21:	movs    	r1, #9
0x005a23:	adds    	r2, r0, #0
0x005a25:	adds    	r3, r4, #0
0x005a27:	adds    	r0, r5, #0
0x005a29:	bl      	#0x5159
; block 0x5a2d
0x005a2d:	movs    	r2, #0
0x005a2f:	movs    	r1, #0
0x005a31:	str     	r1, [sp, #4]
0x005a33:	str     	r2, [sp, #8]
0x005a35:	movs    	r0, #2
0x005a37:	str     	r0, [sp]
0x005a39:	movs    	r2, #0x1e
0x005a3b:	movs    	r1, #0x14
0x005a3d:	adds    	r3, r4, #0
0x005a3f:	adds    	r0, r5, #0
0x005a41:	bl      	#0x5159
; block 0x5a45
0x005a45:	ldr     	r6, [pc, #0x3c]
0x005a47:	add     	r6, sb
0x005a49:	ldr     	r7, [r6]
0x005a4b:	cmp     	r7, #0
0x005a4d:	beq     	#0x5a67
; block 0x5a4f
0x005a4f:	movs    	r1, #0
0x005a51:	movs    	r2, #0
0x005a53:	str     	r2, [sp, #8]
0x005a55:	str     	r1, [sp]
0x005a57:	str     	r1, [sp, #4]
0x005a59:	movs    	r1, #0x4c
0x005a5b:	adds    	r2, r7, #0
0x005a5d:	adds    	r3, r4, #0
0x005a5f:	adds    	r0, r5, #0
0x005a61:	bl      	#0x5159
; block 0x5a65
0x005a65:	str     	r4, [r6]
0x005a67:	movs    	r1, #0
0x005a69:	movs    	r2, #0
0x005a6b:	str     	r2, [sp, #8]
0x005a6d:	str     	r1, [sp]
0x005a6f:	str     	r1, [sp, #4]
0x005a71:	movs    	r1, #0x6b
0x005a73:	movs    	r2, #1
0x005a75:	adds    	r3, r4, #0
0x005a77:	adds    	r0, r5, #0
0x005a79:	bl      	#0x5159
; block 0x5a67
0x005a67:	movs    	r1, #0
0x005a69:	movs    	r2, #0
0x005a6b:	str     	r2, [sp, #8]
0x005a6d:	str     	r1, [sp]
0x005a6f:	str     	r1, [sp, #4]
0x005a71:	movs    	r1, #0x6b
0x005a73:	movs    	r2, #1
0x005a75:	adds    	r3, r4, #0
0x005a77:	adds    	r0, r5, #0
0x005a79:	bl      	#0x5159
; block 0x5a7d
0x005a7d:	bl      	#0x6005
; block 0x5a81
0x005a81:	add     	sp, #0xc
0x005a83:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_5a85 @ 0x5a85 offset=0x5a84 size=4 blocks=1 cc=1 =====
; block 0x5a85
0x005a85:	lsls    	r4, r1, #2
0x005a87:	movs    	r0, r0
0x005a89:	push    	{r4, r5, r6, r7, lr}
0x005a8b:	sub     	sp, #0xc
0x005a8d:	movs    	r1, #0
0x005a8f:	str     	r1, [sp]
0x005a91:	str     	r1, [sp, #4]
0x005a93:	ldr     	r5, [pc, #0x12c]
0x005a95:	movs    	r2, #0
0x005a97:	movs    	r4, #0xf1
0x005a99:	movs    	r6, #0
0x005a9b:	adds    	r3, r6, #0
0x005a9d:	lsls    	r4, r4, #9
0x005a9f:	str     	r2, [sp, #8]
0x005aa1:	movs    	r1, #6
0x005aa3:	add     	r5, sb
0x005aa5:	ldr     	r2, [r5, #0x58]
0x005aa7:	adds    	r0, r4, #0
0x005aa9:	bl      	#0x5159

; ===== sub_5a89 @ 0x5a89 offset=0x5a88 size=310 blocks=19 cc=18 =====
; block 0x5a89
0x005a89:	push    	{r4, r5, r6, r7, lr}
0x005a8b:	sub     	sp, #0xc
0x005a8d:	movs    	r1, #0
0x005a8f:	str     	r1, [sp]
0x005a91:	str     	r1, [sp, #4]
0x005a93:	ldr     	r5, [pc, #0x12c]
0x005a95:	movs    	r2, #0
0x005a97:	movs    	r4, #0xf1
0x005a99:	movs    	r6, #0
0x005a9b:	adds    	r3, r6, #0
0x005a9d:	lsls    	r4, r4, #9
0x005a9f:	str     	r2, [sp, #8]
0x005aa1:	movs    	r1, #6
0x005aa3:	add     	r5, sb
0x005aa5:	ldr     	r2, [r5, #0x58]
0x005aa7:	adds    	r0, r4, #0
0x005aa9:	bl      	#0x5159
; block 0x5aad
0x005aad:	movs    	r0, #0
0x005aaf:	str     	r0, [r5, #0x58]
0x005ab1:	movs    	r1, #0
0x005ab3:	str     	r1, [sp, #4]
0x005ab5:	movs    	r2, #0
0x005ab7:	str     	r0, [sp]
0x005ab9:	str     	r2, [sp, #8]
0x005abb:	movs    	r1, #6
0x005abd:	movs    	r3, #0
0x005abf:	adds    	r0, r4, #0
0x005ac1:	ldr     	r2, [r5, #0x5c]
0x005ac3:	bl      	#0x5159
; block 0x5ac7
0x005ac7:	movs    	r0, #0
0x005ac9:	str     	r0, [r5, #0x5c]
0x005acb:	ldr     	r7, [r5, #0x24]
0x005acd:	cmp     	r7, #0
0x005acf:	beq     	#0x5ae7
; block 0x5ad1
0x005ad1:	movs    	r1, #0
0x005ad3:	movs    	r2, #0
0x005ad5:	str     	r2, [sp, #8]
0x005ad7:	str     	r1, [sp]
0x005ad9:	str     	r1, [sp, #4]
0x005adb:	movs    	r1, #6
0x005add:	adds    	r2, r7, #0
0x005adf:	adds    	r3, r6, #0
0x005ae1:	adds    	r0, r4, #0
0x005ae3:	bl      	#0x5159
; block 0x5ae7
0x005ae7:	str     	r6, [r5, #0x24]
0x005ae9:	ldr     	r7, [r5, #0x28]
0x005aeb:	cmp     	r7, #0
0x005aed:	beq     	#0x5b05
; block 0x5aef
0x005aef:	movs    	r1, #0
0x005af1:	movs    	r2, #0
0x005af3:	str     	r2, [sp, #8]
0x005af5:	str     	r1, [sp]
0x005af7:	str     	r1, [sp, #4]
0x005af9:	movs    	r1, #6
0x005afb:	adds    	r2, r7, #0
0x005afd:	adds    	r3, r6, #0
0x005aff:	adds    	r0, r4, #0
0x005b01:	bl      	#0x5159
; block 0x5b05
0x005b05:	str     	r6, [r5, #0x28]
0x005b07:	ldr     	r7, [r5, #0x2c]
0x005b09:	cmp     	r7, #0
0x005b0b:	beq     	#0x5b23
; block 0x5b0d
0x005b0d:	movs    	r1, #0
0x005b0f:	movs    	r2, #0
0x005b11:	str     	r2, [sp, #8]
0x005b13:	str     	r1, [sp]
0x005b15:	str     	r1, [sp, #4]
0x005b17:	movs    	r1, #6
0x005b19:	adds    	r2, r7, #0
0x005b1b:	adds    	r3, r6, #0
0x005b1d:	adds    	r0, r4, #0
0x005b1f:	bl      	#0x5159
; block 0x5b23
0x005b23:	str     	r6, [r5, #0x2c]
0x005b25:	ldr     	r7, [r5, #0x30]
0x005b27:	cmp     	r7, #0
0x005b29:	beq     	#0x5b41
; block 0x5b2b
0x005b2b:	movs    	r1, #0
0x005b2d:	movs    	r2, #0
0x005b2f:	str     	r2, [sp, #8]
0x005b31:	str     	r1, [sp]
0x005b33:	str     	r1, [sp, #4]
0x005b35:	movs    	r1, #6
0x005b37:	adds    	r2, r7, #0
0x005b39:	adds    	r3, r6, #0
0x005b3b:	adds    	r0, r4, #0
0x005b3d:	bl      	#0x5159
; block 0x5b41
0x005b41:	str     	r6, [r5, #0x30]
0x005b43:	ldr     	r7, [r5, #0x34]
0x005b45:	cmp     	r7, #0
0x005b47:	beq     	#0x5b5f
; block 0x5b49
0x005b49:	movs    	r1, #0
0x005b4b:	movs    	r2, #0
0x005b4d:	str     	r2, [sp, #8]
0x005b4f:	str     	r1, [sp]
0x005b51:	str     	r1, [sp, #4]
0x005b53:	movs    	r1, #6
0x005b55:	adds    	r2, r7, #0
0x005b57:	adds    	r3, r6, #0
0x005b59:	adds    	r0, r4, #0
0x005b5b:	bl      	#0x5159
; block 0x5b5f
0x005b5f:	str     	r6, [r5, #0x34]
0x005b61:	ldr     	r7, [r5, #0x38]
0x005b63:	cmp     	r7, #0
0x005b65:	beq     	#0x5b7d
; block 0x5b67
0x005b67:	movs    	r1, #0
0x005b69:	movs    	r2, #0
0x005b6b:	str     	r2, [sp, #8]
0x005b6d:	str     	r1, [sp]
0x005b6f:	str     	r1, [sp, #4]
0x005b71:	movs    	r1, #6
0x005b73:	adds    	r2, r7, #0
0x005b75:	adds    	r3, r6, #0
0x005b77:	adds    	r0, r4, #0
0x005b79:	bl      	#0x5159
; block 0x5b7d
0x005b7d:	str     	r6, [r5, #0x38]
0x005b7f:	ldr     	r7, [r5, #0x3c]
0x005b81:	cmp     	r7, #0
0x005b83:	beq     	#0x5b9b
; block 0x5b85
0x005b85:	movs    	r1, #0
0x005b87:	movs    	r2, #0
0x005b89:	str     	r2, [sp, #8]
0x005b8b:	str     	r1, [sp]
0x005b8d:	str     	r1, [sp, #4]
0x005b8f:	movs    	r1, #6
0x005b91:	adds    	r2, r7, #0
0x005b93:	adds    	r3, r6, #0
0x005b95:	adds    	r0, r4, #0
0x005b97:	bl      	#0x5159
; block 0x5b9b
0x005b9b:	str     	r6, [r5, #0x3c]
0x005b9d:	ldr     	r7, [r5, #0x40]
0x005b9f:	cmp     	r7, #0
0x005ba1:	beq     	#0x5bb9
; block 0x5ba3
0x005ba3:	movs    	r1, #0
0x005ba5:	movs    	r2, #0
0x005ba7:	str     	r2, [sp, #8]
0x005ba9:	str     	r1, [sp]
0x005bab:	str     	r1, [sp, #4]
0x005bad:	movs    	r1, #6
0x005baf:	adds    	r2, r7, #0
0x005bb1:	adds    	r3, r6, #0
0x005bb3:	adds    	r0, r4, #0
0x005bb5:	bl      	#0x5159
; block 0x5bb9
0x005bb9:	str     	r6, [r5, #0x40]
0x005bbb:	add     	sp, #0xc
0x005bbd:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_5bc1 @ 0x5bc1 offset=0x5bc0 size=4 blocks=1 cc=1 =====
; block 0x5bc1
0x005bc1:	movs    	r4, r1
0x005bc3:	movs    	r0, r0
0x005bc5:	push    	{r4, r5, lr}
0x005bc7:	sub     	sp, #0xc
0x005bc9:	movs    	r1, #0
0x005bcb:	str     	r1, [sp]
0x005bcd:	str     	r1, [sp, #4]
0x005bcf:	ldr     	r4, [pc, #0x38]
0x005bd1:	movs    	r2, #0
0x005bd3:	movs    	r5, #0
0x005bd5:	adds    	r3, r5, #0
0x005bd7:	str     	r2, [sp, #8]
0x005bd9:	movs    	r1, #6
0x005bdb:	movs    	r0, #0xf1
0x005bdd:	add     	r4, sb
0x005bdf:	ldr     	r2, [r4, #0x14]
0x005be1:	lsls    	r0, r0, #9
0x005be3:	bl      	#0x5159

; ===== sub_5bc5 @ 0x5bc5 offset=0x5bc4 size=66 blocks=3 cc=2 =====
; block 0x5bc5
0x005bc5:	push    	{r4, r5, lr}
0x005bc7:	sub     	sp, #0xc
0x005bc9:	movs    	r1, #0
0x005bcb:	str     	r1, [sp]
0x005bcd:	str     	r1, [sp, #4]
0x005bcf:	ldr     	r4, [pc, #0x38]
0x005bd1:	movs    	r2, #0
0x005bd3:	movs    	r5, #0
0x005bd5:	adds    	r3, r5, #0
0x005bd7:	str     	r2, [sp, #8]
0x005bd9:	movs    	r1, #6
0x005bdb:	movs    	r0, #0xf1
0x005bdd:	add     	r4, sb
0x005bdf:	ldr     	r2, [r4, #0x14]
0x005be1:	lsls    	r0, r0, #9
0x005be3:	bl      	#0x5159
; block 0x5be7
0x005be7:	str     	r0, [r4, #0x14]
0x005be9:	movs    	r1, #0
0x005beb:	str     	r1, [sp]
0x005bed:	str     	r1, [sp, #4]
0x005bef:	movs    	r2, #0
0x005bf1:	str     	r2, [sp, #8]
0x005bf3:	movs    	r1, #6
0x005bf5:	movs    	r0, #0xf1
0x005bf7:	adds    	r3, r5, #0
0x005bf9:	lsls    	r0, r0, #9
0x005bfb:	ldr     	r2, [r4, #0x18]
0x005bfd:	bl      	#0x5159
; block 0x5c01
0x005c01:	str     	r0, [r4, #0x18]
0x005c03:	add     	sp, #0xc
0x005c05:	pop     	{r4, r5, pc}

; ===== sub_5c09 @ 0x5c09 offset=0x5c08 size=4 blocks=1 cc=1 =====
; block 0x5c09
0x005c09:	lsls    	r4, r1, #2
0x005c0b:	movs    	r0, r0
0x005c0d:	push    	{r4, r5, r6, r7, lr}
0x005c0f:	sub     	sp, #0xc
0x005c11:	movs    	r1, #0
0x005c13:	str     	r1, [sp]
0x005c15:	str     	r1, [sp, #4]
0x005c17:	ldr     	r6, [pc, #0x110]
0x005c19:	movs    	r2, #0
0x005c1b:	movs    	r4, #0xf1
0x005c1d:	movs    	r5, #0
0x005c1f:	adds    	r3, r5, #0
0x005c21:	lsls    	r4, r4, #9
0x005c23:	str     	r2, [sp, #8]
0x005c25:	movs    	r1, #6
0x005c27:	add     	r6, sb
0x005c29:	ldr     	r2, [r6, #0xc]
0x005c2b:	adds    	r0, r4, #0
0x005c2d:	bl      	#0x5159

; ===== sub_5c0d @ 0x5c0d offset=0x5c0c size=284 blocks=18 cc=17 =====
; block 0x5c0d
0x005c0d:	push    	{r4, r5, r6, r7, lr}
0x005c0f:	sub     	sp, #0xc
0x005c11:	movs    	r1, #0
0x005c13:	str     	r1, [sp]
0x005c15:	str     	r1, [sp, #4]
0x005c17:	ldr     	r6, [pc, #0x110]
0x005c19:	movs    	r2, #0
0x005c1b:	movs    	r4, #0xf1
0x005c1d:	movs    	r5, #0
0x005c1f:	adds    	r3, r5, #0
0x005c21:	lsls    	r4, r4, #9
0x005c23:	str     	r2, [sp, #8]
0x005c25:	movs    	r1, #6
0x005c27:	add     	r6, sb
0x005c29:	ldr     	r2, [r6, #0xc]
0x005c2b:	adds    	r0, r4, #0
0x005c2d:	bl      	#0x5159
; block 0x5c31
0x005c31:	str     	r0, [r6, #0xc]
0x005c33:	subs    	r6, #0x80
0x005c35:	ldr     	r7, [r6, #0x24]
0x005c37:	cmp     	r7, #0
0x005c39:	beq     	#0x5c51
; block 0x5c3b
0x005c3b:	movs    	r1, #0
0x005c3d:	movs    	r2, #0
0x005c3f:	str     	r2, [sp, #8]
0x005c41:	str     	r1, [sp]
0x005c43:	str     	r1, [sp, #4]
0x005c45:	movs    	r1, #6
0x005c47:	adds    	r2, r7, #0
0x005c49:	adds    	r3, r5, #0
0x005c4b:	adds    	r0, r4, #0
0x005c4d:	bl      	#0x5159
; block 0x5c51
0x005c51:	str     	r5, [r6, #0x24]
0x005c53:	ldr     	r7, [r6, #0x28]
0x005c55:	cmp     	r7, #0
0x005c57:	beq     	#0x5c6f
; block 0x5c59
0x005c59:	movs    	r1, #0
0x005c5b:	movs    	r2, #0
0x005c5d:	str     	r2, [sp, #8]
0x005c5f:	str     	r1, [sp]
0x005c61:	str     	r1, [sp, #4]
0x005c63:	movs    	r1, #6
0x005c65:	adds    	r2, r7, #0
0x005c67:	adds    	r3, r5, #0
0x005c69:	adds    	r0, r4, #0
0x005c6b:	bl      	#0x5159
; block 0x5c6f
0x005c6f:	str     	r5, [r6, #0x28]
0x005c71:	ldr     	r7, [r6, #0x2c]
0x005c73:	cmp     	r7, #0
0x005c75:	beq     	#0x5c8d
; block 0x5c77
0x005c77:	movs    	r1, #0
0x005c79:	movs    	r2, #0
0x005c7b:	str     	r2, [sp, #8]
0x005c7d:	str     	r1, [sp]
0x005c7f:	str     	r1, [sp, #4]
0x005c81:	movs    	r1, #6
0x005c83:	adds    	r2, r7, #0
0x005c85:	adds    	r3, r5, #0
0x005c87:	adds    	r0, r4, #0
0x005c89:	bl      	#0x5159
; block 0x5c8d
0x005c8d:	str     	r5, [r6, #0x2c]
0x005c8f:	ldr     	r7, [r6, #0x30]
0x005c91:	cmp     	r7, #0
0x005c93:	beq     	#0x5cab
; block 0x5c95
0x005c95:	movs    	r1, #0
0x005c97:	movs    	r2, #0
0x005c99:	str     	r2, [sp, #8]
0x005c9b:	str     	r1, [sp]
0x005c9d:	str     	r1, [sp, #4]
0x005c9f:	movs    	r1, #6
0x005ca1:	adds    	r2, r7, #0
0x005ca3:	adds    	r3, r5, #0
0x005ca5:	adds    	r0, r4, #0
0x005ca7:	bl      	#0x5159
; block 0x5cab
0x005cab:	str     	r5, [r6, #0x30]
0x005cad:	ldr     	r7, [r6, #0x34]
0x005caf:	cmp     	r7, #0
0x005cb1:	beq     	#0x5cc9
; block 0x5cb3
0x005cb3:	movs    	r1, #0
0x005cb5:	movs    	r2, #0
0x005cb7:	str     	r2, [sp, #8]
0x005cb9:	str     	r1, [sp]
0x005cbb:	str     	r1, [sp, #4]
0x005cbd:	movs    	r1, #6
0x005cbf:	adds    	r2, r7, #0
0x005cc1:	adds    	r3, r5, #0
0x005cc3:	adds    	r0, r4, #0
0x005cc5:	bl      	#0x5159
; block 0x5cc9
0x005cc9:	str     	r5, [r6, #0x34]
0x005ccb:	ldr     	r7, [r6, #0x38]
0x005ccd:	cmp     	r7, #0
0x005ccf:	beq     	#0x5ce7
; block 0x5cd1
0x005cd1:	movs    	r1, #0
0x005cd3:	movs    	r2, #0
0x005cd5:	str     	r2, [sp, #8]
0x005cd7:	str     	r1, [sp]
0x005cd9:	str     	r1, [sp, #4]
0x005cdb:	movs    	r1, #6
0x005cdd:	adds    	r2, r7, #0
0x005cdf:	adds    	r3, r5, #0
0x005ce1:	adds    	r0, r4, #0
0x005ce3:	bl      	#0x5159
; block 0x5ce7
0x005ce7:	str     	r5, [r6, #0x38]
0x005ce9:	ldr     	r7, [r6, #0x3c]
0x005ceb:	cmp     	r7, #0
0x005ced:	beq     	#0x5d05
; block 0x5cef
0x005cef:	movs    	r1, #0
0x005cf1:	movs    	r2, #0
0x005cf3:	str     	r2, [sp, #8]
0x005cf5:	str     	r1, [sp]
0x005cf7:	str     	r1, [sp, #4]
0x005cf9:	movs    	r1, #6
0x005cfb:	adds    	r2, r7, #0
0x005cfd:	adds    	r3, r5, #0
0x005cff:	adds    	r0, r4, #0
0x005d01:	bl      	#0x5159
; block 0x5d05
0x005d05:	str     	r5, [r6, #0x3c]
0x005d07:	ldr     	r7, [r6, #0x40]
0x005d09:	cmp     	r7, #0
0x005d0b:	beq     	#0x5d23
; block 0x5d0d
0x005d0d:	movs    	r1, #0
0x005d0f:	movs    	r2, #0
0x005d11:	str     	r2, [sp, #8]
0x005d13:	str     	r1, [sp]
0x005d15:	str     	r1, [sp, #4]
0x005d17:	movs    	r1, #6
0x005d19:	adds    	r2, r7, #0
0x005d1b:	adds    	r3, r5, #0
0x005d1d:	adds    	r0, r4, #0
0x005d1f:	bl      	#0x5159
; block 0x5d23
0x005d23:	str     	r5, [r6, #0x40]
0x005d25:	add     	sp, #0xc
0x005d27:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_5d29 @ 0x5d29 offset=0x5d28 size=4 blocks=1 cc=1 =====
; block 0x5d29
0x005d29:	lsls    	r4, r1, #2
0x005d2b:	movs    	r0, r0
0x005d2d:	push    	{r4, r5, r6, r7, lr}
0x005d2f:	sub     	sp, #0xc
0x005d31:	movs    	r1, #0
0x005d33:	ldr     	r0, [pc, #0x150]
0x005d35:	str     	r1, [sp]
0x005d37:	str     	r1, [sp, #4]
0x005d39:	movs    	r2, #0
0x005d3b:	str     	r2, [sp, #8]
0x005d3d:	movs    	r7, #0xf1
0x005d3f:	add     	r0, sb
0x005d41:	ldr     	r2, [r0, #0x18]
0x005d43:	lsls    	r7, r7, #9
0x005d45:	movs    	r1, #0x26
0x005d47:	movs    	r3, #0
0x005d49:	adds    	r0, r7, #0
0x005d4b:	bl      	#0x5159

; ===== sub_5d2d @ 0x5d2d offset=0x5d2c size=344 blocks=20 cc=18 =====
; block 0x5d2d
0x005d2d:	push    	{r4, r5, r6, r7, lr}
0x005d2f:	sub     	sp, #0xc
0x005d31:	movs    	r1, #0
0x005d33:	ldr     	r0, [pc, #0x150]
0x005d35:	str     	r1, [sp]
0x005d37:	str     	r1, [sp, #4]
0x005d39:	movs    	r2, #0
0x005d3b:	str     	r2, [sp, #8]
0x005d3d:	movs    	r7, #0xf1
0x005d3f:	add     	r0, sb
0x005d41:	ldr     	r2, [r0, #0x18]
0x005d43:	lsls    	r7, r7, #9
0x005d45:	movs    	r1, #0x26
0x005d47:	movs    	r3, #0
0x005d49:	adds    	r0, r7, #0
0x005d4b:	bl      	#0x5159
; block 0x5d4f
0x005d4f:	adds    	r6, r0, #0
0x005d51:	movs    	r5, #0
0x005d53:	cmp     	r0, #0
0x005d55:	ble     	#0x5e0d
; block 0x5d57
0x005d57:	movs    	r1, #0
0x005d59:	ldr     	r0, [pc, #0x128]
0x005d5b:	str     	r1, [sp]
0x005d5d:	str     	r1, [sp, #4]
0x005d5f:	movs    	r2, #0
0x005d61:	str     	r2, [sp, #8]
0x005d63:	add     	r0, sb
0x005d65:	ldr     	r2, [r0, #0x18]
0x005d67:	movs    	r1, #0x27
0x005d69:	adds    	r3, r5, #0
0x005d6b:	adds    	r0, r7, #0
0x005d6d:	bl      	#0x5159
; block 0x5d71
0x005d71:	adds    	r4, r0, #0
0x005d73:	beq     	#0x5ded
; block 0x5d75
0x005d75:	movs    	r1, #0
0x005d77:	str     	r1, [sp]
0x005d79:	str     	r1, [sp, #4]
0x005d7b:	movs    	r2, #0
0x005d7d:	str     	r2, [sp, #8]
0x005d7f:	movs    	r1, #9
0x005d81:	movs    	r3, #0
0x005d83:	adds    	r0, r7, #0
0x005d85:	ldr     	r2, [r4]
0x005d87:	bl      	#0x5159
; block 0x5d8b
0x005d8b:	movs    	r1, #0
0x005d8d:	str     	r1, [sp]
0x005d8f:	str     	r1, [sp, #4]
0x005d91:	movs    	r2, #0
0x005d93:	str     	r2, [sp, #8]
0x005d95:	movs    	r1, #9
0x005d97:	movs    	r3, #0
0x005d99:	movs    	r0, #0xf1
0x005d9b:	lsls    	r0, r0, #9
0x005d9d:	ldr     	r2, [r4, #0x28]
0x005d9f:	bl      	#0x5159
; block 0x5da3
0x005da3:	ldr     	r3, [r4, #0x3c]
0x005da5:	cmp     	r3, #0
0x005da7:	beq     	#0x5dbf
; block 0x5da9
0x005da9:	movs    	r2, #0
0x005dab:	movs    	r1, #0
0x005dad:	str     	r2, [sp, #8]
0x005daf:	adds    	r2, r3, #0
0x005db1:	str     	r1, [sp]
0x005db3:	str     	r1, [sp, #4]
0x005db5:	movs    	r1, #9
0x005db7:	movs    	r3, #0
0x005db9:	adds    	r0, r7, #0
0x005dbb:	bl      	#0x5159
; block 0x5dbf
0x005dbf:	movs    	r1, #0
0x005dc1:	str     	r1, [sp]
0x005dc3:	str     	r1, [sp, #4]
0x005dc5:	movs    	r2, #0
0x005dc7:	str     	r2, [sp, #8]
0x005dc9:	movs    	r1, #0x4a
0x005dcb:	movs    	r3, #0
0x005dcd:	adds    	r0, r7, #0
0x005dcf:	ldr     	r2, [r4, #0x14]
0x005dd1:	bl      	#0x5159
; block 0x5dd5
0x005dd5:	movs    	r1, #0
0x005dd7:	movs    	r2, #0
0x005dd9:	str     	r2, [sp, #8]
0x005ddb:	str     	r1, [sp]
0x005ddd:	str     	r1, [sp, #4]
0x005ddf:	movs    	r1, #9
0x005de1:	adds    	r2, r4, #0
0x005de3:	movs    	r3, #0
0x005de5:	movs    	r0, #0xf1
0x005de7:	lsls    	r0, r0, #9
0x005de9:	bl      	#0x5159
; block 0x5ded
0x005ded:	movs    	r1, #0
0x005def:	ldr     	r0, [pc, #0x94]
0x005df1:	str     	r1, [sp]
0x005df3:	str     	r1, [sp, #4]
0x005df5:	movs    	r2, #0
0x005df7:	str     	r2, [sp, #8]
0x005df9:	add     	r0, sb
0x005dfb:	ldr     	r2, [r0, #0x18]
0x005dfd:	movs    	r1, #0x4b
0x005dff:	adds    	r3, r5, #0
0x005e01:	adds    	r0, r7, #0
0x005e03:	bl      	#0x5159
; block 0x5e07
0x005e07:	subs    	r6, #1
0x005e09:	cmp     	r5, r6
0x005e0b:	blt     	#0x5d57
; block 0x5e0d
0x005e0d:	movs    	r1, #0
0x005e0f:	str     	r1, [sp]
0x005e11:	str     	r1, [sp, #4]
0x005e13:	movs    	r2, #0
0x005e15:	ldr     	r4, [pc, #0x6c]
0x005e17:	movs    	r6, #0
0x005e19:	adds    	r3, r6, #0
0x005e1b:	str     	r2, [sp, #8]
0x005e1d:	movs    	r1, #9
0x005e1f:	adds    	r5, r7, #0
0x005e21:	add     	r4, sb
0x005e23:	ldr     	r2, [r4, #0x18]
0x005e25:	adds    	r0, r7, #0
0x005e27:	bl      	#0x5159
; block 0x5e2b
0x005e2b:	ldr     	r7, [pc, #0x58]
0x005e2d:	str     	r6, [r4, #0x18]
0x005e2f:	movs    	r4, #0
0x005e31:	add     	r7, sb
0x005e33:	adds    	r7, #0xa4
0x005e35:	lsls    	r5, r4, #2
0x005e37:	ldr     	r3, [r7, r5]
0x005e39:	cmp     	r3, #0
0x005e3b:	beq     	#0x5e55
; block 0x5e35
0x005e35:	lsls    	r5, r4, #2
0x005e37:	ldr     	r3, [r7, r5]
0x005e39:	cmp     	r3, #0
0x005e3b:	beq     	#0x5e55
; block 0x5e3d
0x005e3d:	movs    	r2, #0
0x005e3f:	movs    	r1, #0
0x005e41:	str     	r2, [sp, #8]
0x005e43:	adds    	r2, r3, #0
0x005e45:	str     	r1, [sp]
0x005e47:	str     	r1, [sp, #4]
0x005e49:	movs    	r1, #0x4c
0x005e4b:	adds    	r3, r6, #0
0x005e4d:	movs    	r0, #0xf1
0x005e4f:	lsls    	r0, r0, #9
0x005e51:	bl      	#0x5159
; block 0x5e55
0x005e55:	adds    	r4, #1
0x005e57:	cmp     	r4, #3
0x005e59:	str     	r6, [r7, r5]
0x005e5b:	blt     	#0x5e35
; block 0x5e5d
0x005e5d:	ldr     	r4, [pc, #0x24]
0x005e5f:	add     	r4, sb
0x005e61:	ldr     	r5, [r4]
0x005e63:	cmp     	r5, #0
0x005e65:	beq     	#0x5e7f
; block 0x5e67
0x005e67:	movs    	r1, #0
0x005e69:	movs    	r2, #0
0x005e6b:	str     	r2, [sp, #8]
0x005e6d:	str     	r1, [sp]
0x005e6f:	str     	r1, [sp, #4]
0x005e71:	adds    	r3, r6, #0
0x005e73:	adds    	r2, r5, #0
0x005e75:	movs    	r1, #6
0x005e77:	movs    	r0, #0xf1
0x005e79:	lsls    	r0, r0, #9
0x005e7b:	bl      	#0x5159
; block 0x5e7f
0x005e7f:	str     	r6, [r4]
0x005e81:	add     	sp, #0xc
0x005e83:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_5e85 @ 0x5e85 offset=0x5e84 size=4 blocks=1 cc=1 =====
; block 0x5e85
0x005e85:	movs    	r4, r1
0x005e87:	movs    	r0, r0
0x005e89:	push    	{r4, r5, r6, lr}
0x005e8b:	ldr     	r4, [pc, #0x2c]
0x005e8d:	movs    	r5, #0
0x005e8f:	add     	r4, sb
0x005e91:	ldr     	r6, [r4, #0x1c]
0x005e93:	sub     	sp, #0x10
0x005e95:	cmp     	r6, #0
0x005e97:	beq     	#0x5eb1

; ===== sub_5e89 @ 0x5e89 offset=0x5e88 size=46 blocks=3 cc=2 =====
; block 0x5e89
0x005e89:	push    	{r4, r5, r6, lr}
0x005e8b:	ldr     	r4, [pc, #0x2c]
0x005e8d:	movs    	r5, #0
0x005e8f:	add     	r4, sb
0x005e91:	ldr     	r6, [r4, #0x1c]
0x005e93:	sub     	sp, #0x10
0x005e95:	cmp     	r6, #0
0x005e97:	beq     	#0x5eb1
; block 0x5e99
0x005e99:	movs    	r1, #0
0x005e9b:	movs    	r2, #0
0x005e9d:	str     	r2, [sp, #8]
0x005e9f:	str     	r1, [sp]
0x005ea1:	str     	r1, [sp, #4]
0x005ea3:	adds    	r3, r5, #0
0x005ea5:	adds    	r2, r6, #0
0x005ea7:	movs    	r1, #0x12
0x005ea9:	movs    	r0, #0xf1
0x005eab:	lsls    	r0, r0, #9
0x005ead:	bl      	#0x5159
; block 0x5eb1
0x005eb1:	str     	r5, [r4, #0x1c]
0x005eb3:	add     	sp, #0x10
0x005eb5:	pop     	{r4, r5, r6, pc}

; ===== sub_5eb9 @ 0x5eb9 offset=0x5eb8 size=4 blocks=1 cc=1 =====
; block 0x5eb9
0x005eb9:	movs    	r4, r1
0x005ebb:	movs    	r0, r0
0x005ebd:	push    	{r4, r5, r6, r7, lr}
0x005ebf:	adds    	r7, r0, #0
0x005ec1:	ldr     	r0, [pc, #0x13c]
0x005ec3:	movs    	r6, #0xf1
0x005ec5:	add     	r0, sb
0x005ec7:	ldr     	r3, [r0]
0x005ec9:	lsls    	r6, r6, #9
0x005ecb:	movs    	r5, #0
0x005ecd:	movs    	r4, #0
0x005ecf:	cmp     	r3, #0
0x005ed1:	sub     	sp, #0x14
0x005ed3:	beq     	#0x5ef1

; ===== sub_5ebd @ 0x5ebd offset=0x5ebc size=322 blocks=23 cc=19 =====
; block 0x5ebd
0x005ebd:	push    	{r4, r5, r6, r7, lr}
0x005ebf:	adds    	r7, r0, #0
0x005ec1:	ldr     	r0, [pc, #0x13c]
0x005ec3:	movs    	r6, #0xf1
0x005ec5:	add     	r0, sb
0x005ec7:	ldr     	r3, [r0]
0x005ec9:	lsls    	r6, r6, #9
0x005ecb:	movs    	r5, #0
0x005ecd:	movs    	r4, #0
0x005ecf:	cmp     	r3, #0
0x005ed1:	sub     	sp, #0x14
0x005ed3:	beq     	#0x5ef1
; block 0x5ed5
0x005ed5:	movs    	r1, #0
0x005ed7:	movs    	r2, #0
0x005ed9:	str     	r2, [sp, #8]
0x005edb:	str     	r1, [sp]
0x005edd:	str     	r1, [sp, #4]
0x005edf:	movs    	r1, #6
0x005ee1:	adds    	r2, r3, #0
0x005ee3:	adds    	r0, r6, #0
0x005ee5:	adds    	r3, r4, #0
0x005ee7:	bl      	#0x5159
; block 0x5eeb
0x005eeb:	ldr     	r0, [pc, #0x114]
0x005eed:	add     	r0, sb
0x005eef:	str     	r4, [r0]
0x005ef1:	ldr     	r0, [pc, #0x10c]
0x005ef3:	add     	r0, sb
0x005ef5:	ldr     	r3, [r0, #4]
0x005ef7:	cmp     	r3, #0
0x005ef9:	beq     	#0x5f17
; block 0x5ef1
0x005ef1:	ldr     	r0, [pc, #0x10c]
0x005ef3:	add     	r0, sb
0x005ef5:	ldr     	r3, [r0, #4]
0x005ef7:	cmp     	r3, #0
0x005ef9:	beq     	#0x5f17
; block 0x5efb
0x005efb:	movs    	r1, #0
0x005efd:	movs    	r2, #0
0x005eff:	str     	r2, [sp, #8]
0x005f01:	str     	r1, [sp]
0x005f03:	str     	r1, [sp, #4]
0x005f05:	movs    	r1, #9
0x005f07:	adds    	r2, r3, #0
0x005f09:	adds    	r0, r6, #0
0x005f0b:	adds    	r3, r4, #0
0x005f0d:	bl      	#0x5159
; block 0x5f11
0x005f11:	ldr     	r0, [pc, #0xec]
0x005f13:	add     	r0, sb
0x005f15:	str     	r4, [r0, #4]
0x005f17:	ldr     	r0, [pc, #0xe8]
0x005f19:	add     	r0, sb
0x005f1b:	ldr     	r3, [r0, #8]
0x005f1d:	cmp     	r3, #0
0x005f1f:	beq     	#0x5f3d
; block 0x5f17
0x005f17:	ldr     	r0, [pc, #0xe8]
0x005f19:	add     	r0, sb
0x005f1b:	ldr     	r3, [r0, #8]
0x005f1d:	cmp     	r3, #0
0x005f1f:	beq     	#0x5f3d
; block 0x5f21
0x005f21:	movs    	r1, #0
0x005f23:	movs    	r2, #0
0x005f25:	str     	r2, [sp, #8]
0x005f27:	str     	r1, [sp]
0x005f29:	str     	r1, [sp, #4]
0x005f2b:	movs    	r1, #0x12
0x005f2d:	adds    	r2, r3, #0
0x005f2f:	adds    	r0, r6, #0
0x005f31:	adds    	r3, r4, #0
0x005f33:	bl      	#0x5159
; block 0x5f37
0x005f37:	ldr     	r0, [pc, #0xc8]
0x005f39:	add     	r0, sb
0x005f3b:	str     	r4, [r0, #8]
0x005f3d:	movs    	r1, #0
0x005f3f:	movs    	r2, #0
0x005f41:	str     	r2, [sp, #8]
0x005f43:	str     	r1, [sp]
0x005f45:	str     	r1, [sp, #4]
0x005f47:	movs    	r1, #0x26
0x005f49:	adds    	r2, r7, #0
0x005f4b:	movs    	r3, #0
0x005f4d:	adds    	r0, r6, #0
0x005f4f:	bl      	#0x5159
; block 0x5f3d
0x005f3d:	movs    	r1, #0
0x005f3f:	movs    	r2, #0
0x005f41:	str     	r2, [sp, #8]
0x005f43:	str     	r1, [sp]
0x005f45:	str     	r1, [sp, #4]
0x005f47:	movs    	r1, #0x26
0x005f49:	adds    	r2, r7, #0
0x005f4b:	movs    	r3, #0
0x005f4d:	adds    	r0, r6, #0
0x005f4f:	bl      	#0x5159
; block 0x5f53
0x005f53:	str     	r0, [sp, #0x10]
0x005f55:	cmp     	r0, #0
0x005f57:	ble     	#0x5fe5
; block 0x5f59
0x005f59:	movs    	r1, #0
0x005f5b:	movs    	r2, #0
0x005f5d:	str     	r2, [sp, #8]
0x005f5f:	str     	r1, [sp]
0x005f61:	str     	r1, [sp, #4]
0x005f63:	movs    	r1, #0x27
0x005f65:	adds    	r2, r7, #0
0x005f67:	adds    	r3, r5, #0
0x005f69:	adds    	r0, r6, #0
0x005f6b:	bl      	#0x5159
; block 0x5f6f
0x005f6f:	adds    	r4, r0, #0
0x005f71:	beq     	#0x5fdd
; block 0x5f73
0x005f73:	ldr     	r3, [r4]
0x005f75:	cmp     	r3, #0
0x005f77:	beq     	#0x5f8f
; block 0x5f79
0x005f79:	movs    	r2, #0
0x005f7b:	movs    	r1, #0
0x005f7d:	str     	r2, [sp, #8]
0x005f7f:	adds    	r2, r3, #0
0x005f81:	str     	r1, [sp]
0x005f83:	str     	r1, [sp, #4]
0x005f85:	movs    	r1, #9
0x005f87:	movs    	r3, #0
0x005f89:	adds    	r0, r6, #0
0x005f8b:	bl      	#0x5159
; block 0x5f8f
0x005f8f:	ldr     	r3, [r4, #0xc]
0x005f91:	cmp     	r3, #0
0x005f93:	beq     	#0x5fab
; block 0x5f95
0x005f95:	movs    	r2, #0
0x005f97:	movs    	r1, #0
0x005f99:	str     	r2, [sp, #8]
0x005f9b:	adds    	r2, r3, #0
0x005f9d:	str     	r1, [sp]
0x005f9f:	str     	r1, [sp, #4]
0x005fa1:	movs    	r1, #9
0x005fa3:	movs    	r3, #0
0x005fa5:	adds    	r0, r6, #0
0x005fa7:	bl      	#0x5159
; block 0x5fab
0x005fab:	ldr     	r3, [r4, #0x1c]
0x005fad:	cmp     	r3, #0
0x005faf:	beq     	#0x5fc7
; block 0x5fb1
0x005fb1:	movs    	r2, #0
0x005fb3:	movs    	r1, #0
0x005fb5:	str     	r2, [sp, #8]
0x005fb7:	adds    	r2, r3, #0
0x005fb9:	str     	r1, [sp]
0x005fbb:	str     	r1, [sp, #4]
0x005fbd:	movs    	r1, #9
0x005fbf:	movs    	r3, #0
0x005fc1:	adds    	r0, r6, #0
0x005fc3:	bl      	#0x5159
; block 0x5fc7
0x005fc7:	movs    	r1, #0
0x005fc9:	movs    	r2, #0
0x005fcb:	str     	r2, [sp, #8]
0x005fcd:	str     	r1, [sp]
0x005fcf:	str     	r1, [sp, #4]
0x005fd1:	movs    	r1, #9
0x005fd3:	adds    	r2, r4, #0
0x005fd5:	movs    	r3, #0
0x005fd7:	adds    	r0, r6, #0
0x005fd9:	bl      	#0x5159
; block 0x5fdd
0x005fdd:	ldr     	r0, [sp, #0x10]
0x005fdf:	adds    	r5, #1
0x005fe1:	cmp     	r5, r0
0x005fe3:	blt     	#0x5f59
; block 0x5fe5
0x005fe5:	movs    	r1, #0
0x005fe7:	movs    	r2, #0
0x005fe9:	str     	r2, [sp, #8]
0x005feb:	str     	r1, [sp]
0x005fed:	str     	r1, [sp, #4]
0x005fef:	movs    	r1, #0x28
0x005ff1:	adds    	r2, r7, #0
0x005ff3:	movs    	r3, #0
0x005ff5:	adds    	r0, r6, #0
0x005ff7:	bl      	#0x5159
; block 0x5ffb
0x005ffb:	add     	sp, #0x14
0x005ffd:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_6001 @ 0x6001 offset=0x6000 size=4 blocks=1 cc=1 =====
; block 0x6001
0x006001:	movs    	r4, r1
0x006003:	movs    	r0, r0
0x006005:	push    	{r4, r5, r6, lr}
0x006007:	ldr     	r4, [pc, #0x2c]
0x006009:	movs    	r5, #0
0x00600b:	add     	r4, sb
0x00600d:	ldr     	r6, [r4, #0x44]
0x00600f:	sub     	sp, #0x10
0x006011:	cmp     	r6, #0
0x006013:	beq     	#0x602d

; ===== sub_6005 @ 0x6005 offset=0x6004 size=48 blocks=3 cc=2 =====
; block 0x6005
0x006005:	push    	{r4, r5, r6, lr}
0x006007:	ldr     	r4, [pc, #0x2c]
0x006009:	movs    	r5, #0
0x00600b:	add     	r4, sb
0x00600d:	ldr     	r6, [r4, #0x44]
0x00600f:	sub     	sp, #0x10
0x006011:	cmp     	r6, #0
0x006013:	beq     	#0x602d
; block 0x6015
0x006015:	movs    	r1, #0
0x006017:	movs    	r2, #0
0x006019:	str     	r2, [sp, #8]
0x00601b:	str     	r1, [sp]
0x00601d:	str     	r1, [sp, #4]
0x00601f:	adds    	r3, r5, #0
0x006021:	adds    	r2, r6, #0
0x006023:	movs    	r1, #0x12
0x006025:	movs    	r0, #0xf1
0x006027:	lsls    	r0, r0, #9
0x006029:	bl      	#0x5159
; block 0x602d
0x00602d:	str     	r5, [r4, #0x44]
0x00602f:	str     	r5, [r4, #0x48]
0x006031:	add     	sp, #0x10
0x006033:	pop     	{r4, r5, r6, pc}

; ===== sub_6035 @ 0x6035 offset=0x6034 size=4 blocks=1 cc=1 =====
; block 0x6035
0x006035:	movs    	r4, r1
0x006037:	movs    	r0, r0
0x006039:	push    	{r4, r5, r6, r7, lr}
0x00603b:	sub     	sp, #0xc
0x00603d:	adds    	r7, r1, #0
0x00603f:	movs    	r1, #0
0x006041:	adds    	r6, r0, #0
0x006043:	movs    	r4, #0
0x006045:	movs    	r2, #0
0x006047:	str     	r2, [sp, #8]
0x006049:	adds    	r3, r4, #0
0x00604b:	str     	r1, [sp]
0x00604d:	str     	r1, [sp, #4]
0x00604f:	movs    	r5, #0x11
0x006051:	adds    	r2, r5, #0
0x006053:	movs    	r1, #0x17
0x006055:	movs    	r0, #0xf1
0x006057:	lsls    	r0, r0, #9
0x006059:	bl      	#0x5159

; ===== sub_6039 @ 0x6039 offset=0x6038 size=264 blocks=11 cc=10 =====
; block 0x6039
0x006039:	push    	{r4, r5, r6, r7, lr}
0x00603b:	sub     	sp, #0xc
0x00603d:	adds    	r7, r1, #0
0x00603f:	movs    	r1, #0
0x006041:	adds    	r6, r0, #0
0x006043:	movs    	r4, #0
0x006045:	movs    	r2, #0
0x006047:	str     	r2, [sp, #8]
0x006049:	adds    	r3, r4, #0
0x00604b:	str     	r1, [sp]
0x00604d:	str     	r1, [sp, #4]
0x00604f:	movs    	r5, #0x11
0x006051:	adds    	r2, r5, #0
0x006053:	movs    	r1, #0x17
0x006055:	movs    	r0, #0xf1
0x006057:	lsls    	r0, r0, #9
0x006059:	bl      	#0x5159
; block 0x605d
0x00605d:	movs    	r1, #0
0x00605f:	movs    	r2, #0
0x006061:	str     	r2, [sp, #8]
0x006063:	str     	r1, [sp]
0x006065:	str     	r1, [sp, #4]
0x006067:	adds    	r3, r4, #0
0x006069:	adds    	r2, r5, #0
0x00606b:	movs    	r1, #0x18
0x00606d:	movs    	r0, #0xf1
0x00606f:	lsls    	r0, r0, #9
0x006071:	bl      	#0x5159
; block 0x6075
0x006075:	movs    	r1, #0
0x006077:	movs    	r2, #0
0x006079:	str     	r2, [sp, #8]
0x00607b:	str     	r1, [sp]
0x00607d:	str     	r1, [sp, #4]
0x00607f:	movs    	r1, #0xe1
0x006081:	movs    	r2, #0x18
0x006083:	adds    	r3, r4, #0
0x006085:	movs    	r0, #0xf1
0x006087:	lsls    	r0, r0, #9
0x006089:	bl      	#0x5159
; block 0x608d
0x00608d:	ldr     	r5, [r0, #8]
0x00608f:	movs    	r1, #0
0x006091:	movs    	r2, #0
0x006093:	str     	r2, [sp, #8]
0x006095:	str     	r1, [sp]
0x006097:	str     	r1, [sp, #4]
0x006099:	adds    	r3, r4, #0
0x00609b:	adds    	r2, r5, #0
0x00609d:	movs    	r1, #0x19
0x00609f:	movs    	r0, #0xf1
0x0060a1:	lsls    	r0, r0, #9
0x0060a3:	bl      	#0x5159
; block 0x60a7
0x0060a7:	movs    	r1, #0
0x0060a9:	movs    	r2, #0
0x0060ab:	str     	r2, [sp, #8]
0x0060ad:	str     	r1, [sp]
0x0060af:	str     	r1, [sp, #4]
0x0060b1:	movs    	r1, #0xe1
0x0060b3:	movs    	r2, #0x1d
0x0060b5:	adds    	r3, r4, #0
0x0060b7:	movs    	r0, #0xf1
0x0060b9:	lsls    	r0, r0, #9
0x0060bb:	bl      	#0x5159
; block 0x60bf
0x0060bf:	movs    	r2, #0
0x0060c1:	movs    	r1, #0
0x0060c3:	str     	r2, [sp, #8]
0x0060c5:	adds    	r3, r4, #0
0x0060c7:	adds    	r2, r0, #0
0x0060c9:	str     	r1, [sp]
0x0060cb:	str     	r1, [sp, #4]
0x0060cd:	movs    	r1, #0x19
0x0060cf:	movs    	r0, #0xf1
0x0060d1:	lsls    	r0, r0, #9
0x0060d3:	bl      	#0x5159
; block 0x60d7
0x0060d7:	movs    	r1, #0
0x0060d9:	movs    	r2, #0
0x0060db:	str     	r2, [sp, #8]
0x0060dd:	str     	r1, [sp]
0x0060df:	str     	r1, [sp, #4]
0x0060e1:	adds    	r3, r4, #0
0x0060e3:	adds    	r2, r6, #0
0x0060e5:	movs    	r1, #0x49
0x0060e7:	movs    	r0, #0xf1
0x0060e9:	lsls    	r0, r0, #9
0x0060eb:	bl      	#0x5159
; block 0x60ef
0x0060ef:	movs    	r1, #0
0x0060f1:	movs    	r2, #0
0x0060f3:	str     	r2, [sp, #8]
0x0060f5:	str     	r1, [sp]
0x0060f7:	str     	r1, [sp, #4]
0x0060f9:	adds    	r3, r4, #0
0x0060fb:	adds    	r2, r7, #0
0x0060fd:	movs    	r1, #0x19
0x0060ff:	movs    	r0, #0xf1
0x006101:	lsls    	r0, r0, #9
0x006103:	bl      	#0x5159
; block 0x6107
0x006107:	movs    	r1, #0
0x006109:	ldr     	r0, [pc, #0x34]
0x00610b:	str     	r1, [sp]
0x00610d:	str     	r1, [sp, #4]
0x00610f:	movs    	r2, #0
0x006111:	str     	r2, [sp, #8]
0x006113:	add     	r0, sb
0x006115:	ldr     	r2, [r0, #4]
0x006117:	movs    	r0, #0xf1
0x006119:	movs    	r1, #0x19
0x00611b:	adds    	r3, r4, #0
0x00611d:	lsls    	r0, r0, #9
0x00611f:	bl      	#0x5159
; block 0x6123
0x006123:	movs    	r2, #0
0x006125:	movs    	r1, #0
0x006127:	ldr     	r3, [pc, #0x1c]
0x006129:	str     	r1, [sp]
0x00612b:	str     	r1, [sp, #4]
0x00612d:	str     	r2, [sp, #8]
0x00612f:	add     	r3, pc
0x006131:	movs    	r2, #1
0x006133:	movs    	r1, #0x1b
0x006135:	movs    	r0, #0xf1
0x006137:	lsls    	r0, r0, #9
0x006139:	bl      	#0x5159
; block 0x613d
0x00613d:	add     	sp, #0xc
0x00613f:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_6141 @ 0x6141 offset=0x6140 size=8 blocks=1 cc=1 =====
; block 0x6141
0x006141:	lsls    	r4, r1, #2
0x006143:	movs    	r0, r0
0x006145:	lsrs    	r6, r4, #2
0x006147:	movs    	r0, r0
0x006149:	push    	{r4, r5, r6, r7, lr}
0x00614b:	sub     	sp, #0xc
0x00614d:	adds    	r6, r1, #0
0x00614f:	movs    	r1, #0
0x006151:	adds    	r7, r0, #0
0x006153:	movs    	r5, #0
0x006155:	movs    	r2, #0
0x006157:	str     	r2, [sp, #8]
0x006159:	adds    	r3, r5, #0
0x00615b:	str     	r1, [sp]
0x00615d:	str     	r1, [sp, #4]
0x00615f:	movs    	r4, #0x12
0x006161:	adds    	r2, r4, #0
0x006163:	movs    	r1, #0x17
0x006165:	movs    	r0, #0xf1
0x006167:	lsls    	r0, r0, #9
0x006169:	bl      	#0x5159

; ===== sub_6149 @ 0x6149 offset=0x6148 size=112 blocks=5 cc=4 =====
; block 0x6149
0x006149:	push    	{r4, r5, r6, r7, lr}
0x00614b:	sub     	sp, #0xc
0x00614d:	adds    	r6, r1, #0
0x00614f:	movs    	r1, #0
0x006151:	adds    	r7, r0, #0
0x006153:	movs    	r5, #0
0x006155:	movs    	r2, #0
0x006157:	str     	r2, [sp, #8]
0x006159:	adds    	r3, r5, #0
0x00615b:	str     	r1, [sp]
0x00615d:	str     	r1, [sp, #4]
0x00615f:	movs    	r4, #0x12
0x006161:	adds    	r2, r4, #0
0x006163:	movs    	r1, #0x17
0x006165:	movs    	r0, #0xf1
0x006167:	lsls    	r0, r0, #9
0x006169:	bl      	#0x5159
; block 0x616d
0x00616d:	movs    	r1, #0
0x00616f:	movs    	r2, #0
0x006171:	str     	r2, [sp, #8]
0x006173:	str     	r1, [sp]
0x006175:	str     	r1, [sp, #4]
0x006177:	movs    	r1, #0xe1
0x006179:	movs    	r2, #0x1d
0x00617b:	adds    	r3, r5, #0
0x00617d:	movs    	r0, #0xf1
0x00617f:	lsls    	r0, r0, #9
0x006181:	bl      	#0x5159
; block 0x6185
0x006185:	movs    	r2, #0
0x006187:	str     	r2, [sp, #8]
0x006189:	str     	r0, [sp, #4]
0x00618b:	adds    	r3, r6, #0
0x00618d:	adds    	r2, r4, #0
0x00618f:	movs    	r0, #0xf1
0x006191:	movs    	r1, #0x52
0x006193:	lsls    	r0, r0, #9
0x006195:	str     	r7, [sp]
0x006197:	bl      	#0x5159
; block 0x619b
0x00619b:	movs    	r2, #0
0x00619d:	movs    	r1, #0
0x00619f:	ldr     	r3, [pc, #0x18]
0x0061a1:	str     	r1, [sp]
0x0061a3:	str     	r1, [sp, #4]
0x0061a5:	str     	r2, [sp, #8]
0x0061a7:	add     	r3, pc
0x0061a9:	movs    	r2, #1
0x0061ab:	movs    	r1, #0x1b
0x0061ad:	movs    	r0, #0xf1
0x0061af:	lsls    	r0, r0, #9
0x0061b1:	bl      	#0x5159
; block 0x61b5
0x0061b5:	add     	sp, #0xc
0x0061b7:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_61b9 @ 0x61b9 offset=0x61b8 size=4 blocks=1 cc=1 =====
; block 0x61b9
0x0061b9:	lsls    	r2, r4, #0x1b
0x0061bb:	movs    	r0, r0
0x0061bd:	push    	{r4, r5, lr}
0x0061bf:	sub     	sp, #0xc
0x0061c1:	movs    	r1, #0
0x0061c3:	movs    	r4, #0
0x0061c5:	movs    	r2, #0
0x0061c7:	str     	r2, [sp, #8]
0x0061c9:	adds    	r3, r4, #0
0x0061cb:	str     	r1, [sp]
0x0061cd:	str     	r1, [sp, #4]
0x0061cf:	movs    	r5, #6
0x0061d1:	adds    	r2, r5, #0
0x0061d3:	movs    	r1, #0x17
0x0061d5:	movs    	r0, #0xf1
0x0061d7:	lsls    	r0, r0, #9
0x0061d9:	bl      	#0x5159

; ===== sub_61bd @ 0x61bd offset=0x61bc size=208 blocks=9 cc=8 =====
; block 0x61bd
0x0061bd:	push    	{r4, r5, lr}
0x0061bf:	sub     	sp, #0xc
0x0061c1:	movs    	r1, #0
0x0061c3:	movs    	r4, #0
0x0061c5:	movs    	r2, #0
0x0061c7:	str     	r2, [sp, #8]
0x0061c9:	adds    	r3, r4, #0
0x0061cb:	str     	r1, [sp]
0x0061cd:	str     	r1, [sp, #4]
0x0061cf:	movs    	r5, #6
0x0061d1:	adds    	r2, r5, #0
0x0061d3:	movs    	r1, #0x17
0x0061d5:	movs    	r0, #0xf1
0x0061d7:	lsls    	r0, r0, #9
0x0061d9:	bl      	#0x5159
; block 0x61dd
0x0061dd:	movs    	r1, #0
0x0061df:	movs    	r2, #0
0x0061e1:	str     	r2, [sp, #8]
0x0061e3:	str     	r1, [sp]
0x0061e5:	str     	r1, [sp, #4]
0x0061e7:	adds    	r3, r4, #0
0x0061e9:	adds    	r2, r5, #0
0x0061eb:	movs    	r1, #0x18
0x0061ed:	movs    	r0, #0xf1
0x0061ef:	lsls    	r0, r0, #9
0x0061f1:	bl      	#0x5159
; block 0x61f5
0x0061f5:	movs    	r1, #0
0x0061f7:	movs    	r2, #0
0x0061f9:	str     	r2, [sp, #8]
0x0061fb:	str     	r1, [sp]
0x0061fd:	str     	r1, [sp, #4]
0x0061ff:	movs    	r1, #0xe1
0x006201:	movs    	r2, #0x19
0x006203:	adds    	r3, r4, #0
0x006205:	movs    	r0, #0xf1
0x006207:	lsls    	r0, r0, #9
0x006209:	bl      	#0x5159
; block 0x620d
0x00620d:	movs    	r2, #0
0x00620f:	movs    	r1, #0
0x006211:	str     	r2, [sp, #8]
0x006213:	adds    	r3, r4, #0
0x006215:	adds    	r2, r0, #0
0x006217:	str     	r1, [sp]
0x006219:	str     	r1, [sp, #4]
0x00621b:	movs    	r1, #0x19
0x00621d:	movs    	r0, #0xf1
0x00621f:	lsls    	r0, r0, #9
0x006221:	bl      	#0x5159
; block 0x6225
0x006225:	movs    	r1, #0
0x006227:	movs    	r2, #0
0x006229:	str     	r2, [sp, #8]
0x00622b:	str     	r1, [sp]
0x00622d:	str     	r1, [sp, #4]
0x00622f:	movs    	r1, #0x1a
0x006231:	movs    	r2, #1
0x006233:	adds    	r3, r4, #0
0x006235:	movs    	r0, #0xf1
0x006237:	lsls    	r0, r0, #9
0x006239:	bl      	#0x5159
; block 0x623d
0x00623d:	movs    	r1, #0
0x00623f:	movs    	r2, #0
0x006241:	str     	r2, [sp, #8]
0x006243:	str     	r1, [sp]
0x006245:	str     	r1, [sp, #4]
0x006247:	movs    	r1, #0xe1
0x006249:	movs    	r2, #0x18
0x00624b:	adds    	r3, r4, #0
0x00624d:	movs    	r0, #0xf1
0x00624f:	lsls    	r0, r0, #9
0x006251:	bl      	#0x5159
; block 0x6255
0x006255:	ldr     	r5, [r0, #8]
0x006257:	movs    	r1, #0
0x006259:	movs    	r2, #0
0x00625b:	str     	r2, [sp, #8]
0x00625d:	str     	r1, [sp]
0x00625f:	str     	r1, [sp, #4]
0x006261:	adds    	r3, r4, #0
0x006263:	adds    	r2, r5, #0
0x006265:	movs    	r1, #0x19
0x006267:	movs    	r0, #0xf1
0x006269:	lsls    	r0, r0, #9
0x00626b:	bl      	#0x5159
; block 0x626f
0x00626f:	movs    	r2, #0
0x006271:	movs    	r1, #0
0x006273:	ldr     	r3, [pc, #0x18]
0x006275:	str     	r1, [sp]
0x006277:	str     	r1, [sp, #4]
0x006279:	str     	r2, [sp, #8]
0x00627b:	add     	r3, pc
0x00627d:	movs    	r2, #1
0x00627f:	movs    	r1, #0x1b
0x006281:	movs    	r0, #0xf1
0x006283:	lsls    	r0, r0, #9
0x006285:	bl      	#0x5159
; block 0x6289
0x006289:	add     	sp, #0xc
0x00628b:	pop     	{r4, r5, pc}

; ===== sub_628d @ 0x628d offset=0x628c size=4 blocks=1 cc=1 =====
; block 0x628d
0x00628d:	lsrs    	r6, r1, #6
0x00628f:	movs    	r0, r0
0x006291:	push    	{r4, r5, lr}
0x006293:	sub     	sp, #0xc
0x006295:	movs    	r1, #0
0x006297:	movs    	r4, #0
0x006299:	movs    	r2, #0
0x00629b:	str     	r2, [sp, #8]
0x00629d:	adds    	r3, r4, #0
0x00629f:	str     	r1, [sp]
0x0062a1:	str     	r1, [sp, #4]
0x0062a3:	movs    	r5, #0x10
0x0062a5:	adds    	r2, r5, #0
0x0062a7:	movs    	r1, #0x17
0x0062a9:	movs    	r0, #0xf1
0x0062ab:	lsls    	r0, r0, #9
0x0062ad:	bl      	#0x5159

; ===== sub_6291 @ 0x6291 offset=0x6290 size=184 blocks=8 cc=7 =====
; block 0x6291
0x006291:	push    	{r4, r5, lr}
0x006293:	sub     	sp, #0xc
0x006295:	movs    	r1, #0
0x006297:	movs    	r4, #0
0x006299:	movs    	r2, #0
0x00629b:	str     	r2, [sp, #8]
0x00629d:	adds    	r3, r4, #0
0x00629f:	str     	r1, [sp]
0x0062a1:	str     	r1, [sp, #4]
0x0062a3:	movs    	r5, #0x10
0x0062a5:	adds    	r2, r5, #0
0x0062a7:	movs    	r1, #0x17
0x0062a9:	movs    	r0, #0xf1
0x0062ab:	lsls    	r0, r0, #9
0x0062ad:	bl      	#0x5159
; block 0x62b1
0x0062b1:	movs    	r1, #0
0x0062b3:	movs    	r2, #0
0x0062b5:	str     	r2, [sp, #8]
0x0062b7:	str     	r1, [sp]
0x0062b9:	str     	r1, [sp, #4]
0x0062bb:	adds    	r3, r4, #0
0x0062bd:	adds    	r2, r5, #0
0x0062bf:	movs    	r1, #0x18
0x0062c1:	movs    	r0, #0xf1
0x0062c3:	lsls    	r0, r0, #9
0x0062c5:	bl      	#0x5159
; block 0x62c9
0x0062c9:	movs    	r1, #0
0x0062cb:	movs    	r2, #0
0x0062cd:	str     	r2, [sp, #8]
0x0062cf:	str     	r1, [sp]
0x0062d1:	str     	r1, [sp, #4]
0x0062d3:	movs    	r1, #0xe1
0x0062d5:	movs    	r2, #0x18
0x0062d7:	adds    	r3, r4, #0
0x0062d9:	movs    	r0, #0xf1
0x0062db:	lsls    	r0, r0, #9
0x0062dd:	bl      	#0x5159
; block 0x62e1
0x0062e1:	ldr     	r5, [r0, #8]
0x0062e3:	movs    	r1, #0
0x0062e5:	movs    	r2, #0
0x0062e7:	str     	r2, [sp, #8]
0x0062e9:	str     	r1, [sp]
0x0062eb:	str     	r1, [sp, #4]
0x0062ed:	adds    	r3, r4, #0
0x0062ef:	adds    	r2, r5, #0
0x0062f1:	movs    	r1, #0x19
0x0062f3:	movs    	r0, #0xf1
0x0062f5:	lsls    	r0, r0, #9
0x0062f7:	bl      	#0x5159
; block 0x62fb
0x0062fb:	movs    	r1, #0
0x0062fd:	movs    	r2, #0
0x0062ff:	str     	r2, [sp, #8]
0x006301:	str     	r1, [sp]
0x006303:	str     	r1, [sp, #4]
0x006305:	movs    	r1, #0xe1
0x006307:	movs    	r2, #0x1d
0x006309:	adds    	r3, r4, #0
0x00630b:	movs    	r0, #0xf1
0x00630d:	lsls    	r0, r0, #9
0x00630f:	bl      	#0x5159
; block 0x6313
0x006313:	movs    	r2, #0
0x006315:	movs    	r1, #0
0x006317:	str     	r2, [sp, #8]
0x006319:	adds    	r3, r4, #0
0x00631b:	adds    	r2, r0, #0
0x00631d:	str     	r1, [sp]
0x00631f:	str     	r1, [sp, #4]
0x006321:	movs    	r1, #0x19
0x006323:	movs    	r0, #0xf1
0x006325:	lsls    	r0, r0, #9
0x006327:	bl      	#0x5159
; block 0x632b
0x00632b:	movs    	r2, #0
0x00632d:	movs    	r1, #0
0x00632f:	ldr     	r3, [pc, #0x18]
0x006331:	str     	r1, [sp]
0x006333:	str     	r1, [sp, #4]
0x006335:	str     	r2, [sp, #8]
0x006337:	add     	r3, pc
0x006339:	movs    	r2, #1
0x00633b:	movs    	r1, #0x1b
0x00633d:	movs    	r0, #0xf1
0x00633f:	lsls    	r0, r0, #9
0x006341:	bl      	#0x5159
; block 0x6345
0x006345:	add     	sp, #0xc
0x006347:	pop     	{r4, r5, pc}

; ===== sub_6349 @ 0x6349 offset=0x6348 size=4 blocks=1 cc=1 =====
; block 0x6349
0x006349:	lsls    	r6, r2, #0x13
0x00634b:	movs    	r0, r0
0x00634d:	push    	{r4, r5, r6, r7, lr}
0x00634f:	sub     	sp, #0xc
0x006351:	movs    	r1, #0
0x006353:	movs    	r2, #0
0x006355:	str     	r2, [sp, #8]
0x006357:	str     	r1, [sp]
0x006359:	str     	r1, [sp, #4]
0x00635b:	movs    	r5, #0xf1
0x00635d:	lsls    	r5, r5, #9
0x00635f:	movs    	r1, #0x14
0x006361:	movs    	r2, #0xd
0x006363:	movs    	r4, #0xe
0x006365:	movs    	r3, #1
0x006367:	adds    	r0, r5, #0
0x006369:	bl      	#0x5159

; ===== sub_634d @ 0x634d offset=0x634c size=190 blocks=10 cc=8 =====
; block 0x634d
0x00634d:	push    	{r4, r5, r6, r7, lr}
0x00634f:	sub     	sp, #0xc
0x006351:	movs    	r1, #0
0x006353:	movs    	r2, #0
0x006355:	str     	r2, [sp, #8]
0x006357:	str     	r1, [sp]
0x006359:	str     	r1, [sp, #4]
0x00635b:	movs    	r5, #0xf1
0x00635d:	lsls    	r5, r5, #9
0x00635f:	movs    	r1, #0x14
0x006361:	movs    	r2, #0xd
0x006363:	movs    	r4, #0xe
0x006365:	movs    	r3, #1
0x006367:	adds    	r0, r5, #0
0x006369:	bl      	#0x5159
; block 0x636d
0x00636d:	ldr     	r6, [pc, #0x9c]
0x00636f:	movs    	r7, #0
0x006371:	add     	r6, sb
0x006373:	ldr     	r0, [r6, #0xc]
0x006375:	cmp     	r0, #0
0x006377:	bne     	#0x638f
; block 0x6379
0x006379:	movs    	r1, #0
0x00637b:	str     	r1, [sp]
0x00637d:	str     	r1, [sp, #4]
0x00637f:	movs    	r2, #0
0x006381:	movs    	r1, #0x13
0x006383:	adds    	r3, r7, #0
0x006385:	adds    	r0, r5, #0
0x006387:	str     	r2, [sp, #8]
0x006389:	bl      	#0x5159
; block 0x638d
0x00638d:	str     	r0, [r6, #0xc]
0x00638f:	movs    	r1, #0
0x006391:	movs    	r2, #0
0x006393:	str     	r2, [sp, #8]
0x006395:	str     	r1, [sp]
0x006397:	str     	r1, [sp, #4]
0x006399:	movs    	r1, #0x17
0x00639b:	adds    	r2, r4, #0
0x00639d:	adds    	r3, r7, #0
0x00639f:	adds    	r0, r5, #0
0x0063a1:	bl      	#0x5159
; block 0x638f
0x00638f:	movs    	r1, #0
0x006391:	movs    	r2, #0
0x006393:	str     	r2, [sp, #8]
0x006395:	str     	r1, [sp]
0x006397:	str     	r1, [sp, #4]
0x006399:	movs    	r1, #0x17
0x00639b:	adds    	r2, r4, #0
0x00639d:	adds    	r3, r7, #0
0x00639f:	adds    	r0, r5, #0
0x0063a1:	bl      	#0x5159
; block 0x63a5
0x0063a5:	movs    	r1, #0
0x0063a7:	movs    	r2, #0
0x0063a9:	str     	r2, [sp, #8]
0x0063ab:	str     	r1, [sp]
0x0063ad:	str     	r1, [sp, #4]
0x0063af:	adds    	r3, r7, #0
0x0063b1:	adds    	r2, r4, #0
0x0063b3:	movs    	r1, #0x18
0x0063b5:	movs    	r0, #0xf1
0x0063b7:	lsls    	r0, r0, #9
0x0063b9:	bl      	#0x5159
; block 0x63bd
0x0063bd:	movs    	r1, #0
0x0063bf:	movs    	r2, #0
0x0063c1:	str     	r2, [sp, #8]
0x0063c3:	str     	r1, [sp]
0x0063c5:	str     	r1, [sp, #4]
0x0063c7:	movs    	r1, #0xe1
0x0063c9:	movs    	r2, #0x19
0x0063cb:	adds    	r3, r7, #0
0x0063cd:	movs    	r0, #0xf1
0x0063cf:	lsls    	r0, r0, #9
0x0063d1:	bl      	#0x5159
; block 0x63d5
0x0063d5:	movs    	r2, #0
0x0063d7:	movs    	r1, #0
0x0063d9:	str     	r2, [sp, #8]
0x0063db:	adds    	r3, r7, #0
0x0063dd:	adds    	r2, r0, #0
0x0063df:	str     	r1, [sp]
0x0063e1:	str     	r1, [sp, #4]
0x0063e3:	movs    	r1, #0x19
0x0063e5:	movs    	r0, #0xf1
0x0063e7:	lsls    	r0, r0, #9
0x0063e9:	bl      	#0x5159
; block 0x63ed
0x0063ed:	movs    	r2, #0
0x0063ef:	movs    	r1, #0
0x0063f1:	ldr     	r3, [pc, #0x1c]
0x0063f3:	str     	r1, [sp]
0x0063f5:	str     	r1, [sp, #4]
0x0063f7:	str     	r2, [sp, #8]
0x0063f9:	add     	r3, pc
0x0063fb:	movs    	r2, #1
0x0063fd:	movs    	r1, #0x1b
0x0063ff:	movs    	r0, #0xf1
0x006401:	lsls    	r0, r0, #9
0x006403:	bl      	#0x5159
; block 0x6407
0x006407:	add     	sp, #0xc
0x006409:	pop     	{r4, r5, r6, r7, pc}

; ===== sub_640d @ 0x640d offset=0x640c size=8 blocks=1 cc=1 =====
; block 0x640d
0x00640d:	movs    	r4, r1
0x00640f:	movs    	r0, r0
0x006411:	lsls    	r4, r4, #0x10
0x006413:	movs    	r0, r0
0x006415:	push    	{r4, r5, r6, r7, lr}
0x006417:	sub     	sp, #0xc
0x006419:	movs    	r1, #0
0x00641b:	str     	r1, [sp]
0x00641d:	str     	r1, [sp, #4]
0x00641f:	ldr     	r6, [pc, #0x160]
0x006421:	movs    	r2, #0
0x006423:	movs    	r5, #0xf1
0x006425:	movs    	r4, #0
0x006427:	adds    	r3, r4, #0
0x006429:	lsls    	r5, r5, #9
0x00642b:	str     	r2, [sp, #8]
0x00642d:	movs    	r1, #0x26
0x00642f:	adds    	r7, r0, #0
0x006431:	add     	r6, sb
0x006433:	ldr     	r2, [r6, #0xc]
0x006435:	adds    	r0, r5, #0
0x006437:	bl      	#0x5159

; ===== sub_6415 @ 0x6415 offset=0x6414 size=362 blocks=30 cc=23 =====
; block 0x6415
0x006415:	push    	{r4, r5, r6, r7, lr}
0x006417:	sub     	sp, #0xc
0x006419:	movs    	r1, #0
0x00641b:	str     	r1, [sp]
0x00641d:	str     	r1, [sp, #4]
0x00641f:	ldr     	r6, [pc, #0x160]
0x006421:	movs    	r2, #0
0x006423:	movs    	r5, #0xf1
0x006425:	movs    	r4, #0
0x006427:	adds    	r3, r4, #0
0x006429:	lsls    	r5, r5, #9
0x00642b:	str     	r2, [sp, #8]
0x00642d:	movs    	r1, #0x26
0x00642f:	adds    	r7, r0, #0
0x006431:	add     	r6, sb
0x006433:	ldr     	r2, [r6, #0xc]
0x006435:	adds    	r0, r5, #0
0x006437:	bl      	#0x5159
; block 0x643b
0x00643b:	adds    	r3, r0, #0
0x00643d:	ldr     	r0, [pc, #0x140]
0x00643f:	add     	r0, sb
0x006441:	adds    	r0, #0x7c
0x006443:	cmp     	r7, #0xd
0x006445:	beq     	#0x64ef
; block 0x6447
0x006447:	bgt     	#0x6473
; block 0x6449
0x006449:	cmp     	r7, #2
0x00644b:	beq     	#0x6459
; block 0x644d
0x00644d:	cmp     	r7, #5
0x00644f:	beq     	#0x647f
; block 0x6451
0x006451:	cmp     	r7, #8
0x006453:	beq     	#0x64ef
; block 0x6455
0x006455:	cmp     	r7, #0xc
0x006457:	bne     	#0x646f
; block 0x6459
0x006459:	movs    	r2, #0
0x00645b:	movs    	r1, #0
0x00645d:	str     	r1, [sp, #4]
0x00645f:	str     	r2, [sp, #8]
0x006461:	str     	r0, [sp]
0x006463:	adds    	r0, r5, #0
0x006465:	adds    	r2, r3, #0
0x006467:	movs    	r1, #0x29
0x006469:	adds    	r3, r4, #0
0x00646b:	bl      	#0x5159
; block 0x646f
0x00646f:	add     	sp, #0xc
0x006471:	pop     	{r4, r5, r6, r7, pc}
; block 0x6473
0x006473:	cmp     	r7, #0x11
0x006475:	beq     	#0x647f
; block 0x6477
0x006477:	cmp     	r7, #0x12
0x006479:	beq     	#0x64cf
; block 0x647b
0x00647b:	cmp     	r7, #0x14
0x00647d:	bne     	#0x646f
; block 0x647f
0x00647f:	movs    	r1, #0
0x006481:	str     	r1, [sp]
0x006483:	str     	r1, [sp, #4]
0x006485:	movs    	r2, #0
0x006487:	ldr     	r6, [pc, #0xf8]
0x006489:	str     	r2, [sp, #8]
0x00648b:	add     	r6, sb
0x00648d:	ldr     	r2, [r6, #0xc]
0x00648f:	movs    	r1, #0x27
0x006491:	adds    	r0, r5, #0
0x006493:	ldr     	r3, [r6, #0x7c]
0x006495:	bl      	#0x5159
; block 0x6499
0x006499:	ldrb    	r1, [r0, #8]
0x00649b:	cmp     	r1, #0
0x00649d:	bne     	#0x6507
; block 0x649f
0x00649f:	movs    	r2, #0
0x0064a1:	str     	r2, [sp, #8]
0x0064a3:	str     	r1, [sp]
0x0064a5:	str     	r1, [sp, #4]
0x0064a7:	movs    	r1, #0x14
0x0064a9:	movs    	r2, #0x1f
0x0064ab:	adds    	r3, r4, #0
0x0064ad:	adds    	r0, r5, #0
0x0064af:	bl      	#0x5159
; block 0x64b3
0x0064b3:	movs    	r2, #0
0x0064b5:	movs    	r1, #0
0x0064b7:	str     	r2, [sp, #8]
0x0064b9:	ldr     	r2, [pc, #0xc8]
0x0064bb:	str     	r1, [sp]
0x0064bd:	str     	r1, [sp, #4]
0x0064bf:	adds    	r3, r4, #0
0x0064c1:	add     	r2, pc
0x0064c3:	movs    	r1, #0x33
0x0064c5:	movs    	r0, #0xf1
0x0064c7:	lsls    	r0, r0, #9
0x0064c9:	bl      	#0x5159
; block 0x64cd
0x0064cd:	b       	#0x646f
; block 0x64cf
0x0064cf:	ldr     	r0, [r6, #0xc]
0x0064d1:	bl      	#0x5ebd
; block 0x64d5
0x0064d5:	movs    	r2, #0
0x0064d7:	movs    	r1, #0
0x0064d9:	str     	r1, [sp, #4]
0x0064db:	str     	r2, [sp, #8]
0x0064dd:	movs    	r0, #2
0x0064df:	str     	r0, [sp]
0x0064e1:	movs    	r2, #0x17
0x0064e3:	movs    	r1, #0x14
0x0064e5:	movs    	r3, #1
0x0064e7:	adds    	r0, r5, #0
0x0064e9:	bl      	#0x5159
; block 0x64ed
0x0064ed:	b       	#0x646f
; block 0x64ef
0x0064ef:	movs    	r2, #0
0x0064f1:	movs    	r1, #1
0x0064f3:	str     	r1, [sp, #4]
0x0064f5:	str     	r2, [sp, #8]
0x0064f7:	str     	r0, [sp]
0x0064f9:	adds    	r0, r5, #0
0x0064fb:	adds    	r2, r3, #0
0x0064fd:	movs    	r1, #0x29
0x0064ff:	adds    	r3, r4, #0
0x006501:	bl      	#0x5159
; block 0x6505
0x006505:	b       	#0x646f
; block 0x6507
0x006507:	cmp     	r1, #4
0x006509:	bne     	#0x653d
; block 0x650b
0x00650b:	movs    	r1, #0
0x00650d:	movs    	r2, #0
0x00650f:	str     	r2, [sp, #8]
0x006511:	str     	r1, [sp]
0x006513:	str     	r1, [sp, #4]
0x006515:	movs    	r1, #0x14
0x006517:	movs    	r2, #0x1f
0x006519:	adds    	r3, r4, #0
0x00651b:	adds    	r0, r5, #0
0x00651d:	bl      	#0x5159
; block 0x6521
0x006521:	movs    	r2, #0
0x006523:	movs    	r1, #0
0x006525:	str     	r2, [sp, #8]
0x006527:	ldr     	r2, [pc, #0x60]
0x006529:	str     	r1, [sp]
0x00652b:	str     	r1, [sp, #4]
0x00652d:	adds    	r3, r4, #0
0x00652f:	add     	r2, pc
0x006531:	movs    	r1, #0x33
0x006533:	movs    	r0, #0xf1
0x006535:	lsls    	r0, r0, #9
0x006537:	bl      	#0x5159
; block 0x653b
0x00653b:	b       	#0x646f
; block 0x653d
0x00653d:	movs    	r3, #9
0x00653f:	ldrsb   	r7, [r0, r3]
0x006541:	ldr     	r6, [r0, #4]
0x006543:	ldr     	r0, [pc, #0x3c]
0x006545:	add     	r0, sb
0x006547:	ldr     	r0, [r0, #0xc]
0x006549:	bl      	#0x5ebd
; block 0x654d
0x00654d:	movs    	r1, #0
0x00654f:	movs    	r2, #0
0x006551:	str     	r2, [sp, #8]
0x006553:	str     	r1, [sp]
0x006555:	str     	r1, [sp, #4]
0x006557:	movs    	r1, #0x4f
0x006559:	adds    	r2, r6, #0
0x00655b:	adds    	r3, r4, #0
0x00655d:	adds    	r0, r5, #0
0x00655f:	bl      	#0x5159
; block 0x6563
0x006563:	movs    	r2, #0
0x006565:	movs    	r1, #0
0x006567:	ldr     	r3, [pc, #0x24]
0x006569:	str     	r1, [sp]
0x00656b:	str     	r1, [sp, #4]
0x00656d:	str     	r2, [sp, #8]
0x00656f:	add     	r3, pc
0x006571:	adds    	r2, r7, #0
0x006573:	movs    	r1, #0x4e
0x006575:	movs    	r0, #0xf1
0x006577:	lsls    	r0, r0, #9
0x006579:	bl      	#0x5159
; block 0x657d
0x00657d:	b       	#0x646f

; ===== sub_6591 @ 0x6591 offset=0x6590 size=258 blocks=18 cc=14 =====
; block 0x6591
0x006591:	push    	{r4, r5, r6, r7, lr}
0x006593:	ldr     	r5, [pc, #0x100]
0x006595:	movs    	r7, #0
0x006597:	add     	r5, sb
0x006599:	ldr     	r4, [r5, #0xc]
0x00659b:	sub     	sp, #0x1c
0x00659d:	cmp     	r4, #0
0x00659f:	bne     	#0x65a7
; block 0x65a1
0x0065a1:	movs    	r0, #0
0x0065a3:	add     	sp, #0x1c
0x0065a5:	pop     	{r4, r5, r6, r7, pc}
; block 0x65a3
0x0065a3:	add     	sp, #0x1c
0x0065a5:	pop     	{r4, r5, r6, r7, pc}
; block 0x65a7
0x0065a7:	movs    	r2, #0
0x0065a9:	str     	r2, [sp, #8]
0x0065ab:	movs    	r1, #0
0x0065ad:	adds    	r2, r4, #0
0x0065af:	movs    	r4, #0xf1
0x0065b1:	str     	r1, [sp]
0x0065b3:	str     	r1, [sp, #4]
0x0065b5:	movs    	r6, #0
0x0065b7:	adds    	r3, r6, #0
0x0065b9:	movs    	r1, #0x26
0x0065bb:	lsls    	r4, r4, #9
0x0065bd:	adds    	r0, r4, #0
0x0065bf:	bl      	#0x5159
; block 0x65c3
0x0065c3:	movs    	r1, #0
0x0065c5:	str     	r1, [sp]
0x0065c7:	str     	r1, [sp, #4]
0x0065c9:	movs    	r2, #0
0x0065cb:	movs    	r1, #0x13
0x0065cd:	str     	r0, [sp, #0x18]
0x0065cf:	adds    	r3, r6, #0
0x0065d1:	adds    	r0, r4, #0
0x0065d3:	str     	r2, [sp, #8]
0x0065d5:	bl      	#0x5159
; block 0x65d9
0x0065d9:	adds    	r5, r0, #0
0x0065db:	ldr     	r0, [sp, #0x18]
0x0065dd:	cmp     	r0, #0
0x0065df:	ble     	#0x668f
; block 0x65e1
0x0065e1:	movs    	r1, #0
0x0065e3:	ldr     	r0, [pc, #0xb0]
0x0065e5:	str     	r1, [sp]
0x0065e7:	str     	r1, [sp, #4]
0x0065e9:	movs    	r2, #0
0x0065eb:	str     	r2, [sp, #8]
0x0065ed:	add     	r0, sb
0x0065ef:	ldr     	r2, [r0, #0xc]
0x0065f1:	movs    	r0, #0xf1
0x0065f3:	movs    	r1, #0x27
0x0065f5:	adds    	r3, r7, #0
0x0065f7:	lsls    	r0, r0, #9
0x0065f9:	bl      	#0x5159
; block 0x65fd
0x0065fd:	movs    	r1, #0
0x0065ff:	adds    	r6, r0, #0
0x006601:	movs    	r2, #0
0x006603:	str     	r2, [sp, #8]
0x006605:	str     	r1, [sp]
0x006607:	str     	r1, [sp, #4]
0x006609:	movs    	r1, #0x26
0x00660b:	adds    	r2, r5, #0
0x00660d:	movs    	r0, #0xf1
0x00660f:	movs    	r4, #0
0x006611:	movs    	r3, #0
0x006613:	lsls    	r0, r0, #9
0x006615:	bl      	#0x5159
; block 0x6619
0x006619:	str     	r0, [sp, #0x14]
0x00661b:	movs    	r0, #0
0x00661d:	str     	r0, [sp, #0x10]
0x00661f:	ldr     	r0, [sp, #0x14]
0x006621:	cmp     	r0, #0
0x006623:	ble     	#0x666f
; block 0x6625
0x006625:	movs    	r1, #0
0x006627:	movs    	r2, #0
0x006629:	str     	r2, [sp, #8]
0x00662b:	str     	r1, [sp]
0x00662d:	str     	r1, [sp, #4]
0x00662f:	adds    	r3, r4, #0
0x006631:	adds    	r2, r5, #0
0x006633:	movs    	r1, #0x27
0x006635:	movs    	r0, #0xf1
0x006637:	lsls    	r0, r0, #9
0x006639:	bl      	#0x5159
; block 0x663d
0x00663d:	movs    	r3, #9
0x00663f:	ldrsb   	r1, [r6, r3]
0x006641:	ldrsb   	r0, [r0, r3]
0x006643:	cmp     	r1, r0
0x006645:	bge     	#0x6661
; block 0x6647
0x006647:	movs    	r2, #0
0x006649:	movs    	r1, #0
0x00664b:	str     	r1, [sp, #4]
0x00664d:	str     	r2, [sp, #8]
0x00664f:	adds    	r3, r6, #0
0x006651:	adds    	r2, r5, #0
0x006653:	movs    	r1, #0xf7
0x006655:	movs    	r0, #0xf1
0x006657:	lsls    	r0, r0, #9
0x006659:	str     	r4, [sp]
0x00665b:	bl      	#0x5159
; block 0x665f
0x00665f:	b       	#0x6687
; block 0x6661
0x006661:	ldr     	r0, [sp, #0x14]
0x006663:	adds    	r4, #1
0x006665:	cmp     	r4, r0
0x006667:	blt     	#0x6625
; block 0x6669
0x006669:	ldr     	r0, [sp, #0x10]
0x00666b:	cmp     	r0, #0
0x00666d:	bne     	#0x6687
; block 0x666f
0x00666f:	movs    	r1, #0
0x006671:	movs    	r2, #0
0x006673:	str     	r2, [sp, #8]
0x006675:	str     	r1, [sp]
0x006677:	str     	r1, [sp, #4]
0x006679:	adds    	r3, r6, #0
0x00667b:	adds    	r2, r5, #0
0x00667d:	movs    	r1, #0x36
0x00667f:	movs    	r0, #0xf1
0x006681:	lsls    	r0, r0, #9
0x006683:	bl      	#0x5159
; block 0x6687
0x006687:	ldr     	r0, [sp, #0x18]
0x006689:	adds    	r7, #1
0x00668b:	cmp     	r7, r0
0x00668d:	blt     	#0x65e1
; block 0x668f
0x00668f:	adds    	r0, r5, #0
0x006691:	b       	#0x65a3

; ===== sub_6695 @ 0x6695 offset=0x6694 size=4 blocks=1 cc=1 =====
; block 0x6695
0x006695:	movs    	r4, r1
0x006697:	movs    	r0, r0
0x006699:	ldr     	r0, [pc, #0x134]
0x00669b:	push    	{r4, lr}
0x00669d:	add     	r0, sb
0x00669f:	ldr     	r0, [r0]
0x0066a1:	sub     	sp, #0x10
0x0066a3:	cmp     	r0, #0xb
0x0066a5:	bhs     	#0x66d5

; ===== sub_6699 @ 0x6699 offset=0x6698 size=296 blocks=20 cc=16 =====
; block 0x6699
0x006699:	ldr     	r0, [pc, #0x134]
0x00669b:	push    	{r4, lr}
0x00669d:	add     	r0, sb
0x00669f:	ldr     	r0, [r0]
0x0066a1:	sub     	sp, #0x10
0x0066a3:	cmp     	r0, #0xb
0x0066a5:	bhs     	#0x66d5
; block 0x66a7
0x0066a7:	adr     	r3, #8
0x0066a9:	ldrb    	r3, [r3, r0]
0x0066ab:	lsls    	r3, r3, #1
0x0066ad:	add     	pc, r3
; block 0x66bd
0x0066bd:	ldr     	r1, [pc, #0x114]
0x0066bf:	add     	r1, sb
0x0066c1:	ldr     	r0, [r1, #0x68]
0x0066c3:	adds    	r0, #1
0x0066c5:	str     	r0, [r1, #0x68]
0x0066c7:	cmp     	r0, #3
0x0066c9:	blt     	#0x66d5
; block 0x66cb
0x0066cb:	movs    	r0, #0
0x0066cd:	str     	r0, [r1, #0x68]
0x0066cf:	ldr     	r1, [pc, #0x100]
0x0066d1:	add     	r1, sb
0x0066d3:	str     	r0, [r1]
0x0066d5:	add     	sp, #0x10
0x0066d7:	pop     	{r4, pc}
; block 0x66d5
0x0066d5:	add     	sp, #0x10
0x0066d7:	pop     	{r4, pc}
; block 0x66d9
0x0066d9:	ldr     	r1, [pc, #0xf8]
0x0066db:	add     	r1, sb
0x0066dd:	ldr     	r0, [r1, #0x68]
0x0066df:	adds    	r0, #1
0x0066e1:	str     	r0, [r1, #0x68]
0x0066e3:	cmp     	r0, #3
0x0066e5:	blt     	#0x66d5
; block 0x66e7
0x0066e7:	movs    	r0, #0
0x0066e9:	str     	r0, [r1, #0x68]
0x0066eb:	bl      	#0x5a89
; block 0x66ef
0x0066ef:	bl      	#0x61bd
; block 0x66f3
0x0066f3:	b       	#0x66d5
; block 0x66f5
0x0066f5:	ldr     	r4, [pc, #0xdc]
0x0066f7:	movs    	r1, #0
0x0066f9:	add     	r4, sb
0x0066fb:	ldr     	r0, [r4, #0x60]
0x0066fd:	movs    	r2, #0
0x0066ff:	adds    	r0, #0x11
0x006701:	str     	r0, [r4, #0x60]
0x006703:	str     	r1, [sp]
0x006705:	str     	r1, [sp, #4]
0x006707:	movs    	r1, #0x1c
0x006709:	movs    	r0, #0xf1
0x00670b:	movs    	r3, #0
0x00670d:	lsls    	r0, r0, #9
0x00670f:	str     	r2, [sp, #8]
0x006711:	bl      	#0x5159
; block 0x6715
0x006715:	ldr     	r1, [r4, #0x60]
0x006717:	cmp     	r0, r1
0x006719:	bgt     	#0x66d5
; block 0x671b
0x00671b:	ldr     	r1, [pc, #0xb4]
0x00671d:	movs    	r0, #1
0x00671f:	add     	r1, sb
0x006721:	str     	r0, [r1]
0x006723:	b       	#0x66d5
; block 0x6725
0x006725:	ldr     	r4, [pc, #0xac]
0x006727:	movs    	r3, #8
0x006729:	add     	r4, sb
0x00672b:	ldr     	r0, [r4, #0x64]
0x00672d:	subs    	r0, #0x11
0x00672f:	str     	r0, [r4, #0x64]
0x006731:	ldr     	r1, [r4, #0x5c]
0x006733:	ldrsh   	r1, [r1, r3]
0x006735:	rsbs    	r1, r1, #0
0x006737:	cmp     	r1, r0
0x006739:	blt     	#0x66d5
; block 0x673b
0x00673b:	ldr     	r1, [pc, #0x94]
0x00673d:	movs    	r0, #2
0x00673f:	add     	r1, sb
0x006741:	str     	r0, [r1]
0x006743:	ldr     	r0, [r4, #0x58]
0x006745:	movs    	r1, #0
0x006747:	ldrsh   	r0, [r0, r3]
0x006749:	movs    	r2, #0
0x00674b:	movs    	r3, #0
0x00674d:	rsbs    	r0, r0, #0
0x00674f:	str     	r0, [r4, #0x60]
0x006751:	str     	r1, [sp]
0x006753:	str     	r1, [sp, #4]
0x006755:	movs    	r1, #0x1c
0x006757:	movs    	r0, #0xf1
0x006759:	lsls    	r0, r0, #9
0x00675b:	str     	r2, [sp, #8]
0x00675d:	bl      	#0x5159
; block 0x6761
0x006761:	str     	r0, [r4, #0x64]
0x006763:	b       	#0x66d5
; block 0x6765
0x006765:	ldr     	r4, [pc, #0x6c]
0x006767:	movs    	r1, #0
0x006769:	add     	r4, sb
0x00676b:	ldr     	r0, [r4, #0x60]
0x00676d:	movs    	r2, #0
0x00676f:	adds    	r0, #0xd
0x006771:	str     	r0, [r4, #0x60]
0x006773:	ldr     	r0, [r4, #0x64]
0x006775:	movs    	r3, #0
0x006777:	subs    	r0, #0xd
0x006779:	str     	r0, [r4, #0x64]
0x00677b:	str     	r1, [sp]
0x00677d:	str     	r1, [sp, #4]
0x00677f:	movs    	r1, #0x1c
0x006781:	movs    	r0, #0xf1
0x006783:	lsls    	r0, r0, #9
0x006785:	str     	r2, [sp, #8]
0x006787:	bl      	#0x5159
; block 0x678b
0x00678b:	lsrs    	r1, r0, #0x1f
0x00678d:	adds    	r0, r1, r0
0x00678f:	asrs    	r0, r0, #1
0x006791:	ldr     	r1, [r4, #0x60]
0x006793:	subs    	r0, #0xa0
0x006795:	cmp     	r0, r1
0x006797:	bge     	#0x66d5
; block 0x6799
0x006799:	ldr     	r1, [pc, #0x34]
0x00679b:	movs    	r0, #3
0x00679d:	add     	r1, sb
0x00679f:	str     	r0, [r1]
0x0067a1:	b       	#0x66d5
; block 0x67a3
0x0067a3:	ldr     	r0, [pc, #0x30]
0x0067a5:	add     	r0, sb
0x0067a7:	ldr     	r1, [r0, #0x6c]
0x0067a9:	adds    	r1, #0xf
0x0067ab:	str     	r1, [r0, #0x6c]
0x0067ad:	ldr     	r2, [r0, #0x70]
0x0067af:	adds    	r2, #0xf
0x0067b1:	str     	r2, [r0, #0x70]
0x0067b3:	ldr     	r2, [r0, #0x74]
0x0067b5:	adds    	r2, #0xf
0x0067b7:	str     	r2, [r0, #0x74]
0x0067b9:	cmp     	r1, #0xff
0x0067bb:	blt     	#0x66d5
; block 0x67bd
0x0067bd:	movs    	r1, #0xff
0x0067bf:	str     	r1, [r0, #0x6c]
0x0067c1:	str     	r1, [r0, #0x70]
0x0067c3:	str     	r1, [r0, #0x74]
0x0067c5:	ldr     	r1, [pc, #8]
0x0067c7:	movs    	r0, #0xa
0x0067c9:	add     	r1, sb
0x0067cb:	str     	r0, [r1]
0x0067cd:	b       	#0x66d5

; ===== sub_67d1 @ 0x67d1 offset=0x67d0 size=8 blocks=1 cc=1 =====
; block 0x67d1
0x0067d1:	movs    	r4, r0
0x0067d3:	movs    	r0, r0
0x0067d5:	movs    	r4, r1
0x0067d7:	movs    	r0, r0
0x0067d9:	ldr     	r1, [pc, #0x30]
0x0067db:	push    	{r3, lr}
0x0067dd:	add     	r1, sb
0x0067df:	adds    	r0, r1, #0
0x0067e1:	ldr     	r2, [r1, #0x54]
0x0067e3:	ldr     	r0, [r0, #0x50]
0x0067e5:	adds    	r0, #1
0x0067e7:	cmp     	r2, #0
0x0067e9:	bne     	#0x67fb

; ===== sub_67d9 @ 0x67d9 offset=0x67d8 size=50 blocks=9 cc=4 =====
; block 0x67d9
0x0067d9:	ldr     	r1, [pc, #0x30]
0x0067db:	push    	{r3, lr}
0x0067dd:	add     	r1, sb
0x0067df:	adds    	r0, r1, #0
0x0067e1:	ldr     	r2, [r1, #0x54]
0x0067e3:	ldr     	r0, [r0, #0x50]
0x0067e5:	adds    	r0, #1
0x0067e7:	cmp     	r2, #0
0x0067e9:	bne     	#0x67fb
; block 0x67e5
0x0067e5:	adds    	r0, #1
0x0067e7:	cmp     	r2, #0
0x0067e9:	bne     	#0x67fb
; block 0x67eb
0x0067eb:	str     	r0, [r1, #0x50]
0x0067ed:	cmp     	r0, #0x2d
0x0067ef:	ble     	#0x67f9
; block 0x67f1
0x0067f1:	movs    	r0, #1
0x0067f3:	str     	r0, [r1, #0x54]
0x0067f5:	movs    	r0, #0
0x0067f7:	str     	r0, [r1, #0x50]
0x0067f9:	pop     	{r3, pc}
; block 0x67f9
0x0067f9:	pop     	{r3, pc}
; block 0x67fb
0x0067fb:	str     	r0, [r1, #0x50]
0x0067fd:	cmp     	r0, #0x2d
0x0067ff:	ble     	#0x67f9
; block 0x6801
0x006801:	bl      	#0x5bc5
; block 0x6805
0x006805:	bl      	#0x41e9
; block 0x6809
0x006809:	b       	#0x67f9

; ===== sub_680c @ 0x680c offset=0x680c size=12 blocks=1 cc=1 =====
; block 0x680c
0x00680c:	andeq   	r0, r0, ip
0x006810:	strhge  	pc, [r8, #0x1b]
0x006814:	blge    	#0xff278710

; ===== sub_6829 @ 0x6829 offset=0x6828 size=4 blocks=2 cc=1 =====
; block 0x6829
0x006829:	bl      	#0xff3cc9af
; block 0x682b
0x00682b:	beq     	#0x67b1

; ===== sub_6835 @ 0x6835 offset=0x6834 size=12 blocks=5 cc=1 =====
; block 0x6835
0x006835:	bl      	#0x5d57c5
; block 0x6839
0x006839:	ble     	#0x67e5
; block 0x683b
0x00683b:	bhi     	#0x67b1
; block 0x683d
0x00683d:	bpl     	#0x67a3
; block 0x683f
0x00683f:	add     	r4, sp, #0x28c

; ===== sub_684d @ 0x684d offset=0x684c size=2 blocks=1 cc=1 =====
; block 0x684d
0x00684d:	bmi     	#0x67e3

; ===== sub_685f @ 0x685f offset=0x685e size=4 blocks=1 cc=1 =====
; block 0x685f
0x00685f:	bl      	#0x5d57ef

; ===== sub_6879 @ 0x6879 offset=0x6878 size=4 blocks=1 cc=1 =====
; block 0x6879
0x006879:	bl      	#0x5d5809

; ===== sub_6893 @ 0x6893 offset=0x6892 size=2 blocks=1 cc=1 =====
; block 0x6893
0x006893:	ldc2    	p7, c12, [r3, #0x2f4]!
0x006897:	add     	r3, sp, #0x324
0x006899:	movs    	r0, r0
0x00689b:	movs    	r0, r0
0x00689d:	push    	{r0, r1, r2, r4, r5, r7, lr}
0x00689f:	bhi     	#0x6819

; ===== sub_6894 @ 0x6894 offset=0x6894 size=12 blocks=2 cc=1 =====
; block 0x6894
0x006894:	blge    	#0xff278790
; block 0x6898
0x006898:	andeq   	r0, r0, r0
0x00689c:	ldmle   	fp!, {r0, r1, r2, r4, r5, r7, r8, sl, ip, sp, pc}

; ===== sub_68b4 @ 0x68b4 offset=0x68b4 size=4 blocks=1 cc=1 =====
; block 0x68b4
0x0068b4:	blge    	#0xff2787b0

; ===== sub_68bf @ 0x68bf offset=0x68be size=4 blocks=1 cc=1 =====
; block 0x68bf
0x0068bf:	b.w     	#0x5be853

; ===== sub_68dc @ 0x68dc offset=0x68dc size=12 blocks=1 cc=1 =====
; block 0x68dc
0x0068dc:	ldrtlt  	sp, [r8], #0x6bb
0x0068e0:	andeq   	r0, r0, r0
0x0068e4:	bl      	#0xff244be0

; ===== sub_68f4 @ 0x68f4 offset=0x68f4 size=4 blocks=1 cc=1 =====
; block 0x68f4
0x0068f4:	svcgt   	#0xced32a

; ===== sub_6903 @ 0x6903 offset=0x6902 size=10 blocks=2 cc=1 =====
; block 0x6903
0x006903:	cbz     	r7, #0x693f
0x006905:	ldr     	r7, [pc, #0x2a4]
0x006907:	movs    	r6, #0x4c
0x006909:	movs    	r6, #0x20
0x00690b:	ittte   	hs
; block 0x6904
0x006904:	strbhs  	r4, [ip], -sb, lsr #31
0x006908:	svclt   	#0x232620

; ===== sub_6924 @ 0x6924 offset=0x6924 size=4 blocks=1 cc=1 =====
; block 0x6924
0x006924:	ldmiblt 	lr, {r4, r6, r7, r8, sb, sl, fp, lr, pc} ^

; ===== sub_6936 @ 0x6936 offset=0x6936 size=4 blocks=1 cc=1 =====
; block 0x6936
0x006936:	ldmgt   	r3!, {r1, r2, r5, r8, sb, sl, ip, lr, pc} ^

; ===== sub_6948 @ 0x6948 offset=0x6948 size=4 blocks=1 cc=1 =====
; block 0x6948
0x006948:	ldmgt   	r2, {r1, r2, r5, r8, sb, ip, lr, pc} ^

; ===== sub_6969 @ 0x6969 offset=0x6968 size=6 blocks=1 cc=1 =====
; block 0x6969
0x006969:	movs    	r6, #0xa8
0x00696b:	ldm     	r7, {r0, r3, r6, r7}
0x00696d:	pop     	{r0, r1, r2, r4, r5, r7, pc}

; ===== sub_696f @ 0x696f offset=0x696e size=4 blocks=1 cc=1 =====
; block 0x696f
0x00696f:	bl      	#0x2d62eb

; ===== sub_69bb @ 0x69bb offset=0x69ba size=4 blocks=1 cc=1 =====
; block 0x69bb
0x0069bb:	ite     	lt
0x0069bd:	poplt   	{r2, r3, r5, r6, r7, pc}

; ===== sub_69cb @ 0x69cb offset=0x69ca size=2 blocks=1 cc=1 =====
; block 0x69cb
0x0069cb:	adr     	r7, #0x358
0x0069cd:	bvs     	#0x6937

; ===== sub_69cd @ 0x69cd offset=0x69cc size=2 blocks=1 cc=1 =====
; block 0x69cd
0x0069cd:	bvs     	#0x6937

; ===== UnresolvableJumpTarget @ 0x100014 offset=0x100014 size=0 blocks=1 cc=1 =====
; block 0x100014
0x100014:	andeq   	r0, r0, r0

; ===== UnresolvableCallTarget @ 0x100018 offset=0x100018 size=0 blocks=1 cc=1 =====
; block 0x100018
0x100018:	andeq   	r0, r0, r0
0x10001c:	andeq   	r0, r0, r0
0x100020:	andeq   	r0, r0, r0
0x100024:	andeq   	r0, r0, r0
0x100028:	andeq   	r0, r0, r0
0x10002c:	andeq   	r0, r0, r0
0x100030:	andeq   	r0, r0, r0
0x100034:	andeq   	r0, r0, r0
0x100038:	andeq   	r0, r0, r0
0x10003c:	andeq   	r0, r0, r0
0x100040:	andeq   	r0, r0, r0
0x100044:	andeq   	r0, r0, r0
0x100048:	andeq   	r0, r0, r0
0x10004c:	andeq   	r0, r0, r0
0x100050:	andeq   	r0, r0, r0
0x100054:	andeq   	r0, r0, r0
0x100058:	andeq   	r0, r0, r0
0x10005c:	andeq   	r0, r0, r0
0x100060:	andeq   	r0, r0, r0
0x100064:	andeq   	r0, r0, r0
0x100068:	andeq   	r0, r0, r0
0x10006c:	andeq   	r0, r0, r0
0x100070:	andeq   	r0, r0, r0
0x100074:	andeq   	r0, r0, r0
0x100078:	andeq   	r0, r0, r0
0x10007c:	andeq   	r0, r0, r0
0x100080:	andeq   	r0, r0, r0
0x100084:	andeq   	r0, r0, r0
0x100088:	andeq   	r0, r0, r0
0x10008c:	andeq   	r0, r0, r0
0x100090:	andeq   	r0, r0, r0
0x100094:	andeq   	r0, r0, r0
0x100098:	andeq   	r0, r0, r0
0x10009c:	andeq   	r0, r0, r0
0x1000a0:	andeq   	r0, r0, r0
0x1000a4:	andeq   	r0, r0, r0
0x1000a8:	andeq   	r0, r0, r0
0x1000ac:	andeq   	r0, r0, r0
0x1000b0:	andeq   	r0, r0, r0
0x1000b4:	andeq   	r0, r0, r0
0x1000b8:	andeq   	r0, r0, r0
0x1000bc:	andeq   	r0, r0, r0
0x1000c0:	andeq   	r0, r0, r0
0x1000c4:	andeq   	r0, r0, r0
0x1000c8:	andeq   	r0, r0, r0
0x1000cc:	andeq   	r0, r0, r0
0x1000d0:	andeq   	r0, r0, r0
0x1000d4:	andeq   	r0, r0, r0
0x1000d8:	andeq   	r0, r0, r0
0x1000dc:	andeq   	r0, r0, r0
0x1000e0:	andeq   	r0, r0, r0
0x1000e4:	andeq   	r0, r0, r0
0x1000e8:	andeq   	r0, r0, r0
0x1000ec:	andeq   	r0, r0, r0
0x1000f0:	andeq   	r0, r0, r0
0x1000f4:	andeq   	r0, r0, r0
0x1000f8:	andeq   	r0, r0, r0
0x1000fc:	andeq   	r0, r0, r0
0x100100:	andeq   	r0, r0, r0
0x100104:	andeq   	r0, r0, r0
0x100108:	andeq   	r0, r0, r0
0x10010c:	andeq   	r0, r0, r0
0x100110:	andeq   	r0, r0, r0
0x100114:	andeq   	r0, r0, r0
0x100118:	andeq   	r0, r0, r0
0x10011c:	andeq   	r0, r0, r0
0x100120:	andeq   	r0, r0, r0
0x100124:	andeq   	r0, r0, r0
0x100128:	andeq   	r0, r0, r0
0x10012c:	andeq   	r0, r0, r0
0x100130:	andeq   	r0, r0, r0
0x100134:	andeq   	r0, r0, r0
0x100138:	andeq   	r0, r0, r0
0x10013c:	andeq   	r0, r0, r0
0x100140:	andeq   	r0, r0, r0
0x100144:	andeq   	r0, r0, r0
0x100148:	andeq   	r0, r0, r0
0x10014c:	andeq   	r0, r0, r0
0x100150:	andeq   	r0, r0, r0
0x100154:	andeq   	r0, r0, r0
0x100158:	andeq   	r0, r0, r0
0x10015c:	andeq   	r0, r0, r0
0x100160:	andeq   	r0, r0, r0
0x100164:	andeq   	r0, r0, r0
0x100168:	andeq   	r0, r0, r0
0x10016c:	andeq   	r0, r0, r0
0x100170:	andeq   	r0, r0, r0
0x100174:	andeq   	r0, r0, r0
0x100178:	andeq   	r0, r0, r0
0x10017c:	andeq   	r0, r0, r0
0x100180:	andeq   	r0, r0, r0
0x100184:	andeq   	r0, r0, r0
0x100188:	andeq   	r0, r0, r0
0x10018c:	andeq   	r0, r0, r0
0x100190:	andeq   	r0, r0, r0
0x100194:	andeq   	r0, r0, r0
0x100198:	andeq   	r0, r0, r0
0x10019c:	andeq   	r0, r0, r0
0x1001a0:	andeq   	r0, r0, r0
