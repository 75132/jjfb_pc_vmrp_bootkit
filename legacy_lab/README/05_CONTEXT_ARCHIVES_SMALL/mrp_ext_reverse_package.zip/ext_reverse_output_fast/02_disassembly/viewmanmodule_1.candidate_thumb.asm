; fallback candidate disassembly from Thumb prologues; true code is ARM entry + Thumb functions.

; ARM entry
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0x31dc
0x000018:	pop     	{r4, pc}
0x00001c:	andeq   	r4, r0, r8, ror r7
0x000020:	ands    	r2, r0, #128, #8
0x000024:	rsbmi   	r0, r0, #0
0x000028:	eors    	r3, r2, r1, asr #32
0x00002c:	rsbhs   	r1, r1, #0
0x000030:	rsbs    	ip, r0, r1, lsr #3
0x000034:	blo     	#0xbc
0x000038:	rsbs    	ip, r0, r1, lsr #8
0x00003c:	blo     	#0x80
0x000040:	lsl     	r0, r0, #8
0x000044:	orr     	r2, r2, #0xff000000
0x000048:	rsbs    	ip, r0, r1, lsr #4
0x00004c:	blo     	#0xb0
0x000050:	rsbs    	ip, r0, r1, lsr #8
0x000054:	blo     	#0x80
0x000058:	lsl     	r0, r0, #8
0x00005c:	orr     	r2, r2, #0xff0000
0x000060:	rsbs    	ip, r0, r1, lsr #8
0x000064:	lslhs   	r0, r0, #8
0x000068:	orrhs   	r2, r2, #0xff00
0x00006c:	rsbs    	ip, r0, r1, lsr #4
0x000070:	blo     	#0xb0
0x000074:	rsbs    	ip, r0, #0
0x000078:	bhs     	#0xf8
0x00007c:	lsrhs   	r0, r0, #8
0x000080:	rsbs    	ip, r0, r1, lsr #7
0x000084:	subhs   	r1, r1, r0, lsl #7
0x000088:	adc     	r2, r2, r2
0x00008c:	rsbs    	ip, r0, r1, lsr #6
0x000090:	subhs   	r1, r1, r0, lsl #6
0x000094:	adc     	r2, r2, r2
0x000098:	rsbs    	ip, r0, r1, lsr #5
0x00009c:	subhs   	r1, r1, r0, lsl #5
0x0000a0:	adc     	r2, r2, r2
0x0000a4:	rsbs    	ip, r0, r1, lsr #4
0x0000a8:	subhs   	r1, r1, r0, lsl #4
0x0000ac:	adc     	r2, r2, r2
0x0000b0:	rsbs    	ip, r0, r1, lsr #3
0x0000b4:	subhs   	r1, r1, r0, lsl #3
0x0000b8:	adc     	r2, r2, r2
0x0000bc:	rsbs    	ip, r0, r1, lsr #2
0x0000c0:	subhs   	r1, r1, r0, lsl #2
0x0000c4:	adc     	r2, r2, r2
0x0000c8:	rsbs    	ip, r0, r1, lsr #1
0x0000cc:	subhs   	r1, r1, r0, lsl #1
0x0000d0:	adc     	r2, r2, r2
0x0000d4:	rsbs    	ip, r0, r1
0x0000d8:	subhs   	r1, r1, r0
0x0000dc:	adcs    	r2, r2, r2
0x0000e0:	bhs     	#0x7c
0x0000e4:	eors    	r0, r2, r3, asr #31
0x0000e8:	add     	r0, r0, r3, lsr #31
0x0000ec:	rsbhs   	r1, r1, #0
0x0000f0:	bx      	lr
0x0000f4:	andeq   	r4, r0, r8, ror r7
0x0000f8:	mov     	r0, #2
0x0000fc:	mov     	r1, #2
0x000100:	b       	#0x118
0x000104:	strmi   	r4, [r8, -r0, lsl #14]

; ===== candidate_000008 =====
0x000008:	ands    	r0, r2
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	lsrs    	r0, r6, #0x11

; ===== candidate_00000a =====
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	lsrs    	r0, r6, #0x11

; ===== candidate_00011a =====
0x00011a:	stmdb   	sp!, {r2}

; ===== candidate_000134 =====
0x000134:	push    	{r4, r5, r6, lr}
0x000136:	ldr     	r6, [pc, #0x38]
0x000138:	adds    	r5, r1, #0
0x00013a:	adds    	r1, r0, #0
0x00013c:	adds    	r4, r0, #0
0x00013e:	add     	r6, pc
0x000140:	adds    	r0, r6, #0
0x000142:	bl      	#0x146
0x000146:	adds    	r2, r0, #0
0x000148:	cmp     	r0, r6
0x00014a:	bne     	#0x15a
0x00014c:	adds    	r1, r5, #0
0x00014e:	adds    	r0, r4, #0
0x000150:	bl      	#0x194
0x000154:	pop     	{r4, r5, r6}
0x000156:	pop     	{r3}
0x000158:	bx      	r3
0x00015a:	ldr     	r0, [pc, #0x18]
0x00015c:	add     	r0, pc
0x00015e:	cmp     	r2, r0
0x000160:	beq     	#0x16a
0x000162:	adds    	r1, r5, #0
0x000164:	adds    	r0, r4, #0
0x000166:	bl      	#0x108
0x00016a:	movs    	r0, #0
0x00016c:	b       	#0x154
0x00016e:	movs    	r0, r0
0x000170:	mcr2    	p15, #6, pc, c5, c7, #7
0x000174:	mcr2    	p15, #5, pc, c5, c7, #7
0x000178:	bx      	pc

; ===== candidate_000194 =====
0x000194:	push    	{r3, r4, r5, lr}
0x000196:	subs    	r2, r0, #1
0x000198:	cmp     	r2, #0xd
0x00019a:	adr     	r4, #0x90
0x00019c:	bhs     	#0x1ec
0x00019e:	movs    	r2, #0x17
0x0001a0:	ldr     	r3, [pc, #0x8c]
0x0001a2:	muls    	r2, r0, r2
0x0001a4:	add     	r3, pc
0x0001a6:	adds    	r5, r2, r3
0x0001a8:	subs    	r5, #0x17
0x0001aa:	cmp     	r0, #2
0x0001ac:	bne     	#0x1d8
0x0001ae:	lsls    	r0, r1, #5
0x0001b0:	bpl     	#0x1b6
0x0001b2:	adr     	r4, #0x80
0x0001b4:	b       	#0x1ee
0x0001b6:	ldr     	r0, [pc, #0x90]
0x0001b8:	ands    	r0, r1
0x0001ba:	beq     	#0x1c0
0x0001bc:	adr     	r4, #0x8c
0x0001be:	b       	#0x1ee
0x0001c0:	lsls    	r0, r1, #3
0x0001c2:	bpl     	#0x1c8
0x0001c4:	adr     	r4, #0x94
0x0001c6:	b       	#0x1ee
0x0001c8:	lsls    	r0, r1, #2
0x0001ca:	bpl     	#0x1d0
0x0001cc:	adr     	r4, #0x98
0x0001ce:	b       	#0x1ee
0x0001d0:	lsls    	r0, r1, #1
0x0001d2:	bpl     	#0x1ee
0x0001d4:	adr     	r4, #0x9c
0x0001d6:	b       	#0x1ee
0x0001d8:	cmp     	r0, #8
0x0001da:	bne     	#0x1e0
0x0001dc:	adds    	r4, r1, #0
0x0001de:	b       	#0x1ee
0x0001e0:	cmp     	r0, #9
0x0001e2:	bne     	#0x1ee
0x0001e4:	cmp     	r1, #1
0x0001e6:	bne     	#0x1ee
0x0001e8:	adr     	r5, #0x98
0x0001ea:	b       	#0x1ee
0x0001ec:	adr     	r5, #0xac
0x0001ee:	movs    	r0, #0xa
0x0001f0:	bl      	#0x2b4
0x0001f4:	ldrb    	r0, [r5]
0x0001f6:	cmp     	r0, #0
0x0001f8:	beq     	#0x208
0x0001fa:	ldrb    	r0, [r5]
0x0001fc:	adds    	r5, #1
0x0001fe:	bl      	#0x2b4
0x000202:	ldrb    	r0, [r5]
0x000204:	cmp     	r0, #0
0x000206:	bne     	#0x1fa
0x000208:	ldrb    	r0, [r4]
0x00020a:	cmp     	r0, #0
0x00020c:	beq     	#0x21c
0x00020e:	ldrb    	r0, [r4]
0x000210:	adds    	r4, #1
0x000212:	bl      	#0x2b4
0x000216:	ldrb    	r0, [r4]
0x000218:	cmp     	r0, #0
0x00021a:	bne     	#0x20e
0x00021c:	movs    	r0, #0xa
0x00021e:	bl      	#0x2b4
0x000222:	pop     	{r3, r4, r5}
0x000224:	pop     	{r3}
0x000226:	movs    	r0, #1
0x000228:	bx      	r3
0x00022a:	movs    	r0, r0
0x00022c:	movs    	r0, r0
0x00022e:	movs    	r0, r0
0x000230:	ldr     	r1, [pc, #0x50]
0x000232:	movs    	r0, r0
0x000234:	ldr     	r1, [r1, #0x64]
0x000236:	str     	r6, [r6, #0x14]
0x000238:	ldr     	r4, [r5, #0x14]
0x00023a:	movs    	r0, #0x64
0x00023c:	strb    	r7, [r1, #1]
0x00023e:	strb    	r5, [r4, #9]
0x000240:	strb    	r1, [r4, #0x11]
0x000242:	ldr     	r1, [r5, #0x74]
0x000244:	lsls    	r6, r5, #1
0x000246:	movs    	r0, r0
0x000248:	movs    	r2, r0
0x00024a:	lsrs    	r0, r0, #0x20
0x00024c:	ldr     	r4, [r0, #0x14]
0x00024e:	ldr     	r6, [r6, #0x14]
0x000250:	str     	r4, [r4, #0x54]
0x000252:	tst     	r0, r4
0x000254:	movs    	r0, #0x79
0x000256:	str     	r2, [r3, #0x54]
0x000258:	ldr     	r2, [r6, #0x74]
0x00025a:	movs    	r0, r0
0x00025c:	strb    	r7, [r1, #0x19]
0x00025e:	strb    	r5, [r4, #9]
0x000260:	ldr     	r6, [r4, #0x44]
0x000262:	strb    	r7, [r5, #0x1d]
0x000264:	movs    	r0, r0
0x000266:	movs    	r0, r0
0x000268:	ldr     	r5, [r2, #0x64]
0x00026a:	str     	r4, [r4, #0x54]
0x00026c:	str     	r2, [r6, #0x64]
0x00026e:	ldr     	r4, [r5, #0x74]
0x000270:	lsls    	r7, r6, #1
0x000272:	movs    	r0, r0
0x000274:	ldr     	r1, [r1, #0x64]
0x000276:	ldrb    	r5, [r4, #1]
0x000278:	str     	r1, [r4, #0x34]
0x00027a:	movs    	r0, #0x74
0x00027c:	str     	r2, [r2, #0x54]
0x00027e:	strb    	r3, [r6, #0x15]
0x000280:	strb    	r4, [r5, #0x11]
0x000282:	movs    	r0, r0
0x000284:	movs    	r0, #0x3a
0x000286:	str     	r0, [r1, #0x54]
0x000288:	strb    	r1, [r4, #1]
0x00028a:	ldr     	r0, [r4, #0x50]
0x00028c:	ldr     	r5, [r4, #0x54]
0x00028e:	strb    	r7, [r5, #9]
0x000290:	movs    	r0, #0x79
0x000292:	ldr     	r3, [r4, #0x74]
0x000294:	strb    	r2, [r6, #9]
0x000296:	strb    	r5, [r6, #1]
0x000298:	str     	r4, [r6, #0x54]
0x00029a:	lsls    	r4, r4, #1
0x00029c:	ldr     	r5, [r2, #0x64]
0x00029e:	ldr     	r3, [r5, #0x64]
0x0002a0:	strb    	r7, [r5, #0x1d]
0x0002a2:	movs    	r0, #0x6e
0x0002a4:	ldr     	r3, [r6, #0x14]
0x0002a6:	ldr     	r7, [r4, #0x64]
0x0002a8:	ldr     	r1, [r4, #0x44]
0x0002aa:	movs    	r0, r0
0x0002ac:	bx      	pc

; ===== candidate_0002b4 =====
0x0002b4:	push    	{r3, lr}
0x0002b6:	add     	r3, sp, #0
0x0002b8:	strb    	r0, [r3]
0x0002ba:	movs    	r0, #3
0x0002bc:	mov     	r1, sp
0x0002be:	svc     	#0xab
0x0002c0:	add     	sp, #4
0x0002c2:	pop     	{r3}
0x0002c4:	bx      	r3
0x0002c6:	movs    	r0, r0
0x0002c8:	movs    	r0, r1
0x0002ca:	b       	#0xfffffe0c
0x0002cc:	asrs    	r0, r1, #0x20
0x0002ce:	b       	#0xfffffe10
0x0002d0:	movs    	r1, r0
0x0002d2:	b       	#0x3d6
0x0002d4:	vrhadd.u16	d14, d14, d31
0x0002d8:	movs    	r4, r0
0x0002da:	movs    	r0, r0
0x0002dc:	lsls    	r0, r0, #6
0x0002de:	movs    	r0, r0
0x0002e0:	str     	r0, [sp]
0x0002e2:	b       	#0x626
0x0002e4:	vrhadd.u16	d14, d14, d31
0x0002e8:	adds    	r0, #0x14
0x0002ea:	b       	#0xfffffe2c
0x0002ec:	cmp     	r7, #0xc0
0x0002ee:	b       	#0x632
0x0002f0:	stm     	r0!, {r0, r1, r4, r7}
0x0002f2:	b       	#0x478
0x0002f4:	adds    	r0, #4
0x0002f6:	b       	#0xaba
0x0002f8:	asrs    	r1, r0, #3
0x0002fa:	b       	#0x3c2
0x0002fc:	lsls    	r3, r2, #6
0x0002fe:	b       	#0x342
0x000300:	vrhadd.u16	d14, d14, d31
0x000304:	str     	r7, [r4, #0x64]
0x000306:	str     	r6, [r4, #0x64]
0x000308:	push    	{r4, r5, lr}
0x00030a:	ldr     	r4, [pc, #0xb4]
0x00030c:	movs    	r2, #0x1c
0x00030e:	add     	r4, pc
0x000310:	ldr     	r0, [r4, #0x38]
0x000312:	movs    	r1, #0
0x000314:	ldr     	r3, [r0, #0x38]
0x000316:	ldr     	r0, [pc, #0xac]
0x000318:	sub     	sp, #0xc
0x00031a:	add     	r0, sb
0x00031c:	blx     	r3
0x00031e:	movs    	r2, #0
0x000320:	movs    	r0, #0
0x000322:	str     	r0, [sp]
0x000324:	ldr     	r1, [pc, #0x9c]
0x000326:	movs    	r3, #0
0x000328:	add     	r1, sb
0x00032a:	str     	r1, [sp, #4]
0x00032c:	movs    	r1, #0x64
0x00032e:	movs    	r0, #1
0x000330:	str     	r2, [sp, #8]
0x000332:	bl      	#0x326c
0x000336:	ldr     	r1, [pc, #0x8c]
0x000338:	movs    	r0, #0
0x00033a:	add     	r1, sb
0x00033c:	subs    	r1, #0x7c
0x00033e:	str     	r0, [r1, #8]
0x000340:	ldr     	r5, [pc, #0x80]
0x000342:	str     	r0, [r1, #0x10]
0x000344:	str     	r0, [r1, #0xc]
0x000346:	add     	r5, sb
0x000348:	subs    	r5, #0xfc
0x00034a:	movs    	r0, #1
0x00034c:	str     	r0, [r5, #0x18]
0x00034e:	ldr     	r0, [r4, #0x38]
0x000350:	ldr     	r2, [pc, #0x74]
0x000352:	ldr     	r1, [r0, #0x68]
0x000354:	add     	r2, sb
0x000356:	str     	r1, [r5, #0x2c]
0x000358:	ldr     	r1, [r0, #0xc]
0x00035a:	ldr     	r4, [pc, #0x70]
0x00035c:	str     	r1, [r5, #0x30]
0x00035e:	ldr     	r1, [r0, #0x10]
0x000360:	str     	r1, [r5, #0x34]
0x000362:	ldr     	r1, [r0, #0x14]
0x000364:	str     	r1, [r5, #0x38]
0x000366:	ldr     	r1, [r0, #0x18]
0x000368:	str     	r1, [r5, #0x3c]
0x00036a:	ldr     	r1, [r0, #0x1c]
0x00036c:	str     	r1, [r5, #0x40]
0x00036e:	ldr     	r1, [r0, #0x20]
0x000370:	str     	r1, [r5, #0x44]
0x000372:	ldr     	r1, [r0, #0x24]
0x000374:	str     	r1, [r5, #0x48]
0x000376:	ldr     	r1, [r0, #0x28]
0x000378:	str     	r1, [r5, #0x4c]
0x00037a:	ldr     	r1, [r0, #0x2c]
0x00037c:	str     	r1, [r5, #0x50]
0x00037e:	ldr     	r1, [r0, #0x30]
0x000380:	str     	r1, [r5, #0x54]
0x000382:	ldr     	r1, [r0, #0x34]
0x000384:	str     	r1, [r5, #0x58]
0x000386:	ldr     	r1, [r0, #0x38]
0x000388:	str     	r1, [r5, #0x5c]
0x00038a:	ldr     	r1, [r0, #0x3c]
0x00038c:	str     	r1, [r5, #0x60]
0x00038e:	ldr     	r1, [r0, #0x40]
0x000390:	str     	r1, [r5, #0x64]
0x000392:	ldr     	r1, [r0, #0x44]
0x000394:	str     	r1, [r5, #0x68]
0x000396:	ldr     	r1, [r0, #0x48]
0x000398:	str     	r1, [r5, #0x6c]
0x00039a:	ldr     	r1, [r0, #0x4c]
0x00039c:	str     	r1, [r5, #0x70]
0x00039e:	movs    	r1, #0
0x0003a0:	str     	r1, [r2]
0x0003a2:	movs    	r1, #1
0x0003a4:	lsls    	r1, r1, #9
0x0003a6:	adds    	r0, r0, r1
0x0003a8:	ldr     	r3, [r0, #8]
0x0003aa:	movs    	r1, #7
0x0003ac:	adds    	r2, r4, #0
0x0003ae:	movs    	r0, #0
0x0003b0:	blx     	r3
0x0003b2:	cmp     	r0, r4
0x0003b4:	bne     	#0x3ba
0x0003b6:	subs    	r0, #2
0x0003b8:	str     	r0, [r5, #0x28]
0x0003ba:	add     	sp, #0xc
0x0003bc:	pop     	{r4, r5, pc}

; ===== candidate_000308 =====
0x000308:	push    	{r4, r5, lr}
0x00030a:	ldr     	r4, [pc, #0xb4]
0x00030c:	movs    	r2, #0x1c
0x00030e:	add     	r4, pc
0x000310:	ldr     	r0, [r4, #0x38]
0x000312:	movs    	r1, #0
0x000314:	ldr     	r3, [r0, #0x38]
0x000316:	ldr     	r0, [pc, #0xac]
0x000318:	sub     	sp, #0xc
0x00031a:	add     	r0, sb
0x00031c:	blx     	r3
0x00031e:	movs    	r2, #0
0x000320:	movs    	r0, #0
0x000322:	str     	r0, [sp]
0x000324:	ldr     	r1, [pc, #0x9c]
0x000326:	movs    	r3, #0
0x000328:	add     	r1, sb
0x00032a:	str     	r1, [sp, #4]
0x00032c:	movs    	r1, #0x64
0x00032e:	movs    	r0, #1
0x000330:	str     	r2, [sp, #8]
0x000332:	bl      	#0x326c
0x000336:	ldr     	r1, [pc, #0x8c]
0x000338:	movs    	r0, #0
0x00033a:	add     	r1, sb
0x00033c:	subs    	r1, #0x7c
0x00033e:	str     	r0, [r1, #8]
0x000340:	ldr     	r5, [pc, #0x80]
0x000342:	str     	r0, [r1, #0x10]
0x000344:	str     	r0, [r1, #0xc]
0x000346:	add     	r5, sb
0x000348:	subs    	r5, #0xfc
0x00034a:	movs    	r0, #1
0x00034c:	str     	r0, [r5, #0x18]
0x00034e:	ldr     	r0, [r4, #0x38]
0x000350:	ldr     	r2, [pc, #0x74]
0x000352:	ldr     	r1, [r0, #0x68]
0x000354:	add     	r2, sb
0x000356:	str     	r1, [r5, #0x2c]
0x000358:	ldr     	r1, [r0, #0xc]
0x00035a:	ldr     	r4, [pc, #0x70]
0x00035c:	str     	r1, [r5, #0x30]
0x00035e:	ldr     	r1, [r0, #0x10]
0x000360:	str     	r1, [r5, #0x34]
0x000362:	ldr     	r1, [r0, #0x14]
0x000364:	str     	r1, [r5, #0x38]
0x000366:	ldr     	r1, [r0, #0x18]
0x000368:	str     	r1, [r5, #0x3c]
0x00036a:	ldr     	r1, [r0, #0x1c]
0x00036c:	str     	r1, [r5, #0x40]
0x00036e:	ldr     	r1, [r0, #0x20]
0x000370:	str     	r1, [r5, #0x44]
0x000372:	ldr     	r1, [r0, #0x24]
0x000374:	str     	r1, [r5, #0x48]
0x000376:	ldr     	r1, [r0, #0x28]
0x000378:	str     	r1, [r5, #0x4c]
0x00037a:	ldr     	r1, [r0, #0x2c]
0x00037c:	str     	r1, [r5, #0x50]
0x00037e:	ldr     	r1, [r0, #0x30]
0x000380:	str     	r1, [r5, #0x54]
0x000382:	ldr     	r1, [r0, #0x34]
0x000384:	str     	r1, [r5, #0x58]
0x000386:	ldr     	r1, [r0, #0x38]
0x000388:	str     	r1, [r5, #0x5c]
0x00038a:	ldr     	r1, [r0, #0x3c]
0x00038c:	str     	r1, [r5, #0x60]
0x00038e:	ldr     	r1, [r0, #0x40]
0x000390:	str     	r1, [r5, #0x64]
0x000392:	ldr     	r1, [r0, #0x44]
0x000394:	str     	r1, [r5, #0x68]
0x000396:	ldr     	r1, [r0, #0x48]
0x000398:	str     	r1, [r5, #0x6c]
0x00039a:	ldr     	r1, [r0, #0x4c]
0x00039c:	str     	r1, [r5, #0x70]
0x00039e:	movs    	r1, #0
0x0003a0:	str     	r1, [r2]
0x0003a2:	movs    	r1, #1
0x0003a4:	lsls    	r1, r1, #9
0x0003a6:	adds    	r0, r0, r1
0x0003a8:	ldr     	r3, [r0, #8]
0x0003aa:	movs    	r1, #7
0x0003ac:	adds    	r2, r4, #0
0x0003ae:	movs    	r0, #0
0x0003b0:	blx     	r3
0x0003b2:	cmp     	r0, r4
0x0003b4:	bne     	#0x3ba
0x0003b6:	subs    	r0, #2
0x0003b8:	str     	r0, [r5, #0x28]
0x0003ba:	add     	sp, #0xc
0x0003bc:	pop     	{r4, r5, pc}

; ===== candidate_0003d0 =====
0x0003d0:	push    	{r4, r5, r6, lr}
0x0003d2:	sub     	sp, #0x10
0x0003d4:	movs    	r1, #2
0x0003d6:	movs    	r2, #2
0x0003d8:	str     	r2, [sp, #8]
0x0003da:	str     	r1, [sp]
0x0003dc:	str     	r1, [sp, #4]
0x0003de:	movs    	r1, #0
0x0003e0:	movs    	r2, #0
0x0003e2:	adds    	r4, r0, #0
0x0003e4:	movs    	r3, #4
0x0003e6:	movs    	r0, #0
0x0003e8:	bl      	#0x424
0x0003ec:	ldr     	r5, [pc, #0x30]
0x0003ee:	movs    	r6, #1
0x0003f0:	add     	r5, sb
0x0003f2:	str     	r0, [r5, #0x14]
0x0003f4:	ldr     	r1, [r4, #0x5c]
0x0003f6:	str     	r1, [r0, #0x38]
0x0003f8:	strb    	r6, [r0, #0x15]
0x0003fa:	movs    	r1, #0
0x0003fc:	strb    	r1, [r0, #0x16]
0x0003fe:	strb    	r1, [r0, #0xc]
0x000400:	adds    	r0, #0x80
0x000402:	str     	r1, [r0, #0x34]
0x000404:	str     	r1, [r0, #0x38]
0x000406:	ldr     	r0, [r4, #0x48]
0x000408:	bl      	#0x28d4
0x00040c:	cmn     	r0, r6
0x00040e:	beq     	#0x41a
0x000410:	ldr     	r1, [r5, #0x14]
0x000412:	movs    	r2, #0xac
0x000414:	strb    	r6, [r2, r1]
0x000416:	adds    	r1, #0xc0
0x000418:	str     	r0, [r1, #0x2c]
0x00041a:	add     	sp, #0x10
0x00041c:	pop     	{r4, r5, r6, pc}

; ===== candidate_000424 =====
0x000424:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x000426:	sub     	sp, #0xc
0x000428:	adds    	r7, r2, #0
0x00042a:	movs    	r1, #0
0x00042c:	movs    	r2, #0
0x00042e:	str     	r2, [sp, #8]
0x000430:	str     	r1, [sp]
0x000432:	str     	r1, [sp, #4]
0x000434:	movs    	r6, #0
0x000436:	adds    	r3, r6, #0
0x000438:	movs    	r1, #0xf
0x00043a:	movs    	r2, #0xf0
0x00043c:	movs    	r0, #0xf1
0x00043e:	movs    	r5, #0
0x000440:	lsls    	r0, r0, #9
0x000442:	bl      	#0x326c
0x000446:	movs    	r1, #0
0x000448:	movs    	r2, #0
0x00044a:	str     	r2, [sp, #8]
0x00044c:	str     	r1, [sp]
0x00044e:	str     	r1, [sp, #4]
0x000450:	adds    	r4, r0, #0
0x000452:	movs    	r0, #0xf1
0x000454:	movs    	r1, #0xa
0x000456:	movs    	r2, #7
0x000458:	movs    	r3, #1
0x00045a:	lsls    	r0, r0, #9
0x00045c:	bl      	#0x326c
0x000460:	adds    	r1, r4, #0
0x000462:	adds    	r1, #0x80
0x000464:	str     	r0, [r1, #0x3c]
0x000466:	adds    	r0, r6, #0
0x000468:	ldr     	r2, [r1, #0x3c]
0x00046a:	strb    	r0, [r2, r5]
0x00046c:	adds    	r5, #1
0x00046e:	cmp     	r5, #7
0x000470:	blt     	#0x468
0x000472:	adds    	r5, r0, #0
0x000474:	adds    	r0, r4, #0
0x000476:	adds    	r0, #0xc0
0x000478:	str     	r5, [r0, #4]
0x00047a:	str     	r5, [r0, #8]
0x00047c:	adds    	r2, r4, #0
0x00047e:	adds    	r2, #0xd0
0x000480:	str     	r5, [r0, #0x28]
0x000482:	strb    	r5, [r2, #0xe]
0x000484:	str     	r5, [r4, #0x34]
0x000486:	str     	r5, [r0, #0x20]
0x000488:	strb    	r5, [r2, #0xc]
0x00048a:	str     	r5, [r0, #0x14]
0x00048c:	str     	r5, [r0, #0x18]
0x00048e:	str     	r5, [r1, #0x10]
0x000490:	str     	r5, [r4, #4]
0x000492:	subs    	r0, #0x50
0x000494:	strb    	r5, [r0, #4]
0x000496:	strb    	r5, [r0, #5]
0x000498:	str     	r5, [r4, #0x70]
0x00049a:	str     	r5, [r4, #0x20]
0x00049c:	str     	r5, [r4, #0x64]
0x00049e:	ldr     	r0, [sp, #0x18]
0x0004a0:	adds    	r6, r4, #0
0x0004a2:	adds    	r6, #0x40
0x0004a4:	strb    	r0, [r6, #8]
0x0004a6:	adds    	r0, r7, #0
0x0004a8:	adds    	r7, r4, #0
0x0004aa:	adds    	r7, #0x30
0x0004ac:	strb    	r0, [r7, #0xc]
0x0004ae:	movs    	r1, #0
0x0004b0:	movs    	r2, #0
0x0004b2:	str     	r2, [sp, #8]
0x0004b4:	str     	r1, [sp]
0x0004b6:	str     	r1, [sp, #4]
0x0004b8:	adds    	r3, r5, #0
0x0004ba:	adds    	r2, r4, #0
0x0004bc:	movs    	r1, #0x5c
0x0004be:	movs    	r0, #0xf1
0x0004c0:	lsls    	r0, r0, #9
0x0004c2:	bl      	#0x326c
0x0004c6:	movs    	r0, #0
0x0004c8:	mvns    	r0, r0
0x0004ca:	str     	r0, [r4, #0x50]
0x0004cc:	strb    	r5, [r6, #9]
0x0004ce:	movs    	r3, #1
0x0004d0:	strb    	r3, [r4, #0x14]
0x0004d2:	strb    	r5, [r4, #0x15]
0x0004d4:	strb    	r5, [r4, #0x16]
0x0004d6:	str     	r5, [r4, #0x24]
0x0004d8:	str     	r5, [r4, #8]
0x0004da:	ldr     	r0, [sp, #0xc]
0x0004dc:	str     	r0, [r4, #0x18]
0x0004de:	ldr     	r0, [sp, #0x10]
0x0004e0:	str     	r0, [r4, #0x1c]
0x0004e2:	str     	r5, [r4, #0x20]
0x0004e4:	ldr     	r0, [sp, #0x30]
0x0004e6:	str     	r0, [r4, #0x28]
0x0004e8:	ldr     	r0, [sp, #0x34]
0x0004ea:	str     	r0, [r4, #0x2c]
0x0004ec:	ldr     	r0, [sp, #0x38]
0x0004ee:	strb    	r0, [r7]
0x0004f0:	add     	sp, #0x1c
0x0004f2:	adds    	r0, r4, #0
0x0004f4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0004f8 =====
0x0004f8:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x0004fa:	adds    	r7, r0, #0
0x0004fc:	ldr     	r0, [pc, #0x3a4]
0x0004fe:	sub     	sp, #0x58
0x000500:	add     	r0, sb
0x000502:	ldr     	r0, [r0, #0x1c]
0x000504:	adds    	r5, r2, #0
0x000506:	ldr     	r1, [r0, #0x48]
0x000508:	movs    	r2, #0
0x00050a:	str     	r1, [sp, #0x4c]
0x00050c:	movs    	r1, #0x3c
0x00050e:	str     	r1, [sp, #0x48]
0x000510:	movs    	r1, #0
0x000512:	str     	r1, [sp]
0x000514:	str     	r1, [sp, #4]
0x000516:	movs    	r1, #0x11
0x000518:	str     	r2, [sp, #8]
0x00051a:	movs    	r0, #0xf1
0x00051c:	movs    	r3, #4
0x00051e:	lsls    	r0, r0, #9
0x000520:	ldr     	r2, [sp, #0x4c]
0x000522:	bl      	#0x326c
0x000526:	movs    	r1, #0
0x000528:	str     	r1, [sp]
0x00052a:	str     	r1, [sp, #4]
0x00052c:	adds    	r4, r0, #0
0x00052e:	movs    	r2, #0
0x000530:	movs    	r0, #0xf1
0x000532:	movs    	r1, #0x1c
0x000534:	movs    	r6, #0x19
0x000536:	movs    	r3, #0
0x000538:	lsls    	r0, r0, #9
0x00053a:	str     	r2, [sp, #8]
0x00053c:	bl      	#0x326c
0x000540:	str     	r0, [sp, #0x44]
0x000542:	movs    	r1, #0
0x000544:	str     	r1, [sp]
0x000546:	str     	r1, [sp, #4]
0x000548:	movs    	r2, #0
0x00054a:	movs    	r1, #0x1d
0x00054c:	movs    	r0, #0xf1
0x00054e:	movs    	r3, #0
0x000550:	lsls    	r0, r0, #9
0x000552:	str     	r2, [sp, #8]
0x000554:	bl      	#0x326c
0x000558:	subs    	r0, r0, r5
0x00055a:	subs    	r0, #0x3c
0x00055c:	str     	r0, [sp, #0x40]
0x00055e:	adds    	r1, r0, #0
0x000560:	adds    	r0, r6, #0
0x000562:	blx     	#0x20
0x000566:	str     	r0, [sp, #0x3c]
0x000568:	ldr     	r0, [pc, #0x338]
0x00056a:	cmp     	r4, #0
0x00056c:	add     	r0, sb
0x00056e:	str     	r4, [r0, #0x10]
0x000570:	ble     	#0x642
0x000572:	ldr     	r2, [sp, #0x3c]
0x000574:	ldr     	r1, [r0, #0xc]
0x000576:	adds    	r0, r2, #0
0x000578:	str     	r1, [sp, #0x54]
0x00057a:	blx     	#0x20
0x00057e:	ldr     	r2, [sp, #0x3c]
0x000580:	muls    	r0, r2, r0
0x000582:	str     	r0, [sp, #0x38]
0x000584:	ldr     	r1, [sp, #0x38]
0x000586:	adds    	r0, r4, #0
0x000588:	adds    	r1, r1, r2
0x00058a:	cmp     	r1, r4
0x00058c:	bge     	#0x590
0x00058e:	adds    	r0, r1, #0
0x000590:	str     	r0, [sp, #0x34]
0x000592:	ldr     	r0, [sp, #0x40]
0x000594:	ldr     	r2, [sp, #0x54]
0x000596:	str     	r4, [sp, #4]
0x000598:	str     	r0, [sp]
0x00059a:	ldr     	r0, [sp, #0x44]
0x00059c:	str     	r2, [sp, #8]
0x00059e:	adds    	r2, r7, r0
0x0005a0:	subs    	r2, #0xc
0x0005a2:	adds    	r3, r5, #0
0x0005a4:	movs    	r0, #0xf1
0x0005a6:	movs    	r1, #0x3b
0x0005a8:	lsls    	r0, r0, #9
0x0005aa:	bl      	#0x326c
0x0005ae:	ldr     	r0, [sp, #0x44]
0x0005b0:	ldr     	r4, [sp, #0x38]
0x0005b2:	subs    	r0, #0xc
0x0005b4:	str     	r0, [sp, #0x44]
0x0005b6:	ldr     	r0, [sp, #0x34]
0x0005b8:	cmp     	r4, r0
0x0005ba:	bge     	#0x682
0x0005bc:	adds    	r0, r7, #0
0x0005be:	adds    	r0, #0x14
0x0005c0:	str     	r0, [sp, #0x50]
0x0005c2:	ldr     	r1, [sp, #0x4c]
0x0005c4:	lsls    	r0, r4, #2
0x0005c6:	ldr     	r0, [r1, r0]
0x0005c8:	movs    	r2, #0
0x0005ca:	str     	r0, [sp, #0x30]
0x0005cc:	ldr     	r0, [sp, #0x44]
0x0005ce:	str     	r2, [sp, #8]
0x0005d0:	adds    	r3, r5, #0
0x0005d2:	str     	r0, [sp]
0x0005d4:	movs    	r0, #0xf1
0x0005d6:	adds    	r2, r7, #0
0x0005d8:	movs    	r1, #0x2e
0x0005da:	lsls    	r0, r0, #9
0x0005dc:	str     	r6, [sp, #4]
0x0005de:	bl      	#0x326c
0x0005e2:	ldr     	r1, [pc, #0x2c0]
0x0005e4:	add     	r1, sb
0x0005e6:	ldr     	r0, [r1, #0xc]
0x0005e8:	cmp     	r4, r0
0x0005ea:	bne     	#0x604
0x0005ec:	ldr     	r0, [sp, #0x44]
0x0005ee:	movs    	r2, #0
0x0005f0:	str     	r2, [sp, #8]
0x0005f2:	adds    	r3, r5, #0
0x0005f4:	str     	r0, [sp]
0x0005f6:	movs    	r0, #0xf1
0x0005f8:	adds    	r2, r7, #0
0x0005fa:	movs    	r1, #0xc7
0x0005fc:	lsls    	r0, r0, #9
0x0005fe:	str     	r6, [sp, #4]
0x000600:	bl      	#0x326c
0x000604:	ldr     	r0, [sp, #0x44]
0x000606:	movs    	r2, #0
0x000608:	str     	r2, [sp, #8]
0x00060a:	adds    	r3, r5, #0
0x00060c:	str     	r0, [sp]
0x00060e:	movs    	r0, #0xf1
0x000610:	adds    	r2, r7, #0
0x000612:	movs    	r1, #0x2f
0x000614:	lsls    	r0, r0, #9
0x000616:	str     	r6, [sp, #4]
0x000618:	bl      	#0x326c
0x00061c:	cmp     	r0, #1
0x00061e:	bne     	#0x65c
0x000620:	ldr     	r1, [pc, #0x280]
0x000622:	add     	r1, sb

; ===== candidate_0008ac =====
0x0008ac:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x0008ae:	adds    	r4, r0, #0
0x0008b0:	sub     	sp, #0x70
0x0008b2:	adds    	r5, r1, #0
0x0008b4:	movs    	r1, #0
0x0008b6:	movs    	r2, #0
0x0008b8:	str     	r2, [sp, #8]
0x0008ba:	str     	r1, [sp]
0x0008bc:	str     	r1, [sp, #4]
0x0008be:	movs    	r1, #0xe1
0x0008c0:	movs    	r2, #0x28
0x0008c2:	movs    	r0, #0xf1
0x0008c4:	movs    	r6, #0x32
0x0008c6:	movs    	r3, #0
0x0008c8:	lsls    	r0, r0, #9
0x0008ca:	bl      	#0x326c
0x0008ce:	movs    	r1, #0
0x0008d0:	movs    	r2, #0
0x0008d2:	str     	r2, [sp, #8]
0x0008d4:	str     	r1, [sp]
0x0008d6:	str     	r1, [sp, #4]
0x0008d8:	adds    	r7, r0, #0
0x0008da:	movs    	r0, #0xf1
0x0008dc:	movs    	r1, #0xe1
0x0008de:	movs    	r2, #0x29
0x0008e0:	movs    	r3, #0
0x0008e2:	lsls    	r0, r0, #9
0x0008e4:	bl      	#0x326c
0x0008e8:	add     	r2, sp, #0x58
0x0008ea:	str     	r2, [sp, #8]
0x0008ec:	ldr     	r2, [pc, #0x3e4]
0x0008ee:	add     	r1, sp, #0x5c
0x0008f0:	str     	r1, [sp, #4]
0x0008f2:	adds    	r3, r0, #0
0x0008f4:	str     	r7, [sp]
0x0008f6:	add     	r2, pc
0x0008f8:	movs    	r1, #0x2a
0x0008fa:	movs    	r0, #0xf1
0x0008fc:	lsls    	r0, r0, #9
0x0008fe:	bl      	#0x326c
0x000902:	ldr     	r7, [pc, #0x3d4]
0x000904:	add     	r7, sb
0x000906:	ldr     	r0, [r7, #8]
0x000908:	cmp     	r0, #0
0x00090a:	bne     	#0x92a
0x00090c:	movs    	r1, #0
0x00090e:	movs    	r2, #0
0x000910:	str     	r2, [sp, #8]
0x000912:	str     	r1, [sp]
0x000914:	str     	r1, [sp, #4]
0x000916:	ldr     	r0, [r7, #0x1c]
0x000918:	movs    	r1, #0x37
0x00091a:	ldr     	r0, [r0, #0x5c]
0x00091c:	movs    	r3, #0
0x00091e:	ldr     	r2, [r0, #4]
0x000920:	movs    	r0, #0xf1
0x000922:	lsls    	r0, r0, #9
0x000924:	bl      	#0x326c
0x000928:	str     	r0, [r7, #8]
0x00092a:	movs    	r1, #0
0x00092c:	movs    	r0, #0x64
0x00092e:	str     	r0, [sp, #0x54]
0x000930:	str     	r1, [sp]
0x000932:	str     	r1, [sp, #4]
0x000934:	movs    	r2, #0
0x000936:	movs    	r1, #0x1c
0x000938:	movs    	r0, #0xf1
0x00093a:	movs    	r3, #0
0x00093c:	lsls    	r0, r0, #9
0x00093e:	str     	r2, [sp, #8]
0x000940:	bl      	#0x326c
0x000944:	ldr     	r1, [sp, #0x54]
0x000946:	movs    	r2, #0
0x000948:	str     	r2, [sp, #8]
0x00094a:	str     	r0, [sp]
0x00094c:	adds    	r3, r5, #0
0x00094e:	str     	r1, [sp, #4]
0x000950:	movs    	r1, #0x31
0x000952:	adds    	r2, r4, #0
0x000954:	movs    	r0, #0xf1
0x000956:	lsls    	r0, r0, #9
0x000958:	bl      	#0x326c
0x00095c:	movs    	r1, #0
0x00095e:	str     	r1, [sp]
0x000960:	str     	r1, [sp, #4]
0x000962:	movs    	r2, #0
0x000964:	movs    	r1, #0x1c
0x000966:	movs    	r3, #0
0x000968:	movs    	r0, #0xf1
0x00096a:	lsls    	r0, r0, #9
0x00096c:	str     	r2, [sp, #8]
0x00096e:	bl      	#0x326c
0x000972:	movs    	r2, #0
0x000974:	adds    	r5, #0x64
0x000976:	adds    	r3, r5, #0
0x000978:	str     	r2, [sp, #8]
0x00097a:	str     	r0, [sp]
0x00097c:	movs    	r0, #0xf1
0x00097e:	adds    	r2, r4, #0
0x000980:	movs    	r1, #0x32
0x000982:	lsls    	r0, r0, #9
0x000984:	str     	r6, [sp, #4]
0x000986:	bl      	#0x326c
0x00098a:	ldr     	r7, [pc, #0x34c]
0x00098c:	add     	r7, sb
0x00098e:	ldr     	r0, [r7, #0x1c]
0x000990:	ldr     	r7, [r0, #0x58]
0x000992:	cmp     	r7, #0
0x000994:	bne     	#0x99a
0x000996:	ldr     	r7, [pc, #0x344]
0x000998:	add     	r7, pc
0x00099a:	movs    	r1, #0
0x00099c:	movs    	r2, #0
0x00099e:	str     	r2, [sp, #8]
0x0009a0:	str     	r1, [sp]
0x0009a2:	str     	r1, [sp, #4]
0x0009a4:	movs    	r1, #0xe1
0x0009a6:	movs    	r2, #0x58
0x0009a8:	movs    	r3, #0
0x0009aa:	movs    	r0, #0xf1
0x0009ac:	lsls    	r0, r0, #9
0x0009ae:	bl      	#0x326c
0x0009b2:	cmp     	r0, #0
0x0009b4:	bne     	#0xa16
0x0009b6:	movs    	r1, #0
0x0009b8:	str     	r1, [sp]
0x0009ba:	str     	r1, [sp, #4]
0x0009bc:	movs    	r2, #0
0x0009be:	movs    	r1, #0x1c
0x0009c0:	movs    	r3, #0
0x0009c2:	movs    	r0, #0xf1
0x0009c4:	lsls    	r0, r0, #9
0x0009c6:	str     	r2, [sp, #8]
0x0009c8:	bl      	#0x326c
0x0009cc:	adds    	r3, r0, #0
0x0009ce:	movs    	r1, #0
0x0009d0:	movs    	r2, #0
0x0009d2:	str     	r2, [sp, #8]
0x0009d4:	str     	r1, [sp]
0x0009d6:	str     	r1, [sp, #4]
0x0009d8:	subs    	r3, #0x32

; ===== candidate_001a2c =====
0x001a2c:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x001a2e:	sub     	sp, #0x88
0x001a30:	movs    	r1, #0x1e
0x001a32:	str     	r1, [sp, #0x6c]
0x001a34:	movs    	r1, #0
0x001a36:	adds    	r4, r2, #0
0x001a38:	movs    	r2, #0
0x001a3a:	str     	r1, [sp]
0x001a3c:	str     	r1, [sp, #4]
0x001a3e:	movs    	r5, #0
0x001a40:	adds    	r3, r5, #0
0x001a42:	movs    	r1, #0x1d
0x001a44:	movs    	r0, #0xf1
0x001a46:	lsls    	r0, r0, #9
0x001a48:	str     	r2, [sp, #8]
0x001a4a:	bl      	#0x326c
0x001a4e:	subs    	r7, r0, r4
0x001a50:	movs    	r1, #0
0x001a52:	str     	r1, [sp]
0x001a54:	str     	r1, [sp, #4]
0x001a56:	subs    	r7, #0x1e
0x001a58:	movs    	r2, #0
0x001a5a:	adds    	r3, r5, #0
0x001a5c:	movs    	r1, #0x1c
0x001a5e:	movs    	r0, #0xf1
0x001a60:	lsls    	r0, r0, #9
0x001a62:	str     	r2, [sp, #8]
0x001a64:	bl      	#0x326c
0x001a68:	movs    	r1, #0x24
0x001a6a:	str     	r1, [sp, #0x4c]
0x001a6c:	movs    	r1, #0
0x001a6e:	str     	r1, [sp]
0x001a70:	str     	r1, [sp, #4]
0x001a72:	adds    	r6, r0, #0
0x001a74:	movs    	r0, #0x24
0x001a76:	ldr     	r1, [pc, #0x3c0]
0x001a78:	movs    	r2, #0
0x001a7a:	str     	r2, [sp, #8]
0x001a7c:	str     	r0, [sp, #0x5c]
0x001a7e:	str     	r0, [sp, #0x58]
0x001a80:	add     	r1, sb
0x001a82:	ldr     	r0, [r1, #0x1c]
0x001a84:	movs    	r1, #0x11
0x001a86:	ldr     	r2, [r0, #0x30]
0x001a88:	movs    	r0, #0xf1
0x001a8a:	movs    	r3, #4
0x001a8c:	lsls    	r0, r0, #9
0x001a8e:	bl      	#0x326c
0x001a92:	adds    	r5, r0, #0
0x001a94:	movs    	r0, #0
0x001a96:	ldr     	r1, [pc, #0x3a0]
0x001a98:	str     	r0, [sp, #0x3c]
0x001a9a:	str     	r0, [sp, #0x38]
0x001a9c:	add     	r1, sb
0x001a9e:	str     	r5, [r1, #0x10]
0x001aa0:	cmp     	r5, #0
0x001aa2:	bgt     	#0x1b40
0x001aa4:	ldr     	r5, [pc, #0x394]
0x001aa6:	add     	r5, pc
0x001aa8:	movs    	r1, #0
0x001aaa:	str     	r1, [sp]
0x001aac:	str     	r1, [sp, #4]
0x001aae:	movs    	r2, #0
0x001ab0:	movs    	r7, #0
0x001ab2:	adds    	r3, r7, #0
0x001ab4:	movs    	r1, #0x1d
0x001ab6:	movs    	r0, #0xf1
0x001ab8:	lsls    	r0, r0, #9
0x001aba:	str     	r2, [sp, #8]
0x001abc:	bl      	#0x326c
0x001ac0:	subs    	r1, r0, r4
0x001ac2:	str     	r1, [sp, #4]
0x001ac4:	movs    	r2, #0
0x001ac6:	movs    	r1, #0x2e
0x001ac8:	movs    	r0, #0xf1
0x001aca:	adds    	r3, r4, #0
0x001acc:	lsls    	r0, r0, #9
0x001ace:	str     	r2, [sp, #8]
0x001ad0:	str     	r6, [sp]
0x001ad2:	bl      	#0x326c
0x001ad6:	add     	r2, sp, #0x30
0x001ad8:	add     	r1, sp, #0x34
0x001ada:	movs    	r0, #0
0x001adc:	str     	r0, [sp]
0x001ade:	str     	r1, [sp, #4]
0x001ae0:	str     	r2, [sp, #8]
0x001ae2:	adds    	r3, r7, #0
0x001ae4:	adds    	r2, r5, #0
0x001ae6:	movs    	r1, #0x2a
0x001ae8:	movs    	r0, #0xf1
0x001aea:	lsls    	r0, r0, #9
0x001aec:	bl      	#0x326c
0x001af0:	ldr     	r0, [sp, #0x34]
0x001af2:	adds    	r4, #0x14
0x001af4:	subs    	r0, r6, r0
0x001af6:	lsrs    	r1, r0, #0x1f
0x001af8:	adds    	r0, r1, r0
0x001afa:	asrs    	r0, r0, #1
0x001afc:	str     	r0, [sp, #0x14]
0x001afe:	movs    	r0, #0xff
0x001b00:	str     	r0, [sp, #0x20]
0x001b02:	str     	r0, [sp, #0x24]
0x001b04:	movs    	r1, #0
0x001b06:	movs    	r2, #0
0x001b08:	str     	r1, [sp]
0x001b0a:	str     	r1, [sp, #4]
0x001b0c:	str     	r0, [sp, #0x1c]
0x001b0e:	str     	r7, [sp, #0x28]
0x001b10:	str     	r2, [sp, #8]
0x001b12:	movs    	r0, #0xf1
0x001b14:	movs    	r1, #0x56
0x001b16:	adds    	r3, r7, #0
0x001b18:	lsls    	r0, r0, #9
0x001b1a:	add     	r2, sp, #0x10
0x001b1c:	str     	r4, [sp, #0x18]
0x001b1e:	str     	r5, [sp, #0x10]
0x001b20:	str     	r7, [sp, #0x2c]
0x001b22:	bl      	#0x326c
0x001b26:	movs    	r1, #0
0x001b28:	str     	r1, [sp]
0x001b2a:	str     	r1, [sp, #4]
0x001b2c:	movs    	r2, #0
0x001b2e:	movs    	r1, #0x24
0x001b30:	movs    	r3, #1
0x001b32:	movs    	r0, #0xf1
0x001b34:	lsls    	r0, r0, #9
0x001b36:	str     	r2, [sp, #8]
0x001b38:	bl      	#0x326c
0x001b3c:	add     	sp, #0x94
0x001b3e:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_001e40 =====
0x001e40:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x001e42:	sub     	sp, #0x40
0x001e44:	movs    	r1, #0
0x001e46:	movs    	r7, #0
0x001e48:	adds    	r4, r2, #0
0x001e4a:	movs    	r2, #0
0x001e4c:	str     	r1, [sp]
0x001e4e:	str     	r1, [sp, #4]
0x001e50:	movs    	r5, #0xf1
0x001e52:	lsls    	r5, r5, #9
0x001e54:	movs    	r1, #0x1c
0x001e56:	adds    	r6, r7, #0
0x001e58:	adds    	r3, r7, #0
0x001e5a:	adds    	r0, r5, #0
0x001e5c:	str     	r2, [sp, #8]
0x001e5e:	bl      	#0x326c
0x001e62:	movs    	r1, #0
0x001e64:	str     	r1, [sp]
0x001e66:	str     	r1, [sp, #4]
0x001e68:	movs    	r2, #0
0x001e6a:	movs    	r1, #0x1d
0x001e6c:	str     	r0, [sp, #0x34]
0x001e6e:	adds    	r3, r6, #0
0x001e70:	adds    	r0, r5, #0
0x001e72:	str     	r2, [sp, #8]
0x001e74:	bl      	#0x326c
0x001e78:	subs    	r0, r0, r4
0x001e7a:	movs    	r1, #0
0x001e7c:	str     	r0, [sp, #0x30]
0x001e7e:	movs    	r2, #0
0x001e80:	str     	r2, [sp, #8]
0x001e82:	movs    	r0, #0x1e
0x001e84:	str     	r1, [sp]
0x001e86:	str     	r1, [sp, #4]
0x001e88:	movs    	r1, #0xe1
0x001e8a:	str     	r0, [sp, #0x2c]
0x001e8c:	movs    	r2, #0xa3
0x001e8e:	movs    	r4, #0x6e
0x001e90:	adds    	r3, r6, #0
0x001e92:	adds    	r0, r5, #0
0x001e94:	bl      	#0x326c
0x001e98:	cmp     	r0, #0
0x001e9a:	bne     	#0x1ed2
0x001e9c:	movs    	r1, #0
0x001e9e:	str     	r1, [sp]
0x001ea0:	str     	r1, [sp, #4]
0x001ea2:	movs    	r2, #0
0x001ea4:	movs    	r1, #0x34
0x001ea6:	adds    	r3, r7, #0
0x001ea8:	adds    	r0, r5, #0
0x001eaa:	str     	r2, [sp, #8]
0x001eac:	bl      	#0x326c
0x001eb0:	movs    	r1, #0
0x001eb2:	str     	r1, [sp]
0x001eb4:	str     	r1, [sp, #4]
0x001eb6:	ldr     	r1, [pc, #0x2d8]
0x001eb8:	movs    	r2, #0
0x001eba:	str     	r2, [sp, #8]
0x001ebc:	add     	r1, sb
0x001ebe:	ldr     	r0, [r1, #0x1c]
0x001ec0:	movs    	r1, #0xff
0x001ec2:	adds    	r1, #0x2b
0x001ec4:	movs    	r2, #0xc8
0x001ec6:	ldr     	r3, [r0, #0x4c]
0x001ec8:	adds    	r0, r5, #0
0x001eca:	bl      	#0x326c
0x001ece:	add     	sp, #0x4c
0x001ed0:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00219c =====
0x00219c:	push    	{r4, r5, r6, r7, lr}
0x00219e:	ldr     	r1, [pc, #0x178]
0x0021a0:	sub     	sp, #0x3c
0x0021a2:	add     	r1, sb
0x0021a4:	ldr     	r0, [r1, #0x1c]
0x0021a6:	movs    	r1, #0
0x0021a8:	ldr     	r5, [r0, #0x44]
0x0021aa:	adds    	r4, r2, #0
0x0021ac:	movs    	r2, #0
0x0021ae:	str     	r1, [sp]
0x0021b0:	str     	r1, [sp, #4]
0x0021b2:	movs    	r7, #0xf1
0x0021b4:	lsls    	r7, r7, #9
0x0021b6:	movs    	r1, #0x1c
0x0021b8:	movs    	r3, #0
0x0021ba:	adds    	r0, r7, #0
0x0021bc:	str     	r2, [sp, #8]
0x0021be:	bl      	#0x326c
0x0021c2:	movs    	r1, #0
0x0021c4:	str     	r1, [sp]
0x0021c6:	str     	r1, [sp, #4]
0x0021c8:	movs    	r2, #0
0x0021ca:	movs    	r1, #0x1d
0x0021cc:	adds    	r6, r0, #0
0x0021ce:	movs    	r3, #0
0x0021d0:	adds    	r0, r7, #0
0x0021d2:	str     	r2, [sp, #8]
0x0021d4:	bl      	#0x326c
0x0021d8:	movs    	r1, #0
0x0021da:	subs    	r0, r0, r4
0x0021dc:	movs    	r2, #0
0x0021de:	str     	r2, [sp, #8]
0x0021e0:	subs    	r0, #0x50
0x0021e2:	str     	r1, [sp]
0x0021e4:	str     	r1, [sp, #4]
0x0021e6:	movs    	r1, #0x11
0x0021e8:	str     	r0, [sp, #0x34]
0x0021ea:	adds    	r2, r5, #0
0x0021ec:	movs    	r3, #4
0x0021ee:	adds    	r0, r7, #0
0x0021f0:	bl      	#0x326c
0x0021f4:	ldr     	r1, [pc, #0x120]
0x0021f6:	cmp     	r0, #0
0x0021f8:	add     	r1, sb
0x0021fa:	str     	r0, [r1, #0x10]
0x0021fc:	bgt     	#0x22a6
0x0021fe:	movs    	r1, #0
0x002200:	str     	r1, [sp]
0x002202:	str     	r1, [sp, #4]
0x002204:	movs    	r2, #0
0x002206:	movs    	r1, #0x1d
0x002208:	movs    	r3, #0
0x00220a:	adds    	r0, r7, #0
0x00220c:	str     	r2, [sp, #8]
0x00220e:	bl      	#0x326c
0x002212:	subs    	r1, r0, r4
0x002214:	str     	r1, [sp, #4]
0x002216:	movs    	r2, #0
0x002218:	movs    	r1, #0x2e
0x00221a:	adds    	r3, r4, #0
0x00221c:	adds    	r0, r7, #0
0x00221e:	str     	r2, [sp, #8]
0x002220:	str     	r6, [sp]
0x002222:	bl      	#0x326c
0x002226:	ldr     	r0, [pc, #0xf0]
0x002228:	add     	r0, sb
0x00222a:	ldr     	r0, [r0, #0x1c]
0x00222c:	adds    	r0, #0x80
0x00222e:	ldrb    	r0, [r0]
0x002230:	cmp     	r0, #0
0x002232:	bne     	#0x223a
0x002234:	ldr     	r5, [pc, #0xe4]
0x002236:	add     	r5, pc
0x002238:	b       	#0x223e
0x00223a:	ldr     	r5, [pc, #0xe4]
0x00223c:	add     	r5, pc
0x00223e:	add     	r2, sp, #0x2c
0x002240:	add     	r1, sp, #0x30
0x002242:	movs    	r0, #0
0x002244:	movs    	r7, #0
0x002246:	adds    	r3, r7, #0
0x002248:	str     	r0, [sp]
0x00224a:	str     	r1, [sp, #4]
0x00224c:	str     	r2, [sp, #8]
0x00224e:	adds    	r2, r5, #0
0x002250:	movs    	r1, #0x2a
0x002252:	movs    	r0, #0xf1
0x002254:	lsls    	r0, r0, #9
0x002256:	bl      	#0x326c
0x00225a:	ldr     	r0, [sp, #0x30]
0x00225c:	movs    	r1, #0
0x00225e:	subs    	r0, r6, r0
0x002260:	asrs    	r0, r0, #1
0x002262:	str     	r0, [sp, #0x10]
0x002264:	movs    	r0, #0xff
0x002266:	str     	r0, [sp, #0x20]
0x002268:	adds    	r4, #0x14
0x00226a:	str     	r7, [sp, #0x24]
0x00226c:	movs    	r2, #0
0x00226e:	str     	r1, [sp, #4]
0x002270:	str     	r1, [sp]
0x002272:	str     	r0, [sp, #0x18]
0x002274:	str     	r0, [sp, #0x1c]
0x002276:	str     	r7, [sp, #0x28]
0x002278:	str     	r2, [sp, #8]
0x00227a:	movs    	r0, #0xf1
0x00227c:	movs    	r1, #0x56
0x00227e:	adds    	r3, r7, #0
0x002280:	lsls    	r0, r0, #9
0x002282:	add     	r2, sp, #0xc
0x002284:	str     	r4, [sp, #0x14]
0x002286:	str     	r5, [sp, #0xc]
0x002288:	bl      	#0x326c
0x00228c:	movs    	r1, #0
0x00228e:	str     	r1, [sp]
0x002290:	str     	r1, [sp, #4]
0x002292:	movs    	r2, #0
0x002294:	movs    	r1, #0x24
0x002296:	movs    	r3, #1
0x002298:	movs    	r0, #0xf1
0x00229a:	lsls    	r0, r0, #9
0x00229c:	str     	r2, [sp, #8]
0x00229e:	bl      	#0x326c
0x0022a2:	add     	sp, #0x3c
0x0022a4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002324 =====
0x002324:	push    	{r4, r5, r6, r7, lr}
0x002326:	sub     	sp, #0x3c
0x002328:	movs    	r1, #0
0x00232a:	str     	r1, [sp]
0x00232c:	str     	r1, [sp, #4]
0x00232e:	movs    	r4, #0xf1
0x002330:	movs    	r6, #0
0x002332:	movs    	r2, #0
0x002334:	adds    	r3, r6, #0
0x002336:	lsls    	r4, r4, #9
0x002338:	movs    	r1, #0x1c
0x00233a:	adds    	r0, r4, #0
0x00233c:	str     	r2, [sp, #8]
0x00233e:	bl      	#0x326c
0x002342:	movs    	r1, #0
0x002344:	str     	r1, [sp]
0x002346:	str     	r1, [sp, #4]
0x002348:	movs    	r1, #0xff
0x00234a:	movs    	r2, #0
0x00234c:	adds    	r1, #0x27
0x00234e:	adds    	r3, r6, #0
0x002350:	adds    	r0, r4, #0
0x002352:	str     	r2, [sp, #8]
0x002354:	bl      	#0x326c
0x002358:	movs    	r1, #0
0x00235a:	str     	r1, [sp]
0x00235c:	str     	r1, [sp, #4]
0x00235e:	movs    	r1, #0xff
0x002360:	movs    	r2, #0
0x002362:	adds    	r1, #0x26
0x002364:	adds    	r3, r6, #0
0x002366:	adds    	r0, r4, #0
0x002368:	str     	r2, [sp, #8]
0x00236a:	bl      	#0x326c
0x00236e:	movs    	r1, #0
0x002370:	movs    	r2, #0
0x002372:	str     	r2, [sp, #8]
0x002374:	str     	r1, [sp]
0x002376:	str     	r1, [sp, #4]
0x002378:	movs    	r1, #0xe1
0x00237a:	movs    	r2, #0xed
0x00237c:	adds    	r3, r6, #0
0x00237e:	adds    	r0, r4, #0
0x002380:	bl      	#0x326c
0x002384:	cmp     	r0, #0
0x002386:	ble     	#0x246e
0x002388:	movs    	r1, #0
0x00238a:	str     	r1, [sp]
0x00238c:	str     	r1, [sp, #4]
0x00238e:	movs    	r1, #0xff
0x002390:	movs    	r2, #0
0x002392:	adds    	r1, #0x25
0x002394:	adds    	r3, r6, #0
0x002396:	adds    	r0, r4, #0
0x002398:	str     	r2, [sp, #8]
0x00239a:	bl      	#0x326c
0x00239e:	movs    	r1, #0
0x0023a0:	str     	r1, [sp]
0x0023a2:	str     	r1, [sp, #4]
0x0023a4:	movs    	r2, #0
0x0023a6:	movs    	r1, #0x40
0x0023a8:	adds    	r3, r6, #0
0x0023aa:	adds    	r0, r4, #0
0x0023ac:	str     	r2, [sp, #8]
0x0023ae:	bl      	#0x326c
0x0023b2:	movs    	r1, #0
0x0023b4:	movs    	r2, #0
0x0023b6:	str     	r2, [sp, #8]
0x0023b8:	str     	r1, [sp]
0x0023ba:	str     	r1, [sp, #4]
0x0023bc:	movs    	r1, #0xe1
0x0023be:	movs    	r2, #0x28
0x0023c0:	adds    	r3, r6, #0
0x0023c2:	adds    	r0, r4, #0
0x0023c4:	bl      	#0x326c
0x0023c8:	movs    	r1, #0
0x0023ca:	adds    	r4, r0, #0
0x0023cc:	movs    	r2, #0
0x0023ce:	str     	r2, [sp, #8]
0x0023d0:	str     	r1, [sp]
0x0023d2:	str     	r1, [sp, #4]
0x0023d4:	movs    	r1, #0xe1
0x0023d6:	movs    	r2, #0x29
0x0023d8:	movs    	r0, #0xf1
0x0023da:	adds    	r3, r6, #0
0x0023dc:	lsls    	r0, r0, #9
0x0023de:	bl      	#0x326c
0x0023e2:	add     	r2, sp, #0x30
0x0023e4:	str     	r2, [sp, #8]
0x0023e6:	ldr     	r2, [pc, #0x3e4]
0x0023e8:	add     	r1, sp, #0x34
0x0023ea:	str     	r1, [sp, #4]
0x0023ec:	adds    	r3, r0, #0
0x0023ee:	str     	r4, [sp]
0x0023f0:	add     	r2, pc
0x0023f2:	movs    	r1, #0x2a
0x0023f4:	movs    	r0, #0xf1
0x0023f6:	lsls    	r0, r0, #9
0x0023f8:	bl      	#0x326c
0x0023fc:	movs    	r1, #0
0x0023fe:	movs    	r2, #0
0x002400:	str     	r2, [sp, #8]
0x002402:	str     	r1, [sp]
0x002404:	str     	r1, [sp, #4]
0x002406:	movs    	r1, #0xe1
0x002408:	movs    	r2, #0x2a
0x00240a:	adds    	r3, r6, #0
0x00240c:	movs    	r0, #0xf1
0x00240e:	lsls    	r0, r0, #9
0x002410:	bl      	#0x326c
0x002414:	ldr     	r1, [sp, #0x30]
0x002416:	movs    	r2, #0
0x002418:	adds    	r5, r0, r1
0x00241a:	movs    	r1, #0
0x00241c:	str     	r1, [sp]
0x00241e:	str     	r1, [sp, #4]
0x002420:	movs    	r1, #0x1c
0x002422:	movs    	r0, #0xf1
0x002424:	adds    	r3, r6, #0
0x002426:	lsls    	r0, r0, #9
0x002428:	str     	r2, [sp, #8]
0x00242a:	bl      	#0x326c
0x00242e:	movs    	r2, #0
0x002430:	str     	r0, [sp]
0x002432:	movs    	r0, #0xf1
0x002434:	adds    	r3, r6, #0
0x002436:	movs    	r1, #0x32
0x002438:	lsls    	r0, r0, #9
0x00243a:	str     	r2, [sp, #8]
0x00243c:	str     	r5, [sp, #4]
0x00243e:	bl      	#0x326c
0x002442:	movs    	r1, #0
0x002444:	str     	r1, [sp]
0x002446:	str     	r1, [sp, #4]
0x002448:	movs    	r2, #0
0x00244a:	movs    	r1, #0x1c
0x00244c:	adds    	r3, r6, #0
0x00244e:	movs    	r0, #0xf1
0x002450:	lsls    	r0, r0, #9
0x002452:	str     	r2, [sp, #8]
0x002454:	bl      	#0x326c

; ===== candidate_0028d4 =====
0x0028d4:	push    	{r4, r5, r6, r7, lr}
0x0028d6:	adds    	r6, r0, #0
0x0028d8:	movs    	r0, #0
0x0028da:	mvns    	r0, r0
0x0028dc:	sub     	sp, #0x14
0x0028de:	movs    	r4, #0
0x0028e0:	cmp     	r6, #0
0x0028e2:	str     	r0, [sp, #0x10]
0x0028e4:	beq     	#0x2914
0x0028e6:	movs    	r1, #0
0x0028e8:	movs    	r2, #0
0x0028ea:	str     	r2, [sp, #8]
0x0028ec:	str     	r1, [sp]
0x0028ee:	str     	r1, [sp, #4]
0x0028f0:	movs    	r1, #0x11
0x0028f2:	adds    	r2, r6, #0
0x0028f4:	movs    	r3, #4
0x0028f6:	movs    	r0, #0xf1
0x0028f8:	lsls    	r0, r0, #9
0x0028fa:	bl      	#0x326c
0x0028fe:	adds    	r7, r0, #0
0x002900:	cmp     	r0, #0
0x002902:	ble     	#0x291e
0x002904:	lsls    	r0, r4, #2
0x002906:	ldr     	r5, [r6, r0]
0x002908:	ldr     	r0, [r5, #4]
0x00290a:	bl      	#0x2c38
0x00290e:	cmp     	r0, #0
0x002910:	beq     	#0x2918
0x002912:	ldr     	r0, [r5, #4]
0x002914:	add     	sp, #0x14
0x002916:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002964 =====
0x002964:	push    	{r4, r5, r6, r7, lr}
0x002966:	movs    	r7, #0xf1
0x002968:	lsls    	r7, r7, #9
0x00296a:	adds    	r5, r0, #0
0x00296c:	movs    	r4, #0
0x00296e:	cmp     	r0, #0
0x002970:	sub     	sp, #0xc
0x002972:	bne     	#0x2988
0x002974:	movs    	r1, #0
0x002976:	str     	r1, [sp]
0x002978:	str     	r1, [sp, #4]
0x00297a:	movs    	r2, #0
0x00297c:	movs    	r1, #0x2c
0x00297e:	adds    	r3, r4, #0
0x002980:	adds    	r0, r7, #0
0x002982:	str     	r2, [sp, #8]
0x002984:	bl      	#0x326c
0x002988:	movs    	r1, #0
0x00298a:	movs    	r2, #0
0x00298c:	str     	r2, [sp, #8]
0x00298e:	str     	r1, [sp]
0x002990:	str     	r1, [sp, #4]
0x002992:	movs    	r1, #0xe1
0x002994:	movs    	r2, #0x9a
0x002996:	adds    	r3, r4, #0
0x002998:	adds    	r0, r7, #0
0x00299a:	bl      	#0x326c
0x00299e:	cmp     	r0, #0
0x0029a0:	beq     	#0x29ba
0x0029a2:	movs    	r1, #0
0x0029a4:	movs    	r2, #0
0x0029a6:	str     	r2, [sp, #8]
0x0029a8:	str     	r1, [sp]
0x0029aa:	str     	r1, [sp, #4]
0x0029ac:	movs    	r1, #0x14
0x0029ae:	movs    	r2, #0xa4
0x0029b0:	movs    	r3, #1
0x0029b2:	adds    	r0, r7, #0
0x0029b4:	bl      	#0x326c
0x0029b8:	b       	#0x29d0
0x0029ba:	movs    	r1, #0
0x0029bc:	movs    	r2, #0
0x0029be:	str     	r2, [sp, #8]
0x0029c0:	str     	r1, [sp]
0x0029c2:	str     	r1, [sp, #4]
0x0029c4:	movs    	r1, #0x14
0x0029c6:	movs    	r2, #0xa4
0x0029c8:	adds    	r3, r4, #0
0x0029ca:	adds    	r0, r7, #0
0x0029cc:	bl      	#0x326c
0x0029d0:	movs    	r1, #0
0x0029d2:	movs    	r2, #0
0x0029d4:	str     	r2, [sp, #8]
0x0029d6:	str     	r1, [sp]
0x0029d8:	str     	r1, [sp, #4]
0x0029da:	movs    	r1, #0x14
0x0029dc:	movs    	r2, #0xee
0x0029de:	adds    	r3, r4, #0
0x0029e0:	adds    	r0, r7, #0
0x0029e2:	bl      	#0x326c
0x0029e6:	movs    	r1, #0
0x0029e8:	str     	r1, [sp]
0x0029ea:	str     	r1, [sp, #4]
0x0029ec:	movs    	r2, #0
0x0029ee:	movs    	r1, #0xe6
0x0029f0:	adds    	r3, r4, #0
0x0029f2:	movs    	r0, #0xf1
0x0029f4:	lsls    	r0, r0, #9
0x0029f6:	str     	r2, [sp, #8]
0x0029f8:	bl      	#0x326c
0x0029fc:	ldr     	r6, [pc, #0x230]
0x0029fe:	movs    	r1, #0
0x002a00:	add     	r6, sb
0x002a02:	str     	r4, [r6, #0x18]
0x002a04:	str     	r4, [r6, #0xc]
0x002a06:	movs    	r2, #0
0x002a08:	str     	r2, [sp, #8]
0x002a0a:	str     	r1, [sp]
0x002a0c:	str     	r1, [sp, #4]
0x002a0e:	movs    	r1, #0xe1
0x002a10:	movs    	r2, #0xa2
0x002a12:	adds    	r3, r4, #0
0x002a14:	movs    	r0, #0xf1
0x002a16:	lsls    	r0, r0, #9
0x002a18:	bl      	#0x326c
0x002a1c:	movs    	r1, #0
0x002a1e:	movs    	r2, #0
0x002a20:	str     	r2, [sp, #8]
0x002a22:	str     	r1, [sp]
0x002a24:	str     	r1, [sp, #4]
0x002a26:	adds    	r3, r0, #0
0x002a28:	movs    	r0, #0xf1
0x002a2a:	movs    	r1, #0x14
0x002a2c:	movs    	r2, #0x17
0x002a2e:	lsls    	r0, r0, #9
0x002a30:	bl      	#0x326c
0x002a34:	str     	r4, [r6, #8]
0x002a36:	str     	r5, [r6, #0x1c]
0x002a38:	movs    	r1, #0
0x002a3a:	movs    	r2, #0
0x002a3c:	str     	r2, [sp, #8]
0x002a3e:	str     	r1, [sp]
0x002a40:	str     	r1, [sp, #4]
0x002a42:	movs    	r1, #0x14
0x002a44:	movs    	r2, #0xa3
0x002a46:	adds    	r3, r4, #0
0x002a48:	movs    	r0, #0xf1
0x002a4a:	lsls    	r0, r0, #9
0x002a4c:	bl      	#0x326c
0x002a50:	movs    	r1, #0
0x002a52:	movs    	r2, #0
0x002a54:	str     	r2, [sp, #8]
0x002a56:	str     	r1, [sp]
0x002a58:	str     	r1, [sp, #4]
0x002a5a:	movs    	r1, #0xe1
0x002a5c:	movs    	r2, #0x9b
0x002a5e:	adds    	r3, r4, #0
0x002a60:	movs    	r0, #0xf1
0x002a62:	lsls    	r0, r0, #9
0x002a64:	bl      	#0x326c
0x002a68:	movs    	r1, #0
0x002a6a:	adds    	r6, r0, #0
0x002a6c:	movs    	r2, #0
0x002a6e:	str     	r2, [sp, #8]
0x002a70:	str     	r1, [sp]
0x002a72:	str     	r1, [sp, #4]
0x002a74:	movs    	r1, #0xe1
0x002a76:	movs    	r2, #0x9c
0x002a78:	movs    	r0, #0xf1
0x002a7a:	adds    	r3, r4, #0
0x002a7c:	lsls    	r0, r0, #9
0x002a7e:	bl      	#0x326c
0x002a82:	movs    	r2, #0
0x002a84:	mvns    	r1, r2
0x002a86:	str     	r2, [sp, #8]
0x002a88:	adds    	r2, r0, #0
0x002a8a:	movs    	r0, #0xf1
0x002a8c:	str     	r1, [sp]
0x002a8e:	str     	r1, [sp, #4]
0x002a90:	movs    	r1, #5
0x002a92:	lsls    	r0, r0, #9

; ===== candidate_002c38 =====
0x002c38:	push    	{r4, r5, r6, r7, lr}
0x002c3a:	sub     	sp, #0xc
0x002c3c:	movs    	r2, #0
0x002c3e:	movs    	r1, #0
0x002c40:	str     	r2, [sp, #8]
0x002c42:	movs    	r2, #0xff
0x002c44:	str     	r1, [sp]
0x002c46:	str     	r1, [sp, #4]
0x002c48:	movs    	r7, #0xf1
0x002c4a:	lsls    	r7, r7, #9
0x002c4c:	movs    	r1, #0xe1
0x002c4e:	adds    	r2, #0x22
0x002c50:	adds    	r6, r0, #0
0x002c52:	movs    	r3, #0
0x002c54:	adds    	r0, r7, #0
0x002c56:	bl      	#0x326c
0x002c5a:	movs    	r1, #0
0x002c5c:	movs    	r2, #0
0x002c5e:	str     	r2, [sp, #8]
0x002c60:	str     	r1, [sp]
0x002c62:	str     	r1, [sp, #4]
0x002c64:	movs    	r1, #0x11
0x002c66:	adds    	r2, r0, #0
0x002c68:	movs    	r3, #4
0x002c6a:	adds    	r0, r7, #0
0x002c6c:	bl      	#0x326c
0x002c70:	adds    	r5, r0, #0
0x002c72:	movs    	r4, #0
0x002c74:	cmp     	r0, #0
0x002c76:	ble     	#0x2caa
0x002c78:	movs    	r7, #0
0x002c7a:	movs    	r2, #0
0x002c7c:	movs    	r1, #0
0x002c7e:	str     	r2, [sp, #8]
0x002c80:	movs    	r2, #0xff
0x002c82:	str     	r1, [sp]
0x002c84:	str     	r1, [sp, #4]
0x002c86:	adds    	r3, r7, #0
0x002c88:	adds    	r2, #0x22
0x002c8a:	movs    	r1, #0xe1
0x002c8c:	movs    	r0, #0xf1
0x002c8e:	lsls    	r0, r0, #9
0x002c90:	bl      	#0x326c
0x002c94:	lsls    	r1, r4, #2
0x002c96:	ldr     	r0, [r0, r1]
0x002c98:	ldr     	r0, [r0]
0x002c9a:	cmp     	r0, r6
0x002c9c:	bne     	#0x2ca4
0x002c9e:	movs    	r0, #1
0x002ca0:	add     	sp, #0xc
0x002ca2:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002cb0 =====
0x002cb0:	push    	{r4, r5, r6, r7, lr}
0x002cb2:	sub     	sp, #0xc
0x002cb4:	movs    	r1, #0
0x002cb6:	adds    	r7, r0, #0
0x002cb8:	str     	r1, [sp]
0x002cba:	str     	r1, [sp, #4]
0x002cbc:	movs    	r4, #0
0x002cbe:	movs    	r2, #0
0x002cc0:	adds    	r3, r4, #0
0x002cc2:	movs    	r1, #0xe6
0x002cc4:	movs    	r0, #0xf1
0x002cc6:	lsls    	r0, r0, #9
0x002cc8:	str     	r2, [sp, #8]
0x002cca:	bl      	#0x326c
0x002cce:	movs    	r1, #0
0x002cd0:	movs    	r2, #0
0x002cd2:	str     	r2, [sp, #8]
0x002cd4:	str     	r1, [sp]
0x002cd6:	str     	r1, [sp, #4]
0x002cd8:	movs    	r1, #0x14
0x002cda:	movs    	r2, #0xee
0x002cdc:	adds    	r3, r4, #0
0x002cde:	movs    	r0, #0xf1
0x002ce0:	lsls    	r0, r0, #9
0x002ce2:	bl      	#0x326c
0x002ce6:	subs    	r0, r7, #4
0x002ce8:	cmp     	r0, #0x11
0x002cea:	bhs     	#0x2cf6
0x002cec:	adr     	r3, #0xc
0x002cee:	adds    	r3, r3, r0
0x002cf0:	ldrh    	r3, [r3, r0]
0x002cf2:	lsls    	r3, r3, #1
0x002cf4:	add     	pc, r3
0x002cf6:	add     	sp, #0xc
0x002cf8:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0031dc =====
0x0031dc:	push    	{r3, r4, r5, lr}
0x0031de:	ldr     	r4, [pc, #0x74]
0x0031e0:	add     	r4, pc
0x0031e2:	ldr     	r0, [r4, #0x38]
0x0031e4:	movs    	r1, #0x14
0x0031e6:	ldr     	r2, [r0, #0x64]
0x0031e8:	ldr     	r0, [pc, #0x6c]
0x0031ea:	add     	r0, pc
0x0031ec:	blx     	r2
0x0031ee:	movs    	r5, #0
0x0031f0:	mvns    	r5, r5
0x0031f2:	cmp     	r0, r5
0x0031f4:	bne     	#0x31fa
0x0031f6:	adds    	r0, r5, #0
0x0031f8:	pop     	{r3, r4, r5, pc}

; ===== candidate_00326c =====
0x00326c:	push    	{r4, r5, r6, r7, lr}
0x00326e:	adds    	r5, r1, #0
0x003270:	adds    	r4, r0, #0
0x003272:	adds    	r6, r2, #0
0x003274:	ldr     	r2, [pc, #0x28]
0x003276:	sub     	sp, #0x14
0x003278:	mov     	ip, r3
0x00327a:	add     	r2, pc
0x00327c:	ldr     	r0, [sp, #0x2c]
0x00327e:	ldr     	r1, [sp, #0x30]
0x003280:	ldr     	r7, [sp, #0x28]
0x003282:	ldr     	r3, [r2, #0x3c]
0x003284:	movs    	r2, #2
0x003286:	str     	r2, [sp, #0xc]
0x003288:	str     	r1, [sp, #8]
0x00328a:	str     	r0, [sp, #4]
0x00328c:	str     	r7, [sp]
0x00328e:	ldr     	r0, [r3, #0xc]
0x003290:	adds    	r1, r5, #0
0x003292:	adds    	r2, r6, #0
0x003294:	ldr     	r7, [r0, #0x28]
0x003296:	adds    	r0, r4, #0
0x003298:	mov     	r3, ip
0x00329a:	blx     	r7
0x00329c:	add     	sp, #0x14
0x00329e:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0032a8 =====
0x0032a8:	push    	{r4, lr}
0x0032aa:	movs    	r2, #0
0x0032ac:	add     	r0, pc
0x0032ae:	ldr     	r4, [r0, #0x3c]
0x0032b0:	sub     	sp, #0x10
0x0032b2:	movs    	r1, #0
0x0032b4:	str     	r1, [sp, #4]
0x0032b6:	str     	r1, [sp, #8]
0x0032b8:	str     	r2, [sp, #0xc]
0x0032ba:	str     	r2, [sp]
0x0032bc:	ldr     	r0, [r4, #0xc]
0x0032be:	ldr     	r2, [r0, #0x24]
0x0032c0:	ldr     	r4, [r0, #0x28]
0x0032c2:	blx     	r4
0x0032c4:	add     	sp, #0x10
0x0032c6:	pop     	{r4, pc}

; ===== candidate_0032cc =====
0x0032cc:	push    	{r4, lr}
0x0032ce:	ldr     	r0, [pc, #0x24]
0x0032d0:	sub     	sp, #0x10
0x0032d2:	add     	r0, pc
0x0032d4:	ldr     	r3, [r0, #0x3c]
0x0032d6:	movs    	r2, #0
0x0032d8:	movs    	r1, #0
0x0032da:	str     	r1, [sp, #4]
0x0032dc:	str     	r1, [sp, #8]
0x0032de:	str     	r2, [sp, #0xc]
0x0032e0:	str     	r2, [sp]
0x0032e2:	ldr     	r0, [r3, #0xc]
0x0032e4:	movs    	r3, #0
0x0032e6:	ldr     	r2, [r0, #0x24]
0x0032e8:	ldr     	r4, [r0, #0x28]
0x0032ea:	movs    	r1, #1
0x0032ec:	blx     	r4
0x0032ee:	add     	sp, #0x10
0x0032f0:	pop     	{r4, pc}

; ===== candidate_00330c =====
0x00330c:	push    	{r4, lr}
0x00330e:	sub     	sp, #0x10
0x003310:	movs    	r2, #0
0x003312:	movs    	r1, #0
0x003314:	str     	r2, [sp, #8]
0x003316:	ldr     	r2, [pc, #0x3c]
0x003318:	str     	r1, [sp]
0x00331a:	str     	r1, [sp, #4]
0x00331c:	movs    	r3, #0
0x00331e:	add     	r2, pc
0x003320:	ldr     	r1, [pc, #0x34]
0x003322:	ldr     	r0, [pc, #0x38]
0x003324:	bl      	#0x326c
0x003328:	ldr     	r3, [pc, #0x38]
0x00332a:	ldr     	r4, [pc, #0x34]
0x00332c:	add     	r3, sb
0x00332e:	ldr     	r3, [r3]
0x003330:	movs    	r2, #0x41
0x003332:	movs    	r1, #0
0x003334:	add     	r4, sb
0x003336:	adds    	r0, r4, #0
0x003338:	blx     	r3
0x00333a:	bl      	#0x32f8
0x00333e:	ldr     	r3, [pc, #0x28]
0x003340:	adds    	r1, r0, #0
0x003342:	add     	r3, sb
0x003344:	ldr     	r3, [r3]
0x003346:	movs    	r2, #0x41
0x003348:	adds    	r0, r4, #0
0x00334a:	blx     	r3
0x00334c:	movs    	r0, #0
0x00334e:	add     	sp, #0x10
0x003350:	pop     	{r4, pc}

; ===== candidate_003370 =====
0x003370:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x003372:	adds    	r7, r3, #0
0x003374:	adds    	r6, r2, #0
0x003376:	adds    	r5, r0, #0
0x003378:	ldr     	r0, [r0]
0x00337a:	sub     	sp, #4
0x00337c:	mov     	r1, sb
0x00337e:	str     	r1, [sp]
0x003380:	movs    	r4, #0
0x003382:	blx     	#0x2e0
0x003386:	ldr     	r0, [sp, #8]
0x003388:	cmp     	r0, #0xb
0x00338a:	bhs     	#0x33f8
0x00338c:	adr     	r3, #4
0x00338e:	ldrb    	r3, [r3, r0]
0x003390:	lsls    	r3, r3, #1
0x003392:	add     	pc, r3
0x003394:	lsrs    	r5, r0, #0x1c
0x003396:	subs    	r4, r3, #4
0x003398:	movs    	r4, #0x21
0x00339a:	adds    	r1, #0x27
0x00339c:	adds    	r1, #0x2b
0x00339e:	movs    	r7, r5
0x0033a0:	ldr     	r1, [pc, #0x60]
0x0033a2:	ldr     	r0, [r5, #0xc]
0x0033a4:	add     	r1, sb
0x0033a6:	str     	r0, [r1, #0x14]
0x0033a8:	bl      	#0x308
0x0033ac:	bl      	#0x330c
0x0033b0:	adds    	r4, r0, #0
0x0033b2:	b       	#0x33f8
0x0033b4:	ldr     	r0, [r6]
0x0033b6:	cmp     	r0, #8
0x0033b8:	bne     	#0x33c2
0x0033ba:	bl      	#0x3268
0x0033be:	adds    	r4, r0, #0
0x0033c0:	b       	#0x33f8
0x0033c2:	ldr     	r1, [r6, #4]
0x0033c4:	ldr     	r2, [r6, #8]
0x0033c6:	bl      	#0x3264
0x0033ca:	adds    	r4, r0, #0
0x0033cc:	b       	#0x33f8
0x0033ce:	bl      	#0x3600
0x0033d2:	b       	#0x33f8
0x0033d4:	str     	r7, [r5, #0xc]
0x0033d6:	b       	#0x33f8
0x0033d8:	bl      	#0x336c
0x0033dc:	b       	#0x33f8
0x0033de:	bl      	#0x343c
0x0033e2:	b       	#0x33f8
0x0033e4:	ldr     	r0, [pc, #0x1c]
0x0033e6:	add     	r0, sb
0x0033e8:	str     	r7, [r0, #0x1c]
0x0033ea:	b       	#0x33f8
0x0033ec:	ldr     	r0, [pc, #0x14]
0x0033ee:	add     	r0, sb
0x0033f0:	str     	r6, [r0, #0x20]
0x0033f2:	b       	#0x33f8
0x0033f4:	ldr     	r4, [pc, #0x10]
0x0033f6:	add     	r4, pc
0x0033f8:	ldr     	r1, [sp]
0x0033fa:	add     	sp, #0x14
0x0033fc:	adds    	r0, r4, #0
0x0033fe:	mov     	sb, r1
0x003400:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00340c =====
0x00340c:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00340e:	sub     	sp, #0xc
0x003410:	ldr     	r0, [sp, #0x38]
0x003412:	ldr     	r4, [sp, #0x3c]
0x003414:	ldr     	r6, [sp, #0x34]
0x003416:	ldr     	r0, [r0]
0x003418:	mov     	r7, sb
0x00341a:	movs    	r5, #0
0x00341c:	blx     	#0x2e0
0x003420:	cmp     	r4, #0
0x003422:	beq     	#0x3432
0x003424:	ldr     	r1, [sp, #0x30]
0x003426:	str     	r6, [sp, #4]
0x003428:	add     	r3, sp, #0xc
0x00342a:	str     	r1, [sp]
0x00342c:	ldm     	r3, {r0, r1, r2, r3}
0x00342e:	blx     	r4
0x003430:	adds    	r5, r0, #0
0x003432:	mov     	sb, r7
0x003434:	adds    	r0, r5, #0
0x003436:	add     	sp, #0x1c
0x003438:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0034a0 =====
0x0034a0:	push    	{r3, r4, r5, r6, r7, lr}
0x0034a2:	adds    	r4, r0, #0
0x0034a4:	ldr     	r0, [pc, #0x10c]
0x0034a6:	movs    	r5, #0
0x0034a8:	mvns    	r5, r5
0x0034aa:	mov     	ip, r2
0x0034ac:	add     	r0, pc
0x0034ae:	ldr     	r2, [r0, #0x38]
0x0034b0:	cmp     	r4, #0
0x0034b2:	bne     	#0x34c4
0x0034b4:	ldr     	r0, [pc, #0x100]
0x0034b6:	ldr     	r2, [r2, #0x68]
0x0034b8:	movs    	r1, #0x7d
0x0034ba:	lsls    	r1, r1, #3
0x0034bc:	add     	r0, pc
0x0034be:	blx     	r2
0x0034c0:	adds    	r0, r5, #0
0x0034c2:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_0035cc =====
0x0035cc:	push    	{r3, r4, r5, lr}
0x0035ce:	ldr     	r4, [pc, #0x28]
0x0035d0:	adds    	r5, r0, #0
0x0035d2:	add     	r4, pc
0x0035d4:	ldr     	r0, [r4, #0x38]
0x0035d6:	adds    	r0, #0x80
0x0035d8:	ldr     	r0, [r0, #4]
0x0035da:	blx     	r0
0x0035dc:	adds    	r0, r0, r5
0x0035de:	ldr     	r1, [pc, #0x1c]
0x0035e0:	add     	r1, sb
0x0035e2:	str     	r0, [r1, #0x10]
0x0035e4:	ldr     	r0, [r4, #0x38]
0x0035e6:	adds    	r0, #0x80
0x0035e8:	ldr     	r0, [r0]
0x0035ea:	blx     	r0
0x0035ec:	ldr     	r0, [r4, #0x38]
0x0035ee:	ldr     	r1, [r0, #0x7c]
0x0035f0:	lsls    	r0, r5, #0x10
0x0035f2:	lsrs    	r0, r0, #0x10
0x0035f4:	blx     	r1
0x0035f6:	pop     	{r3, r4, r5, pc}

; ===== candidate_003602 =====
0x003602:	push    	{r3, r4, r5, r6, r7, lr}
0x003604:	add     	r0, pc
0x003606:	ldr     	r0, [r0, #0x38]
0x003608:	adds    	r0, #0x80
0x00360a:	ldr     	r0, [r0, #4]
0x00360c:	blx     	r0
0x00360e:	movs    	r5, #0
0x003610:	ldr     	r6, [pc, #0xc8]
0x003612:	add     	r6, sb
0x003614:	ldr     	r1, [r6, #0x10]
0x003616:	str     	r5, [r6, #0x10]
0x003618:	subs    	r1, r0, r1
0x00361a:	ldr     	r0, [r6, #8]
0x00361c:	adds    	r3, r1, #0
0x00361e:	cmp     	r0, #0
0x003620:	beq     	#0x36d6
0x003622:	ldr     	r2, [r0, #8]
0x003624:	cmp     	r2, #0
0x003626:	bne     	#0x3686
0x003628:	mvns    	r7, r2
0x00362a:	str     	r7, [r0, #8]
0x00362c:	ldr     	r2, [r0, #0x18]
0x00362e:	adds    	r4, r0, #0
0x003630:	cmp     	r1, #0x32
0x003632:	str     	r2, [r6, #8]
0x003634:	bge     	#0x363a
0x003636:	movs    	r1, #0x32
0x003638:	b       	#0x3656
0x00363a:	movs    	r2, #0x7d
0x00363c:	lsls    	r2, r2, #4
0x00363e:	cmp     	r1, r2
0x003640:	ble     	#0x3656
0x003642:	adds    	r1, r2, #0
0x003644:	b       	#0x3656
0x003646:	movs    	r7, #0
0x003648:	mvns    	r7, r7
0x00364a:	str     	r7, [r2, #8]
0x00364c:	ldr     	r2, [r0, #0x18]
0x00364e:	str     	r2, [r0, #0x1c]
0x003650:	ldr     	r0, [r2, #0x18]
0x003652:	str     	r0, [r6, #8]
0x003654:	adds    	r0, r2, #0
0x003656:	ldr     	r2, [r0, #0x18]
0x003658:	cmp     	r2, #0
0x00365a:	beq     	#0x3662
0x00365c:	ldr     	r7, [r2, #8]
0x00365e:	cmp     	r7, r1
0x003660:	blt     	#0x3646
0x003662:	str     	r5, [r0, #0x1c]
0x003664:	ldr     	r0, [r6, #8]
0x003666:	cmp     	r0, #0
0x003668:	beq     	#0x36ca
0x00366a:	cmp     	r3, #0
0x00366c:	bge     	#0x3670
0x00366e:	movs    	r3, #0
0x003670:	ldr     	r0, [r6, #8]
0x003672:	ldr     	r1, [r0, #8]
0x003674:	cmp     	r1, #0
0x003676:	bge     	#0x367c
0x003678:	movs    	r1, #0
0x00367a:	str     	r5, [r0, #8]
0x00367c:	ldr     	r2, [pc, #0x60]
0x00367e:	cmp     	r1, r2
0x003680:	ble     	#0x368a
0x003682:	adds    	r1, r2, #0
0x003684:	b       	#0x368a
0x003686:	movs    	r4, #0
0x003688:	b       	#0x366a
0x00368a:	ldr     	r2, [r0, #8]
0x00368c:	subs    	r2, r2, r1
0x00368e:	str     	r2, [r0, #8]
0x003690:	ldr     	r0, [r0, #0x18]
0x003692:	cmp     	r0, #0
0x003694:	bne     	#0x368a
0x003696:	subs    	r0, r1, r3
0x003698:	cmp     	r0, #0
0x00369a:	bgt     	#0x369e
0x00369c:	movs    	r0, #0xa
0x00369e:	bl      	#0x35cc
0x0036a2:	b       	#0x36ca
0x0036a4:	str     	r5, [r4, #8]
0x0036a6:	ldr     	r0, [r4, #0x1c]
0x0036a8:	adds    	r3, r5, #0
0x0036aa:	str     	r0, [r6, #0xc]
0x0036ac:	ldr     	r0, [r4, #0x14]
0x0036ae:	cmp     	r0, #0
0x0036b0:	beq     	#0x36be
0x0036b2:	str     	r0, [sp]
0x0036b4:	movs    	r1, #0
0x0036b6:	adds    	r0, r4, #0
0x0036b8:	ldr     	r2, [r4, #0x10]
0x0036ba:	bl      	#0x34a0
0x0036be:	ldr     	r1, [r4, #0xc]
0x0036c0:	cmp     	r1, #0
0x0036c2:	beq     	#0x36c8
0x0036c4:	ldr     	r0, [r4, #0x10]
0x0036c6:	blx     	r1
0x0036c8:	ldr     	r4, [r6, #0xc]
0x0036ca:	cmp     	r4, #0
0x0036cc:	beq     	#0x36d4
0x0036ce:	ldr     	r0, [r4, #8]
0x0036d0:	cmp     	r0, #0
0x0036d2:	blt     	#0x36a4
0x0036d4:	str     	r5, [r6, #0xc]
0x0036d6:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_0036e4 =====
0x0036e4:	push    	{r4, r5, r6, r7, lr}
0x0036e6:	sub     	sp, #0xa4
0x0036e8:	movs    	r6, #0
0x0036ea:	adds    	r4, r0, #0
0x0036ec:	mvns    	r0, r6
0x0036ee:	str     	r0, [sp, #0x44]
0x0036f0:	str     	r0, [sp, #0x40]
0x0036f2:	movs    	r0, #0
0x0036f4:	movs    	r1, #0
0x0036f6:	str     	r1, [sp, #0x48]
0x0036f8:	str     	r1, [sp, #4]
0x0036fa:	str     	r0, [sp, #0x3c]
0x0036fc:	movs    	r2, #0
0x0036fe:	str     	r0, [sp, #0x1c]
0x003700:	str     	r0, [sp, #0x34]
0x003702:	str     	r0, [sp, #0x30]
0x003704:	str     	r0, [sp]
0x003706:	movs    	r5, #0xf1
0x003708:	movs    	r7, #0
0x00370a:	adds    	r3, r7, #0
0x00370c:	lsls    	r5, r5, #9
0x00370e:	str     	r2, [sp, #8]
0x003710:	movs    	r1, #0x45
0x003712:	adds    	r0, r5, #0
0x003714:	ldr     	r2, [r4, #8]
0x003716:	bl      	#0x326c
0x00371a:	movs    	r1, #0
0x00371c:	str     	r1, [sp]
0x00371e:	str     	r1, [sp, #4]
0x003720:	movs    	r2, #0
0x003722:	str     	r0, [sp, #0x9c]
0x003724:	str     	r2, [sp, #8]
0x003726:	movs    	r1, #0x45
0x003728:	adds    	r3, r7, #0
0x00372a:	adds    	r0, r5, #0
0x00372c:	ldr     	r2, [r4, #8]
0x00372e:	bl      	#0x326c
0x003732:	movs    	r1, #0
0x003734:	str     	r1, [sp]
0x003736:	str     	r1, [sp, #4]
0x003738:	movs    	r2, #0
0x00373a:	str     	r0, [sp, #0x98]
0x00373c:	str     	r2, [sp, #8]
0x00373e:	movs    	r1, #0x47
0x003740:	adds    	r3, r7, #0
0x003742:	adds    	r0, r5, #0
0x003744:	ldr     	r2, [r4, #8]
0x003746:	bl      	#0x326c
0x00374a:	movs    	r1, #0
0x00374c:	str     	r0, [sp, #0xa0]
0x00374e:	str     	r1, [sp]
0x003750:	str     	r1, [sp, #4]
0x003752:	movs    	r2, #0
0x003754:	str     	r2, [sp, #8]
0x003756:	movs    	r1, #0x45
0x003758:	adds    	r3, r7, #0
0x00375a:	adds    	r0, r5, #0
0x00375c:	ldr     	r2, [r4, #8]
0x00375e:	bl      	#0x326c
0x003762:	movs    	r1, #0
0x003764:	str     	r1, [sp]
0x003766:	str     	r1, [sp, #4]
0x003768:	movs    	r2, #0
0x00376a:	str     	r0, [sp, #0x90]
0x00376c:	str     	r2, [sp, #8]
0x00376e:	movs    	r1, #0x45
0x003770:	adds    	r3, r7, #0
0x003772:	adds    	r0, r5, #0
0x003774:	ldr     	r2, [r4, #8]
0x003776:	bl      	#0x326c
0x00377a:	movs    	r1, #0
0x00377c:	str     	r1, [sp]
0x00377e:	str     	r1, [sp, #4]
0x003780:	movs    	r2, #0
0x003782:	str     	r0, [sp, #0x8c]
0x003784:	str     	r2, [sp, #8]
0x003786:	movs    	r1, #0x45
0x003788:	adds    	r3, r7, #0
0x00378a:	adds    	r0, r5, #0
0x00378c:	ldr     	r2, [r4, #8]
0x00378e:	bl      	#0x326c
0x003792:	movs    	r1, #0
0x003794:	str     	r1, [sp]
0x003796:	str     	r1, [sp, #4]
0x003798:	str     	r0, [sp, #0x88]
0x00379a:	movs    	r2, #0
0x00379c:	str     	r2, [sp, #8]
0x00379e:	movs    	r1, #0x45
0x0037a0:	adds    	r3, r7, #0
0x0037a2:	adds    	r0, r5, #0
0x0037a4:	ldr     	r2, [r4, #8]
0x0037a6:	bl      	#0x326c
0x0037aa:	movs    	r1, #0
0x0037ac:	movs    	r2, #0
0x0037ae:	str     	r2, [sp, #8]
0x0037b0:	str     	r1, [sp]
0x0037b2:	str     	r1, [sp, #4]
0x0037b4:	movs    	r1, #0x48
0x0037b6:	adds    	r2, r4, #0
0x0037b8:	str     	r0, [sp, #0x94]
0x0037ba:	adds    	r3, r7, #0
0x0037bc:	adds    	r0, r5, #0
0x0037be:	bl      	#0x326c
0x0037c2:	movs    	r1, #0
0x0037c4:	str     	r1, [sp]
0x0037c6:	str     	r1, [sp, #4]
0x0037c8:	movs    	r2, #0
0x0037ca:	str     	r0, [sp, #0x74]
0x0037cc:	str     	r2, [sp, #8]
0x0037ce:	movs    	r1, #0x45
0x0037d0:	adds    	r3, r7, #0
0x0037d2:	adds    	r0, r5, #0
0x0037d4:	ldr     	r2, [r4, #8]
0x0037d6:	bl      	#0x326c
0x0037da:	movs    	r1, #0
0x0037dc:	str     	r0, [sp, #0x84]
0x0037de:	str     	r1, [sp, #4]
0x0037e0:	str     	r1, [sp]
0x0037e2:	movs    	r2, #0
0x0037e4:	str     	r2, [sp, #8]
0x0037e6:	movs    	r1, #0x45
0x0037e8:	adds    	r3, r7, #0
0x0037ea:	adds    	r0, r5, #0
0x0037ec:	ldr     	r2, [r4, #8]
0x0037ee:	bl      	#0x326c
0x0037f2:	movs    	r1, #0
0x0037f4:	str     	r0, [sp, #0x80]
0x0037f6:	str     	r1, [sp]
0x0037f8:	str     	r1, [sp, #4]
0x0037fa:	movs    	r2, #0
0x0037fc:	str     	r2, [sp, #8]
0x0037fe:	movs    	r1, #0x45
0x003800:	adds    	r3, r7, #0
0x003802:	adds    	r0, r5, #0
0x003804:	ldr     	r2, [r4, #8]
0x003806:	bl      	#0x326c
0x00380a:	movs    	r1, #0
0x00380c:	str     	r1, [sp]
0x00380e:	str     	r1, [sp, #4]
0x003810:	movs    	r2, #0
0x003812:	str     	r0, [sp, #0x7c]

; ===== candidate_003d20 =====
0x003d20:	push    	{r4, r5, r6, r7, lr}
0x003d22:	ldr     	r4, [pc, #0x3e0]
0x003d24:	movs    	r7, #0xf1
0x003d26:	add     	r4, sb
0x003d28:	ldr     	r0, [r4, #0x14]
0x003d2a:	lsls    	r7, r7, #9
0x003d2c:	movs    	r6, #0
0x003d2e:	cmp     	r0, #0
0x003d30:	sub     	sp, #0x14
0x003d32:	beq     	#0x3d68
0x003d34:	adds    	r0, #0x80
0x003d36:	ldr     	r3, [r0, #0x3c]
0x003d38:	cmp     	r3, #0
0x003d3a:	beq     	#0x3d52
0x003d3c:	movs    	r2, #0
0x003d3e:	movs    	r1, #0
0x003d40:	str     	r2, [sp, #8]
0x003d42:	adds    	r2, r3, #0
0x003d44:	str     	r1, [sp]
0x003d46:	str     	r1, [sp, #4]
0x003d48:	movs    	r1, #9
0x003d4a:	adds    	r3, r6, #0
0x003d4c:	adds    	r0, r7, #0
0x003d4e:	bl      	#0x326c
0x003d52:	movs    	r1, #0
0x003d54:	str     	r1, [sp]
0x003d56:	str     	r1, [sp, #4]
0x003d58:	movs    	r2, #0
0x003d5a:	str     	r2, [sp, #8]
0x003d5c:	movs    	r1, #9
0x003d5e:	adds    	r3, r6, #0
0x003d60:	adds    	r0, r7, #0
0x003d62:	ldr     	r2, [r4, #0x14]
0x003d64:	bl      	#0x326c
0x003d68:	str     	r6, [r4, #0x14]
0x003d6a:	movs    	r1, #0
0x003d6c:	movs    	r2, #0
0x003d6e:	str     	r2, [sp, #8]
0x003d70:	str     	r1, [sp]
0x003d72:	str     	r1, [sp, #4]
0x003d74:	movs    	r1, #0xe1
0x003d76:	movs    	r2, #0x9c
0x003d78:	adds    	r3, r6, #0
0x003d7a:	adds    	r0, r7, #0
0x003d7c:	bl      	#0x326c
0x003d80:	cmp     	r0, #0
0x003d82:	beq     	#0x3dca
0x003d84:	movs    	r1, #0
0x003d86:	movs    	r2, #0
0x003d88:	str     	r2, [sp, #8]
0x003d8a:	str     	r1, [sp]
0x003d8c:	str     	r1, [sp, #4]
0x003d8e:	movs    	r1, #0xe1
0x003d90:	movs    	r2, #0x9c
0x003d92:	adds    	r3, r6, #0
0x003d94:	adds    	r0, r7, #0
0x003d96:	bl      	#0x326c
0x003d9a:	movs    	r2, #0
0x003d9c:	movs    	r1, #0
0x003d9e:	str     	r2, [sp, #8]
0x003da0:	adds    	r3, r6, #0
0x003da2:	adds    	r2, r0, #0
0x003da4:	str     	r1, [sp]
0x003da6:	str     	r1, [sp, #4]
0x003da8:	movs    	r1, #6
0x003daa:	movs    	r0, #0xf1
0x003dac:	lsls    	r0, r0, #9
0x003dae:	bl      	#0x326c
0x003db2:	movs    	r1, #0
0x003db4:	movs    	r2, #0
0x003db6:	str     	r2, [sp, #8]
0x003db8:	str     	r1, [sp]
0x003dba:	str     	r1, [sp, #4]
0x003dbc:	movs    	r1, #0x14
0x003dbe:	movs    	r2, #0x9c
0x003dc0:	adds    	r3, r6, #0
0x003dc2:	movs    	r0, #0xf1
0x003dc4:	lsls    	r0, r0, #9
0x003dc6:	bl      	#0x326c
0x003dca:	movs    	r1, #0
0x003dcc:	movs    	r2, #0
0x003dce:	str     	r2, [sp, #8]
0x003dd0:	str     	r1, [sp]
0x003dd2:	str     	r1, [sp, #4]
0x003dd4:	movs    	r1, #0xe1
0x003dd6:	movs    	r2, #0x9e
0x003dd8:	adds    	r3, r6, #0
0x003dda:	adds    	r0, r7, #0
0x003ddc:	bl      	#0x326c
0x003de0:	movs    	r2, #0
0x003de2:	movs    	r1, #0
0x003de4:	str     	r2, [sp, #8]
0x003de6:	adds    	r3, r6, #0
0x003de8:	adds    	r2, r0, #0
0x003dea:	str     	r1, [sp]
0x003dec:	str     	r1, [sp, #4]
0x003dee:	movs    	r1, #6
0x003df0:	movs    	r0, #0xf1
0x003df2:	lsls    	r0, r0, #9
0x003df4:	bl      	#0x326c
0x003df8:	movs    	r1, #0
0x003dfa:	movs    	r2, #0
0x003dfc:	str     	r2, [sp, #8]
0x003dfe:	str     	r1, [sp]
0x003e00:	str     	r1, [sp, #4]
0x003e02:	movs    	r1, #0x14
0x003e04:	movs    	r2, #0x9e
0x003e06:	adds    	r3, r6, #0
0x003e08:	movs    	r0, #0xf1
0x003e0a:	lsls    	r0, r0, #9
0x003e0c:	bl      	#0x326c
0x003e10:	movs    	r1, #0
0x003e12:	movs    	r2, #0
0x003e14:	str     	r2, [sp, #8]
0x003e16:	str     	r1, [sp]
0x003e18:	str     	r1, [sp, #4]
0x003e1a:	movs    	r1, #0xe1
0x003e1c:	movs    	r2, #0x9f
0x003e1e:	adds    	r3, r6, #0
0x003e20:	movs    	r0, #0xf1
0x003e22:	lsls    	r0, r0, #9
0x003e24:	bl      	#0x326c
0x003e28:	cmp     	r0, #0
0x003e2a:	beq     	#0x3e72
0x003e2c:	movs    	r1, #0
0x003e2e:	movs    	r2, #0
0x003e30:	str     	r2, [sp, #8]
0x003e32:	str     	r1, [sp]
0x003e34:	str     	r1, [sp, #4]
0x003e36:	movs    	r1, #0xe1
0x003e38:	movs    	r2, #0x9f
0x003e3a:	adds    	r3, r6, #0
0x003e3c:	adds    	r0, r7, #0
0x003e3e:	bl      	#0x326c
0x003e42:	movs    	r2, #0
0x003e44:	movs    	r1, #0
0x003e46:	str     	r2, [sp, #8]
0x003e48:	adds    	r3, r6, #0
0x003e4a:	adds    	r2, r0, #0
0x003e4c:	str     	r1, [sp]
0x003e4e:	str     	r1, [sp, #4]

; ===== candidate_004170 =====
0x004170:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x004172:	sub     	sp, #0xc
0x004174:	movs    	r1, #0
0x004176:	movs    	r2, #0
0x004178:	str     	r2, [sp, #8]
0x00417a:	str     	r1, [sp]
0x00417c:	str     	r1, [sp, #4]
0x00417e:	movs    	r4, #0
0x004180:	adds    	r3, r4, #0
0x004182:	movs    	r1, #0x14
0x004184:	movs    	r2, #0x98
0x004186:	movs    	r0, #0xf1
0x004188:	movs    	r5, #0x15
0x00418a:	lsls    	r0, r0, #9
0x00418c:	bl      	#0x326c
0x004190:	movs    	r1, #0
0x004192:	movs    	r2, #0
0x004194:	str     	r2, [sp, #8]
0x004196:	str     	r1, [sp]
0x004198:	str     	r1, [sp, #4]
0x00419a:	adds    	r3, r4, #0
0x00419c:	adds    	r2, r5, #0
0x00419e:	movs    	r1, #0x17
0x0041a0:	movs    	r0, #0xf1
0x0041a2:	lsls    	r0, r0, #9
0x0041a4:	bl      	#0x326c
0x0041a8:	movs    	r1, #0
0x0041aa:	movs    	r2, #0
0x0041ac:	str     	r2, [sp, #8]
0x0041ae:	str     	r1, [sp]
0x0041b0:	str     	r1, [sp, #4]
0x0041b2:	movs    	r1, #0xe1
0x0041b4:	movs    	r2, #0x1d
0x0041b6:	adds    	r3, r4, #0
0x0041b8:	movs    	r0, #0xf1
0x0041ba:	lsls    	r0, r0, #9
0x0041bc:	bl      	#0x326c
0x0041c0:	movs    	r1, #0
0x0041c2:	adds    	r6, r0, #0
0x0041c4:	movs    	r2, #0
0x0041c6:	str     	r2, [sp, #8]
0x0041c8:	str     	r1, [sp]
0x0041ca:	str     	r1, [sp, #4]
0x0041cc:	movs    	r1, #0xe1
0x0041ce:	movs    	r2, #0x18
0x0041d0:	movs    	r0, #0xf1
0x0041d2:	adds    	r3, r4, #0
0x0041d4:	lsls    	r0, r0, #9
0x0041d6:	bl      	#0x326c
0x0041da:	ldr     	r7, [r0, #0xc]
0x0041dc:	movs    	r1, #0
0x0041de:	movs    	r2, #0
0x0041e0:	str     	r2, [sp, #8]
0x0041e2:	str     	r1, [sp]
0x0041e4:	str     	r1, [sp, #4]
0x0041e6:	movs    	r1, #0xe1
0x0041e8:	movs    	r2, #0x18
0x0041ea:	movs    	r0, #0xf1
0x0041ec:	adds    	r3, r4, #0
0x0041ee:	lsls    	r0, r0, #9
0x0041f0:	bl      	#0x326c
0x0041f4:	ldr     	r3, [r0, #8]
0x0041f6:	movs    	r2, #0
0x0041f8:	str     	r2, [sp, #8]
0x0041fa:	adds    	r2, r5, #0
0x0041fc:	movs    	r0, #0xf1
0x0041fe:	movs    	r1, #0x52
0x004200:	lsls    	r0, r0, #9
0x004202:	str     	r7, [sp]
0x004204:	str     	r6, [sp, #4]
0x004206:	bl      	#0x326c
0x00420a:	movs    	r1, #0
0x00420c:	movs    	r2, #0
0x00420e:	str     	r1, [sp]
0x004210:	str     	r1, [sp, #4]
0x004212:	movs    	r1, #0x19
0x004214:	str     	r2, [sp, #8]
0x004216:	adds    	r3, r4, #0
0x004218:	movs    	r0, #0xf1
0x00421a:	lsls    	r0, r0, #9
0x00421c:	ldr     	r2, [sp, #0xc]
0x00421e:	bl      	#0x326c
0x004222:	movs    	r1, #0
0x004224:	movs    	r2, #0
0x004226:	str     	r1, [sp]
0x004228:	str     	r1, [sp, #4]
0x00422a:	movs    	r1, #0x19
0x00422c:	str     	r2, [sp, #8]
0x00422e:	adds    	r3, r4, #0
0x004230:	movs    	r0, #0xf1
0x004232:	lsls    	r0, r0, #9
0x004234:	ldr     	r2, [sp, #0x10]
0x004236:	bl      	#0x326c
0x00423a:	movs    	r2, #0
0x00423c:	movs    	r1, #0
0x00423e:	ldr     	r3, [pc, #0x18]
0x004240:	str     	r1, [sp]
0x004242:	str     	r1, [sp, #4]
0x004244:	str     	r2, [sp, #8]
0x004246:	add     	r3, pc
0x004248:	movs    	r2, #1
0x00424a:	movs    	r1, #0x1b
0x00424c:	movs    	r0, #0xf1
0x00424e:	lsls    	r0, r0, #9
0x004250:	bl      	#0x326c
0x004254:	add     	sp, #0x14
0x004256:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00425c =====
0x00425c:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x00425e:	ldr     	r5, [pc, #0xc8]
0x004260:	movs    	r7, #0xf1
0x004262:	add     	r5, sb
0x004264:	ldr     	r0, [r5, #0x1c]
0x004266:	lsls    	r7, r7, #9
0x004268:	ldr     	r3, [r0, #0x4c]
0x00426a:	movs    	r6, #0
0x00426c:	adds    	r4, r1, #0
0x00426e:	cmp     	r3, #0
0x004270:	sub     	sp, #0xc
0x004272:	beq     	#0x428e
0x004274:	movs    	r2, #0
0x004276:	movs    	r1, #0
0x004278:	str     	r2, [sp, #8]
0x00427a:	adds    	r2, r3, #0
0x00427c:	str     	r1, [sp]
0x00427e:	str     	r1, [sp, #4]
0x004280:	movs    	r1, #0x12
0x004282:	adds    	r3, r6, #0
0x004284:	adds    	r0, r7, #0
0x004286:	bl      	#0x326c
0x00428a:	ldr     	r0, [r5, #0x1c]
0x00428c:	str     	r6, [r0, #0x4c]
0x00428e:	ldr     	r0, [sp, #0xc]
0x004290:	ldr     	r1, [r5, #0x1c]
0x004292:	cmp     	r4, #0
0x004294:	str     	r0, [r1, #0x4c]
0x004296:	bne     	#0x430e
0x004298:	ldr     	r1, [r5, #0xc]
0x00429a:	movs    	r2, #0
0x00429c:	lsls    	r1, r1, #2
0x00429e:	ldr     	r0, [r0, r1]
0x0042a0:	movs    	r1, #0
0x0042a2:	ldr     	r4, [r0]
0x0042a4:	str     	r1, [sp]
0x0042a6:	str     	r1, [sp, #4]
0x0042a8:	str     	r2, [sp, #8]
0x0042aa:	movs    	r2, #0xa3
0x0042ac:	movs    	r1, #0xe1
0x0042ae:	adds    	r3, r6, #0
0x0042b0:	adds    	r0, r7, #0
0x0042b2:	bl      	#0x326c
0x0042b6:	lsls    	r4, r4, #2
0x0042b8:	ldr     	r0, [r0, r4]
0x0042ba:	ldr     	r0, [r0, #0x18]
0x0042bc:	cmp     	r0, #0
0x0042be:	beq     	#0x430e
0x0042c0:	movs    	r1, #0
0x0042c2:	movs    	r2, #0
0x0042c4:	str     	r2, [sp, #8]
0x0042c6:	str     	r1, [sp]
0x0042c8:	str     	r1, [sp, #4]
0x0042ca:	movs    	r1, #0xe1
0x0042cc:	movs    	r2, #0xa3
0x0042ce:	adds    	r3, r6, #0
0x0042d0:	adds    	r0, r7, #0
0x0042d2:	bl      	#0x326c
0x0042d6:	ldr     	r0, [r0, r4]
0x0042d8:	movs    	r1, #0
0x0042da:	ldr     	r3, [r0, #0x18]
0x0042dc:	movs    	r2, #0
0x0042de:	str     	r2, [sp, #8]
0x0042e0:	str     	r1, [sp]
0x0042e2:	str     	r1, [sp, #4]
0x0042e4:	movs    	r0, #0xf1
0x0042e6:	lsls    	r0, r0, #9
0x0042e8:	movs    	r1, #9
0x0042ea:	adds    	r2, r3, #0
0x0042ec:	adds    	r3, r6, #0
0x0042ee:	bl      	#0x326c
0x0042f2:	movs    	r1, #0
0x0042f4:	movs    	r2, #0
0x0042f6:	str     	r2, [sp, #8]
0x0042f8:	str     	r1, [sp]
0x0042fa:	str     	r1, [sp, #4]
0x0042fc:	movs    	r1, #0xe1
0x0042fe:	movs    	r2, #0xa3
0x004300:	adds    	r3, r6, #0
0x004302:	movs    	r0, #0xf1
0x004304:	lsls    	r0, r0, #9
0x004306:	bl      	#0x326c
0x00430a:	ldr     	r0, [r0, r4]
0x00430c:	str     	r6, [r0, #0x18]
0x00430e:	str     	r6, [r5, #0xc]
0x004310:	movs    	r1, #0
0x004312:	str     	r1, [sp]
0x004314:	str     	r1, [sp, #4]
0x004316:	movs    	r2, #0
0x004318:	movs    	r1, #0xe6
0x00431a:	adds    	r3, r6, #0
0x00431c:	adds    	r0, r7, #0
0x00431e:	str     	r2, [sp, #8]
0x004320:	bl      	#0x326c
0x004324:	add     	sp, #0x14
0x004326:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00432c =====
0x00432c:	push    	{r4, r5, r6, r7, lr}
0x00432e:	sub     	sp, #0xc
0x004330:	adds    	r4, r1, #0
0x004332:	movs    	r1, #0
0x004334:	adds    	r5, r2, #0
0x004336:	movs    	r2, #0
0x004338:	str     	r2, [sp, #8]
0x00433a:	str     	r1, [sp]
0x00433c:	str     	r1, [sp, #4]
0x00433e:	movs    	r6, #0xf1
0x004340:	lsls    	r6, r6, #9
0x004342:	movs    	r1, #0xe1
0x004344:	movs    	r2, #0xc7
0x004346:	adds    	r7, r0, #0
0x004348:	movs    	r3, #0
0x00434a:	adds    	r0, r6, #0
0x00434c:	bl      	#0x326c
0x004350:	cmp     	r0, #0
0x004352:	bne     	#0x436a
0x004354:	movs    	r1, #0
0x004356:	movs    	r2, #0
0x004358:	str     	r2, [sp, #8]
0x00435a:	str     	r1, [sp]
0x00435c:	str     	r1, [sp, #4]
0x00435e:	movs    	r1, #0x14
0x004360:	movs    	r2, #0xc7
0x004362:	movs    	r3, #1
0x004364:	adds    	r0, r6, #0
0x004366:	bl      	#0x326c
0x00436a:	cmp     	r7, #0xa
0x00436c:	blo     	#0x4370
0x00436e:	b       	#0x4458
0x004370:	adr     	r3, #4
0x004372:	ldrb    	r3, [r3, r7]
0x004374:	lsls    	r3, r3, #1
0x004376:	add     	pc, r3
0x004378:	ldrsh   	r3, [r2, r1]
0x00437a:	ldr     	r6, [pc, #0x1a4]
0x00437c:	adds    	r4, #0x38
0x00437e:	adds    	r7, r5, #4
0x004380:	lsls    	r6, r2, #0x10
0x004382:	movs    	r1, #0
0x004384:	str     	r1, [sp]
0x004386:	str     	r1, [sp, #4]
0x004388:	movs    	r2, #0
0x00438a:	ldr     	r5, [pc, #0xd4]
0x00438c:	movs    	r4, #0
0x00438e:	adds    	r3, r4, #0
0x004390:	str     	r2, [sp, #8]
0x004392:	movs    	r1, #0x12
0x004394:	add     	r5, sb
0x004396:	ldr     	r2, [r5]
0x004398:	adds    	r0, r6, #0
0x00439a:	bl      	#0x326c
0x00439e:	movs    	r0, #0
0x0043a0:	str     	r4, [r5]
0x0043a2:	add     	sp, #0xc
0x0043a4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_004496 =====
0x004496:	push    	{r0, r1, r2, r3, r4, r5, r7}
0x004498:	movs    	r0, r0
0x00449a:	movs    	r0, r0
0x00449c:	push    	{r1, r2, r3, r6, r7}
0x00449e:	sub     	sp, #0x15c

; ===== candidate_00449c =====
0x00449c:	push    	{r1, r2, r3, r6, r7}
0x00449e:	sub     	sp, #0x15c

; ===== candidate_0044a8 =====
0x0044a8:	push    	{r0, r4, r5, r7}
0x0044aa:	movs    	r0, r0
0x0044ac:	ble     	#0x4458
0x0044ae:	push    	{r1, r2, r3, r6, r7}
0x0044b0:	add     	r2, sp, #0x2fc
0x0044b2:	stm     	r5!, {r0, r1, r2, r4, r5, r7}
0x0044b4:	movs    	r0, r0
0x0044b6:	movs    	r0, r0
0x0044b8:	udf     	#0xce

; ===== candidate_0044ae =====
0x0044ae:	push    	{r1, r2, r3, r6, r7}
0x0044b0:	add     	r2, sp, #0x2fc
0x0044b2:	stm     	r5!, {r0, r1, r2, r4, r5, r7}
0x0044b4:	movs    	r0, r0
0x0044b6:	movs    	r0, r0
0x0044b8:	udf     	#0xce

; ===== candidate_004514 =====
0x004514:	push    	{r1, r2, r4, r6, r7, lr}
0x004516:	movs    	r0, r0
0x004518:	add     	r1, sb
0x00451a:	movs    	r2, r7
0x00451c:	movs    	r7, r5
0x00451e:	movs    	r0, r0
0x004520:	sub     	sp, #0x158
0x004522:	push    	{r1, r4, r6, r7, lr}
0x004524:	movs    	r2, r7
0x004526:	movs    	r0, r0
0x004528:	bl      	#0xcc1a8e
0x00452c:	movs    	r2, r7
0x00452e:	movs    	r0, r0
0x004530:	bgt     	#0x44bc
0x004532:	itttt   	gt

; ===== candidate_004522 =====
0x004522:	push    	{r1, r4, r6, r7, lr}
0x004524:	movs    	r2, r7
0x004526:	movs    	r0, r0
0x004528:	bl      	#0xcc1a8e
0x00452c:	movs    	r2, r7
0x00452e:	movs    	r0, r0
0x004530:	bgt     	#0x44bc
0x004532:	itttt   	gt

; ===== candidate_004550 =====
0x004550:	push    	{r1, r2, r4, r6, r7, lr}
0x004552:	movs    	r2, r7
0x004554:	ble     	#0x4500
0x004556:	push    	{r1, r2, r3, r6, r7}
0x004558:	add     	r2, sp, #0x2fc
0x00455a:	add     	r0, sp, #0x334
0x00455c:	ldr     	r1, [pc, #0x158]
0x00455e:	ldm     	r4, {r4, r6}
0x004560:	ldm     	r0!, {r3, r4, r6, r7}
0x004562:	lsls    	r0, r5, #2
0x004564:	movs    	r0, r0
0x004566:	movs    	r0, r0
0x004568:	bkpt    	#0xa1
0x00456a:	bvc     	#0x44ce

; ===== candidate_004556 =====
0x004556:	push    	{r1, r2, r3, r6, r7}
0x004558:	add     	r2, sp, #0x2fc
0x00455a:	add     	r0, sp, #0x334
0x00455c:	ldr     	r1, [pc, #0x158]
0x00455e:	ldm     	r4, {r4, r6}
0x004560:	ldm     	r0!, {r3, r4, r6, r7}
0x004562:	lsls    	r0, r5, #2
0x004564:	movs    	r0, r0
0x004566:	movs    	r0, r0
0x004568:	bkpt    	#0xa1
0x00456a:	bvc     	#0x44ce

; ===== candidate_004590 =====
0x004590:	push    	{r1, r2, r3, r6, r7}
0x004592:	cbnz    	r2, #0x45c8
0x004594:	stm     	r3!, {r0, r1, r4, r6, r7}
0x004596:	bkpt    	#0xa1
0x004598:	add     	r3, sp, #0x32c

; ===== candidate_0045ac =====
0x0045ac:	push    	{r0, r1, r2, r4, r6, r7}

; ===== candidate_0045b4 =====
0x0045b4:	push    	{r1, r2, r3, r6, r7}

; ===== candidate_00462a =====
0x00462a:	push    	{r0, r1, r2, r3, r4, r5, r7}
0x00462c:	movs    	r0, r0
0x00462e:	movs    	r0, r0
0x004630:	adr     	r6, #0x2c4
0x004632:	push    	{r0, r4, r5, r7}
0x004634:	movs    	r0, r0
0x004636:	movs    	r0, r0
0x004638:	stm     	r6!, {r0, r1, r4, r5, r7}
0x00463a:	stm     	r5!, {r1, r3, r4, r5, r7}
0x00463c:	movs    	r0, r0
0x00463e:	movs    	r0, r0
0x004640:	pop     	{r2, r3, r4, r5, r7}
0x004642:	bgt     	#0x45ce
0x004644:	movs    	r0, r0
0x004646:	movs    	r0, r0

; ===== candidate_004632 =====
0x004632:	push    	{r0, r4, r5, r7}
0x004634:	movs    	r0, r0
0x004636:	movs    	r0, r0
0x004638:	stm     	r6!, {r0, r1, r4, r5, r7}
0x00463a:	stm     	r5!, {r1, r3, r4, r5, r7}
0x00463c:	movs    	r0, r0
0x00463e:	movs    	r0, r0
0x004640:	pop     	{r2, r3, r4, r5, r7}
0x004642:	bgt     	#0x45ce
0x004644:	movs    	r0, r0
0x004646:	movs    	r0, r0

; ===== candidate_004664 =====
0x004664:	push    	{r2, r3, r6, r7, lr}
0x004666:	adr     	r1, #0x3a8
0x004668:	cmp     	r7, #0xbf
0x00466a:	ldm     	r1, {r0, r1, r2, r3, r4, r5, r7}
0x00466c:	bmi     	#0x4614

; ===== candidate_004678 =====
0x004678:	push    	{r1, r4, r6, r7, lr}
0x00467a:	itttt   	ge
0x00467c:	stmge   	r4!, {r0, r2, r4, r5, r7}
0x00467e:	ldmge   	r3, {r3, r6, r7}

; ===== candidate_004774 =====
0x004774:	push    	{r1, r3, r5}
0x004776:	stm     	r0!, {r1, r4, r5, r6, r7}
0x004778:	ldm     	r4, {r1, r2, r3, r4, r6, r7}
0x00477a:	cmp     	r7, #0xa8

; ===== candidate_004814 =====
0x004814:	push    	{r4, r6, r7}
0x004816:	ldm     	r2!, {r0, r1, r4, r6, r7}
0x004818:	cdp2    	p0, #0xb, c0, c12, c0, #0
0x00481c:	push    	{r0, r1, r2, r4, r5, r7, lr}
0x00481e:	bhi     	#0x4798
0x004820:	movs    	r0, r0
0x004822:	movs    	r0, r0
0x004824:	strh    	r5, [r1, r1]
0x004826:	bx      	sl
0x004828:	movs    	r4, r0
0x00482a:	movs    	r0, r0
0x00482c:	movs    	r0, r0
0x00482e:	movs    	r0, r0
0x004830:	movs    	r4, r0
0x004832:	movs    	r0, r0
0x004834:	str     	r1, [r4, #0x24]
0x004836:	lsls    	r3, r4, #1
0x004838:	movs    	r0, r0
0x00483a:	movs    	r0, r0
0x00483c:	str     	r6, [r2, #0x14]
0x00483e:	subs    	r2, #0x6c
0x004840:	ldrb    	r0, [r6]
0x004842:	ldrb    	r5, [r4]
0x004844:	movs    	r0, r0
0x004846:	movs    	r0, r0
0x004848:	ldr     	r4, [r6, #0x14]
0x00484a:	str     	r5, [r5, #0x54]
0x00484c:	movs    	r0, #0x72
0x00484e:	strb    	r5, [r4, #9]
0x004850:	subs    	r2, #0x72
0x004852:	str     	r5, [r4, #0x40]
0x004854:	movs    	r0, r0
0x004856:	movs    	r0, r0
0x004858:	str     	r4, [r4, #0x54]
0x00485a:	ldr     	r1, [r4, #0x44]
0x00485c:	ldr     	r4, [r6, #0x14]
0x00485e:	str     	r5, [r5, #0x54]
0x004860:	lsls    	r2, r6, #1
0x004862:	movs    	r0, r0
0x004864:	ldr     	r4, [r6, #0x14]
0x004866:	str     	r5, [r5, #0x54]
0x004868:	muls    	r2, r6, r2
0x00486a:	str     	r2, [r6, #0x54]
0x00486c:	strb    	r1, [r4, #0x11]
0x00486e:	movs    	r0, #0x65
0x004870:	strb    	r5, [r4, #9]
0x004872:	movs    	r0, #0x72
0x004874:	adds    	r1, #0x30
0x004876:	movs    	r0, r0
0x004878:	ldrb    	r5, [r4, #1]
0x00487a:	movs    	r0, #0x74
0x00487c:	strb    	r5, [r4, #9]
0x00487e:	subs    	r2, #0x72
0x004880:	str     	r5, [r4, #0x40]
0x004882:	movs    	r0, r0
0x004884:	strb    	r5, [r5, #9]
0x004886:	ldrsh   	r3, [r4, r5]
0x004888:	ldrb    	r5, [r4, #1]
0x00488a:	ldr     	r5, [pc, #0x1d0]
0x00488c:	strb    	r0, [r6, #0xd]
0x00488e:	strb    	r6, [r0, #1]
0x004890:	str     	r3, [r0, #0x14]
0x004892:	ldr     	r4, [r5, #0x44]
0x004894:	str     	r2, [r7, #0x50]
0x004896:	strb    	r2, [r6, #9]
0x004898:	movs    	r0, r0
0x00489a:	movs    	r0, r0
0x00489c:	adds    	r2, #0x63
0x00489e:	subs    	r2, #0x75
0x0048a0:	strb    	r5, [r4, #9]
0x0048a2:	movs    	r0, #0x72
0x0048a4:	movs    	r0, #0x20
0x0048a6:	movs    	r1, r6
0x0048a8:	adds    	r2, #0x63
0x0048aa:	subs    	r2, #0x75
0x0048ac:	strb    	r5, [r4, #9]
0x0048ae:	movs    	r0, #0x72
0x0048b0:	movs    	r0, #0x20
0x0048b2:	movs    	r2, r6
0x0048b4:	str     	r2, [r6, #0x54]
0x0048b6:	strb    	r3, [r6, #0x11]
0x0048b8:	strb    	r1, [r4, #9]
0x0048ba:	lsls    	r4, r6, #1
0x0048bc:	strb    	r5, [r4, #9]
0x0048be:	subs    	r2, #0x72
0x0048c0:	str     	r5, [r4, #0x40]
0x0048c2:	movs    	r0, r0
0x0048c4:	str     	r2, [r6, #0x54]
0x0048c6:	str     	r1, [r4, #0x44]
0x0048c8:	movs    	r2, #0x20
0x0048ca:	strb    	r5, [r4, #0xc]
0x0048cc:	movs    	r0, #0x22
0x0048ce:	strb    	r6, [r4, #9]
0x0048d0:	ldr     	r7, [r5, #0x54]
0x0048d2:	ldr     	r0, [r4, #0x50]
0x0048d4:	strb    	r2, [r6, #1]
0x0048d6:	str     	r0, [r4, #0x50]
0x0048d8:	strb    	r2, [r6, #9]
0x0048da:	str     	r4, [r5, #0x30]
0x0048dc:	str     	r7, [r5, #0x44]
0x0048de:	subs    	r5, #0x65
0x0048e0:	str     	r5, [r4, #0x40]
0x0048e2:	movs    	r0, r0
0x0048e4:	strb    	r3, [r4, #9]
0x0048e6:	movs    	r0, #0x63
0x0048e8:	strb    	r5, [r4, #9]
0x0048ea:	movs    	r1, #0x72
0x0048ec:	movs    	r0, r0
0x0048ee:	movs    	r0, r0
0x0048f0:	str     	r4, [r5, #0x54]
0x0048f2:	str     	r6, [r5, #0x74]
0x0048f4:	ldr     	r4, [r6, #4]
0x0048f6:	str     	r0, [r4, #0x50]
0x0048f8:	strb    	r2, [r6, #9]
0x0048fa:	movs    	r1, r4
0x0048fc:	ldrh    	r7, [r3, #0x18]
0x0048fe:	movs    	r0, r0
0x004900:	ldr     	r6, [sp, #0x7c]
0x004902:	movs    	r0, r0
0x004904:	movs    	r4, r4
0x004906:	movs    	r0, r0
0x004908:	str     	r1, [r4, #0x24]
0x00490a:	lsls    	r3, r4, #1
0x00490c:	ldr     	r4, [r2, #0x14]
0x00490e:	str     	r5, [r5, #0x54]
0x004910:	strh    	r2, [r6, r5]
0x004912:	str     	r4, [r6, #0x14]
0x004914:	str     	r4, [r6, #0x54]
0x004916:	subs    	r5, #0x20
0x004918:	movs    	r5, #0x20
0x00491a:	lsls    	r4, r4, #1
0x00491c:	rsbs    	r3, r0, #0
0x00491e:	strb    	r0, [r4, #0x1c]
0x004920:	str     	r0, [r5, #0x54]
0x004922:	movs    	r0, #0x6e
0x004924:	str     	r0, [r6, #0x14]
0x004926:	strb    	r5, [r6, #0xd]
0x004928:	movs    	r1, #0x65
0x00492a:	movs    	r0, r0
0x00492c:	str     	r3, [r4, #0x14]
0x00492e:	ldr     	r3, [r4, #4]

; ===== candidate_00481c =====
0x00481c:	push    	{r0, r1, r2, r4, r5, r7, lr}
0x00481e:	bhi     	#0x4798
0x004820:	movs    	r0, r0
0x004822:	movs    	r0, r0
0x004824:	strh    	r5, [r1, r1]
0x004826:	bx      	sl
0x004828:	movs    	r4, r0
0x00482a:	movs    	r0, r0
0x00482c:	movs    	r0, r0
0x00482e:	movs    	r0, r0
0x004830:	movs    	r4, r0
0x004832:	movs    	r0, r0
0x004834:	str     	r1, [r4, #0x24]
0x004836:	lsls    	r3, r4, #1
0x004838:	movs    	r0, r0
0x00483a:	movs    	r0, r0
0x00483c:	str     	r6, [r2, #0x14]
0x00483e:	subs    	r2, #0x6c
0x004840:	ldrb    	r0, [r6]
0x004842:	ldrb    	r5, [r4]
0x004844:	movs    	r0, r0
0x004846:	movs    	r0, r0
0x004848:	ldr     	r4, [r6, #0x14]
0x00484a:	str     	r5, [r5, #0x54]
0x00484c:	movs    	r0, #0x72
0x00484e:	strb    	r5, [r4, #9]
0x004850:	subs    	r2, #0x72
0x004852:	str     	r5, [r4, #0x40]
0x004854:	movs    	r0, r0
0x004856:	movs    	r0, r0
0x004858:	str     	r4, [r4, #0x54]
0x00485a:	ldr     	r1, [r4, #0x44]
0x00485c:	ldr     	r4, [r6, #0x14]
0x00485e:	str     	r5, [r5, #0x54]
0x004860:	lsls    	r2, r6, #1
0x004862:	movs    	r0, r0
0x004864:	ldr     	r4, [r6, #0x14]
0x004866:	str     	r5, [r5, #0x54]
0x004868:	muls    	r2, r6, r2
0x00486a:	str     	r2, [r6, #0x54]
0x00486c:	strb    	r1, [r4, #0x11]
0x00486e:	movs    	r0, #0x65
0x004870:	strb    	r5, [r4, #9]
0x004872:	movs    	r0, #0x72
0x004874:	adds    	r1, #0x30
0x004876:	movs    	r0, r0
0x004878:	ldrb    	r5, [r4, #1]
0x00487a:	movs    	r0, #0x74
0x00487c:	strb    	r5, [r4, #9]
0x00487e:	subs    	r2, #0x72
0x004880:	str     	r5, [r4, #0x40]
0x004882:	movs    	r0, r0
0x004884:	strb    	r5, [r5, #9]
0x004886:	ldrsh   	r3, [r4, r5]
0x004888:	ldrb    	r5, [r4, #1]
0x00488a:	ldr     	r5, [pc, #0x1d0]
0x00488c:	strb    	r0, [r6, #0xd]
0x00488e:	strb    	r6, [r0, #1]
0x004890:	str     	r3, [r0, #0x14]
0x004892:	ldr     	r4, [r5, #0x44]
0x004894:	str     	r2, [r7, #0x50]
0x004896:	strb    	r2, [r6, #9]
0x004898:	movs    	r0, r0
0x00489a:	movs    	r0, r0
0x00489c:	adds    	r2, #0x63
0x00489e:	subs    	r2, #0x75
0x0048a0:	strb    	r5, [r4, #9]
0x0048a2:	movs    	r0, #0x72
0x0048a4:	movs    	r0, #0x20
0x0048a6:	movs    	r1, r6
0x0048a8:	adds    	r2, #0x63
0x0048aa:	subs    	r2, #0x75
0x0048ac:	strb    	r5, [r4, #9]
0x0048ae:	movs    	r0, #0x72
0x0048b0:	movs    	r0, #0x20
0x0048b2:	movs    	r2, r6
0x0048b4:	str     	r2, [r6, #0x54]
0x0048b6:	strb    	r3, [r6, #0x11]
0x0048b8:	strb    	r1, [r4, #9]
0x0048ba:	lsls    	r4, r6, #1
0x0048bc:	strb    	r5, [r4, #9]
0x0048be:	subs    	r2, #0x72
0x0048c0:	str     	r5, [r4, #0x40]
0x0048c2:	movs    	r0, r0
0x0048c4:	str     	r2, [r6, #0x54]
0x0048c6:	str     	r1, [r4, #0x44]
0x0048c8:	movs    	r2, #0x20
0x0048ca:	strb    	r5, [r4, #0xc]
0x0048cc:	movs    	r0, #0x22
0x0048ce:	strb    	r6, [r4, #9]
0x0048d0:	ldr     	r7, [r5, #0x54]
0x0048d2:	ldr     	r0, [r4, #0x50]
0x0048d4:	strb    	r2, [r6, #1]
0x0048d6:	str     	r0, [r4, #0x50]
0x0048d8:	strb    	r2, [r6, #9]
0x0048da:	str     	r4, [r5, #0x30]
0x0048dc:	str     	r7, [r5, #0x44]
0x0048de:	subs    	r5, #0x65
0x0048e0:	str     	r5, [r4, #0x40]
0x0048e2:	movs    	r0, r0
0x0048e4:	strb    	r3, [r4, #9]
0x0048e6:	movs    	r0, #0x63
0x0048e8:	strb    	r5, [r4, #9]
0x0048ea:	movs    	r1, #0x72
0x0048ec:	movs    	r0, r0
0x0048ee:	movs    	r0, r0
0x0048f0:	str     	r4, [r5, #0x54]
0x0048f2:	str     	r6, [r5, #0x74]
0x0048f4:	ldr     	r4, [r6, #4]
0x0048f6:	str     	r0, [r4, #0x50]
0x0048f8:	strb    	r2, [r6, #9]
0x0048fa:	movs    	r1, r4
0x0048fc:	ldrh    	r7, [r3, #0x18]
0x0048fe:	movs    	r0, r0
0x004900:	ldr     	r6, [sp, #0x7c]
0x004902:	movs    	r0, r0
0x004904:	movs    	r4, r4
0x004906:	movs    	r0, r0
0x004908:	str     	r1, [r4, #0x24]
0x00490a:	lsls    	r3, r4, #1
0x00490c:	ldr     	r4, [r2, #0x14]
0x00490e:	str     	r5, [r5, #0x54]
0x004910:	strh    	r2, [r6, r5]
0x004912:	str     	r4, [r6, #0x14]
0x004914:	str     	r4, [r6, #0x54]
0x004916:	subs    	r5, #0x20
0x004918:	movs    	r5, #0x20
0x00491a:	lsls    	r4, r4, #1
0x00491c:	rsbs    	r3, r0, #0
0x00491e:	strb    	r0, [r4, #0x1c]
0x004920:	str     	r0, [r5, #0x54]
0x004922:	movs    	r0, #0x6e
0x004924:	str     	r0, [r6, #0x14]
0x004926:	strb    	r5, [r6, #0xd]
0x004928:	movs    	r1, #0x65
0x00492a:	movs    	r0, r0
0x00492c:	str     	r3, [r4, #0x14]
0x00492e:	ldr     	r3, [r4, #4]
0x004930:	lsls    	r5, r4, #1
0x004932:	movs    	r0, r0
0x004934:	str     	r3, [r4, #0x14]
