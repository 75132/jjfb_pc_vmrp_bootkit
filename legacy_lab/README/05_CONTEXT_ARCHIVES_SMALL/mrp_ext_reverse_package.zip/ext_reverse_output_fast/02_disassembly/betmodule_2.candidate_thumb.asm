; fallback candidate disassembly from Thumb prologues; true code is ARM entry + Thumb functions.

; ARM entry
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0x29e4
0x000018:	pop     	{r4, pc}
0x00001c:	andeq   	r4, r0, r8, ror r7
0x000020:	ands    	r2, r0, #128, #8
0x000024:	rsbmi   	r0, r0, #0
0x000028:	eors    	r3, r2, r1, asr #32
0x00002c:	rsbhs   	r1, r1, #0
0x000030:	rsbs    	ip, r0, r1, lsr #3
0x000034:	blo     	#0xbc
0x000038:	rsbs    	ip, r0, r1, lsr #8
0x00003c:	blo     	#0x80
0x000040:	lsl     	r0, r0, #8
0x000044:	orr     	r2, r2, #0xff000000
0x000048:	rsbs    	ip, r0, r1, lsr #4
0x00004c:	blo     	#0xb0
0x000050:	rsbs    	ip, r0, r1, lsr #8
0x000054:	blo     	#0x80
0x000058:	lsl     	r0, r0, #8
0x00005c:	orr     	r2, r2, #0xff0000
0x000060:	rsbs    	ip, r0, r1, lsr #8
0x000064:	lslhs   	r0, r0, #8
0x000068:	orrhs   	r2, r2, #0xff00
0x00006c:	rsbs    	ip, r0, r1, lsr #4
0x000070:	blo     	#0xb0
0x000074:	rsbs    	ip, r0, #0
0x000078:	bhs     	#0xf8
0x00007c:	lsrhs   	r0, r0, #8
0x000080:	rsbs    	ip, r0, r1, lsr #7
0x000084:	subhs   	r1, r1, r0, lsl #7
0x000088:	adc     	r2, r2, r2
0x00008c:	rsbs    	ip, r0, r1, lsr #6
0x000090:	subhs   	r1, r1, r0, lsl #6
0x000094:	adc     	r2, r2, r2
0x000098:	rsbs    	ip, r0, r1, lsr #5
0x00009c:	subhs   	r1, r1, r0, lsl #5
0x0000a0:	adc     	r2, r2, r2
0x0000a4:	rsbs    	ip, r0, r1, lsr #4
0x0000a8:	subhs   	r1, r1, r0, lsl #4
0x0000ac:	adc     	r2, r2, r2
0x0000b0:	rsbs    	ip, r0, r1, lsr #3
0x0000b4:	subhs   	r1, r1, r0, lsl #3
0x0000b8:	adc     	r2, r2, r2
0x0000bc:	rsbs    	ip, r0, r1, lsr #2
0x0000c0:	subhs   	r1, r1, r0, lsl #2
0x0000c4:	adc     	r2, r2, r2
0x0000c8:	rsbs    	ip, r0, r1, lsr #1
0x0000cc:	subhs   	r1, r1, r0, lsl #1
0x0000d0:	adc     	r2, r2, r2
0x0000d4:	rsbs    	ip, r0, r1
0x0000d8:	subhs   	r1, r1, r0
0x0000dc:	adcs    	r2, r2, r2
0x0000e0:	bhs     	#0x7c
0x0000e4:	eors    	r0, r2, r3, asr #31
0x0000e8:	add     	r0, r0, r3, lsr #31
0x0000ec:	rsbhs   	r1, r1, #0
0x0000f0:	bx      	lr
0x0000f4:	andeq   	r4, r0, r8, ror r7
0x0000f8:	mov     	r0, #2
0x0000fc:	mov     	r1, #2
0x000100:	b       	#0x118
0x000104:	strmi   	r4, [r8, -r0, lsl #14]

; ===== candidate_000008 =====
0x000008:	ands    	r0, r2
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	lsrs    	r2, r6, #9

; ===== candidate_00000a =====
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	lsrs    	r2, r6, #9

; ===== candidate_00011a =====
0x00011a:	stmdb   	sp!, {r2}

; ===== candidate_000134 =====
0x000134:	push    	{r4, r5, r6, lr}
0x000136:	ldr     	r6, [pc, #0x38]
0x000138:	adds    	r5, r1, #0
0x00013a:	adds    	r1, r0, #0
0x00013c:	adds    	r4, r0, #0
0x00013e:	add     	r6, pc
0x000140:	adds    	r0, r6, #0
0x000142:	bl      	#0x146
0x000146:	adds    	r2, r0, #0
0x000148:	cmp     	r0, r6
0x00014a:	bne     	#0x15a
0x00014c:	adds    	r1, r5, #0
0x00014e:	adds    	r0, r4, #0
0x000150:	bl      	#0x194
0x000154:	pop     	{r4, r5, r6}
0x000156:	pop     	{r3}
0x000158:	bx      	r3
0x00015a:	ldr     	r0, [pc, #0x18]
0x00015c:	add     	r0, pc
0x00015e:	cmp     	r2, r0
0x000160:	beq     	#0x16a
0x000162:	adds    	r1, r5, #0
0x000164:	adds    	r0, r4, #0
0x000166:	bl      	#0x108
0x00016a:	movs    	r0, #0
0x00016c:	b       	#0x154
0x00016e:	movs    	r0, r0
0x000170:	mcr2    	p15, #6, pc, c5, c7, #7
0x000174:	mcr2    	p15, #5, pc, c5, c7, #7
0x000178:	bx      	pc

; ===== candidate_000194 =====
0x000194:	push    	{r3, r4, r5, lr}
0x000196:	subs    	r2, r0, #1
0x000198:	cmp     	r2, #0xd
0x00019a:	adr     	r4, #0x90
0x00019c:	bhs     	#0x1ec
0x00019e:	movs    	r2, #0x17
0x0001a0:	ldr     	r3, [pc, #0x8c]
0x0001a2:	muls    	r2, r0, r2
0x0001a4:	add     	r3, pc
0x0001a6:	adds    	r5, r2, r3
0x0001a8:	subs    	r5, #0x17
0x0001aa:	cmp     	r0, #2
0x0001ac:	bne     	#0x1d8
0x0001ae:	lsls    	r0, r1, #5
0x0001b0:	bpl     	#0x1b6
0x0001b2:	adr     	r4, #0x80
0x0001b4:	b       	#0x1ee
0x0001b6:	ldr     	r0, [pc, #0x90]
0x0001b8:	ands    	r0, r1
0x0001ba:	beq     	#0x1c0
0x0001bc:	adr     	r4, #0x8c
0x0001be:	b       	#0x1ee
0x0001c0:	lsls    	r0, r1, #3
0x0001c2:	bpl     	#0x1c8
0x0001c4:	adr     	r4, #0x94
0x0001c6:	b       	#0x1ee
0x0001c8:	lsls    	r0, r1, #2
0x0001ca:	bpl     	#0x1d0
0x0001cc:	adr     	r4, #0x98
0x0001ce:	b       	#0x1ee
0x0001d0:	lsls    	r0, r1, #1
0x0001d2:	bpl     	#0x1ee
0x0001d4:	adr     	r4, #0x9c
0x0001d6:	b       	#0x1ee
0x0001d8:	cmp     	r0, #8
0x0001da:	bne     	#0x1e0
0x0001dc:	adds    	r4, r1, #0
0x0001de:	b       	#0x1ee
0x0001e0:	cmp     	r0, #9
0x0001e2:	bne     	#0x1ee
0x0001e4:	cmp     	r1, #1
0x0001e6:	bne     	#0x1ee
0x0001e8:	adr     	r5, #0x98
0x0001ea:	b       	#0x1ee
0x0001ec:	adr     	r5, #0xac
0x0001ee:	movs    	r0, #0xa
0x0001f0:	bl      	#0x2b4
0x0001f4:	ldrb    	r0, [r5]
0x0001f6:	cmp     	r0, #0
0x0001f8:	beq     	#0x208
0x0001fa:	ldrb    	r0, [r5]
0x0001fc:	adds    	r5, #1
0x0001fe:	bl      	#0x2b4
0x000202:	ldrb    	r0, [r5]
0x000204:	cmp     	r0, #0
0x000206:	bne     	#0x1fa
0x000208:	ldrb    	r0, [r4]
0x00020a:	cmp     	r0, #0
0x00020c:	beq     	#0x21c
0x00020e:	ldrb    	r0, [r4]
0x000210:	adds    	r4, #1
0x000212:	bl      	#0x2b4
0x000216:	ldrb    	r0, [r4]
0x000218:	cmp     	r0, #0
0x00021a:	bne     	#0x20e
0x00021c:	movs    	r0, #0xa
0x00021e:	bl      	#0x2b4
0x000222:	pop     	{r3, r4, r5}
0x000224:	pop     	{r3}
0x000226:	movs    	r0, #1
0x000228:	bx      	r3
0x00022a:	movs    	r0, r0
0x00022c:	movs    	r0, r0
0x00022e:	movs    	r0, r0
0x000230:	adds    	r5, #0xd0
0x000232:	movs    	r0, r0
0x000234:	ldr     	r1, [r1, #0x64]
0x000236:	str     	r6, [r6, #0x14]
0x000238:	ldr     	r4, [r5, #0x14]
0x00023a:	movs    	r0, #0x64
0x00023c:	strb    	r7, [r1, #1]
0x00023e:	strb    	r5, [r4, #9]
0x000240:	strb    	r1, [r4, #0x11]
0x000242:	ldr     	r1, [r5, #0x74]
0x000244:	lsls    	r6, r5, #1
0x000246:	movs    	r0, r0
0x000248:	movs    	r2, r0
0x00024a:	lsrs    	r0, r0, #0x20
0x00024c:	ldr     	r4, [r0, #0x14]
0x00024e:	ldr     	r6, [r6, #0x14]
0x000250:	str     	r4, [r4, #0x54]
0x000252:	tst     	r0, r4
0x000254:	movs    	r0, #0x79
0x000256:	str     	r2, [r3, #0x54]
0x000258:	ldr     	r2, [r6, #0x74]
0x00025a:	movs    	r0, r0
0x00025c:	strb    	r7, [r1, #0x19]
0x00025e:	strb    	r5, [r4, #9]
0x000260:	ldr     	r6, [r4, #0x44]
0x000262:	strb    	r7, [r5, #0x1d]
0x000264:	movs    	r0, r0
0x000266:	movs    	r0, r0
0x000268:	ldr     	r5, [r2, #0x64]
0x00026a:	str     	r4, [r4, #0x54]
0x00026c:	str     	r2, [r6, #0x64]
0x00026e:	ldr     	r4, [r5, #0x74]
0x000270:	lsls    	r7, r6, #1
0x000272:	movs    	r0, r0
0x000274:	ldr     	r1, [r1, #0x64]
0x000276:	ldrb    	r5, [r4, #1]
0x000278:	str     	r1, [r4, #0x34]
0x00027a:	movs    	r0, #0x74
0x00027c:	str     	r2, [r2, #0x54]
0x00027e:	strb    	r3, [r6, #0x15]
0x000280:	strb    	r4, [r5, #0x11]
0x000282:	movs    	r0, r0
0x000284:	movs    	r0, #0x3a
0x000286:	str     	r0, [r1, #0x54]
0x000288:	strb    	r1, [r4, #1]
0x00028a:	ldr     	r0, [r4, #0x50]
0x00028c:	ldr     	r5, [r4, #0x54]
0x00028e:	strb    	r7, [r5, #9]
0x000290:	movs    	r0, #0x79
0x000292:	ldr     	r3, [r4, #0x74]
0x000294:	strb    	r2, [r6, #9]
0x000296:	strb    	r5, [r6, #1]
0x000298:	str     	r4, [r6, #0x54]
0x00029a:	lsls    	r4, r4, #1
0x00029c:	ldr     	r5, [r2, #0x64]
0x00029e:	ldr     	r3, [r5, #0x64]
0x0002a0:	strb    	r7, [r5, #0x1d]
0x0002a2:	movs    	r0, #0x6e
0x0002a4:	ldr     	r3, [r6, #0x14]
0x0002a6:	ldr     	r7, [r4, #0x64]
0x0002a8:	ldr     	r1, [r4, #0x44]
0x0002aa:	movs    	r0, r0
0x0002ac:	bx      	pc

; ===== candidate_0002b4 =====
0x0002b4:	push    	{r3, lr}
0x0002b6:	add     	r3, sp, #0
0x0002b8:	strb    	r0, [r3]
0x0002ba:	movs    	r0, #3
0x0002bc:	mov     	r1, sp
0x0002be:	svc     	#0xab
0x0002c0:	add     	sp, #4
0x0002c2:	pop     	{r3}
0x0002c4:	bx      	r3
0x0002c6:	movs    	r0, r0
0x0002c8:	movs    	r0, r1
0x0002ca:	b       	#0xfffffe0c
0x0002cc:	asrs    	r0, r1, #0x20
0x0002ce:	b       	#0xfffffe10
0x0002d0:	movs    	r1, r0
0x0002d2:	b       	#0x3d6
0x0002d4:	vrhadd.u16	d14, d14, d31
0x0002d8:	movs    	r4, r1
0x0002da:	movs    	r0, r0
0x0002dc:	lsls    	r4, r0, #7
0x0002de:	movs    	r0, r0
0x0002e0:	str     	r0, [sp]
0x0002e2:	b       	#0x626
0x0002e4:	vrhadd.u16	d14, d14, d31
0x0002e8:	push    	{r4, r5, lr}
0x0002ea:	ldr     	r4, [pc, #0xb4]
0x0002ec:	movs    	r2, #0x1c
0x0002ee:	add     	r4, pc
0x0002f0:	ldr     	r0, [r4, #0x38]
0x0002f2:	movs    	r1, #0
0x0002f4:	ldr     	r3, [r0, #0x38]
0x0002f6:	ldr     	r0, [pc, #0xac]
0x0002f8:	sub     	sp, #0xc
0x0002fa:	add     	r0, sb
0x0002fc:	blx     	r3
0x0002fe:	movs    	r2, #0
0x000300:	movs    	r0, #0
0x000302:	str     	r0, [sp]
0x000304:	ldr     	r1, [pc, #0x9c]
0x000306:	movs    	r3, #0
0x000308:	add     	r1, sb
0x00030a:	str     	r1, [sp, #4]
0x00030c:	movs    	r1, #0x64
0x00030e:	movs    	r0, #1
0x000310:	str     	r2, [sp, #8]
0x000312:	bl      	#0x2abc
0x000316:	ldr     	r1, [pc, #0x8c]
0x000318:	movs    	r0, #0
0x00031a:	add     	r1, sb
0x00031c:	subs    	r1, #0x7c
0x00031e:	str     	r0, [r1, #8]
0x000320:	ldr     	r5, [pc, #0x80]
0x000322:	str     	r0, [r1, #0x10]
0x000324:	str     	r0, [r1, #0xc]
0x000326:	add     	r5, sb
0x000328:	subs    	r5, #0xfc
0x00032a:	movs    	r0, #1
0x00032c:	str     	r0, [r5, #0x18]
0x00032e:	ldr     	r0, [r4, #0x38]
0x000330:	ldr     	r2, [pc, #0x74]
0x000332:	ldr     	r1, [r0, #0x68]
0x000334:	add     	r2, sb
0x000336:	str     	r1, [r5, #0x2c]
0x000338:	ldr     	r1, [r0, #0xc]
0x00033a:	ldr     	r4, [pc, #0x70]
0x00033c:	str     	r1, [r5, #0x30]
0x00033e:	ldr     	r1, [r0, #0x10]
0x000340:	str     	r1, [r5, #0x34]
0x000342:	ldr     	r1, [r0, #0x14]
0x000344:	str     	r1, [r5, #0x38]
0x000346:	ldr     	r1, [r0, #0x18]
0x000348:	str     	r1, [r5, #0x3c]
0x00034a:	ldr     	r1, [r0, #0x1c]
0x00034c:	str     	r1, [r5, #0x40]
0x00034e:	ldr     	r1, [r0, #0x20]
0x000350:	str     	r1, [r5, #0x44]
0x000352:	ldr     	r1, [r0, #0x24]
0x000354:	str     	r1, [r5, #0x48]
0x000356:	ldr     	r1, [r0, #0x28]
0x000358:	str     	r1, [r5, #0x4c]
0x00035a:	ldr     	r1, [r0, #0x2c]
0x00035c:	str     	r1, [r5, #0x50]
0x00035e:	ldr     	r1, [r0, #0x30]
0x000360:	str     	r1, [r5, #0x54]
0x000362:	ldr     	r1, [r0, #0x34]
0x000364:	str     	r1, [r5, #0x58]
0x000366:	ldr     	r1, [r0, #0x38]
0x000368:	str     	r1, [r5, #0x5c]
0x00036a:	ldr     	r1, [r0, #0x3c]
0x00036c:	str     	r1, [r5, #0x60]
0x00036e:	ldr     	r1, [r0, #0x40]
0x000370:	str     	r1, [r5, #0x64]
0x000372:	ldr     	r1, [r0, #0x44]
0x000374:	str     	r1, [r5, #0x68]
0x000376:	ldr     	r1, [r0, #0x48]
0x000378:	str     	r1, [r5, #0x6c]
0x00037a:	ldr     	r1, [r0, #0x4c]
0x00037c:	str     	r1, [r5, #0x70]
0x00037e:	movs    	r1, #0
0x000380:	str     	r1, [r2]
0x000382:	movs    	r1, #1
0x000384:	lsls    	r1, r1, #9
0x000386:	adds    	r0, r0, r1
0x000388:	ldr     	r3, [r0, #8]
0x00038a:	movs    	r1, #7
0x00038c:	adds    	r2, r4, #0
0x00038e:	movs    	r0, #0
0x000390:	blx     	r3
0x000392:	cmp     	r0, r4
0x000394:	bne     	#0x39a
0x000396:	subs    	r0, #2
0x000398:	str     	r0, [r5, #0x28]
0x00039a:	add     	sp, #0xc
0x00039c:	pop     	{r4, r5, pc}

; ===== candidate_0002e8 =====
0x0002e8:	push    	{r4, r5, lr}
0x0002ea:	ldr     	r4, [pc, #0xb4]
0x0002ec:	movs    	r2, #0x1c
0x0002ee:	add     	r4, pc
0x0002f0:	ldr     	r0, [r4, #0x38]
0x0002f2:	movs    	r1, #0
0x0002f4:	ldr     	r3, [r0, #0x38]
0x0002f6:	ldr     	r0, [pc, #0xac]
0x0002f8:	sub     	sp, #0xc
0x0002fa:	add     	r0, sb
0x0002fc:	blx     	r3
0x0002fe:	movs    	r2, #0
0x000300:	movs    	r0, #0
0x000302:	str     	r0, [sp]
0x000304:	ldr     	r1, [pc, #0x9c]
0x000306:	movs    	r3, #0
0x000308:	add     	r1, sb
0x00030a:	str     	r1, [sp, #4]
0x00030c:	movs    	r1, #0x64
0x00030e:	movs    	r0, #1
0x000310:	str     	r2, [sp, #8]
0x000312:	bl      	#0x2abc
0x000316:	ldr     	r1, [pc, #0x8c]
0x000318:	movs    	r0, #0
0x00031a:	add     	r1, sb
0x00031c:	subs    	r1, #0x7c
0x00031e:	str     	r0, [r1, #8]
0x000320:	ldr     	r5, [pc, #0x80]
0x000322:	str     	r0, [r1, #0x10]
0x000324:	str     	r0, [r1, #0xc]
0x000326:	add     	r5, sb
0x000328:	subs    	r5, #0xfc
0x00032a:	movs    	r0, #1
0x00032c:	str     	r0, [r5, #0x18]
0x00032e:	ldr     	r0, [r4, #0x38]
0x000330:	ldr     	r2, [pc, #0x74]
0x000332:	ldr     	r1, [r0, #0x68]
0x000334:	add     	r2, sb
0x000336:	str     	r1, [r5, #0x2c]
0x000338:	ldr     	r1, [r0, #0xc]
0x00033a:	ldr     	r4, [pc, #0x70]
0x00033c:	str     	r1, [r5, #0x30]
0x00033e:	ldr     	r1, [r0, #0x10]
0x000340:	str     	r1, [r5, #0x34]
0x000342:	ldr     	r1, [r0, #0x14]
0x000344:	str     	r1, [r5, #0x38]
0x000346:	ldr     	r1, [r0, #0x18]
0x000348:	str     	r1, [r5, #0x3c]
0x00034a:	ldr     	r1, [r0, #0x1c]
0x00034c:	str     	r1, [r5, #0x40]
0x00034e:	ldr     	r1, [r0, #0x20]
0x000350:	str     	r1, [r5, #0x44]
0x000352:	ldr     	r1, [r0, #0x24]
0x000354:	str     	r1, [r5, #0x48]
0x000356:	ldr     	r1, [r0, #0x28]
0x000358:	str     	r1, [r5, #0x4c]
0x00035a:	ldr     	r1, [r0, #0x2c]
0x00035c:	str     	r1, [r5, #0x50]
0x00035e:	ldr     	r1, [r0, #0x30]
0x000360:	str     	r1, [r5, #0x54]
0x000362:	ldr     	r1, [r0, #0x34]
0x000364:	str     	r1, [r5, #0x58]
0x000366:	ldr     	r1, [r0, #0x38]
0x000368:	str     	r1, [r5, #0x5c]
0x00036a:	ldr     	r1, [r0, #0x3c]
0x00036c:	str     	r1, [r5, #0x60]
0x00036e:	ldr     	r1, [r0, #0x40]
0x000370:	str     	r1, [r5, #0x64]
0x000372:	ldr     	r1, [r0, #0x44]
0x000374:	str     	r1, [r5, #0x68]
0x000376:	ldr     	r1, [r0, #0x48]
0x000378:	str     	r1, [r5, #0x6c]
0x00037a:	ldr     	r1, [r0, #0x4c]
0x00037c:	str     	r1, [r5, #0x70]
0x00037e:	movs    	r1, #0
0x000380:	str     	r1, [r2]
0x000382:	movs    	r1, #1
0x000384:	lsls    	r1, r1, #9
0x000386:	adds    	r0, r0, r1
0x000388:	ldr     	r3, [r0, #8]
0x00038a:	movs    	r1, #7
0x00038c:	adds    	r2, r4, #0
0x00038e:	movs    	r0, #0
0x000390:	blx     	r3
0x000392:	cmp     	r0, r4
0x000394:	bne     	#0x39a
0x000396:	subs    	r0, #2
0x000398:	str     	r0, [r5, #0x28]
0x00039a:	add     	sp, #0xc
0x00039c:	pop     	{r4, r5, pc}

; ===== candidate_0003b0 =====
0x0003b0:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0003b2:	sub     	sp, #0xc
0x0003b4:	adds    	r4, r1, #0
0x0003b6:	movs    	r1, #0
0x0003b8:	adds    	r7, r2, #0
0x0003ba:	movs    	r2, #0
0x0003bc:	movs    	r5, #0xff
0x0003be:	adds    	r5, #0x2e
0x0003c0:	str     	r2, [sp, #8]
0x0003c2:	str     	r1, [sp]
0x0003c4:	str     	r1, [sp, #4]
0x0003c6:	movs    	r6, #0xf1
0x0003c8:	lsls    	r6, r6, #9
0x0003ca:	movs    	r1, #0xe1
0x0003cc:	adds    	r2, r5, #0
0x0003ce:	movs    	r3, #0
0x0003d0:	adds    	r0, r6, #0
0x0003d2:	bl      	#0x2abc
0x0003d6:	cmp     	r0, #0
0x0003d8:	bne     	#0x3f0
0x0003da:	movs    	r1, #0
0x0003dc:	movs    	r2, #0
0x0003de:	str     	r2, [sp, #8]
0x0003e0:	str     	r1, [sp]
0x0003e2:	str     	r1, [sp, #4]
0x0003e4:	movs    	r1, #0x14
0x0003e6:	adds    	r2, r5, #0
0x0003e8:	movs    	r3, #1
0x0003ea:	adds    	r0, r6, #0
0x0003ec:	bl      	#0x2abc
0x0003f0:	ldr     	r0, [sp, #0xc]
0x0003f2:	cmp     	r0, #0xd
0x0003f4:	bhs     	#0x4a4
0x0003f6:	adr     	r3, #8
0x0003f8:	ldrb    	r3, [r3, r0]
0x0003fa:	lsls    	r3, r3, #1
0x0003fc:	add     	pc, r3
0x0003fe:	movs    	r0, r0
0x000400:	bxns    	r7
0x000402:	adds    	r2, #0x36
0x000404:	cmp     	r1, #0x2d
0x000406:	subs    	r4, r4, #4
0x000408:	asrs    	r3, r3, #0x18
0x00040a:	lsrs    	r1, r2, #0x10
0x00040c:	movs    	r7, r0
0x00040e:	bl      	#0x1684
0x000412:	movs    	r0, #0
0x000414:	add     	sp, #0x1c
0x000416:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0004b8 =====
0x0004b8:	push    	{r4, r5, r6, r7, lr}
0x0004ba:	sub     	sp, #0x14
0x0004bc:	movs    	r2, #0
0x0004be:	movs    	r1, #0
0x0004c0:	str     	r2, [sp, #8]
0x0004c2:	movs    	r2, #0xff
0x0004c4:	str     	r1, [sp]
0x0004c6:	str     	r1, [sp, #4]
0x0004c8:	movs    	r6, #0xf1
0x0004ca:	movs    	r5, #0
0x0004cc:	adds    	r3, r5, #0
0x0004ce:	lsls    	r6, r6, #9
0x0004d0:	movs    	r1, #0xe1
0x0004d2:	adds    	r2, #0x2f
0x0004d4:	adds    	r0, r6, #0
0x0004d6:	bl      	#0x2abc
0x0004da:	movs    	r7, #0xff
0x0004dc:	adds    	r7, #0x30
0x0004de:	cmp     	r0, #0
0x0004e0:	bgt     	#0x518
0x0004e2:	movs    	r1, #0
0x0004e4:	movs    	r2, #0
0x0004e6:	str     	r2, [sp, #8]
0x0004e8:	str     	r1, [sp]
0x0004ea:	str     	r1, [sp, #4]
0x0004ec:	movs    	r1, #0xe1
0x0004ee:	adds    	r2, r7, #0
0x0004f0:	adds    	r3, r5, #0
0x0004f2:	adds    	r0, r6, #0
0x0004f4:	bl      	#0x2abc
0x0004f8:	cmp     	r0, #0
0x0004fa:	bgt     	#0x518
0x0004fc:	movs    	r2, #0
0x0004fe:	movs    	r1, #0
0x000500:	str     	r2, [sp, #8]
0x000502:	ldr     	r2, [pc, #0x3cc]
0x000504:	str     	r1, [sp]
0x000506:	str     	r1, [sp, #4]
0x000508:	adds    	r3, r5, #0
0x00050a:	add     	r2, pc
0x00050c:	movs    	r1, #0x33
0x00050e:	adds    	r0, r6, #0
0x000510:	bl      	#0x2abc
0x000514:	add     	sp, #0x14
0x000516:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0008f8 =====
0x0008f8:	push    	{r4, r5, r6, r7, lr}
0x0008fa:	ldr     	r1, [pc, #0x1d4]
0x0008fc:	sub     	sp, #0xc
0x0008fe:	adds    	r4, r0, #0
0x000900:	add     	r1, pc
0x000902:	ldr     	r7, [pc, #0x1d0]
0x000904:	add     	r7, sb
0x000906:	ldr     	r2, [r7]
0x000908:	blx     	r2
0x00090a:	movs    	r5, #0xf1
0x00090c:	lsls    	r5, r5, #9
0x00090e:	movs    	r6, #0
0x000910:	cmp     	r0, #0
0x000912:	bne     	#0x95a
0x000914:	movs    	r1, #0
0x000916:	movs    	r2, #0
0x000918:	str     	r2, [sp, #8]
0x00091a:	str     	r1, [sp]
0x00091c:	str     	r1, [sp, #4]
0x00091e:	movs    	r1, #0x9c
0x000920:	movs    	r2, #0x12
0x000922:	adds    	r3, r6, #0
0x000924:	adds    	r0, r5, #0
0x000926:	bl      	#0x2abc
0x00092a:	movs    	r1, #0
0x00092c:	str     	r1, [sp]
0x00092e:	str     	r1, [sp, #4]
0x000930:	movs    	r2, #0
0x000932:	movs    	r1, #0x34
0x000934:	adds    	r3, r6, #0
0x000936:	adds    	r0, r5, #0
0x000938:	str     	r2, [sp, #8]
0x00093a:	bl      	#0x2abc
0x00093e:	movs    	r2, #0
0x000940:	movs    	r1, #0
0x000942:	str     	r2, [sp, #8]
0x000944:	movs    	r2, #0xff
0x000946:	str     	r1, [sp]
0x000948:	str     	r1, [sp, #4]
0x00094a:	movs    	r1, #0x50
0x00094c:	adds    	r2, #0xad
0x00094e:	adds    	r3, r6, #0
0x000950:	adds    	r0, r5, #0
0x000952:	bl      	#0x2abc
0x000956:	add     	sp, #0xc
0x000958:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000aec =====
0x000aec:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x000aee:	sub     	sp, #0x14
0x000af0:	movs    	r1, #0
0x000af2:	movs    	r2, #0
0x000af4:	str     	r2, [sp, #8]
0x000af6:	str     	r1, [sp]
0x000af8:	str     	r1, [sp, #4]
0x000afa:	movs    	r5, #0xf1
0x000afc:	movs    	r7, #0
0x000afe:	adds    	r3, r7, #0
0x000b00:	lsls    	r5, r5, #9
0x000b02:	movs    	r1, #0x44
0x000b04:	adds    	r2, r0, #0
0x000b06:	movs    	r6, #0
0x000b08:	adds    	r4, r0, #0
0x000b0a:	adds    	r0, r5, #0
0x000b0c:	bl      	#0x2abc
0x000b10:	ldr     	r0, [sp, #0x18]
0x000b12:	subs    	r0, #0xff
0x000b14:	subs    	r0, #0xad
0x000b16:	bne     	#0xb44
0x000b18:	ldr     	r0, [pc, #0x2f4]
0x000b1a:	movs    	r3, #0
0x000b1c:	add     	r0, sb
0x000b1e:	ldrsb   	r0, [r0, r3]
0x000b20:	cmp     	r0, #0
0x000b22:	beq     	#0xb38
0x000b24:	movs    	r1, #0
0x000b26:	str     	r1, [sp]
0x000b28:	str     	r1, [sp, #4]
0x000b2a:	movs    	r2, #0
0x000b2c:	movs    	r1, #0x2c
0x000b2e:	adds    	r3, r7, #0
0x000b30:	adds    	r0, r5, #0
0x000b32:	str     	r2, [sp, #8]
0x000b34:	bl      	#0x2abc
0x000b38:	ldr     	r1, [pc, #0x2d4]
0x000b3a:	movs    	r0, #1
0x000b3c:	add     	r1, sb
0x000b3e:	strb    	r0, [r1]
0x000b40:	bl      	#0x2f34
0x000b44:	movs    	r1, #0
0x000b46:	str     	r1, [sp]
0x000b48:	str     	r1, [sp, #4]
0x000b4a:	movs    	r2, #0
0x000b4c:	str     	r2, [sp, #8]
0x000b4e:	movs    	r1, #0x47
0x000b50:	adds    	r3, r7, #0
0x000b52:	movs    	r0, #0xf1
0x000b54:	lsls    	r0, r0, #9
0x000b56:	ldr     	r2, [r4, #8]
0x000b58:	bl      	#0x2abc
0x000b5c:	ldr     	r5, [pc, #0x2b4]
0x000b5e:	movs    	r1, #0
0x000b60:	add     	r5, sb
0x000b62:	str     	r0, [r5, #8]
0x000b64:	str     	r1, [sp]
0x000b66:	str     	r1, [sp, #4]
0x000b68:	movs    	r2, #0
0x000b6a:	str     	r2, [sp, #8]
0x000b6c:	movs    	r1, #0x46
0x000b6e:	movs    	r0, #0xf1
0x000b70:	adds    	r3, r7, #0
0x000b72:	lsls    	r0, r0, #9
0x000b74:	ldr     	r2, [r4, #8]
0x000b76:	bl      	#0x2abc
0x000b7a:	str     	r0, [r5, #0x50]
0x000b7c:	movs    	r1, #0
0x000b7e:	str     	r1, [sp]
0x000b80:	str     	r1, [sp, #4]
0x000b82:	movs    	r2, #0
0x000b84:	str     	r2, [sp, #8]
0x000b86:	movs    	r1, #0x46
0x000b88:	movs    	r0, #0xf1
0x000b8a:	adds    	r3, r7, #0
0x000b8c:	lsls    	r0, r0, #9
0x000b8e:	ldr     	r2, [r4, #8]
0x000b90:	bl      	#0x2abc
0x000b94:	lsls    	r0, r0, #0x18
0x000b96:	asrs    	r0, r0, #0x18
0x000b98:	cmp     	r0, #1
0x000b9a:	bne     	#0xbd6
0x000b9c:	movs    	r1, #0
0x000b9e:	str     	r1, [sp]
0x000ba0:	str     	r1, [sp, #4]
0x000ba2:	movs    	r2, #0
0x000ba4:	str     	r2, [sp, #8]
0x000ba6:	movs    	r1, #0x45
0x000ba8:	adds    	r3, r7, #0
0x000baa:	movs    	r0, #0xf1
0x000bac:	lsls    	r0, r0, #9
0x000bae:	ldr     	r2, [r4, #8]
0x000bb0:	bl      	#0x2abc
0x000bb4:	ldr     	r1, [pc, #0x258]
0x000bb6:	movs    	r2, #0
0x000bb8:	add     	r1, sb
0x000bba:	str     	r0, [r1, #4]
0x000bbc:	movs    	r1, #0
0x000bbe:	str     	r1, [sp]
0x000bc0:	str     	r1, [sp, #4]
0x000bc2:	movs    	r1, #0x47
0x000bc4:	str     	r2, [sp, #8]
0x000bc6:	movs    	r0, #0xf1
0x000bc8:	adds    	r3, r7, #0
0x000bca:	lsls    	r0, r0, #9
0x000bcc:	ldr     	r2, [r4, #8]
0x000bce:	bl      	#0x2abc
0x000bd2:	str     	r0, [r5, #0xc]
0x000bd4:	b       	#0xbe0
0x000bd6:	ldr     	r1, [pc, #0x238]
0x000bd8:	movs    	r0, #0
0x000bda:	mvns    	r0, r0
0x000bdc:	add     	r1, sb
0x000bde:	str     	r0, [r1, #4]
0x000be0:	movs    	r1, #0
0x000be2:	str     	r1, [sp]
0x000be4:	str     	r1, [sp, #4]
0x000be6:	movs    	r2, #0
0x000be8:	movs    	r7, #0
0x000bea:	adds    	r3, r7, #0
0x000bec:	str     	r2, [sp, #8]
0x000bee:	movs    	r1, #0x45
0x000bf0:	movs    	r0, #0xf1
0x000bf2:	lsls    	r0, r0, #9
0x000bf4:	ldr     	r2, [r4, #8]
0x000bf6:	bl      	#0x2abc
0x000bfa:	ldr     	r5, [pc, #0x218]
0x000bfc:	movs    	r1, #0
0x000bfe:	add     	r5, sb
0x000c00:	str     	r0, [r5, #0x10]
0x000c02:	str     	r1, [sp]
0x000c04:	str     	r1, [sp, #4]
0x000c06:	movs    	r2, #0
0x000c08:	str     	r2, [sp, #8]
0x000c0a:	movs    	r1, #0x47
0x000c0c:	movs    	r0, #0xf1
0x000c0e:	adds    	r3, r7, #0
0x000c10:	lsls    	r0, r0, #9
0x000c12:	ldr     	r2, [r4, #8]
0x000c14:	bl      	#0x2abc
0x000c18:	str     	r0, [r5, #0x14]

; ===== candidate_000e18 =====
0x000e18:	push    	{r4, r5, r6, r7, lr}
0x000e1a:	sub     	sp, #0xc
0x000e1c:	movs    	r1, #0
0x000e1e:	movs    	r2, #0
0x000e20:	str     	r2, [sp, #8]
0x000e22:	str     	r1, [sp]
0x000e24:	str     	r1, [sp, #4]
0x000e26:	movs    	r6, #0xf1
0x000e28:	movs    	r5, #0
0x000e2a:	adds    	r3, r5, #0
0x000e2c:	lsls    	r6, r6, #9
0x000e2e:	movs    	r1, #0x44
0x000e30:	adds    	r2, r0, #0
0x000e32:	adds    	r4, r0, #0
0x000e34:	adds    	r0, r6, #0
0x000e36:	bl      	#0x2abc
0x000e3a:	movs    	r1, #0
0x000e3c:	str     	r1, [sp]
0x000e3e:	str     	r1, [sp, #4]
0x000e40:	movs    	r2, #0
0x000e42:	str     	r2, [sp, #8]
0x000e44:	movs    	r1, #0x46
0x000e46:	adds    	r3, r5, #0
0x000e48:	adds    	r0, r6, #0
0x000e4a:	ldr     	r2, [r4, #8]
0x000e4c:	bl      	#0x2abc
0x000e50:	lsls    	r0, r0, #0x18
0x000e52:	ldr     	r7, [pc, #0x5c]
0x000e54:	asrs    	r0, r0, #0x18
0x000e56:	cmp     	r0, #1
0x000e58:	add     	r7, sb
0x000e5a:	bne     	#0xe8e
0x000e5c:	movs    	r1, #0
0x000e5e:	str     	r1, [sp]
0x000e60:	str     	r1, [sp, #4]
0x000e62:	movs    	r2, #0
0x000e64:	str     	r2, [sp, #8]
0x000e66:	movs    	r1, #0x45
0x000e68:	adds    	r3, r5, #0
0x000e6a:	adds    	r0, r6, #0
0x000e6c:	ldr     	r2, [r4, #8]
0x000e6e:	bl      	#0x2abc
0x000e72:	str     	r0, [r7, #0x34]
0x000e74:	movs    	r1, #0
0x000e76:	str     	r1, [sp]
0x000e78:	str     	r1, [sp, #4]
0x000e7a:	movs    	r2, #0
0x000e7c:	str     	r2, [sp, #8]
0x000e7e:	movs    	r1, #0x45
0x000e80:	adds    	r3, r5, #0
0x000e82:	adds    	r0, r6, #0
0x000e84:	ldr     	r2, [r4, #8]
0x000e86:	bl      	#0x2abc
0x000e8a:	str     	r0, [r7, #0x38]
0x000e8c:	b       	#0xe92
0x000e8e:	str     	r5, [r7, #0x34]
0x000e90:	str     	r5, [r7, #0x38]
0x000e92:	movs    	r1, #0
0x000e94:	str     	r1, [sp]
0x000e96:	str     	r1, [sp, #4]
0x000e98:	movs    	r2, #0
0x000e9a:	movs    	r1, #0x2c
0x000e9c:	adds    	r3, r5, #0
0x000e9e:	adds    	r0, r6, #0
0x000ea0:	str     	r2, [sp, #8]
0x000ea2:	bl      	#0x2abc
0x000ea6:	bl      	#0x2298
0x000eaa:	add     	sp, #0xc
0x000eac:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000eb4 =====
0x000eb4:	push    	{r4, r5, r6, r7, lr}
0x000eb6:	ldr     	r7, [pc, #0xd8]
0x000eb8:	adds    	r5, r0, #0
0x000eba:	ldr     	r0, [r0]
0x000ebc:	sub     	sp, #0xc
0x000ebe:	add     	r7, sb
0x000ec0:	str     	r0, [r7, #0x4c]
0x000ec2:	movs    	r1, #0
0x000ec4:	movs    	r6, #0
0x000ec6:	movs    	r2, #0
0x000ec8:	str     	r2, [sp, #8]
0x000eca:	adds    	r3, r6, #0
0x000ecc:	str     	r1, [sp]
0x000ece:	str     	r1, [sp, #4]
0x000ed0:	movs    	r1, #0x44
0x000ed2:	adds    	r2, r5, #0
0x000ed4:	movs    	r0, #0xf1
0x000ed6:	movs    	r4, #0
0x000ed8:	lsls    	r0, r0, #9
0x000eda:	bl      	#0x2abc
0x000ede:	bl      	#0x3090
0x000ee2:	movs    	r1, #0
0x000ee4:	str     	r1, [sp]
0x000ee6:	str     	r1, [sp, #4]
0x000ee8:	movs    	r2, #0
0x000eea:	str     	r2, [sp, #8]
0x000eec:	movs    	r1, #0x45
0x000eee:	adds    	r3, r6, #0
0x000ef0:	movs    	r0, #0xf1
0x000ef2:	lsls    	r0, r0, #9
0x000ef4:	ldr     	r2, [r5, #8]
0x000ef6:	bl      	#0x2abc
0x000efa:	str     	r0, [r7, #0x40]
0x000efc:	movs    	r1, #0
0x000efe:	str     	r1, [sp]
0x000f00:	str     	r1, [sp, #4]
0x000f02:	movs    	r2, #0
0x000f04:	str     	r2, [sp, #8]
0x000f06:	movs    	r1, #0x45
0x000f08:	movs    	r0, #0xf1
0x000f0a:	adds    	r3, r6, #0
0x000f0c:	lsls    	r0, r0, #9
0x000f0e:	ldr     	r2, [r5, #8]
0x000f10:	bl      	#0x2abc
0x000f14:	str     	r0, [r7, #0x3c]
0x000f16:	movs    	r1, #0
0x000f18:	str     	r1, [sp]
0x000f1a:	str     	r1, [sp, #4]
0x000f1c:	movs    	r2, #0
0x000f1e:	str     	r2, [sp, #8]
0x000f20:	movs    	r1, #0x45
0x000f22:	movs    	r0, #0xf1
0x000f24:	adds    	r3, r6, #0
0x000f26:	lsls    	r0, r0, #9
0x000f28:	ldr     	r2, [r5, #8]
0x000f2a:	bl      	#0x2abc
0x000f2e:	movs    	r2, #0
0x000f30:	movs    	r1, #0
0x000f32:	str     	r2, [sp, #8]
0x000f34:	adds    	r6, r0, #0
0x000f36:	adds    	r2, r0, #0
0x000f38:	str     	r1, [sp]
0x000f3a:	str     	r1, [sp, #4]
0x000f3c:	movs    	r1, #0xa
0x000f3e:	movs    	r0, #0xf1
0x000f40:	movs    	r3, #4
0x000f42:	lsls    	r0, r0, #9
0x000f44:	bl      	#0x2abc
0x000f48:	str     	r0, [r7, #0x44]
0x000f4a:	cmp     	r6, #0
0x000f4c:	ble     	#0xf72
0x000f4e:	movs    	r1, #0
0x000f50:	str     	r1, [sp]
0x000f52:	str     	r1, [sp, #4]
0x000f54:	movs    	r2, #0
0x000f56:	str     	r2, [sp, #8]
0x000f58:	movs    	r1, #0x47
0x000f5a:	movs    	r3, #0
0x000f5c:	movs    	r0, #0xf1
0x000f5e:	lsls    	r0, r0, #9
0x000f60:	ldr     	r2, [r5, #8]
0x000f62:	bl      	#0x2abc
0x000f66:	lsls    	r1, r4, #2
0x000f68:	ldr     	r2, [r7, #0x44]
0x000f6a:	adds    	r4, #1
0x000f6c:	cmp     	r4, r6
0x000f6e:	str     	r0, [r2, r1]
0x000f70:	blt     	#0xf4e
0x000f72:	movs    	r1, #0
0x000f74:	str     	r1, [sp]
0x000f76:	str     	r1, [sp, #4]
0x000f78:	movs    	r2, #0
0x000f7a:	movs    	r1, #0x2c
0x000f7c:	movs    	r3, #0
0x000f7e:	movs    	r0, #0xf1
0x000f80:	lsls    	r0, r0, #9
0x000f82:	str     	r2, [sp, #8]
0x000f84:	bl      	#0x2abc
0x000f88:	bl      	#0x2310
0x000f8c:	add     	sp, #0xc
0x000f8e:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000f94 =====
0x000f94:	push    	{r4, r5, r6, r7, lr}
0x000f96:	sub     	sp, #0x5c
0x000f98:	movs    	r1, #0
0x000f9a:	str     	r1, [sp]
0x000f9c:	str     	r1, [sp, #4]
0x000f9e:	movs    	r7, #0xf1
0x000fa0:	movs    	r2, #0
0x000fa2:	lsls    	r7, r7, #9
0x000fa4:	movs    	r1, #0x1c
0x000fa6:	movs    	r3, #0
0x000fa8:	adds    	r0, r7, #0
0x000faa:	str     	r2, [sp, #8]
0x000fac:	bl      	#0x2abc
0x000fb0:	movs    	r1, #0
0x000fb2:	movs    	r2, #0
0x000fb4:	str     	r2, [sp, #8]
0x000fb6:	str     	r1, [sp]
0x000fb8:	str     	r1, [sp, #4]
0x000fba:	movs    	r1, #0xe1
0x000fbc:	movs    	r2, #0xed
0x000fbe:	adds    	r6, r0, #0
0x000fc0:	movs    	r4, #0
0x000fc2:	movs    	r5, #0x23
0x000fc4:	movs    	r3, #0
0x000fc6:	adds    	r0, r7, #0
0x000fc8:	bl      	#0x2abc
0x000fcc:	cmp     	r0, #0
0x000fce:	ble     	#0x10b4
0x000fd0:	movs    	r1, #0
0x000fd2:	str     	r1, [sp]
0x000fd4:	str     	r1, [sp, #4]
0x000fd6:	movs    	r1, #0xff
0x000fd8:	movs    	r2, #0
0x000fda:	adds    	r1, #0x25
0x000fdc:	movs    	r3, #0
0x000fde:	adds    	r0, r7, #0
0x000fe0:	str     	r2, [sp, #8]
0x000fe2:	bl      	#0x2abc
0x000fe6:	movs    	r2, #0
0x000fe8:	movs    	r1, #0
0x000fea:	movs    	r0, #0
0x000fec:	bl      	#0x2a6c
0x000ff0:	add     	r2, sp, #0x44
0x000ff2:	str     	r2, [sp, #8]
0x000ff4:	movs    	r0, #0
0x000ff6:	ldr     	r2, [pc, #0x3e8]
0x000ff8:	add     	r1, sp, #0x48
0x000ffa:	movs    	r7, #0
0x000ffc:	adds    	r3, r7, #0
0x000ffe:	str     	r1, [sp, #4]
0x001000:	str     	r0, [sp]
0x001002:	add     	r2, pc
0x001004:	movs    	r1, #0x2a
0x001006:	movs    	r0, #0xf1
0x001008:	lsls    	r0, r0, #9
0x00100a:	bl      	#0x2abc
0x00100e:	ldr     	r0, [sp, #0x44]
0x001010:	movs    	r2, #0
0x001012:	adds    	r0, #6
0x001014:	str     	r0, [sp, #0x3c]
0x001016:	str     	r0, [sp, #4]
0x001018:	str     	r2, [sp, #8]
0x00101a:	adds    	r3, r7, #0
0x00101c:	adds    	r2, r7, #0
0x00101e:	movs    	r0, #0xf1
0x001020:	movs    	r1, #0x32
0x001022:	lsls    	r0, r0, #9
0x001024:	str     	r6, [sp]
0x001026:	bl      	#0x2abc
0x00102a:	movs    	r2, #0
0x00102c:	movs    	r1, #0
0x00102e:	ldr     	r6, [pc, #0x3b4]
0x001030:	str     	r2, [sp, #8]
0x001032:	str     	r1, [sp]
0x001034:	str     	r1, [sp, #4]
0x001036:	add     	r6, sb
0x001038:	ldr     	r0, [r6, #4]
0x00103a:	ldr     	r1, [r6, #0x1c]
0x00103c:	lsls    	r0, r0, #2
0x00103e:	ldr     	r3, [r1, r0]
0x001040:	ldr     	r2, [pc, #0x3a4]
0x001042:	add     	r2, pc
0x001044:	movs    	r1, #0x2d
0x001046:	movs    	r0, #0xf1
0x001048:	lsls    	r0, r0, #9
0x00104a:	bl      	#0x2abc
0x00104e:	movs    	r2, #0
0x001050:	movs    	r1, #0
0x001052:	ldr     	r3, [pc, #0x398]
0x001054:	str     	r1, [sp]
0x001056:	str     	r1, [sp, #4]
0x001058:	str     	r2, [sp, #8]
0x00105a:	add     	r3, pc
0x00105c:	adds    	r2, r0, #0
0x00105e:	movs    	r0, #0xf1
0x001060:	movs    	r1, #0x2d
0x001062:	lsls    	r0, r0, #9
0x001064:	bl      	#0x2abc
0x001068:	movs    	r2, #0
0x00106a:	movs    	r1, #0
0x00106c:	str     	r2, [sp, #8]
0x00106e:	str     	r1, [sp]
0x001070:	str     	r1, [sp, #4]
0x001072:	adds    	r3, r0, #0
0x001074:	ldr     	r0, [r6, #4]
0x001076:	ldr     	r1, [r6, #0x20]
0x001078:	lsls    	r0, r0, #2
0x00107a:	ldr     	r6, [r1, r0]
0x00107c:	movs    	r0, #0xf1
0x00107e:	lsls    	r0, r0, #9
0x001080:	movs    	r1, #0x2d
0x001082:	adds    	r2, r3, #0
0x001084:	adds    	r3, r6, #0
0x001086:	bl      	#0x2abc
0x00108a:	movs    	r2, #0
0x00108c:	movs    	r1, #0
0x00108e:	ldr     	r3, [pc, #0x360]
0x001090:	str     	r1, [sp]
0x001092:	str     	r1, [sp, #4]
0x001094:	str     	r2, [sp, #8]
0x001096:	add     	r3, pc
0x001098:	adds    	r2, r0, #0
0x00109a:	movs    	r0, #0xf1
0x00109c:	movs    	r1, #0x2d
0x00109e:	lsls    	r0, r0, #9
0x0010a0:	bl      	#0x2abc
0x0010a4:	movs    	r2, #0
0x0010a6:	movs    	r1, #0
0x0010a8:	adds    	r6, r0, #0
0x0010aa:	movs    	r0, #3
0x0010ac:	str     	r0, [sp]
0x0010ae:	str     	r1, [sp, #4]
0x0010b0:	str     	r2, [sp, #8]
0x0010b2:	b       	#0x10b6
0x0010b4:	b       	#0x165e
0x0010b6:	adds    	r2, r6, #0
0x0010b8:	movs    	r1, #0xff
0x0010ba:	adds    	r1, #0x38
0x0010bc:	movs    	r3, #0xa
0x0010be:	movs    	r0, #0xf1
0x0010c0:	lsls    	r0, r0, #9

; ===== candidate_001684 =====
0x001684:	push    	{r4, r5, r6, r7, lr}
0x001686:	sub     	sp, #0x3c
0x001688:	movs    	r1, #0
0x00168a:	str     	r1, [sp]
0x00168c:	str     	r1, [sp, #4]
0x00168e:	movs    	r4, #0xf1
0x001690:	movs    	r6, #0
0x001692:	movs    	r2, #0
0x001694:	adds    	r3, r6, #0
0x001696:	lsls    	r4, r4, #9
0x001698:	movs    	r1, #0x1c
0x00169a:	adds    	r0, r4, #0
0x00169c:	str     	r2, [sp, #8]
0x00169e:	bl      	#0x2abc
0x0016a2:	movs    	r1, #0
0x0016a4:	adds    	r7, r0, #0
0x0016a6:	movs    	r2, #0
0x0016a8:	str     	r2, [sp, #8]
0x0016aa:	movs    	r0, #0x19
0x0016ac:	str     	r1, [sp]
0x0016ae:	str     	r1, [sp, #4]
0x0016b0:	movs    	r1, #0xe1
0x0016b2:	str     	r0, [sp, #0x2c]
0x0016b4:	movs    	r2, #0xed
0x0016b6:	movs    	r5, #0
0x0016b8:	adds    	r3, r6, #0
0x0016ba:	adds    	r0, r4, #0
0x0016bc:	bl      	#0x2abc
0x0016c0:	cmp     	r0, #0
0x0016c2:	ble     	#0x17a8
0x0016c4:	movs    	r1, #0
0x0016c6:	str     	r1, [sp]
0x0016c8:	str     	r1, [sp, #4]
0x0016ca:	movs    	r1, #0xff
0x0016cc:	movs    	r2, #0
0x0016ce:	adds    	r1, #0x25
0x0016d0:	adds    	r3, r6, #0
0x0016d2:	adds    	r0, r4, #0
0x0016d4:	str     	r2, [sp, #8]
0x0016d6:	bl      	#0x2abc
0x0016da:	movs    	r2, #0
0x0016dc:	movs    	r1, #0
0x0016de:	movs    	r0, #0
0x0016e0:	bl      	#0x2a6c
0x0016e4:	add     	r2, sp, #0x30
0x0016e6:	str     	r2, [sp, #8]
0x0016e8:	movs    	r0, #0
0x0016ea:	ldr     	r2, [pc, #0x270]
0x0016ec:	add     	r1, sp, #0x34
0x0016ee:	str     	r1, [sp, #4]
0x0016f0:	str     	r0, [sp]
0x0016f2:	adds    	r3, r6, #0
0x0016f4:	add     	r2, pc
0x0016f6:	movs    	r1, #0x2a
0x0016f8:	adds    	r0, r4, #0
0x0016fa:	bl      	#0x2abc
0x0016fe:	ldr     	r4, [sp, #0x30]
0x001700:	movs    	r2, #0
0x001702:	adds    	r4, #0xa
0x001704:	movs    	r3, #0
0x001706:	movs    	r1, #0x32
0x001708:	movs    	r0, #0xf1
0x00170a:	lsls    	r0, r0, #9
0x00170c:	str     	r4, [sp, #4]
0x00170e:	str     	r2, [sp, #8]
0x001710:	str     	r7, [sp]
0x001712:	bl      	#0x2abc
0x001716:	ldr     	r0, [pc, #0x248]
0x001718:	add     	r0, sb
0x00171a:	ldr     	r0, [r0, #0x4c]
0x00171c:	adds    	r1, r0, #0
0x00171e:	subs    	r1, #0xff
0x001720:	subs    	r1, #0xaf
0x001722:	bne     	#0x172a
0x001724:	ldr     	r5, [pc, #0x23c]
0x001726:	add     	r5, pc
0x001728:	b       	#0x1742
0x00172a:	adds    	r1, r0, #0
0x00172c:	subs    	r1, #0xff
0x00172e:	subs    	r1, #0xb1
0x001730:	bne     	#0x1738
0x001732:	ldr     	r5, [pc, #0x234]
0x001734:	add     	r5, pc
0x001736:	b       	#0x1742
0x001738:	subs    	r0, #0xff
0x00173a:	subs    	r0, #0xb2
0x00173c:	bne     	#0x1742
0x00173e:	ldr     	r5, [pc, #0x22c]
0x001740:	add     	r5, pc
0x001742:	add     	r2, sp, #0x30
0x001744:	add     	r1, sp, #0x34
0x001746:	movs    	r0, #0
0x001748:	movs    	r6, #0
0x00174a:	adds    	r3, r6, #0
0x00174c:	str     	r0, [sp]
0x00174e:	str     	r1, [sp, #4]
0x001750:	str     	r2, [sp, #8]
0x001752:	adds    	r2, r5, #0
0x001754:	movs    	r1, #0x2a
0x001756:	movs    	r0, #0xf1
0x001758:	lsls    	r0, r0, #9
0x00175a:	bl      	#0x2abc
0x00175e:	ldr     	r0, [sp, #0x34]
0x001760:	str     	r6, [sp, #0x24]
0x001762:	subs    	r0, r7, r0
0x001764:	lsrs    	r1, r0, #0x1f
0x001766:	adds    	r0, r1, r0
0x001768:	asrs    	r0, r0, #1
0x00176a:	str     	r0, [sp, #0x10]
0x00176c:	movs    	r0, #3
0x00176e:	str     	r0, [sp, #0x14]
0x001770:	movs    	r0, #0xff
0x001772:	str     	r0, [sp, #0x20]
0x001774:	movs    	r1, #0
0x001776:	movs    	r2, #0
0x001778:	str     	r1, [sp]
0x00177a:	str     	r1, [sp, #4]
0x00177c:	str     	r0, [sp, #0x18]
0x00177e:	str     	r0, [sp, #0x1c]
0x001780:	str     	r6, [sp, #0x28]
0x001782:	str     	r2, [sp, #8]
0x001784:	movs    	r0, #0xf1
0x001786:	movs    	r1, #0x56
0x001788:	adds    	r3, r6, #0
0x00178a:	lsls    	r0, r0, #9
0x00178c:	add     	r2, sp, #0xc
0x00178e:	str     	r5, [sp, #0xc]
0x001790:	bl      	#0x2abc
0x001794:	movs    	r1, #0
0x001796:	str     	r1, [sp]
0x001798:	str     	r1, [sp, #4]
0x00179a:	movs    	r2, #0
0x00179c:	movs    	r1, #0x1d
0x00179e:	adds    	r3, r6, #0
0x0017a0:	movs    	r0, #0xf1
0x0017a2:	lsls    	r0, r0, #9
0x0017a4:	str     	r2, [sp, #8]
0x0017a6:	b       	#0x17aa
0x0017a8:	b       	#0x1958
0x0017aa:	bl      	#0x2abc
0x0017ae:	subs    	r5, r0, r4

; ===== candidate_001974 =====
0x001974:	push    	{r4, r5, r6, r7, lr}
0x001976:	ldr     	r6, [pc, #0xac]
0x001978:	sub     	sp, #0x2c
0x00197a:	add     	r6, pc
0x00197c:	movs    	r1, #0
0x00197e:	str     	r1, [sp]
0x001980:	str     	r1, [sp, #4]
0x001982:	movs    	r2, #0
0x001984:	ldr     	r7, [pc, #0xa0]
0x001986:	str     	r2, [sp, #8]
0x001988:	movs    	r1, #0x11
0x00198a:	movs    	r3, #4
0x00198c:	movs    	r0, #0xf1
0x00198e:	add     	r7, sb
0x001990:	ldr     	r2, [r7, #0x28]
0x001992:	lsls    	r0, r0, #9
0x001994:	bl      	#0x2abc
0x001998:	adds    	r4, r0, #0
0x00199a:	movs    	r0, #0
0x00199c:	add     	r2, sp, #0x24
0x00199e:	add     	r1, sp, #0x28
0x0019a0:	movs    	r5, #0
0x0019a2:	adds    	r3, r5, #0
0x0019a4:	str     	r1, [sp, #4]
0x0019a6:	str     	r2, [sp, #8]
0x0019a8:	str     	r0, [sp]
0x0019aa:	movs    	r0, #0xf1
0x0019ac:	adds    	r2, r6, #0
0x0019ae:	movs    	r1, #0x2a
0x0019b0:	lsls    	r0, r0, #9
0x0019b2:	bl      	#0x2abc
0x0019b6:	ldr     	r0, [sp, #0x24]
0x0019b8:	ldr     	r6, [sp, #0x28]
0x0019ba:	muls    	r4, r0, r4
0x0019bc:	ldr     	r0, [r7, #0x28]
0x0019be:	movs    	r1, #0
0x0019c0:	str     	r1, [sp]
0x0019c2:	str     	r1, [sp, #4]
0x0019c4:	movs    	r2, #0
0x0019c6:	adds    	r6, #0x32
0x0019c8:	adds    	r4, #0xa
0x0019ca:	str     	r0, [sp, #0xc]
0x0019cc:	movs    	r0, #0xf1
0x0019ce:	adds    	r3, r5, #0
0x0019d0:	movs    	r1, #0x1d
0x0019d2:	lsls    	r0, r0, #9
0x0019d4:	str     	r2, [sp, #8]
0x0019d6:	str     	r5, [sp, #0x10]
0x0019d8:	bl      	#0x2abc
0x0019dc:	subs    	r0, r0, r4
0x0019de:	subs    	r0, #0x14
0x0019e0:	str     	r0, [sp, #0x14]
0x0019e2:	ldr     	r0, [pc, #0x44]
0x0019e4:	movs    	r1, #0
0x0019e6:	add     	r0, sb
0x0019e8:	adds    	r0, #0x2c
0x0019ea:	str     	r0, [sp, #0x20]
0x0019ec:	movs    	r2, #0
0x0019ee:	str     	r1, [sp]
0x0019f0:	str     	r1, [sp, #4]
0x0019f2:	movs    	r1, #0x2b
0x0019f4:	str     	r2, [sp, #8]
0x0019f6:	movs    	r0, #0xf1
0x0019f8:	adds    	r3, r5, #0
0x0019fa:	lsls    	r0, r0, #9
0x0019fc:	add     	r2, sp, #0xc
0x0019fe:	str     	r6, [sp, #0x18]
0x001a00:	str     	r4, [sp, #0x1c]
0x001a02:	bl      	#0x2abc
0x001a06:	movs    	r1, #0
0x001a08:	movs    	r2, #0
0x001a0a:	str     	r2, [sp, #8]
0x001a0c:	str     	r1, [sp]
0x001a0e:	str     	r1, [sp, #4]
0x001a10:	movs    	r1, #0x24
0x001a12:	movs    	r2, #1
0x001a14:	movs    	r3, #1
0x001a16:	movs    	r0, #0xf1
0x001a18:	lsls    	r0, r0, #9
0x001a1a:	bl      	#0x2abc
0x001a1e:	add     	sp, #0x2c
0x001a20:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_001a2c =====
0x001a2c:	push    	{r4, r5, r6, r7, lr}
0x001a2e:	sub     	sp, #0x54
0x001a30:	movs    	r1, #0
0x001a32:	str     	r1, [sp]
0x001a34:	str     	r1, [sp, #4]
0x001a36:	movs    	r7, #0xf1
0x001a38:	movs    	r5, #0
0x001a3a:	movs    	r2, #0
0x001a3c:	adds    	r3, r5, #0
0x001a3e:	lsls    	r7, r7, #9
0x001a40:	movs    	r1, #0x1c
0x001a42:	adds    	r0, r7, #0
0x001a44:	str     	r2, [sp, #8]
0x001a46:	bl      	#0x2abc
0x001a4a:	movs    	r1, #0
0x001a4c:	movs    	r2, #0
0x001a4e:	str     	r2, [sp, #8]
0x001a50:	str     	r1, [sp]
0x001a52:	str     	r1, [sp, #4]
0x001a54:	movs    	r1, #0xe1
0x001a56:	movs    	r2, #0xed
0x001a58:	adds    	r4, r0, #0
0x001a5a:	adds    	r3, r5, #0
0x001a5c:	adds    	r0, r7, #0
0x001a5e:	bl      	#0x2abc
0x001a62:	cmp     	r0, #0
0x001a64:	ble     	#0x1b4c
0x001a66:	movs    	r1, #0
0x001a68:	str     	r1, [sp]
0x001a6a:	str     	r1, [sp, #4]
0x001a6c:	movs    	r1, #0xff
0x001a6e:	movs    	r2, #0
0x001a70:	adds    	r1, #0x25
0x001a72:	adds    	r3, r5, #0
0x001a74:	adds    	r0, r7, #0
0x001a76:	str     	r2, [sp, #8]
0x001a78:	bl      	#0x2abc
0x001a7c:	movs    	r2, #0
0x001a7e:	movs    	r1, #0
0x001a80:	movs    	r0, #0
0x001a82:	bl      	#0x2a6c
0x001a86:	add     	r2, sp, #0x48
0x001a88:	str     	r2, [sp, #8]
0x001a8a:	movs    	r0, #0
0x001a8c:	ldr     	r2, [pc, #0x3b0]
0x001a8e:	add     	r1, sp, #0x4c
0x001a90:	str     	r1, [sp, #4]
0x001a92:	str     	r0, [sp]
0x001a94:	adds    	r3, r5, #0
0x001a96:	add     	r2, pc
0x001a98:	movs    	r1, #0x2a
0x001a9a:	adds    	r0, r7, #0
0x001a9c:	bl      	#0x2abc
0x001aa0:	ldr     	r0, [sp, #0x48]
0x001aa2:	movs    	r2, #0
0x001aa4:	lsls    	r6, r0, #1
0x001aa6:	adds    	r6, r6, r0
0x001aa8:	lsls    	r3, r0, #2
0x001aaa:	adds    	r0, r3, r0
0x001aac:	adds    	r0, #0x10
0x001aae:	adds    	r6, #0xc
0x001ab0:	str     	r0, [sp, #0x34]
0x001ab2:	adds    	r3, r5, #0
0x001ab4:	movs    	r1, #0x32
0x001ab6:	adds    	r0, r7, #0
0x001ab8:	str     	r6, [sp, #4]
0x001aba:	str     	r2, [sp, #8]
0x001abc:	str     	r4, [sp]
0x001abe:	bl      	#0x2abc
0x001ac2:	movs    	r0, #0
0x001ac4:	str     	r0, [sp]
0x001ac6:	adds    	r3, r5, #0
0x001ac8:	movs    	r2, #7
0x001aca:	movs    	r1, #0x23
0x001acc:	adds    	r0, r7, #0
0x001ace:	str     	r4, [sp, #4]
0x001ad0:	str     	r6, [sp, #8]
0x001ad2:	bl      	#0x2abc
0x001ad6:	ldr     	r0, [pc, #0x36c]
0x001ad8:	movs    	r6, #5
0x001ada:	str     	r6, [sp, #0x44]
0x001adc:	add     	r0, sb
0x001ade:	ldr     	r7, [r0, #4]
0x001ae0:	adds    	r3, r7, #1
0x001ae2:	beq     	#0x1bac
0x001ae4:	movs    	r1, #0
0x001ae6:	movs    	r2, #0
0x001ae8:	str     	r2, [sp, #8]
0x001aea:	str     	r1, [sp]
0x001aec:	str     	r1, [sp, #4]
0x001aee:	adds    	r3, r5, #0
0x001af0:	adds    	r2, r7, #0
0x001af2:	movs    	r1, #0x3f
0x001af4:	movs    	r0, #0xf1
0x001af6:	lsls    	r0, r0, #9
0x001af8:	bl      	#0x2abc
0x001afc:	ldr     	r3, [pc, #0x348]
0x001afe:	adds    	r7, r0, #0
0x001b00:	add     	r3, pc
0x001b02:	movs    	r1, #0
0x001b04:	movs    	r2, #0
0x001b06:	str     	r2, [sp, #8]
0x001b08:	str     	r1, [sp]
0x001b0a:	str     	r1, [sp, #4]
0x001b0c:	movs    	r0, #0xf1
0x001b0e:	lsls    	r0, r0, #9
0x001b10:	movs    	r1, #0x2d
0x001b12:	adds    	r2, r3, #0
0x001b14:	adds    	r3, r7, #0
0x001b16:	bl      	#0x2abc
0x001b1a:	movs    	r1, #0
0x001b1c:	movs    	r2, #0
0x001b1e:	str     	r2, [sp, #8]
0x001b20:	str     	r1, [sp]
0x001b22:	str     	r1, [sp, #4]
0x001b24:	str     	r0, [sp, #0x38]
0x001b26:	adds    	r3, r5, #0
0x001b28:	adds    	r2, r7, #0
0x001b2a:	movs    	r0, #0xf1
0x001b2c:	movs    	r1, #9
0x001b2e:	lsls    	r0, r0, #9
0x001b30:	bl      	#0x2abc
0x001b34:	movs    	r2, #0
0x001b36:	movs    	r1, #0
0x001b38:	ldr     	r3, [pc, #0x310]
0x001b3a:	str     	r1, [sp]
0x001b3c:	str     	r1, [sp, #4]
0x001b3e:	str     	r2, [sp, #8]
0x001b40:	add     	r3, pc
0x001b42:	movs    	r1, #0x2d
0x001b44:	movs    	r0, #0xf1
0x001b46:	lsls    	r0, r0, #9
0x001b48:	ldr     	r2, [sp, #0x38]
0x001b4a:	b       	#0x1b4e
0x001b4c:	b       	#0x2220
0x001b4e:	bl      	#0x2abc
0x001b52:	adds    	r7, r0, #0
0x001b54:	movs    	r1, #0
0x001b56:	ldr     	r0, [pc, #0x2f8]
0x001b58:	movs    	r2, #0
0x001b5a:	str     	r2, [sp, #8]

; ===== candidate_002248 =====
0x002248:	push    	{r4, r5, r6, lr}
0x00224a:	sub     	sp, #0x18
0x00224c:	add     	r2, sp, #0x10
0x00224e:	str     	r2, [sp, #8]
0x002250:	movs    	r0, #0
0x002252:	ldr     	r2, [pc, #0x40]
0x002254:	add     	r1, sp, #0x14
0x002256:	movs    	r6, #0
0x002258:	movs    	r4, #0x19
0x00225a:	adds    	r3, r6, #0
0x00225c:	str     	r1, [sp, #4]
0x00225e:	str     	r0, [sp]
0x002260:	add     	r2, pc
0x002262:	movs    	r1, #0x2a
0x002264:	movs    	r0, #0xf1
0x002266:	lsls    	r0, r0, #9
0x002268:	bl      	#0x2abc
0x00226c:	ldr     	r5, [sp, #0x10]
0x00226e:	movs    	r1, #0
0x002270:	str     	r1, [sp]
0x002272:	str     	r1, [sp, #4]
0x002274:	movs    	r2, #0
0x002276:	adds    	r5, #0xa
0x002278:	adds    	r3, r6, #0
0x00227a:	movs    	r1, #0x1d
0x00227c:	movs    	r0, #0xf1
0x00227e:	lsls    	r0, r0, #9
0x002280:	str     	r2, [sp, #8]
0x002282:	bl      	#0x2abc
0x002286:	subs    	r1, r0, r5
0x002288:	subs    	r1, #0x32
0x00228a:	adds    	r0, r4, #0
0x00228c:	blx     	#0x20
0x002290:	add     	sp, #0x18
0x002292:	pop     	{r4, r5, r6, pc}

; ===== candidate_002298 =====
0x002298:	push    	{r4, lr}
0x00229a:	ldr     	r0, [pc, #0x70]
0x00229c:	movs    	r4, #0
0x00229e:	sub     	sp, #0x10
0x0022a0:	add     	r0, sb
0x0022a2:	str     	r4, [r0, #0x30]
0x0022a4:	movs    	r1, #0
0x0022a6:	str     	r1, [sp]
0x0022a8:	str     	r1, [sp, #4]
0x0022aa:	movs    	r2, #0
0x0022ac:	movs    	r1, #0x34
0x0022ae:	movs    	r0, #0xf1
0x0022b0:	adds    	r3, r4, #0
0x0022b2:	lsls    	r0, r0, #9
0x0022b4:	str     	r2, [sp, #8]
0x0022b6:	bl      	#0x2abc
0x0022ba:	movs    	r2, #0
0x0022bc:	movs    	r1, #0
0x0022be:	str     	r2, [sp, #8]
0x0022c0:	movs    	r2, #0xff
0x0022c2:	str     	r1, [sp]
0x0022c4:	str     	r1, [sp, #4]
0x0022c6:	adds    	r3, r4, #0
0x0022c8:	adds    	r2, #0x2f
0x0022ca:	movs    	r1, #0x14
0x0022cc:	movs    	r0, #0xf1
0x0022ce:	lsls    	r0, r0, #9
0x0022d0:	bl      	#0x2abc
0x0022d4:	movs    	r2, #0
0x0022d6:	movs    	r1, #0
0x0022d8:	str     	r2, [sp, #8]
0x0022da:	movs    	r2, #0xff
0x0022dc:	str     	r1, [sp]
0x0022de:	str     	r1, [sp, #4]
0x0022e0:	adds    	r3, r4, #0
0x0022e2:	adds    	r2, #0x30
0x0022e4:	movs    	r1, #0x14
0x0022e6:	movs    	r0, #0xf1
0x0022e8:	lsls    	r0, r0, #9
0x0022ea:	bl      	#0x2abc
0x0022ee:	movs    	r1, #0
0x0022f0:	movs    	r2, #0
0x0022f2:	str     	r2, [sp, #8]
0x0022f4:	str     	r1, [sp]
0x0022f6:	str     	r1, [sp, #4]
0x0022f8:	movs    	r3, #0xff
0x0022fa:	adds    	r3, #0x49
0x0022fc:	movs    	r1, #0x14
0x0022fe:	movs    	r2, #0x17
0x002300:	movs    	r0, #0xf1
0x002302:	lsls    	r0, r0, #9
0x002304:	bl      	#0x2abc
0x002308:	add     	sp, #0x10
0x00230a:	pop     	{r4, pc}

; ===== candidate_002310 =====
0x002310:	push    	{r4, r5, lr}
0x002312:	sub     	sp, #0xc
0x002314:	movs    	r1, #0
0x002316:	movs    	r2, #0
0x002318:	str     	r2, [sp, #8]
0x00231a:	str     	r1, [sp]
0x00231c:	str     	r1, [sp, #4]
0x00231e:	movs    	r5, #0xf1
0x002320:	movs    	r4, #0
0x002322:	adds    	r3, r4, #0
0x002324:	lsls    	r5, r5, #9
0x002326:	movs    	r1, #0xe1
0x002328:	movs    	r2, #0x17
0x00232a:	adds    	r0, r5, #0
0x00232c:	bl      	#0x2abc
0x002330:	subs    	r0, #0xff
0x002332:	subs    	r0, #0x4a
0x002334:	beq     	#0x234a
0x002336:	movs    	r1, #0
0x002338:	str     	r1, [sp]
0x00233a:	str     	r1, [sp, #4]
0x00233c:	movs    	r2, #0
0x00233e:	movs    	r1, #0x34
0x002340:	adds    	r3, r4, #0
0x002342:	adds    	r0, r5, #0
0x002344:	str     	r2, [sp, #8]
0x002346:	bl      	#0x2abc
0x00234a:	ldr     	r0, [pc, #0x20]
0x00234c:	movs    	r1, #0
0x00234e:	add     	r0, sb
0x002350:	str     	r4, [r0, #0x48]
0x002352:	movs    	r2, #0
0x002354:	str     	r2, [sp, #8]
0x002356:	str     	r1, [sp]
0x002358:	str     	r1, [sp, #4]
0x00235a:	movs    	r3, #0xff
0x00235c:	adds    	r3, #0x4a
0x00235e:	movs    	r1, #0x14
0x002360:	movs    	r2, #0x17
0x002362:	adds    	r0, r5, #0
0x002364:	bl      	#0x2abc
0x002368:	add     	sp, #0xc
0x00236a:	pop     	{r4, r5, pc}

; ===== candidate_002370 =====
0x002370:	push    	{r4, r5, r6, r7, lr}
0x002372:	sub     	sp, #0xc
0x002374:	movs    	r1, #0
0x002376:	str     	r1, [sp]
0x002378:	str     	r1, [sp, #4]
0x00237a:	movs    	r2, #0
0x00237c:	movs    	r1, #0x13
0x00237e:	movs    	r3, #0
0x002380:	movs    	r0, #0xf1
0x002382:	lsls    	r0, r0, #9
0x002384:	str     	r2, [sp, #8]
0x002386:	bl      	#0x2abc
0x00238a:	movs    	r1, #0
0x00238c:	str     	r1, [sp]
0x00238e:	str     	r1, [sp, #4]
0x002390:	adds    	r4, r0, #0
0x002392:	movs    	r2, #0
0x002394:	movs    	r0, #0xf1
0x002396:	movs    	r1, #0x34
0x002398:	movs    	r3, #0
0x00239a:	lsls    	r0, r0, #9
0x00239c:	str     	r2, [sp, #8]
0x00239e:	bl      	#0x2abc
0x0023a2:	movs    	r2, #0
0x0023a4:	movs    	r1, #0
0x0023a6:	ldr     	r5, [pc, #0x1e0]
0x0023a8:	str     	r1, [sp]
0x0023aa:	str     	r1, [sp, #4]
0x0023ac:	str     	r2, [sp, #8]
0x0023ae:	add     	r5, pc
0x0023b0:	adds    	r3, r5, #0
0x0023b2:	adds    	r2, r5, #0
0x0023b4:	adds    	r2, #0x98
0x0023b6:	movs    	r1, #0x35
0x0023b8:	movs    	r0, #0xf1
0x0023ba:	lsls    	r0, r0, #9
0x0023bc:	bl      	#0x2abc
0x0023c0:	movs    	r1, #0
0x0023c2:	adds    	r3, r0, #0
0x0023c4:	movs    	r2, #0
0x0023c6:	str     	r2, [sp, #8]
0x0023c8:	str     	r1, [sp]
0x0023ca:	str     	r1, [sp, #4]
0x0023cc:	movs    	r1, #0x36
0x0023ce:	adds    	r2, r4, #0
0x0023d0:	movs    	r0, #0xf1
0x0023d2:	lsls    	r0, r0, #9
0x0023d4:	bl      	#0x2abc
0x0023d8:	movs    	r2, #0
0x0023da:	movs    	r1, #0
0x0023dc:	str     	r2, [sp, #8]
0x0023de:	adds    	r2, r5, #0
0x0023e0:	str     	r1, [sp]
0x0023e2:	str     	r1, [sp, #4]
0x0023e4:	adds    	r3, r5, #0
0x0023e6:	adds    	r2, #0x88
0x0023e8:	movs    	r1, #0x35
0x0023ea:	movs    	r0, #0xf1
0x0023ec:	lsls    	r0, r0, #9
0x0023ee:	bl      	#0x2abc
0x0023f2:	movs    	r1, #0
0x0023f4:	adds    	r3, r0, #0
0x0023f6:	movs    	r2, #0
0x0023f8:	str     	r2, [sp, #8]
0x0023fa:	str     	r1, [sp]
0x0023fc:	str     	r1, [sp, #4]
0x0023fe:	movs    	r1, #0x36
0x002400:	adds    	r2, r4, #0
0x002402:	movs    	r0, #0xf1
0x002404:	lsls    	r0, r0, #9
0x002406:	bl      	#0x2abc
0x00240a:	movs    	r2, #0
0x00240c:	movs    	r1, #0
0x00240e:	str     	r2, [sp, #8]
0x002410:	adds    	r2, r5, #0
0x002412:	str     	r1, [sp]
0x002414:	str     	r1, [sp, #4]
0x002416:	adds    	r3, r5, #0
0x002418:	adds    	r2, #0x78
0x00241a:	movs    	r1, #0x35
0x00241c:	movs    	r0, #0xf1
0x00241e:	lsls    	r0, r0, #9
0x002420:	bl      	#0x2abc
0x002424:	movs    	r1, #0
0x002426:	adds    	r3, r0, #0
0x002428:	movs    	r2, #0
0x00242a:	str     	r2, [sp, #8]
0x00242c:	str     	r1, [sp]
0x00242e:	str     	r1, [sp, #4]
0x002430:	movs    	r1, #0x36
0x002432:	adds    	r2, r4, #0
0x002434:	movs    	r0, #0xf1
0x002436:	lsls    	r0, r0, #9
0x002438:	bl      	#0x2abc
0x00243c:	movs    	r2, #0
0x00243e:	movs    	r1, #0
0x002440:	str     	r2, [sp, #8]
0x002442:	adds    	r2, r5, #0
0x002444:	str     	r1, [sp]
0x002446:	str     	r1, [sp, #4]
0x002448:	adds    	r3, r5, #0
0x00244a:	adds    	r2, #0x6c
0x00244c:	movs    	r1, #0x35
0x00244e:	movs    	r0, #0xf1
0x002450:	lsls    	r0, r0, #9
0x002452:	bl      	#0x2abc
0x002456:	movs    	r1, #0
0x002458:	adds    	r3, r0, #0
0x00245a:	movs    	r2, #0
0x00245c:	str     	r2, [sp, #8]
0x00245e:	str     	r1, [sp]
0x002460:	str     	r1, [sp, #4]
0x002462:	movs    	r1, #0x36
0x002464:	adds    	r2, r4, #0
0x002466:	movs    	r0, #0xf1
0x002468:	lsls    	r0, r0, #9
0x00246a:	bl      	#0x2abc
0x00246e:	movs    	r2, #0
0x002470:	movs    	r1, #0
0x002472:	str     	r2, [sp, #8]
0x002474:	adds    	r2, r5, #0
0x002476:	str     	r1, [sp]
0x002478:	str     	r1, [sp, #4]
0x00247a:	adds    	r3, r5, #0
0x00247c:	adds    	r2, #0x60
0x00247e:	movs    	r1, #0x35
0x002480:	movs    	r0, #0xf1
0x002482:	lsls    	r0, r0, #9
0x002484:	bl      	#0x2abc
0x002488:	movs    	r1, #0
0x00248a:	adds    	r3, r0, #0
0x00248c:	movs    	r2, #0
0x00248e:	str     	r2, [sp, #8]
0x002490:	str     	r1, [sp]
0x002492:	str     	r1, [sp, #4]
0x002494:	movs    	r1, #0x36
0x002496:	adds    	r2, r4, #0
0x002498:	movs    	r0, #0xf1
0x00249a:	lsls    	r0, r0, #9
0x00249c:	bl      	#0x2abc
0x0024a0:	movs    	r2, #0

; ===== candidate_002590 =====
0x002590:	push    	{r4, r5, r6, lr}
0x002592:	sub     	sp, #0x10
0x002594:	movs    	r1, #0
0x002596:	str     	r1, [sp]
0x002598:	str     	r1, [sp, #4]
0x00259a:	movs    	r5, #0xf1
0x00259c:	movs    	r4, #0
0x00259e:	movs    	r2, #0
0x0025a0:	adds    	r3, r4, #0
0x0025a2:	lsls    	r5, r5, #9
0x0025a4:	movs    	r1, #0xba
0x0025a6:	adds    	r0, r5, #0
0x0025a8:	str     	r2, [sp, #8]
0x0025aa:	bl      	#0x2abc
0x0025ae:	ldr     	r1, [pc, #0x9c]
0x0025b0:	movs    	r0, #1
0x0025b2:	add     	r1, sb
0x0025b4:	strb    	r0, [r1]
0x0025b6:	movs    	r1, #0
0x0025b8:	movs    	r2, #0
0x0025ba:	str     	r2, [sp, #8]
0x0025bc:	str     	r1, [sp]
0x0025be:	str     	r1, [sp, #4]
0x0025c0:	movs    	r1, #0xe1
0x0025c2:	movs    	r2, #0x17
0x0025c4:	adds    	r3, r4, #0
0x0025c6:	adds    	r0, r5, #0
0x0025c8:	bl      	#0x2abc
0x0025cc:	subs    	r0, #0xff
0x0025ce:	subs    	r0, #0x47
0x0025d0:	beq     	#0x261c
0x0025d2:	movs    	r1, #0
0x0025d4:	str     	r1, [sp]
0x0025d6:	str     	r1, [sp, #4]
0x0025d8:	movs    	r2, #0
0x0025da:	movs    	r1, #0x34
0x0025dc:	adds    	r3, r4, #0
0x0025de:	adds    	r0, r5, #0
0x0025e0:	str     	r2, [sp, #8]
0x0025e2:	bl      	#0x2abc
0x0025e6:	ldr     	r6, [pc, #0x68]
0x0025e8:	movs    	r1, #0
0x0025ea:	add     	r6, sb
0x0025ec:	str     	r4, [r6, #4]
0x0025ee:	movs    	r2, #0
0x0025f0:	str     	r2, [sp, #8]
0x0025f2:	str     	r1, [sp]
0x0025f4:	str     	r1, [sp, #4]
0x0025f6:	movs    	r1, #0xe1
0x0025f8:	movs    	r2, #0x74
0x0025fa:	adds    	r3, r4, #0
0x0025fc:	adds    	r0, r5, #0
0x0025fe:	bl      	#0x2abc
0x002602:	str     	r0, [r6]
0x002604:	movs    	r1, #0
0x002606:	movs    	r2, #0
0x002608:	str     	r2, [sp, #8]
0x00260a:	str     	r1, [sp]
0x00260c:	str     	r1, [sp, #4]
0x00260e:	movs    	r1, #0x14
0x002610:	movs    	r2, #0x74
0x002612:	adds    	r3, r4, #0
0x002614:	adds    	r0, r5, #0
0x002616:	bl      	#0x2abc
0x00261a:	b       	#0x2630
0x00261c:	movs    	r1, #0
0x00261e:	str     	r1, [sp]
0x002620:	str     	r1, [sp, #4]
0x002622:	movs    	r2, #0
0x002624:	movs    	r1, #0x2c
0x002626:	adds    	r3, r4, #0
0x002628:	adds    	r0, r5, #0
0x00262a:	str     	r2, [sp, #8]
0x00262c:	bl      	#0x2abc
0x002630:	movs    	r1, #0
0x002632:	movs    	r2, #0
0x002634:	str     	r2, [sp, #8]
0x002636:	str     	r1, [sp]
0x002638:	str     	r1, [sp, #4]
0x00263a:	movs    	r3, #0xff
0x00263c:	adds    	r3, #0x47
0x00263e:	movs    	r1, #0x14
0x002640:	movs    	r2, #0x17
0x002642:	adds    	r0, r5, #0
0x002644:	bl      	#0x2abc
0x002648:	add     	sp, #0x10
0x00264a:	pop     	{r4, r5, r6, pc}

; ===== candidate_002654 =====
0x002654:	push    	{r4, r5, r6, lr}
0x002656:	sub     	sp, #0x10
0x002658:	movs    	r1, #0
0x00265a:	movs    	r2, #0
0x00265c:	str     	r2, [sp, #8]
0x00265e:	str     	r1, [sp]
0x002660:	str     	r1, [sp, #4]
0x002662:	movs    	r5, #0xf1
0x002664:	movs    	r6, #0
0x002666:	adds    	r3, r6, #0
0x002668:	lsls    	r5, r5, #9
0x00266a:	movs    	r1, #0xe1
0x00266c:	movs    	r2, #0x20
0x00266e:	adds    	r4, r0, #0
0x002670:	adds    	r0, r5, #0
0x002672:	bl      	#0x2abc
0x002676:	cmp     	r0, #1
0x002678:	bne     	#0x2684
0x00267a:	cmp     	r4, #0x14
0x00267c:	beq     	#0x2682
0x00267e:	cmp     	r4, #5
0x002680:	bne     	#0x2684
0x002682:	movs    	r4, #0x11
0x002684:	ldr     	r0, [pc, #0x94]
0x002686:	cmp     	r4, #0xd
0x002688:	add     	r0, sb
0x00268a:	beq     	#0x270e
0x00268c:	bgt     	#0x26ae
0x00268e:	cmp     	r4, #2
0x002690:	beq     	#0x269e
0x002692:	cmp     	r4, #5
0x002694:	beq     	#0x26ba
0x002696:	cmp     	r4, #8
0x002698:	beq     	#0x270e
0x00269a:	cmp     	r4, #0xc
0x00269c:	bne     	#0x26aa
0x00269e:	ldr     	r1, [r0, #0x30]
0x0026a0:	subs    	r1, #1
0x0026a2:	str     	r1, [r0, #0x30]
0x0026a4:	bpl     	#0x26aa
0x0026a6:	movs    	r1, #1
0x0026a8:	str     	r1, [r0, #0x30]
0x0026aa:	add     	sp, #0x10
0x0026ac:	pop     	{r4, r5, r6, pc}

; ===== candidate_002720 =====
0x002720:	push    	{r4, r5, r6, r7, lr}
0x002722:	ldr     	r4, [pc, #0xe4]
0x002724:	movs    	r5, #0xf1
0x002726:	add     	r4, sb
0x002728:	ldr     	r7, [r4, #0x44]
0x00272a:	adds    	r6, r0, #0
0x00272c:	movs    	r0, #0
0x00272e:	lsls    	r5, r5, #9
0x002730:	cmp     	r7, #0
0x002732:	sub     	sp, #0xc
0x002734:	beq     	#0x274c
0x002736:	movs    	r1, #0
0x002738:	movs    	r2, #0
0x00273a:	str     	r2, [sp, #8]
0x00273c:	str     	r1, [sp]
0x00273e:	str     	r1, [sp, #4]
0x002740:	movs    	r1, #0x11
0x002742:	adds    	r2, r7, #0
0x002744:	movs    	r3, #4
0x002746:	adds    	r0, r5, #0
0x002748:	bl      	#0x2abc
0x00274c:	subs    	r6, #2
0x00274e:	cmp     	r6, #0x11
0x002750:	bhs     	#0x2786
0x002752:	adr     	r3, #8
0x002754:	ldrb    	r3, [r3, r6]
0x002756:	lsls    	r3, r3, #1
0x002758:	add     	pc, r3
0x00275a:	movs    	r0, r0
0x00275c:	asrs    	r7, r3, #0x14
0x00275e:	asrs    	r6, r4, #0x14
0x002760:	asrs    	r5, r7, #0x14
0x002762:	asrs    	r7, r2, #0x14
0x002764:	asrs    	r5, r2, #0x14
0x002766:	asrs    	r7, r3, #0x1c
0x002768:	subs    	r5, #0x26
0x00276a:	asrs    	r5, r2, #0x14
0x00276c:	movs    	r1, r1
0x00276e:	bl      	#0x3090
0x002772:	movs    	r1, #0
0x002774:	str     	r1, [sp]
0x002776:	str     	r1, [sp, #4]
0x002778:	movs    	r2, #0
0x00277a:	movs    	r1, #0x2c
0x00277c:	movs    	r3, #0
0x00277e:	adds    	r0, r5, #0
0x002780:	str     	r2, [sp, #8]
0x002782:	bl      	#0x2abc
0x002786:	add     	sp, #0xc
0x002788:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00280c =====
0x00280c:	push    	{r4, r5, r6, r7, lr}
0x00280e:	sub     	sp, #0xc
0x002810:	movs    	r1, #0
0x002812:	str     	r1, [sp]
0x002814:	str     	r1, [sp, #4]
0x002816:	ldr     	r4, [pc, #0xa0]
0x002818:	movs    	r2, #0
0x00281a:	movs    	r6, #0xf1
0x00281c:	lsls    	r6, r6, #9
0x00281e:	str     	r2, [sp, #8]
0x002820:	movs    	r1, #0x11
0x002822:	adds    	r5, r0, #0
0x002824:	movs    	r3, #4
0x002826:	add     	r4, sb
0x002828:	ldr     	r2, [r4, #0x28]
0x00282a:	adds    	r0, r6, #0
0x00282c:	bl      	#0x2abc
0x002830:	adds    	r1, r5, #0
0x002832:	movs    	r5, #0
0x002834:	cmp     	r1, #0xd
0x002836:	beq     	#0x28a8
0x002838:	bgt     	#0x285a
0x00283a:	cmp     	r1, #2
0x00283c:	beq     	#0x284a
0x00283e:	cmp     	r1, #5
0x002840:	beq     	#0x2866
0x002842:	cmp     	r1, #8
0x002844:	beq     	#0x28a8
0x002846:	cmp     	r1, #0xc
0x002848:	bne     	#0x2856
0x00284a:	ldr     	r1, [r4, #0x2c]
0x00284c:	subs    	r1, #1
0x00284e:	str     	r1, [r4, #0x2c]
0x002850:	bpl     	#0x2856
0x002852:	subs    	r0, #1
0x002854:	str     	r0, [r4, #0x2c]
0x002856:	add     	sp, #0xc
0x002858:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0028bc =====
0x0028bc:	push    	{r4, r5, r6, lr}
0x0028be:	sub     	sp, #0x10
0x0028c0:	movs    	r1, #0
0x0028c2:	str     	r1, [sp]
0x0028c4:	str     	r1, [sp, #4]
0x0028c6:	ldr     	r4, [pc, #0x118]
0x0028c8:	movs    	r2, #0
0x0028ca:	movs    	r6, #0xf1
0x0028cc:	lsls    	r6, r6, #9
0x0028ce:	str     	r2, [sp, #8]
0x0028d0:	movs    	r1, #0x11
0x0028d2:	adds    	r5, r0, #0
0x0028d4:	movs    	r3, #4
0x0028d6:	add     	r4, sb
0x0028d8:	ldr     	r2, [r4, #0x1c]
0x0028da:	adds    	r0, r6, #0
0x0028dc:	bl      	#0x2abc
0x0028e0:	adds    	r1, r5, #0
0x0028e2:	movs    	r5, #0
0x0028e4:	cmp     	r1, #0xc
0x0028e6:	beq     	#0x2992
0x0028e8:	bgt     	#0x28fc
0x0028ea:	cmp     	r1, #1
0x0028ec:	beq     	#0x29ae
0x0028ee:	cmp     	r1, #2
0x0028f0:	beq     	#0x2992
0x0028f2:	cmp     	r1, #5
0x0028f4:	beq     	#0x290c
0x0028f6:	cmp     	r1, #8
0x0028f8:	bne     	#0x293a
0x0028fa:	b       	#0x299e
0x0028fc:	cmp     	r1, #0xd
0x0028fe:	beq     	#0x299e
0x002900:	cmp     	r1, #0x11
0x002902:	beq     	#0x298c
0x002904:	cmp     	r1, #0x12
0x002906:	beq     	#0x293e
0x002908:	cmp     	r1, #0x14
0x00290a:	bne     	#0x293a
0x00290c:	movs    	r1, #0
0x00290e:	str     	r1, [sp]
0x002910:	str     	r1, [sp, #4]
0x002912:	movs    	r2, #0
0x002914:	movs    	r1, #0x34
0x002916:	adds    	r3, r5, #0
0x002918:	adds    	r0, r6, #0
0x00291a:	str     	r2, [sp, #8]
0x00291c:	bl      	#0x2abc
0x002920:	movs    	r2, #0
0x002922:	movs    	r1, #0
0x002924:	str     	r2, [sp, #8]
0x002926:	str     	r1, [sp]
0x002928:	str     	r1, [sp, #4]
0x00292a:	movs    	r2, #0xff
0x00292c:	adds    	r2, #0xb0
0x00292e:	movs    	r1, #0x50
0x002930:	movs    	r0, #0xf1
0x002932:	lsls    	r0, r0, #9
0x002934:	ldr     	r3, [r4, #4]
0x002936:	bl      	#0x2abc
0x00293a:	add     	sp, #0x10
0x00293c:	pop     	{r4, r5, r6, pc}

; ===== candidate_0029e4 =====
0x0029e4:	push    	{r3, r4, r5, lr}
0x0029e6:	ldr     	r4, [pc, #0x74]
0x0029e8:	add     	r4, pc
0x0029ea:	ldr     	r0, [r4, #0x38]
0x0029ec:	movs    	r1, #0x14
0x0029ee:	ldr     	r2, [r0, #0x64]
0x0029f0:	ldr     	r0, [pc, #0x6c]
0x0029f2:	add     	r0, pc
0x0029f4:	blx     	r2
0x0029f6:	movs    	r5, #0
0x0029f8:	mvns    	r5, r5
0x0029fa:	cmp     	r0, r5
0x0029fc:	bne     	#0x2a02
0x0029fe:	adds    	r0, r5, #0
0x002a00:	pop     	{r3, r4, r5, pc}

; ===== candidate_002a6c =====
0x002a6c:	push    	{r4, lr}
0x002a6e:	sub     	sp, #0x10
0x002a70:	lsls    	r0, r0, #0x18
0x002a72:	lsrs    	r0, r0, #0x18
0x002a74:	str     	r0, [sp]
0x002a76:	ldr     	r0, [pc, #0x38]
0x002a78:	lsls    	r2, r2, #0x18
0x002a7a:	lsls    	r1, r1, #0x18
0x002a7c:	lsrs    	r1, r1, #0x18
0x002a7e:	lsrs    	r2, r2, #0x18
0x002a80:	str     	r2, [sp, #8]
0x002a82:	str     	r1, [sp, #4]
0x002a84:	add     	r0, pc
0x002a86:	ldr     	r0, [r0, #0x38]
0x002a88:	adds    	r1, r0, #0
0x002a8a:	adds    	r1, #0xff
0x002a8c:	adds    	r1, #0x41
0x002a8e:	ldr     	r2, [r1, #0x34]
0x002a90:	ldr     	r1, [r1, #0x30]
0x002a92:	ldr     	r2, [r2]
0x002a94:	ldr     	r1, [r1]
0x002a96:	lsls    	r3, r2, #0x10
0x002a98:	lsls    	r2, r1, #0x10
0x002a9a:	asrs    	r2, r2, #0x10
0x002a9c:	asrs    	r3, r3, #0x10
0x002a9e:	adds    	r0, #0xff
0x002aa0:	adds    	r0, #0xc1
0x002aa2:	ldr     	r4, [r0, #0x28]
0x002aa4:	movs    	r1, #0
0x002aa6:	movs    	r0, #0
0x002aa8:	blx     	r4
0x002aaa:	add     	sp, #0x10
0x002aac:	pop     	{r4, pc}

; ===== candidate_002abc =====
0x002abc:	push    	{r4, r5, r6, r7, lr}
0x002abe:	adds    	r5, r1, #0
0x002ac0:	adds    	r4, r0, #0
0x002ac2:	adds    	r6, r2, #0
0x002ac4:	ldr     	r2, [pc, #0x28]
0x002ac6:	sub     	sp, #0x14
0x002ac8:	mov     	ip, r3
0x002aca:	add     	r2, pc
0x002acc:	ldr     	r0, [sp, #0x2c]
0x002ace:	ldr     	r1, [sp, #0x30]
0x002ad0:	ldr     	r7, [sp, #0x28]
0x002ad2:	ldr     	r3, [r2, #0x3c]
0x002ad4:	movs    	r2, #2
0x002ad6:	str     	r2, [sp, #0xc]
0x002ad8:	str     	r1, [sp, #8]
0x002ada:	str     	r0, [sp, #4]
0x002adc:	str     	r7, [sp]
0x002ade:	ldr     	r0, [r3, #0xc]
0x002ae0:	adds    	r1, r5, #0
0x002ae2:	adds    	r2, r6, #0
0x002ae4:	ldr     	r7, [r0, #0x28]
0x002ae6:	adds    	r0, r4, #0
0x002ae8:	mov     	r3, ip
0x002aea:	blx     	r7
0x002aec:	add     	sp, #0x14
0x002aee:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002af8 =====
0x002af8:	push    	{r4, lr}
0x002afa:	movs    	r2, #0
0x002afc:	add     	r0, pc
0x002afe:	ldr     	r4, [r0, #0x3c]
0x002b00:	sub     	sp, #0x10
0x002b02:	movs    	r1, #0
0x002b04:	str     	r1, [sp, #4]
0x002b06:	str     	r1, [sp, #8]
0x002b08:	str     	r2, [sp, #0xc]
0x002b0a:	str     	r2, [sp]
0x002b0c:	ldr     	r0, [r4, #0xc]
0x002b0e:	ldr     	r2, [r0, #0x24]
0x002b10:	ldr     	r4, [r0, #0x28]
0x002b12:	blx     	r4
0x002b14:	add     	sp, #0x10
0x002b16:	pop     	{r4, pc}

; ===== candidate_002b1c =====
0x002b1c:	push    	{r4, lr}
0x002b1e:	ldr     	r0, [pc, #0x24]
0x002b20:	sub     	sp, #0x10
0x002b22:	add     	r0, pc
0x002b24:	ldr     	r3, [r0, #0x3c]
0x002b26:	movs    	r2, #0
0x002b28:	movs    	r1, #0
0x002b2a:	str     	r1, [sp, #4]
0x002b2c:	str     	r1, [sp, #8]
0x002b2e:	str     	r2, [sp, #0xc]
0x002b30:	str     	r2, [sp]
0x002b32:	ldr     	r0, [r3, #0xc]
0x002b34:	movs    	r3, #0
0x002b36:	ldr     	r2, [r0, #0x24]
0x002b38:	ldr     	r4, [r0, #0x28]
0x002b3a:	movs    	r1, #1
0x002b3c:	blx     	r4
0x002b3e:	add     	sp, #0x10
0x002b40:	pop     	{r4, pc}

; ===== candidate_002b5c =====
0x002b5c:	push    	{r4, lr}
0x002b5e:	sub     	sp, #0x10
0x002b60:	movs    	r2, #0
0x002b62:	movs    	r1, #0
0x002b64:	str     	r2, [sp, #8]
0x002b66:	ldr     	r2, [pc, #0x3c]
0x002b68:	str     	r1, [sp]
0x002b6a:	str     	r1, [sp, #4]
0x002b6c:	movs    	r3, #0
0x002b6e:	add     	r2, pc
0x002b70:	ldr     	r1, [pc, #0x34]
0x002b72:	ldr     	r0, [pc, #0x38]
0x002b74:	bl      	#0x2abc
0x002b78:	ldr     	r3, [pc, #0x38]
0x002b7a:	ldr     	r4, [pc, #0x34]
0x002b7c:	add     	r3, sb
0x002b7e:	ldr     	r3, [r3]
0x002b80:	movs    	r2, #0x41
0x002b82:	movs    	r1, #0
0x002b84:	add     	r4, sb
0x002b86:	adds    	r0, r4, #0
0x002b88:	blx     	r3
0x002b8a:	bl      	#0x2b48
0x002b8e:	ldr     	r3, [pc, #0x28]
0x002b90:	adds    	r1, r0, #0
0x002b92:	add     	r3, sb
0x002b94:	ldr     	r3, [r3]
0x002b96:	movs    	r2, #0x41
0x002b98:	adds    	r0, r4, #0
0x002b9a:	blx     	r3
0x002b9c:	movs    	r0, #0
0x002b9e:	add     	sp, #0x10
0x002ba0:	pop     	{r4, pc}

; ===== candidate_002bc0 =====
0x002bc0:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x002bc2:	adds    	r7, r3, #0
0x002bc4:	adds    	r6, r2, #0
0x002bc6:	adds    	r5, r0, #0
0x002bc8:	ldr     	r0, [r0]
0x002bca:	sub     	sp, #4
0x002bcc:	mov     	r1, sb
0x002bce:	str     	r1, [sp]
0x002bd0:	movs    	r4, #0
0x002bd2:	blx     	#0x2e0
0x002bd6:	ldr     	r0, [sp, #8]
0x002bd8:	cmp     	r0, #0xb
0x002bda:	bhs     	#0x2c48
0x002bdc:	adr     	r3, #4
0x002bde:	ldrb    	r3, [r3, r0]
0x002be0:	lsls    	r3, r3, #1
0x002be2:	add     	pc, r3
0x002be4:	lsrs    	r5, r0, #0x1c
0x002be6:	subs    	r4, r3, #4
0x002be8:	movs    	r4, #0x21
0x002bea:	adds    	r1, #0x27
0x002bec:	adds    	r1, #0x2b
0x002bee:	movs    	r7, r5
0x002bf0:	ldr     	r1, [pc, #0x60]
0x002bf2:	ldr     	r0, [r5, #0xc]
0x002bf4:	add     	r1, sb
0x002bf6:	str     	r0, [r1, #0x14]
0x002bf8:	bl      	#0x2e8
0x002bfc:	bl      	#0x2b5c
0x002c00:	adds    	r4, r0, #0
0x002c02:	b       	#0x2c48
0x002c04:	ldr     	r0, [r6]
0x002c06:	cmp     	r0, #8
0x002c08:	bne     	#0x2c12
0x002c0a:	bl      	#0x2ab8
0x002c0e:	adds    	r4, r0, #0
0x002c10:	b       	#0x2c48
0x002c12:	ldr     	r1, [r6, #4]
0x002c14:	ldr     	r2, [r6, #8]
0x002c16:	bl      	#0x2ab4
0x002c1a:	adds    	r4, r0, #0
0x002c1c:	b       	#0x2c48
0x002c1e:	bl      	#0x2e50
0x002c22:	b       	#0x2c48
0x002c24:	str     	r7, [r5, #0xc]
0x002c26:	b       	#0x2c48
0x002c28:	bl      	#0x2bbc
0x002c2c:	b       	#0x2c48
0x002c2e:	bl      	#0x2c8c
0x002c32:	b       	#0x2c48
0x002c34:	ldr     	r0, [pc, #0x1c]
0x002c36:	add     	r0, sb
0x002c38:	str     	r7, [r0, #0x1c]
0x002c3a:	b       	#0x2c48
0x002c3c:	ldr     	r0, [pc, #0x14]
0x002c3e:	add     	r0, sb
0x002c40:	str     	r6, [r0, #0x20]
0x002c42:	b       	#0x2c48
0x002c44:	ldr     	r4, [pc, #0x10]
0x002c46:	add     	r4, pc
0x002c48:	ldr     	r1, [sp]
0x002c4a:	add     	sp, #0x14
0x002c4c:	adds    	r0, r4, #0
0x002c4e:	mov     	sb, r1
0x002c50:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002c5c =====
0x002c5c:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x002c5e:	sub     	sp, #0xc
0x002c60:	ldr     	r0, [sp, #0x38]
0x002c62:	ldr     	r4, [sp, #0x3c]
0x002c64:	ldr     	r6, [sp, #0x34]
0x002c66:	ldr     	r0, [r0]
0x002c68:	mov     	r7, sb
0x002c6a:	movs    	r5, #0
0x002c6c:	blx     	#0x2e0
0x002c70:	cmp     	r4, #0
0x002c72:	beq     	#0x2c82
0x002c74:	ldr     	r1, [sp, #0x30]
0x002c76:	str     	r6, [sp, #4]
0x002c78:	add     	r3, sp, #0xc
0x002c7a:	str     	r1, [sp]
0x002c7c:	ldm     	r3, {r0, r1, r2, r3}
0x002c7e:	blx     	r4
0x002c80:	adds    	r5, r0, #0
0x002c82:	mov     	sb, r7
0x002c84:	adds    	r0, r5, #0
0x002c86:	add     	sp, #0x1c
0x002c88:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002cf0 =====
0x002cf0:	push    	{r3, r4, r5, r6, r7, lr}
0x002cf2:	adds    	r4, r0, #0
0x002cf4:	ldr     	r0, [pc, #0x10c]
0x002cf6:	movs    	r5, #0
0x002cf8:	mvns    	r5, r5
0x002cfa:	mov     	ip, r2
0x002cfc:	add     	r0, pc
0x002cfe:	ldr     	r2, [r0, #0x38]
0x002d00:	cmp     	r4, #0
0x002d02:	bne     	#0x2d14
0x002d04:	ldr     	r0, [pc, #0x100]
0x002d06:	ldr     	r2, [r2, #0x68]
0x002d08:	movs    	r1, #0x7d
0x002d0a:	lsls    	r1, r1, #3
0x002d0c:	add     	r0, pc
0x002d0e:	blx     	r2
0x002d10:	adds    	r0, r5, #0
0x002d12:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_002e1c =====
0x002e1c:	push    	{r3, r4, r5, lr}
0x002e1e:	ldr     	r4, [pc, #0x28]
0x002e20:	adds    	r5, r0, #0
0x002e22:	add     	r4, pc
0x002e24:	ldr     	r0, [r4, #0x38]
0x002e26:	adds    	r0, #0x80
0x002e28:	ldr     	r0, [r0, #4]
0x002e2a:	blx     	r0
0x002e2c:	adds    	r0, r0, r5
0x002e2e:	ldr     	r1, [pc, #0x1c]
0x002e30:	add     	r1, sb
0x002e32:	str     	r0, [r1, #0x10]
0x002e34:	ldr     	r0, [r4, #0x38]
0x002e36:	adds    	r0, #0x80
0x002e38:	ldr     	r0, [r0]
0x002e3a:	blx     	r0
0x002e3c:	ldr     	r0, [r4, #0x38]
0x002e3e:	ldr     	r1, [r0, #0x7c]
0x002e40:	lsls    	r0, r5, #0x10
0x002e42:	lsrs    	r0, r0, #0x10
0x002e44:	blx     	r1
0x002e46:	pop     	{r3, r4, r5, pc}

; ===== candidate_002e52 =====
0x002e52:	push    	{r3, r4, r5, r6, r7, lr}
0x002e54:	add     	r0, pc
0x002e56:	ldr     	r0, [r0, #0x38]
0x002e58:	adds    	r0, #0x80
0x002e5a:	ldr     	r0, [r0, #4]
0x002e5c:	blx     	r0
0x002e5e:	movs    	r5, #0
0x002e60:	ldr     	r6, [pc, #0xc8]
0x002e62:	add     	r6, sb
0x002e64:	ldr     	r1, [r6, #0x10]
0x002e66:	str     	r5, [r6, #0x10]
0x002e68:	subs    	r1, r0, r1
0x002e6a:	ldr     	r0, [r6, #8]
0x002e6c:	adds    	r3, r1, #0
0x002e6e:	cmp     	r0, #0
0x002e70:	beq     	#0x2f26
0x002e72:	ldr     	r2, [r0, #8]
0x002e74:	cmp     	r2, #0
0x002e76:	bne     	#0x2ed6
0x002e78:	mvns    	r7, r2
0x002e7a:	str     	r7, [r0, #8]
0x002e7c:	ldr     	r2, [r0, #0x18]
0x002e7e:	adds    	r4, r0, #0
0x002e80:	cmp     	r1, #0x32
0x002e82:	str     	r2, [r6, #8]
0x002e84:	bge     	#0x2e8a
0x002e86:	movs    	r1, #0x32
0x002e88:	b       	#0x2ea6
0x002e8a:	movs    	r2, #0x7d
0x002e8c:	lsls    	r2, r2, #4
0x002e8e:	cmp     	r1, r2
0x002e90:	ble     	#0x2ea6
0x002e92:	adds    	r1, r2, #0
0x002e94:	b       	#0x2ea6
0x002e96:	movs    	r7, #0
0x002e98:	mvns    	r7, r7
0x002e9a:	str     	r7, [r2, #8]
0x002e9c:	ldr     	r2, [r0, #0x18]
0x002e9e:	str     	r2, [r0, #0x1c]
0x002ea0:	ldr     	r0, [r2, #0x18]
0x002ea2:	str     	r0, [r6, #8]
0x002ea4:	adds    	r0, r2, #0
0x002ea6:	ldr     	r2, [r0, #0x18]
0x002ea8:	cmp     	r2, #0
0x002eaa:	beq     	#0x2eb2
0x002eac:	ldr     	r7, [r2, #8]
0x002eae:	cmp     	r7, r1
0x002eb0:	blt     	#0x2e96
0x002eb2:	str     	r5, [r0, #0x1c]
0x002eb4:	ldr     	r0, [r6, #8]
0x002eb6:	cmp     	r0, #0
0x002eb8:	beq     	#0x2f1a
0x002eba:	cmp     	r3, #0
0x002ebc:	bge     	#0x2ec0
0x002ebe:	movs    	r3, #0
0x002ec0:	ldr     	r0, [r6, #8]
0x002ec2:	ldr     	r1, [r0, #8]
0x002ec4:	cmp     	r1, #0
0x002ec6:	bge     	#0x2ecc
0x002ec8:	movs    	r1, #0
0x002eca:	str     	r5, [r0, #8]
0x002ecc:	ldr     	r2, [pc, #0x60]
0x002ece:	cmp     	r1, r2
0x002ed0:	ble     	#0x2eda
0x002ed2:	adds    	r1, r2, #0
0x002ed4:	b       	#0x2eda
0x002ed6:	movs    	r4, #0
0x002ed8:	b       	#0x2eba
0x002eda:	ldr     	r2, [r0, #8]
0x002edc:	subs    	r2, r2, r1
0x002ede:	str     	r2, [r0, #8]
0x002ee0:	ldr     	r0, [r0, #0x18]
0x002ee2:	cmp     	r0, #0
0x002ee4:	bne     	#0x2eda
0x002ee6:	subs    	r0, r1, r3
0x002ee8:	cmp     	r0, #0
0x002eea:	bgt     	#0x2eee
0x002eec:	movs    	r0, #0xa
0x002eee:	bl      	#0x2e1c
0x002ef2:	b       	#0x2f1a
0x002ef4:	str     	r5, [r4, #8]
0x002ef6:	ldr     	r0, [r4, #0x1c]
0x002ef8:	adds    	r3, r5, #0
0x002efa:	str     	r0, [r6, #0xc]
0x002efc:	ldr     	r0, [r4, #0x14]
0x002efe:	cmp     	r0, #0
0x002f00:	beq     	#0x2f0e
0x002f02:	str     	r0, [sp]
0x002f04:	movs    	r1, #0
0x002f06:	adds    	r0, r4, #0
0x002f08:	ldr     	r2, [r4, #0x10]
0x002f0a:	bl      	#0x2cf0
0x002f0e:	ldr     	r1, [r4, #0xc]
0x002f10:	cmp     	r1, #0
0x002f12:	beq     	#0x2f18
0x002f14:	ldr     	r0, [r4, #0x10]
0x002f16:	blx     	r1
0x002f18:	ldr     	r4, [r6, #0xc]
0x002f1a:	cmp     	r4, #0
0x002f1c:	beq     	#0x2f24
0x002f1e:	ldr     	r0, [r4, #8]
0x002f20:	cmp     	r0, #0
0x002f22:	blt     	#0x2ef4
0x002f24:	str     	r5, [r6, #0xc]
0x002f26:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_002f34 =====
0x002f34:	push    	{r4, r5, r6, r7, lr}
0x002f36:	ldr     	r4, [pc, #0x154]
0x002f38:	movs    	r7, #0xf1
0x002f3a:	add     	r4, sb
0x002f3c:	ldr     	r6, [r4, #0xc]
0x002f3e:	lsls    	r7, r7, #9
0x002f40:	movs    	r5, #0
0x002f42:	cmp     	r6, #0
0x002f44:	sub     	sp, #0xc
0x002f46:	beq     	#0x2f5e
0x002f48:	movs    	r1, #0
0x002f4a:	movs    	r2, #0
0x002f4c:	str     	r2, [sp, #8]
0x002f4e:	str     	r1, [sp]
0x002f50:	str     	r1, [sp, #4]
0x002f52:	movs    	r1, #9
0x002f54:	adds    	r2, r6, #0
0x002f56:	adds    	r3, r5, #0
0x002f58:	adds    	r0, r7, #0
0x002f5a:	bl      	#0x2abc
0x002f5e:	str     	r5, [r4, #0xc]
0x002f60:	ldr     	r6, [r4, #8]
0x002f62:	cmp     	r6, #0
0x002f64:	beq     	#0x2f7c
0x002f66:	movs    	r1, #0
0x002f68:	movs    	r2, #0
0x002f6a:	str     	r2, [sp, #8]
0x002f6c:	str     	r1, [sp]
0x002f6e:	str     	r1, [sp, #4]
0x002f70:	movs    	r1, #9
0x002f72:	adds    	r2, r6, #0
0x002f74:	adds    	r3, r5, #0
0x002f76:	adds    	r0, r7, #0
0x002f78:	bl      	#0x2abc
0x002f7c:	str     	r5, [r4, #8]
0x002f7e:	ldr     	r6, [r4, #0x14]
0x002f80:	cmp     	r6, #0
0x002f82:	beq     	#0x2f9a
0x002f84:	movs    	r1, #0
0x002f86:	movs    	r2, #0
0x002f88:	str     	r2, [sp, #8]
0x002f8a:	str     	r1, [sp]
0x002f8c:	str     	r1, [sp, #4]
0x002f8e:	movs    	r1, #9
0x002f90:	adds    	r2, r6, #0
0x002f92:	adds    	r3, r5, #0
0x002f94:	adds    	r0, r7, #0
0x002f96:	bl      	#0x2abc
0x002f9a:	str     	r5, [r4, #0x14]
0x002f9c:	ldr     	r6, [r4, #0x1c]
0x002f9e:	cmp     	r6, #0
0x002fa0:	beq     	#0x2fb8
0x002fa2:	movs    	r1, #0
0x002fa4:	movs    	r2, #0
0x002fa6:	str     	r2, [sp, #8]
0x002fa8:	str     	r1, [sp]
0x002faa:	str     	r1, [sp, #4]
0x002fac:	movs    	r1, #0x12
0x002fae:	adds    	r2, r6, #0
0x002fb0:	adds    	r3, r5, #0
0x002fb2:	adds    	r0, r7, #0
0x002fb4:	bl      	#0x2abc
0x002fb8:	str     	r5, [r4, #0x1c]
0x002fba:	ldr     	r6, [r4, #0x20]
0x002fbc:	cmp     	r6, #0
0x002fbe:	beq     	#0x2fd6
0x002fc0:	movs    	r1, #0
0x002fc2:	movs    	r2, #0
0x002fc4:	str     	r2, [sp, #8]
0x002fc6:	str     	r1, [sp]
0x002fc8:	str     	r1, [sp, #4]
0x002fca:	movs    	r1, #0x12
0x002fcc:	adds    	r2, r6, #0
0x002fce:	adds    	r3, r5, #0
0x002fd0:	adds    	r0, r7, #0
0x002fd2:	bl      	#0x2abc
0x002fd6:	ldr     	r4, [pc, #0xb4]
0x002fd8:	movs    	r3, #0
0x002fda:	add     	r4, sb
0x002fdc:	str     	r3, [r4, #0x20]
0x002fde:	ldr     	r4, [r4, #0x18]
0x002fe0:	cmp     	r4, #0
0x002fe2:	beq     	#0x3062
0x002fe4:	movs    	r1, #0
0x002fe6:	movs    	r2, #0
0x002fe8:	str     	r2, [sp, #8]
0x002fea:	str     	r1, [sp]
0x002fec:	str     	r1, [sp, #4]
0x002fee:	movs    	r1, #0x11
0x002ff0:	adds    	r2, r4, #0
0x002ff2:	movs    	r3, #4
0x002ff4:	adds    	r0, r7, #0
0x002ff6:	bl      	#0x2abc
0x002ffa:	adds    	r6, r0, #0
0x002ffc:	movs    	r4, #0
0x002ffe:	cmp     	r0, #0
0x003000:	ble     	#0x3044
0x003002:	ldr     	r1, [pc, #0x88]
0x003004:	lsls    	r0, r4, #2
0x003006:	add     	r1, sb
0x003008:	ldr     	r1, [r1, #0x18]
0x00300a:	ldr     	r5, [r1, r0]
0x00300c:	ldr     	r3, [r5]
0x00300e:	cmp     	r3, #0
0x003010:	beq     	#0x3028
0x003012:	movs    	r2, #0
0x003014:	movs    	r1, #0
0x003016:	str     	r2, [sp, #8]
0x003018:	adds    	r2, r3, #0
0x00301a:	str     	r1, [sp]
0x00301c:	str     	r1, [sp, #4]
0x00301e:	movs    	r1, #9
0x003020:	movs    	r3, #0
0x003022:	adds    	r0, r7, #0
0x003024:	bl      	#0x2abc
0x003028:	movs    	r1, #0
0x00302a:	movs    	r2, #0
0x00302c:	str     	r2, [sp, #8]
0x00302e:	str     	r1, [sp]
0x003030:	str     	r1, [sp, #4]
0x003032:	movs    	r1, #9
0x003034:	adds    	r2, r5, #0
0x003036:	movs    	r3, #0
0x003038:	adds    	r0, r7, #0
0x00303a:	bl      	#0x2abc
0x00303e:	adds    	r4, #1
0x003040:	cmp     	r4, r6
0x003042:	blt     	#0x3002
0x003044:	movs    	r1, #0
0x003046:	str     	r1, [sp]
0x003048:	str     	r1, [sp, #4]
0x00304a:	movs    	r2, #0
0x00304c:	ldr     	r5, [pc, #0x3c]
0x00304e:	movs    	r4, #0
0x003050:	adds    	r3, r4, #0
0x003052:	str     	r2, [sp, #8]
0x003054:	movs    	r1, #9
0x003056:	add     	r5, sb
0x003058:	ldr     	r2, [r5, #0x18]
0x00305a:	adds    	r0, r7, #0
0x00305c:	bl      	#0x2abc

; ===== candidate_003090 =====
0x003090:	push    	{r4, r5, r6, lr}
0x003092:	ldr     	r5, [pc, #0x2c]
0x003094:	sub     	sp, #0x10
0x003096:	add     	r5, sb
0x003098:	ldr     	r6, [r5, #0x44]
0x00309a:	cmp     	r6, #0
0x00309c:	beq     	#0x30ba
0x00309e:	movs    	r1, #0
0x0030a0:	movs    	r2, #0
0x0030a2:	movs    	r4, #0
0x0030a4:	adds    	r3, r4, #0
0x0030a6:	str     	r2, [sp, #8]
0x0030a8:	str     	r1, [sp]
0x0030aa:	str     	r1, [sp, #4]
0x0030ac:	movs    	r1, #0x12
0x0030ae:	adds    	r2, r6, #0
0x0030b0:	movs    	r0, #0xf1
0x0030b2:	lsls    	r0, r0, #9
0x0030b4:	bl      	#0x2abc
0x0030b8:	str     	r4, [r5, #0x44]
0x0030ba:	add     	sp, #0x10
0x0030bc:	pop     	{r4, r5, r6, pc}

; ===== candidate_0030c4 =====
0x0030c4:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x0030c6:	sub     	sp, #0x10
0x0030c8:	movs    	r1, #0
0x0030ca:	movs    	r5, #0xff
0x0030cc:	movs    	r2, #0
0x0030ce:	movs    	r4, #0
0x0030d0:	adds    	r3, r4, #0
0x0030d2:	str     	r2, [sp, #8]
0x0030d4:	adds    	r5, #0xae
0x0030d6:	str     	r1, [sp]
0x0030d8:	str     	r1, [sp, #4]
0x0030da:	movs    	r1, #0x17
0x0030dc:	adds    	r2, r5, #0
0x0030de:	movs    	r0, #0xf1
0x0030e0:	lsls    	r0, r0, #9
0x0030e2:	bl      	#0x2abc
0x0030e6:	movs    	r1, #0
0x0030e8:	movs    	r2, #0
0x0030ea:	str     	r2, [sp, #8]
0x0030ec:	str     	r1, [sp]
0x0030ee:	str     	r1, [sp, #4]
0x0030f0:	movs    	r1, #0xe1
0x0030f2:	movs    	r2, #0x1d
0x0030f4:	adds    	r3, r4, #0
0x0030f6:	movs    	r0, #0xf1
0x0030f8:	lsls    	r0, r0, #9
0x0030fa:	bl      	#0x2abc
0x0030fe:	movs    	r1, #0
0x003100:	adds    	r6, r0, #0
0x003102:	movs    	r2, #0
0x003104:	str     	r2, [sp, #8]
0x003106:	str     	r1, [sp]
0x003108:	str     	r1, [sp, #4]
0x00310a:	movs    	r1, #0xe1
0x00310c:	movs    	r2, #0x18
0x00310e:	movs    	r0, #0xf1
0x003110:	adds    	r3, r4, #0
0x003112:	lsls    	r0, r0, #9
0x003114:	bl      	#0x2abc
0x003118:	ldr     	r7, [r0, #0xc]
0x00311a:	movs    	r1, #0
0x00311c:	movs    	r2, #0
0x00311e:	str     	r2, [sp, #8]
0x003120:	str     	r1, [sp]
0x003122:	str     	r1, [sp, #4]
0x003124:	movs    	r1, #0xe1
0x003126:	movs    	r2, #0x18
0x003128:	movs    	r0, #0xf1
0x00312a:	adds    	r3, r4, #0
0x00312c:	lsls    	r0, r0, #9
0x00312e:	bl      	#0x2abc
0x003132:	ldr     	r3, [r0, #8]
0x003134:	movs    	r2, #0
0x003136:	str     	r2, [sp, #8]
0x003138:	adds    	r2, r5, #0
0x00313a:	movs    	r0, #0xf1
0x00313c:	movs    	r1, #0x52
0x00313e:	lsls    	r0, r0, #9
0x003140:	str     	r7, [sp]
0x003142:	str     	r6, [sp, #4]
0x003144:	bl      	#0x2abc
0x003148:	movs    	r1, #0
0x00314a:	movs    	r2, #0
0x00314c:	str     	r1, [sp]
0x00314e:	str     	r1, [sp, #4]
0x003150:	movs    	r1, #0x19
0x003152:	str     	r2, [sp, #8]
0x003154:	adds    	r3, r4, #0
0x003156:	movs    	r0, #0xf1
0x003158:	lsls    	r0, r0, #9
0x00315a:	ldr     	r2, [sp, #0x10]
0x00315c:	bl      	#0x2abc
0x003160:	movs    	r1, #0
0x003162:	movs    	r2, #0
0x003164:	str     	r1, [sp]
0x003166:	str     	r1, [sp, #4]
0x003168:	movs    	r1, #0x19
0x00316a:	str     	r2, [sp, #8]
0x00316c:	adds    	r3, r4, #0
0x00316e:	movs    	r0, #0xf1
0x003170:	lsls    	r0, r0, #9
0x003172:	ldr     	r2, [sp, #0x14]
0x003174:	bl      	#0x2abc
0x003178:	movs    	r1, #0
0x00317a:	movs    	r2, #0
0x00317c:	str     	r1, [sp]
0x00317e:	str     	r1, [sp, #4]
0x003180:	movs    	r1, #0x19
0x003182:	str     	r2, [sp, #8]
0x003184:	adds    	r3, r4, #0
0x003186:	movs    	r0, #0xf1
0x003188:	lsls    	r0, r0, #9
0x00318a:	ldr     	r2, [sp, #0x18]
0x00318c:	bl      	#0x2abc
0x003190:	movs    	r1, #0
0x003192:	movs    	r2, #0
0x003194:	str     	r2, [sp, #8]
0x003196:	str     	r1, [sp]
0x003198:	str     	r1, [sp, #4]
0x00319a:	movs    	r1, #0x1b
0x00319c:	movs    	r2, #1
0x00319e:	adds    	r3, r4, #0
0x0031a0:	movs    	r0, #0xf1
0x0031a2:	lsls    	r0, r0, #9
0x0031a4:	bl      	#0x2abc
0x0031a8:	add     	sp, #0x1c
0x0031aa:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0031ac =====
0x0031ac:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x0031ae:	sub     	sp, #0x10
0x0031b0:	movs    	r2, #0
0x0031b2:	movs    	r1, #0
0x0031b4:	movs    	r4, #0
0x0031b6:	adds    	r3, r4, #0
0x0031b8:	str     	r2, [sp, #8]
0x0031ba:	adds    	r5, r0, #0
0x0031bc:	adds    	r2, r0, #0
0x0031be:	str     	r1, [sp]
0x0031c0:	str     	r1, [sp, #4]
0x0031c2:	movs    	r1, #0x17
0x0031c4:	movs    	r0, #0xf1
0x0031c6:	lsls    	r0, r0, #9
0x0031c8:	bl      	#0x2abc
0x0031cc:	movs    	r1, #0
0x0031ce:	movs    	r2, #0
0x0031d0:	str     	r2, [sp, #8]
0x0031d2:	str     	r1, [sp]
0x0031d4:	str     	r1, [sp, #4]
0x0031d6:	movs    	r1, #0xe1
0x0031d8:	movs    	r2, #0x1d
0x0031da:	adds    	r3, r4, #0
0x0031dc:	movs    	r0, #0xf1
0x0031de:	lsls    	r0, r0, #9
0x0031e0:	bl      	#0x2abc
0x0031e4:	movs    	r1, #0
0x0031e6:	adds    	r6, r0, #0
0x0031e8:	movs    	r2, #0
0x0031ea:	str     	r2, [sp, #8]
0x0031ec:	str     	r1, [sp]
0x0031ee:	str     	r1, [sp, #4]
0x0031f0:	movs    	r1, #0xe1
0x0031f2:	movs    	r2, #0x18
0x0031f4:	movs    	r0, #0xf1
0x0031f6:	adds    	r3, r4, #0
0x0031f8:	lsls    	r0, r0, #9
0x0031fa:	bl      	#0x2abc
0x0031fe:	ldr     	r7, [r0, #0xc]
0x003200:	movs    	r1, #0
0x003202:	movs    	r2, #0
0x003204:	str     	r2, [sp, #8]
0x003206:	str     	r1, [sp]
0x003208:	str     	r1, [sp, #4]
0x00320a:	movs    	r1, #0xe1
0x00320c:	movs    	r2, #0x18
0x00320e:	movs    	r0, #0xf1
0x003210:	adds    	r3, r4, #0
0x003212:	lsls    	r0, r0, #9
0x003214:	bl      	#0x2abc
0x003218:	ldr     	r3, [r0, #8]
0x00321a:	movs    	r2, #0
0x00321c:	str     	r2, [sp, #8]
0x00321e:	adds    	r2, r5, #0
0x003220:	movs    	r0, #0xf1
0x003222:	movs    	r1, #0x52
0x003224:	lsls    	r0, r0, #9
0x003226:	str     	r7, [sp]
0x003228:	str     	r6, [sp, #4]
0x00322a:	bl      	#0x2abc
0x00322e:	movs    	r1, #0
0x003230:	movs    	r2, #0
0x003232:	str     	r1, [sp]
0x003234:	str     	r1, [sp, #4]
0x003236:	movs    	r1, #0x19
0x003238:	str     	r2, [sp, #8]
0x00323a:	adds    	r3, r4, #0
0x00323c:	movs    	r0, #0xf1
0x00323e:	lsls    	r0, r0, #9
0x003240:	ldr     	r2, [sp, #0x14]
0x003242:	bl      	#0x2abc
0x003246:	movs    	r1, #0
0x003248:	movs    	r2, #0
0x00324a:	str     	r1, [sp]
0x00324c:	str     	r1, [sp, #4]
0x00324e:	movs    	r1, #0x19
0x003250:	str     	r2, [sp, #8]
0x003252:	adds    	r3, r4, #0
0x003254:	movs    	r0, #0xf1
0x003256:	lsls    	r0, r0, #9
0x003258:	ldr     	r2, [sp, #0x18]
0x00325a:	bl      	#0x2abc
0x00325e:	movs    	r1, #0
0x003260:	movs    	r2, #0
0x003262:	str     	r2, [sp, #8]
0x003264:	str     	r1, [sp]
0x003266:	str     	r1, [sp, #4]
0x003268:	movs    	r1, #0x1b
0x00326a:	movs    	r2, #1
0x00326c:	adds    	r3, r4, #0
0x00326e:	movs    	r0, #0xf1
0x003270:	lsls    	r0, r0, #9
0x003272:	bl      	#0x2abc
0x003276:	add     	sp, #0x1c
0x003278:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00333c =====
0x00333c:	push    	{r0, r1, r2, r4, r5, r7, lr}
0x00333e:	bhi     	#0x32b8
0x003340:	movs    	r0, r0
0x003342:	movs    	r0, r0
0x003344:	ldm     	r6, {r0, r1, r4, r6, r7}

; ===== candidate_0033ce =====
0x0033ce:	push    	{r0, r1, r6, r7}
0x0033d0:	b       	#0x3540
0x0033d2:	bhs.w   	#0x101164
0x0033d6:	add     	r4, sp, #0x28c
0x0033d8:	cbnz    	r2, #0x3448
0x0033da:	bgt     	#0x3366
0x0033dc:	revsh   	r1, r2
0x0033de:	adr     	r2, #0x35c
0x0033e0:	movs    	r0, r0
0x0033e2:	movs    	r0, r0
0x0033e4:	cbnz    	r3, #0x3458
0x0033e6:	beq     	#0x3390
0x0033e8:	b       	#0x3996
0x0033ea:	push    	{r0, r1, r6, r7}
0x0033ec:	b       	#0x355c
0x0033ee:	bgt     	#0x337a
0x0033f0:	itttt   	gt

; ===== candidate_0033ea =====
0x0033ea:	push    	{r0, r1, r6, r7}
0x0033ec:	b       	#0x355c
0x0033ee:	bgt     	#0x337a
0x0033f0:	itttt   	gt

; ===== candidate_0034b6 =====
0x0034b6:	push    	{r0, r1, r2, r3, r4, r5, r7}
