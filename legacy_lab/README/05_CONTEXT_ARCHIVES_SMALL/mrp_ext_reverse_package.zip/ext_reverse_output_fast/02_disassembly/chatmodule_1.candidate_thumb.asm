; fallback candidate disassembly from Thumb prologues; true code is ARM entry + Thumb functions.

; ARM entry
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0x2cb8
0x000018:	pop     	{r4, pc}
0x00001c:	andeq   	r4, r0, r8, ror r7
0x000020:	cmp     	r0, #0
0x000024:	bxne    	lr
0x000028:	b       	#0x30
0x00002c:	andeq   	r4, r0, r8, ror r7
0x000030:	mov     	r0, #2
0x000034:	mov     	r1, #2
0x000038:	b       	#0x50
0x00003c:	strmi   	r4, [r8, -r0, lsl #14]

; ===== candidate_000008 =====
0x000008:	ands    	r0, r2
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	lsrs    	r7, r4, #0xc

; ===== candidate_00000a =====
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	lsrs    	r7, r4, #0xc

; ===== candidate_000052 =====
0x000052:	stmdb   	sp!, {r2}

; ===== candidate_00006c =====
0x00006c:	push    	{r4, r5, r6, lr}
0x00006e:	ldr     	r6, [pc, #0x38]
0x000070:	adds    	r5, r1, #0
0x000072:	adds    	r1, r0, #0
0x000074:	adds    	r4, r0, #0
0x000076:	add     	r6, pc
0x000078:	adds    	r0, r6, #0
0x00007a:	bl      	#0x7e
0x00007e:	adds    	r2, r0, #0
0x000080:	cmp     	r0, r6
0x000082:	bne     	#0x92
0x000084:	adds    	r1, r5, #0
0x000086:	adds    	r0, r4, #0
0x000088:	bl      	#0xcc
0x00008c:	pop     	{r4, r5, r6}
0x00008e:	pop     	{r3}
0x000090:	bx      	r3
0x000092:	ldr     	r0, [pc, #0x18]
0x000094:	add     	r0, pc
0x000096:	cmp     	r2, r0
0x000098:	beq     	#0xa2
0x00009a:	adds    	r1, r5, #0
0x00009c:	adds    	r0, r4, #0
0x00009e:	bl      	#0x40
0x0000a2:	movs    	r0, #0
0x0000a4:	b       	#0x8c
0x0000a6:	movs    	r0, r0

; ===== candidate_0000cc =====
0x0000cc:	push    	{r3, r4, r5, lr}
0x0000ce:	subs    	r2, r0, #1
0x0000d0:	cmp     	r2, #0xd
0x0000d2:	adr     	r4, #0x90
0x0000d4:	bhs     	#0x124
0x0000d6:	movs    	r2, #0x17
0x0000d8:	ldr     	r3, [pc, #0x8c]
0x0000da:	muls    	r2, r0, r2
0x0000dc:	add     	r3, pc
0x0000de:	adds    	r5, r2, r3
0x0000e0:	subs    	r5, #0x17
0x0000e2:	cmp     	r0, #2
0x0000e4:	bne     	#0x110
0x0000e6:	lsls    	r0, r1, #5
0x0000e8:	bpl     	#0xee
0x0000ea:	adr     	r4, #0x80
0x0000ec:	b       	#0x126
0x0000ee:	ldr     	r0, [pc, #0x90]
0x0000f0:	ands    	r0, r1
0x0000f2:	beq     	#0xf8
0x0000f4:	adr     	r4, #0x8c
0x0000f6:	b       	#0x126
0x0000f8:	lsls    	r0, r1, #3
0x0000fa:	bpl     	#0x100
0x0000fc:	adr     	r4, #0x94
0x0000fe:	b       	#0x126
0x000100:	lsls    	r0, r1, #2
0x000102:	bpl     	#0x108
0x000104:	adr     	r4, #0x98
0x000106:	b       	#0x126
0x000108:	lsls    	r0, r1, #1
0x00010a:	bpl     	#0x126
0x00010c:	adr     	r4, #0x9c
0x00010e:	b       	#0x126
0x000110:	cmp     	r0, #8
0x000112:	bne     	#0x118
0x000114:	adds    	r4, r1, #0
0x000116:	b       	#0x126
0x000118:	cmp     	r0, #9
0x00011a:	bne     	#0x126
0x00011c:	cmp     	r1, #1
0x00011e:	bne     	#0x126
0x000120:	adr     	r5, #0x98
0x000122:	b       	#0x126
0x000124:	adr     	r5, #0xac
0x000126:	movs    	r0, #0xa
0x000128:	bl      	#0x1ec
0x00012c:	ldrb    	r0, [r5]
0x00012e:	cmp     	r0, #0
0x000130:	beq     	#0x140
0x000132:	ldrb    	r0, [r5]
0x000134:	adds    	r5, #1
0x000136:	bl      	#0x1ec
0x00013a:	ldrb    	r0, [r5]
0x00013c:	cmp     	r0, #0
0x00013e:	bne     	#0x132
0x000140:	ldrb    	r0, [r4]
0x000142:	cmp     	r0, #0
0x000144:	beq     	#0x154
0x000146:	ldrb    	r0, [r4]
0x000148:	adds    	r4, #1
0x00014a:	bl      	#0x1ec
0x00014e:	ldrb    	r0, [r4]
0x000150:	cmp     	r0, #0
0x000152:	bne     	#0x146
0x000154:	movs    	r0, #0xa
0x000156:	bl      	#0x1ec
0x00015a:	pop     	{r3, r4, r5}
0x00015c:	pop     	{r3}
0x00015e:	movs    	r0, #1
0x000160:	bx      	r3
0x000162:	movs    	r0, r0
0x000164:	movs    	r0, r0
0x000166:	movs    	r0, r0
0x000168:	subs    	r1, #0x6c
0x00016a:	movs    	r0, r0
0x00016c:	ldr     	r1, [r1, #0x64]
0x00016e:	str     	r6, [r6, #0x14]
0x000170:	ldr     	r4, [r5, #0x14]
0x000172:	movs    	r0, #0x64
0x000174:	strb    	r7, [r1, #1]
0x000176:	strb    	r5, [r4, #9]
0x000178:	strb    	r1, [r4, #0x11]
0x00017a:	ldr     	r1, [r5, #0x74]
0x00017c:	lsls    	r6, r5, #1
0x00017e:	movs    	r0, r0
0x000180:	movs    	r2, r0
0x000182:	lsrs    	r0, r0, #0x20
0x000184:	ldr     	r4, [r0, #0x14]
0x000186:	ldr     	r6, [r6, #0x14]
0x000188:	str     	r4, [r4, #0x54]
0x00018a:	tst     	r0, r4
0x00018c:	movs    	r0, #0x79
0x00018e:	str     	r2, [r3, #0x54]
0x000190:	ldr     	r2, [r6, #0x74]
0x000192:	movs    	r0, r0
0x000194:	strb    	r7, [r1, #0x19]
0x000196:	strb    	r5, [r4, #9]
0x000198:	ldr     	r6, [r4, #0x44]
0x00019a:	strb    	r7, [r5, #0x1d]
0x00019c:	movs    	r0, r0
0x00019e:	movs    	r0, r0
0x0001a0:	ldr     	r5, [r2, #0x64]
0x0001a2:	str     	r4, [r4, #0x54]
0x0001a4:	str     	r2, [r6, #0x64]
0x0001a6:	ldr     	r4, [r5, #0x74]
0x0001a8:	lsls    	r7, r6, #1
0x0001aa:	movs    	r0, r0
0x0001ac:	ldr     	r1, [r1, #0x64]
0x0001ae:	ldrb    	r5, [r4, #1]
0x0001b0:	str     	r1, [r4, #0x34]
0x0001b2:	movs    	r0, #0x74
0x0001b4:	str     	r2, [r2, #0x54]
0x0001b6:	strb    	r3, [r6, #0x15]
0x0001b8:	strb    	r4, [r5, #0x11]
0x0001ba:	movs    	r0, r0
0x0001bc:	movs    	r0, #0x3a
0x0001be:	str     	r0, [r1, #0x54]
0x0001c0:	strb    	r1, [r4, #1]
0x0001c2:	ldr     	r0, [r4, #0x50]
0x0001c4:	ldr     	r5, [r4, #0x54]
0x0001c6:	strb    	r7, [r5, #9]
0x0001c8:	movs    	r0, #0x79
0x0001ca:	ldr     	r3, [r4, #0x74]
0x0001cc:	strb    	r2, [r6, #9]
0x0001ce:	strb    	r5, [r6, #1]
0x0001d0:	str     	r4, [r6, #0x54]
0x0001d2:	lsls    	r4, r4, #1
0x0001d4:	ldr     	r5, [r2, #0x64]
0x0001d6:	ldr     	r3, [r5, #0x64]
0x0001d8:	strb    	r7, [r5, #0x1d]
0x0001da:	movs    	r0, #0x6e
0x0001dc:	ldr     	r3, [r6, #0x14]
0x0001de:	ldr     	r7, [r4, #0x64]
0x0001e0:	ldr     	r1, [r4, #0x44]
0x0001e2:	movs    	r0, r0
0x0001e4:	bx      	pc

; ===== candidate_0001ec =====
0x0001ec:	push    	{r3, lr}
0x0001ee:	add     	r3, sp, #0
0x0001f0:	strb    	r0, [r3]
0x0001f2:	movs    	r0, #3
0x0001f4:	mov     	r1, sp
0x0001f6:	svc     	#0xab
0x0001f8:	add     	sp, #4
0x0001fa:	pop     	{r3}
0x0001fc:	bx      	r3
0x0001fe:	movs    	r0, r0
0x000200:	movs    	r0, r1
0x000202:	b       	#0xfffffd44
0x000204:	asrs    	r0, r1, #0x20
0x000206:	b       	#0xfffffd48
0x000208:	movs    	r1, r0
0x00020a:	b       	#0x30e
0x00020c:	vrhadd.u16	d14, d14, d31
0x000210:	movs    	r4, r0
0x000212:	movs    	r0, r0
0x000214:	lsls    	r0, r1, #6
0x000216:	movs    	r0, r0
0x000218:	str     	r0, [sp]
0x00021a:	b       	#0x55e
0x00021c:	vrhadd.u16	d14, d14, d31
0x000220:	adds    	r0, #0x14
0x000222:	b       	#0xfffffd64
0x000224:	cmp     	r7, #0xc0
0x000226:	b       	#0x56a
0x000228:	stm     	r0!, {r0, r1, r4, r7}
0x00022a:	b       	#0x3b0
0x00022c:	adds    	r0, #9
0x00022e:	b       	#0x9f2
0x000230:	asrs    	r1, r0, #5
0x000232:	b       	#0x2fa
0x000234:	lsls    	r3, r2, #6
0x000236:	b       	#0x27a
0x000238:	vrhadd.u16	d14, d14, d31
0x00023c:	str     	r7, [r4, #0x64]
0x00023e:	str     	r6, [r4, #0x64]
0x000240:	adds    	r0, #0x14
0x000242:	b       	#0xfffffd84
0x000244:	cmp     	r7, #0xc0
0x000246:	b       	#0x58a
0x000248:	stm     	r0!, {r0, r1, r4, r7}
0x00024a:	b       	#0x3d0
0x00024c:	adds    	r0, #0xc
0x00024e:	b       	#0xfffffd90
0x000250:	asrs    	r1, r0, #0xd
0x000252:	b       	#0x31a
0x000254:	lsls    	r3, r2, #6
0x000256:	b       	#0x29a
0x000258:	vrhadd.u16	d14, d14, d31
0x00025c:	ldr     	r5, [pc, #0x34c]
0x00025e:	asrs    	r2, r4, #1

; ===== candidate_000264 =====
0x000264:	push    	{r4, r5, lr}
0x000266:	ldr     	r4, [pc, #0xb4]
0x000268:	movs    	r2, #0x1c
0x00026a:	add     	r4, pc
0x00026c:	ldr     	r0, [r4, #0x38]
0x00026e:	movs    	r1, #0
0x000270:	ldr     	r3, [r0, #0x38]
0x000272:	ldr     	r0, [pc, #0xac]
0x000274:	sub     	sp, #0xc
0x000276:	add     	r0, sb
0x000278:	blx     	r3
0x00027a:	movs    	r2, #0
0x00027c:	movs    	r0, #0
0x00027e:	str     	r0, [sp]
0x000280:	ldr     	r1, [pc, #0x9c]
0x000282:	movs    	r3, #0
0x000284:	add     	r1, sb
0x000286:	str     	r1, [sp, #4]
0x000288:	movs    	r1, #0x64
0x00028a:	movs    	r0, #1
0x00028c:	str     	r2, [sp, #8]
0x00028e:	bl      	#0x2d90
0x000292:	ldr     	r1, [pc, #0x8c]
0x000294:	movs    	r0, #0
0x000296:	add     	r1, sb
0x000298:	subs    	r1, #0x7c
0x00029a:	str     	r0, [r1, #8]
0x00029c:	ldr     	r5, [pc, #0x80]
0x00029e:	str     	r0, [r1, #0x10]
0x0002a0:	str     	r0, [r1, #0xc]
0x0002a2:	add     	r5, sb
0x0002a4:	subs    	r5, #0xfc
0x0002a6:	movs    	r0, #1
0x0002a8:	str     	r0, [r5, #0x18]
0x0002aa:	ldr     	r0, [r4, #0x38]
0x0002ac:	ldr     	r2, [pc, #0x74]
0x0002ae:	ldr     	r1, [r0, #0x68]
0x0002b0:	add     	r2, sb
0x0002b2:	str     	r1, [r5, #0x2c]
0x0002b4:	ldr     	r1, [r0, #0xc]
0x0002b6:	ldr     	r4, [pc, #0x70]
0x0002b8:	str     	r1, [r5, #0x30]
0x0002ba:	ldr     	r1, [r0, #0x10]
0x0002bc:	str     	r1, [r5, #0x34]
0x0002be:	ldr     	r1, [r0, #0x14]
0x0002c0:	str     	r1, [r5, #0x38]
0x0002c2:	ldr     	r1, [r0, #0x18]
0x0002c4:	str     	r1, [r5, #0x3c]
0x0002c6:	ldr     	r1, [r0, #0x1c]
0x0002c8:	str     	r1, [r5, #0x40]
0x0002ca:	ldr     	r1, [r0, #0x20]
0x0002cc:	str     	r1, [r5, #0x44]
0x0002ce:	ldr     	r1, [r0, #0x24]
0x0002d0:	str     	r1, [r5, #0x48]
0x0002d2:	ldr     	r1, [r0, #0x28]
0x0002d4:	str     	r1, [r5, #0x4c]
0x0002d6:	ldr     	r1, [r0, #0x2c]
0x0002d8:	str     	r1, [r5, #0x50]
0x0002da:	ldr     	r1, [r0, #0x30]
0x0002dc:	str     	r1, [r5, #0x54]
0x0002de:	ldr     	r1, [r0, #0x34]
0x0002e0:	str     	r1, [r5, #0x58]
0x0002e2:	ldr     	r1, [r0, #0x38]
0x0002e4:	str     	r1, [r5, #0x5c]
0x0002e6:	ldr     	r1, [r0, #0x3c]
0x0002e8:	str     	r1, [r5, #0x60]
0x0002ea:	ldr     	r1, [r0, #0x40]
0x0002ec:	str     	r1, [r5, #0x64]
0x0002ee:	ldr     	r1, [r0, #0x44]
0x0002f0:	str     	r1, [r5, #0x68]
0x0002f2:	ldr     	r1, [r0, #0x48]
0x0002f4:	str     	r1, [r5, #0x6c]
0x0002f6:	ldr     	r1, [r0, #0x4c]
0x0002f8:	str     	r1, [r5, #0x70]
0x0002fa:	movs    	r1, #0
0x0002fc:	str     	r1, [r2]
0x0002fe:	movs    	r1, #1
0x000300:	lsls    	r1, r1, #9
0x000302:	adds    	r0, r0, r1
0x000304:	ldr     	r3, [r0, #8]
0x000306:	movs    	r1, #7
0x000308:	adds    	r2, r4, #0
0x00030a:	movs    	r0, #0
0x00030c:	blx     	r3
0x00030e:	cmp     	r0, r4
0x000310:	bne     	#0x316
0x000312:	subs    	r0, #2
0x000314:	str     	r0, [r5, #0x28]
0x000316:	add     	sp, #0xc
0x000318:	pop     	{r4, r5, pc}

; ===== candidate_00032c =====
0x00032c:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00032e:	sub     	sp, #0xc
0x000330:	adds    	r4, r1, #0
0x000332:	movs    	r1, #0
0x000334:	adds    	r5, r2, #0
0x000336:	movs    	r2, #0
0x000338:	str     	r2, [sp, #8]
0x00033a:	str     	r1, [sp]
0x00033c:	str     	r1, [sp, #4]
0x00033e:	movs    	r6, #0xf1
0x000340:	lsls    	r6, r6, #9
0x000342:	movs    	r1, #0xe1
0x000344:	movs    	r2, #0xc5
0x000346:	movs    	r3, #0
0x000348:	adds    	r0, r6, #0
0x00034a:	ldr     	r7, [sp, #0x30]
0x00034c:	bl      	#0x2d90
0x000350:	cmp     	r0, #0
0x000352:	bne     	#0x36a
0x000354:	movs    	r1, #0
0x000356:	movs    	r2, #0
0x000358:	str     	r2, [sp, #8]
0x00035a:	str     	r1, [sp]
0x00035c:	str     	r1, [sp, #4]
0x00035e:	movs    	r1, #0x14
0x000360:	movs    	r2, #0xc5
0x000362:	movs    	r3, #1
0x000364:	adds    	r0, r6, #0
0x000366:	bl      	#0x2d90
0x00036a:	ldr     	r0, [sp, #0xc]
0x00036c:	cmp     	r0, #0xe
0x00036e:	blo     	#0x372
0x000370:	b       	#0x46c
0x000372:	adr     	r3, #8
0x000374:	ldrb    	r3, [r3, r0]
0x000376:	lsls    	r3, r3, #1
0x000378:	add     	pc, r3
0x00037a:	movs    	r0, r0
0x00037c:	ldr     	r2, [r4, #0x54]
0x00037e:	strb    	r1, [r3, r1]
0x000380:	ldr     	r4, [pc, #0x140]
0x000382:	rsbs    	r7, r0, #0
0x000384:	cmp     	r1, #0x30
0x000386:	asrs    	r4, r4, #4
0x000388:	lsls    	r5, r1, #0x1c
0x00038a:	adds    	r1, r5, #0
0x00038c:	adds    	r0, r4, #0
0x00038e:	bl      	#0x484
0x000392:	add     	sp, #0x1c
0x000394:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000484 =====
0x000484:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x000486:	sub     	sp, #0x14
0x000488:	movs    	r1, #0
0x00048a:	str     	r1, [sp]
0x00048c:	str     	r1, [sp, #4]
0x00048e:	movs    	r6, #0xf1
0x000490:	movs    	r7, #0
0x000492:	movs    	r2, #0
0x000494:	adds    	r3, r7, #0
0x000496:	lsls    	r6, r6, #9
0x000498:	movs    	r1, #0xd2
0x00049a:	adds    	r4, r0, #0
0x00049c:	adds    	r0, r6, #0
0x00049e:	str     	r2, [sp, #8]
0x0004a0:	bl      	#0x2d90
0x0004a4:	movs    	r1, #0
0x0004a6:	movs    	r2, #0
0x0004a8:	str     	r2, [sp, #8]
0x0004aa:	str     	r1, [sp]
0x0004ac:	str     	r1, [sp, #4]
0x0004ae:	movs    	r1, #0x82
0x0004b0:	adds    	r2, r0, #0
0x0004b2:	movs    	r3, #1
0x0004b4:	adds    	r0, r6, #0
0x0004b6:	bl      	#0x2d90
0x0004ba:	movs    	r1, #0
0x0004bc:	lsls    	r0, r0, #0x18
0x0004be:	movs    	r2, #0
0x0004c0:	str     	r2, [sp, #8]
0x0004c2:	asrs    	r0, r0, #0x18
0x0004c4:	str     	r1, [sp]
0x0004c6:	str     	r1, [sp, #4]
0x0004c8:	movs    	r1, #0xe1
0x0004ca:	str     	r0, [sp, #0x10]
0x0004cc:	movs    	r2, #0x90
0x0004ce:	adds    	r3, r7, #0
0x0004d0:	adds    	r0, r6, #0
0x0004d2:	bl      	#0x2d90
0x0004d6:	cmp     	r0, #0
0x0004d8:	beq     	#0x598
0x0004da:	movs    	r1, #0
0x0004dc:	movs    	r2, #0
0x0004de:	str     	r2, [sp, #8]
0x0004e0:	str     	r1, [sp]
0x0004e2:	str     	r1, [sp, #4]
0x0004e4:	movs    	r1, #0xe1
0x0004e6:	movs    	r2, #0x90
0x0004e8:	adds    	r3, r7, #0
0x0004ea:	adds    	r0, r6, #0
0x0004ec:	bl      	#0x2d90
0x0004f0:	adds    	r5, r0, #0
0x0004f2:	bl      	#0x2e30
0x0004f6:	ldr     	r1, [pc, #0x100]
0x0004f8:	subs    	r0, r0, r5
0x0004fa:	cmp     	r0, r1
0x0004fc:	bge     	#0x598
0x0004fe:	subs    	r0, r1, r0
0x000500:	blx     	#0x240
0x000504:	adds    	r5, r1, #0
0x000506:	bne     	#0x50a
0x000508:	movs    	r5, #1
0x00050a:	movs    	r1, #0
0x00050c:	movs    	r2, #0
0x00050e:	str     	r2, [sp, #8]
0x000510:	str     	r1, [sp]
0x000512:	str     	r1, [sp, #4]
0x000514:	movs    	r1, #0x3f
0x000516:	adds    	r2, r5, #0
0x000518:	movs    	r3, #0
0x00051a:	adds    	r0, r6, #0
0x00051c:	bl      	#0x2d90
0x000520:	movs    	r2, #0
0x000522:	movs    	r1, #0
0x000524:	str     	r2, [sp, #8]
0x000526:	ldr     	r2, [pc, #0xd4]
0x000528:	adds    	r5, r0, #0
0x00052a:	adds    	r3, r0, #0
0x00052c:	str     	r1, [sp]
0x00052e:	str     	r1, [sp, #4]
0x000530:	add     	r2, pc
0x000532:	movs    	r1, #0x2d
0x000534:	movs    	r0, #0xf1
0x000536:	lsls    	r0, r0, #9
0x000538:	bl      	#0x2d90
0x00053c:	movs    	r2, #0
0x00053e:	str     	r0, [r4]
0x000540:	movs    	r1, #0
0x000542:	ldr     	r3, [pc, #0xbc]
0x000544:	str     	r1, [sp]
0x000546:	str     	r1, [sp, #4]
0x000548:	str     	r2, [sp, #8]
0x00054a:	add     	r3, pc
0x00054c:	adds    	r2, r0, #0
0x00054e:	movs    	r0, #0xf1
0x000550:	movs    	r1, #0x2d
0x000552:	lsls    	r0, r0, #9
0x000554:	bl      	#0x2d90
0x000558:	str     	r0, [r4]
0x00055a:	movs    	r1, #0
0x00055c:	movs    	r2, #0
0x00055e:	str     	r2, [sp, #8]
0x000560:	str     	r1, [sp]
0x000562:	str     	r1, [sp, #4]
0x000564:	movs    	r1, #9
0x000566:	adds    	r2, r5, #0
0x000568:	movs    	r0, #0xf1
0x00056a:	movs    	r3, #0
0x00056c:	lsls    	r0, r0, #9
0x00056e:	bl      	#0x2d90
0x000572:	ldr     	r0, [sp, #0x10]
0x000574:	cmp     	r0, #1
0x000576:	bne     	#0x59e
0x000578:	movs    	r3, #1
0x00057a:	ldr     	r0, [sp, #0x18]
0x00057c:	movs    	r2, #0
0x00057e:	strb    	r3, [r0]
0x000580:	movs    	r1, #0
0x000582:	ldr     	r3, [pc, #0x80]
0x000584:	str     	r1, [sp]
0x000586:	str     	r1, [sp, #4]
0x000588:	str     	r2, [sp, #8]
0x00058a:	add     	r3, pc
0x00058c:	movs    	r1, #0x2d
0x00058e:	adds    	r0, r6, #0
0x000590:	ldr     	r2, [r4]
0x000592:	bl      	#0x2d90
0x000596:	str     	r0, [r4]
0x000598:	movs    	r0, #1
0x00059a:	add     	sp, #0x1c
0x00059c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000608 =====
0x000608:	push    	{r4, r5, r6, r7, lr}
0x00060a:	movs    	r7, #0xf1
0x00060c:	lsls    	r7, r7, #9
0x00060e:	movs    	r6, #0
0x000610:	cmp     	r0, #0
0x000612:	sub     	sp, #0x14
0x000614:	bne     	#0x65c
0x000616:	movs    	r1, #0
0x000618:	str     	r1, [sp]
0x00061a:	str     	r1, [sp, #4]
0x00061c:	movs    	r2, #0
0x00061e:	movs    	r1, #0x53
0x000620:	movs    	r3, #0x32
0x000622:	adds    	r0, r7, #0
0x000624:	str     	r2, [sp, #8]
0x000626:	bl      	#0x2d90
0x00062a:	movs    	r1, #0
0x00062c:	movs    	r2, #0
0x00062e:	str     	r2, [sp, #8]
0x000630:	str     	r1, [sp]
0x000632:	str     	r1, [sp, #4]
0x000634:	movs    	r1, #0xe1
0x000636:	movs    	r2, #0x93
0x000638:	adds    	r3, r6, #0
0x00063a:	adds    	r0, r7, #0
0x00063c:	bl      	#0x2d90
0x000640:	movs    	r1, #0
0x000642:	str     	r1, [sp]
0x000644:	str     	r1, [sp, #4]
0x000646:	movs    	r2, #0
0x000648:	str     	r2, [sp, #8]
0x00064a:	movs    	r1, #0xff
0x00064c:	adds    	r1, #0x1f
0x00064e:	adds    	r2, r0, #0
0x000650:	adds    	r3, r6, #0
0x000652:	adds    	r0, r7, #0
0x000654:	bl      	#0x2d90
0x000658:	add     	sp, #0x14
0x00065a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000820 =====
0x000820:	push    	{r4, r5, r6, r7, lr}
0x000822:	sub     	sp, #0x5c
0x000824:	movs    	r0, #0
0x000826:	movs    	r1, #0
0x000828:	str     	r1, [sp, #4]
0x00082a:	movs    	r4, #0xf1
0x00082c:	movs    	r5, #0
0x00082e:	movs    	r2, #0
0x000830:	adds    	r3, r5, #0
0x000832:	lsls    	r4, r4, #9
0x000834:	movs    	r1, #0x1c
0x000836:	str     	r0, [sp, #0x50]
0x000838:	str     	r0, [sp, #0x4c]
0x00083a:	str     	r0, [sp]
0x00083c:	adds    	r0, r4, #0
0x00083e:	str     	r2, [sp, #8]
0x000840:	bl      	#0x2d90
0x000844:	movs    	r1, #0
0x000846:	str     	r1, [sp]
0x000848:	str     	r1, [sp, #4]
0x00084a:	movs    	r1, #0xff
0x00084c:	movs    	r2, #0
0x00084e:	adds    	r1, #0x26
0x000850:	str     	r0, [sp, #0x38]
0x000852:	adds    	r3, r5, #0
0x000854:	adds    	r0, r4, #0
0x000856:	str     	r2, [sp, #8]
0x000858:	bl      	#0x2d90
0x00085c:	movs    	r1, #0
0x00085e:	movs    	r2, #0
0x000860:	str     	r2, [sp, #8]
0x000862:	str     	r1, [sp]
0x000864:	str     	r1, [sp, #4]
0x000866:	movs    	r1, #0xe1
0x000868:	movs    	r2, #0xed
0x00086a:	adds    	r3, r5, #0
0x00086c:	adds    	r0, r4, #0
0x00086e:	bl      	#0x2d90
0x000872:	cmp     	r0, #0
0x000874:	ble     	#0x95a
0x000876:	movs    	r1, #0
0x000878:	str     	r1, [sp]
0x00087a:	str     	r1, [sp, #4]
0x00087c:	movs    	r1, #0xff
0x00087e:	movs    	r2, #0
0x000880:	adds    	r1, #0x25
0x000882:	adds    	r3, r5, #0
0x000884:	adds    	r0, r4, #0
0x000886:	str     	r2, [sp, #8]
0x000888:	bl      	#0x2d90
0x00088c:	movs    	r1, #0
0x00088e:	str     	r1, [sp]
0x000890:	str     	r1, [sp, #4]
0x000892:	movs    	r2, #0
0x000894:	movs    	r1, #0x40
0x000896:	adds    	r3, r5, #0
0x000898:	adds    	r0, r4, #0
0x00089a:	str     	r2, [sp, #8]
0x00089c:	bl      	#0x2d90
0x0008a0:	ldr     	r0, [pc, #0x3dc]
0x0008a2:	add     	r0, sb
0x0008a4:	ldr     	r0, [r0, #0x10]
0x0008a6:	bl      	#0x1c04
0x0008aa:	movs    	r1, #0
0x0008ac:	movs    	r2, #0
0x0008ae:	str     	r2, [sp, #8]
0x0008b0:	str     	r1, [sp]
0x0008b2:	str     	r1, [sp, #4]
0x0008b4:	movs    	r1, #0xe1
0x0008b6:	movs    	r2, #0x28
0x0008b8:	adds    	r7, r0, #0
0x0008ba:	adds    	r3, r5, #0
0x0008bc:	adds    	r0, r4, #0
0x0008be:	bl      	#0x2d90
0x0008c2:	movs    	r1, #0
0x0008c4:	adds    	r4, r0, #0
0x0008c6:	movs    	r2, #0
0x0008c8:	str     	r2, [sp, #8]
0x0008ca:	str     	r1, [sp]
0x0008cc:	str     	r1, [sp, #4]
0x0008ce:	movs    	r1, #0xe1
0x0008d0:	movs    	r2, #0x29
0x0008d2:	movs    	r0, #0xf1
0x0008d4:	adds    	r3, r5, #0
0x0008d6:	lsls    	r0, r0, #9
0x0008d8:	bl      	#0x2d90
0x0008dc:	adds    	r3, r0, #0
0x0008de:	add     	r2, sp, #0x4c
0x0008e0:	add     	r1, sp, #0x50
0x0008e2:	str     	r1, [sp, #4]
0x0008e4:	str     	r2, [sp, #8]
0x0008e6:	adds    	r2, r7, #0
0x0008e8:	movs    	r1, #0x2a
0x0008ea:	movs    	r0, #0xf1
0x0008ec:	lsls    	r0, r0, #9
0x0008ee:	str     	r4, [sp]
0x0008f0:	bl      	#0x2d90
0x0008f4:	movs    	r1, #0
0x0008f6:	movs    	r2, #0
0x0008f8:	str     	r2, [sp, #8]
0x0008fa:	str     	r1, [sp]
0x0008fc:	str     	r1, [sp, #4]
0x0008fe:	movs    	r1, #0xe1
0x000900:	movs    	r2, #0x2a
0x000902:	adds    	r3, r5, #0
0x000904:	movs    	r0, #0xf1
0x000906:	lsls    	r0, r0, #9
0x000908:	bl      	#0x2d90
0x00090c:	ldr     	r1, [sp, #0x4c]
0x00090e:	movs    	r2, #0
0x000910:	adds    	r4, r0, r1
0x000912:	movs    	r1, #0
0x000914:	str     	r1, [sp]
0x000916:	str     	r1, [sp, #4]
0x000918:	movs    	r1, #0x1c
0x00091a:	movs    	r0, #0xf1
0x00091c:	adds    	r3, r5, #0
0x00091e:	lsls    	r0, r0, #9
0x000920:	str     	r2, [sp, #8]
0x000922:	bl      	#0x2d90
0x000926:	movs    	r2, #0
0x000928:	str     	r2, [sp, #8]
0x00092a:	str     	r0, [sp]
0x00092c:	adds    	r3, r5, #0
0x00092e:	adds    	r2, r5, #0
0x000930:	movs    	r0, #0xf1
0x000932:	movs    	r1, #0x32
0x000934:	lsls    	r0, r0, #9
0x000936:	str     	r4, [sp, #4]
0x000938:	bl      	#0x2d90
0x00093c:	movs    	r1, #0
0x00093e:	ldr     	r0, [pc, #0x340]
0x000940:	str     	r1, [sp]
0x000942:	str     	r1, [sp, #4]
0x000944:	movs    	r2, #0
0x000946:	str     	r2, [sp, #8]
0x000948:	add     	r0, sb
0x00094a:	ldr     	r2, [r0, #0x24]
0x00094c:	movs    	r0, #0xf1
0x00094e:	movs    	r1, #0xd3
0x000950:	adds    	r3, r5, #0

; ===== candidate_001334 =====
0x001334:	push    	{r4, r5, r6, r7, lr}
0x001336:	sub     	sp, #0x5c
0x001338:	movs    	r0, #0
0x00133a:	movs    	r1, #0
0x00133c:	str     	r1, [sp, #4]
0x00133e:	movs    	r1, #0xff
0x001340:	str     	r0, [sp, #0x40]
0x001342:	movs    	r7, #0xf1
0x001344:	movs    	r4, #0
0x001346:	movs    	r2, #0
0x001348:	adds    	r3, r4, #0
0x00134a:	lsls    	r7, r7, #9
0x00134c:	str     	r0, [sp]
0x00134e:	adds    	r1, #0x4a
0x001350:	str     	r0, [sp, #0x3c]
0x001352:	adds    	r0, r7, #0
0x001354:	str     	r2, [sp, #8]
0x001356:	bl      	#0x2d90
0x00135a:	movs    	r1, #0
0x00135c:	movs    	r2, #0
0x00135e:	str     	r2, [sp, #8]
0x001360:	str     	r1, [sp]
0x001362:	str     	r1, [sp, #4]
0x001364:	movs    	r1, #0xe1
0x001366:	movs    	r2, #0xed
0x001368:	adds    	r3, r4, #0
0x00136a:	adds    	r0, r7, #0
0x00136c:	bl      	#0x2d90
0x001370:	cmp     	r0, #0
0x001372:	ble     	#0x145a
0x001374:	movs    	r1, #0
0x001376:	str     	r1, [sp]
0x001378:	str     	r1, [sp, #4]
0x00137a:	movs    	r1, #0xff
0x00137c:	movs    	r2, #0
0x00137e:	adds    	r1, #0x25
0x001380:	adds    	r3, r4, #0
0x001382:	adds    	r0, r7, #0
0x001384:	str     	r2, [sp, #8]
0x001386:	bl      	#0x2d90
0x00138a:	movs    	r1, #0
0x00138c:	str     	r1, [sp]
0x00138e:	str     	r1, [sp, #4]
0x001390:	movs    	r2, #0
0x001392:	movs    	r1, #0x40
0x001394:	adds    	r3, r4, #0
0x001396:	adds    	r0, r7, #0
0x001398:	str     	r2, [sp, #8]
0x00139a:	bl      	#0x2d90
0x00139e:	movs    	r1, #0
0x0013a0:	movs    	r2, #0
0x0013a2:	str     	r2, [sp, #8]
0x0013a4:	str     	r1, [sp]
0x0013a6:	str     	r1, [sp, #4]
0x0013a8:	movs    	r1, #0xe1
0x0013aa:	movs    	r2, #0x84
0x0013ac:	adds    	r3, r4, #0
0x0013ae:	adds    	r0, r7, #0
0x0013b0:	bl      	#0x2d90
0x0013b4:	ldr     	r1, [pc, #0x3cc]
0x0013b6:	add     	r1, sb
0x0013b8:	ldr     	r1, [r1, #0x24]
0x0013ba:	cmp     	r0, r1
0x0013bc:	bne     	#0x13d4
0x0013be:	movs    	r1, #0
0x0013c0:	movs    	r2, #0
0x0013c2:	str     	r2, [sp, #8]
0x0013c4:	str     	r1, [sp]
0x0013c6:	str     	r1, [sp, #4]
0x0013c8:	movs    	r1, #0x14
0x0013ca:	movs    	r2, #0x84
0x0013cc:	movs    	r3, #0
0x0013ce:	adds    	r0, r7, #0
0x0013d0:	bl      	#0x2d90
0x0013d4:	ldr     	r0, [pc, #0x3ac]
0x0013d6:	add     	r0, sb
0x0013d8:	ldr     	r0, [r0, #0x24]
0x0013da:	bl      	#0x1c04
0x0013de:	movs    	r1, #0
0x0013e0:	movs    	r2, #0
0x0013e2:	str     	r2, [sp, #8]
0x0013e4:	str     	r1, [sp]
0x0013e6:	str     	r1, [sp, #4]
0x0013e8:	movs    	r4, #0
0x0013ea:	adds    	r3, r4, #0
0x0013ec:	movs    	r1, #0xe1
0x0013ee:	movs    	r2, #0x28
0x0013f0:	adds    	r5, r0, #0
0x0013f2:	adds    	r0, r7, #0
0x0013f4:	bl      	#0x2d90
0x0013f8:	movs    	r1, #0
0x0013fa:	adds    	r6, r0, #0
0x0013fc:	movs    	r2, #0
0x0013fe:	str     	r2, [sp, #8]
0x001400:	str     	r1, [sp]
0x001402:	str     	r1, [sp, #4]
0x001404:	movs    	r1, #0xe1
0x001406:	movs    	r2, #0x29
0x001408:	movs    	r0, #0xf1
0x00140a:	adds    	r3, r4, #0
0x00140c:	lsls    	r0, r0, #9
0x00140e:	bl      	#0x2d90
0x001412:	adds    	r3, r0, #0
0x001414:	add     	r2, sp, #0x3c
0x001416:	add     	r1, sp, #0x40
0x001418:	str     	r1, [sp, #4]
0x00141a:	str     	r2, [sp, #8]
0x00141c:	adds    	r2, r5, #0
0x00141e:	movs    	r1, #0x2a
0x001420:	movs    	r0, #0xf1
0x001422:	lsls    	r0, r0, #9
0x001424:	str     	r6, [sp]
0x001426:	bl      	#0x2d90
0x00142a:	movs    	r1, #0
0x00142c:	movs    	r2, #0
0x00142e:	str     	r2, [sp, #8]
0x001430:	str     	r1, [sp]
0x001432:	str     	r1, [sp, #4]
0x001434:	movs    	r1, #0xe1
0x001436:	movs    	r2, #0x2a
0x001438:	adds    	r3, r4, #0
0x00143a:	movs    	r0, #0xf1
0x00143c:	lsls    	r0, r0, #9
0x00143e:	bl      	#0x2d90
0x001442:	ldr     	r1, [sp, #0x3c]
0x001444:	movs    	r2, #0
0x001446:	adds    	r6, r0, r1
0x001448:	movs    	r1, #0
0x00144a:	str     	r1, [sp]
0x00144c:	str     	r1, [sp, #4]
0x00144e:	movs    	r1, #0x1c
0x001450:	movs    	r0, #0xf1
0x001452:	adds    	r3, r4, #0
0x001454:	lsls    	r0, r0, #9
0x001456:	str     	r2, [sp, #8]
0x001458:	b       	#0x145c
0x00145a:	b       	#0x19da
0x00145c:	bl      	#0x2d90
0x001460:	movs    	r2, #0
0x001462:	str     	r2, [sp, #8]
0x001464:	str     	r0, [sp]

; ===== candidate_0019f0 =====
0x0019f0:	push    	{r4, r5, r6, lr}
0x0019f2:	sub     	sp, #0x30
0x0019f4:	movs    	r1, #0
0x0019f6:	movs    	r2, #0
0x0019f8:	str     	r2, [sp, #8]
0x0019fa:	str     	r1, [sp]
0x0019fc:	str     	r1, [sp, #4]
0x0019fe:	adds    	r5, r0, #0
0x001a00:	movs    	r0, #0xf1
0x001a02:	movs    	r1, #0xe1
0x001a04:	movs    	r2, #0x18
0x001a06:	movs    	r4, #0
0x001a08:	movs    	r3, #0
0x001a0a:	lsls    	r0, r0, #9
0x001a0c:	bl      	#0x2d90
0x001a10:	movs    	r2, #0
0x001a12:	ldr     	r6, [r0, #0x10]
0x001a14:	movs    	r1, #0
0x001a16:	ldr     	r3, [pc, #0x1e4]
0x001a18:	str     	r1, [sp]
0x001a1a:	str     	r1, [sp, #4]
0x001a1c:	str     	r2, [sp, #8]
0x001a1e:	add     	r3, pc
0x001a20:	adds    	r2, r6, #0
0x001a22:	movs    	r1, #0x35
0x001a24:	movs    	r0, #0xf1
0x001a26:	lsls    	r0, r0, #9
0x001a28:	bl      	#0x2d90
0x001a2c:	ldr     	r1, [pc, #0x1d0]
0x001a2e:	add     	r1, sb
0x001a30:	ldr     	r1, [r1, #0x24]
0x001a32:	cmp     	r1, #7
0x001a34:	blo     	#0x1a38
0x001a36:	b       	#0x1b4e
0x001a38:	adr     	r3, #4
0x001a3a:	ldrb    	r3, [r3, r1]
0x001a3c:	lsls    	r3, r3, #1
0x001a3e:	add     	pc, r3
0x001a40:	lsls    	r6, r0, #0xe
0x001a42:	lsls    	r3, r0, #0xc
0x001a44:	lsls    	r0, r7, #0xc
0x001a46:	movs    	r3, r0
0x001a48:	ldr     	r1, [pc, #0x1b4]
0x001a4a:	movs    	r2, #0
0x001a4c:	add     	r1, sb
0x001a4e:	ldr     	r1, [r1, #0x10]
0x001a50:	str     	r0, [sp, #0x14]
0x001a52:	str     	r1, [sp, #0x10]
0x001a54:	movs    	r1, #0
0x001a56:	str     	r1, [sp]
0x001a58:	str     	r1, [sp, #4]
0x001a5a:	str     	r2, [sp, #8]
0x001a5c:	movs    	r4, #0
0x001a5e:	adds    	r3, r4, #0
0x001a60:	movs    	r2, #0x18
0x001a62:	movs    	r1, #0xe1
0x001a64:	movs    	r0, #0xf1
0x001a66:	lsls    	r0, r0, #9
0x001a68:	bl      	#0x2d90
0x001a6c:	ldr     	r0, [r0, #8]
0x001a6e:	movs    	r1, #0
0x001a70:	movs    	r2, #0
0x001a72:	str     	r2, [sp, #8]
0x001a74:	str     	r1, [sp]
0x001a76:	str     	r1, [sp, #4]
0x001a78:	str     	r0, [sp, #0x18]
0x001a7a:	movs    	r0, #0xf1
0x001a7c:	movs    	r1, #0xe1
0x001a7e:	movs    	r2, #0x18
0x001a80:	adds    	r3, r4, #0
0x001a82:	lsls    	r0, r0, #9
0x001a84:	bl      	#0x2d90
0x001a88:	ldr     	r0, [r0, #0xc]
0x001a8a:	movs    	r1, #0
0x001a8c:	str     	r5, [sp, #0x20]
0x001a8e:	str     	r4, [sp, #0x24]
0x001a90:	movs    	r2, #0
0x001a92:	str     	r1, [sp, #4]
0x001a94:	str     	r1, [sp]
0x001a96:	str     	r4, [sp, #0x28]
0x001a98:	str     	r0, [sp, #0x1c]
0x001a9a:	movs    	r0, #0xf1
0x001a9c:	str     	r2, [sp, #8]
0x001a9e:	movs    	r1, #0xd7
0x001aa0:	adds    	r3, r4, #0
0x001aa2:	lsls    	r0, r0, #9
0x001aa4:	add     	r2, sp, #0x10
0x001aa6:	str     	r4, [sp, #0x2c]
0x001aa8:	bl      	#0x2d90
0x001aac:	adds    	r4, r0, #0
0x001aae:	str     	r5, [r0, #0x10]
0x001ab0:	b       	#0x1b4e
0x001ab2:	ldr     	r1, [pc, #0x14c]
0x001ab4:	movs    	r2, #0
0x001ab6:	add     	r1, sb
0x001ab8:	ldr     	r1, [r1, #0x10]
0x001aba:	str     	r0, [sp, #0x14]
0x001abc:	str     	r1, [sp, #0x10]
0x001abe:	movs    	r1, #0
0x001ac0:	str     	r1, [sp]
0x001ac2:	str     	r1, [sp, #4]
0x001ac4:	str     	r2, [sp, #8]
0x001ac6:	movs    	r6, #0
0x001ac8:	adds    	r3, r6, #0
0x001aca:	movs    	r2, #0x18
0x001acc:	movs    	r1, #0xe1
0x001ace:	movs    	r0, #0xf1
0x001ad0:	lsls    	r0, r0, #9
0x001ad2:	bl      	#0x2d90
0x001ad6:	ldr     	r0, [r0, #8]
0x001ad8:	movs    	r1, #0
0x001ada:	movs    	r2, #0
0x001adc:	str     	r2, [sp, #8]
0x001ade:	str     	r1, [sp]
0x001ae0:	str     	r1, [sp, #4]
0x001ae2:	str     	r0, [sp, #0x18]
0x001ae4:	movs    	r0, #0xf1
0x001ae6:	movs    	r1, #0xe1
0x001ae8:	movs    	r2, #0x18
0x001aea:	adds    	r3, r6, #0
0x001aec:	lsls    	r0, r0, #9
0x001aee:	bl      	#0x2d90
0x001af2:	ldr     	r0, [r0, #0xc]
0x001af4:	movs    	r1, #0
0x001af6:	str     	r5, [sp, #0x20]
0x001af8:	str     	r6, [sp, #0x24]
0x001afa:	movs    	r2, #0
0x001afc:	str     	r1, [sp, #4]
0x001afe:	str     	r1, [sp]
0x001b00:	str     	r6, [sp, #0x28]
0x001b02:	str     	r0, [sp, #0x1c]
0x001b04:	movs    	r0, #0xf1
0x001b06:	str     	r2, [sp, #8]
0x001b08:	movs    	r1, #0xd7
0x001b0a:	adds    	r3, r6, #0
0x001b0c:	lsls    	r0, r0, #9
0x001b0e:	add     	r2, sp, #0x10
0x001b10:	str     	r6, [sp, #0x2c]
0x001b12:	bl      	#0x2d90
0x001b16:	str     	r5, [r0, #0x10]
0x001b18:	movs    	r1, #0

; ===== candidate_001d04 =====
0x001d04:	push    	{r3, lr}
0x001d06:	movs    	r1, #0
0x001d08:	str     	r1, [sp]
0x001d0a:	mov     	r1, sp
0x001d0c:	bl      	#0x1c58
0x001d10:	ldr     	r1, [sp]
0x001d12:	cmp     	r1, #1
0x001d14:	beq     	#0x1d22
0x001d16:	cmp     	r1, #2
0x001d18:	beq     	#0x1d28
0x001d1a:	cmp     	r1, #4
0x001d1c:	ldr     	r0, [r0]
0x001d1e:	bne     	#0x1d2e
0x001d20:	pop     	{r3, pc}

; ===== candidate_001d30 =====
0x001d30:	push    	{r4, r5, r6, r7, lr}
0x001d32:	sub     	sp, #0xc
0x001d34:	adds    	r6, r1, #0
0x001d36:	movs    	r1, #0
0x001d38:	movs    	r2, #0
0x001d3a:	str     	r2, [sp, #8]
0x001d3c:	adds    	r7, r0, #0
0x001d3e:	adds    	r2, r0, #0
0x001d40:	str     	r1, [sp]
0x001d42:	str     	r1, [sp, #4]
0x001d44:	movs    	r1, #0x26
0x001d46:	movs    	r0, #0xf1
0x001d48:	movs    	r3, #0
0x001d4a:	lsls    	r0, r0, #9
0x001d4c:	bl      	#0x2d90
0x001d50:	movs    	r5, #0
0x001d52:	subs    	r4, r0, #1
0x001d54:	cmp     	r4, r6
0x001d56:	ble     	#0x1d84
0x001d58:	movs    	r1, #0
0x001d5a:	movs    	r2, #0
0x001d5c:	str     	r2, [sp, #8]
0x001d5e:	str     	r1, [sp]
0x001d60:	str     	r1, [sp, #4]
0x001d62:	adds    	r3, r4, #0
0x001d64:	adds    	r2, r7, #0
0x001d66:	movs    	r1, #0x27
0x001d68:	movs    	r0, #0xf1
0x001d6a:	lsls    	r0, r0, #9
0x001d6c:	bl      	#0x2d90
0x001d70:	ldr     	r0, [r0, #0x24]
0x001d72:	movs    	r1, #0
0x001d74:	cmp     	r0, #0
0x001d76:	ble     	#0x1d7a
0x001d78:	adds    	r1, r0, #0
0x001d7a:	adds    	r5, r5, r1
0x001d7c:	adds    	r5, #1
0x001d7e:	subs    	r4, #1
0x001d80:	cmp     	r4, r6
0x001d82:	bgt     	#0x1d58
0x001d84:	adds    	r0, r5, #0
0x001d86:	add     	sp, #0xc
0x001d88:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_001d8c =====
0x001d8c:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x001d8e:	sub     	sp, #0xc
0x001d90:	adds    	r5, r1, #0
0x001d92:	movs    	r1, #0
0x001d94:	str     	r1, [sp]
0x001d96:	str     	r1, [sp, #4]
0x001d98:	movs    	r6, #0xf1
0x001d9a:	movs    	r4, #0
0x001d9c:	movs    	r2, #0
0x001d9e:	adds    	r3, r4, #0
0x001da0:	lsls    	r6, r6, #9
0x001da2:	movs    	r1, #0x34
0x001da4:	adds    	r7, r0, #0
0x001da6:	adds    	r0, r6, #0
0x001da8:	str     	r2, [sp, #8]
0x001daa:	bl      	#0x2d90
0x001dae:	movs    	r1, #0
0x001db0:	movs    	r2, #0
0x001db2:	str     	r2, [sp, #8]
0x001db4:	str     	r1, [sp]
0x001db6:	str     	r1, [sp, #4]
0x001db8:	movs    	r3, #0xff
0x001dba:	adds    	r3, #2
0x001dbc:	movs    	r1, #0x14
0x001dbe:	movs    	r2, #0x17
0x001dc0:	adds    	r0, r6, #0
0x001dc2:	bl      	#0x2d90
0x001dc6:	adds    	r0, r7, #0
0x001dc8:	ldr     	r7, [pc, #0xfc]
0x001dca:	movs    	r1, #0
0x001dcc:	add     	r7, sb
0x001dce:	strb    	r0, [r7, #2]
0x001dd0:	str     	r5, [r7, #0x10]
0x001dd2:	strb    	r4, [r7]
0x001dd4:	str     	r5, [r7, #0x24]
0x001dd6:	strh    	r4, [r7, #4]
0x001dd8:	movs    	r2, #0
0x001dda:	str     	r2, [sp, #8]
0x001ddc:	str     	r1, [sp]
0x001dde:	str     	r1, [sp, #4]
0x001de0:	movs    	r1, #0xe1
0x001de2:	movs    	r2, #0x85
0x001de4:	adds    	r3, r4, #0
0x001de6:	adds    	r0, r6, #0
0x001de8:	bl      	#0x2d90
0x001dec:	movs    	r2, #0
0x001dee:	mvns    	r1, r2
0x001df0:	ldr     	r3, [pc, #0xd8]
0x001df2:	str     	r1, [sp]
0x001df4:	str     	r1, [sp, #4]
0x001df6:	str     	r2, [sp, #8]
0x001df8:	add     	r3, pc
0x001dfa:	adds    	r2, r0, #0
0x001dfc:	movs    	r1, #5
0x001dfe:	adds    	r0, r6, #0
0x001e00:	bl      	#0x2d90
0x001e04:	movs    	r1, #0
0x001e06:	movs    	r2, #0
0x001e08:	str     	r2, [sp, #8]
0x001e0a:	str     	r1, [sp]
0x001e0c:	str     	r1, [sp, #4]
0x001e0e:	movs    	r1, #0x14
0x001e10:	movs    	r2, #0x85
0x001e12:	adds    	r3, r0, #0
0x001e14:	adds    	r0, r6, #0
0x001e16:	bl      	#0x2d90
0x001e1a:	movs    	r1, #0
0x001e1c:	movs    	r2, #0
0x001e1e:	str     	r2, [sp, #8]
0x001e20:	str     	r1, [sp]
0x001e22:	str     	r1, [sp, #4]
0x001e24:	movs    	r1, #0xe1
0x001e26:	movs    	r2, #0x93
0x001e28:	adds    	r3, r4, #0
0x001e2a:	adds    	r0, r6, #0
0x001e2c:	bl      	#0x2d90
0x001e30:	cmp     	r0, #0
0x001e32:	beq     	#0x1e76
0x001e34:	movs    	r1, #0
0x001e36:	movs    	r2, #0
0x001e38:	str     	r2, [sp, #8]
0x001e3a:	str     	r1, [sp]
0x001e3c:	str     	r1, [sp, #4]
0x001e3e:	movs    	r1, #0xe1
0x001e40:	movs    	r2, #0x93
0x001e42:	adds    	r3, r4, #0
0x001e44:	adds    	r0, r6, #0
0x001e46:	bl      	#0x2d90
0x001e4a:	movs    	r1, #0
0x001e4c:	movs    	r2, #0
0x001e4e:	str     	r2, [sp, #8]
0x001e50:	str     	r1, [sp]
0x001e52:	str     	r1, [sp, #4]
0x001e54:	movs    	r1, #9
0x001e56:	adds    	r2, r0, #0
0x001e58:	adds    	r3, r4, #0
0x001e5a:	adds    	r0, r6, #0
0x001e5c:	bl      	#0x2d90
0x001e60:	movs    	r1, #0
0x001e62:	movs    	r2, #0
0x001e64:	str     	r2, [sp, #8]
0x001e66:	str     	r1, [sp]
0x001e68:	str     	r1, [sp, #4]
0x001e6a:	movs    	r1, #0x14
0x001e6c:	movs    	r2, #0x93
0x001e6e:	adds    	r3, r4, #0
0x001e70:	adds    	r0, r6, #0
0x001e72:	bl      	#0x2d90
0x001e76:	movs    	r4, #0
0x001e78:	str     	r4, [r7, #0x1c]
0x001e7a:	str     	r4, [r7, #0x20]
0x001e7c:	movs    	r1, #0
0x001e7e:	movs    	r2, #0
0x001e80:	str     	r2, [sp, #8]
0x001e82:	str     	r1, [sp]
0x001e84:	str     	r1, [sp, #4]
0x001e86:	movs    	r1, #0x14
0x001e88:	movs    	r2, #0x87
0x001e8a:	adds    	r0, r6, #0
0x001e8c:	ldr     	r3, [sp, #0x14]
0x001e8e:	bl      	#0x2d90
0x001e92:	movs    	r1, #0
0x001e94:	movs    	r2, #0
0x001e96:	str     	r2, [sp, #8]
0x001e98:	str     	r1, [sp]
0x001e9a:	str     	r1, [sp, #4]
0x001e9c:	movs    	r1, #0x14
0x001e9e:	movs    	r2, #0x88
0x001ea0:	movs    	r0, #0xf1
0x001ea2:	lsls    	r0, r0, #9
0x001ea4:	ldr     	r3, [sp, #0x18]
0x001ea6:	bl      	#0x2d90
0x001eaa:	movs    	r1, #0
0x001eac:	str     	r1, [sp]
0x001eae:	str     	r1, [sp, #4]
0x001eb0:	movs    	r1, #0xff
0x001eb2:	movs    	r2, #0
0x001eb4:	adds    	r3, r4, #0
0x001eb6:	adds    	r1, #0x4e
0x001eb8:	movs    	r0, #0xf1
0x001eba:	lsls    	r0, r0, #9

; ===== candidate_001ed0 =====
0x001ed0:	push    	{r4, r5, r6, r7, lr}
0x001ed2:	adds    	r4, r0, #0
0x001ed4:	cmp     	r0, #0
0x001ed6:	sub     	sp, #0xc
0x001ed8:	bgt     	#0x1edc
0x001eda:	movs    	r4, #1
0x001edc:	movs    	r1, #0
0x001ede:	str     	r1, [sp]
0x001ee0:	str     	r1, [sp, #4]
0x001ee2:	movs    	r2, #0
0x001ee4:	movs    	r5, #0
0x001ee6:	movs    	r6, #0xf1
0x001ee8:	lsls    	r6, r6, #9
0x001eea:	adds    	r3, r5, #0
0x001eec:	movs    	r1, #0x6c
0x001eee:	adds    	r0, r6, #0
0x001ef0:	str     	r2, [sp, #8]
0x001ef2:	bl      	#0x2d90
0x001ef6:	movs    	r1, #0
0x001ef8:	str     	r1, [sp]
0x001efa:	str     	r1, [sp, #4]
0x001efc:	movs    	r2, #0
0x001efe:	movs    	r1, #0x7e
0x001f00:	adds    	r3, r5, #0
0x001f02:	adds    	r0, r6, #0
0x001f04:	str     	r2, [sp, #8]
0x001f06:	bl      	#0x2d90
0x001f0a:	movs    	r1, #0
0x001f0c:	str     	r1, [sp]
0x001f0e:	str     	r1, [sp, #4]
0x001f10:	movs    	r2, #0
0x001f12:	movs    	r1, #0x68
0x001f14:	adds    	r3, r5, #0
0x001f16:	adds    	r0, r6, #0
0x001f18:	str     	r2, [sp, #8]
0x001f1a:	bl      	#0x2d90
0x001f1e:	movs    	r1, #0
0x001f20:	str     	r1, [sp]
0x001f22:	str     	r1, [sp, #4]
0x001f24:	movs    	r2, #0
0x001f26:	movs    	r1, #0x6b
0x001f28:	adds    	r3, r5, #0
0x001f2a:	adds    	r0, r6, #0
0x001f2c:	str     	r2, [sp, #8]
0x001f2e:	bl      	#0x2d90
0x001f32:	ldr     	r7, [pc, #0xfc]
0x001f34:	movs    	r0, #1
0x001f36:	add     	r7, sb
0x001f38:	strb    	r0, [r7, #1]
0x001f3a:	movs    	r1, #0
0x001f3c:	movs    	r2, #0
0x001f3e:	str     	r2, [sp, #8]
0x001f40:	str     	r1, [sp]
0x001f42:	str     	r1, [sp, #4]
0x001f44:	movs    	r1, #0xe1
0x001f46:	movs    	r2, #0x83
0x001f48:	adds    	r3, r5, #0
0x001f4a:	adds    	r0, r6, #0
0x001f4c:	bl      	#0x2d90
0x001f50:	lsls    	r1, r4, #2
0x001f52:	ldr     	r3, [r0, r1]
0x001f54:	str     	r3, [r7, #8]
0x001f56:	cmp     	r3, #0
0x001f58:	bne     	#0x1f8a
0x001f5a:	movs    	r1, #0
0x001f5c:	str     	r1, [sp]
0x001f5e:	str     	r1, [sp, #4]
0x001f60:	movs    	r2, #0
0x001f62:	movs    	r1, #0x34
0x001f64:	adds    	r3, r5, #0
0x001f66:	adds    	r0, r6, #0
0x001f68:	str     	r2, [sp, #8]
0x001f6a:	bl      	#0x2d90
0x001f6e:	movs    	r2, #0
0x001f70:	movs    	r1, #0
0x001f72:	str     	r2, [sp, #8]
0x001f74:	movs    	r2, #0xff
0x001f76:	str     	r1, [sp]
0x001f78:	str     	r1, [sp, #4]
0x001f7a:	movs    	r1, #0x50
0x001f7c:	adds    	r2, #0x22
0x001f7e:	adds    	r3, r4, #0
0x001f80:	adds    	r0, r6, #0
0x001f82:	bl      	#0x2d90
0x001f86:	add     	sp, #0xc
0x001f88:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002034 =====
0x002034:	push    	{r4, r5, r6, r7, lr}
0x002036:	sub     	sp, #0x14
0x002038:	movs    	r1, #0
0x00203a:	str     	r1, [sp]
0x00203c:	str     	r1, [sp, #4]
0x00203e:	movs    	r6, #0xf1
0x002040:	movs    	r2, #0
0x002042:	lsls    	r6, r6, #9
0x002044:	movs    	r1, #0x13
0x002046:	movs    	r3, #0
0x002048:	adds    	r0, r6, #0
0x00204a:	str     	r2, [sp, #8]
0x00204c:	bl      	#0x2d90
0x002050:	movs    	r1, #0
0x002052:	str     	r1, [sp]
0x002054:	str     	r1, [sp, #4]
0x002056:	movs    	r2, #0
0x002058:	ldr     	r7, [pc, #0x3e0]
0x00205a:	str     	r2, [sp, #8]
0x00205c:	add     	r7, sb
0x00205e:	ldr     	r2, [r7, #8]
0x002060:	movs    	r1, #0x27
0x002062:	adds    	r4, r0, #0
0x002064:	adds    	r0, r6, #0
0x002066:	ldr     	r3, [r7, #0xc]
0x002068:	bl      	#0x2d90
0x00206c:	adds    	r5, r0, #0
0x00206e:	movs    	r0, #0
0x002070:	str     	r0, [r7, #0x18]
0x002072:	movs    	r1, #0
0x002074:	str     	r1, [sp, #4]
0x002076:	movs    	r2, #0
0x002078:	movs    	r1, #0x34
0x00207a:	str     	r0, [sp]
0x00207c:	movs    	r3, #0
0x00207e:	adds    	r0, r6, #0
0x002080:	str     	r2, [sp, #8]
0x002082:	bl      	#0x2d90
0x002086:	movs    	r1, #0
0x002088:	movs    	r2, #0
0x00208a:	str     	r2, [sp, #8]
0x00208c:	str     	r1, [sp]
0x00208e:	str     	r1, [sp, #4]
0x002090:	movs    	r1, #0x14
0x002092:	movs    	r2, #0x17
0x002094:	movs    	r3, #0xd8
0x002096:	adds    	r0, r6, #0
0x002098:	bl      	#0x2d90
0x00209c:	ldr     	r1, [pc, #0x3a0]
0x00209e:	add     	r1, pc
0x0020a0:	ldr     	r2, [pc, #0x3a0]
0x0020a2:	ldr     	r0, [r5, #0xc]
0x0020a4:	add     	r2, sb
0x0020a6:	ldr     	r2, [r2]
0x0020a8:	blx     	r2
0x0020aa:	ldr     	r7, [pc, #0x39c]
0x0020ac:	add     	r7, pc
0x0020ae:	cmp     	r0, #0
0x0020b0:	beq     	#0x2196
0x0020b2:	movs    	r1, #0
0x0020b4:	movs    	r2, #0
0x0020b6:	str     	r2, [sp, #8]
0x0020b8:	str     	r1, [sp]
0x0020ba:	str     	r1, [sp, #4]
0x0020bc:	movs    	r1, #0x35
0x0020be:	adds    	r2, r7, #4
0x0020c0:	adds    	r3, r7, #0
0x0020c2:	adds    	r0, r6, #0
0x0020c4:	bl      	#0x2d90
0x0020c8:	movs    	r1, #0
0x0020ca:	movs    	r2, #0
0x0020cc:	str     	r2, [sp, #8]
0x0020ce:	str     	r1, [sp]
0x0020d0:	str     	r1, [sp, #4]
0x0020d2:	movs    	r1, #0x36
0x0020d4:	adds    	r2, r4, #0
0x0020d6:	adds    	r3, r0, #0
0x0020d8:	adds    	r0, r6, #0
0x0020da:	bl      	#0x2d90
0x0020de:	movs    	r2, #0
0x0020e0:	movs    	r1, #0
0x0020e2:	str     	r2, [sp, #8]
0x0020e4:	adds    	r2, r7, #0
0x0020e6:	str     	r1, [sp]
0x0020e8:	str     	r1, [sp, #4]
0x0020ea:	movs    	r1, #0x35
0x0020ec:	subs    	r2, #0xc
0x0020ee:	adds    	r3, r7, #0
0x0020f0:	adds    	r0, r6, #0
0x0020f2:	bl      	#0x2d90
0x0020f6:	movs    	r1, #0
0x0020f8:	movs    	r2, #0
0x0020fa:	str     	r2, [sp, #8]
0x0020fc:	str     	r1, [sp]
0x0020fe:	str     	r1, [sp, #4]
0x002100:	movs    	r1, #0x36
0x002102:	adds    	r2, r4, #0
0x002104:	adds    	r3, r0, #0
0x002106:	adds    	r0, r6, #0
0x002108:	bl      	#0x2d90
0x00210c:	movs    	r1, #0
0x00210e:	movs    	r2, #0
0x002110:	str     	r2, [sp, #8]
0x002112:	str     	r1, [sp]
0x002114:	str     	r1, [sp, #4]
0x002116:	movs    	r1, #0xe1
0x002118:	movs    	r2, #0xbf
0x00211a:	movs    	r3, #0
0x00211c:	adds    	r0, r6, #0
0x00211e:	bl      	#0x2d90
0x002122:	cmp     	r0, #0
0x002124:	bne     	#0x2154
0x002126:	movs    	r2, #0
0x002128:	movs    	r1, #0
0x00212a:	str     	r2, [sp, #8]
0x00212c:	adds    	r2, r7, #0
0x00212e:	str     	r1, [sp]
0x002130:	str     	r1, [sp, #4]
0x002132:	movs    	r1, #0x35
0x002134:	adds    	r2, #0xc
0x002136:	adds    	r3, r7, #0
0x002138:	adds    	r0, r6, #0
0x00213a:	bl      	#0x2d90
0x00213e:	movs    	r1, #0
0x002140:	movs    	r2, #0
0x002142:	str     	r2, [sp, #8]
0x002144:	str     	r1, [sp]
0x002146:	str     	r1, [sp, #4]
0x002148:	movs    	r1, #0x36
0x00214a:	adds    	r2, r4, #0
0x00214c:	adds    	r3, r0, #0
0x00214e:	adds    	r0, r6, #0
0x002150:	bl      	#0x2d90
0x002154:	movs    	r2, #0
0x002156:	movs    	r1, #0
0x002158:	str     	r2, [sp, #8]
0x00215a:	ldr     	r2, [pc, #0x2f0]
0x00215c:	str     	r1, [sp]
0x00215e:	str     	r1, [sp, #4]
0x002160:	adds    	r3, r7, #0
0x002162:	add     	r2, pc

; ===== candidate_0025a4 =====
0x0025a4:	push    	{r4, r5, r6, r7, lr}
0x0025a6:	sub     	sp, #0x14
0x0025a8:	adds    	r7, r0, #0
0x0025aa:	movs    	r1, #0
0x0025ac:	ldr     	r0, [pc, #0x3a8]
0x0025ae:	str     	r1, [sp]
0x0025b0:	str     	r1, [sp, #4]
0x0025b2:	movs    	r2, #0
0x0025b4:	str     	r2, [sp, #8]
0x0025b6:	add     	r0, sb
0x0025b8:	ldr     	r2, [r0, #8]
0x0025ba:	movs    	r0, #0xf1
0x0025bc:	movs    	r1, #0x26
0x0025be:	movs    	r3, #0
0x0025c0:	lsls    	r0, r0, #9
0x0025c2:	bl      	#0x2d90
0x0025c6:	adds    	r4, r0, #0
0x0025c8:	movs    	r0, #0
0x0025ca:	movs    	r5, #0
0x0025cc:	add     	r3, sp, #0
0x0025ce:	strb    	r0, [r3, #0x10]
0x0025d0:	mvns    	r5, r5
0x0025d2:	adds    	r6, r5, #0
0x0025d4:	subs    	r0, r7, #2
0x0025d6:	cmp     	r0, #0x13
0x0025d8:	bhs     	#0x25e4
0x0025da:	adr     	r3, #0xc
0x0025dc:	adds    	r3, r3, r0
0x0025de:	ldrh    	r3, [r3, r0]
0x0025e0:	lsls    	r3, r3, #1
0x0025e2:	add     	pc, r3
0x0025e4:	add     	sp, #0x14
0x0025e6:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0029d4 =====
0x0029d4:	push    	{r4, r5, r6, lr}
0x0029d6:	subs    	r0, #2
0x0029d8:	cmp     	r0, #0x13
0x0029da:	sub     	sp, #0x10
0x0029dc:	bhs     	#0x29e8
0x0029de:	adr     	r3, #0xc
0x0029e0:	adds    	r3, r3, r0
0x0029e2:	ldrh    	r3, [r3, r0]
0x0029e4:	lsls    	r3, r3, #1
0x0029e6:	add     	pc, r3
0x0029e8:	add     	sp, #0x10
0x0029ea:	pop     	{r4, r5, r6, pc}

; ===== candidate_002cb8 =====
0x002cb8:	push    	{r3, r4, r5, lr}
0x002cba:	ldr     	r4, [pc, #0x74]
0x002cbc:	add     	r4, pc
0x002cbe:	ldr     	r0, [r4, #0x38]
0x002cc0:	movs    	r1, #0x14
0x002cc2:	ldr     	r2, [r0, #0x64]
0x002cc4:	ldr     	r0, [pc, #0x6c]
0x002cc6:	add     	r0, pc
0x002cc8:	blx     	r2
0x002cca:	movs    	r5, #0
0x002ccc:	mvns    	r5, r5
0x002cce:	cmp     	r0, r5
0x002cd0:	bne     	#0x2cd6
0x002cd2:	adds    	r0, r5, #0
0x002cd4:	pop     	{r3, r4, r5, pc}

; ===== candidate_002d40 =====
0x002d40:	push    	{r4, lr}
0x002d42:	sub     	sp, #0x10
0x002d44:	lsls    	r0, r0, #0x18
0x002d46:	lsrs    	r0, r0, #0x18
0x002d48:	str     	r0, [sp]
0x002d4a:	ldr     	r0, [pc, #0x38]
0x002d4c:	lsls    	r2, r2, #0x18
0x002d4e:	lsls    	r1, r1, #0x18
0x002d50:	lsrs    	r1, r1, #0x18
0x002d52:	lsrs    	r2, r2, #0x18
0x002d54:	str     	r2, [sp, #8]
0x002d56:	str     	r1, [sp, #4]
0x002d58:	add     	r0, pc
0x002d5a:	ldr     	r0, [r0, #0x38]
0x002d5c:	adds    	r1, r0, #0
0x002d5e:	adds    	r1, #0xff
0x002d60:	adds    	r1, #0x41
0x002d62:	ldr     	r2, [r1, #0x34]
0x002d64:	ldr     	r1, [r1, #0x30]
0x002d66:	ldr     	r2, [r2]
0x002d68:	ldr     	r1, [r1]
0x002d6a:	lsls    	r3, r2, #0x10
0x002d6c:	lsls    	r2, r1, #0x10
0x002d6e:	asrs    	r2, r2, #0x10
0x002d70:	asrs    	r3, r3, #0x10
0x002d72:	adds    	r0, #0xff
0x002d74:	adds    	r0, #0xc1
0x002d76:	ldr     	r4, [r0, #0x28]
0x002d78:	movs    	r1, #0
0x002d7a:	movs    	r0, #0
0x002d7c:	blx     	r4
0x002d7e:	add     	sp, #0x10
0x002d80:	pop     	{r4, pc}

; ===== candidate_002d90 =====
0x002d90:	push    	{r4, r5, r6, r7, lr}
0x002d92:	adds    	r5, r1, #0
0x002d94:	adds    	r4, r0, #0
0x002d96:	adds    	r6, r2, #0
0x002d98:	ldr     	r2, [pc, #0x28]
0x002d9a:	sub     	sp, #0x14
0x002d9c:	mov     	ip, r3
0x002d9e:	add     	r2, pc
0x002da0:	ldr     	r0, [sp, #0x2c]
0x002da2:	ldr     	r1, [sp, #0x30]
0x002da4:	ldr     	r7, [sp, #0x28]
0x002da6:	ldr     	r3, [r2, #0x3c]
0x002da8:	movs    	r2, #2
0x002daa:	str     	r2, [sp, #0xc]
0x002dac:	str     	r1, [sp, #8]
0x002dae:	str     	r0, [sp, #4]
0x002db0:	str     	r7, [sp]
0x002db2:	ldr     	r0, [r3, #0xc]
0x002db4:	adds    	r1, r5, #0
0x002db6:	adds    	r2, r6, #0
0x002db8:	ldr     	r7, [r0, #0x28]
0x002dba:	adds    	r0, r4, #0
0x002dbc:	mov     	r3, ip
0x002dbe:	blx     	r7
0x002dc0:	add     	sp, #0x14
0x002dc2:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002dcc =====
0x002dcc:	push    	{r4, lr}
0x002dce:	movs    	r2, #0
0x002dd0:	add     	r0, pc
0x002dd2:	ldr     	r4, [r0, #0x3c]
0x002dd4:	sub     	sp, #0x10
0x002dd6:	movs    	r1, #0
0x002dd8:	str     	r1, [sp, #4]
0x002dda:	str     	r1, [sp, #8]
0x002ddc:	str     	r2, [sp, #0xc]
0x002dde:	str     	r2, [sp]
0x002de0:	ldr     	r0, [r4, #0xc]
0x002de2:	ldr     	r2, [r0, #0x24]
0x002de4:	ldr     	r4, [r0, #0x28]
0x002de6:	blx     	r4
0x002de8:	add     	sp, #0x10
0x002dea:	pop     	{r4, pc}

; ===== candidate_002df0 =====
0x002df0:	push    	{r4, lr}
0x002df2:	ldr     	r0, [pc, #0x24]
0x002df4:	sub     	sp, #0x10
0x002df6:	add     	r0, pc
0x002df8:	ldr     	r3, [r0, #0x3c]
0x002dfa:	movs    	r2, #0
0x002dfc:	movs    	r1, #0
0x002dfe:	str     	r1, [sp, #4]
0x002e00:	str     	r1, [sp, #8]
0x002e02:	str     	r2, [sp, #0xc]
0x002e04:	str     	r2, [sp]
0x002e06:	ldr     	r0, [r3, #0xc]
0x002e08:	movs    	r3, #0
0x002e0a:	ldr     	r2, [r0, #0x24]
0x002e0c:	ldr     	r4, [r0, #0x28]
0x002e0e:	movs    	r1, #1
0x002e10:	blx     	r4
0x002e12:	add     	sp, #0x10
0x002e14:	pop     	{r4, pc}

; ===== candidate_002e32 =====
0x002e32:	push    	{r3, lr}
0x002e34:	add     	r0, pc
0x002e36:	ldr     	r0, [r0, #0x38]
0x002e38:	adds    	r0, #0x80
0x002e3a:	ldr     	r0, [r0, #4]
0x002e3c:	blx     	r0
0x002e3e:	pop     	{r3, pc}

; ===== candidate_002e44 =====
0x002e44:	push    	{r4, lr}
0x002e46:	sub     	sp, #0x10
0x002e48:	movs    	r2, #0
0x002e4a:	movs    	r1, #0
0x002e4c:	str     	r2, [sp, #8]
0x002e4e:	ldr     	r2, [pc, #0x3c]
0x002e50:	str     	r1, [sp]
0x002e52:	str     	r1, [sp, #4]
0x002e54:	movs    	r3, #0
0x002e56:	add     	r2, pc
0x002e58:	ldr     	r1, [pc, #0x34]
0x002e5a:	ldr     	r0, [pc, #0x38]
0x002e5c:	bl      	#0x2d90
0x002e60:	ldr     	r3, [pc, #0x38]
0x002e62:	ldr     	r4, [pc, #0x34]
0x002e64:	add     	r3, sb
0x002e66:	ldr     	r3, [r3]
0x002e68:	movs    	r2, #0x41
0x002e6a:	movs    	r1, #0
0x002e6c:	add     	r4, sb
0x002e6e:	adds    	r0, r4, #0
0x002e70:	blx     	r3
0x002e72:	bl      	#0x2e1c
0x002e76:	ldr     	r3, [pc, #0x28]
0x002e78:	adds    	r1, r0, #0
0x002e7a:	add     	r3, sb
0x002e7c:	ldr     	r3, [r3]
0x002e7e:	movs    	r2, #0x41
0x002e80:	adds    	r0, r4, #0
0x002e82:	blx     	r3
0x002e84:	movs    	r0, #0
0x002e86:	add     	sp, #0x10
0x002e88:	pop     	{r4, pc}

; ===== candidate_002ea8 =====
0x002ea8:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x002eaa:	adds    	r7, r3, #0
0x002eac:	adds    	r6, r2, #0
0x002eae:	adds    	r5, r0, #0
0x002eb0:	ldr     	r0, [r0]
0x002eb2:	sub     	sp, #4
0x002eb4:	mov     	r1, sb
0x002eb6:	str     	r1, [sp]
0x002eb8:	movs    	r4, #0
0x002eba:	blx     	#0x218
0x002ebe:	ldr     	r0, [sp, #8]
0x002ec0:	cmp     	r0, #0xb
0x002ec2:	bhs     	#0x2f30
0x002ec4:	adr     	r3, #4
0x002ec6:	ldrb    	r3, [r3, r0]
0x002ec8:	lsls    	r3, r3, #1
0x002eca:	add     	pc, r3
0x002ecc:	lsrs    	r5, r0, #0x1c
0x002ece:	subs    	r4, r3, #4
0x002ed0:	movs    	r4, #0x21
0x002ed2:	adds    	r1, #0x27
0x002ed4:	adds    	r1, #0x2b
0x002ed6:	movs    	r7, r5
0x002ed8:	ldr     	r1, [pc, #0x60]
0x002eda:	ldr     	r0, [r5, #0xc]
0x002edc:	add     	r1, sb
0x002ede:	str     	r0, [r1, #0x14]
0x002ee0:	bl      	#0x264
0x002ee4:	bl      	#0x2e44
0x002ee8:	adds    	r4, r0, #0
0x002eea:	b       	#0x2f30
0x002eec:	ldr     	r0, [r6]
0x002eee:	cmp     	r0, #8
0x002ef0:	bne     	#0x2efa
0x002ef2:	bl      	#0x2d8c
0x002ef6:	adds    	r4, r0, #0
0x002ef8:	b       	#0x2f30
0x002efa:	ldr     	r1, [r6, #4]
0x002efc:	ldr     	r2, [r6, #8]
0x002efe:	bl      	#0x2d88
0x002f02:	adds    	r4, r0, #0
0x002f04:	b       	#0x2f30
0x002f06:	bl      	#0x3138
0x002f0a:	b       	#0x2f30
0x002f0c:	str     	r7, [r5, #0xc]
0x002f0e:	b       	#0x2f30
0x002f10:	bl      	#0x2ea4
0x002f14:	b       	#0x2f30
0x002f16:	bl      	#0x2f74
0x002f1a:	b       	#0x2f30
0x002f1c:	ldr     	r0, [pc, #0x1c]
0x002f1e:	add     	r0, sb
0x002f20:	str     	r7, [r0, #0x1c]
0x002f22:	b       	#0x2f30
0x002f24:	ldr     	r0, [pc, #0x14]
0x002f26:	add     	r0, sb
0x002f28:	str     	r6, [r0, #0x20]
0x002f2a:	b       	#0x2f30
0x002f2c:	ldr     	r4, [pc, #0x10]
0x002f2e:	add     	r4, pc
0x002f30:	ldr     	r1, [sp]
0x002f32:	add     	sp, #0x14
0x002f34:	adds    	r0, r4, #0
0x002f36:	mov     	sb, r1
0x002f38:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002f44 =====
0x002f44:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x002f46:	sub     	sp, #0xc
0x002f48:	ldr     	r0, [sp, #0x38]
0x002f4a:	ldr     	r4, [sp, #0x3c]
0x002f4c:	ldr     	r6, [sp, #0x34]
0x002f4e:	ldr     	r0, [r0]
0x002f50:	mov     	r7, sb
0x002f52:	movs    	r5, #0
0x002f54:	blx     	#0x218
0x002f58:	cmp     	r4, #0
0x002f5a:	beq     	#0x2f6a
0x002f5c:	ldr     	r1, [sp, #0x30]
0x002f5e:	str     	r6, [sp, #4]
0x002f60:	add     	r3, sp, #0xc
0x002f62:	str     	r1, [sp]
0x002f64:	ldm     	r3, {r0, r1, r2, r3}
0x002f66:	blx     	r4
0x002f68:	adds    	r5, r0, #0
0x002f6a:	mov     	sb, r7
0x002f6c:	adds    	r0, r5, #0
0x002f6e:	add     	sp, #0x1c
0x002f70:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002fd8 =====
0x002fd8:	push    	{r3, r4, r5, r6, r7, lr}
0x002fda:	adds    	r4, r0, #0
0x002fdc:	ldr     	r0, [pc, #0x10c]
0x002fde:	movs    	r5, #0
0x002fe0:	mvns    	r5, r5
0x002fe2:	mov     	ip, r2
0x002fe4:	add     	r0, pc
0x002fe6:	ldr     	r2, [r0, #0x38]
0x002fe8:	cmp     	r4, #0
0x002fea:	bne     	#0x2ffc
0x002fec:	ldr     	r0, [pc, #0x100]
0x002fee:	ldr     	r2, [r2, #0x68]
0x002ff0:	movs    	r1, #0x7d
0x002ff2:	lsls    	r1, r1, #3
0x002ff4:	add     	r0, pc
0x002ff6:	blx     	r2
0x002ff8:	adds    	r0, r5, #0
0x002ffa:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_003104 =====
0x003104:	push    	{r3, r4, r5, lr}
0x003106:	ldr     	r4, [pc, #0x28]
0x003108:	adds    	r5, r0, #0
0x00310a:	add     	r4, pc
0x00310c:	ldr     	r0, [r4, #0x38]
0x00310e:	adds    	r0, #0x80
0x003110:	ldr     	r0, [r0, #4]
0x003112:	blx     	r0
0x003114:	adds    	r0, r0, r5
0x003116:	ldr     	r1, [pc, #0x1c]
0x003118:	add     	r1, sb
0x00311a:	str     	r0, [r1, #0x10]
0x00311c:	ldr     	r0, [r4, #0x38]
0x00311e:	adds    	r0, #0x80
0x003120:	ldr     	r0, [r0]
0x003122:	blx     	r0
0x003124:	ldr     	r0, [r4, #0x38]
0x003126:	ldr     	r1, [r0, #0x7c]
0x003128:	lsls    	r0, r5, #0x10
0x00312a:	lsrs    	r0, r0, #0x10
0x00312c:	blx     	r1
0x00312e:	pop     	{r3, r4, r5, pc}

; ===== candidate_00313a =====
0x00313a:	push    	{r3, r4, r5, r6, r7, lr}
0x00313c:	add     	r0, pc
0x00313e:	ldr     	r0, [r0, #0x38]
0x003140:	adds    	r0, #0x80
0x003142:	ldr     	r0, [r0, #4]
0x003144:	blx     	r0
0x003146:	movs    	r5, #0
0x003148:	ldr     	r6, [pc, #0xc8]
0x00314a:	add     	r6, sb
0x00314c:	ldr     	r1, [r6, #0x10]
0x00314e:	str     	r5, [r6, #0x10]
0x003150:	subs    	r1, r0, r1
0x003152:	ldr     	r0, [r6, #8]
0x003154:	adds    	r3, r1, #0
0x003156:	cmp     	r0, #0
0x003158:	beq     	#0x320e
0x00315a:	ldr     	r2, [r0, #8]
0x00315c:	cmp     	r2, #0
0x00315e:	bne     	#0x31be
0x003160:	mvns    	r7, r2
0x003162:	str     	r7, [r0, #8]
0x003164:	ldr     	r2, [r0, #0x18]
0x003166:	adds    	r4, r0, #0
0x003168:	cmp     	r1, #0x32
0x00316a:	str     	r2, [r6, #8]
0x00316c:	bge     	#0x3172
0x00316e:	movs    	r1, #0x32
0x003170:	b       	#0x318e
0x003172:	movs    	r2, #0x7d
0x003174:	lsls    	r2, r2, #4
0x003176:	cmp     	r1, r2
0x003178:	ble     	#0x318e
0x00317a:	adds    	r1, r2, #0
0x00317c:	b       	#0x318e
0x00317e:	movs    	r7, #0
0x003180:	mvns    	r7, r7
0x003182:	str     	r7, [r2, #8]
0x003184:	ldr     	r2, [r0, #0x18]
0x003186:	str     	r2, [r0, #0x1c]
0x003188:	ldr     	r0, [r2, #0x18]
0x00318a:	str     	r0, [r6, #8]
0x00318c:	adds    	r0, r2, #0
0x00318e:	ldr     	r2, [r0, #0x18]
0x003190:	cmp     	r2, #0
0x003192:	beq     	#0x319a
0x003194:	ldr     	r7, [r2, #8]
0x003196:	cmp     	r7, r1
0x003198:	blt     	#0x317e
0x00319a:	str     	r5, [r0, #0x1c]
0x00319c:	ldr     	r0, [r6, #8]
0x00319e:	cmp     	r0, #0
0x0031a0:	beq     	#0x3202
0x0031a2:	cmp     	r3, #0
0x0031a4:	bge     	#0x31a8
0x0031a6:	movs    	r3, #0
0x0031a8:	ldr     	r0, [r6, #8]
0x0031aa:	ldr     	r1, [r0, #8]
0x0031ac:	cmp     	r1, #0
0x0031ae:	bge     	#0x31b4
0x0031b0:	movs    	r1, #0
0x0031b2:	str     	r5, [r0, #8]
0x0031b4:	ldr     	r2, [pc, #0x60]
0x0031b6:	cmp     	r1, r2
0x0031b8:	ble     	#0x31c2
0x0031ba:	adds    	r1, r2, #0
0x0031bc:	b       	#0x31c2
0x0031be:	movs    	r4, #0
0x0031c0:	b       	#0x31a2
0x0031c2:	ldr     	r2, [r0, #8]
0x0031c4:	subs    	r2, r2, r1
0x0031c6:	str     	r2, [r0, #8]
0x0031c8:	ldr     	r0, [r0, #0x18]
0x0031ca:	cmp     	r0, #0
0x0031cc:	bne     	#0x31c2
0x0031ce:	subs    	r0, r1, r3
0x0031d0:	cmp     	r0, #0
0x0031d2:	bgt     	#0x31d6
0x0031d4:	movs    	r0, #0xa
0x0031d6:	bl      	#0x3104
0x0031da:	b       	#0x3202
0x0031dc:	str     	r5, [r4, #8]
0x0031de:	ldr     	r0, [r4, #0x1c]
0x0031e0:	adds    	r3, r5, #0
0x0031e2:	str     	r0, [r6, #0xc]
0x0031e4:	ldr     	r0, [r4, #0x14]
0x0031e6:	cmp     	r0, #0
0x0031e8:	beq     	#0x31f6
0x0031ea:	str     	r0, [sp]
0x0031ec:	movs    	r1, #0
0x0031ee:	adds    	r0, r4, #0
0x0031f0:	ldr     	r2, [r4, #0x10]
0x0031f2:	bl      	#0x2fd8
0x0031f6:	ldr     	r1, [r4, #0xc]
0x0031f8:	cmp     	r1, #0
0x0031fa:	beq     	#0x3200
0x0031fc:	ldr     	r0, [r4, #0x10]
0x0031fe:	blx     	r1
0x003200:	ldr     	r4, [r6, #0xc]
0x003202:	cmp     	r4, #0
0x003204:	beq     	#0x320c
0x003206:	ldr     	r0, [r4, #8]
0x003208:	cmp     	r0, #0
0x00320a:	blt     	#0x31dc
0x00320c:	str     	r5, [r6, #0xc]
0x00320e:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_00321c =====
0x00321c:	push    	{r4, r5, lr}
0x00321e:	ldr     	r0, [pc, #0x70]
0x003220:	movs    	r4, #0
0x003222:	sub     	sp, #0xc
0x003224:	add     	r0, sb
0x003226:	str     	r4, [r0, #0x1c]
0x003228:	str     	r4, [r0, #0x20]
0x00322a:	movs    	r1, #0
0x00322c:	movs    	r2, #0
0x00322e:	str     	r2, [sp, #8]
0x003230:	str     	r1, [sp]
0x003232:	str     	r1, [sp, #4]
0x003234:	movs    	r5, #0xf1
0x003236:	lsls    	r5, r5, #9
0x003238:	movs    	r1, #0xe1
0x00323a:	movs    	r2, #0x93
0x00323c:	adds    	r3, r4, #0
0x00323e:	adds    	r0, r5, #0
0x003240:	bl      	#0x2d90
0x003244:	cmp     	r0, #0
0x003246:	beq     	#0x328a
0x003248:	movs    	r1, #0
0x00324a:	movs    	r2, #0
0x00324c:	str     	r2, [sp, #8]
0x00324e:	str     	r1, [sp]
0x003250:	str     	r1, [sp, #4]
0x003252:	movs    	r1, #0xe1
0x003254:	movs    	r2, #0x93
0x003256:	adds    	r3, r4, #0
0x003258:	adds    	r0, r5, #0
0x00325a:	bl      	#0x2d90
0x00325e:	movs    	r1, #0
0x003260:	movs    	r2, #0
0x003262:	str     	r2, [sp, #8]
0x003264:	str     	r1, [sp]
0x003266:	str     	r1, [sp, #4]
0x003268:	movs    	r1, #9
0x00326a:	adds    	r2, r0, #0
0x00326c:	adds    	r3, r4, #0
0x00326e:	adds    	r0, r5, #0
0x003270:	bl      	#0x2d90
0x003274:	movs    	r1, #0
0x003276:	movs    	r2, #0
0x003278:	str     	r2, [sp, #8]
0x00327a:	str     	r1, [sp]
0x00327c:	str     	r1, [sp, #4]
0x00327e:	movs    	r1, #0x14
0x003280:	movs    	r2, #0x93
0x003282:	adds    	r3, r4, #0
0x003284:	adds    	r0, r5, #0
0x003286:	bl      	#0x2d90
0x00328a:	add     	sp, #0xc
0x00328c:	pop     	{r4, r5, pc}

; ===== candidate_003294 =====
0x003294:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x003296:	sub     	sp, #0xc
0x003298:	movs    	r1, #0
0x00329a:	movs    	r2, #0
0x00329c:	str     	r2, [sp, #8]
0x00329e:	str     	r1, [sp]
0x0032a0:	str     	r1, [sp, #4]
0x0032a2:	movs    	r6, #0xf1
0x0032a4:	movs    	r7, #0xb
0x0032a6:	movs    	r5, #0
0x0032a8:	adds    	r3, r5, #0
0x0032aa:	adds    	r2, r7, #0
0x0032ac:	lsls    	r6, r6, #9
0x0032ae:	movs    	r1, #0x17
0x0032b0:	adds    	r4, r0, #0
0x0032b2:	adds    	r0, r6, #0
0x0032b4:	bl      	#0x2d90
0x0032b8:	movs    	r1, #0
0x0032ba:	movs    	r2, #0
0x0032bc:	str     	r2, [sp, #8]
0x0032be:	str     	r1, [sp]
0x0032c0:	str     	r1, [sp, #4]
0x0032c2:	movs    	r1, #0x18
0x0032c4:	adds    	r2, r7, #0
0x0032c6:	adds    	r3, r5, #0
0x0032c8:	adds    	r0, r6, #0
0x0032ca:	bl      	#0x2d90
0x0032ce:	movs    	r1, #0
0x0032d0:	movs    	r2, #0
0x0032d2:	str     	r1, [sp]
0x0032d4:	str     	r1, [sp, #4]
0x0032d6:	movs    	r1, #0x1a
0x0032d8:	str     	r2, [sp, #8]
0x0032da:	adds    	r3, r5, #0
0x0032dc:	adds    	r0, r6, #0
0x0032de:	ldr     	r2, [sp, #0x10]
0x0032e0:	bl      	#0x2d90
0x0032e4:	movs    	r1, #0
0x0032e6:	str     	r1, [sp]
0x0032e8:	str     	r1, [sp, #4]
0x0032ea:	movs    	r2, #0
0x0032ec:	str     	r2, [sp, #8]
0x0032ee:	movs    	r1, #0x18
0x0032f0:	adds    	r3, r5, #0
0x0032f2:	adds    	r0, r6, #0
0x0032f4:	ldr     	r2, [r4]
0x0032f6:	bl      	#0x2d90
0x0032fa:	movs    	r1, #0
0x0032fc:	str     	r1, [sp]
0x0032fe:	str     	r1, [sp, #4]
0x003300:	movs    	r2, #0
0x003302:	str     	r2, [sp, #8]
0x003304:	movs    	r1, #0x19
0x003306:	adds    	r3, r5, #0
0x003308:	adds    	r0, r6, #0
0x00330a:	ldr     	r2, [r4, #4]
0x00330c:	bl      	#0x2d90
0x003310:	movs    	r1, #0
0x003312:	str     	r1, [sp]
0x003314:	str     	r1, [sp, #4]
0x003316:	movs    	r2, #0
0x003318:	str     	r2, [sp, #8]
0x00331a:	movs    	r1, #0x19
0x00331c:	adds    	r3, r5, #0
0x00331e:	adds    	r0, r6, #0
0x003320:	ldr     	r2, [r4, #8]
0x003322:	bl      	#0x2d90
0x003326:	movs    	r1, #0
0x003328:	movs    	r2, #0
0x00332a:	str     	r2, [sp, #8]
0x00332c:	str     	r1, [sp]
0x00332e:	str     	r1, [sp, #4]
0x003330:	movs    	r1, #0xe1
0x003332:	movs    	r2, #0x1d
0x003334:	adds    	r3, r5, #0
0x003336:	adds    	r0, r6, #0
0x003338:	bl      	#0x2d90
0x00333c:	movs    	r1, #0
0x00333e:	movs    	r2, #0
0x003340:	str     	r2, [sp, #8]
0x003342:	str     	r1, [sp]
0x003344:	str     	r1, [sp, #4]
0x003346:	movs    	r1, #0x19
0x003348:	adds    	r2, r0, #0
0x00334a:	adds    	r3, r5, #0
0x00334c:	adds    	r0, r6, #0
0x00334e:	bl      	#0x2d90
0x003352:	movs    	r1, #0
0x003354:	str     	r1, [sp]
0x003356:	str     	r1, [sp, #4]
0x003358:	movs    	r2, #0
0x00335a:	str     	r2, [sp, #8]
0x00335c:	movs    	r1, #0x49
0x00335e:	adds    	r3, r5, #0
0x003360:	adds    	r0, r6, #0
0x003362:	ldr     	r2, [r4, #0xc]
0x003364:	bl      	#0x2d90
0x003368:	movs    	r1, #0
0x00336a:	str     	r1, [sp]
0x00336c:	str     	r1, [sp, #4]
0x00336e:	movs    	r2, #0
0x003370:	str     	r2, [sp, #8]
0x003372:	movs    	r1, #0x49
0x003374:	adds    	r3, r5, #0
0x003376:	adds    	r0, r6, #0
0x003378:	ldr     	r2, [r4, #0x10]
0x00337a:	bl      	#0x2d90
0x00337e:	adds    	r7, r4, #0
0x003380:	adds    	r7, #0xc0
0x003382:	ldr     	r0, [r7, #0x38]
0x003384:	cmp     	r0, #0
0x003386:	beq     	#0x33b6
0x003388:	movs    	r1, #0
0x00338a:	str     	r1, [sp]
0x00338c:	str     	r1, [sp, #4]
0x00338e:	movs    	r2, #0
0x003390:	movs    	r1, #0x19
0x003392:	adds    	r3, r5, #0
0x003394:	adds    	r0, r6, #0
0x003396:	str     	r2, [sp, #8]
0x003398:	bl      	#0x2d90
0x00339c:	movs    	r1, #0
0x00339e:	movs    	r2, #0
0x0033a0:	str     	r2, [sp, #8]
0x0033a2:	str     	r1, [sp]
0x0033a4:	str     	r1, [sp, #4]
0x0033a6:	ldr     	r0, [r7, #0x38]
0x0033a8:	movs    	r1, #0x19
0x0033aa:	adds    	r3, r5, #0
0x0033ac:	ldr     	r2, [r0]
0x0033ae:	adds    	r0, r6, #0
0x0033b0:	bl      	#0x2d90
0x0033b4:	b       	#0x33cc
0x0033b6:	movs    	r1, #0
0x0033b8:	movs    	r2, #0
0x0033ba:	str     	r2, [sp, #8]
0x0033bc:	mvns    	r2, r1
0x0033be:	str     	r1, [sp]
0x0033c0:	str     	r1, [sp, #4]
0x0033c2:	movs    	r1, #0x19
0x0033c4:	adds    	r3, r5, #0

; ===== candidate_0034d4 =====
0x0034d4:	push    	{r0, r1, r2, r3, r6, r7, lr}
0x0034d6:	cbz     	r5, #0x354c
0x0034d8:	smlald  	sl, r2, pc, pc
0x0034dc:	movs    	r0, r0
0x0034de:	movs    	r0, r0
0x0034e0:	blo     	#0x3450
0x0034e2:	strd    	pc, fp, [lr, #0x33c]
0x0034e6:	adr     	r2, #0x33c
0x0034e8:	movs    	r0, r0
0x0034ea:	movs    	r0, r0
0x0034ec:	add     	r2, sp, #0x304
0x0034ee:	ldm     	r3!, {r0, r1, r6, r7}
0x0034f0:	smlald  	sl, r2, pc, pc
0x0034f4:	movs    	r0, r0
0x0034f6:	movs    	r0, r0
0x0034f8:	cbnz    	r3, #0x356c
0x0034fa:	beq     	#0x34a4
0x0034fc:	bl      	#0xff0c4ea2
0x003500:	movs    	r0, r0
0x003502:	movs    	r0, r0
0x003504:	adr     	r2, #0x2dc
0x003506:	bmi     	#0x34ac
0x003508:	movs    	r0, r0
0x00350a:	movs    	r0, r0
0x00350c:	stm     	r4!, {r0, r6, r7}
0x00350e:	vstmia  	ip, {s27, s28, s29, s30, s31}
0x003512:	ble     	#0x34a6
0x003514:	movs    	r2, r7
0x003516:	movs    	r0, r0
0x003518:	ldm     	r3!, {r2, r4, r5, r7}
0x00351a:	ldm     	r6!, {r2, r4, r5, r7}
0x00351c:	adr     	r2, #0x2dc
0x00351e:	bmi     	#0x34c4
0x003520:	smlaltt 	ip, r4, pc, sl

; ===== candidate_003596 =====
0x003596:	push    	{r0, r1, r5, r6, r7, lr}
0x003598:	stm     	r1!, {r2, r6, r7}
0x00359a:	stm     	r3!, {r1, r3, r5, r7}
0x00359c:	ldrb    	r3, [r1, r7]
0x00359e:	movs    	r0, r0
0x0035a0:	stm     	r7!, {r1, r3, r6, r7}
0x0035a2:	movs    	r0, r0
0x0035a4:	subs.w  	r0, r7, #0
0x0035a8:	push    	{r0, r1, r2, r4, r5, r7, lr}
0x0035aa:	bhi     	#0x3524
0x0035ac:	movs    	r0, r0
0x0035ae:	movs    	r0, r0
0x0035b0:	adr     	r2, #0x2dc
0x0035b2:	ldm     	r5!, {r0, r1, r3, r6, r7}
0x0035b4:	smlald  	sl, r2, pc, pc
0x0035b8:	movs    	r0, r0
0x0035ba:	movs    	r0, r0
0x0035bc:	rsb     	sl, r3, pc, asr #12
0x0035c0:	uxtb    	r3, r6
0x0035c2:	stm     	r4!, {r0, r2, r6, r7}

; ===== candidate_0035a8 =====
0x0035a8:	push    	{r0, r1, r2, r4, r5, r7, lr}
0x0035aa:	bhi     	#0x3524
0x0035ac:	movs    	r0, r0
0x0035ae:	movs    	r0, r0
0x0035b0:	adr     	r2, #0x2dc
0x0035b2:	ldm     	r5!, {r0, r1, r3, r6, r7}
0x0035b4:	smlald  	sl, r2, pc, pc
0x0035b8:	movs    	r0, r0
0x0035ba:	movs    	r0, r0
0x0035bc:	rsb     	sl, r3, pc, asr #12
0x0035c0:	uxtb    	r3, r6
0x0035c2:	stm     	r4!, {r0, r2, r6, r7}

; ===== candidate_003606 =====
0x003606:	push    	{r0, r2, r4, r5, r7, lr}
0x003608:	cmp     	r7, #0xc0
0x00360a:	stm     	r4!, {r0, r2, r4, r5, r7}
0x00360c:	push    	{r0, r1, r3, r6, r7, lr}
0x00360e:	sub     	sp, #0xec
0x003610:	bls     	#0x35aa
0x003612:	ldm     	r0!, {r1, r2, r4, r5, r7}
0x003614:	add     	r3, sp, #0x330
0x003616:	ldc     	p0, c13, [pc], #0xb0
0x00361a:	bhs     	#0x35ee
0x00361c:	push    	{r1, r3, r5, r7, lr}
0x00361e:	push    	{r3, r6, r7}
0x003620:	movs    	r4, #0xfd
0x003622:	movs    	r0, r0
0x003624:	ldm     	r4, {r2, r3, r4, r5, r7}
0x003626:	ldr.w   	sl, [r0, #0x2b7]
0x00362a:	bmi     	#0x35d0
0x00362c:	add     	r3, sp, #0x2f4
0x00362e:	b       	#0x39a8
0x003630:	smlaltt 	ip, r4, pc, sl

; ===== candidate_00360c =====
0x00360c:	push    	{r0, r1, r3, r6, r7, lr}
0x00360e:	sub     	sp, #0xec
0x003610:	bls     	#0x35aa
0x003612:	ldm     	r0!, {r1, r2, r4, r5, r7}
0x003614:	add     	r3, sp, #0x330
0x003616:	ldc     	p0, c13, [pc], #0xb0
0x00361a:	bhs     	#0x35ee
0x00361c:	push    	{r1, r3, r5, r7, lr}
0x00361e:	push    	{r3, r6, r7}
0x003620:	movs    	r4, #0xfd
0x003622:	movs    	r0, r0
0x003624:	ldm     	r4, {r2, r3, r4, r5, r7}
0x003626:	ldr.w   	sl, [r0, #0x2b7]
0x00362a:	bmi     	#0x35d0
0x00362c:	add     	r3, sp, #0x2f4
0x00362e:	b       	#0x39a8
0x003630:	smlaltt 	ip, r4, pc, sl

; ===== candidate_00361c =====
0x00361c:	push    	{r1, r3, r5, r7, lr}
0x00361e:	push    	{r3, r6, r7}
0x003620:	movs    	r4, #0xfd
0x003622:	movs    	r0, r0
0x003624:	ldm     	r4, {r2, r3, r4, r5, r7}
0x003626:	ldr.w   	sl, [r0, #0x2b7]
0x00362a:	bmi     	#0x35d0
0x00362c:	add     	r3, sp, #0x2f4
0x00362e:	b       	#0x39a8
0x003630:	smlaltt 	ip, r4, pc, sl

; ===== candidate_00361e =====
0x00361e:	push    	{r3, r6, r7}
0x003620:	movs    	r4, #0xfd
0x003622:	movs    	r0, r0
0x003624:	ldm     	r4, {r2, r3, r4, r5, r7}
0x003626:	ldr.w   	sl, [r0, #0x2b7]
0x00362a:	bmi     	#0x35d0
0x00362c:	add     	r3, sp, #0x2f4
0x00362e:	b       	#0x39a8
0x003630:	smlaltt 	ip, r4, pc, sl

; ===== candidate_003668 =====
0x003668:	push    	{r0, r1, r2, r3, r6, r7, lr}
0x00366a:	cbz     	r5, #0x36e0
0x00366c:	movs    	r0, r0
0x00366e:	movs    	r0, r0
0x003670:	smlaltt 	ip, r4, fp, r5
0x003674:	push    	{r0, r1, r2, r4, r6, r7}
0x003676:	add     	r4, sp, #0x330
0x003678:	movs    	r0, r0
0x00367a:	movs    	r0, r0
0x00367c:	movs    	r0, r0
0x00367e:	movs    	r0, r0
0x003680:	stm     	r4!, {r0, r6, r7}
0x003682:	stcl    	p0, c0, [ip], {0}
0x003686:	movs    	r0, r0
0x003688:	ldm     	r2!, {r0, r1, r4, r6, r7}

; ===== candidate_003674 =====
0x003674:	push    	{r0, r1, r2, r4, r6, r7}
0x003676:	add     	r4, sp, #0x330
0x003678:	movs    	r0, r0
0x00367a:	movs    	r0, r0
0x00367c:	movs    	r0, r0
0x00367e:	movs    	r0, r0
0x003680:	stm     	r4!, {r0, r6, r7}
0x003682:	stcl    	p0, c0, [ip], {0}
0x003686:	movs    	r0, r0
0x003688:	ldm     	r2!, {r0, r1, r4, r6, r7}

; ===== candidate_0036ae =====
0x0036ae:	push    	{r0, r1, r2, r3, r4, r5, r7}
0x0036b0:	add     	r2, sp, #0x304
0x0036b2:	ldm     	r3!, {r0, r1, r6, r7}
0x0036b4:	movs    	r0, r0
0x0036b6:	movs    	r0, r0

; ===== candidate_0036ba =====
0x0036ba:	push    	{r0, r1, r2, r3, r4, r5, r7}

; ===== candidate_0036c6 =====
0x0036c6:	push    	{r0, r1, r2, r3, r4, r5, r7}

; ===== candidate_003718 =====
0x003718:	push    	{r4, r6, r7}
0x00371a:	ldm     	r2!, {r0, r1, r4, r6, r7}
0x00371c:	cdp2    	p0, #0xb, c0, c12, c0, #0
0x003720:	itt     	gt

; ===== candidate_003742 =====
0x003742:	push    	{r1, r2, r6, r7, lr}
0x003744:	stm     	r0!, {r0, r2, r4, r5, r7}
0x003746:	adr     	r2, #0x2dc
0x003748:	bmi     	#0x36ee
0x00374a:	movs    	r0, r0
0x00374c:	bl      	#0xbb78ba
0x003750:	pop     	{r0, r2, r3, r6, r7}
0x003752:	beq     	#0x3702
0x003754:	add     	r4, sp, #0x28c
0x003756:	cbnz    	r2, #0x37c6
0x003758:	bgt     	#0x36e4
0x00375a:	bge     	#0x3706
0x00375c:	ldm     	r3!, {r2, r4, r5, r7}
0x00375e:	push    	{r1, r2, r6, r7, lr}
0x003760:	stm     	r0!, {r0, r2, r4, r5, r7}
0x003762:	adr     	r2, #0x2dc
0x003764:	bmi     	#0x370a
0x003766:	movs    	r0, r0
0x003768:	ble     	#0x3714
0x00376a:	push    	{r1, r2, r3, r6, r7}
0x00376c:	blo     	#0x36e8
0x00376e:	rsb     	r3, r8, r6, ror #22
0x003772:	strd    	sl, ip, [lr, #0x28c]
0x003776:	cbnz    	r2, #0x37e6
0x003778:	bgt     	#0x3704
0x00377a:	adr     	r2, #0x2dc
0x00377c:	ldm     	r5!, {r0, r1, r3, r6, r7}
0x00377e:	blo     	#0x36ee
0x003780:	strd    	pc, fp, [lr, #0x33c]
0x003784:	adr     	r2, #0x33c
0x003786:	adr     	r1, #0x28c
0x003788:	movs    	r0, r0
0x00378a:	movs    	r0, r0
0x00378c:	movs    	r3, r4
0x00378e:	movs    	r0, r0
0x003790:	stm     	r4!, {r0, r6, r7}
0x003792:	stcl    	p5, c12, [ip], {0xd0}
0x003796:	adr     	r2, #0x33c
0x003798:	bne     	#0x3740
0x00379a:	adr     	r2, #0x2dc
0x00379c:	ldm     	r5!, {r0, r1, r3, r6, r7}
0x00379e:	movs    	r0, r0
0x0037a0:	stm     	r4!, {r0, r6, r7}
0x0037a2:	vstmia  	ip, {s27, s28, s29, s30, s31}
0x0037a6:	ble     	#0x373a
0x0037a8:	cbnz    	r2, #0x3818
0x0037aa:	bgt     	#0x3736
0x0037ac:	add     	r2, sp, #0x338
0x0037ae:	bpl     	#0x3730
0x0037b0:	movs    	r0, r0
0x0037b2:	movs    	r0, r0
0x0037b4:	strh    	r5, [r1, r1]
0x0037b6:	bx      	sl
0x0037b8:	movs    	r4, r0
0x0037ba:	movs    	r0, r0
0x0037bc:	movs    	r0, r0
0x0037be:	movs    	r0, r0
0x0037c0:	movs    	r4, r0
0x0037c2:	movs    	r0, r0
0x0037c4:	str     	r1, [r4, #0x24]
0x0037c6:	lsls    	r3, r4, #1
0x0037c8:	movs    	r0, r0
0x0037ca:	movs    	r0, r0
0x0037cc:	str     	r6, [r2, #0x14]
0x0037ce:	subs    	r2, #0x6c
0x0037d0:	ldrb    	r0, [r6]
0x0037d2:	ldrb    	r5, [r4]
0x0037d4:	movs    	r0, r0
0x0037d6:	movs    	r0, r0
0x0037d8:	ldr     	r4, [r6, #0x14]
0x0037da:	str     	r5, [r5, #0x54]
0x0037dc:	movs    	r0, #0x72
0x0037de:	strb    	r5, [r4, #9]
0x0037e0:	subs    	r2, #0x72
0x0037e2:	str     	r5, [r4, #0x40]
0x0037e4:	movs    	r0, r0
0x0037e6:	movs    	r0, r0
0x0037e8:	str     	r4, [r4, #0x54]
0x0037ea:	ldr     	r1, [r4, #0x44]
0x0037ec:	ldr     	r4, [r6, #0x14]
0x0037ee:	str     	r5, [r5, #0x54]
0x0037f0:	lsls    	r2, r6, #1
0x0037f2:	movs    	r0, r0
0x0037f4:	ldr     	r4, [r6, #0x14]
0x0037f6:	str     	r5, [r5, #0x54]
0x0037f8:	muls    	r2, r6, r2
0x0037fa:	str     	r2, [r6, #0x54]
0x0037fc:	strb    	r1, [r4, #0x11]
0x0037fe:	movs    	r0, #0x65
0x003800:	strb    	r5, [r4, #9]
0x003802:	movs    	r0, #0x72
0x003804:	adds    	r1, #0x30
0x003806:	movs    	r0, r0
0x003808:	ldrb    	r5, [r4, #1]
0x00380a:	movs    	r0, #0x74
0x00380c:	strb    	r5, [r4, #9]
0x00380e:	subs    	r2, #0x72
0x003810:	str     	r5, [r4, #0x40]
0x003812:	movs    	r0, r0
0x003814:	strb    	r5, [r5, #9]
0x003816:	ldrsh   	r3, [r4, r5]
0x003818:	ldrb    	r5, [r4, #1]
0x00381a:	ldr     	r5, [pc, #0x1d0]
0x00381c:	strb    	r0, [r6, #0xd]
0x00381e:	strb    	r6, [r0, #1]
0x003820:	str     	r3, [r0, #0x14]
0x003822:	ldr     	r4, [r5, #0x44]
0x003824:	str     	r2, [r7, #0x50]
0x003826:	strb    	r2, [r6, #9]
0x003828:	movs    	r0, r0
0x00382a:	movs    	r0, r0
0x00382c:	adds    	r2, #0x63
0x00382e:	subs    	r2, #0x75
0x003830:	strb    	r5, [r4, #9]
0x003832:	movs    	r0, #0x72
0x003834:	movs    	r0, #0x20
0x003836:	movs    	r1, r6
0x003838:	adds    	r2, #0x63
0x00383a:	subs    	r2, #0x75
0x00383c:	strb    	r5, [r4, #9]
0x00383e:	movs    	r0, #0x72
0x003840:	movs    	r0, #0x20
0x003842:	movs    	r2, r6
0x003844:	str     	r2, [r6, #0x54]
0x003846:	strb    	r3, [r6, #0x11]
0x003848:	strb    	r1, [r4, #9]
0x00384a:	lsls    	r4, r6, #1
0x00384c:	strb    	r5, [r4, #9]
0x00384e:	subs    	r2, #0x72
0x003850:	str     	r5, [r4, #0x40]
0x003852:	movs    	r0, r0
0x003854:	str     	r2, [r6, #0x54]
0x003856:	str     	r1, [r4, #0x44]
0x003858:	movs    	r2, #0x20
0x00385a:	strb    	r5, [r4, #0xc]
0x00385c:	movs    	r0, #0x22
0x00385e:	strb    	r6, [r4, #9]
0x003860:	ldr     	r7, [r5, #0x54]
0x003862:	ldr     	r0, [r4, #0x50]
0x003864:	strb    	r2, [r6, #1]
0x003866:	str     	r0, [r4, #0x50]

; ===== candidate_00375e =====
0x00375e:	push    	{r1, r2, r6, r7, lr}
0x003760:	stm     	r0!, {r0, r2, r4, r5, r7}
0x003762:	adr     	r2, #0x2dc
0x003764:	bmi     	#0x370a
0x003766:	movs    	r0, r0
0x003768:	ble     	#0x3714
0x00376a:	push    	{r1, r2, r3, r6, r7}
0x00376c:	blo     	#0x36e8
0x00376e:	rsb     	r3, r8, r6, ror #22
0x003772:	strd    	sl, ip, [lr, #0x28c]
0x003776:	cbnz    	r2, #0x37e6
0x003778:	bgt     	#0x3704
0x00377a:	adr     	r2, #0x2dc
0x00377c:	ldm     	r5!, {r0, r1, r3, r6, r7}
0x00377e:	blo     	#0x36ee
0x003780:	strd    	pc, fp, [lr, #0x33c]
0x003784:	adr     	r2, #0x33c
0x003786:	adr     	r1, #0x28c
0x003788:	movs    	r0, r0
0x00378a:	movs    	r0, r0
0x00378c:	movs    	r3, r4
0x00378e:	movs    	r0, r0
0x003790:	stm     	r4!, {r0, r6, r7}
0x003792:	stcl    	p5, c12, [ip], {0xd0}
0x003796:	adr     	r2, #0x33c
0x003798:	bne     	#0x3740
0x00379a:	adr     	r2, #0x2dc
0x00379c:	ldm     	r5!, {r0, r1, r3, r6, r7}
0x00379e:	movs    	r0, r0
0x0037a0:	stm     	r4!, {r0, r6, r7}
0x0037a2:	vstmia  	ip, {s27, s28, s29, s30, s31}
0x0037a6:	ble     	#0x373a
0x0037a8:	cbnz    	r2, #0x3818
0x0037aa:	bgt     	#0x3736
0x0037ac:	add     	r2, sp, #0x338
0x0037ae:	bpl     	#0x3730
0x0037b0:	movs    	r0, r0
0x0037b2:	movs    	r0, r0
0x0037b4:	strh    	r5, [r1, r1]
0x0037b6:	bx      	sl
0x0037b8:	movs    	r4, r0
0x0037ba:	movs    	r0, r0
0x0037bc:	movs    	r0, r0
0x0037be:	movs    	r0, r0
0x0037c0:	movs    	r4, r0
0x0037c2:	movs    	r0, r0
0x0037c4:	str     	r1, [r4, #0x24]
0x0037c6:	lsls    	r3, r4, #1
0x0037c8:	movs    	r0, r0
0x0037ca:	movs    	r0, r0
0x0037cc:	str     	r6, [r2, #0x14]
0x0037ce:	subs    	r2, #0x6c
0x0037d0:	ldrb    	r0, [r6]
0x0037d2:	ldrb    	r5, [r4]
0x0037d4:	movs    	r0, r0
0x0037d6:	movs    	r0, r0
0x0037d8:	ldr     	r4, [r6, #0x14]
0x0037da:	str     	r5, [r5, #0x54]
0x0037dc:	movs    	r0, #0x72
0x0037de:	strb    	r5, [r4, #9]
0x0037e0:	subs    	r2, #0x72
0x0037e2:	str     	r5, [r4, #0x40]
0x0037e4:	movs    	r0, r0
0x0037e6:	movs    	r0, r0
0x0037e8:	str     	r4, [r4, #0x54]
0x0037ea:	ldr     	r1, [r4, #0x44]
0x0037ec:	ldr     	r4, [r6, #0x14]
0x0037ee:	str     	r5, [r5, #0x54]
0x0037f0:	lsls    	r2, r6, #1
0x0037f2:	movs    	r0, r0
0x0037f4:	ldr     	r4, [r6, #0x14]
0x0037f6:	str     	r5, [r5, #0x54]
0x0037f8:	muls    	r2, r6, r2
0x0037fa:	str     	r2, [r6, #0x54]
0x0037fc:	strb    	r1, [r4, #0x11]
0x0037fe:	movs    	r0, #0x65
0x003800:	strb    	r5, [r4, #9]
0x003802:	movs    	r0, #0x72
0x003804:	adds    	r1, #0x30
0x003806:	movs    	r0, r0
0x003808:	ldrb    	r5, [r4, #1]
0x00380a:	movs    	r0, #0x74
0x00380c:	strb    	r5, [r4, #9]
0x00380e:	subs    	r2, #0x72
0x003810:	str     	r5, [r4, #0x40]
0x003812:	movs    	r0, r0
0x003814:	strb    	r5, [r5, #9]
0x003816:	ldrsh   	r3, [r4, r5]
0x003818:	ldrb    	r5, [r4, #1]
0x00381a:	ldr     	r5, [pc, #0x1d0]
0x00381c:	strb    	r0, [r6, #0xd]
0x00381e:	strb    	r6, [r0, #1]
0x003820:	str     	r3, [r0, #0x14]
0x003822:	ldr     	r4, [r5, #0x44]
0x003824:	str     	r2, [r7, #0x50]
0x003826:	strb    	r2, [r6, #9]
0x003828:	movs    	r0, r0
0x00382a:	movs    	r0, r0
0x00382c:	adds    	r2, #0x63
0x00382e:	subs    	r2, #0x75
0x003830:	strb    	r5, [r4, #9]
0x003832:	movs    	r0, #0x72
0x003834:	movs    	r0, #0x20
0x003836:	movs    	r1, r6
0x003838:	adds    	r2, #0x63
0x00383a:	subs    	r2, #0x75
0x00383c:	strb    	r5, [r4, #9]
0x00383e:	movs    	r0, #0x72
0x003840:	movs    	r0, #0x20
0x003842:	movs    	r2, r6
0x003844:	str     	r2, [r6, #0x54]
0x003846:	strb    	r3, [r6, #0x11]
0x003848:	strb    	r1, [r4, #9]
0x00384a:	lsls    	r4, r6, #1
0x00384c:	strb    	r5, [r4, #9]
0x00384e:	subs    	r2, #0x72
0x003850:	str     	r5, [r4, #0x40]
0x003852:	movs    	r0, r0
0x003854:	str     	r2, [r6, #0x54]
0x003856:	str     	r1, [r4, #0x44]
0x003858:	movs    	r2, #0x20
0x00385a:	strb    	r5, [r4, #0xc]
0x00385c:	movs    	r0, #0x22
0x00385e:	strb    	r6, [r4, #9]
0x003860:	ldr     	r7, [r5, #0x54]
0x003862:	ldr     	r0, [r4, #0x50]
0x003864:	strb    	r2, [r6, #1]
0x003866:	str     	r0, [r4, #0x50]
0x003868:	strb    	r2, [r6, #9]
0x00386a:	str     	r4, [r5, #0x30]
0x00386c:	str     	r7, [r5, #0x44]
0x00386e:	subs    	r5, #0x65
0x003870:	str     	r5, [r4, #0x40]
0x003872:	movs    	r0, r0
0x003874:	strb    	r3, [r4, #9]
0x003876:	movs    	r0, #0x63
0x003878:	strb    	r5, [r4, #9]
0x00387a:	movs    	r1, #0x72
0x00387c:	movs    	r0, r0
0x00387e:	movs    	r0, r0
0x003880:	str     	r4, [r5, #0x54]

; ===== candidate_00376a =====
0x00376a:	push    	{r1, r2, r3, r6, r7}
0x00376c:	blo     	#0x36e8
0x00376e:	rsb     	r3, r8, r6, ror #22
0x003772:	strd    	sl, ip, [lr, #0x28c]
0x003776:	cbnz    	r2, #0x37e6
0x003778:	bgt     	#0x3704
0x00377a:	adr     	r2, #0x2dc
0x00377c:	ldm     	r5!, {r0, r1, r3, r6, r7}
0x00377e:	blo     	#0x36ee
0x003780:	strd    	pc, fp, [lr, #0x33c]
0x003784:	adr     	r2, #0x33c
0x003786:	adr     	r1, #0x28c
0x003788:	movs    	r0, r0
0x00378a:	movs    	r0, r0
0x00378c:	movs    	r3, r4
0x00378e:	movs    	r0, r0
0x003790:	stm     	r4!, {r0, r6, r7}
0x003792:	stcl    	p5, c12, [ip], {0xd0}
0x003796:	adr     	r2, #0x33c
0x003798:	bne     	#0x3740
0x00379a:	adr     	r2, #0x2dc
0x00379c:	ldm     	r5!, {r0, r1, r3, r6, r7}
0x00379e:	movs    	r0, r0
0x0037a0:	stm     	r4!, {r0, r6, r7}
0x0037a2:	vstmia  	ip, {s27, s28, s29, s30, s31}
0x0037a6:	ble     	#0x373a
0x0037a8:	cbnz    	r2, #0x3818
0x0037aa:	bgt     	#0x3736
0x0037ac:	add     	r2, sp, #0x338
0x0037ae:	bpl     	#0x3730
0x0037b0:	movs    	r0, r0
0x0037b2:	movs    	r0, r0
0x0037b4:	strh    	r5, [r1, r1]
0x0037b6:	bx      	sl
0x0037b8:	movs    	r4, r0
0x0037ba:	movs    	r0, r0
0x0037bc:	movs    	r0, r0
0x0037be:	movs    	r0, r0
0x0037c0:	movs    	r4, r0
0x0037c2:	movs    	r0, r0
0x0037c4:	str     	r1, [r4, #0x24]
0x0037c6:	lsls    	r3, r4, #1
0x0037c8:	movs    	r0, r0
0x0037ca:	movs    	r0, r0
0x0037cc:	str     	r6, [r2, #0x14]
0x0037ce:	subs    	r2, #0x6c
0x0037d0:	ldrb    	r0, [r6]
0x0037d2:	ldrb    	r5, [r4]
0x0037d4:	movs    	r0, r0
0x0037d6:	movs    	r0, r0
0x0037d8:	ldr     	r4, [r6, #0x14]
0x0037da:	str     	r5, [r5, #0x54]
0x0037dc:	movs    	r0, #0x72
0x0037de:	strb    	r5, [r4, #9]
0x0037e0:	subs    	r2, #0x72
0x0037e2:	str     	r5, [r4, #0x40]
0x0037e4:	movs    	r0, r0
0x0037e6:	movs    	r0, r0
0x0037e8:	str     	r4, [r4, #0x54]
0x0037ea:	ldr     	r1, [r4, #0x44]
0x0037ec:	ldr     	r4, [r6, #0x14]
0x0037ee:	str     	r5, [r5, #0x54]
0x0037f0:	lsls    	r2, r6, #1
0x0037f2:	movs    	r0, r0
0x0037f4:	ldr     	r4, [r6, #0x14]
0x0037f6:	str     	r5, [r5, #0x54]
0x0037f8:	muls    	r2, r6, r2
0x0037fa:	str     	r2, [r6, #0x54]
0x0037fc:	strb    	r1, [r4, #0x11]
0x0037fe:	movs    	r0, #0x65
0x003800:	strb    	r5, [r4, #9]
0x003802:	movs    	r0, #0x72
0x003804:	adds    	r1, #0x30
0x003806:	movs    	r0, r0
0x003808:	ldrb    	r5, [r4, #1]
0x00380a:	movs    	r0, #0x74
0x00380c:	strb    	r5, [r4, #9]
0x00380e:	subs    	r2, #0x72
0x003810:	str     	r5, [r4, #0x40]
0x003812:	movs    	r0, r0
0x003814:	strb    	r5, [r5, #9]
0x003816:	ldrsh   	r3, [r4, r5]
0x003818:	ldrb    	r5, [r4, #1]
0x00381a:	ldr     	r5, [pc, #0x1d0]
0x00381c:	strb    	r0, [r6, #0xd]
0x00381e:	strb    	r6, [r0, #1]
0x003820:	str     	r3, [r0, #0x14]
0x003822:	ldr     	r4, [r5, #0x44]
0x003824:	str     	r2, [r7, #0x50]
0x003826:	strb    	r2, [r6, #9]
0x003828:	movs    	r0, r0
0x00382a:	movs    	r0, r0
0x00382c:	adds    	r2, #0x63
0x00382e:	subs    	r2, #0x75
0x003830:	strb    	r5, [r4, #9]
0x003832:	movs    	r0, #0x72
0x003834:	movs    	r0, #0x20
0x003836:	movs    	r1, r6
0x003838:	adds    	r2, #0x63
0x00383a:	subs    	r2, #0x75
0x00383c:	strb    	r5, [r4, #9]
0x00383e:	movs    	r0, #0x72
0x003840:	movs    	r0, #0x20
0x003842:	movs    	r2, r6
0x003844:	str     	r2, [r6, #0x54]
0x003846:	strb    	r3, [r6, #0x11]
0x003848:	strb    	r1, [r4, #9]
0x00384a:	lsls    	r4, r6, #1
0x00384c:	strb    	r5, [r4, #9]
0x00384e:	subs    	r2, #0x72
0x003850:	str     	r5, [r4, #0x40]
0x003852:	movs    	r0, r0
0x003854:	str     	r2, [r6, #0x54]
0x003856:	str     	r1, [r4, #0x44]
0x003858:	movs    	r2, #0x20
0x00385a:	strb    	r5, [r4, #0xc]
0x00385c:	movs    	r0, #0x22
0x00385e:	strb    	r6, [r4, #9]
0x003860:	ldr     	r7, [r5, #0x54]
0x003862:	ldr     	r0, [r4, #0x50]
0x003864:	strb    	r2, [r6, #1]
0x003866:	str     	r0, [r4, #0x50]
0x003868:	strb    	r2, [r6, #9]
0x00386a:	str     	r4, [r5, #0x30]
0x00386c:	str     	r7, [r5, #0x44]
0x00386e:	subs    	r5, #0x65
0x003870:	str     	r5, [r4, #0x40]
0x003872:	movs    	r0, r0
0x003874:	strb    	r3, [r4, #9]
0x003876:	movs    	r0, #0x63
0x003878:	strb    	r5, [r4, #9]
0x00387a:	movs    	r1, #0x72
0x00387c:	movs    	r0, r0
0x00387e:	movs    	r0, r0
0x003880:	str     	r4, [r5, #0x54]
0x003882:	str     	r6, [r5, #0x74]
0x003884:	ldr     	r4, [r6, #4]
0x003886:	str     	r0, [r4, #0x50]
0x003888:	strb    	r2, [r6, #9]
0x00388a:	movs    	r1, r4
0x00388c:	ldrh    	r7, [r3, #0x18]
