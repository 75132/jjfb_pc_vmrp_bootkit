; fallback candidate disassembly from Thumb prologues; true code is ARM entry + Thumb functions.

; ARM entry
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0xc8
0x000018:	pop     	{r4, pc}
0x00001c:	ldr     	r0, [pc, #8]
0x000020:	ldr     	r1, [pc, #8]
0x000024:	add     	r0, r0, r1
0x000028:	bx      	lr
0x00002c:	andeq   	r0, r0, r4
0x000030:	andeq   	r0, r0, r0, lsl #2
0x000034:	mov     	sb, r0
0x000038:	bx      	lr

; ===== candidate_000008 =====
0x000008:	ands    	r0, r2
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	movs    	r3, r5

; ===== candidate_00000a =====
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	movs    	r3, r5

; ===== candidate_00003c =====
0x00003c:	push    	{r3, r4, r5, lr}
0x00003e:	ldr     	r4, [pc, #0x78]
0x000040:	movs    	r0, #1
0x000042:	add     	r4, sb
0x000044:	str     	r0, [r4, #0x18]
0x000046:	ldr     	r0, [pc, #0x74]
0x000048:	add     	r0, pc
0x00004a:	ldr     	r0, [r0, #0x38]
0x00004c:	ldr     	r2, [pc, #0x70]
0x00004e:	ldr     	r1, [r0, #0x68]
0x000050:	add     	r2, sb
0x000052:	str     	r1, [r4, #0x2c]
0x000054:	ldr     	r1, [r0, #0xc]
0x000056:	ldr     	r5, [pc, #0x6c]
0x000058:	str     	r1, [r4, #0x30]
0x00005a:	ldr     	r1, [r0, #0x10]
0x00005c:	str     	r1, [r4, #0x34]
0x00005e:	ldr     	r1, [r0, #0x14]
0x000060:	str     	r1, [r4, #0x38]
0x000062:	ldr     	r1, [r0, #0x18]
0x000064:	str     	r1, [r4, #0x3c]
0x000066:	ldr     	r1, [r0, #0x1c]
0x000068:	str     	r1, [r4, #0x40]
0x00006a:	ldr     	r1, [r0, #0x20]
0x00006c:	str     	r1, [r4, #0x44]
0x00006e:	ldr     	r1, [r0, #0x24]
0x000070:	str     	r1, [r4, #0x48]
0x000072:	ldr     	r1, [r0, #0x28]
0x000074:	str     	r1, [r4, #0x4c]
0x000076:	ldr     	r1, [r0, #0x2c]
0x000078:	str     	r1, [r4, #0x50]
0x00007a:	ldr     	r1, [r0, #0x30]
0x00007c:	str     	r1, [r4, #0x54]
0x00007e:	ldr     	r1, [r0, #0x34]
0x000080:	str     	r1, [r4, #0x58]
0x000082:	ldr     	r1, [r0, #0x38]
0x000084:	str     	r1, [r4, #0x5c]
0x000086:	ldr     	r1, [r0, #0x3c]
0x000088:	str     	r1, [r4, #0x60]
0x00008a:	ldr     	r1, [r0, #0x40]
0x00008c:	str     	r1, [r4, #0x64]
0x00008e:	ldr     	r1, [r0, #0x44]
0x000090:	str     	r1, [r4, #0x68]
0x000092:	ldr     	r1, [r0, #0x48]
0x000094:	str     	r1, [r4, #0x6c]
0x000096:	ldr     	r1, [r0, #0x4c]
0x000098:	str     	r1, [r4, #0x70]
0x00009a:	movs    	r1, #0
0x00009c:	str     	r1, [r2]
0x00009e:	movs    	r1, #1
0x0000a0:	lsls    	r1, r1, #9
0x0000a2:	adds    	r0, r0, r1
0x0000a4:	ldr     	r3, [r0, #8]
0x0000a6:	movs    	r1, #7
0x0000a8:	adds    	r2, r5, #0
0x0000aa:	movs    	r0, #0
0x0000ac:	blx     	r3
0x0000ae:	cmp     	r0, r5
0x0000b0:	bne     	#0xb6
0x0000b2:	subs    	r0, #2
0x0000b4:	str     	r0, [r4, #0x28]
0x0000b6:	pop     	{r3, r4, r5, pc}

; ===== candidate_0000c8 =====
0x0000c8:	push    	{r3, r4, r5, lr}
0x0000ca:	ldr     	r4, [pc, #0x48]
0x0000cc:	add     	r4, pc
0x0000ce:	ldr     	r0, [r4, #0x38]
0x0000d0:	movs    	r1, #0x14
0x0000d2:	ldr     	r2, [r0, #0x64]
0x0000d4:	ldr     	r0, [pc, #0x40]
0x0000d6:	add     	r0, pc
0x0000d8:	blx     	r2
0x0000da:	movs    	r5, #0
0x0000dc:	mvns    	r5, r5
0x0000de:	cmp     	r0, r5
0x0000e0:	bne     	#0xe6
0x0000e2:	adds    	r0, r5, #0
0x0000e4:	pop     	{r3, r4, r5, pc}

; ===== candidate_00011c =====
0x00011c:	push    	{r4, r5, r6, r7, lr}
0x00011e:	adds    	r5, r1, #0
0x000120:	adds    	r4, r0, #0
0x000122:	adds    	r6, r2, #0
0x000124:	ldr     	r2, [pc, #0x28]
0x000126:	sub     	sp, #0x14
0x000128:	mov     	ip, r3
0x00012a:	add     	r2, pc
0x00012c:	ldr     	r0, [sp, #0x2c]
0x00012e:	ldr     	r1, [sp, #0x30]
0x000130:	ldr     	r7, [sp, #0x28]
0x000132:	ldr     	r3, [r2, #0x3c]
0x000134:	movs    	r2, #2
0x000136:	str     	r2, [sp, #0xc]
0x000138:	str     	r1, [sp, #8]
0x00013a:	str     	r0, [sp, #4]
0x00013c:	str     	r7, [sp]
0x00013e:	ldr     	r0, [r3, #0xc]
0x000140:	adds    	r1, r5, #0
0x000142:	adds    	r2, r6, #0
0x000144:	ldr     	r7, [r0, #0x28]
0x000146:	adds    	r0, r4, #0
0x000148:	mov     	r3, ip
0x00014a:	blx     	r7
0x00014c:	add     	sp, #0x14
0x00014e:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000168 =====
0x000168:	push    	{r4, r5, r6, r7, lr}
0x00016a:	sub     	sp, #0xc
0x00016c:	bl      	#0x154
0x000170:	adds    	r3, r0, #0
0x000172:	ldr     	r0, [pc, #0x3a0]
0x000174:	movs    	r2, #0
0x000176:	movs    	r1, #0
0x000178:	add     	r0, pc
0x00017a:	str     	r1, [sp, #4]
0x00017c:	str     	r2, [sp, #8]
0x00017e:	movs    	r2, #0xc
0x000180:	movs    	r1, #0x71
0x000182:	str     	r0, [sp]
0x000184:	ldr     	r0, [pc, #0x390]
0x000186:	lsls    	r1, r1, #9
0x000188:	bl      	#0x11c
0x00018c:	movs    	r5, #0
0x00018e:	mvns    	r5, r5
0x000190:	adds    	r6, r0, #0
0x000192:	cmp     	r0, #0
0x000194:	bne     	#0x19c
0x000196:	adds    	r0, r5, #0
0x000198:	add     	sp, #0xc
0x00019a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0007a8 =====
0x0007a8:	push    	{r4, lr}
0x0007aa:	adds    	r4, r0, #0
0x0007ac:	ldr     	r0, [pc, #0x14]
0x0007ae:	add     	r0, pc
0x0007b0:	ldr     	r0, [r0, #0x38]
0x0007b2:	ldr     	r1, [r0]
0x0007b4:	adds    	r0, r4, #4
0x0007b6:	blx     	r1
0x0007b8:	cmp     	r0, #0
0x0007ba:	beq     	#0x7c0
0x0007bc:	stm     	r0!, {r4}
0x0007be:	pop     	{r4, pc}

; ===== candidate_0007c8 =====
0x0007c8:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0007ca:	sub     	sp, #0xc
0x0007cc:	ldr     	r0, [sp, #0x38]
0x0007ce:	ldr     	r4, [sp, #0x3c]
0x0007d0:	ldr     	r6, [sp, #0x34]
0x0007d2:	ldr     	r0, [r0]
0x0007d4:	mov     	r7, sb
0x0007d6:	movs    	r5, #0
0x0007d8:	blx     	#0x34
0x0007dc:	cmp     	r4, #0
0x0007de:	beq     	#0x7ee
0x0007e0:	ldr     	r1, [sp, #0x30]
0x0007e2:	str     	r6, [sp, #4]
0x0007e4:	add     	r3, sp, #0xc
0x0007e6:	str     	r1, [sp]
0x0007e8:	ldm     	r3, {r0, r1, r2, r3}
0x0007ea:	blx     	r4
0x0007ec:	adds    	r5, r0, #0
0x0007ee:	mov     	sb, r7
0x0007f0:	adds    	r0, r5, #0
0x0007f2:	add     	sp, #0x1c
0x0007f4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0007f8 =====
0x0007f8:	push    	{r3, r4, r5, r6, r7, lr}
0x0007fa:	adds    	r6, r1, #0
0x0007fc:	adds    	r5, r0, #0
0x0007fe:	ldr     	r0, [r0]
0x000800:	movs    	r4, #0
0x000802:	mov     	r7, sb
0x000804:	blx     	#0x34
0x000808:	cmp     	r6, #0
0x00080a:	beq     	#0x81a
0x00080c:	cmp     	r6, #0xa
0x00080e:	bne     	#0x814
0x000810:	ldr     	r4, [pc, #0x1c]
0x000812:	add     	r4, pc
0x000814:	mov     	sb, r7
0x000816:	adds    	r0, r4, #0
0x000818:	pop     	{r3, r4, r5, r6, r7, pc}
