; fallback candidate disassembly from Thumb prologues; true code is ARM entry + Thumb functions.

; ARM entry
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0x38d0
0x000018:	pop     	{r4, pc}
0x00001c:	ldr     	r0, [pc, #8]
0x000020:	ldr     	r1, [pc, #8]
0x000024:	add     	r0, r0, r1
0x000028:	bx      	lr
0x00002c:	andeq   	r0, r0, r0, lsl r0
0x000030:	andeq   	r0, r0, r8, ror r1
0x000034:	mov     	sb, r0
0x000038:	bx      	lr
0x00003c:	stcmi   	p5, c11, [sp], #-0xc0
0x000040:	ldrbtmi 	r2, [ip], #-0x21c
0x000044:	smlatbhs	r0, r0, fp, r6
0x000048:	stmdami 	fp!, {r0, r1, r7, r8, sb, fp, sp, lr}
0x00004c:	strbmi  	fp, [r8], #-0x83
0x000050:	andhs   	r4, r0, #152, #14
0x000054:	andls   	r2, r0, r0
0x000058:	movwhs  	r4, #0x927

; ===== candidate_000008 =====
0x000008:	ands    	r0, r2
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	lsrs    	r5, r5, #0x18

; ===== candidate_00000a =====
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	lsrs    	r5, r5, #0x18

; ===== candidate_00003c =====
0x00003c:	push    	{r4, r5, lr}
0x00003e:	ldr     	r4, [pc, #0xb4]
0x000040:	movs    	r2, #0x1c
0x000042:	add     	r4, pc
0x000044:	ldr     	r0, [r4, #0x38]
0x000046:	movs    	r1, #0
0x000048:	ldr     	r3, [r0, #0x38]
0x00004a:	ldr     	r0, [pc, #0xac]
0x00004c:	sub     	sp, #0xc
0x00004e:	add     	r0, sb
0x000050:	blx     	r3
0x000052:	movs    	r2, #0
0x000054:	movs    	r0, #0
0x000056:	str     	r0, [sp]
0x000058:	ldr     	r1, [pc, #0x9c]
0x00005a:	movs    	r3, #0
0x00005c:	add     	r1, sb
0x00005e:	str     	r1, [sp, #4]
0x000060:	movs    	r1, #0x64
0x000062:	movs    	r0, #1
0x000064:	str     	r2, [sp, #8]
0x000066:	bl      	#0x39a8
0x00006a:	ldr     	r1, [pc, #0x8c]
0x00006c:	movs    	r0, #0
0x00006e:	add     	r1, sb
0x000070:	subs    	r1, #0x7c
0x000072:	str     	r0, [r1, #8]
0x000074:	ldr     	r5, [pc, #0x80]
0x000076:	str     	r0, [r1, #0x10]
0x000078:	str     	r0, [r1, #0xc]
0x00007a:	add     	r5, sb
0x00007c:	subs    	r5, #0xfc
0x00007e:	movs    	r0, #1
0x000080:	str     	r0, [r5, #0x18]
0x000082:	ldr     	r0, [r4, #0x38]
0x000084:	ldr     	r2, [pc, #0x74]
0x000086:	ldr     	r1, [r0, #0x68]
0x000088:	add     	r2, sb
0x00008a:	str     	r1, [r5, #0x2c]
0x00008c:	ldr     	r1, [r0, #0xc]
0x00008e:	ldr     	r4, [pc, #0x70]
0x000090:	str     	r1, [r5, #0x30]
0x000092:	ldr     	r1, [r0, #0x10]
0x000094:	str     	r1, [r5, #0x34]
0x000096:	ldr     	r1, [r0, #0x14]
0x000098:	str     	r1, [r5, #0x38]
0x00009a:	ldr     	r1, [r0, #0x18]
0x00009c:	str     	r1, [r5, #0x3c]
0x00009e:	ldr     	r1, [r0, #0x1c]
0x0000a0:	str     	r1, [r5, #0x40]
0x0000a2:	ldr     	r1, [r0, #0x20]
0x0000a4:	str     	r1, [r5, #0x44]
0x0000a6:	ldr     	r1, [r0, #0x24]
0x0000a8:	str     	r1, [r5, #0x48]
0x0000aa:	ldr     	r1, [r0, #0x28]
0x0000ac:	str     	r1, [r5, #0x4c]
0x0000ae:	ldr     	r1, [r0, #0x2c]
0x0000b0:	str     	r1, [r5, #0x50]
0x0000b2:	ldr     	r1, [r0, #0x30]
0x0000b4:	str     	r1, [r5, #0x54]
0x0000b6:	ldr     	r1, [r0, #0x34]
0x0000b8:	str     	r1, [r5, #0x58]
0x0000ba:	ldr     	r1, [r0, #0x38]
0x0000bc:	str     	r1, [r5, #0x5c]
0x0000be:	ldr     	r1, [r0, #0x3c]
0x0000c0:	str     	r1, [r5, #0x60]
0x0000c2:	ldr     	r1, [r0, #0x40]
0x0000c4:	str     	r1, [r5, #0x64]
0x0000c6:	ldr     	r1, [r0, #0x44]
0x0000c8:	str     	r1, [r5, #0x68]
0x0000ca:	ldr     	r1, [r0, #0x48]
0x0000cc:	str     	r1, [r5, #0x6c]
0x0000ce:	ldr     	r1, [r0, #0x4c]
0x0000d0:	str     	r1, [r5, #0x70]
0x0000d2:	movs    	r1, #0
0x0000d4:	str     	r1, [r2]
0x0000d6:	movs    	r1, #1
0x0000d8:	lsls    	r1, r1, #9
0x0000da:	adds    	r0, r0, r1
0x0000dc:	ldr     	r3, [r0, #8]
0x0000de:	movs    	r1, #7
0x0000e0:	adds    	r2, r4, #0
0x0000e2:	movs    	r0, #0
0x0000e4:	blx     	r3
0x0000e6:	cmp     	r0, r4
0x0000e8:	bne     	#0xee
0x0000ea:	subs    	r0, #2
0x0000ec:	str     	r0, [r5, #0x28]
0x0000ee:	add     	sp, #0xc
0x0000f0:	pop     	{r4, r5, pc}

; ===== candidate_000104 =====
0x000104:	push    	{r4, r5, r6, r7, lr}
0x000106:	sub     	sp, #0xc
0x000108:	movs    	r1, #0
0x00010a:	movs    	r2, #0
0x00010c:	str     	r2, [sp, #8]
0x00010e:	str     	r1, [sp]
0x000110:	str     	r1, [sp, #4]
0x000112:	movs    	r7, #0xf1
0x000114:	movs    	r4, #0
0x000116:	adds    	r3, r4, #0
0x000118:	lsls    	r7, r7, #9
0x00011a:	movs    	r1, #0xe1
0x00011c:	movs    	r2, #0xde
0x00011e:	adds    	r5, r0, #0
0x000120:	adds    	r0, r7, #0
0x000122:	bl      	#0x39a8
0x000126:	movs    	r1, #0
0x000128:	movs    	r2, #0
0x00012a:	str     	r2, [sp, #8]
0x00012c:	str     	r1, [sp]
0x00012e:	str     	r1, [sp, #4]
0x000130:	movs    	r1, #0xe1
0x000132:	movs    	r2, #0x52
0x000134:	adds    	r6, r0, #0
0x000136:	adds    	r3, r4, #0
0x000138:	adds    	r0, r7, #0
0x00013a:	bl      	#0x39a8
0x00013e:	movs    	r2, #0
0x000140:	movs    	r1, #0
0x000142:	str     	r2, [sp, #8]
0x000144:	adds    	r2, r0, #0
0x000146:	str     	r1, [sp]
0x000148:	str     	r1, [sp, #4]
0x00014a:	movs    	r1, #0x27
0x00014c:	adds    	r0, r7, #0
0x00014e:	adds    	r3, r6, #0
0x000150:	bl      	#0x39a8
0x000154:	movs    	r1, #0
0x000156:	movs    	r2, #0
0x000158:	str     	r2, [sp, #8]
0x00015a:	str     	r1, [sp]
0x00015c:	str     	r1, [sp, #4]
0x00015e:	movs    	r1, #0x8c
0x000160:	adds    	r2, r0, #0
0x000162:	adds    	r3, r4, #0
0x000164:	adds    	r0, r7, #0
0x000166:	bl      	#0x39a8
0x00016a:	movs    	r1, #0
0x00016c:	movs    	r2, #0
0x00016e:	str     	r2, [sp, #8]
0x000170:	str     	r1, [sp]
0x000172:	str     	r1, [sp, #4]
0x000174:	movs    	r1, #0xe1
0x000176:	movs    	r2, #0xde
0x000178:	adds    	r3, r4, #0
0x00017a:	adds    	r0, r7, #0
0x00017c:	bl      	#0x39a8
0x000180:	movs    	r1, #0
0x000182:	movs    	r2, #0
0x000184:	str     	r2, [sp, #8]
0x000186:	str     	r1, [sp]
0x000188:	str     	r1, [sp, #4]
0x00018a:	movs    	r1, #0xe1
0x00018c:	movs    	r2, #0x52
0x00018e:	adds    	r6, r0, #0
0x000190:	adds    	r3, r4, #0
0x000192:	adds    	r0, r7, #0
0x000194:	bl      	#0x39a8
0x000198:	movs    	r1, #0
0x00019a:	movs    	r2, #0
0x00019c:	str     	r2, [sp, #8]
0x00019e:	str     	r1, [sp]
0x0001a0:	str     	r1, [sp, #4]
0x0001a2:	movs    	r1, #0x4b
0x0001a4:	adds    	r2, r0, #0
0x0001a6:	adds    	r3, r6, #0
0x0001a8:	adds    	r0, r7, #0
0x0001aa:	bl      	#0x39a8
0x0001ae:	cmp     	r5, #0
0x0001b0:	beq     	#0x1cc
0x0001b2:	movs    	r1, #0
0x0001b4:	ldr     	r0, [pc, #0x20]
0x0001b6:	str     	r1, [sp]
0x0001b8:	str     	r1, [sp, #4]
0x0001ba:	movs    	r2, #0
0x0001bc:	str     	r2, [sp, #8]
0x0001be:	add     	r0, sb
0x0001c0:	ldr     	r2, [r0, #0x14]
0x0001c2:	movs    	r1, #0x36
0x0001c4:	adds    	r3, r5, #0
0x0001c6:	adds    	r0, r7, #0
0x0001c8:	bl      	#0x39a8
0x0001cc:	movs    	r1, #0
0x0001ce:	movs    	r0, #1
0x0001d0:	bl      	#0x3e20
0x0001d4:	add     	sp, #0xc
0x0001d6:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0001dc =====
0x0001dc:	push    	{r4, r5, r6, r7, lr}
0x0001de:	sub     	sp, #0x1c
0x0001e0:	movs    	r6, #0
0x0001e2:	movs    	r2, #0
0x0001e4:	movs    	r1, #0
0x0001e6:	str     	r2, [sp, #8]
0x0001e8:	adds    	r3, r6, #0
0x0001ea:	adds    	r4, r0, #0
0x0001ec:	adds    	r2, r0, #0
0x0001ee:	str     	r1, [sp]
0x0001f0:	str     	r1, [sp, #4]
0x0001f2:	movs    	r1, #0x44
0x0001f4:	movs    	r0, #0xf1
0x0001f6:	movs    	r5, #0
0x0001f8:	lsls    	r0, r0, #9
0x0001fa:	bl      	#0x39a8
0x0001fe:	movs    	r1, #0
0x000200:	str     	r1, [sp]
0x000202:	str     	r1, [sp, #4]
0x000204:	movs    	r2, #0
0x000206:	str     	r2, [sp, #8]
0x000208:	movs    	r1, #0x45
0x00020a:	adds    	r3, r6, #0
0x00020c:	movs    	r0, #0xf1
0x00020e:	lsls    	r0, r0, #9
0x000210:	ldr     	r2, [r4, #8]
0x000212:	bl      	#0x39a8
0x000216:	movs    	r1, #0
0x000218:	adds    	r7, r0, #0
0x00021a:	movs    	r2, #0
0x00021c:	str     	r2, [sp, #8]
0x00021e:	str     	r1, [sp]
0x000220:	str     	r1, [sp, #4]
0x000222:	movs    	r1, #0xe1
0x000224:	movs    	r2, #0x52
0x000226:	movs    	r0, #0xf1
0x000228:	adds    	r3, r6, #0
0x00022a:	lsls    	r0, r0, #9
0x00022c:	bl      	#0x39a8
0x000230:	movs    	r2, #0
0x000232:	str     	r2, [sp, #8]
0x000234:	movs    	r1, #0
0x000236:	adds    	r2, r0, #0
0x000238:	movs    	r0, #0xf1
0x00023a:	str     	r1, [sp]
0x00023c:	str     	r1, [sp, #4]
0x00023e:	movs    	r1, #0x92
0x000240:	lsls    	r0, r0, #9
0x000242:	adds    	r3, r7, #0
0x000244:	bl      	#0x39a8
0x000248:	movs    	r1, #0
0x00024a:	str     	r1, [sp]
0x00024c:	str     	r1, [sp, #4]
0x00024e:	str     	r0, [sp, #0x14]
0x000250:	movs    	r2, #0
0x000252:	str     	r2, [sp, #8]
0x000254:	movs    	r0, #0xf1
0x000256:	movs    	r1, #0x45
0x000258:	adds    	r3, r6, #0
0x00025a:	lsls    	r0, r0, #9
0x00025c:	ldr     	r2, [r4, #8]
0x00025e:	bl      	#0x39a8
0x000262:	str     	r0, [sp, #0x18]
0x000264:	cmp     	r0, #0
0x000266:	ble     	#0x2f6
0x000268:	movs    	r1, #0
0x00026a:	str     	r1, [sp]
0x00026c:	str     	r1, [sp, #4]
0x00026e:	movs    	r2, #0
0x000270:	movs    	r7, #0xf1
0x000272:	lsls    	r7, r7, #9
0x000274:	str     	r2, [sp, #8]
0x000276:	movs    	r1, #0x46
0x000278:	adds    	r3, r6, #0
0x00027a:	adds    	r0, r7, #0
0x00027c:	ldr     	r2, [r4, #8]
0x00027e:	bl      	#0x39a8
0x000282:	lsls    	r0, r0, #0x18
0x000284:	asrs    	r0, r0, #0x18
0x000286:	adds    	r3, r0, #1
0x000288:	beq     	#0x2ee
0x00028a:	movs    	r1, #0
0x00028c:	str     	r1, [sp]
0x00028e:	str     	r1, [sp, #4]
0x000290:	movs    	r2, #0
0x000292:	str     	r2, [sp, #8]
0x000294:	movs    	r1, #0x45
0x000296:	adds    	r3, r6, #0
0x000298:	adds    	r0, r7, #0
0x00029a:	ldr     	r2, [r4, #8]
0x00029c:	bl      	#0x39a8
0x0002a0:	movs    	r1, #0
0x0002a2:	str     	r1, [sp]
0x0002a4:	str     	r1, [sp, #4]
0x0002a6:	movs    	r2, #0
0x0002a8:	str     	r0, [sp, #0x10]
0x0002aa:	str     	r2, [sp, #8]
0x0002ac:	movs    	r1, #0x46
0x0002ae:	adds    	r3, r6, #0
0x0002b0:	adds    	r0, r7, #0
0x0002b2:	ldr     	r2, [r4, #8]
0x0002b4:	bl      	#0x39a8
0x0002b8:	movs    	r1, #0
0x0002ba:	lsls    	r7, r0, #0x18
0x0002bc:	movs    	r2, #0
0x0002be:	str     	r1, [sp]
0x0002c0:	str     	r1, [sp, #4]
0x0002c2:	movs    	r1, #0x90
0x0002c4:	str     	r2, [sp, #8]
0x0002c6:	asrs    	r7, r7, #0x18
0x0002c8:	movs    	r0, #0xf1
0x0002ca:	adds    	r3, r6, #0
0x0002cc:	lsls    	r0, r0, #9
0x0002ce:	ldr     	r2, [sp, #0x10]
0x0002d0:	bl      	#0x39a8
0x0002d4:	movs    	r1, #0
0x0002d6:	str     	r1, [sp, #4]
0x0002d8:	adds    	r3, r0, #0
0x0002da:	movs    	r2, #0
0x0002dc:	movs    	r1, #0xff
0x0002de:	adds    	r1, #0x18
0x0002e0:	str     	r2, [sp, #8]
0x0002e2:	movs    	r0, #0xf1
0x0002e4:	lsls    	r0, r0, #9
0x0002e6:	ldr     	r2, [sp, #0x14]
0x0002e8:	str     	r7, [sp]
0x0002ea:	bl      	#0x39a8
0x0002ee:	ldr     	r0, [sp, #0x18]
0x0002f0:	adds    	r5, #1
0x0002f2:	cmp     	r5, r0
0x0002f4:	blt     	#0x268
0x0002f6:	movs    	r2, #0
0x0002f8:	str     	r2, [sp, #8]
0x0002fa:	movs    	r1, #0
0x0002fc:	adds    	r2, r4, #0
0x0002fe:	movs    	r4, #0xf1
0x000300:	str     	r1, [sp]
0x000302:	str     	r1, [sp, #4]
0x000304:	movs    	r1, #0x91
0x000306:	lsls    	r4, r4, #9
0x000308:	adds    	r0, r4, #0

; ===== candidate_000390 =====
0x000390:	push    	{r4, r5, r6, r7, lr}
0x000392:	sub     	sp, #0x14
0x000394:	movs    	r1, #0
0x000396:	movs    	r2, #0
0x000398:	str     	r2, [sp, #8]
0x00039a:	str     	r1, [sp]
0x00039c:	str     	r1, [sp, #4]
0x00039e:	movs    	r6, #0xf1
0x0003a0:	movs    	r5, #0
0x0003a2:	adds    	r3, r5, #0
0x0003a4:	lsls    	r6, r6, #9
0x0003a6:	movs    	r1, #0xe1
0x0003a8:	movs    	r2, #0xdb
0x0003aa:	movs    	r4, #0
0x0003ac:	adds    	r0, r6, #0
0x0003ae:	bl      	#0x39a8
0x0003b2:	cmp     	r0, #0
0x0003b4:	beq     	#0x3e8
0x0003b6:	movs    	r1, #0
0x0003b8:	movs    	r2, #0
0x0003ba:	str     	r2, [sp, #8]
0x0003bc:	str     	r1, [sp]
0x0003be:	str     	r1, [sp, #4]
0x0003c0:	movs    	r1, #0xe1
0x0003c2:	movs    	r2, #0xdb
0x0003c4:	adds    	r3, r5, #0
0x0003c6:	adds    	r0, r6, #0
0x0003c8:	bl      	#0x39a8
0x0003cc:	movs    	r1, #0
0x0003ce:	movs    	r2, #0
0x0003d0:	str     	r2, [sp, #8]
0x0003d2:	str     	r1, [sp]
0x0003d4:	str     	r1, [sp, #4]
0x0003d6:	movs    	r1, #0xe1
0x0003d8:	movs    	r2, #0xdc
0x0003da:	adds    	r4, r0, #0
0x0003dc:	adds    	r3, r5, #0
0x0003de:	adds    	r0, r6, #0
0x0003e0:	bl      	#0x39a8
0x0003e4:	lsls    	r1, r0, #2
0x0003e6:	ldr     	r4, [r4, r1]
0x0003e8:	ldr     	r1, [pc, #0x3e0]
0x0003ea:	add     	r1, pc
0x0003ec:	ldr     	r7, [pc, #0x3e0]
0x0003ee:	adds    	r0, r4, #0
0x0003f0:	add     	r7, sb
0x0003f2:	ldr     	r2, [r7]
0x0003f4:	blx     	r2
0x0003f6:	cmp     	r0, #0
0x0003f8:	bne     	#0x478
0x0003fa:	movs    	r1, #0
0x0003fc:	movs    	r2, #0
0x0003fe:	str     	r2, [sp, #8]
0x000400:	str     	r1, [sp]
0x000402:	str     	r1, [sp, #4]
0x000404:	movs    	r1, #0xe1
0x000406:	movs    	r2, #0xde
0x000408:	adds    	r3, r5, #0
0x00040a:	adds    	r0, r6, #0
0x00040c:	bl      	#0x39a8
0x000410:	movs    	r1, #0
0x000412:	adds    	r4, r0, #0
0x000414:	movs    	r2, #0
0x000416:	str     	r2, [sp, #8]
0x000418:	str     	r1, [sp]
0x00041a:	str     	r1, [sp, #4]
0x00041c:	movs    	r1, #0xe1
0x00041e:	movs    	r2, #0x52
0x000420:	movs    	r0, #0xf1
0x000422:	adds    	r3, r5, #0
0x000424:	lsls    	r0, r0, #9
0x000426:	bl      	#0x39a8
0x00042a:	movs    	r2, #0
0x00042c:	movs    	r1, #0
0x00042e:	str     	r2, [sp, #8]
0x000430:	adds    	r3, r4, #0
0x000432:	adds    	r2, r0, #0
0x000434:	str     	r1, [sp]
0x000436:	str     	r1, [sp, #4]
0x000438:	movs    	r1, #0x27
0x00043a:	movs    	r0, #0xf1
0x00043c:	lsls    	r0, r0, #9
0x00043e:	bl      	#0x39a8
0x000442:	movs    	r1, #0
0x000444:	adds    	r4, r0, #0
0x000446:	movs    	r2, #0
0x000448:	str     	r2, [sp, #8]
0x00044a:	str     	r1, [sp]
0x00044c:	str     	r1, [sp, #4]
0x00044e:	movs    	r1, #0x9c
0x000450:	movs    	r2, #0x12
0x000452:	movs    	r0, #0xf1
0x000454:	adds    	r3, r5, #0
0x000456:	lsls    	r0, r0, #9
0x000458:	bl      	#0x39a8
0x00045c:	movs    	r1, #0
0x00045e:	movs    	r2, #0
0x000460:	str     	r2, [sp, #8]
0x000462:	str     	r1, [sp]
0x000464:	str     	r1, [sp, #4]
0x000466:	movs    	r1, #0x81
0x000468:	adds    	r2, r4, #0
0x00046a:	movs    	r3, #1
0x00046c:	movs    	r0, #0xf1
0x00046e:	lsls    	r0, r0, #9
0x000470:	bl      	#0x39a8
0x000474:	add     	sp, #0x14
0x000476:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_001348 =====
0x001348:	push    	{r4, r5, r6, r7, lr}
0x00134a:	ldr     	r7, [pc, #0x18c]
0x00134c:	movs    	r6, #0xf1
0x00134e:	add     	r7, sb
0x001350:	ldr     	r0, [r7, #8]
0x001352:	lsls    	r6, r6, #9
0x001354:	movs    	r5, #0
0x001356:	movs    	r4, #0
0x001358:	adds    	r3, r0, #1
0x00135a:	sub     	sp, #0xc
0x00135c:	beq     	#0x13d6
0x00135e:	movs    	r1, #0
0x001360:	movs    	r2, #0
0x001362:	str     	r2, [sp, #8]
0x001364:	str     	r1, [sp]
0x001366:	str     	r1, [sp, #4]
0x001368:	movs    	r1, #0xe1
0x00136a:	movs    	r2, #0x52
0x00136c:	adds    	r3, r5, #0
0x00136e:	adds    	r0, r6, #0
0x001370:	bl      	#0x39a8
0x001374:	movs    	r1, #0
0x001376:	movs    	r2, #0
0x001378:	str     	r2, [sp, #8]
0x00137a:	str     	r1, [sp]
0x00137c:	str     	r1, [sp, #4]
0x00137e:	movs    	r1, #0x92
0x001380:	adds    	r2, r0, #0
0x001382:	adds    	r0, r6, #0
0x001384:	ldr     	r3, [r7, #8]
0x001386:	bl      	#0x39a8
0x00138a:	movs    	r1, #0
0x00138c:	str     	r1, [sp]
0x00138e:	str     	r1, [sp, #4]
0x001390:	movs    	r2, #0
0x001392:	str     	r2, [sp, #8]
0x001394:	movs    	r3, #0xc
0x001396:	ldrsh   	r2, [r0, r3]
0x001398:	adds    	r3, r0, #0
0x00139a:	movs    	r1, #0x8b
0x00139c:	adds    	r0, r6, #0
0x00139e:	bl      	#0x39a8
0x0013a2:	movs    	r2, #0
0x0013a4:	adds    	r3, r0, #0
0x0013a6:	movs    	r1, #0
0x0013a8:	str     	r2, [sp, #8]
0x0013aa:	ldr     	r2, [pc, #0x130]
0x0013ac:	str     	r1, [sp]
0x0013ae:	str     	r1, [sp, #4]
0x0013b0:	add     	r2, pc
0x0013b2:	movs    	r1, #0x2d
0x0013b4:	adds    	r0, r6, #0
0x0013b6:	bl      	#0x39a8
0x0013ba:	movs    	r2, #0
0x0013bc:	movs    	r1, #0
0x0013be:	ldr     	r3, [pc, #0x120]
0x0013c0:	str     	r1, [sp]
0x0013c2:	str     	r1, [sp, #4]
0x0013c4:	str     	r2, [sp, #8]
0x0013c6:	add     	r3, pc
0x0013c8:	adds    	r2, r0, #0
0x0013ca:	movs    	r1, #0x2d
0x0013cc:	adds    	r0, r6, #0
0x0013ce:	bl      	#0x39a8
0x0013d2:	adds    	r4, r0, #0
0x0013d4:	b       	#0x13dc
0x0013d6:	ldr     	r0, [pc, #0x10c]
0x0013d8:	add     	r0, sb
0x0013da:	str     	r5, [r0, #4]
0x0013dc:	movs    	r1, #0
0x0013de:	str     	r1, [sp]
0x0013e0:	str     	r1, [sp, #4]
0x0013e2:	movs    	r2, #0
0x0013e4:	movs    	r1, #0xc2
0x0013e6:	adds    	r3, r5, #0
0x0013e8:	adds    	r0, r6, #0
0x0013ea:	str     	r2, [sp, #8]
0x0013ec:	bl      	#0x39a8
0x0013f0:	ldr     	r0, [r7, #8]
0x0013f2:	adds    	r3, r0, #1
0x0013f4:	beq     	#0x1488
0x0013f6:	movs    	r1, #0
0x0013f8:	movs    	r2, #0
0x0013fa:	str     	r2, [sp, #8]
0x0013fc:	str     	r1, [sp]
0x0013fe:	str     	r1, [sp, #4]
0x001400:	movs    	r1, #0xe1
0x001402:	movs    	r2, #0x74
0x001404:	adds    	r3, r5, #0
0x001406:	adds    	r0, r6, #0
0x001408:	bl      	#0x39a8
0x00140c:	movs    	r2, #0
0x00140e:	str     	r2, [sp, #8]
0x001410:	movs    	r1, #0
0x001412:	adds    	r2, r0, #0
0x001414:	movs    	r0, #0xf1
0x001416:	str     	r1, [sp]
0x001418:	str     	r1, [sp, #4]
0x00141a:	movs    	r1, #0xbe
0x00141c:	lsls    	r0, r0, #9
0x00141e:	adds    	r3, r5, #0
0x001420:	bl      	#0x39a8
0x001424:	movs    	r2, #0
0x001426:	movs    	r1, #0
0x001428:	ldr     	r3, [pc, #0xbc]
0x00142a:	str     	r1, [sp]
0x00142c:	str     	r1, [sp, #4]
0x00142e:	str     	r2, [sp, #8]
0x001430:	add     	r3, pc
0x001432:	adds    	r2, r4, #0
0x001434:	movs    	r1, #0x35
0x001436:	movs    	r0, #0xf1
0x001438:	lsls    	r0, r0, #9
0x00143a:	bl      	#0x39a8
0x00143e:	movs    	r1, #0
0x001440:	adds    	r4, r0, #0
0x001442:	movs    	r2, #0
0x001444:	str     	r2, [sp, #8]
0x001446:	str     	r1, [sp]
0x001448:	str     	r1, [sp, #4]
0x00144a:	movs    	r1, #0xe1
0x00144c:	movs    	r2, #0xda
0x00144e:	movs    	r0, #0xf1
0x001450:	adds    	r3, r5, #0
0x001452:	lsls    	r0, r0, #9
0x001454:	bl      	#0x39a8
0x001458:	movs    	r2, #0
0x00145a:	str     	r2, [sp, #8]
0x00145c:	movs    	r1, #0
0x00145e:	adds    	r2, r0, #0
0x001460:	movs    	r0, #0xf1
0x001462:	str     	r1, [sp]
0x001464:	str     	r1, [sp, #4]
0x001466:	movs    	r1, #0x36
0x001468:	lsls    	r0, r0, #9
0x00146a:	adds    	r3, r4, #0
0x00146c:	bl      	#0x39a8
0x001470:	movs    	r1, #0
0x001472:	str     	r1, [sp]
0x001474:	str     	r1, [sp, #4]
0x001476:	movs    	r2, #0

; ===== candidate_0014f0 =====
0x0014f0:	push    	{r4, r5, r6, r7, lr}
0x0014f2:	sub     	sp, #0xc
0x0014f4:	movs    	r1, #0
0x0014f6:	adds    	r5, r0, #0
0x0014f8:	str     	r1, [sp]
0x0014fa:	str     	r1, [sp, #4]
0x0014fc:	movs    	r7, #0
0x0014fe:	movs    	r2, #0
0x001500:	adds    	r3, r7, #0
0x001502:	movs    	r1, #0x13
0x001504:	movs    	r0, #0xf1
0x001506:	movs    	r4, #0
0x001508:	lsls    	r0, r0, #9
0x00150a:	str     	r2, [sp, #8]
0x00150c:	bl      	#0x39a8
0x001510:	movs    	r1, #0
0x001512:	adds    	r6, r0, #0
0x001514:	movs    	r2, #0
0x001516:	str     	r2, [sp, #8]
0x001518:	str     	r1, [sp]
0x00151a:	str     	r1, [sp, #4]
0x00151c:	movs    	r1, #0xe1
0x00151e:	movs    	r2, #0x52
0x001520:	movs    	r0, #0xf1
0x001522:	adds    	r3, r7, #0
0x001524:	lsls    	r0, r0, #9
0x001526:	bl      	#0x39a8
0x00152a:	ldr     	r1, [pc, #0xf0]
0x00152c:	movs    	r2, #0
0x00152e:	add     	r1, sb
0x001530:	str     	r0, [r1, #0x14]
0x001532:	movs    	r1, #0
0x001534:	str     	r1, [sp]
0x001536:	str     	r1, [sp, #4]
0x001538:	str     	r2, [sp, #8]
0x00153a:	movs    	r2, #0x52
0x00153c:	movs    	r1, #0x14
0x00153e:	movs    	r0, #0xf1
0x001540:	adds    	r3, r6, #0
0x001542:	lsls    	r0, r0, #9
0x001544:	bl      	#0x39a8
0x001548:	movs    	r1, #0
0x00154a:	movs    	r2, #0
0x00154c:	str     	r2, [sp, #8]
0x00154e:	str     	r1, [sp]
0x001550:	str     	r1, [sp, #4]
0x001552:	adds    	r3, r7, #0
0x001554:	adds    	r2, r5, #0
0x001556:	movs    	r1, #0x44
0x001558:	movs    	r0, #0xf1
0x00155a:	lsls    	r0, r0, #9
0x00155c:	bl      	#0x39a8
0x001560:	movs    	r1, #0
0x001562:	str     	r1, [sp]
0x001564:	str     	r1, [sp, #4]
0x001566:	movs    	r2, #0
0x001568:	str     	r2, [sp, #8]
0x00156a:	movs    	r1, #0x45
0x00156c:	adds    	r3, r7, #0
0x00156e:	movs    	r0, #0xf1
0x001570:	lsls    	r0, r0, #9
0x001572:	ldr     	r2, [r5, #8]
0x001574:	bl      	#0x39a8
0x001578:	movs    	r1, #0
0x00157a:	movs    	r2, #0
0x00157c:	str     	r2, [sp, #8]
0x00157e:	str     	r1, [sp]
0x001580:	str     	r1, [sp, #4]
0x001582:	adds    	r3, r0, #0
0x001584:	movs    	r0, #0xf1
0x001586:	movs    	r1, #0x14
0x001588:	movs    	r2, #0xd2
0x00158a:	lsls    	r0, r0, #9
0x00158c:	bl      	#0x39a8
0x001590:	movs    	r1, #0
0x001592:	str     	r1, [sp]
0x001594:	str     	r1, [sp, #4]
0x001596:	movs    	r2, #0
0x001598:	str     	r2, [sp, #8]
0x00159a:	movs    	r1, #0x45
0x00159c:	adds    	r3, r7, #0
0x00159e:	movs    	r0, #0xf1
0x0015a0:	lsls    	r0, r0, #9
0x0015a2:	ldr     	r2, [r5, #8]
0x0015a4:	bl      	#0x39a8
0x0015a8:	adds    	r6, r0, #0
0x0015aa:	cmp     	r0, #0
0x0015ac:	ble     	#0x15fe
0x0015ae:	movs    	r1, #0
0x0015b0:	movs    	r2, #0
0x0015b2:	str     	r2, [sp, #8]
0x0015b4:	str     	r1, [sp]
0x0015b6:	str     	r1, [sp, #4]
0x0015b8:	movs    	r1, #0x91
0x0015ba:	adds    	r2, r5, #0
0x0015bc:	movs    	r3, #0
0x0015be:	movs    	r0, #0xf1
0x0015c0:	lsls    	r0, r0, #9
0x0015c2:	bl      	#0x39a8
0x0015c6:	movs    	r1, #0
0x0015c8:	movs    	r2, #0
0x0015ca:	str     	r2, [sp, #8]
0x0015cc:	str     	r1, [sp]
0x0015ce:	str     	r1, [sp, #4]
0x0015d0:	adds    	r7, r0, #0
0x0015d2:	movs    	r0, #0xf1
0x0015d4:	movs    	r1, #0xe1
0x0015d6:	movs    	r2, #0x52
0x0015d8:	movs    	r3, #0
0x0015da:	lsls    	r0, r0, #9
0x0015dc:	bl      	#0x39a8
0x0015e0:	movs    	r2, #0
0x0015e2:	str     	r2, [sp, #8]
0x0015e4:	movs    	r1, #0
0x0015e6:	adds    	r2, r0, #0
0x0015e8:	movs    	r0, #0xf1
0x0015ea:	str     	r1, [sp]
0x0015ec:	str     	r1, [sp, #4]
0x0015ee:	movs    	r1, #0x36
0x0015f0:	lsls    	r0, r0, #9
0x0015f2:	adds    	r3, r7, #0
0x0015f4:	bl      	#0x39a8
0x0015f8:	adds    	r4, #1
0x0015fa:	cmp     	r4, r6
0x0015fc:	blt     	#0x15ae
0x0015fe:	movs    	r1, #0
0x001600:	str     	r1, [sp]
0x001602:	str     	r1, [sp, #4]
0x001604:	movs    	r2, #0
0x001606:	movs    	r1, #0x2c
0x001608:	movs    	r3, #0
0x00160a:	movs    	r0, #0xf1
0x00160c:	lsls    	r0, r0, #9
0x00160e:	str     	r2, [sp, #8]
0x001610:	bl      	#0x39a8
0x001614:	bl      	#0x30d0
0x001618:	add     	sp, #0xc
0x00161a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_001620 =====
0x001620:	push    	{r4, r5, r6, r7, lr}
0x001622:	sub     	sp, #0xc
0x001624:	movs    	r6, #0
0x001626:	movs    	r2, #0
0x001628:	movs    	r1, #0
0x00162a:	str     	r2, [sp, #8]
0x00162c:	adds    	r3, r6, #0
0x00162e:	adds    	r5, r0, #0
0x001630:	adds    	r2, r0, #0
0x001632:	str     	r1, [sp]
0x001634:	str     	r1, [sp, #4]
0x001636:	movs    	r1, #0x44
0x001638:	movs    	r0, #0xf1
0x00163a:	movs    	r4, #0
0x00163c:	lsls    	r0, r0, #9
0x00163e:	bl      	#0x39a8
0x001642:	movs    	r1, #0
0x001644:	str     	r1, [sp]
0x001646:	str     	r1, [sp, #4]
0x001648:	movs    	r2, #0
0x00164a:	str     	r2, [sp, #8]
0x00164c:	movs    	r1, #0x46
0x00164e:	adds    	r3, r6, #0
0x001650:	movs    	r0, #0xf1
0x001652:	lsls    	r0, r0, #9
0x001654:	ldr     	r2, [r5, #8]
0x001656:	bl      	#0x39a8
0x00165a:	lsls    	r6, r0, #0x18
0x00165c:	asrs    	r6, r6, #0x18
0x00165e:	cmp     	r6, #0
0x001660:	ble     	#0x1698
0x001662:	movs    	r1, #0
0x001664:	movs    	r2, #0
0x001666:	str     	r2, [sp, #8]
0x001668:	str     	r1, [sp]
0x00166a:	str     	r1, [sp, #4]
0x00166c:	movs    	r1, #0xa8
0x00166e:	adds    	r2, r5, #0
0x001670:	movs    	r3, #0
0x001672:	movs    	r0, #0xf1
0x001674:	lsls    	r0, r0, #9
0x001676:	bl      	#0x39a8
0x00167a:	movs    	r2, #0
0x00167c:	movs    	r1, #0
0x00167e:	str     	r2, [sp, #8]
0x001680:	adds    	r2, r0, #0
0x001682:	str     	r1, [sp]
0x001684:	str     	r1, [sp, #4]
0x001686:	movs    	r1, #0xa9
0x001688:	movs    	r0, #0xf1
0x00168a:	movs    	r3, #1
0x00168c:	lsls    	r0, r0, #9
0x00168e:	bl      	#0x39a8
0x001692:	adds    	r4, #1
0x001694:	cmp     	r4, r6
0x001696:	blt     	#0x1662
0x001698:	bl      	#0x437c
0x00169c:	movs    	r1, #0
0x00169e:	str     	r1, [sp]
0x0016a0:	str     	r1, [sp, #4]
0x0016a2:	movs    	r1, #0xff
0x0016a4:	movs    	r2, #0
0x0016a6:	adds    	r1, #0x11
0x0016a8:	movs    	r3, #0
0x0016aa:	movs    	r0, #0xf1
0x0016ac:	lsls    	r0, r0, #9
0x0016ae:	str     	r2, [sp, #8]
0x0016b0:	bl      	#0x39a8
0x0016b4:	add     	sp, #0xc
0x0016b6:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0016b8 =====
0x0016b8:	push    	{r4, r5, r6, r7, lr}
0x0016ba:	adds    	r4, r0, #0
0x0016bc:	ldr     	r0, [pc, #0x3b0]
0x0016be:	sub     	sp, #0xc
0x0016c0:	add     	r0, sb
0x0016c2:	str     	r4, [r0, #4]
0x0016c4:	movs    	r1, #0
0x0016c6:	strb    	r1, [r0]
0x0016c8:	ldr     	r0, [r0, #0x10]
0x0016ca:	cmp     	r0, #6
0x0016cc:	bhs     	#0x16d8
0x0016ce:	adr     	r3, #0xc
0x0016d0:	adds    	r3, r3, r0
0x0016d2:	ldrh    	r3, [r3, r0]
0x0016d4:	lsls    	r3, r3, #1
0x0016d6:	add     	pc, r3
0x0016d8:	add     	sp, #0xc
0x0016da:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_001a88 =====
0x001a88:	push    	{r4, r5, r6, r7, lr}
0x001a8a:	sub     	sp, #0x14
0x001a8c:	movs    	r6, #0
0x001a8e:	movs    	r2, #0
0x001a90:	movs    	r1, #0
0x001a92:	str     	r2, [sp, #8]
0x001a94:	adds    	r3, r6, #0
0x001a96:	adds    	r5, r0, #0
0x001a98:	adds    	r2, r0, #0
0x001a9a:	str     	r1, [sp]
0x001a9c:	str     	r1, [sp, #4]
0x001a9e:	movs    	r1, #0x44
0x001aa0:	movs    	r0, #0xf1
0x001aa2:	movs    	r4, #0
0x001aa4:	lsls    	r0, r0, #9
0x001aa6:	bl      	#0x39a8
0x001aaa:	movs    	r1, #0
0x001aac:	str     	r1, [sp]
0x001aae:	str     	r1, [sp, #4]
0x001ab0:	movs    	r2, #0
0x001ab2:	str     	r2, [sp, #8]
0x001ab4:	movs    	r1, #0x45
0x001ab6:	adds    	r3, r6, #0
0x001ab8:	movs    	r0, #0xf1
0x001aba:	lsls    	r0, r0, #9
0x001abc:	ldr     	r2, [r5, #8]
0x001abe:	bl      	#0x39a8
0x001ac2:	movs    	r1, #0
0x001ac4:	adds    	r7, r0, #0
0x001ac6:	movs    	r2, #0
0x001ac8:	str     	r2, [sp, #8]
0x001aca:	str     	r1, [sp]
0x001acc:	str     	r1, [sp, #4]
0x001ace:	movs    	r1, #0xe1
0x001ad0:	movs    	r2, #0x52
0x001ad2:	movs    	r0, #0xf1
0x001ad4:	adds    	r3, r6, #0
0x001ad6:	lsls    	r0, r0, #9
0x001ad8:	bl      	#0x39a8
0x001adc:	movs    	r2, #0
0x001ade:	str     	r2, [sp, #8]
0x001ae0:	movs    	r1, #0
0x001ae2:	adds    	r2, r0, #0
0x001ae4:	movs    	r0, #0xf1
0x001ae6:	str     	r1, [sp]
0x001ae8:	str     	r1, [sp, #4]
0x001aea:	movs    	r1, #0x92
0x001aec:	lsls    	r0, r0, #9
0x001aee:	adds    	r3, r7, #0
0x001af0:	bl      	#0x39a8
0x001af4:	movs    	r1, #0
0x001af6:	str     	r1, [sp]
0x001af8:	str     	r1, [sp, #4]
0x001afa:	str     	r0, [sp, #0x10]
0x001afc:	movs    	r2, #0
0x001afe:	str     	r2, [sp, #8]
0x001b00:	movs    	r0, #0xf1
0x001b02:	movs    	r1, #0x45
0x001b04:	adds    	r3, r6, #0
0x001b06:	lsls    	r0, r0, #9
0x001b08:	ldr     	r2, [r5, #8]
0x001b0a:	bl      	#0x39a8
0x001b0e:	adds    	r6, r0, #0
0x001b10:	cmp     	r0, #0
0x001b12:	ble     	#0x1b4a
0x001b14:	movs    	r1, #0
0x001b16:	movs    	r2, #0
0x001b18:	str     	r2, [sp, #8]
0x001b1a:	str     	r1, [sp]
0x001b1c:	str     	r1, [sp, #4]
0x001b1e:	movs    	r1, #0xa8
0x001b20:	adds    	r2, r5, #0
0x001b22:	movs    	r3, #0
0x001b24:	movs    	r0, #0xf1
0x001b26:	lsls    	r0, r0, #9
0x001b28:	bl      	#0x39a8
0x001b2c:	movs    	r2, #0
0x001b2e:	movs    	r1, #0
0x001b30:	str     	r2, [sp, #8]
0x001b32:	adds    	r2, r0, #0
0x001b34:	str     	r1, [sp]
0x001b36:	str     	r1, [sp, #4]
0x001b38:	movs    	r1, #0xa9
0x001b3a:	movs    	r0, #0xf1
0x001b3c:	movs    	r3, #1
0x001b3e:	lsls    	r0, r0, #9
0x001b40:	bl      	#0x39a8
0x001b44:	adds    	r4, #1
0x001b46:	cmp     	r4, r6
0x001b48:	blt     	#0x1b14
0x001b4a:	movs    	r1, #0
0x001b4c:	movs    	r2, #0
0x001b4e:	str     	r2, [sp, #8]
0x001b50:	str     	r1, [sp]
0x001b52:	str     	r1, [sp, #4]
0x001b54:	movs    	r4, #0xf1
0x001b56:	lsls    	r4, r4, #9
0x001b58:	movs    	r1, #0x91
0x001b5a:	adds    	r2, r5, #0
0x001b5c:	adds    	r0, r4, #0
0x001b5e:	ldr     	r3, [sp, #0x10]
0x001b60:	bl      	#0x39a8
0x001b64:	movs    	r1, #0
0x001b66:	str     	r1, [sp]
0x001b68:	str     	r1, [sp, #4]
0x001b6a:	movs    	r2, #0
0x001b6c:	movs    	r1, #0xff
0x001b6e:	movs    	r6, #0
0x001b70:	adds    	r3, r6, #0
0x001b72:	adds    	r1, #0x14
0x001b74:	str     	r2, [sp, #8]
0x001b76:	ldr     	r2, [sp, #0x10]
0x001b78:	adds    	r0, r4, #0
0x001b7a:	bl      	#0x39a8
0x001b7e:	movs    	r1, #0
0x001b80:	movs    	r2, #0
0x001b82:	str     	r2, [sp, #8]
0x001b84:	str     	r1, [sp]
0x001b86:	str     	r1, [sp, #4]
0x001b88:	movs    	r1, #0xe1
0x001b8a:	movs    	r2, #0xd8
0x001b8c:	adds    	r3, r6, #0
0x001b8e:	adds    	r0, r4, #0
0x001b90:	bl      	#0x39a8
0x001b94:	cmp     	r0, #0
0x001b96:	bne     	#0x1bb0
0x001b98:	movs    	r2, #0
0x001b9a:	movs    	r1, #0
0x001b9c:	str     	r2, [sp, #8]
0x001b9e:	ldr     	r2, [pc, #0x14]
0x001ba0:	str     	r1, [sp]
0x001ba2:	str     	r1, [sp, #4]
0x001ba4:	adds    	r3, r6, #0
0x001ba6:	add     	r2, pc
0x001ba8:	movs    	r1, #0x33
0x001baa:	adds    	r0, r4, #0
0x001bac:	bl      	#0x39a8
0x001bb0:	add     	sp, #0x14
0x001bb2:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_001bb8 =====
0x001bb8:	push    	{r4, r5, r6, r7, lr}
0x001bba:	sub     	sp, #0xc
0x001bbc:	movs    	r4, #0
0x001bbe:	movs    	r2, #0
0x001bc0:	movs    	r1, #0
0x001bc2:	str     	r2, [sp, #8]
0x001bc4:	adds    	r3, r4, #0
0x001bc6:	adds    	r6, r0, #0
0x001bc8:	adds    	r2, r0, #0
0x001bca:	str     	r1, [sp]
0x001bcc:	str     	r1, [sp, #4]
0x001bce:	movs    	r1, #0x44
0x001bd0:	movs    	r0, #0xf1
0x001bd2:	movs    	r5, #0
0x001bd4:	lsls    	r0, r0, #9
0x001bd6:	bl      	#0x39a8
0x001bda:	movs    	r1, #0
0x001bdc:	str     	r1, [sp]
0x001bde:	str     	r1, [sp, #4]
0x001be0:	movs    	r2, #0
0x001be2:	str     	r2, [sp, #8]
0x001be4:	movs    	r1, #0x45
0x001be6:	adds    	r3, r4, #0
0x001be8:	movs    	r0, #0xf1
0x001bea:	lsls    	r0, r0, #9
0x001bec:	ldr     	r2, [r6, #8]
0x001bee:	bl      	#0x39a8
0x001bf2:	movs    	r1, #0
0x001bf4:	adds    	r7, r0, #0
0x001bf6:	movs    	r2, #0
0x001bf8:	str     	r2, [sp, #8]
0x001bfa:	str     	r1, [sp]
0x001bfc:	str     	r1, [sp, #4]
0x001bfe:	movs    	r1, #0xe1
0x001c00:	movs    	r2, #0x52
0x001c02:	movs    	r0, #0xf1
0x001c04:	adds    	r3, r4, #0
0x001c06:	lsls    	r0, r0, #9
0x001c08:	bl      	#0x39a8
0x001c0c:	movs    	r2, #0
0x001c0e:	str     	r2, [sp, #8]
0x001c10:	movs    	r1, #0
0x001c12:	adds    	r2, r0, #0
0x001c14:	movs    	r0, #0xf1
0x001c16:	str     	r1, [sp]
0x001c18:	str     	r1, [sp, #4]
0x001c1a:	movs    	r1, #0x92
0x001c1c:	lsls    	r0, r0, #9
0x001c1e:	adds    	r3, r7, #0
0x001c20:	bl      	#0x39a8
0x001c24:	movs    	r1, #0
0x001c26:	adds    	r3, r0, #0
0x001c28:	movs    	r2, #0
0x001c2a:	str     	r2, [sp, #8]
0x001c2c:	str     	r1, [sp]
0x001c2e:	str     	r1, [sp, #4]
0x001c30:	movs    	r1, #0x91
0x001c32:	adds    	r2, r6, #0
0x001c34:	movs    	r0, #0xf1
0x001c36:	lsls    	r0, r0, #9
0x001c38:	bl      	#0x39a8
0x001c3c:	ldr     	r0, [pc, #0x11c]
0x001c3e:	movs    	r1, #0
0x001c40:	add     	r0, sb
0x001c42:	str     	r4, [r0, #8]
0x001c44:	str     	r1, [sp]
0x001c46:	str     	r1, [sp, #4]
0x001c48:	movs    	r2, #0
0x001c4a:	str     	r2, [sp, #8]
0x001c4c:	movs    	r1, #0x45
0x001c4e:	movs    	r0, #0xf1
0x001c50:	adds    	r3, r4, #0
0x001c52:	lsls    	r0, r0, #9
0x001c54:	ldr     	r2, [r6, #8]
0x001c56:	bl      	#0x39a8
0x001c5a:	adds    	r7, r0, #0
0x001c5c:	cmp     	r0, #0
0x001c5e:	ble     	#0x1cd8
0x001c60:	movs    	r1, #0
0x001c62:	str     	r1, [sp]
0x001c64:	str     	r1, [sp, #4]
0x001c66:	movs    	r2, #0
0x001c68:	str     	r2, [sp, #8]
0x001c6a:	movs    	r1, #0x45
0x001c6c:	movs    	r3, #0
0x001c6e:	movs    	r0, #0xf1
0x001c70:	lsls    	r0, r0, #9
0x001c72:	ldr     	r2, [r6, #8]
0x001c74:	bl      	#0x39a8
0x001c78:	movs    	r2, #0
0x001c7a:	movs    	r1, #0
0x001c7c:	str     	r2, [sp, #8]
0x001c7e:	adds    	r2, r0, #0
0x001c80:	str     	r1, [sp]
0x001c82:	str     	r1, [sp, #4]
0x001c84:	movs    	r1, #0x90
0x001c86:	movs    	r0, #0xf1
0x001c88:	movs    	r3, #0
0x001c8a:	lsls    	r0, r0, #9
0x001c8c:	bl      	#0x39a8
0x001c90:	adds    	r4, r0, #0
0x001c92:	beq     	#0x1cd2
0x001c94:	ldrh    	r0, [r4, #8]
0x001c96:	subs    	r0, #1
0x001c98:	lsls    	r0, r0, #0x10
0x001c9a:	asrs    	r0, r0, #0x10
0x001c9c:	strh    	r0, [r4, #8]
0x001c9e:	cmp     	r0, #0
0x001ca0:	bgt     	#0x1cd2
0x001ca2:	movs    	r1, #0
0x001ca4:	movs    	r2, #0
0x001ca6:	str     	r2, [sp, #8]
0x001ca8:	str     	r1, [sp]
0x001caa:	str     	r1, [sp, #4]
0x001cac:	movs    	r1, #0x8f
0x001cae:	adds    	r2, r4, #0
0x001cb0:	movs    	r3, #0
0x001cb2:	movs    	r0, #0xf1
0x001cb4:	lsls    	r0, r0, #9
0x001cb6:	bl      	#0x39a8
0x001cba:	movs    	r1, #0
0x001cbc:	movs    	r2, #0
0x001cbe:	str     	r2, [sp, #8]
0x001cc0:	str     	r1, [sp]
0x001cc2:	str     	r1, [sp, #4]
0x001cc4:	movs    	r1, #0x8e
0x001cc6:	adds    	r2, r4, #0
0x001cc8:	movs    	r3, #0
0x001cca:	movs    	r0, #0xf1
0x001ccc:	lsls    	r0, r0, #9
0x001cce:	bl      	#0x39a8
0x001cd2:	adds    	r5, #1
0x001cd4:	cmp     	r5, r7
0x001cd6:	blt     	#0x1c60
0x001cd8:	ldr     	r1, [pc, #0x80]
0x001cda:	add     	r1, sb
0x001cdc:	ldr     	r0, [r1, #0xc]
0x001cde:	cmp     	r0, #0
0x001ce0:	ble     	#0x1d08
0x001ce2:	subs    	r0, #1
0x001ce4:	str     	r0, [r1, #0xc]

; ===== candidate_001d6c =====
0x001d6c:	push    	{r4, r5, r6, r7, lr}
0x001d6e:	sub     	sp, #0x34
0x001d70:	movs    	r1, #0
0x001d72:	movs    	r2, #0
0x001d74:	str     	r2, [sp, #8]
0x001d76:	str     	r1, [sp]
0x001d78:	str     	r1, [sp, #4]
0x001d7a:	movs    	r4, #0
0x001d7c:	adds    	r3, r4, #0
0x001d7e:	movs    	r1, #0xe1
0x001d80:	movs    	r2, #0x2a
0x001d82:	movs    	r0, #0xf1
0x001d84:	lsls    	r0, r0, #9
0x001d86:	bl      	#0x39a8
0x001d8a:	movs    	r1, #0
0x001d8c:	movs    	r2, #0
0x001d8e:	str     	r2, [sp, #8]
0x001d90:	str     	r1, [sp]
0x001d92:	str     	r1, [sp, #4]
0x001d94:	movs    	r1, #0xe1
0x001d96:	movs    	r2, #0xdb
0x001d98:	adds    	r3, r4, #0
0x001d9a:	movs    	r0, #0xf1
0x001d9c:	lsls    	r0, r0, #9
0x001d9e:	bl      	#0x39a8
0x001da2:	movs    	r2, #0
0x001da4:	movs    	r1, #0
0x001da6:	str     	r2, [sp, #8]
0x001da8:	adds    	r2, r0, #0
0x001daa:	str     	r1, [sp]
0x001dac:	str     	r1, [sp, #4]
0x001dae:	movs    	r1, #0xff
0x001db0:	adds    	r3, r4, #0
0x001db2:	adds    	r1, #0x10
0x001db4:	movs    	r0, #0xf1
0x001db6:	lsls    	r0, r0, #9
0x001db8:	bl      	#0x39a8
0x001dbc:	movs    	r1, #0
0x001dbe:	adds    	r6, r0, #0
0x001dc0:	movs    	r2, #0
0x001dc2:	str     	r2, [sp, #8]
0x001dc4:	str     	r1, [sp]
0x001dc6:	str     	r1, [sp, #4]
0x001dc8:	movs    	r1, #0xe1
0x001dca:	movs    	r2, #0x28
0x001dcc:	movs    	r0, #0xf1
0x001dce:	adds    	r3, r4, #0
0x001dd0:	lsls    	r0, r0, #9
0x001dd2:	bl      	#0x39a8
0x001dd6:	movs    	r1, #0
0x001dd8:	adds    	r5, r0, #0
0x001dda:	movs    	r2, #0
0x001ddc:	str     	r2, [sp, #8]
0x001dde:	str     	r1, [sp]
0x001de0:	str     	r1, [sp, #4]
0x001de2:	movs    	r1, #0xe1
0x001de4:	movs    	r2, #0x29
0x001de6:	movs    	r0, #0xf1
0x001de8:	adds    	r3, r4, #0
0x001dea:	lsls    	r0, r0, #9
0x001dec:	bl      	#0x39a8
0x001df0:	movs    	r1, #0
0x001df2:	adds    	r7, r0, #0
0x001df4:	movs    	r2, #0
0x001df6:	str     	r2, [sp, #8]
0x001df8:	str     	r1, [sp]
0x001dfa:	str     	r1, [sp, #4]
0x001dfc:	movs    	r1, #0xe1
0x001dfe:	movs    	r2, #0xdb
0x001e00:	movs    	r0, #0xf1
0x001e02:	adds    	r3, r4, #0
0x001e04:	lsls    	r0, r0, #9
0x001e06:	bl      	#0x39a8
0x001e0a:	lsls    	r1, r6, #2
0x001e0c:	ldr     	r6, [r0, r1]
0x001e0e:	add     	r1, sp, #0x30
0x001e10:	add     	r2, sp, #0x2c
0x001e12:	str     	r2, [sp, #8]
0x001e14:	str     	r1, [sp, #4]
0x001e16:	adds    	r3, r7, #0
0x001e18:	adds    	r2, r6, #0
0x001e1a:	movs    	r1, #0x2a
0x001e1c:	movs    	r0, #0xf1
0x001e1e:	lsls    	r0, r0, #9
0x001e20:	str     	r5, [sp]
0x001e22:	bl      	#0x39a8
0x001e26:	ldr     	r5, [sp, #0x30]
0x001e28:	movs    	r1, #0
0x001e2a:	movs    	r2, #0
0x001e2c:	str     	r2, [sp, #8]
0x001e2e:	str     	r1, [sp]
0x001e30:	str     	r1, [sp, #4]
0x001e32:	adds    	r5, #0x28
0x001e34:	adds    	r3, r4, #0
0x001e36:	movs    	r1, #0xe1
0x001e38:	movs    	r2, #0xdb
0x001e3a:	movs    	r0, #0xf1
0x001e3c:	lsls    	r0, r0, #9
0x001e3e:	bl      	#0x39a8
0x001e42:	movs    	r2, #0
0x001e44:	movs    	r1, #0
0x001e46:	str     	r2, [sp, #8]
0x001e48:	adds    	r2, r0, #0
0x001e4a:	str     	r1, [sp]
0x001e4c:	str     	r1, [sp, #4]
0x001e4e:	movs    	r1, #0x11
0x001e50:	movs    	r0, #0xf1
0x001e52:	movs    	r3, #4
0x001e54:	lsls    	r0, r0, #9
0x001e56:	bl      	#0x39a8
0x001e5a:	movs    	r1, #0
0x001e5c:	adds    	r6, r0, #0
0x001e5e:	movs    	r2, #0
0x001e60:	str     	r2, [sp, #8]
0x001e62:	str     	r1, [sp]
0x001e64:	str     	r1, [sp, #4]
0x001e66:	movs    	r1, #0xe1
0x001e68:	movs    	r2, #0x2e
0x001e6a:	movs    	r0, #0xf1
0x001e6c:	adds    	r3, r4, #0
0x001e6e:	lsls    	r0, r0, #9
0x001e70:	bl      	#0x39a8
0x001e74:	adds    	r1, r0, #0
0x001e76:	muls    	r6, r1, r6
0x001e78:	movs    	r1, #0
0x001e7a:	adds    	r0, r6, #0
0x001e7c:	adds    	r6, r0, #0
0x001e7e:	adds    	r6, #0xa
0x001e80:	str     	r1, [sp]
0x001e82:	str     	r1, [sp, #4]
0x001e84:	movs    	r2, #0
0x001e86:	movs    	r1, #0x1c
0x001e88:	adds    	r3, r4, #0
0x001e8a:	movs    	r0, #0xf1
0x001e8c:	lsls    	r0, r0, #9
0x001e8e:	str     	r2, [sp, #8]
0x001e90:	bl      	#0x39a8
0x001e94:	subs    	r0, r0, r5
0x001e96:	lsrs    	r1, r0, #0x1f
0x001e98:	adds    	r0, r1, r0
0x001e9a:	movs    	r1, #0

; ===== candidate_001f30 =====
0x001f30:	push    	{r4, r5, r6, r7, lr}
0x001f32:	sub     	sp, #0x64
0x001f34:	movs    	r1, #0
0x001f36:	movs    	r2, #0
0x001f38:	str     	r2, [sp, #8]
0x001f3a:	str     	r1, [sp]
0x001f3c:	str     	r1, [sp, #4]
0x001f3e:	movs    	r6, #0xf1
0x001f40:	movs    	r7, #0
0x001f42:	adds    	r3, r7, #0
0x001f44:	lsls    	r6, r6, #9
0x001f46:	movs    	r1, #0xe1
0x001f48:	movs    	r2, #0xed
0x001f4a:	movs    	r5, #0
0x001f4c:	movs    	r4, #0x19
0x001f4e:	adds    	r0, r6, #0
0x001f50:	bl      	#0x39a8
0x001f54:	cmp     	r0, #0
0x001f56:	ble     	#0x203e
0x001f58:	movs    	r1, #0
0x001f5a:	str     	r1, [sp]
0x001f5c:	str     	r1, [sp, #4]
0x001f5e:	movs    	r1, #0xff
0x001f60:	movs    	r2, #0
0x001f62:	adds    	r1, #0x25
0x001f64:	adds    	r3, r7, #0
0x001f66:	adds    	r0, r6, #0
0x001f68:	str     	r2, [sp, #8]
0x001f6a:	bl      	#0x39a8
0x001f6e:	movs    	r1, #0
0x001f70:	movs    	r2, #0
0x001f72:	str     	r2, [sp, #8]
0x001f74:	str     	r1, [sp]
0x001f76:	str     	r1, [sp, #4]
0x001f78:	movs    	r1, #0xe1
0x001f7a:	movs    	r2, #0x28
0x001f7c:	adds    	r3, r7, #0
0x001f7e:	adds    	r0, r6, #0
0x001f80:	bl      	#0x39a8
0x001f84:	movs    	r1, #0
0x001f86:	movs    	r2, #0
0x001f88:	str     	r2, [sp, #8]
0x001f8a:	str     	r1, [sp]
0x001f8c:	str     	r1, [sp, #4]
0x001f8e:	movs    	r1, #0xe1
0x001f90:	movs    	r2, #0x29
0x001f92:	str     	r0, [sp, #0x38]
0x001f94:	adds    	r3, r7, #0
0x001f96:	adds    	r0, r6, #0
0x001f98:	bl      	#0x39a8
0x001f9c:	adds    	r3, r0, #0
0x001f9e:	add     	r2, sp, #0x60
0x001fa0:	str     	r2, [sp, #8]
0x001fa2:	ldr     	r0, [sp, #0x38]
0x001fa4:	ldr     	r2, [pc, #0x3e0]
0x001fa6:	add     	r1, sp, #0x5c
0x001fa8:	str     	r1, [sp, #4]
0x001faa:	str     	r0, [sp]
0x001fac:	add     	r2, pc
0x001fae:	movs    	r1, #0x2a
0x001fb0:	adds    	r0, r6, #0
0x001fb2:	bl      	#0x39a8
0x001fb6:	movs    	r1, #0
0x001fb8:	movs    	r2, #0
0x001fba:	str     	r2, [sp, #8]
0x001fbc:	str     	r1, [sp]
0x001fbe:	str     	r1, [sp, #4]
0x001fc0:	movs    	r1, #0xe1
0x001fc2:	movs    	r2, #0x2a
0x001fc4:	adds    	r3, r7, #0
0x001fc6:	adds    	r0, r6, #0
0x001fc8:	bl      	#0x39a8
0x001fcc:	ldr     	r1, [sp, #0x60]
0x001fce:	movs    	r2, #0
0x001fd0:	adds    	r0, r0, r1
0x001fd2:	str     	r0, [sp, #0x58]
0x001fd4:	movs    	r1, #0
0x001fd6:	movs    	r0, #0
0x001fd8:	bl      	#0x3958
0x001fdc:	movs    	r1, #0
0x001fde:	movs    	r2, #0
0x001fe0:	str     	r2, [sp, #8]
0x001fe2:	str     	r1, [sp]
0x001fe4:	str     	r1, [sp, #4]
0x001fe6:	movs    	r1, #0xe1
0x001fe8:	movs    	r2, #0x52
0x001fea:	adds    	r3, r7, #0
0x001fec:	adds    	r0, r6, #0
0x001fee:	bl      	#0x39a8
0x001ff2:	movs    	r2, #0
0x001ff4:	movs    	r1, #0
0x001ff6:	str     	r2, [sp, #8]
0x001ff8:	adds    	r2, r0, #0
0x001ffa:	str     	r1, [sp]
0x001ffc:	str     	r1, [sp, #4]
0x001ffe:	movs    	r1, #0x26
0x002000:	adds    	r0, r6, #0
0x002002:	adds    	r3, r7, #0
0x002004:	bl      	#0x39a8
0x002008:	movs    	r1, #0
0x00200a:	movs    	r2, #0
0x00200c:	str     	r2, [sp, #8]
0x00200e:	str     	r1, [sp]
0x002010:	str     	r1, [sp, #4]
0x002012:	movs    	r1, #0xe1
0x002014:	movs    	r2, #0xde
0x002016:	str     	r0, [sp, #0x4c]
0x002018:	adds    	r3, r7, #0
0x00201a:	adds    	r0, r6, #0
0x00201c:	bl      	#0x39a8
0x002020:	ldr     	r1, [sp, #0x4c]
0x002022:	cmp     	r0, r1
0x002024:	bge     	#0x2070
0x002026:	movs    	r1, #0
0x002028:	movs    	r2, #0
0x00202a:	str     	r2, [sp, #8]
0x00202c:	str     	r1, [sp]
0x00202e:	str     	r1, [sp, #4]
0x002030:	movs    	r1, #0xe1
0x002032:	movs    	r2, #0xde
0x002034:	adds    	r3, r7, #0
0x002036:	adds    	r0, r6, #0
0x002038:	bl      	#0x39a8
0x00203c:	b       	#0x2040
0x00203e:	b       	#0x2798
0x002040:	movs    	r1, #0
0x002042:	movs    	r2, #0
0x002044:	str     	r2, [sp, #8]
0x002046:	str     	r1, [sp]
0x002048:	str     	r1, [sp, #4]
0x00204a:	movs    	r1, #0xe1
0x00204c:	movs    	r2, #0x52
0x00204e:	adds    	r5, r0, #0
0x002050:	adds    	r3, r7, #0
0x002052:	adds    	r0, r6, #0
0x002054:	bl      	#0x39a8
0x002058:	movs    	r2, #0
0x00205a:	movs    	r1, #0
0x00205c:	str     	r2, [sp, #8]
0x00205e:	adds    	r2, r0, #0
0x002060:	str     	r1, [sp]

; ===== candidate_00279c =====
0x00279c:	push    	{r4, r5, r6, r7, lr}
0x00279e:	sub     	sp, #0xc
0x0027a0:	movs    	r1, #0
0x0027a2:	movs    	r2, #0
0x0027a4:	str     	r2, [sp, #8]
0x0027a6:	str     	r1, [sp]
0x0027a8:	str     	r1, [sp, #4]
0x0027aa:	movs    	r7, #0xf1
0x0027ac:	movs    	r6, #0
0x0027ae:	adds    	r3, r6, #0
0x0027b0:	lsls    	r7, r7, #9
0x0027b2:	movs    	r1, #0xe1
0x0027b4:	movs    	r2, #0x52
0x0027b6:	adds    	r0, r7, #0
0x0027b8:	bl      	#0x39a8
0x0027bc:	movs    	r1, #0
0x0027be:	movs    	r2, #0
0x0027c0:	str     	r2, [sp, #8]
0x0027c2:	str     	r1, [sp]
0x0027c4:	str     	r1, [sp, #4]
0x0027c6:	movs    	r1, #0x26
0x0027c8:	adds    	r2, r0, #0
0x0027ca:	adds    	r3, r6, #0
0x0027cc:	adds    	r0, r7, #0
0x0027ce:	bl      	#0x39a8
0x0027d2:	movs    	r1, #0
0x0027d4:	str     	r1, [sp]
0x0027d6:	str     	r1, [sp, #4]
0x0027d8:	movs    	r2, #0
0x0027da:	movs    	r1, #0x2c
0x0027dc:	adds    	r5, r0, #0
0x0027de:	movs    	r4, #0
0x0027e0:	adds    	r3, r6, #0
0x0027e2:	adds    	r0, r7, #0
0x0027e4:	str     	r2, [sp, #8]
0x0027e6:	bl      	#0x39a8
0x0027ea:	cmp     	r5, #0
0x0027ec:	ble     	#0x283c
0x0027ee:	movs    	r1, #0
0x0027f0:	movs    	r2, #0
0x0027f2:	str     	r2, [sp, #8]
0x0027f4:	str     	r1, [sp]
0x0027f6:	str     	r1, [sp, #4]
0x0027f8:	movs    	r1, #0xe1
0x0027fa:	movs    	r2, #0x52
0x0027fc:	adds    	r3, r6, #0
0x0027fe:	adds    	r0, r7, #0
0x002800:	bl      	#0x39a8
0x002804:	movs    	r2, #0
0x002806:	str     	r2, [sp, #8]
0x002808:	movs    	r1, #0
0x00280a:	adds    	r2, r0, #0
0x00280c:	movs    	r0, #0xf1
0x00280e:	str     	r1, [sp]
0x002810:	str     	r1, [sp, #4]
0x002812:	movs    	r1, #0x27
0x002814:	lsls    	r0, r0, #9
0x002816:	adds    	r3, r4, #0
0x002818:	bl      	#0x39a8
0x00281c:	adds    	r3, r0, #0
0x00281e:	beq     	#0x2836
0x002820:	movs    	r1, #0
0x002822:	movs    	r2, #0
0x002824:	str     	r2, [sp, #8]
0x002826:	str     	r1, [sp]
0x002828:	str     	r1, [sp, #4]
0x00282a:	movs    	r1, #0x8c
0x00282c:	adds    	r2, r3, #0
0x00282e:	adds    	r0, r7, #0
0x002830:	adds    	r3, r6, #0
0x002832:	bl      	#0x39a8
0x002836:	adds    	r4, #1
0x002838:	cmp     	r4, r5
0x00283a:	blt     	#0x27ee
0x00283c:	movs    	r1, #0
0x00283e:	movs    	r2, #0
0x002840:	str     	r2, [sp, #8]
0x002842:	str     	r1, [sp]
0x002844:	str     	r1, [sp, #4]
0x002846:	movs    	r1, #0xe1
0x002848:	movs    	r2, #0x52
0x00284a:	adds    	r3, r6, #0
0x00284c:	adds    	r0, r7, #0
0x00284e:	bl      	#0x39a8
0x002852:	movs    	r2, #0
0x002854:	movs    	r1, #0
0x002856:	str     	r2, [sp, #8]
0x002858:	adds    	r3, r6, #0
0x00285a:	adds    	r2, r0, #0
0x00285c:	str     	r1, [sp]
0x00285e:	str     	r1, [sp, #4]
0x002860:	movs    	r1, #0x28
0x002862:	movs    	r0, #0xf1
0x002864:	lsls    	r0, r0, #9
0x002866:	bl      	#0x39a8
0x00286a:	movs    	r1, #0
0x00286c:	movs    	r2, #0
0x00286e:	str     	r2, [sp, #8]
0x002870:	str     	r1, [sp]
0x002872:	str     	r1, [sp, #4]
0x002874:	movs    	r1, #0xe1
0x002876:	movs    	r2, #0x52
0x002878:	adds    	r3, r6, #0
0x00287a:	movs    	r0, #0xf1
0x00287c:	lsls    	r0, r0, #9
0x00287e:	bl      	#0x39a8
0x002882:	movs    	r2, #0
0x002884:	movs    	r1, #0
0x002886:	str     	r2, [sp, #8]
0x002888:	adds    	r3, r6, #0
0x00288a:	adds    	r2, r0, #0
0x00288c:	str     	r1, [sp]
0x00288e:	str     	r1, [sp, #4]
0x002890:	movs    	r1, #9
0x002892:	movs    	r0, #0xf1
0x002894:	lsls    	r0, r0, #9
0x002896:	bl      	#0x39a8
0x00289a:	movs    	r1, #0
0x00289c:	movs    	r2, #0
0x00289e:	str     	r2, [sp, #8]
0x0028a0:	str     	r1, [sp]
0x0028a2:	str     	r1, [sp, #4]
0x0028a4:	ldr     	r4, [pc, #0x74]
0x0028a6:	movs    	r1, #0x14
0x0028a8:	movs    	r2, #0x52
0x0028aa:	movs    	r0, #0xf1
0x0028ac:	add     	r4, sb
0x0028ae:	ldr     	r3, [r4, #0x14]
0x0028b0:	lsls    	r0, r0, #9
0x0028b2:	bl      	#0x39a8
0x0028b6:	str     	r6, [r4, #0x14]
0x0028b8:	movs    	r1, #0
0x0028ba:	movs    	r2, #0
0x0028bc:	str     	r2, [sp, #8]
0x0028be:	str     	r1, [sp]
0x0028c0:	str     	r1, [sp, #4]
0x0028c2:	movs    	r1, #0xe1
0x0028c4:	movs    	r2, #0xb2
0x0028c6:	adds    	r3, r6, #0
0x0028c8:	movs    	r0, #0xf1
0x0028ca:	lsls    	r0, r0, #9

; ===== candidate_002964 =====
0x002964:	push    	{r0, r4, r5, r6, r7, lr}
0x002966:	sub     	sp, #0x10
0x002968:	movs    	r1, #0
0x00296a:	str     	r1, [sp]
0x00296c:	str     	r1, [sp, #4]
0x00296e:	movs    	r6, #0xf1
0x002970:	movs    	r7, #0
0x002972:	movs    	r2, #0
0x002974:	adds    	r3, r7, #0
0x002976:	lsls    	r6, r6, #9
0x002978:	movs    	r1, #0x13
0x00297a:	adds    	r0, r6, #0
0x00297c:	str     	r2, [sp, #8]
0x00297e:	bl      	#0x39a8
0x002982:	movs    	r1, #0
0x002984:	str     	r1, [sp]
0x002986:	str     	r1, [sp, #4]
0x002988:	movs    	r2, #0
0x00298a:	movs    	r1, #0x34
0x00298c:	adds    	r4, r0, #0
0x00298e:	adds    	r3, r7, #0
0x002990:	adds    	r0, r6, #0
0x002992:	str     	r2, [sp, #8]
0x002994:	bl      	#0x39a8
0x002998:	movs    	r1, #0
0x00299a:	movs    	r2, #0
0x00299c:	str     	r2, [sp, #8]
0x00299e:	str     	r1, [sp]
0x0029a0:	str     	r1, [sp, #4]
0x0029a2:	movs    	r1, #0x14
0x0029a4:	movs    	r2, #0xdd
0x0029a6:	adds    	r3, r7, #0
0x0029a8:	adds    	r0, r6, #0
0x0029aa:	bl      	#0x39a8
0x0029ae:	movs    	r1, #0
0x0029b0:	movs    	r2, #0
0x0029b2:	str     	r2, [sp, #8]
0x0029b4:	str     	r1, [sp]
0x0029b6:	str     	r1, [sp, #4]
0x0029b8:	movs    	r1, #0x14
0x0029ba:	movs    	r2, #0xdc
0x0029bc:	adds    	r3, r7, #0
0x0029be:	adds    	r0, r6, #0
0x0029c0:	bl      	#0x39a8
0x0029c4:	movs    	r1, #0
0x0029c6:	movs    	r2, #0
0x0029c8:	str     	r2, [sp, #8]
0x0029ca:	str     	r1, [sp]
0x0029cc:	str     	r1, [sp, #4]
0x0029ce:	movs    	r1, #0xe1
0x0029d0:	movs    	r2, #0xde
0x0029d2:	adds    	r3, r7, #0
0x0029d4:	adds    	r0, r6, #0
0x0029d6:	bl      	#0x39a8
0x0029da:	movs    	r1, #0
0x0029dc:	movs    	r2, #0
0x0029de:	str     	r2, [sp, #8]
0x0029e0:	str     	r1, [sp]
0x0029e2:	str     	r1, [sp, #4]
0x0029e4:	movs    	r1, #0xe1
0x0029e6:	movs    	r2, #0x52
0x0029e8:	adds    	r5, r0, #0
0x0029ea:	adds    	r3, r7, #0
0x0029ec:	adds    	r0, r6, #0
0x0029ee:	bl      	#0x39a8
0x0029f2:	movs    	r1, #0
0x0029f4:	movs    	r2, #0
0x0029f6:	str     	r2, [sp, #8]
0x0029f8:	str     	r1, [sp]
0x0029fa:	str     	r1, [sp, #4]
0x0029fc:	movs    	r1, #0x27
0x0029fe:	adds    	r2, r0, #0
0x002a00:	adds    	r3, r5, #0
0x002a02:	adds    	r0, r6, #0
0x002a04:	bl      	#0x39a8
0x002a08:	ldr     	r7, [pc, #0x358]
0x002a0a:	adds    	r5, r0, #0
0x002a0c:	add     	r7, pc
0x002a0e:	ldr     	r0, [sp, #0x10]
0x002a10:	cmp     	r0, #0x2c
0x002a12:	bne     	#0x2afa
0x002a14:	movs    	r0, #0x33
0x002a16:	ldrb    	r0, [r0, r5]
0x002a18:	cmp     	r0, #1
0x002a1a:	bne     	#0x2a4a
0x002a1c:	movs    	r2, #0
0x002a1e:	movs    	r1, #0
0x002a20:	str     	r2, [sp, #8]
0x002a22:	adds    	r2, r7, #0
0x002a24:	str     	r1, [sp]
0x002a26:	str     	r1, [sp, #4]
0x002a28:	movs    	r1, #0x35
0x002a2a:	subs    	r2, #0xc
0x002a2c:	adds    	r3, r7, #0
0x002a2e:	adds    	r0, r6, #0
0x002a30:	bl      	#0x39a8
0x002a34:	movs    	r1, #0
0x002a36:	movs    	r2, #0
0x002a38:	str     	r2, [sp, #8]
0x002a3a:	str     	r1, [sp]
0x002a3c:	str     	r1, [sp, #4]
0x002a3e:	movs    	r1, #0x36
0x002a40:	adds    	r2, r4, #0
0x002a42:	adds    	r3, r0, #0
0x002a44:	adds    	r0, r6, #0
0x002a46:	bl      	#0x39a8
0x002a4a:	movs    	r2, #0
0x002a4c:	movs    	r1, #0
0x002a4e:	str     	r2, [sp, #8]
0x002a50:	ldr     	r2, [pc, #0x314]
0x002a52:	str     	r1, [sp]
0x002a54:	str     	r1, [sp, #4]
0x002a56:	adds    	r3, r7, #0
0x002a58:	add     	r2, pc
0x002a5a:	movs    	r1, #0x35
0x002a5c:	adds    	r0, r6, #0
0x002a5e:	bl      	#0x39a8
0x002a62:	movs    	r1, #0
0x002a64:	adds    	r3, r0, #0
0x002a66:	movs    	r2, #0
0x002a68:	str     	r2, [sp, #8]
0x002a6a:	str     	r1, [sp]
0x002a6c:	str     	r1, [sp, #4]
0x002a6e:	movs    	r1, #0x36
0x002a70:	adds    	r2, r4, #0
0x002a72:	movs    	r0, #0xf1
0x002a74:	lsls    	r0, r0, #9
0x002a76:	bl      	#0x39a8
0x002a7a:	movs    	r2, #0
0x002a7c:	movs    	r1, #0
0x002a7e:	str     	r2, [sp, #8]
0x002a80:	ldr     	r2, [pc, #0x2e8]
0x002a82:	str     	r1, [sp]
0x002a84:	str     	r1, [sp, #4]
0x002a86:	adds    	r3, r7, #0
0x002a88:	add     	r2, pc
0x002a8a:	movs    	r1, #0x35
0x002a8c:	movs    	r0, #0xf1
0x002a8e:	lsls    	r0, r0, #9
0x002a90:	bl      	#0x39a8
0x002a94:	movs    	r1, #0

; ===== candidate_002d94 =====
0x002d94:	push    	{r4, r5, lr}
0x002d96:	sub     	sp, #0xc
0x002d98:	movs    	r1, #0
0x002d9a:	movs    	r2, #0
0x002d9c:	str     	r2, [sp, #8]
0x002d9e:	str     	r1, [sp]
0x002da0:	str     	r1, [sp, #4]
0x002da2:	movs    	r5, #0xf1
0x002da4:	movs    	r4, #0
0x002da6:	adds    	r3, r4, #0
0x002da8:	lsls    	r5, r5, #9
0x002daa:	movs    	r1, #0x14
0x002dac:	movs    	r2, #0xcf
0x002dae:	adds    	r0, r5, #0
0x002db0:	bl      	#0x39a8
0x002db4:	movs    	r1, #0
0x002db6:	str     	r1, [sp]
0x002db8:	str     	r1, [sp, #4]
0x002dba:	movs    	r1, #0xff
0x002dbc:	movs    	r2, #0
0x002dbe:	adds    	r1, #0x11
0x002dc0:	adds    	r3, r4, #0
0x002dc2:	adds    	r0, r5, #0
0x002dc4:	str     	r2, [sp, #8]
0x002dc6:	bl      	#0x39a8
0x002dca:	movs    	r1, #0
0x002dcc:	movs    	r2, #0
0x002dce:	str     	r2, [sp, #8]
0x002dd0:	str     	r1, [sp]
0x002dd2:	str     	r1, [sp, #4]
0x002dd4:	movs    	r1, #0xe1
0x002dd6:	movs    	r2, #0x74
0x002dd8:	adds    	r3, r4, #0
0x002dda:	adds    	r0, r5, #0
0x002ddc:	bl      	#0x39a8
0x002de0:	cmp     	r0, #0
0x002de2:	bne     	#0x2df8
0x002de4:	movs    	r1, #0
0x002de6:	str     	r1, [sp]
0x002de8:	str     	r1, [sp, #4]
0x002dea:	movs    	r2, #0
0x002dec:	movs    	r1, #0x34
0x002dee:	adds    	r3, r4, #0
0x002df0:	adds    	r0, r5, #0
0x002df2:	str     	r2, [sp, #8]
0x002df4:	bl      	#0x39a8
0x002df8:	movs    	r1, #0
0x002dfa:	movs    	r2, #0
0x002dfc:	str     	r2, [sp, #8]
0x002dfe:	str     	r1, [sp]
0x002e00:	str     	r1, [sp, #4]
0x002e02:	movs    	r1, #0x14
0x002e04:	movs    	r2, #0xde
0x002e06:	adds    	r3, r4, #0
0x002e08:	adds    	r0, r5, #0
0x002e0a:	bl      	#0x39a8
0x002e0e:	movs    	r1, #0
0x002e10:	movs    	r2, #0
0x002e12:	str     	r2, [sp, #8]
0x002e14:	str     	r1, [sp]
0x002e16:	str     	r1, [sp, #4]
0x002e18:	movs    	r1, #0x14
0x002e1a:	movs    	r2, #0x17
0x002e1c:	movs    	r3, #0x29
0x002e1e:	movs    	r0, #0xf1
0x002e20:	lsls    	r0, r0, #9
0x002e22:	bl      	#0x39a8
0x002e26:	movs    	r1, #0
0x002e28:	str     	r1, [sp]
0x002e2a:	str     	r1, [sp, #4]
0x002e2c:	movs    	r2, #0
0x002e2e:	movs    	r1, #0xba
0x002e30:	adds    	r3, r4, #0
0x002e32:	movs    	r0, #0xf1
0x002e34:	lsls    	r0, r0, #9
0x002e36:	str     	r2, [sp, #8]
0x002e38:	bl      	#0x39a8
0x002e3c:	add     	sp, #0xc
0x002e3e:	pop     	{r4, r5, pc}

; ===== candidate_002e40 =====
0x002e40:	push    	{r4, r5, r6, r7, lr}
0x002e42:	sub     	sp, #0xc
0x002e44:	movs    	r1, #0
0x002e46:	str     	r1, [sp]
0x002e48:	str     	r1, [sp, #4]
0x002e4a:	movs    	r6, #0xf1
0x002e4c:	movs    	r4, #0
0x002e4e:	movs    	r2, #0
0x002e50:	adds    	r3, r4, #0
0x002e52:	lsls    	r6, r6, #9
0x002e54:	movs    	r1, #0x13
0x002e56:	adds    	r0, r6, #0
0x002e58:	str     	r2, [sp, #8]
0x002e5a:	bl      	#0x39a8
0x002e5e:	movs    	r1, #0
0x002e60:	str     	r1, [sp]
0x002e62:	str     	r1, [sp, #4]
0x002e64:	movs    	r2, #0
0x002e66:	movs    	r1, #0x34
0x002e68:	adds    	r5, r0, #0
0x002e6a:	adds    	r3, r4, #0
0x002e6c:	adds    	r0, r6, #0
0x002e6e:	str     	r2, [sp, #8]
0x002e70:	bl      	#0x39a8
0x002e74:	movs    	r1, #0
0x002e76:	movs    	r2, #0
0x002e78:	str     	r2, [sp, #8]
0x002e7a:	str     	r1, [sp]
0x002e7c:	str     	r1, [sp, #4]
0x002e7e:	movs    	r1, #0x14
0x002e80:	movs    	r2, #0xdd
0x002e82:	adds    	r3, r4, #0
0x002e84:	adds    	r0, r6, #0
0x002e86:	bl      	#0x39a8
0x002e8a:	movs    	r1, #0
0x002e8c:	movs    	r2, #0
0x002e8e:	str     	r2, [sp, #8]
0x002e90:	str     	r1, [sp]
0x002e92:	str     	r1, [sp, #4]
0x002e94:	movs    	r1, #0x14
0x002e96:	movs    	r2, #0xdc
0x002e98:	adds    	r3, r4, #0
0x002e9a:	adds    	r0, r6, #0
0x002e9c:	bl      	#0x39a8
0x002ea0:	movs    	r1, #0
0x002ea2:	movs    	r2, #0
0x002ea4:	str     	r2, [sp, #8]
0x002ea6:	str     	r1, [sp]
0x002ea8:	str     	r1, [sp, #4]
0x002eaa:	movs    	r1, #0xe1
0x002eac:	movs    	r2, #0xde
0x002eae:	adds    	r3, r4, #0
0x002eb0:	adds    	r0, r6, #0
0x002eb2:	bl      	#0x39a8
0x002eb6:	movs    	r1, #0
0x002eb8:	movs    	r2, #0
0x002eba:	str     	r2, [sp, #8]
0x002ebc:	str     	r1, [sp]
0x002ebe:	str     	r1, [sp, #4]
0x002ec0:	movs    	r1, #0xe1
0x002ec2:	movs    	r2, #0x52
0x002ec4:	adds    	r7, r0, #0
0x002ec6:	adds    	r3, r4, #0
0x002ec8:	adds    	r0, r6, #0
0x002eca:	bl      	#0x39a8
0x002ece:	movs    	r2, #0
0x002ed0:	movs    	r1, #0
0x002ed2:	str     	r2, [sp, #8]
0x002ed4:	adds    	r2, r0, #0
0x002ed6:	str     	r1, [sp]
0x002ed8:	str     	r1, [sp, #4]
0x002eda:	movs    	r1, #0x27
0x002edc:	adds    	r0, r6, #0
0x002ede:	adds    	r3, r7, #0
0x002ee0:	bl      	#0x39a8
0x002ee4:	movs    	r1, #0
0x002ee6:	movs    	r2, #0
0x002ee8:	str     	r2, [sp, #8]
0x002eea:	str     	r1, [sp]
0x002eec:	str     	r1, [sp, #4]
0x002eee:	movs    	r1, #0xe1
0x002ef0:	movs    	r2, #0x18
0x002ef2:	adds    	r3, r4, #0
0x002ef4:	adds    	r0, r6, #0
0x002ef6:	bl      	#0x39a8
0x002efa:	ldr     	r7, [r0, #0xc]
0x002efc:	movs    	r1, #0
0x002efe:	movs    	r2, #0
0x002f00:	str     	r2, [sp, #8]
0x002f02:	str     	r1, [sp]
0x002f04:	str     	r1, [sp, #4]
0x002f06:	movs    	r1, #0xe1
0x002f08:	movs    	r2, #0xab
0x002f0a:	adds    	r3, r4, #0
0x002f0c:	adds    	r0, r6, #0
0x002f0e:	bl      	#0x39a8
0x002f12:	adds    	r1, r7, #0
0x002f14:	ldr     	r7, [pc, #0x1a4]
0x002f16:	add     	r7, pc
0x002f18:	cmp     	r1, r0
0x002f1a:	bne     	#0x2f4c
0x002f1c:	movs    	r2, #0
0x002f1e:	movs    	r1, #0
0x002f20:	str     	r2, [sp, #8]
0x002f22:	ldr     	r2, [pc, #0x19c]
0x002f24:	str     	r1, [sp]
0x002f26:	str     	r1, [sp, #4]
0x002f28:	adds    	r3, r7, #0
0x002f2a:	add     	r2, pc
0x002f2c:	movs    	r1, #0x35
0x002f2e:	adds    	r0, r6, #0
0x002f30:	bl      	#0x39a8
0x002f34:	movs    	r1, #0
0x002f36:	movs    	r2, #0
0x002f38:	str     	r2, [sp, #8]
0x002f3a:	str     	r1, [sp]
0x002f3c:	str     	r1, [sp, #4]
0x002f3e:	movs    	r1, #0x36
0x002f40:	adds    	r2, r5, #0
0x002f42:	adds    	r3, r0, #0
0x002f44:	adds    	r0, r6, #0
0x002f46:	bl      	#0x39a8
0x002f4a:	b       	#0x2f7c
0x002f4c:	movs    	r2, #0
0x002f4e:	movs    	r1, #0
0x002f50:	str     	r2, [sp, #8]
0x002f52:	ldr     	r2, [pc, #0x170]
0x002f54:	str     	r1, [sp]
0x002f56:	str     	r1, [sp, #4]
0x002f58:	adds    	r3, r7, #0
0x002f5a:	add     	r2, pc
0x002f5c:	movs    	r1, #0x35
0x002f5e:	adds    	r0, r6, #0
0x002f60:	bl      	#0x39a8
0x002f64:	movs    	r1, #0
0x002f66:	adds    	r3, r0, #0
0x002f68:	movs    	r2, #0
0x002f6a:	str     	r2, [sp, #8]
0x002f6c:	str     	r1, [sp]
0x002f6e:	str     	r1, [sp, #4]
0x002f70:	movs    	r1, #0x36

; ===== candidate_0030d0 =====
0x0030d0:	push    	{r4, lr}
0x0030d2:	sub     	sp, #0x10
0x0030d4:	movs    	r1, #0
0x0030d6:	str     	r1, [sp]
0x0030d8:	str     	r1, [sp, #4]
0x0030da:	movs    	r4, #0
0x0030dc:	movs    	r2, #0
0x0030de:	adds    	r3, r4, #0
0x0030e0:	movs    	r1, #0xba
0x0030e2:	movs    	r0, #0xf1
0x0030e4:	lsls    	r0, r0, #9
0x0030e6:	str     	r2, [sp, #8]
0x0030e8:	bl      	#0x39a8
0x0030ec:	movs    	r1, #0
0x0030ee:	movs    	r2, #0
0x0030f0:	str     	r2, [sp, #8]
0x0030f2:	str     	r1, [sp]
0x0030f4:	str     	r1, [sp, #4]
0x0030f6:	movs    	r1, #0x14
0x0030f8:	movs    	r2, #0xcf
0x0030fa:	adds    	r3, r4, #0
0x0030fc:	movs    	r0, #0xf1
0x0030fe:	lsls    	r0, r0, #9
0x003100:	bl      	#0x39a8
0x003104:	movs    	r1, #0
0x003106:	str     	r1, [sp]
0x003108:	str     	r1, [sp, #4]
0x00310a:	movs    	r2, #0
0x00310c:	movs    	r1, #0x34
0x00310e:	adds    	r3, r4, #0
0x003110:	movs    	r0, #0xf1
0x003112:	lsls    	r0, r0, #9
0x003114:	str     	r2, [sp, #8]
0x003116:	bl      	#0x39a8
0x00311a:	movs    	r1, #0
0x00311c:	movs    	r2, #0
0x00311e:	str     	r2, [sp, #8]
0x003120:	str     	r1, [sp]
0x003122:	str     	r1, [sp, #4]
0x003124:	movs    	r1, #0x14
0x003126:	movs    	r2, #0xde
0x003128:	adds    	r3, r4, #0
0x00312a:	movs    	r0, #0xf1
0x00312c:	lsls    	r0, r0, #9
0x00312e:	bl      	#0x39a8
0x003132:	movs    	r1, #0
0x003134:	movs    	r2, #0
0x003136:	str     	r2, [sp, #8]
0x003138:	str     	r1, [sp]
0x00313a:	str     	r1, [sp, #4]
0x00313c:	movs    	r1, #0x14
0x00313e:	movs    	r2, #0x17
0x003140:	movs    	r3, #0xdf
0x003142:	movs    	r0, #0xf1
0x003144:	lsls    	r0, r0, #9
0x003146:	bl      	#0x39a8
0x00314a:	add     	sp, #0x10
0x00314c:	pop     	{r4, pc}

; ===== candidate_003150 =====
0x003150:	push    	{r4, r5}
0x003152:	movs    	r3, #0xc
0x003154:	ldrsh   	r4, [r0, r3]
0x003156:	cmp     	r4, r1
0x003158:	bne     	#0x3166
0x00315a:	ldr     	r3, [r0, #0x1c]
0x00315c:	cmp     	r3, r2
0x00315e:	blt     	#0x3166
0x003160:	movs    	r0, #0
0x003162:	pop     	{r4, r5}
0x003164:	bx      	lr

; ===== candidate_003198 =====
0x003198:	push    	{r4, r5, r6, r7, lr}
0x00319a:	sub     	sp, #0xc
0x00319c:	movs    	r1, #0
0x00319e:	movs    	r2, #0
0x0031a0:	str     	r2, [sp, #8]
0x0031a2:	str     	r1, [sp]
0x0031a4:	str     	r1, [sp, #4]
0x0031a6:	movs    	r6, #0xf1
0x0031a8:	movs    	r5, #0
0x0031aa:	adds    	r3, r5, #0
0x0031ac:	lsls    	r6, r6, #9
0x0031ae:	movs    	r1, #0xe1
0x0031b0:	movs    	r2, #0xdb
0x0031b2:	adds    	r7, r0, #0
0x0031b4:	adds    	r0, r6, #0
0x0031b6:	bl      	#0x39a8
0x0031ba:	cmp     	r0, #0
0x0031bc:	beq     	#0x31ec
0x0031be:	movs    	r1, #0
0x0031c0:	movs    	r2, #0
0x0031c2:	str     	r2, [sp, #8]
0x0031c4:	str     	r1, [sp]
0x0031c6:	str     	r1, [sp, #4]
0x0031c8:	movs    	r1, #0xe1
0x0031ca:	movs    	r2, #0xdb
0x0031cc:	adds    	r3, r5, #0
0x0031ce:	adds    	r0, r6, #0
0x0031d0:	bl      	#0x39a8
0x0031d4:	movs    	r1, #0
0x0031d6:	movs    	r2, #0
0x0031d8:	str     	r2, [sp, #8]
0x0031da:	str     	r1, [sp]
0x0031dc:	str     	r1, [sp, #4]
0x0031de:	movs    	r1, #0x11
0x0031e0:	adds    	r2, r0, #0
0x0031e2:	movs    	r3, #4
0x0031e4:	adds    	r0, r6, #0
0x0031e6:	bl      	#0x39a8
0x0031ea:	adds    	r4, r0, #0
0x0031ec:	cmp     	r7, #0xd
0x0031ee:	beq     	#0x3246
0x0031f0:	bgt     	#0x3234
0x0031f2:	cmp     	r7, #2
0x0031f4:	beq     	#0x3202
0x0031f6:	cmp     	r7, #5
0x0031f8:	beq     	#0x3240
0x0031fa:	cmp     	r7, #8
0x0031fc:	beq     	#0x3246
0x0031fe:	cmp     	r7, #0xc
0x003200:	bne     	#0x3230
0x003202:	movs    	r1, #0
0x003204:	movs    	r2, #0
0x003206:	str     	r2, [sp, #8]
0x003208:	str     	r1, [sp]
0x00320a:	str     	r1, [sp, #4]
0x00320c:	movs    	r1, #4
0x00320e:	movs    	r2, #0xdc
0x003210:	adds    	r3, r5, #0
0x003212:	adds    	r0, r6, #0
0x003214:	bl      	#0x39a8
0x003218:	movs    	r2, #0
0x00321a:	movs    	r1, #0
0x00321c:	str     	r1, [sp, #4]
0x00321e:	str     	r2, [sp, #8]
0x003220:	str     	r0, [sp]
0x003222:	adds    	r3, r5, #0
0x003224:	adds    	r2, r4, #0
0x003226:	movs    	r0, #0xf1
0x003228:	movs    	r1, #0x29
0x00322a:	lsls    	r0, r0, #9
0x00322c:	bl      	#0x39a8
0x003230:	add     	sp, #0xc
0x003232:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00331c =====
0x00331c:	push    	{r4, r5, r6, r7, lr}
0x00331e:	sub     	sp, #0xc
0x003320:	movs    	r1, #0
0x003322:	movs    	r2, #0
0x003324:	str     	r2, [sp, #8]
0x003326:	str     	r1, [sp]
0x003328:	str     	r1, [sp, #4]
0x00332a:	movs    	r5, #0xf1
0x00332c:	movs    	r4, #0
0x00332e:	adds    	r3, r4, #0
0x003330:	lsls    	r5, r5, #9
0x003332:	movs    	r1, #0xe1
0x003334:	movs    	r2, #0x52
0x003336:	adds    	r7, r0, #0
0x003338:	adds    	r0, r5, #0
0x00333a:	bl      	#0x39a8
0x00333e:	movs    	r1, #0
0x003340:	movs    	r2, #0
0x003342:	str     	r2, [sp, #8]
0x003344:	str     	r1, [sp]
0x003346:	str     	r1, [sp, #4]
0x003348:	movs    	r1, #0x26
0x00334a:	adds    	r2, r0, #0
0x00334c:	adds    	r3, r4, #0
0x00334e:	adds    	r0, r5, #0
0x003350:	bl      	#0x39a8
0x003354:	adds    	r6, r0, #0
0x003356:	adds    	r0, r7, #0
0x003358:	ldr     	r7, [pc, #0x360]
0x00335a:	cmp     	r0, #0xd
0x00335c:	add     	r7, sb
0x00335e:	beq     	#0x3444
0x003360:	bgt     	#0x33be
0x003362:	cmp     	r0, #2
0x003364:	beq     	#0x3372
0x003366:	cmp     	r0, #5
0x003368:	beq     	#0x33ca
0x00336a:	cmp     	r0, #8
0x00336c:	beq     	#0x3444
0x00336e:	cmp     	r0, #0xc
0x003370:	bne     	#0x33ba
0x003372:	movs    	r1, #0
0x003374:	movs    	r2, #0
0x003376:	str     	r2, [sp, #8]
0x003378:	str     	r1, [sp]
0x00337a:	str     	r1, [sp, #4]
0x00337c:	movs    	r1, #4
0x00337e:	movs    	r2, #0xde
0x003380:	adds    	r3, r4, #0
0x003382:	adds    	r0, r5, #0
0x003384:	bl      	#0x39a8
0x003388:	movs    	r1, #0
0x00338a:	adds    	r5, r0, #0
0x00338c:	movs    	r2, #0
0x00338e:	str     	r2, [sp, #8]
0x003390:	str     	r1, [sp]
0x003392:	str     	r1, [sp, #4]
0x003394:	movs    	r1, #0xe1
0x003396:	movs    	r2, #0xd6
0x003398:	movs    	r0, #0xf1
0x00339a:	adds    	r3, r4, #0
0x00339c:	lsls    	r0, r0, #9
0x00339e:	bl      	#0x39a8
0x0033a2:	movs    	r2, #0
0x0033a4:	str     	r2, [sp, #8]
0x0033a6:	movs    	r1, #0
0x0033a8:	adds    	r3, r4, #0
0x0033aa:	adds    	r2, r0, #0
0x0033ac:	str     	r1, [sp, #4]
0x0033ae:	movs    	r1, #0x29
0x0033b0:	movs    	r0, #0xf1
0x0033b2:	lsls    	r0, r0, #9
0x0033b4:	str     	r5, [sp]
0x0033b6:	bl      	#0x39a8
0x0033ba:	add     	sp, #0xc
0x0033bc:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0036cc =====
0x0036cc:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0036ce:	sub     	sp, #0xc
0x0036d0:	adds    	r4, r1, #0
0x0036d2:	movs    	r1, #0
0x0036d4:	adds    	r5, r2, #0
0x0036d6:	movs    	r2, #0
0x0036d8:	str     	r2, [sp, #8]
0x0036da:	str     	r1, [sp]
0x0036dc:	str     	r1, [sp, #4]
0x0036de:	movs    	r6, #0xf1
0x0036e0:	lsls    	r6, r6, #9
0x0036e2:	movs    	r1, #0xe1
0x0036e4:	movs    	r2, #0xe0
0x0036e6:	movs    	r3, #0
0x0036e8:	adds    	r0, r6, #0
0x0036ea:	bl      	#0x39a8
0x0036ee:	movs    	r7, #1
0x0036f0:	cmp     	r0, #0
0x0036f2:	bne     	#0x370a
0x0036f4:	movs    	r1, #0
0x0036f6:	movs    	r2, #0
0x0036f8:	str     	r2, [sp, #8]
0x0036fa:	str     	r1, [sp]
0x0036fc:	str     	r1, [sp, #4]
0x0036fe:	movs    	r1, #0x14
0x003700:	movs    	r2, #0xe0
0x003702:	adds    	r3, r7, #0
0x003704:	adds    	r0, r6, #0
0x003706:	bl      	#0x39a8
0x00370a:	ldr     	r0, [sp, #0xc]
0x00370c:	cmp     	r0, #0x15
0x00370e:	bhs     	#0x371a
0x003710:	adr     	r3, #8
0x003712:	adds    	r3, r3, r0
0x003714:	ldrh    	r3, [r3, r0]
0x003716:	lsls    	r3, r3, #1
0x003718:	add     	pc, r3
0x00371a:	b       	#0x38b4
0x00371c:	lsls    	r6, r6, #2
0x00371e:	lsls    	r1, r0, #3
0x003720:	lsls    	r4, r4, #2
0x003722:	lsls    	r6, r1, #2
0x003724:	lsls    	r1, r1, #2
0x003726:	lsls    	r2, r7, #1
0x003728:	lsls    	r5, r6, #1
0x00372a:	lsls    	r0, r6, #1
0x00372c:	lsls    	r3, r5, #1
0x00372e:	lsls    	r6, r4, #1
0x003730:	lsls    	r2, r4, #1
0x003732:	lsls    	r4, r3, #1
0x003734:	lsls    	r0, r3, #1
0x003736:	lsls    	r4, r2, #1
0x003738:	lsls    	r7, r1, #1
0x00373a:	lsls    	r2, r1, #1
0x00373c:	lsls    	r5, r0, #1
0x00373e:	lsls    	r0, r0, #1
0x003740:	movs    	r2, r4
0x003742:	movs    	r5, r3
0x003744:	movs    	r5, r2
0x003746:	adds    	r1, r5, #0
0x003748:	adds    	r0, r4, #0
0x00374a:	ldr     	r2, [sp, #0x18]
0x00374c:	bl      	#0x41c4
0x003750:	movs    	r0, #0
0x003752:	add     	sp, #0x1c
0x003754:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0038d0 =====
0x0038d0:	push    	{r3, r4, r5, lr}
0x0038d2:	ldr     	r4, [pc, #0x74]
0x0038d4:	add     	r4, pc
0x0038d6:	ldr     	r0, [r4, #0x38]
0x0038d8:	movs    	r1, #0x14
0x0038da:	ldr     	r2, [r0, #0x64]
0x0038dc:	ldr     	r0, [pc, #0x6c]
0x0038de:	add     	r0, pc
0x0038e0:	blx     	r2
0x0038e2:	movs    	r5, #0
0x0038e4:	mvns    	r5, r5
0x0038e6:	cmp     	r0, r5
0x0038e8:	bne     	#0x38ee
0x0038ea:	adds    	r0, r5, #0
0x0038ec:	pop     	{r3, r4, r5, pc}

; ===== candidate_003958 =====
0x003958:	push    	{r4, lr}
0x00395a:	sub     	sp, #0x10
0x00395c:	lsls    	r0, r0, #0x18
0x00395e:	lsrs    	r0, r0, #0x18
0x003960:	str     	r0, [sp]
0x003962:	ldr     	r0, [pc, #0x38]
0x003964:	lsls    	r2, r2, #0x18
0x003966:	lsls    	r1, r1, #0x18
0x003968:	lsrs    	r1, r1, #0x18
0x00396a:	lsrs    	r2, r2, #0x18
0x00396c:	str     	r2, [sp, #8]
0x00396e:	str     	r1, [sp, #4]
0x003970:	add     	r0, pc
0x003972:	ldr     	r0, [r0, #0x38]
0x003974:	adds    	r1, r0, #0
0x003976:	adds    	r1, #0xff
0x003978:	adds    	r1, #0x41
0x00397a:	ldr     	r2, [r1, #0x34]
0x00397c:	ldr     	r1, [r1, #0x30]
0x00397e:	ldr     	r2, [r2]
0x003980:	ldr     	r1, [r1]
0x003982:	lsls    	r3, r2, #0x10
0x003984:	lsls    	r2, r1, #0x10
0x003986:	asrs    	r2, r2, #0x10
0x003988:	asrs    	r3, r3, #0x10
0x00398a:	adds    	r0, #0xff
0x00398c:	adds    	r0, #0xc1
0x00398e:	ldr     	r4, [r0, #0x28]
0x003990:	movs    	r1, #0
0x003992:	movs    	r0, #0
0x003994:	blx     	r4
0x003996:	add     	sp, #0x10
0x003998:	pop     	{r4, pc}

; ===== candidate_0039a8 =====
0x0039a8:	push    	{r4, r5, r6, r7, lr}
0x0039aa:	adds    	r5, r1, #0
0x0039ac:	adds    	r4, r0, #0
0x0039ae:	adds    	r6, r2, #0
0x0039b0:	ldr     	r2, [pc, #0x28]
0x0039b2:	sub     	sp, #0x14
0x0039b4:	mov     	ip, r3
0x0039b6:	add     	r2, pc
0x0039b8:	ldr     	r0, [sp, #0x2c]
0x0039ba:	ldr     	r1, [sp, #0x30]
0x0039bc:	ldr     	r7, [sp, #0x28]
0x0039be:	ldr     	r3, [r2, #0x3c]
0x0039c0:	movs    	r2, #2
0x0039c2:	str     	r2, [sp, #0xc]
0x0039c4:	str     	r1, [sp, #8]
0x0039c6:	str     	r0, [sp, #4]
0x0039c8:	str     	r7, [sp]
0x0039ca:	ldr     	r0, [r3, #0xc]
0x0039cc:	adds    	r1, r5, #0
0x0039ce:	adds    	r2, r6, #0
0x0039d0:	ldr     	r7, [r0, #0x28]
0x0039d2:	adds    	r0, r4, #0
0x0039d4:	mov     	r3, ip
0x0039d6:	blx     	r7
0x0039d8:	add     	sp, #0x14
0x0039da:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0039e4 =====
0x0039e4:	push    	{r4, lr}
0x0039e6:	movs    	r2, #0
0x0039e8:	add     	r0, pc
0x0039ea:	ldr     	r4, [r0, #0x3c]
0x0039ec:	sub     	sp, #0x10
0x0039ee:	movs    	r1, #0
0x0039f0:	str     	r1, [sp, #4]
0x0039f2:	str     	r1, [sp, #8]
0x0039f4:	str     	r2, [sp, #0xc]
0x0039f6:	str     	r2, [sp]
0x0039f8:	ldr     	r0, [r4, #0xc]
0x0039fa:	ldr     	r2, [r0, #0x24]
0x0039fc:	ldr     	r4, [r0, #0x28]
0x0039fe:	blx     	r4
0x003a00:	add     	sp, #0x10
0x003a02:	pop     	{r4, pc}

; ===== candidate_003a08 =====
0x003a08:	push    	{r4, lr}
0x003a0a:	ldr     	r0, [pc, #0x24]
0x003a0c:	sub     	sp, #0x10
0x003a0e:	add     	r0, pc
0x003a10:	ldr     	r3, [r0, #0x3c]
0x003a12:	movs    	r2, #0
0x003a14:	movs    	r1, #0
0x003a16:	str     	r1, [sp, #4]
0x003a18:	str     	r1, [sp, #8]
0x003a1a:	str     	r2, [sp, #0xc]
0x003a1c:	str     	r2, [sp]
0x003a1e:	ldr     	r0, [r3, #0xc]
0x003a20:	movs    	r3, #0
0x003a22:	ldr     	r2, [r0, #0x24]
0x003a24:	ldr     	r4, [r0, #0x28]
0x003a26:	movs    	r1, #1
0x003a28:	blx     	r4
0x003a2a:	add     	sp, #0x10
0x003a2c:	pop     	{r4, pc}

; ===== candidate_003a48 =====
0x003a48:	push    	{r4, lr}
0x003a4a:	sub     	sp, #0x10
0x003a4c:	movs    	r2, #0
0x003a4e:	movs    	r1, #0
0x003a50:	str     	r2, [sp, #8]
0x003a52:	ldr     	r2, [pc, #0x3c]
0x003a54:	str     	r1, [sp]
0x003a56:	str     	r1, [sp, #4]
0x003a58:	movs    	r3, #0
0x003a5a:	add     	r2, pc
0x003a5c:	ldr     	r1, [pc, #0x34]
0x003a5e:	ldr     	r0, [pc, #0x38]
0x003a60:	bl      	#0x39a8
0x003a64:	ldr     	r3, [pc, #0x38]
0x003a66:	ldr     	r4, [pc, #0x34]
0x003a68:	add     	r3, sb
0x003a6a:	ldr     	r3, [r3]
0x003a6c:	movs    	r2, #0x41
0x003a6e:	movs    	r1, #0
0x003a70:	add     	r4, sb
0x003a72:	adds    	r0, r4, #0
0x003a74:	blx     	r3
0x003a76:	bl      	#0x3a34
0x003a7a:	ldr     	r3, [pc, #0x28]
0x003a7c:	adds    	r1, r0, #0
0x003a7e:	add     	r3, sb
0x003a80:	ldr     	r3, [r3]
0x003a82:	movs    	r2, #0x41
0x003a84:	adds    	r0, r4, #0
0x003a86:	blx     	r3
0x003a88:	movs    	r0, #0
0x003a8a:	add     	sp, #0x10
0x003a8c:	pop     	{r4, pc}

; ===== candidate_003aac =====
0x003aac:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x003aae:	adds    	r7, r3, #0
0x003ab0:	adds    	r6, r2, #0
0x003ab2:	adds    	r5, r0, #0
0x003ab4:	ldr     	r0, [r0]
0x003ab6:	sub     	sp, #4
0x003ab8:	mov     	r1, sb
0x003aba:	str     	r1, [sp]
0x003abc:	movs    	r4, #0
0x003abe:	blx     	#0x34
0x003ac2:	ldr     	r0, [sp, #8]
0x003ac4:	cmp     	r0, #0xb
0x003ac6:	bhs     	#0x3b34
0x003ac8:	adr     	r3, #4
0x003aca:	ldrb    	r3, [r3, r0]
0x003acc:	lsls    	r3, r3, #1
0x003ace:	add     	pc, r3
0x003ad0:	lsrs    	r5, r0, #0x1c
0x003ad2:	subs    	r4, r3, #4
0x003ad4:	movs    	r4, #0x21
0x003ad6:	adds    	r1, #0x27
0x003ad8:	adds    	r1, #0x2b
0x003ada:	movs    	r7, r5
0x003adc:	ldr     	r1, [pc, #0x60]
0x003ade:	ldr     	r0, [r5, #0xc]
0x003ae0:	add     	r1, sb
0x003ae2:	str     	r0, [r1, #0x14]
0x003ae4:	bl      	#0x3c
0x003ae8:	bl      	#0x3a48
0x003aec:	adds    	r4, r0, #0
0x003aee:	b       	#0x3b34
0x003af0:	ldr     	r0, [r6]
0x003af2:	cmp     	r0, #8
0x003af4:	bne     	#0x3afe
0x003af6:	bl      	#0x39a4
0x003afa:	adds    	r4, r0, #0
0x003afc:	b       	#0x3b34
0x003afe:	ldr     	r1, [r6, #4]
0x003b00:	ldr     	r2, [r6, #8]
0x003b02:	bl      	#0x39a0
0x003b06:	adds    	r4, r0, #0
0x003b08:	b       	#0x3b34
0x003b0a:	bl      	#0x3d3c
0x003b0e:	b       	#0x3b34
0x003b10:	str     	r7, [r5, #0xc]
0x003b12:	b       	#0x3b34
0x003b14:	bl      	#0x3aa8
0x003b18:	b       	#0x3b34
0x003b1a:	bl      	#0x3b78
0x003b1e:	b       	#0x3b34
0x003b20:	ldr     	r0, [pc, #0x1c]
0x003b22:	add     	r0, sb
0x003b24:	str     	r7, [r0, #0x1c]
0x003b26:	b       	#0x3b34
0x003b28:	ldr     	r0, [pc, #0x14]
0x003b2a:	add     	r0, sb
0x003b2c:	str     	r6, [r0, #0x20]
0x003b2e:	b       	#0x3b34
0x003b30:	ldr     	r4, [pc, #0x10]
0x003b32:	add     	r4, pc
0x003b34:	ldr     	r1, [sp]
0x003b36:	add     	sp, #0x14
0x003b38:	adds    	r0, r4, #0
0x003b3a:	mov     	sb, r1
0x003b3c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003b48 =====
0x003b48:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x003b4a:	sub     	sp, #0xc
0x003b4c:	ldr     	r0, [sp, #0x38]
0x003b4e:	ldr     	r4, [sp, #0x3c]
0x003b50:	ldr     	r6, [sp, #0x34]
0x003b52:	ldr     	r0, [r0]
0x003b54:	mov     	r7, sb
0x003b56:	movs    	r5, #0
0x003b58:	blx     	#0x34
0x003b5c:	cmp     	r4, #0
0x003b5e:	beq     	#0x3b6e
0x003b60:	ldr     	r1, [sp, #0x30]
0x003b62:	str     	r6, [sp, #4]
0x003b64:	add     	r3, sp, #0xc
0x003b66:	str     	r1, [sp]
0x003b68:	ldm     	r3, {r0, r1, r2, r3}
0x003b6a:	blx     	r4
0x003b6c:	adds    	r5, r0, #0
0x003b6e:	mov     	sb, r7
0x003b70:	adds    	r0, r5, #0
0x003b72:	add     	sp, #0x1c
0x003b74:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003bdc =====
0x003bdc:	push    	{r3, r4, r5, r6, r7, lr}
0x003bde:	adds    	r4, r0, #0
0x003be0:	ldr     	r0, [pc, #0x10c]
0x003be2:	movs    	r5, #0
0x003be4:	mvns    	r5, r5
0x003be6:	mov     	ip, r2
0x003be8:	add     	r0, pc
0x003bea:	ldr     	r2, [r0, #0x38]
0x003bec:	cmp     	r4, #0
0x003bee:	bne     	#0x3c00
0x003bf0:	ldr     	r0, [pc, #0x100]
0x003bf2:	ldr     	r2, [r2, #0x68]
0x003bf4:	movs    	r1, #0x7d
0x003bf6:	lsls    	r1, r1, #3
0x003bf8:	add     	r0, pc
0x003bfa:	blx     	r2
0x003bfc:	adds    	r0, r5, #0
0x003bfe:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_003d08 =====
0x003d08:	push    	{r3, r4, r5, lr}
0x003d0a:	ldr     	r4, [pc, #0x28]
0x003d0c:	adds    	r5, r0, #0
0x003d0e:	add     	r4, pc
0x003d10:	ldr     	r0, [r4, #0x38]
0x003d12:	adds    	r0, #0x80
0x003d14:	ldr     	r0, [r0, #4]
0x003d16:	blx     	r0
0x003d18:	adds    	r0, r0, r5
0x003d1a:	ldr     	r1, [pc, #0x1c]
0x003d1c:	add     	r1, sb
0x003d1e:	str     	r0, [r1, #0x10]
0x003d20:	ldr     	r0, [r4, #0x38]
0x003d22:	adds    	r0, #0x80
0x003d24:	ldr     	r0, [r0]
0x003d26:	blx     	r0
0x003d28:	ldr     	r0, [r4, #0x38]
0x003d2a:	ldr     	r1, [r0, #0x7c]
0x003d2c:	lsls    	r0, r5, #0x10
0x003d2e:	lsrs    	r0, r0, #0x10
0x003d30:	blx     	r1
0x003d32:	pop     	{r3, r4, r5, pc}

; ===== candidate_003d3e =====
0x003d3e:	push    	{r3, r4, r5, r6, r7, lr}
0x003d40:	add     	r0, pc
0x003d42:	ldr     	r0, [r0, #0x38]
0x003d44:	adds    	r0, #0x80
0x003d46:	ldr     	r0, [r0, #4]
0x003d48:	blx     	r0
0x003d4a:	movs    	r5, #0
0x003d4c:	ldr     	r6, [pc, #0xc8]
0x003d4e:	add     	r6, sb
0x003d50:	ldr     	r1, [r6, #0x10]
0x003d52:	str     	r5, [r6, #0x10]
0x003d54:	subs    	r1, r0, r1
0x003d56:	ldr     	r0, [r6, #8]
0x003d58:	adds    	r3, r1, #0
0x003d5a:	cmp     	r0, #0
0x003d5c:	beq     	#0x3e12
0x003d5e:	ldr     	r2, [r0, #8]
0x003d60:	cmp     	r2, #0
0x003d62:	bne     	#0x3dc2
0x003d64:	mvns    	r7, r2
0x003d66:	str     	r7, [r0, #8]
0x003d68:	ldr     	r2, [r0, #0x18]
0x003d6a:	adds    	r4, r0, #0
0x003d6c:	cmp     	r1, #0x32
0x003d6e:	str     	r2, [r6, #8]
0x003d70:	bge     	#0x3d76
0x003d72:	movs    	r1, #0x32
0x003d74:	b       	#0x3d92
0x003d76:	movs    	r2, #0x7d
0x003d78:	lsls    	r2, r2, #4
0x003d7a:	cmp     	r1, r2
0x003d7c:	ble     	#0x3d92
0x003d7e:	adds    	r1, r2, #0
0x003d80:	b       	#0x3d92
0x003d82:	movs    	r7, #0
0x003d84:	mvns    	r7, r7
0x003d86:	str     	r7, [r2, #8]
0x003d88:	ldr     	r2, [r0, #0x18]
0x003d8a:	str     	r2, [r0, #0x1c]
0x003d8c:	ldr     	r0, [r2, #0x18]
0x003d8e:	str     	r0, [r6, #8]
0x003d90:	adds    	r0, r2, #0
0x003d92:	ldr     	r2, [r0, #0x18]
0x003d94:	cmp     	r2, #0
0x003d96:	beq     	#0x3d9e
0x003d98:	ldr     	r7, [r2, #8]
0x003d9a:	cmp     	r7, r1
0x003d9c:	blt     	#0x3d82
0x003d9e:	str     	r5, [r0, #0x1c]
0x003da0:	ldr     	r0, [r6, #8]
0x003da2:	cmp     	r0, #0
0x003da4:	beq     	#0x3e06
0x003da6:	cmp     	r3, #0
0x003da8:	bge     	#0x3dac
0x003daa:	movs    	r3, #0
0x003dac:	ldr     	r0, [r6, #8]
0x003dae:	ldr     	r1, [r0, #8]
0x003db0:	cmp     	r1, #0
0x003db2:	bge     	#0x3db8
0x003db4:	movs    	r1, #0
0x003db6:	str     	r5, [r0, #8]
0x003db8:	ldr     	r2, [pc, #0x60]
0x003dba:	cmp     	r1, r2
0x003dbc:	ble     	#0x3dc6
0x003dbe:	adds    	r1, r2, #0
0x003dc0:	b       	#0x3dc6
0x003dc2:	movs    	r4, #0
0x003dc4:	b       	#0x3da6
0x003dc6:	ldr     	r2, [r0, #8]
0x003dc8:	subs    	r2, r2, r1
0x003dca:	str     	r2, [r0, #8]
0x003dcc:	ldr     	r0, [r0, #0x18]
0x003dce:	cmp     	r0, #0
0x003dd0:	bne     	#0x3dc6
0x003dd2:	subs    	r0, r1, r3
0x003dd4:	cmp     	r0, #0
0x003dd6:	bgt     	#0x3dda
0x003dd8:	movs    	r0, #0xa
0x003dda:	bl      	#0x3d08
0x003dde:	b       	#0x3e06
0x003de0:	str     	r5, [r4, #8]
0x003de2:	ldr     	r0, [r4, #0x1c]
0x003de4:	adds    	r3, r5, #0
0x003de6:	str     	r0, [r6, #0xc]
0x003de8:	ldr     	r0, [r4, #0x14]
0x003dea:	cmp     	r0, #0
0x003dec:	beq     	#0x3dfa
0x003dee:	str     	r0, [sp]
0x003df0:	movs    	r1, #0
0x003df2:	adds    	r0, r4, #0
0x003df4:	ldr     	r2, [r4, #0x10]
0x003df6:	bl      	#0x3bdc
0x003dfa:	ldr     	r1, [r4, #0xc]
0x003dfc:	cmp     	r1, #0
0x003dfe:	beq     	#0x3e04
0x003e00:	ldr     	r0, [r4, #0x10]
0x003e02:	blx     	r1
0x003e04:	ldr     	r4, [r6, #0xc]
0x003e06:	cmp     	r4, #0
0x003e08:	beq     	#0x3e10
0x003e0a:	ldr     	r0, [r4, #8]
0x003e0c:	cmp     	r0, #0
0x003e0e:	blt     	#0x3de0
0x003e10:	str     	r5, [r6, #0xc]
0x003e12:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_003e20 =====
0x003e20:	push    	{r4, r5, r6, r7, lr}
0x003e22:	sub     	sp, #0xc
0x003e24:	adds    	r7, r1, #0
0x003e26:	movs    	r1, #0
0x003e28:	movs    	r2, #0
0x003e2a:	str     	r2, [sp, #8]
0x003e2c:	str     	r1, [sp]
0x003e2e:	str     	r1, [sp, #4]
0x003e30:	movs    	r6, #0xf1
0x003e32:	movs    	r5, #0
0x003e34:	adds    	r3, r5, #0
0x003e36:	lsls    	r6, r6, #9
0x003e38:	movs    	r1, #0x14
0x003e3a:	movs    	r2, #0x20
0x003e3c:	adds    	r4, r0, #0
0x003e3e:	adds    	r0, r6, #0
0x003e40:	bl      	#0x39a8
0x003e44:	movs    	r1, #0
0x003e46:	movs    	r2, #0
0x003e48:	str     	r2, [sp, #8]
0x003e4a:	str     	r1, [sp]
0x003e4c:	str     	r1, [sp, #4]
0x003e4e:	movs    	r1, #0x14
0x003e50:	movs    	r2, #0xdc
0x003e52:	adds    	r3, r5, #0
0x003e54:	adds    	r0, r6, #0
0x003e56:	bl      	#0x39a8
0x003e5a:	movs    	r1, #0
0x003e5c:	movs    	r2, #0
0x003e5e:	str     	r2, [sp, #8]
0x003e60:	str     	r1, [sp]
0x003e62:	str     	r1, [sp, #4]
0x003e64:	movs    	r1, #0x14
0x003e66:	movs    	r2, #0xdd
0x003e68:	adds    	r3, r5, #0
0x003e6a:	adds    	r0, r6, #0
0x003e6c:	bl      	#0x39a8
0x003e70:	movs    	r1, #0
0x003e72:	str     	r1, [sp]
0x003e74:	str     	r1, [sp, #4]
0x003e76:	movs    	r2, #0
0x003e78:	movs    	r1, #0x2c
0x003e7a:	adds    	r3, r5, #0
0x003e7c:	adds    	r0, r6, #0
0x003e7e:	str     	r2, [sp, #8]
0x003e80:	bl      	#0x39a8
0x003e84:	cmp     	r4, #0
0x003e86:	bne     	#0x3f44
0x003e88:	movs    	r1, #0
0x003e8a:	movs    	r2, #0
0x003e8c:	str     	r2, [sp, #8]
0x003e8e:	str     	r1, [sp]
0x003e90:	str     	r1, [sp, #4]
0x003e92:	movs    	r1, #0xe1
0x003e94:	movs    	r2, #0xde
0x003e96:	adds    	r3, r5, #0
0x003e98:	adds    	r0, r6, #0
0x003e9a:	bl      	#0x39a8
0x003e9e:	movs    	r1, #0
0x003ea0:	movs    	r2, #0
0x003ea2:	str     	r2, [sp, #8]
0x003ea4:	str     	r1, [sp]
0x003ea6:	str     	r1, [sp, #4]
0x003ea8:	movs    	r1, #0xe1
0x003eaa:	movs    	r2, #0x52
0x003eac:	adds    	r4, r0, #0
0x003eae:	adds    	r3, r5, #0
0x003eb0:	adds    	r0, r6, #0
0x003eb2:	bl      	#0x39a8
0x003eb6:	movs    	r2, #0
0x003eb8:	movs    	r1, #0
0x003eba:	str     	r2, [sp, #8]
0x003ebc:	adds    	r2, r0, #0
0x003ebe:	str     	r1, [sp]
0x003ec0:	str     	r1, [sp, #4]
0x003ec2:	movs    	r1, #0x27
0x003ec4:	adds    	r0, r6, #0
0x003ec6:	adds    	r3, r4, #0
0x003ec8:	bl      	#0x39a8
0x003ecc:	adds    	r4, r0, #0
0x003ece:	movs    	r1, #0
0x003ed0:	ldr     	r0, [pc, #0xa4]
0x003ed2:	str     	r1, [sp]
0x003ed4:	str     	r1, [sp, #4]
0x003ed6:	movs    	r2, #0
0x003ed8:	str     	r2, [sp, #8]
0x003eda:	add     	r0, sb
0x003edc:	ldr     	r2, [r0, #0x14]
0x003ede:	movs    	r1, #0x36
0x003ee0:	adds    	r3, r7, #0
0x003ee2:	adds    	r0, r6, #0
0x003ee4:	bl      	#0x39a8
0x003ee8:	movs    	r1, #0
0x003eea:	movs    	r2, #0
0x003eec:	str     	r2, [sp, #8]
0x003eee:	str     	r1, [sp]
0x003ef0:	str     	r1, [sp, #4]
0x003ef2:	movs    	r1, #0xe1
0x003ef4:	movs    	r2, #0x52
0x003ef6:	adds    	r3, r5, #0
0x003ef8:	adds    	r0, r6, #0
0x003efa:	bl      	#0x39a8
0x003efe:	movs    	r1, #0
0x003f00:	movs    	r2, #0
0x003f02:	str     	r2, [sp, #8]
0x003f04:	str     	r1, [sp]
0x003f06:	str     	r1, [sp, #4]
0x003f08:	movs    	r1, #0x8d
0x003f0a:	adds    	r2, r0, #0
0x003f0c:	adds    	r3, r4, #0
0x003f0e:	adds    	r0, r6, #0
0x003f10:	bl      	#0x39a8
0x003f14:	movs    	r1, #0
0x003f16:	movs    	r2, #0
0x003f18:	str     	r2, [sp, #8]
0x003f1a:	str     	r1, [sp]
0x003f1c:	str     	r1, [sp, #4]
0x003f1e:	movs    	r1, #0x8c
0x003f20:	adds    	r2, r4, #0
0x003f22:	adds    	r3, r5, #0
0x003f24:	adds    	r0, r6, #0
0x003f26:	bl      	#0x39a8
0x003f2a:	movs    	r2, #0
0x003f2c:	movs    	r1, #0
0x003f2e:	str     	r2, [sp, #8]
0x003f30:	ldr     	r2, [pc, #0x48]
0x003f32:	str     	r1, [sp]
0x003f34:	str     	r1, [sp, #4]
0x003f36:	adds    	r3, r5, #0
0x003f38:	add     	r2, pc
0x003f3a:	movs    	r1, #0x33
0x003f3c:	adds    	r0, r6, #0
0x003f3e:	bl      	#0x39a8
0x003f42:	b       	#0x3f5c
0x003f44:	movs    	r2, #0
0x003f46:	movs    	r1, #0
0x003f48:	str     	r2, [sp, #8]
0x003f4a:	ldr     	r2, [pc, #0x34]
0x003f4c:	str     	r1, [sp]
0x003f4e:	str     	r1, [sp, #4]
0x003f50:	adds    	r3, r5, #0

; ===== candidate_003f84 =====
0x003f84:	push    	{r0, r4, r5, r6, r7, lr}
0x003f86:	sub     	sp, #0x10
0x003f88:	movs    	r1, #0
0x003f8a:	movs    	r4, #0
0x003f8c:	movs    	r2, #0
0x003f8e:	str     	r2, [sp, #8]
0x003f90:	adds    	r3, r4, #0
0x003f92:	str     	r1, [sp]
0x003f94:	str     	r1, [sp, #4]
0x003f96:	movs    	r5, #0x24
0x003f98:	adds    	r2, r5, #0
0x003f9a:	movs    	r1, #0x17
0x003f9c:	movs    	r0, #0xf1
0x003f9e:	lsls    	r0, r0, #9
0x003fa0:	bl      	#0x39a8
0x003fa4:	movs    	r1, #0
0x003fa6:	movs    	r2, #0
0x003fa8:	str     	r2, [sp, #8]
0x003faa:	str     	r1, [sp]
0x003fac:	str     	r1, [sp, #4]
0x003fae:	movs    	r1, #0xe1
0x003fb0:	movs    	r2, #0x1d
0x003fb2:	adds    	r3, r4, #0
0x003fb4:	movs    	r0, #0xf1
0x003fb6:	lsls    	r0, r0, #9
0x003fb8:	bl      	#0x39a8
0x003fbc:	movs    	r1, #0
0x003fbe:	adds    	r6, r0, #0
0x003fc0:	movs    	r2, #0
0x003fc2:	str     	r2, [sp, #8]
0x003fc4:	str     	r1, [sp]
0x003fc6:	str     	r1, [sp, #4]
0x003fc8:	movs    	r1, #0xe1
0x003fca:	movs    	r2, #0x18
0x003fcc:	movs    	r0, #0xf1
0x003fce:	adds    	r3, r4, #0
0x003fd0:	lsls    	r0, r0, #9
0x003fd2:	bl      	#0x39a8
0x003fd6:	ldr     	r7, [r0, #0xc]
0x003fd8:	movs    	r1, #0
0x003fda:	movs    	r2, #0
0x003fdc:	str     	r2, [sp, #8]
0x003fde:	str     	r1, [sp]
0x003fe0:	str     	r1, [sp, #4]
0x003fe2:	movs    	r1, #0xe1
0x003fe4:	movs    	r2, #0x18
0x003fe6:	movs    	r0, #0xf1
0x003fe8:	adds    	r3, r4, #0
0x003fea:	lsls    	r0, r0, #9
0x003fec:	bl      	#0x39a8
0x003ff0:	ldr     	r3, [r0, #8]
0x003ff2:	movs    	r2, #0
0x003ff4:	str     	r2, [sp, #8]
0x003ff6:	adds    	r2, r5, #0
0x003ff8:	movs    	r0, #0xf1
0x003ffa:	movs    	r1, #0x52
0x003ffc:	lsls    	r0, r0, #9
0x003ffe:	str     	r7, [sp]
0x004000:	str     	r6, [sp, #4]
0x004002:	bl      	#0x39a8
0x004006:	movs    	r1, #0
0x004008:	movs    	r2, #0
0x00400a:	str     	r1, [sp]
0x00400c:	str     	r1, [sp, #4]
0x00400e:	movs    	r1, #0x19
0x004010:	str     	r2, [sp, #8]
0x004012:	adds    	r3, r4, #0
0x004014:	movs    	r0, #0xf1
0x004016:	lsls    	r0, r0, #9
0x004018:	ldr     	r2, [sp, #0x10]
0x00401a:	bl      	#0x39a8
0x00401e:	movs    	r1, #0
0x004020:	movs    	r2, #0
0x004022:	str     	r2, [sp, #8]
0x004024:	str     	r1, [sp]
0x004026:	str     	r1, [sp, #4]
0x004028:	movs    	r1, #0x1b
0x00402a:	movs    	r2, #1
0x00402c:	adds    	r3, r4, #0
0x00402e:	movs    	r0, #0xf1
0x004030:	lsls    	r0, r0, #9
0x004032:	bl      	#0x39a8
0x004036:	add     	sp, #0x14
0x004038:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00403c =====
0x00403c:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x00403e:	sub     	sp, #0xc
0x004040:	movs    	r1, #0
0x004042:	movs    	r4, #0
0x004044:	movs    	r2, #0
0x004046:	str     	r2, [sp, #8]
0x004048:	adds    	r3, r4, #0
0x00404a:	str     	r1, [sp]
0x00404c:	str     	r1, [sp, #4]
0x00404e:	movs    	r5, #0x47
0x004050:	adds    	r2, r5, #0
0x004052:	movs    	r1, #0x17
0x004054:	movs    	r0, #0xf1
0x004056:	lsls    	r0, r0, #9
0x004058:	bl      	#0x39a8
0x00405c:	movs    	r1, #0
0x00405e:	movs    	r2, #0
0x004060:	str     	r2, [sp, #8]
0x004062:	str     	r1, [sp]
0x004064:	str     	r1, [sp, #4]
0x004066:	movs    	r1, #0xe1
0x004068:	movs    	r2, #0x1d
0x00406a:	adds    	r3, r4, #0
0x00406c:	movs    	r0, #0xf1
0x00406e:	lsls    	r0, r0, #9
0x004070:	bl      	#0x39a8
0x004074:	movs    	r1, #0
0x004076:	adds    	r6, r0, #0
0x004078:	movs    	r2, #0
0x00407a:	str     	r2, [sp, #8]
0x00407c:	str     	r1, [sp]
0x00407e:	str     	r1, [sp, #4]
0x004080:	movs    	r1, #0xe1
0x004082:	movs    	r2, #0x18
0x004084:	movs    	r0, #0xf1
0x004086:	adds    	r3, r4, #0
0x004088:	lsls    	r0, r0, #9
0x00408a:	bl      	#0x39a8
0x00408e:	ldr     	r7, [r0, #0xc]
0x004090:	movs    	r1, #0
0x004092:	movs    	r2, #0
0x004094:	str     	r2, [sp, #8]
0x004096:	str     	r1, [sp]
0x004098:	str     	r1, [sp, #4]
0x00409a:	movs    	r1, #0xe1
0x00409c:	movs    	r2, #0x18
0x00409e:	movs    	r0, #0xf1
0x0040a0:	adds    	r3, r4, #0
0x0040a2:	lsls    	r0, r0, #9
0x0040a4:	bl      	#0x39a8
0x0040a8:	ldr     	r3, [r0, #8]
0x0040aa:	movs    	r2, #0
0x0040ac:	str     	r2, [sp, #8]
0x0040ae:	adds    	r2, r5, #0
0x0040b0:	movs    	r0, #0xf1
0x0040b2:	movs    	r1, #0x52
0x0040b4:	lsls    	r0, r0, #9
0x0040b6:	str     	r7, [sp]
0x0040b8:	str     	r6, [sp, #4]
0x0040ba:	bl      	#0x39a8
0x0040be:	movs    	r1, #0
0x0040c0:	movs    	r2, #0
0x0040c2:	str     	r1, [sp]
0x0040c4:	str     	r1, [sp, #4]
0x0040c6:	movs    	r1, #0x19
0x0040c8:	str     	r2, [sp, #8]
0x0040ca:	adds    	r3, r4, #0
0x0040cc:	movs    	r0, #0xf1
0x0040ce:	lsls    	r0, r0, #9
0x0040d0:	ldr     	r2, [sp, #0xc]
0x0040d2:	bl      	#0x39a8
0x0040d6:	movs    	r1, #0
0x0040d8:	movs    	r2, #0
0x0040da:	str     	r1, [sp]
0x0040dc:	str     	r1, [sp, #4]
0x0040de:	movs    	r1, #0x19
0x0040e0:	str     	r2, [sp, #8]
0x0040e2:	adds    	r3, r4, #0
0x0040e4:	movs    	r0, #0xf1
0x0040e6:	lsls    	r0, r0, #9
0x0040e8:	ldr     	r2, [sp, #0x10]
0x0040ea:	bl      	#0x39a8
0x0040ee:	movs    	r1, #0
0x0040f0:	movs    	r2, #0
0x0040f2:	str     	r2, [sp, #8]
0x0040f4:	str     	r1, [sp]
0x0040f6:	str     	r1, [sp, #4]
0x0040f8:	movs    	r1, #0x1b
0x0040fa:	movs    	r2, #1
0x0040fc:	adds    	r3, r4, #0
0x0040fe:	movs    	r0, #0xf1
0x004100:	lsls    	r0, r0, #9
0x004102:	bl      	#0x39a8
0x004106:	add     	sp, #0x14
0x004108:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00410c =====
0x00410c:	push    	{r0, r4, r5, r6, r7, lr}
0x00410e:	sub     	sp, #0x10
0x004110:	movs    	r1, #0
0x004112:	movs    	r4, #0
0x004114:	movs    	r2, #0
0x004116:	str     	r2, [sp, #8]
0x004118:	adds    	r3, r4, #0
0x00411a:	str     	r1, [sp]
0x00411c:	str     	r1, [sp, #4]
0x00411e:	movs    	r5, #0x48
0x004120:	adds    	r2, r5, #0
0x004122:	movs    	r1, #0x17
0x004124:	movs    	r0, #0xf1
0x004126:	lsls    	r0, r0, #9
0x004128:	bl      	#0x39a8
0x00412c:	movs    	r1, #0
0x00412e:	movs    	r2, #0
0x004130:	str     	r2, [sp, #8]
0x004132:	str     	r1, [sp]
0x004134:	str     	r1, [sp, #4]
0x004136:	movs    	r1, #0xe1
0x004138:	movs    	r2, #0x1d
0x00413a:	adds    	r3, r4, #0
0x00413c:	movs    	r0, #0xf1
0x00413e:	lsls    	r0, r0, #9
0x004140:	bl      	#0x39a8
0x004144:	movs    	r1, #0
0x004146:	adds    	r6, r0, #0
0x004148:	movs    	r2, #0
0x00414a:	str     	r2, [sp, #8]
0x00414c:	str     	r1, [sp]
0x00414e:	str     	r1, [sp, #4]
0x004150:	movs    	r1, #0xe1
0x004152:	movs    	r2, #0x18
0x004154:	movs    	r0, #0xf1
0x004156:	adds    	r3, r4, #0
0x004158:	lsls    	r0, r0, #9
0x00415a:	bl      	#0x39a8
0x00415e:	ldr     	r7, [r0, #0xc]
0x004160:	movs    	r1, #0
0x004162:	movs    	r2, #0
0x004164:	str     	r2, [sp, #8]
0x004166:	str     	r1, [sp]
0x004168:	str     	r1, [sp, #4]
0x00416a:	movs    	r1, #0xe1
0x00416c:	movs    	r2, #0x18
0x00416e:	movs    	r0, #0xf1
0x004170:	adds    	r3, r4, #0
0x004172:	lsls    	r0, r0, #9
0x004174:	bl      	#0x39a8
0x004178:	ldr     	r3, [r0, #8]
0x00417a:	movs    	r2, #0
0x00417c:	str     	r2, [sp, #8]
0x00417e:	adds    	r2, r5, #0
0x004180:	movs    	r0, #0xf1
0x004182:	movs    	r1, #0x52
0x004184:	lsls    	r0, r0, #9
0x004186:	str     	r7, [sp]
0x004188:	str     	r6, [sp, #4]
0x00418a:	bl      	#0x39a8
0x00418e:	movs    	r1, #0
0x004190:	movs    	r2, #0
0x004192:	str     	r1, [sp]
0x004194:	str     	r1, [sp, #4]
0x004196:	movs    	r1, #0x19
0x004198:	str     	r2, [sp, #8]
0x00419a:	adds    	r3, r4, #0
0x00419c:	movs    	r0, #0xf1
0x00419e:	lsls    	r0, r0, #9
0x0041a0:	ldr     	r2, [sp, #0x10]
0x0041a2:	bl      	#0x39a8
0x0041a6:	movs    	r1, #0
0x0041a8:	movs    	r2, #0
0x0041aa:	str     	r2, [sp, #8]
0x0041ac:	str     	r1, [sp]
0x0041ae:	str     	r1, [sp, #4]
0x0041b0:	movs    	r1, #0x1b
0x0041b2:	movs    	r2, #1
0x0041b4:	adds    	r3, r4, #0
0x0041b6:	movs    	r0, #0xf1
0x0041b8:	lsls    	r0, r0, #9
0x0041ba:	bl      	#0x39a8
0x0041be:	add     	sp, #0x14
0x0041c0:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0041c4 =====
0x0041c4:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x0041c6:	sub     	sp, #0x10
0x0041c8:	movs    	r1, #0
0x0041ca:	movs    	r2, #0
0x0041cc:	movs    	r4, #0
0x0041ce:	adds    	r3, r4, #0
0x0041d0:	str     	r2, [sp, #8]
0x0041d2:	str     	r1, [sp]
0x0041d4:	str     	r1, [sp, #4]
0x0041d6:	movs    	r5, #0x42
0x0041d8:	adds    	r2, r5, #0
0x0041da:	movs    	r1, #0x17
0x0041dc:	movs    	r0, #0xf1
0x0041de:	lsls    	r0, r0, #9
0x0041e0:	bl      	#0x39a8
0x0041e4:	movs    	r1, #0
0x0041e6:	movs    	r2, #0
0x0041e8:	str     	r2, [sp, #8]
0x0041ea:	str     	r1, [sp]
0x0041ec:	str     	r1, [sp, #4]
0x0041ee:	movs    	r1, #0xe1
0x0041f0:	movs    	r2, #0x1d
0x0041f2:	adds    	r3, r4, #0
0x0041f4:	movs    	r0, #0xf1
0x0041f6:	lsls    	r0, r0, #9
0x0041f8:	bl      	#0x39a8
0x0041fc:	movs    	r1, #0
0x0041fe:	adds    	r6, r0, #0
0x004200:	movs    	r2, #0
0x004202:	str     	r2, [sp, #8]
0x004204:	str     	r1, [sp]
0x004206:	str     	r1, [sp, #4]
0x004208:	movs    	r1, #0xe1
0x00420a:	movs    	r2, #0x18
0x00420c:	movs    	r0, #0xf1
0x00420e:	adds    	r3, r4, #0
0x004210:	lsls    	r0, r0, #9
0x004212:	bl      	#0x39a8
0x004216:	ldr     	r7, [r0, #0xc]
0x004218:	movs    	r1, #0
0x00421a:	movs    	r2, #0
0x00421c:	str     	r2, [sp, #8]
0x00421e:	str     	r1, [sp]
0x004220:	str     	r1, [sp, #4]
0x004222:	movs    	r1, #0xe1
0x004224:	movs    	r2, #0x18
0x004226:	movs    	r0, #0xf1
0x004228:	adds    	r3, r4, #0
0x00422a:	lsls    	r0, r0, #9
0x00422c:	bl      	#0x39a8
0x004230:	ldr     	r3, [r0, #8]
0x004232:	movs    	r2, #0
0x004234:	str     	r2, [sp, #8]
0x004236:	adds    	r2, r5, #0
0x004238:	movs    	r0, #0xf1
0x00423a:	movs    	r1, #0x52
0x00423c:	lsls    	r0, r0, #9
0x00423e:	str     	r7, [sp]
0x004240:	str     	r6, [sp, #4]
0x004242:	bl      	#0x39a8
0x004246:	movs    	r1, #0
0x004248:	movs    	r2, #0
0x00424a:	str     	r1, [sp]
0x00424c:	str     	r1, [sp, #4]
0x00424e:	movs    	r1, #0x19
0x004250:	str     	r2, [sp, #8]
0x004252:	adds    	r3, r4, #0
0x004254:	movs    	r0, #0xf1
0x004256:	lsls    	r0, r0, #9
0x004258:	ldr     	r2, [sp, #0x10]
0x00425a:	bl      	#0x39a8
0x00425e:	movs    	r1, #0
0x004260:	movs    	r2, #0
0x004262:	str     	r1, [sp]
0x004264:	str     	r1, [sp, #4]
0x004266:	movs    	r1, #0x19
0x004268:	str     	r2, [sp, #8]
0x00426a:	adds    	r3, r4, #0
0x00426c:	movs    	r0, #0xf1
0x00426e:	lsls    	r0, r0, #9
0x004270:	ldr     	r2, [sp, #0x14]
0x004272:	bl      	#0x39a8
0x004276:	movs    	r1, #0
0x004278:	movs    	r2, #0
0x00427a:	str     	r1, [sp]
0x00427c:	str     	r1, [sp, #4]
0x00427e:	movs    	r1, #0x19
0x004280:	str     	r2, [sp, #8]
0x004282:	adds    	r3, r4, #0
0x004284:	movs    	r0, #0xf1
0x004286:	lsls    	r0, r0, #9
0x004288:	ldr     	r2, [sp, #0x18]
0x00428a:	bl      	#0x39a8
0x00428e:	movs    	r1, #0
0x004290:	movs    	r2, #0
0x004292:	str     	r2, [sp, #8]
0x004294:	str     	r1, [sp]
0x004296:	str     	r1, [sp, #4]
0x004298:	movs    	r1, #0x1b
0x00429a:	movs    	r2, #1
0x00429c:	adds    	r3, r4, #0
0x00429e:	movs    	r0, #0xf1
0x0042a0:	lsls    	r0, r0, #9
0x0042a2:	bl      	#0x39a8
0x0042a6:	add     	sp, #0x1c
0x0042a8:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0042ac =====
0x0042ac:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x0042ae:	sub     	sp, #0xc
0x0042b0:	movs    	r1, #0
0x0042b2:	movs    	r4, #0
0x0042b4:	movs    	r2, #0
0x0042b6:	str     	r2, [sp, #8]
0x0042b8:	adds    	r3, r4, #0
0x0042ba:	str     	r1, [sp]
0x0042bc:	str     	r1, [sp, #4]
0x0042be:	movs    	r5, #0xb3
0x0042c0:	adds    	r2, r5, #0
0x0042c2:	movs    	r1, #0x17
0x0042c4:	movs    	r0, #0xf1
0x0042c6:	lsls    	r0, r0, #9
0x0042c8:	bl      	#0x39a8
0x0042cc:	movs    	r1, #0
0x0042ce:	movs    	r2, #0
0x0042d0:	str     	r2, [sp, #8]
0x0042d2:	str     	r1, [sp]
0x0042d4:	str     	r1, [sp, #4]
0x0042d6:	movs    	r1, #0xe1
0x0042d8:	movs    	r2, #0x1d
0x0042da:	adds    	r3, r4, #0
0x0042dc:	movs    	r0, #0xf1
0x0042de:	lsls    	r0, r0, #9
0x0042e0:	bl      	#0x39a8
0x0042e4:	movs    	r1, #0
0x0042e6:	adds    	r6, r0, #0
0x0042e8:	movs    	r2, #0
0x0042ea:	str     	r2, [sp, #8]
0x0042ec:	str     	r1, [sp]
0x0042ee:	str     	r1, [sp, #4]
0x0042f0:	movs    	r1, #0xe1
0x0042f2:	movs    	r2, #0x18
0x0042f4:	movs    	r0, #0xf1
0x0042f6:	adds    	r3, r4, #0
0x0042f8:	lsls    	r0, r0, #9
0x0042fa:	bl      	#0x39a8
0x0042fe:	ldr     	r7, [r0, #0xc]
0x004300:	movs    	r1, #0
0x004302:	movs    	r2, #0
0x004304:	str     	r2, [sp, #8]
0x004306:	str     	r1, [sp]
0x004308:	str     	r1, [sp, #4]
0x00430a:	movs    	r1, #0xe1
0x00430c:	movs    	r2, #0x18
0x00430e:	movs    	r0, #0xf1
0x004310:	adds    	r3, r4, #0
0x004312:	lsls    	r0, r0, #9
0x004314:	bl      	#0x39a8
0x004318:	ldr     	r3, [r0, #8]
0x00431a:	movs    	r2, #0
0x00431c:	str     	r2, [sp, #8]
0x00431e:	adds    	r2, r5, #0
0x004320:	movs    	r0, #0xf1
0x004322:	movs    	r1, #0x52
0x004324:	lsls    	r0, r0, #9
0x004326:	str     	r7, [sp]
0x004328:	str     	r6, [sp, #4]
0x00432a:	bl      	#0x39a8
0x00432e:	movs    	r1, #0
0x004330:	str     	r1, [sp]
0x004332:	str     	r1, [sp, #4]
0x004334:	movs    	r2, #0
0x004336:	ldr     	r0, [sp, #0xc]
0x004338:	str     	r2, [sp, #8]
0x00433a:	ldr     	r2, [r0]
0x00433c:	movs    	r0, #0xf1
0x00433e:	movs    	r1, #0x19
0x004340:	adds    	r3, r4, #0
0x004342:	lsls    	r0, r0, #9
0x004344:	bl      	#0x39a8
0x004348:	movs    	r1, #0
0x00434a:	movs    	r2, #0
0x00434c:	str     	r1, [sp]
0x00434e:	str     	r1, [sp, #4]
0x004350:	movs    	r1, #0x1a
0x004352:	str     	r2, [sp, #8]
0x004354:	adds    	r3, r4, #0
0x004356:	movs    	r0, #0xf1
0x004358:	lsls    	r0, r0, #9
0x00435a:	ldr     	r2, [sp, #0x10]
0x00435c:	bl      	#0x39a8
0x004360:	movs    	r1, #0
0x004362:	movs    	r2, #0
0x004364:	str     	r2, [sp, #8]
0x004366:	str     	r1, [sp]
0x004368:	str     	r1, [sp, #4]
0x00436a:	movs    	r1, #0x1b
0x00436c:	movs    	r2, #1
0x00436e:	adds    	r3, r4, #0
0x004370:	movs    	r0, #0xf1
0x004372:	lsls    	r0, r0, #9
0x004374:	bl      	#0x39a8
0x004378:	add     	sp, #0x14
0x00437a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00437c =====
0x00437c:	push    	{r4, r5, r6, r7, lr}
0x00437e:	sub     	sp, #0xc
0x004380:	movs    	r1, #0
0x004382:	movs    	r2, #0
0x004384:	str     	r2, [sp, #8]
0x004386:	str     	r1, [sp]
0x004388:	str     	r1, [sp, #4]
0x00438a:	movs    	r4, #0
0x00438c:	adds    	r3, r4, #0
0x00438e:	movs    	r1, #0xe1
0x004390:	movs    	r2, #0xde
0x004392:	movs    	r0, #0xf1
0x004394:	lsls    	r0, r0, #9
0x004396:	bl      	#0x39a8
0x00439a:	movs    	r1, #0
0x00439c:	adds    	r5, r0, #0
0x00439e:	movs    	r2, #0
0x0043a0:	str     	r2, [sp, #8]
0x0043a2:	str     	r1, [sp]
0x0043a4:	str     	r1, [sp, #4]
0x0043a6:	movs    	r1, #0xe1
0x0043a8:	movs    	r2, #0x52
0x0043aa:	movs    	r0, #0xf1
0x0043ac:	adds    	r3, r4, #0
0x0043ae:	lsls    	r0, r0, #9
0x0043b0:	bl      	#0x39a8
0x0043b4:	movs    	r2, #0
0x0043b6:	movs    	r1, #0
0x0043b8:	str     	r2, [sp, #8]
0x0043ba:	adds    	r3, r5, #0
0x0043bc:	adds    	r2, r0, #0
0x0043be:	str     	r1, [sp]
0x0043c0:	str     	r1, [sp, #4]
0x0043c2:	movs    	r1, #0x27
0x0043c4:	movs    	r0, #0xf1
0x0043c6:	lsls    	r0, r0, #9
0x0043c8:	bl      	#0x39a8
0x0043cc:	movs    	r1, #0
0x0043ce:	str     	r1, [sp]
0x0043d0:	str     	r1, [sp, #4]
0x0043d2:	movs    	r2, #0
0x0043d4:	str     	r2, [sp, #8]
0x0043d6:	movs    	r3, #0xc
0x0043d8:	ldrsh   	r2, [r0, r3]
0x0043da:	adds    	r5, r0, #0
0x0043dc:	adds    	r3, r0, #0
0x0043de:	movs    	r0, #0xf1
0x0043e0:	movs    	r1, #0x8b
0x0043e2:	lsls    	r0, r0, #9
0x0043e4:	bl      	#0x39a8
0x0043e8:	movs    	r2, #0
0x0043ea:	movs    	r1, #0
0x0043ec:	ldr     	r3, [pc, #0x108]
0x0043ee:	str     	r1, [sp]
0x0043f0:	str     	r1, [sp, #4]
0x0043f2:	str     	r2, [sp, #8]
0x0043f4:	add     	r3, pc
0x0043f6:	adds    	r2, r0, #0
0x0043f8:	movs    	r0, #0xf1
0x0043fa:	movs    	r1, #0x35
0x0043fc:	lsls    	r0, r0, #9
0x0043fe:	bl      	#0x39a8
0x004402:	movs    	r1, #0
0x004404:	adds    	r6, r0, #0
0x004406:	movs    	r2, #0
0x004408:	str     	r2, [sp, #8]
0x00440a:	str     	r1, [sp]
0x00440c:	str     	r1, [sp, #4]
0x00440e:	movs    	r1, #0xe1
0x004410:	movs    	r2, #0x52
0x004412:	movs    	r0, #0xf1
0x004414:	adds    	r3, r4, #0
0x004416:	lsls    	r0, r0, #9
0x004418:	bl      	#0x39a8
0x00441c:	movs    	r2, #0
0x00441e:	movs    	r1, #0
0x004420:	str     	r2, [sp, #8]
0x004422:	adds    	r3, r5, #0
0x004424:	adds    	r2, r0, #0
0x004426:	str     	r1, [sp]
0x004428:	str     	r1, [sp, #4]
0x00442a:	movs    	r1, #0x8d
0x00442c:	movs    	r0, #0xf1
0x00442e:	lsls    	r0, r0, #9
0x004430:	bl      	#0x39a8
0x004434:	movs    	r1, #0
0x004436:	movs    	r2, #0
0x004438:	str     	r2, [sp, #8]
0x00443a:	str     	r1, [sp]
0x00443c:	str     	r1, [sp, #4]
0x00443e:	adds    	r3, r4, #0
0x004440:	adds    	r2, r5, #0
0x004442:	movs    	r1, #0x8c
0x004444:	movs    	r0, #0xf1
0x004446:	lsls    	r0, r0, #9
0x004448:	bl      	#0x39a8
0x00444c:	movs    	r1, #0
0x00444e:	movs    	r2, #0
0x004450:	str     	r2, [sp, #8]
0x004452:	str     	r1, [sp]
0x004454:	str     	r1, [sp, #4]
0x004456:	movs    	r1, #0x14
0x004458:	movs    	r2, #0x20
0x00445a:	adds    	r3, r4, #0
0x00445c:	movs    	r0, #0xf1
0x00445e:	lsls    	r0, r0, #9
0x004460:	bl      	#0x39a8
0x004464:	movs    	r1, #0
0x004466:	movs    	r2, #0
0x004468:	str     	r2, [sp, #8]
0x00446a:	str     	r1, [sp]
0x00446c:	str     	r1, [sp, #4]
0x00446e:	movs    	r1, #0x14
0x004470:	movs    	r2, #0xdc
0x004472:	adds    	r3, r4, #0
0x004474:	movs    	r0, #0xf1
0x004476:	lsls    	r0, r0, #9
0x004478:	bl      	#0x39a8
0x00447c:	movs    	r1, #0
0x00447e:	movs    	r2, #0
0x004480:	str     	r2, [sp, #8]
0x004482:	str     	r1, [sp]
0x004484:	str     	r1, [sp, #4]
0x004486:	movs    	r1, #0x14
0x004488:	movs    	r2, #0xdd
0x00448a:	adds    	r3, r4, #0
0x00448c:	movs    	r0, #0xf1
0x00448e:	lsls    	r0, r0, #9
0x004490:	bl      	#0x39a8
0x004494:	movs    	r1, #0
0x004496:	movs    	r2, #0
0x004498:	str     	r2, [sp, #8]
0x00449a:	str     	r1, [sp]
0x00449c:	str     	r1, [sp, #4]
0x00449e:	movs    	r1, #0x14
0x0044a0:	movs    	r2, #0xde
0x0044a2:	adds    	r3, r4, #0
0x0044a4:	movs    	r0, #0xf1
0x0044a6:	lsls    	r0, r0, #9
0x0044a8:	bl      	#0x39a8
0x0044ac:	movs    	r1, #0

; ===== candidate_004508 =====
0x004508:	push    	{r3, r4, r5, r7}
0x00450a:	movs    	r0, r0
0x00450c:	udf     	#0xce
0x00450e:	bvs     	#0x4488
0x004510:	push    	{r3, r4, r5, r7}
0x004512:	stm     	r0!, {r0, r2, r4, r5, r7}
0x004514:	svc     	#0xbe
0x004516:	ldm     	r1, {r0, r1, r2, r3, r4, r5, r7}
0x004518:	stm     	r3!, {r0, r1, r4, r6, r7}
0x00451a:	add     	r4, sp, #0x28c
0x00451c:	rsb     	r0, r7, r7, lsl #15

; ===== candidate_004510 =====
0x004510:	push    	{r3, r4, r5, r7}
0x004512:	stm     	r0!, {r0, r2, r4, r5, r7}
0x004514:	svc     	#0xbe
0x004516:	ldm     	r1, {r0, r1, r2, r3, r4, r5, r7}
0x004518:	stm     	r3!, {r0, r1, r4, r6, r7}
0x00451a:	add     	r4, sp, #0x28c
0x00451c:	rsb     	r0, r7, r7, lsl #15

; ===== candidate_00452e =====
0x00452e:	push    	{r2, r3, r6, r7, lr}
0x004530:	cmp     	r7, #0xea

; ===== candidate_004544 =====
0x004544:	push    	{r3, r4, r5, r7}
0x004546:	adr     	r1, #0x28c
0x004548:	movs    	r0, r0
0x00454a:	movs    	r0, r0
0x00454c:	sub     	sp, #0x15c

; ===== candidate_004570 =====
0x004570:	push    	{r5, lr}
0x004572:	cbnz    	r4, #0x45e6
0x004574:	pop     	{r1, r3, r4, r5, r6, r7}
0x004576:	ldm     	r1, {r0, r1, r2, r4, r6, r7}
0x004578:	stm     	r6!, {r2, r3, r6, r7}
0x00457a:	lsls    	r4, r1, #3
0x00457c:	add     	r0, sp, #0x330
0x00457e:	movs    	r0, r0
0x004580:	add     	r0, sp, #0x330

; ===== candidate_0045c0 =====
0x0045c0:	push    	{r0, r1, r2, r4, r6, r7}
0x0045c2:	add     	r4, sp, #0x330
0x0045c4:	bl      	#0xff0cef68
0x0045c8:	movs    	r0, r0
0x0045ca:	movs    	r0, r0

; ===== candidate_0045da =====
0x0045da:	push    	{r3, r4, r5, r7}

; ===== candidate_0046cc =====
0x0046cc:	push    	{r1, r2, r3, r6, r7}
0x0046ce:	b       	#0x4c4c
0x0046d0:	str.w   	sl, [fp, #0xca3]
0x0046d4:	rsb     	r5, r7, r8, lsl #11
0x0046d8:	ldm     	r1, {r0, r1, r5}
0x0046da:	cbz     	r4, #0x4750
0x0046dc:	cmp     	r7, #0xc7

; ===== candidate_004724 =====
0x004724:	push    	{r0, r4, r5, r6, r7, lr}
0x004726:	cmp     	r2, #0xc3
0x004728:	bkpt    	#0xa1
0x00472a:	bhi     	#0x46c6
0x00472c:	add     	r0, sp, #0x2d8
0x00472e:	stm     	r4!, {r1, r4, r5, r7}
0x004730:	ldm     	r7, {r0, r6, r7}
0x004732:	itttt   	ge
0x004734:	cmpge   	r4, #0x2f
0x004736:	cbnz    	r3, #0x4782
0x004738:	popge   	{r1, r3, r4, r5, r6, r7}
0x00473a:	ldmge   	r7, {r0, r1, r2, r4, r6, r7}
0x00473c:	ldm     	r2!, {r0, r1, r3, r4, r5, r6, r7}
0x00473e:	cmp     	r7, #0xa7
0x004740:	ldm     	r2, {r2, r3, r5}
