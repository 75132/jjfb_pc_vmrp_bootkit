; fallback candidate disassembly from Thumb prologues; true code is ARM entry + Thumb functions.

; ARM entry
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0x7db8
0x000018:	pop     	{r4, pc}
0x00001c:	andeq   	r4, r0, r8, ror r7
0x000020:	ands    	r2, r0, #128, #8
0x000024:	rsbmi   	r0, r0, #0
0x000028:	eors    	r3, r2, r1, asr #32
0x00002c:	rsbhs   	r1, r1, #0
0x000030:	rsbs    	ip, r0, r1, lsr #3
0x000034:	blo     	#0xbc
0x000038:	rsbs    	ip, r0, r1, lsr #8
0x00003c:	blo     	#0x80
0x000040:	lsl     	r0, r0, #8
0x000044:	orr     	r2, r2, #0xff000000
0x000048:	rsbs    	ip, r0, r1, lsr #4
0x00004c:	blo     	#0xb0
0x000050:	rsbs    	ip, r0, r1, lsr #8
0x000054:	blo     	#0x80
0x000058:	lsl     	r0, r0, #8
0x00005c:	orr     	r2, r2, #0xff0000
0x000060:	rsbs    	ip, r0, r1, lsr #8
0x000064:	lslhs   	r0, r0, #8
0x000068:	orrhs   	r2, r2, #0xff00
0x00006c:	rsbs    	ip, r0, r1, lsr #4
0x000070:	blo     	#0xb0
0x000074:	rsbs    	ip, r0, #0
0x000078:	bhs     	#0xf8
0x00007c:	lsrhs   	r0, r0, #8
0x000080:	rsbs    	ip, r0, r1, lsr #7
0x000084:	subhs   	r1, r1, r0, lsl #7
0x000088:	adc     	r2, r2, r2
0x00008c:	rsbs    	ip, r0, r1, lsr #6
0x000090:	subhs   	r1, r1, r0, lsl #6
0x000094:	adc     	r2, r2, r2
0x000098:	rsbs    	ip, r0, r1, lsr #5
0x00009c:	subhs   	r1, r1, r0, lsl #5
0x0000a0:	adc     	r2, r2, r2
0x0000a4:	rsbs    	ip, r0, r1, lsr #4
0x0000a8:	subhs   	r1, r1, r0, lsl #4
0x0000ac:	adc     	r2, r2, r2
0x0000b0:	rsbs    	ip, r0, r1, lsr #3
0x0000b4:	subhs   	r1, r1, r0, lsl #3
0x0000b8:	adc     	r2, r2, r2
0x0000bc:	rsbs    	ip, r0, r1, lsr #2
0x0000c0:	subhs   	r1, r1, r0, lsl #2
0x0000c4:	adc     	r2, r2, r2
0x0000c8:	rsbs    	ip, r0, r1, lsr #1
0x0000cc:	subhs   	r1, r1, r0, lsl #1
0x0000d0:	adc     	r2, r2, r2
0x0000d4:	rsbs    	ip, r0, r1
0x0000d8:	subhs   	r1, r1, r0
0x0000dc:	adcs    	r2, r2, r2
0x0000e0:	bhs     	#0x7c
0x0000e4:	eors    	r0, r2, r3, asr #31
0x0000e8:	add     	r0, r0, r3, lsr #31
0x0000ec:	rsbhs   	r1, r1, #0
0x0000f0:	bx      	lr
0x0000f4:	andeq   	r4, r0, r8, ror r7
0x0000f8:	mov     	r0, #2
0x0000fc:	mov     	r1, #2
0x000100:	b       	#0x118
0x000104:	strmi   	r4, [r8, -r0, lsl #14]

; ===== candidate_000008 =====
0x000008:	ands    	r0, r2
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	subs    	r7, r4, #5

; ===== candidate_00000a =====
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	subs    	r7, r4, #5

; ===== candidate_00011a =====
0x00011a:	stmdb   	sp!, {r2}

; ===== candidate_000134 =====
0x000134:	push    	{r4, r5, r6, lr}
0x000136:	ldr     	r6, [pc, #0x38]
0x000138:	adds    	r5, r1, #0
0x00013a:	adds    	r1, r0, #0
0x00013c:	adds    	r4, r0, #0
0x00013e:	add     	r6, pc
0x000140:	adds    	r0, r6, #0
0x000142:	bl      	#0x146
0x000146:	adds    	r2, r0, #0
0x000148:	cmp     	r0, r6
0x00014a:	bne     	#0x15a
0x00014c:	adds    	r1, r5, #0
0x00014e:	adds    	r0, r4, #0
0x000150:	bl      	#0x194
0x000154:	pop     	{r4, r5, r6}
0x000156:	pop     	{r3}
0x000158:	bx      	r3
0x00015a:	ldr     	r0, [pc, #0x18]
0x00015c:	add     	r0, pc
0x00015e:	cmp     	r2, r0
0x000160:	beq     	#0x16a
0x000162:	adds    	r1, r5, #0
0x000164:	adds    	r0, r4, #0
0x000166:	bl      	#0x108
0x00016a:	movs    	r0, #0
0x00016c:	b       	#0x154
0x00016e:	movs    	r0, r0
0x000170:	mcr2    	p15, #6, pc, c5, c7, #7
0x000174:	mcr2    	p15, #5, pc, c5, c7, #7
0x000178:	bx      	pc

; ===== candidate_000194 =====
0x000194:	push    	{r3, r4, r5, lr}
0x000196:	subs    	r2, r0, #1
0x000198:	cmp     	r2, #0xd
0x00019a:	adr     	r4, #0x90
0x00019c:	bhs     	#0x1ec
0x00019e:	movs    	r2, #0x17
0x0001a0:	ldr     	r3, [pc, #0x8c]
0x0001a2:	muls    	r2, r0, r2
0x0001a4:	add     	r3, pc
0x0001a6:	adds    	r5, r2, r3
0x0001a8:	subs    	r5, #0x17
0x0001aa:	cmp     	r0, #2
0x0001ac:	bne     	#0x1d8
0x0001ae:	lsls    	r0, r1, #5
0x0001b0:	bpl     	#0x1b6
0x0001b2:	adr     	r4, #0x80
0x0001b4:	b       	#0x1ee
0x0001b6:	ldr     	r0, [pc, #0x90]
0x0001b8:	ands    	r0, r1
0x0001ba:	beq     	#0x1c0
0x0001bc:	adr     	r4, #0x8c
0x0001be:	b       	#0x1ee
0x0001c0:	lsls    	r0, r1, #3
0x0001c2:	bpl     	#0x1c8
0x0001c4:	adr     	r4, #0x94
0x0001c6:	b       	#0x1ee
0x0001c8:	lsls    	r0, r1, #2
0x0001ca:	bpl     	#0x1d0
0x0001cc:	adr     	r4, #0x98
0x0001ce:	b       	#0x1ee
0x0001d0:	lsls    	r0, r1, #1
0x0001d2:	bpl     	#0x1ee
0x0001d4:	adr     	r4, #0x9c
0x0001d6:	b       	#0x1ee
0x0001d8:	cmp     	r0, #8
0x0001da:	bne     	#0x1e0
0x0001dc:	adds    	r4, r1, #0
0x0001de:	b       	#0x1ee
0x0001e0:	cmp     	r0, #9
0x0001e2:	bne     	#0x1ee
0x0001e4:	cmp     	r1, #1
0x0001e6:	bne     	#0x1ee
0x0001e8:	adr     	r5, #0x98
0x0001ea:	b       	#0x1ee
0x0001ec:	adr     	r5, #0xac
0x0001ee:	movs    	r0, #0xa
0x0001f0:	bl      	#0x2b4
0x0001f4:	ldrb    	r0, [r5]
0x0001f6:	cmp     	r0, #0
0x0001f8:	beq     	#0x208
0x0001fa:	ldrb    	r0, [r5]
0x0001fc:	adds    	r5, #1
0x0001fe:	bl      	#0x2b4
0x000202:	ldrb    	r0, [r5]
0x000204:	cmp     	r0, #0
0x000206:	bne     	#0x1fa
0x000208:	ldrb    	r0, [r4]
0x00020a:	cmp     	r0, #0
0x00020c:	beq     	#0x21c
0x00020e:	ldrb    	r0, [r4]
0x000210:	adds    	r4, #1
0x000212:	bl      	#0x2b4
0x000216:	ldrb    	r0, [r4]
0x000218:	cmp     	r0, #0
0x00021a:	bne     	#0x20e
0x00021c:	movs    	r0, #0xa
0x00021e:	bl      	#0x2b4
0x000222:	pop     	{r3, r4, r5}
0x000224:	pop     	{r3}
0x000226:	movs    	r0, #1
0x000228:	bx      	r3
0x00022a:	movs    	r0, r0
0x00022c:	movs    	r0, r0
0x00022e:	movs    	r0, r0

; ===== candidate_0002b4 =====
0x0002b4:	push    	{r3, lr}
0x0002b6:	add     	r3, sp, #0
0x0002b8:	strb    	r0, [r3]
0x0002ba:	movs    	r0, #3
0x0002bc:	mov     	r1, sp
0x0002be:	svc     	#0xab
0x0002c0:	add     	sp, #4
0x0002c2:	pop     	{r3}
0x0002c4:	bx      	r3
0x0002c6:	movs    	r0, r0
0x0002c8:	movs    	r0, r1
0x0002ca:	b       	#0xfffffe0c
0x0002cc:	asrs    	r0, r1, #0x20
0x0002ce:	b       	#0xfffffe10
0x0002d0:	movs    	r1, r0
0x0002d2:	b       	#0x3d6
0x0002d4:	vrhadd.u16	d14, d14, d31
0x0002d8:	movs    	r4, r1
0x0002da:	movs    	r0, r0
0x0002dc:	lsls    	r4, r0, #9
0x0002de:	movs    	r0, r0
0x0002e0:	str     	r0, [sp]
0x0002e2:	b       	#0x626
0x0002e4:	vrhadd.u16	d14, d14, d31
0x0002e8:	push    	{r4, r5, r6, r7, lr}
0x0002ea:	sub     	sp, #0xc
0x0002ec:	movs    	r1, #0
0x0002ee:	str     	r1, [sp]
0x0002f0:	str     	r1, [sp, #4]
0x0002f2:	ldr     	r5, [pc, #0x104]
0x0002f4:	movs    	r2, #0
0x0002f6:	movs    	r7, #0xf1
0x0002f8:	lsls    	r7, r7, #9
0x0002fa:	str     	r2, [sp, #8]
0x0002fc:	movs    	r1, #0x11
0x0002fe:	adds    	r4, r0, #0
0x000300:	movs    	r3, #4
0x000302:	add     	r5, sb
0x000304:	ldr     	r2, [r5, #0xc]
0x000306:	adds    	r0, r7, #0
0x000308:	bl      	#0x7e90
0x00030c:	adds    	r3, r0, #0
0x00030e:	movs    	r6, #0
0x000310:	cmp     	r4, #0x11
0x000312:	beq     	#0x34a
0x000314:	bgt     	#0x342
0x000316:	cmp     	r4, #0
0x000318:	beq     	#0x33e
0x00031a:	ldr     	r0, [pc, #0xdc]
0x00031c:	add     	r0, sb
0x00031e:	adds    	r0, #0x58
0x000320:	cmp     	r4, #0xc
0x000322:	beq     	#0x35e
0x000324:	cmp     	r4, #0xd
0x000326:	bne     	#0x392
0x000328:	movs    	r2, #0
0x00032a:	movs    	r1, #1
0x00032c:	str     	r1, [sp, #4]
0x00032e:	str     	r2, [sp, #8]
0x000330:	str     	r0, [sp]
0x000332:	adds    	r0, r7, #0
0x000334:	adds    	r2, r3, #0
0x000336:	movs    	r1, #0x29
0x000338:	adds    	r3, r6, #0
0x00033a:	bl      	#0x7e90
0x00033e:	add     	sp, #0xc
0x000340:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0002e8 =====
0x0002e8:	push    	{r4, r5, r6, r7, lr}
0x0002ea:	sub     	sp, #0xc
0x0002ec:	movs    	r1, #0
0x0002ee:	str     	r1, [sp]
0x0002f0:	str     	r1, [sp, #4]
0x0002f2:	ldr     	r5, [pc, #0x104]
0x0002f4:	movs    	r2, #0
0x0002f6:	movs    	r7, #0xf1
0x0002f8:	lsls    	r7, r7, #9
0x0002fa:	str     	r2, [sp, #8]
0x0002fc:	movs    	r1, #0x11
0x0002fe:	adds    	r4, r0, #0
0x000300:	movs    	r3, #4
0x000302:	add     	r5, sb
0x000304:	ldr     	r2, [r5, #0xc]
0x000306:	adds    	r0, r7, #0
0x000308:	bl      	#0x7e90
0x00030c:	adds    	r3, r0, #0
0x00030e:	movs    	r6, #0
0x000310:	cmp     	r4, #0x11
0x000312:	beq     	#0x34a
0x000314:	bgt     	#0x342
0x000316:	cmp     	r4, #0
0x000318:	beq     	#0x33e
0x00031a:	ldr     	r0, [pc, #0xdc]
0x00031c:	add     	r0, sb
0x00031e:	adds    	r0, #0x58
0x000320:	cmp     	r4, #0xc
0x000322:	beq     	#0x35e
0x000324:	cmp     	r4, #0xd
0x000326:	bne     	#0x392
0x000328:	movs    	r2, #0
0x00032a:	movs    	r1, #1
0x00032c:	str     	r1, [sp, #4]
0x00032e:	str     	r2, [sp, #8]
0x000330:	str     	r0, [sp]
0x000332:	adds    	r0, r7, #0
0x000334:	adds    	r2, r3, #0
0x000336:	movs    	r1, #0x29
0x000338:	adds    	r3, r6, #0
0x00033a:	bl      	#0x7e90
0x00033e:	add     	sp, #0xc
0x000340:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0003fc =====
0x0003fc:	push    	{r4, r5, r6, r7, lr}
0x0003fe:	sub     	sp, #0xc
0x000400:	adds    	r5, r0, #0
0x000402:	ldr     	r0, [pc, #0x310]
0x000404:	movs    	r1, #0
0x000406:	movs    	r2, #0
0x000408:	str     	r2, [sp, #8]
0x00040a:	str     	r1, [sp]
0x00040c:	str     	r1, [sp, #4]
0x00040e:	add     	r0, sb
0x000410:	ldr     	r0, [r0, #0x50]
0x000412:	movs    	r1, #0x11
0x000414:	ldr     	r2, [r0]
0x000416:	movs    	r0, #0xf1
0x000418:	movs    	r3, #4
0x00041a:	lsls    	r0, r0, #9
0x00041c:	bl      	#0x7e90
0x000420:	adds    	r4, r0, #0
0x000422:	subs    	r5, #2
0x000424:	cmp     	r5, #0x13
0x000426:	bhs     	#0x472
0x000428:	adr     	r3, #4
0x00042a:	ldrb    	r3, [r3, r5]
0x00042c:	lsls    	r3, r3, #1
0x00042e:	add     	pc, r3
0x000430:	movs    	r0, #9
0x000432:	ldr     	r2, [pc, #0x24]
0x000434:	movs    	r0, #0x22
0x000436:	movs    	r0, #0x22
0x000438:	movs    	r0, #0x20
0x00043a:	movs    	r2, #9
0x00043c:	movs    	r2, #9
0x00043e:	ldr     	r2, [pc, #0x80]
0x000440:	movs    	r0, #0x3a
0x000442:	lsls    	r2, r1, #1
0x000444:	ldr     	r5, [pc, #0x2cc]
0x000446:	movs    	r1, #0
0x000448:	add     	r5, sb
0x00044a:	adds    	r5, #0x2c
0x00044c:	str     	r1, [sp, #4]
0x00044e:	movs    	r2, #0
0x000450:	ldr     	r4, [pc, #0x2c0]
0x000452:	str     	r2, [sp, #8]
0x000454:	str     	r5, [sp]
0x000456:	add     	r4, sb
0x000458:	ldr     	r2, [r4, #0x60]
0x00045a:	movs    	r1, #0x29
0x00045c:	movs    	r0, #0xf1
0x00045e:	lsls    	r0, r0, #9
0x000460:	ldr     	r3, [r4, #0x5c]
0x000462:	bl      	#0x7e90
0x000466:	adds    	r1, r5, #0
0x000468:	ldr     	r2, [r4, #0x5c]
0x00046a:	ldr     	r3, [r4, #0x60]
0x00046c:	movs    	r0, #0
0x00046e:	bl      	#0xc60
0x000472:	add     	sp, #0xc
0x000474:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000720 =====
0x000720:	push    	{r4, r5, r6, r7, lr}
0x000722:	sub     	sp, #0x14
0x000724:	adds    	r4, r0, #0
0x000726:	ldr     	r0, [pc, #0x1ac]
0x000728:	movs    	r1, #0
0x00072a:	movs    	r2, #0
0x00072c:	str     	r2, [sp, #8]
0x00072e:	str     	r1, [sp]
0x000730:	str     	r1, [sp, #4]
0x000732:	add     	r0, sb
0x000734:	ldr     	r0, [r0, #0x50]
0x000736:	movs    	r1, #0x11
0x000738:	ldr     	r2, [r0]
0x00073a:	movs    	r0, #0xf1
0x00073c:	movs    	r3, #4
0x00073e:	lsls    	r0, r0, #9
0x000740:	bl      	#0x7e90
0x000744:	subs    	r4, #2
0x000746:	cmp     	r4, #0x13
0x000748:	bhs     	#0x78a
0x00074a:	adr     	r3, #8
0x00074c:	ldrb    	r3, [r3, r4]
0x00074e:	lsls    	r3, r3, #1
0x000750:	add     	pc, r3
0x000752:	movs    	r0, r0
0x000754:	subs    	r2, r1, r4
0x000756:	add     	r1, sp, #0xbc
0x000758:	subs    	r4, r7, r4
0x00075a:	subs    	r5, r3, r4
0x00075c:	subs    	r3, r3, r4
0x00075e:	adds    	r2, r1, #4
0x000760:	subs    	r4, #0x2f
0x000762:	mov     	r3, r3
0x000764:	subs    	r3, r7, r6
0x000766:	lsls    	r1, r5, #2
0x000768:	ldr     	r2, [pc, #0x168]
0x00076a:	add     	r2, sb
0x00076c:	ldr     	r1, [r2, #0x34]
0x00076e:	subs    	r1, #1
0x000770:	str     	r1, [r2, #0x34]
0x000772:	bpl     	#0x77a
0x000774:	lsls    	r1, r0, #1
0x000776:	subs    	r1, #1
0x000778:	str     	r1, [r2, #0x34]
0x00077a:	ldr     	r1, [pc, #0x158]
0x00077c:	lsls    	r3, r0, #1
0x00077e:	add     	r1, sb
0x000780:	adds    	r1, #0x34
0x000782:	movs    	r2, #0
0x000784:	movs    	r0, #0
0x000786:	bl      	#0xc60
0x00078a:	add     	sp, #0x14
0x00078c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00093c =====
0x00093c:	push    	{r4, r5, lr}
0x00093e:	ldr     	r4, [pc, #0xb4]
0x000940:	movs    	r2, #0x1c
0x000942:	add     	r4, pc
0x000944:	ldr     	r0, [r4, #0x38]
0x000946:	movs    	r1, #0
0x000948:	ldr     	r3, [r0, #0x38]
0x00094a:	ldr     	r0, [pc, #0xac]
0x00094c:	sub     	sp, #0xc
0x00094e:	add     	r0, sb
0x000950:	blx     	r3
0x000952:	movs    	r2, #0
0x000954:	movs    	r0, #0
0x000956:	str     	r0, [sp]
0x000958:	ldr     	r1, [pc, #0x9c]
0x00095a:	movs    	r3, #0
0x00095c:	add     	r1, sb
0x00095e:	str     	r1, [sp, #4]
0x000960:	movs    	r1, #0x64
0x000962:	movs    	r0, #1
0x000964:	str     	r2, [sp, #8]
0x000966:	bl      	#0x7e90
0x00096a:	ldr     	r1, [pc, #0x8c]
0x00096c:	movs    	r0, #0
0x00096e:	add     	r1, sb
0x000970:	subs    	r1, #0x7c
0x000972:	str     	r0, [r1, #8]
0x000974:	ldr     	r5, [pc, #0x80]
0x000976:	str     	r0, [r1, #0x10]
0x000978:	str     	r0, [r1, #0xc]
0x00097a:	add     	r5, sb
0x00097c:	subs    	r5, #0xfc
0x00097e:	movs    	r0, #1
0x000980:	str     	r0, [r5, #0x18]
0x000982:	ldr     	r0, [r4, #0x38]
0x000984:	ldr     	r2, [pc, #0x74]
0x000986:	ldr     	r1, [r0, #0x68]
0x000988:	add     	r2, sb
0x00098a:	str     	r1, [r5, #0x2c]
0x00098c:	ldr     	r1, [r0, #0xc]
0x00098e:	ldr     	r4, [pc, #0x70]
0x000990:	str     	r1, [r5, #0x30]
0x000992:	ldr     	r1, [r0, #0x10]
0x000994:	str     	r1, [r5, #0x34]
0x000996:	ldr     	r1, [r0, #0x14]
0x000998:	str     	r1, [r5, #0x38]
0x00099a:	ldr     	r1, [r0, #0x18]
0x00099c:	str     	r1, [r5, #0x3c]
0x00099e:	ldr     	r1, [r0, #0x1c]
0x0009a0:	str     	r1, [r5, #0x40]
0x0009a2:	ldr     	r1, [r0, #0x20]
0x0009a4:	str     	r1, [r5, #0x44]
0x0009a6:	ldr     	r1, [r0, #0x24]
0x0009a8:	str     	r1, [r5, #0x48]
0x0009aa:	ldr     	r1, [r0, #0x28]
0x0009ac:	str     	r1, [r5, #0x4c]
0x0009ae:	ldr     	r1, [r0, #0x2c]
0x0009b0:	str     	r1, [r5, #0x50]
0x0009b2:	ldr     	r1, [r0, #0x30]
0x0009b4:	str     	r1, [r5, #0x54]
0x0009b6:	ldr     	r1, [r0, #0x34]
0x0009b8:	str     	r1, [r5, #0x58]
0x0009ba:	ldr     	r1, [r0, #0x38]
0x0009bc:	str     	r1, [r5, #0x5c]
0x0009be:	ldr     	r1, [r0, #0x3c]
0x0009c0:	str     	r1, [r5, #0x60]
0x0009c2:	ldr     	r1, [r0, #0x40]
0x0009c4:	str     	r1, [r5, #0x64]
0x0009c6:	ldr     	r1, [r0, #0x44]
0x0009c8:	str     	r1, [r5, #0x68]
0x0009ca:	ldr     	r1, [r0, #0x48]
0x0009cc:	str     	r1, [r5, #0x6c]
0x0009ce:	ldr     	r1, [r0, #0x4c]
0x0009d0:	str     	r1, [r5, #0x70]
0x0009d2:	movs    	r1, #0
0x0009d4:	str     	r1, [r2]
0x0009d6:	movs    	r1, #1
0x0009d8:	lsls    	r1, r1, #9
0x0009da:	adds    	r0, r0, r1
0x0009dc:	ldr     	r3, [r0, #8]
0x0009de:	movs    	r1, #7
0x0009e0:	adds    	r2, r4, #0
0x0009e2:	movs    	r0, #0
0x0009e4:	blx     	r3
0x0009e6:	cmp     	r0, r4
0x0009e8:	bne     	#0x9ee
0x0009ea:	subs    	r0, #2
0x0009ec:	str     	r0, [r5, #0x28]
0x0009ee:	add     	sp, #0xc
0x0009f0:	pop     	{r4, r5, pc}

; ===== candidate_000a04 =====
0x000a04:	push    	{r4, r5, r6, r7, lr}
0x000a06:	ldr     	r3, [r0, #0x18]
0x000a08:	adds    	r6, r0, #0
0x000a0a:	adds    	r5, r1, #0
0x000a0c:	movs    	r4, #0
0x000a0e:	cmp     	r3, #0
0x000a10:	sub     	sp, #0xc
0x000a12:	beq     	#0xa72
0x000a14:	movs    	r2, #0
0x000a16:	movs    	r1, #0
0x000a18:	str     	r2, [sp, #8]
0x000a1a:	adds    	r2, r3, #0
0x000a1c:	str     	r1, [sp]
0x000a1e:	str     	r1, [sp, #4]
0x000a20:	movs    	r1, #0x26
0x000a22:	movs    	r3, #0
0x000a24:	movs    	r0, #0xf1
0x000a26:	lsls    	r0, r0, #9
0x000a28:	bl      	#0x7e90
0x000a2c:	adds    	r7, r0, #0
0x000a2e:	cmp     	r0, #0
0x000a30:	ble     	#0xa7c
0x000a32:	movs    	r1, #0
0x000a34:	str     	r1, [sp]
0x000a36:	str     	r1, [sp, #4]
0x000a38:	movs    	r2, #0
0x000a3a:	str     	r2, [sp, #8]
0x000a3c:	movs    	r1, #0x27
0x000a3e:	adds    	r3, r4, #0
0x000a40:	movs    	r0, #0xf1
0x000a42:	lsls    	r0, r0, #9
0x000a44:	ldr     	r2, [r6, #0x18]
0x000a46:	bl      	#0x7e90
0x000a4a:	ldr     	r1, [r0]
0x000a4c:	ldr     	r2, [r5]
0x000a4e:	cmp     	r1, r2
0x000a50:	bne     	#0xa76
0x000a52:	ldr     	r1, [r0, #4]
0x000a54:	ldr     	r2, [r5, #4]
0x000a56:	movs    	r3, #0
0x000a58:	adds    	r1, r1, r2
0x000a5a:	str     	r1, [r0, #4]
0x000a5c:	movs    	r1, #0
0x000a5e:	movs    	r2, #0
0x000a60:	str     	r2, [sp, #8]
0x000a62:	str     	r1, [sp]
0x000a64:	str     	r1, [sp, #4]
0x000a66:	movs    	r1, #9
0x000a68:	adds    	r2, r5, #0
0x000a6a:	movs    	r0, #0xf1
0x000a6c:	lsls    	r0, r0, #9
0x000a6e:	bl      	#0x7e90
0x000a72:	add     	sp, #0xc
0x000a74:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000a9a =====
0x000a9a:	push    	{r3, lr}
0x000a9c:	movs    	r3, #0x12
0x000a9e:	add     	r1, sb
0x000aa0:	ldrsb   	r2, [r1, r3]
0x000aa2:	cmp     	r2, #1
0x000aa4:	bne     	#0xab0
0x000aa6:	cmp     	r0, #0x12
0x000aa8:	bne     	#0xab0
0x000aaa:	movs    	r0, #0
0x000aac:	strb    	r0, [r1, #0x12]
0x000aae:	pop     	{r3, pc}

; ===== candidate_000af4 =====
0x000af4:	push    	{r4, r5, r6, r7, lr}
0x000af6:	sub     	sp, #0xc
0x000af8:	movs    	r1, #0
0x000afa:	str     	r1, [sp]
0x000afc:	str     	r1, [sp, #4]
0x000afe:	ldr     	r6, [pc, #0xb0]
0x000b00:	movs    	r2, #0
0x000b02:	movs    	r4, #0xf1
0x000b04:	lsls    	r4, r4, #9
0x000b06:	str     	r2, [sp, #8]
0x000b08:	movs    	r1, #0x11
0x000b0a:	adds    	r5, r0, #0
0x000b0c:	movs    	r3, #4
0x000b0e:	add     	r6, sb
0x000b10:	ldr     	r2, [r6, #0x58]
0x000b12:	adds    	r0, r4, #0
0x000b14:	bl      	#0x7e90
0x000b18:	adds    	r7, r0, #0
0x000b1a:	ldr     	r0, [pc, #0x94]
0x000b1c:	adds    	r1, r5, #0
0x000b1e:	add     	r0, sb
0x000b20:	adds    	r0, #0x3c
0x000b22:	movs    	r5, #0
0x000b24:	cmp     	r1, #0xd
0x000b26:	beq     	#0xb66
0x000b28:	bgt     	#0xb54
0x000b2a:	cmp     	r1, #2
0x000b2c:	beq     	#0xb3a
0x000b2e:	cmp     	r1, #5
0x000b30:	beq     	#0xb60
0x000b32:	cmp     	r1, #8
0x000b34:	beq     	#0xb66
0x000b36:	cmp     	r1, #0xc
0x000b38:	bne     	#0xb50
0x000b3a:	movs    	r2, #0
0x000b3c:	movs    	r1, #0
0x000b3e:	str     	r1, [sp, #4]
0x000b40:	str     	r2, [sp, #8]
0x000b42:	adds    	r2, r7, #0
0x000b44:	movs    	r1, #0x29
0x000b46:	str     	r0, [sp]
0x000b48:	adds    	r3, r5, #0
0x000b4a:	adds    	r0, r4, #0
0x000b4c:	bl      	#0x7e90
0x000b50:	add     	sp, #0xc
0x000b52:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000bb4 =====
0x000bb4:	push    	{r4, r5, r6, r7, lr}
0x000bb6:	adds    	r6, r0, #0
0x000bb8:	ldr     	r0, [pc, #0xa0]
0x000bba:	sub     	sp, #0xc
0x000bbc:	add     	r0, sb
0x000bbe:	ldr     	r0, [r0, #0x50]
0x000bc0:	movs    	r2, #0
0x000bc2:	ldr     	r1, [r0, #4]
0x000bc4:	ldr     	r0, [r0, #0x10]
0x000bc6:	movs    	r4, #0
0x000bc8:	lsls    	r0, r0, #2
0x000bca:	ldr     	r5, [r1, r0]
0x000bcc:	str     	r2, [sp, #8]
0x000bce:	movs    	r1, #0
0x000bd0:	adds    	r2, r5, #0
0x000bd2:	movs    	r5, #0xf1
0x000bd4:	str     	r1, [sp]
0x000bd6:	str     	r1, [sp, #4]
0x000bd8:	movs    	r1, #0x26
0x000bda:	lsls    	r5, r5, #9
0x000bdc:	adds    	r3, r4, #0
0x000bde:	adds    	r0, r5, #0
0x000be0:	bl      	#0x7e90
0x000be4:	adds    	r7, r0, #0
0x000be6:	ldr     	r0, [pc, #0x74]
0x000be8:	add     	r0, sb
0x000bea:	subs    	r0, #0x48
0x000bec:	cmp     	r6, #0xd
0x000bee:	beq     	#0xc2e
0x000bf0:	bgt     	#0xc1c
0x000bf2:	cmp     	r6, #2
0x000bf4:	beq     	#0xc02
0x000bf6:	cmp     	r6, #5
0x000bf8:	beq     	#0xc28
0x000bfa:	cmp     	r6, #8
0x000bfc:	beq     	#0xc2e
0x000bfe:	cmp     	r6, #0xc
0x000c00:	bne     	#0xc18
0x000c02:	movs    	r2, #0
0x000c04:	movs    	r1, #0
0x000c06:	str     	r1, [sp, #4]
0x000c08:	str     	r2, [sp, #8]
0x000c0a:	adds    	r2, r7, #0
0x000c0c:	movs    	r1, #0x29
0x000c0e:	str     	r0, [sp]
0x000c10:	adds    	r3, r4, #0
0x000c12:	adds    	r0, r5, #0
0x000c14:	bl      	#0x7e90
0x000c18:	add     	sp, #0xc
0x000c1a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000c60 =====
0x000c60:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x000c62:	adds    	r4, r1, #0
0x000c64:	sub     	sp, #0x14
0x000c66:	movs    	r1, #0
0x000c68:	adds    	r7, r2, #0
0x000c6a:	ldr     	r0, [pc, #0x84]
0x000c6c:	movs    	r2, #0
0x000c6e:	str     	r2, [sp, #8]
0x000c70:	str     	r1, [sp]
0x000c72:	str     	r1, [sp, #4]
0x000c74:	add     	r0, sb
0x000c76:	ldr     	r0, [r0, #0x50]
0x000c78:	movs    	r1, #0x11
0x000c7a:	ldr     	r2, [r0]
0x000c7c:	movs    	r0, #0xf1
0x000c7e:	movs    	r3, #4
0x000c80:	lsls    	r0, r0, #9
0x000c82:	bl      	#0x7e90
0x000c86:	str     	r0, [sp, #0xc]
0x000c88:	ldr     	r0, [r4]
0x000c8a:	bl      	#0x622c
0x000c8e:	adds    	r5, r0, #0
0x000c90:	ldr     	r1, [r4]
0x000c92:	ldr     	r0, [sp, #0xc]
0x000c94:	blx     	#0x20
0x000c98:	ldr     	r0, [sp, #0x20]
0x000c9a:	adds    	r6, r1, #0
0x000c9c:	subs    	r0, #1
0x000c9e:	str     	r0, [sp, #0x10]
0x000ca0:	b       	#0xcd8
0x000ca2:	ldr     	r0, [sp, #0x14]
0x000ca4:	cmp     	r0, #1
0x000ca6:	ldr     	r0, [r4]
0x000ca8:	bne     	#0xcb8
0x000caa:	adds    	r0, #1
0x000cac:	str     	r0, [r4]
0x000cae:	ldr     	r1, [sp, #0x20]
0x000cb0:	cmp     	r0, r1
0x000cb2:	blt     	#0xcc4
0x000cb4:	str     	r7, [r4]
0x000cb6:	b       	#0xcc4
0x000cb8:	subs    	r0, #1
0x000cba:	str     	r0, [r4]
0x000cbc:	cmp     	r0, r7
0x000cbe:	bge     	#0xcc4
0x000cc0:	ldr     	r0, [sp, #0x10]
0x000cc2:	str     	r0, [r4]
0x000cc4:	ldr     	r5, [r4]
0x000cc6:	ldr     	r0, [sp, #0xc]
0x000cc8:	adds    	r1, r5, #0
0x000cca:	blx     	#0x20
0x000cce:	adds    	r6, r1, #0
0x000cd0:	adds    	r0, r5, #0
0x000cd2:	bl      	#0x622c
0x000cd6:	adds    	r5, r0, #0
0x000cd8:	ldr     	r0, [r5]
0x000cda:	lsls    	r1, r6, #2
0x000cdc:	ldr     	r0, [r0, r1]
0x000cde:	cmp     	r0, #0
0x000ce0:	beq     	#0xca2
0x000ce2:	adds    	r0, #0x30
0x000ce4:	ldrb    	r0, [r0, #3]
0x000ce6:	cmp     	r0, #0
0x000ce8:	beq     	#0xca2
0x000cea:	add     	sp, #0x24
0x000cec:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000cf4 =====
0x000cf4:	push    	{r4, r5, r6, r7, lr}
0x000cf6:	sub     	sp, #0x24
0x000cf8:	movs    	r1, #0
0x000cfa:	movs    	r2, #0
0x000cfc:	str     	r2, [sp, #8]
0x000cfe:	str     	r1, [sp]
0x000d00:	str     	r1, [sp, #4]
0x000d02:	movs    	r7, #0xf1
0x000d04:	movs    	r5, #0
0x000d06:	adds    	r3, r5, #0
0x000d08:	lsls    	r7, r7, #9
0x000d0a:	movs    	r1, #0x44
0x000d0c:	adds    	r2, r0, #0
0x000d0e:	movs    	r6, #0
0x000d10:	adds    	r4, r0, #0
0x000d12:	adds    	r0, r7, #0
0x000d14:	bl      	#0x7e90
0x000d18:	movs    	r1, #0
0x000d1a:	str     	r1, [sp]
0x000d1c:	str     	r1, [sp, #4]
0x000d1e:	movs    	r2, #0
0x000d20:	str     	r2, [sp, #8]
0x000d22:	movs    	r1, #0x46
0x000d24:	adds    	r3, r5, #0
0x000d26:	adds    	r0, r7, #0
0x000d28:	ldr     	r2, [r4, #8]
0x000d2a:	bl      	#0x7e90
0x000d2e:	lsls    	r0, r0, #0x18
0x000d30:	asrs    	r0, r0, #0x18
0x000d32:	adds    	r3, r0, #1
0x000d34:	beq     	#0xd62
0x000d36:	movs    	r1, #0
0x000d38:	str     	r1, [sp]
0x000d3a:	str     	r1, [sp, #4]
0x000d3c:	movs    	r2, #0
0x000d3e:	str     	r2, [sp, #8]
0x000d40:	movs    	r1, #0x46
0x000d42:	adds    	r3, r5, #0
0x000d44:	adds    	r0, r7, #0
0x000d46:	ldr     	r2, [r4, #8]
0x000d48:	bl      	#0x7e90
0x000d4c:	movs    	r1, #0
0x000d4e:	str     	r1, [sp]
0x000d50:	str     	r1, [sp, #4]
0x000d52:	movs    	r2, #0
0x000d54:	str     	r2, [sp, #8]
0x000d56:	movs    	r1, #0x45
0x000d58:	adds    	r3, r5, #0
0x000d5a:	adds    	r0, r7, #0
0x000d5c:	ldr     	r2, [r4, #8]
0x000d5e:	bl      	#0x7e90
0x000d62:	movs    	r1, #0
0x000d64:	str     	r1, [sp]
0x000d66:	str     	r1, [sp, #4]
0x000d68:	movs    	r2, #0
0x000d6a:	movs    	r5, #0
0x000d6c:	adds    	r3, r5, #0
0x000d6e:	str     	r2, [sp, #8]
0x000d70:	movs    	r1, #0x45
0x000d72:	adds    	r0, r7, #0
0x000d74:	ldr     	r2, [r4, #8]
0x000d76:	bl      	#0x7e90
0x000d7a:	str     	r0, [sp, #0x20]
0x000d7c:	movs    	r1, #0
0x000d7e:	str     	r1, [sp]
0x000d80:	str     	r1, [sp, #4]
0x000d82:	movs    	r2, #0
0x000d84:	movs    	r1, #0x13
0x000d86:	movs    	r0, #0xf1
0x000d88:	adds    	r3, r5, #0
0x000d8a:	lsls    	r0, r0, #9
0x000d8c:	str     	r2, [sp, #8]
0x000d8e:	bl      	#0x7e90
0x000d92:	str     	r0, [sp, #0x1c]
0x000d94:	ldr     	r0, [sp, #0x20]
0x000d96:	cmp     	r0, #0
0x000d98:	ble     	#0xe64
0x000d9a:	movs    	r1, #0
0x000d9c:	str     	r1, [sp]
0x000d9e:	str     	r1, [sp, #4]
0x000da0:	movs    	r2, #0
0x000da2:	movs    	r5, #0
0x000da4:	adds    	r3, r5, #0
0x000da6:	str     	r2, [sp, #8]
0x000da8:	movs    	r1, #0x45
0x000daa:	adds    	r0, r7, #0
0x000dac:	ldr     	r2, [r4, #8]
0x000dae:	bl      	#0x7e90
0x000db2:	movs    	r1, #0
0x000db4:	str     	r1, [sp]
0x000db6:	str     	r1, [sp, #4]
0x000db8:	str     	r0, [sp, #0x14]
0x000dba:	movs    	r2, #0
0x000dbc:	str     	r2, [sp, #8]
0x000dbe:	movs    	r0, #0xf1
0x000dc0:	movs    	r1, #0x46
0x000dc2:	adds    	r3, r5, #0
0x000dc4:	lsls    	r0, r0, #9
0x000dc6:	ldr     	r2, [r4, #8]
0x000dc8:	bl      	#0x7e90
0x000dcc:	lsls    	r0, r0, #0x18
0x000dce:	movs    	r1, #0
0x000dd0:	asrs    	r0, r0, #0x18
0x000dd2:	str     	r0, [sp, #0x18]
0x000dd4:	str     	r1, [sp]
0x000dd6:	str     	r1, [sp, #4]
0x000dd8:	movs    	r2, #0
0x000dda:	str     	r2, [sp, #8]
0x000ddc:	movs    	r1, #0x46
0x000dde:	movs    	r0, #0xf1
0x000de0:	adds    	r3, r5, #0
0x000de2:	lsls    	r0, r0, #9
0x000de4:	ldr     	r2, [r4, #8]
0x000de6:	bl      	#0x7e90
0x000dea:	lsls    	r2, r0, #0x18
0x000dec:	asrs    	r2, r2, #0x18
0x000dee:	ldr     	r0, [sp, #0x14]
0x000df0:	ldr     	r1, [sp, #0x18]
0x000df2:	bl      	#0x7d74
0x000df6:	adds    	r5, r0, #0
0x000df8:	ldr     	r0, [sp, #0x14]
0x000dfa:	cmp     	r0, #0x17
0x000dfc:	blo     	#0xe00
0x000dfe:	b       	#0xf08
0x000e00:	adr     	r3, #4
0x000e02:	ldrb    	r3, [r3, r0]
0x000e04:	lsls    	r3, r3, #1
0x000e06:	add     	pc, r3
0x000e08:	ldrb    	r5, [r2, #0x1c]
0x000e0a:	asrs    	r7, r7, #1
0x000e0c:	ldrb    	r2, [r3, #0x1c]
0x000e0e:	lsrs    	r7, r7, #0xd
0x000e10:	str     	r0, [r5]
0x000e12:	str     	r7, [r7, #0x54]
0x000e14:	strh    	r2, [r6, #0x2a]
0x000e16:	ldrb    	r0, [r0, #0x1e]
0x000e18:	ldr     	r6, [pc, #0x16c]
0x000e1a:	ldrh    	r6, [r5, #0x10]
0x000e1c:	str     	r4, [sp, #0x23c]
0x000e1e:	lsls    	r1, r3, #2
0x000e20:	adds    	r1, r5, #0

; ===== candidate_000fb8 =====
0x000fb8:	push    	{r4, r5, lr}
0x000fba:	adds    	r5, r0, #0
0x000fbc:	ldr     	r0, [r1, #4]
0x000fbe:	adds    	r4, r1, #0
0x000fc0:	sub     	sp, #0xc
0x000fc2:	bl      	#0x62ac
0x000fc6:	movs    	r2, #1
0x000fc8:	ldr     	r1, [r4, #4]
0x000fca:	adds    	r0, r2, #0
0x000fcc:	cmn     	r1, r0
0x000fce:	beq     	#0xfd2
0x000fd0:	rsbs    	r0, r0, #0
0x000fd2:	bl      	#0x62ac
0x000fd6:	strb    	r2, [r5, #0x14]
0x000fd8:	adds    	r0, r4, #0
0x000fda:	bl      	#0x1edc
0x000fde:	adds    	r4, #0x20
0x000fe0:	ldrb    	r0, [r4, #1]
0x000fe2:	movs    	r4, #0xf1
0x000fe4:	lsls    	r4, r4, #9
0x000fe6:	movs    	r3, #0
0x000fe8:	cmp     	r0, #1
0x000fea:	bne     	#0x1006
0x000fec:	movs    	r2, #0
0x000fee:	str     	r2, [sp, #8]
0x000ff0:	movs    	r1, #0
0x000ff2:	ldr     	r2, [pc, #0x2c]
0x000ff4:	str     	r1, [sp]
0x000ff6:	str     	r1, [sp, #4]
0x000ff8:	add     	r2, pc
0x000ffa:	movs    	r1, #0x33
0x000ffc:	adds    	r0, r4, #0
0x000ffe:	bl      	#0x7e90
0x001002:	add     	sp, #0xc
0x001004:	pop     	{r4, r5, pc}

; ===== candidate_001028 =====
0x001028:	push    	{r4, r5, r6, r7, lr}
0x00102a:	adds    	r4, r0, #0
0x00102c:	ldr     	r0, [r0, #4]
0x00102e:	sub     	sp, #0xc
0x001030:	bl      	#0x62ac
0x001034:	ldr     	r1, [r4, #8]
0x001036:	adds    	r5, r0, #0
0x001038:	ldr     	r0, [r0]
0x00103a:	lsls    	r7, r1, #2
0x00103c:	ldr     	r0, [r0, r7]
0x00103e:	movs    	r1, #0x20
0x001040:	ldrsb   	r3, [r1, r4]
0x001042:	cmp     	r0, #0
0x001044:	bne     	#0x1080
0x001046:	movs    	r6, #1
0x001048:	cmp     	r3, #0
0x00104a:	blt     	#0x1078
0x00104c:	movs    	r1, #0
0x00104e:	movs    	r2, #0
0x001050:	str     	r2, [sp, #8]
0x001052:	str     	r1, [sp]
0x001054:	str     	r1, [sp, #4]
0x001056:	ldr     	r0, [r5, #4]
0x001058:	movs    	r1, #0x27
0x00105a:	ldr     	r2, [r0, r7]
0x00105c:	movs    	r0, #0xf1
0x00105e:	lsls    	r0, r0, #9
0x001060:	bl      	#0x7e90
0x001064:	ldr     	r2, [r4, #8]
0x001066:	ldr     	r1, [r5]
0x001068:	lsls    	r2, r2, #2
0x00106a:	str     	r0, [r1, r2]
0x00106c:	strb    	r6, [r0, #0x14]
0x00106e:	adds    	r1, r4, #0
0x001070:	bl      	#0x66f8
0x001074:	add     	sp, #0xc
0x001076:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_001090 =====
0x001090:	push    	{r4, r5, r6, lr}
0x001092:	ldr     	r4, [r0, #0x24]
0x001094:	adds    	r2, r0, #0
0x001096:	ldr     	r0, [r0, #4]
0x001098:	sub     	sp, #0x10
0x00109a:	bl      	#0x62ac
0x00109e:	ldr     	r1, [pc, #0x70]
0x0010a0:	add     	r1, sb
0x0010a2:	ldr     	r1, [r1, #0x50]
0x0010a4:	cmp     	r0, r1
0x0010a6:	bne     	#0x110a
0x0010a8:	ldr     	r0, [r2, #8]
0x0010aa:	ldr     	r1, [r1, #0x10]
0x0010ac:	cmp     	r0, r1
0x0010ae:	bne     	#0x110a
0x0010b0:	movs    	r1, #0
0x0010b2:	movs    	r2, #0
0x0010b4:	str     	r2, [sp, #8]
0x0010b6:	str     	r1, [sp]
0x0010b8:	str     	r1, [sp, #4]
0x0010ba:	movs    	r5, #0
0x0010bc:	movs    	r6, #0xf1
0x0010be:	lsls    	r6, r6, #9
0x0010c0:	adds    	r3, r5, #0
0x0010c2:	movs    	r1, #0x90
0x0010c4:	adds    	r2, r4, #0
0x0010c6:	adds    	r0, r6, #0
0x0010c8:	bl      	#0x7e90
0x0010cc:	adds    	r4, r0, #0
0x0010ce:	beq     	#0x110a
0x0010d0:	ldrh    	r0, [r4, #8]
0x0010d2:	subs    	r0, #1
0x0010d4:	lsls    	r0, r0, #0x10
0x0010d6:	asrs    	r0, r0, #0x10
0x0010d8:	strh    	r0, [r4, #8]
0x0010da:	cmp     	r0, #0
0x0010dc:	bgt     	#0x110a
0x0010de:	movs    	r1, #0
0x0010e0:	movs    	r2, #0
0x0010e2:	str     	r2, [sp, #8]
0x0010e4:	str     	r1, [sp]
0x0010e6:	str     	r1, [sp, #4]
0x0010e8:	movs    	r1, #0x8f
0x0010ea:	adds    	r2, r4, #0
0x0010ec:	adds    	r3, r5, #0
0x0010ee:	adds    	r0, r6, #0
0x0010f0:	bl      	#0x7e90
0x0010f4:	movs    	r1, #0
0x0010f6:	movs    	r2, #0
0x0010f8:	str     	r2, [sp, #8]
0x0010fa:	str     	r1, [sp]
0x0010fc:	str     	r1, [sp, #4]
0x0010fe:	movs    	r1, #0x8e
0x001100:	adds    	r2, r4, #0
0x001102:	adds    	r3, r5, #0
0x001104:	adds    	r0, r6, #0
0x001106:	bl      	#0x7e90
0x00110a:	add     	sp, #0x10
0x00110c:	pop     	{r4, r5, r6, pc}

; ===== candidate_001114 =====
0x001114:	push    	{r4, r5, r6, r7, lr}
0x001116:	adds    	r5, r0, #0
0x001118:	adds    	r0, #0x40
0x00111a:	ldrb    	r0, [r0]
0x00111c:	movs    	r7, #0
0x00111e:	sub     	sp, #0x14
0x001120:	cmp     	r0, #0
0x001122:	bne     	#0x114c
0x001124:	ldr     	r4, [pc, #0x104]
0x001126:	add     	r4, pc
0x001128:	movs    	r1, #0
0x00112a:	movs    	r2, #0
0x00112c:	str     	r2, [sp, #8]
0x00112e:	str     	r1, [sp]
0x001130:	str     	r1, [sp, #4]
0x001132:	adds    	r3, r7, #0
0x001134:	adds    	r2, r4, #0
0x001136:	movs    	r1, #0x6f
0x001138:	movs    	r0, #0xf1
0x00113a:	lsls    	r0, r0, #9
0x00113c:	bl      	#0x7e90
0x001140:	ldr     	r0, [pc, #0xec]
0x001142:	movs    	r3, #1
0x001144:	add     	r0, sb
0x001146:	strb    	r3, [r0, #8]
0x001148:	add     	sp, #0x14
0x00114a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00123c =====
0x00123c:	push    	{r4, r5, r6, lr}
0x00123e:	adds    	r2, r0, #0
0x001240:	movs    	r3, #0x4c
0x001242:	ldrsb   	r5, [r0, r3]
0x001244:	ldr     	r4, [r0, #0x44]
0x001246:	ldr     	r6, [r0, #0x48]
0x001248:	ldr     	r0, [r0, #4]
0x00124a:	sub     	sp, #0x10
0x00124c:	bl      	#0x62ac
0x001250:	ldr     	r1, [r2, #8]
0x001252:	cmp     	r5, #0
0x001254:	bne     	#0x1268
0x001256:	ldr     	r2, [pc, #0x4c]
0x001258:	add     	r2, sb
0x00125a:	ldr     	r2, [r2, #0x50]
0x00125c:	cmp     	r0, r2
0x00125e:	bne     	#0x128a
0x001260:	ldr     	r0, [r2, #0x10]
0x001262:	cmp     	r0, r1
0x001264:	bne     	#0x128a
0x001266:	b       	#0x126c
0x001268:	cmp     	r5, #1
0x00126a:	bne     	#0x128a
0x00126c:	movs    	r5, #0xf1
0x00126e:	lsls    	r5, r5, #9
0x001270:	movs    	r3, #0
0x001272:	cmp     	r6, #0
0x001274:	bne     	#0x128e
0x001276:	movs    	r1, #0
0x001278:	movs    	r2, #0
0x00127a:	str     	r2, [sp, #8]
0x00127c:	str     	r1, [sp]
0x00127e:	str     	r1, [sp, #4]
0x001280:	movs    	r1, #0x6f
0x001282:	adds    	r2, r4, #0
0x001284:	adds    	r0, r5, #0
0x001286:	bl      	#0x7e90
0x00128a:	add     	sp, #0x10
0x00128c:	pop     	{r4, r5, r6, pc}

; ===== candidate_0012a8 =====
0x0012a8:	push    	{r4, r5, r6, r7, lr}
0x0012aa:	sub     	sp, #0x14
0x0012ac:	movs    	r5, #0
0x0012ae:	str     	r5, [sp, #0xc]
0x0012b0:	ldr     	r3, [r0, #0x54]
0x0012b2:	movs    	r7, #0
0x0012b4:	adds    	r6, r0, #0
0x0012b6:	movs    	r4, #1
0x0012b8:	cmp     	r3, #0
0x0012ba:	bne     	#0x12c6
0x0012bc:	ldr     	r0, [pc, #0x8c]
0x0012be:	add     	r0, sb
0x0012c0:	strb    	r4, [r0, #8]
0x0012c2:	add     	sp, #0x14
0x0012c4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_001350 =====
0x001350:	push    	{r4, r5, r6, r7, lr}
0x001352:	ldr     	r7, [pc, #0x74]
0x001354:	ldr     	r3, [r0, #0x58]
0x001356:	adds    	r5, r0, #0
0x001358:	movs    	r4, #0
0x00135a:	cmp     	r3, #0
0x00135c:	sub     	sp, #0xc
0x00135e:	add     	r7, sb
0x001360:	bne     	#0x136a
0x001362:	movs    	r0, #1
0x001364:	strb    	r0, [r7, #8]
0x001366:	add     	sp, #0xc
0x001368:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0013cc =====
0x0013cc:	push    	{r4, r5, r6, r7, lr}
0x0013ce:	ldr     	r7, [pc, #0x6c]
0x0013d0:	ldr     	r3, [r0, #0x5c]
0x0013d2:	adds    	r5, r0, #0
0x0013d4:	movs    	r4, #0
0x0013d6:	cmp     	r3, #0
0x0013d8:	sub     	sp, #0xc
0x0013da:	add     	r7, sb
0x0013dc:	bne     	#0x13e6
0x0013de:	movs    	r0, #1
0x0013e0:	strb    	r0, [r7, #8]
0x0013e2:	add     	sp, #0xc
0x0013e4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_001440 =====
0x001440:	push    	{r4, r5, r6, r7, lr}
0x001442:	adds    	r6, r0, #0
0x001444:	ldr     	r0, [r0, #4]
0x001446:	sub     	sp, #0xc
0x001448:	bl      	#0x62ac
0x00144c:	ldr     	r1, [r6, #8]
0x00144e:	ldr     	r0, [r0]
0x001450:	lsls    	r1, r1, #2
0x001452:	ldr     	r4, [r0, r1]
0x001454:	cmp     	r4, #0
0x001456:	beq     	#0x14a8
0x001458:	movs    	r1, #0
0x00145a:	movs    	r2, #0
0x00145c:	str     	r2, [sp, #8]
0x00145e:	str     	r1, [sp]
0x001460:	str     	r1, [sp, #4]
0x001462:	movs    	r7, #0xf1
0x001464:	lsls    	r7, r7, #9
0x001466:	movs    	r1, #0xf
0x001468:	movs    	r2, #8
0x00146a:	movs    	r3, #0
0x00146c:	adds    	r0, r7, #0
0x00146e:	bl      	#0x7e90
0x001472:	adds    	r1, r6, #0
0x001474:	adds    	r1, #0x30
0x001476:	movs    	r3, #4
0x001478:	ldrsb   	r2, [r1, r3]
0x00147a:	movs    	r3, #6
0x00147c:	adds    	r5, r0, #0
0x00147e:	str     	r2, [r0]
0x001480:	ldrsb   	r1, [r1, r3]
0x001482:	str     	r1, [r0, #4]
0x001484:	ldr     	r0, [r4, #0x18]
0x001486:	cmp     	r0, #0
0x001488:	bne     	#0x14a0
0x00148a:	movs    	r1, #0
0x00148c:	str     	r1, [sp]
0x00148e:	str     	r1, [sp, #4]
0x001490:	movs    	r2, #0
0x001492:	movs    	r1, #0x13
0x001494:	movs    	r3, #0
0x001496:	adds    	r0, r7, #0
0x001498:	str     	r2, [sp, #8]
0x00149a:	bl      	#0x7e90
0x00149e:	str     	r0, [r4, #0x18]
0x0014a0:	adds    	r1, r5, #0
0x0014a2:	adds    	r0, r4, #0
0x0014a4:	bl      	#0xa04
0x0014a8:	add     	sp, #0xc
0x0014aa:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0014ac =====
0x0014ac:	push    	{r4, r5, r6, r7, lr}
0x0014ae:	ldr     	r0, [r1, #0x30]
0x0014b0:	sub     	sp, #0x24
0x0014b2:	movs    	r3, #0
0x0014b4:	adds    	r5, r1, #0
0x0014b6:	cmp     	r0, #0
0x0014b8:	str     	r3, [sp, #0x18]
0x0014ba:	str     	r0, [sp, #0x20]
0x0014bc:	bne     	#0x14ca
0x0014be:	ldr     	r1, [pc, #0x1a0]
0x0014c0:	movs    	r0, #1
0x0014c2:	add     	r1, sb
0x0014c4:	strb    	r0, [r1, #8]
0x0014c6:	add     	sp, #0x24
0x0014c8:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_001664 =====
0x001664:	push    	{r4, r5, r6, r7, lr}
0x001666:	adds    	r4, r0, #0
0x001668:	ldr     	r2, [pc, #0x2fc]
0x00166a:	ldr     	r0, [r0, #4]
0x00166c:	movs    	r5, #0
0x00166e:	add     	r2, sb
0x001670:	ldr     	r1, [r2, #0x50]
0x001672:	adds    	r3, r0, #1
0x001674:	sub     	sp, #0xc
0x001676:	bne     	#0x167c
0x001678:	adds    	r3, r1, #0
0x00167a:	b       	#0x167e
0x00167c:	ldr     	r3, [r2, #0x54]
0x00167e:	ldr     	r6, [pc, #0x2e8]
0x001680:	movs    	r7, #0
0x001682:	add     	r6, sb
0x001684:	subs    	r6, #0x80
0x001686:	str     	r7, [r6, #0x48]
0x001688:	str     	r7, [r6, #0x4c]
0x00168a:	str     	r7, [r6, #0x50]
0x00168c:	movs    	r7, #1
0x00168e:	strb    	r7, [r6, #9]
0x001690:	ldr     	r6, [r4, #8]
0x001692:	cmp     	r6, #0
0x001694:	blt     	#0x169c
0x001696:	ldr     	r3, [r3]
0x001698:	lsls    	r5, r6, #2
0x00169a:	ldr     	r5, [r3, r5]
0x00169c:	ldr     	r6, [r4]
0x00169e:	cmp     	r6, #0x17
0x0016a0:	bhs     	#0x16ac
0x0016a2:	adr     	r3, #0xc
0x0016a4:	adds    	r3, r3, r6
0x0016a6:	ldrh    	r3, [r3, r6]
0x0016a8:	lsls    	r3, r3, #1
0x0016aa:	add     	pc, r3
0x0016ac:	add     	sp, #0xc
0x0016ae:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_001970 =====
0x001970:	push    	{r4, r5, r6, r7, lr}
0x001972:	ldr     	r6, [pc, #0x3b0]
0x001974:	adds    	r4, r0, #0
0x001976:	add     	r6, sb
0x001978:	ldr     	r0, [r6, #0x2c]
0x00197a:	sub     	sp, #0xc
0x00197c:	cmp     	r0, #0
0x00197e:	beq     	#0x19b8
0x001980:	ldr     	r2, [pc, #0x3a4]
0x001982:	adds    	r1, r4, #0
0x001984:	add     	r2, sb
0x001986:	ldr     	r2, [r2]
0x001988:	blx     	r2
0x00198a:	cmp     	r0, #0
0x00198c:	bne     	#0x19b8
0x00198e:	ldr     	r0, [pc, #0x394]
0x001990:	movs    	r3, #0xf
0x001992:	add     	r0, sb
0x001994:	adds    	r0, #0x80
0x001996:	ldr     	r1, [r0, #0x38]
0x001998:	ldrsb   	r0, [r6, r3]
0x00199a:	movs    	r2, #1
0x00199c:	str     	r2, [sp, #8]
0x00199e:	str     	r1, [sp, #4]
0x0019a0:	str     	r0, [sp]
0x0019a2:	movs    	r3, #0x10
0x0019a4:	ldrsb   	r4, [r6, r3]
0x0019a6:	movs    	r3, #0xe
0x0019a8:	ldrsb   	r2, [r6, r3]
0x0019aa:	ldr     	r0, [r6, #0x2c]
0x0019ac:	ldr     	r1, [r6, #0x30]
0x0019ae:	adds    	r3, r4, #0
0x0019b0:	bl      	#0x27b0
0x0019b4:	add     	sp, #0xc
0x0019b6:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_001edc =====
0x001edc:	push    	{r4, r5, r6, r7, lr}
0x001ede:	adds    	r2, r0, #0
0x001ee0:	ldr     	r0, [r0, #4]
0x001ee2:	sub     	sp, #0x14
0x001ee4:	bl      	#0x62ac
0x001ee8:	adds    	r7, r0, #0
0x001eea:	ldr     	r1, [r2, #4]
0x001eec:	movs    	r0, #1
0x001eee:	cmn     	r1, r0
0x001ef0:	beq     	#0x1ef4
0x001ef2:	rsbs    	r0, r0, #0
0x001ef4:	bl      	#0x62ac
0x001ef8:	adds    	r5, r0, #0
0x001efa:	adds    	r0, r2, #0
0x001efc:	adds    	r0, #0x20
0x001efe:	movs    	r3, #8
0x001f00:	ldrsb   	r1, [r0, r3]
0x001f02:	movs    	r3, #1
0x001f04:	str     	r1, [sp, #0x10]
0x001f06:	ldrsb   	r0, [r0, r3]
0x001f08:	str     	r0, [sp, #0xc]
0x001f0a:	ldr     	r0, [pc, #0xf8]
0x001f0c:	ldr     	r4, [r2, #0x24]
0x001f0e:	ldr     	r6, [r2, #0x2c]
0x001f10:	add     	r0, sb
0x001f12:	ldr     	r0, [r0, #0x50]
0x001f14:	cmp     	r7, r0
0x001f16:	bne     	#0x1fa8
0x001f18:	ldr     	r1, [r2, #8]
0x001f1a:	ldr     	r0, [r0, #0x10]
0x001f1c:	cmp     	r1, r0
0x001f1e:	bne     	#0x1fa8
0x001f20:	movs    	r1, #0
0x001f22:	movs    	r2, #0
0x001f24:	str     	r2, [sp, #8]
0x001f26:	str     	r1, [sp]
0x001f28:	str     	r1, [sp, #4]
0x001f2a:	movs    	r7, #0xf1
0x001f2c:	lsls    	r7, r7, #9
0x001f2e:	movs    	r1, #0x90
0x001f30:	adds    	r2, r4, #0
0x001f32:	movs    	r3, #0
0x001f34:	adds    	r0, r7, #0
0x001f36:	bl      	#0x7e90
0x001f3a:	adds    	r4, r0, #0
0x001f3c:	ldrh    	r0, [r0, #8]
0x001f3e:	subs    	r0, #1
0x001f40:	lsls    	r1, r0, #0x10
0x001f42:	asrs    	r1, r1, #0x10
0x001f44:	strh    	r1, [r4, #8]
0x001f46:	cmp     	r1, #0
0x001f48:	bgt     	#0x1f76
0x001f4a:	movs    	r1, #0
0x001f4c:	movs    	r2, #0
0x001f4e:	str     	r2, [sp, #8]
0x001f50:	str     	r1, [sp]
0x001f52:	str     	r1, [sp, #4]
0x001f54:	movs    	r1, #0x8f
0x001f56:	adds    	r2, r4, #0
0x001f58:	movs    	r3, #0
0x001f5a:	adds    	r0, r7, #0
0x001f5c:	bl      	#0x7e90
0x001f60:	movs    	r1, #0
0x001f62:	movs    	r2, #0
0x001f64:	str     	r2, [sp, #8]
0x001f66:	str     	r1, [sp]
0x001f68:	str     	r1, [sp, #4]
0x001f6a:	movs    	r1, #0x8e
0x001f6c:	adds    	r2, r4, #0
0x001f6e:	movs    	r3, #0
0x001f70:	adds    	r0, r7, #0
0x001f72:	bl      	#0x7e90
0x001f76:	cmp     	r6, #0
0x001f78:	beq     	#0x1fa8
0x001f7a:	movs    	r1, #0
0x001f7c:	movs    	r2, #0
0x001f7e:	str     	r2, [sp, #8]
0x001f80:	str     	r1, [sp]
0x001f82:	str     	r1, [sp, #4]
0x001f84:	movs    	r1, #0xe1
0x001f86:	movs    	r2, #0x52
0x001f88:	movs    	r3, #0
0x001f8a:	adds    	r0, r7, #0
0x001f8c:	bl      	#0x7e90
0x001f90:	movs    	r2, #0
0x001f92:	movs    	r1, #0
0x001f94:	str     	r2, [sp, #8]
0x001f96:	adds    	r3, r6, #0
0x001f98:	adds    	r2, r0, #0
0x001f9a:	str     	r1, [sp]
0x001f9c:	str     	r1, [sp, #4]
0x001f9e:	movs    	r1, #0x36
0x001fa0:	movs    	r0, #0xf1
0x001fa2:	lsls    	r0, r0, #9
0x001fa4:	bl      	#0x7e90
0x001fa8:	ldr     	r0, [sp, #0xc]
0x001faa:	cmp     	r0, #1
0x001fac:	bne     	#0x1fec
0x001fae:	ldr     	r0, [r5]
0x001fb0:	ldr     	r1, [sp, #0x10]
0x001fb2:	movs    	r6, #0
0x001fb4:	lsls    	r3, r1, #2
0x001fb6:	ldr     	r4, [r0, r3]
0x001fb8:	str     	r6, [r0, r3]
0x001fba:	movs    	r1, #0
0x001fbc:	movs    	r2, #0
0x001fbe:	str     	r2, [sp, #8]
0x001fc0:	str     	r1, [sp]
0x001fc2:	str     	r1, [sp, #4]
0x001fc4:	ldr     	r0, [r5, #4]
0x001fc6:	movs    	r1, #0x8d
0x001fc8:	ldr     	r2, [r0, r3]
0x001fca:	movs    	r0, #0xf1
0x001fcc:	adds    	r3, r4, #0
0x001fce:	lsls    	r0, r0, #9
0x001fd0:	bl      	#0x7e90
0x001fd4:	movs    	r1, #0
0x001fd6:	movs    	r2, #0
0x001fd8:	str     	r2, [sp, #8]
0x001fda:	str     	r1, [sp]
0x001fdc:	str     	r1, [sp, #4]
0x001fde:	adds    	r3, r6, #0
0x001fe0:	adds    	r2, r4, #0
0x001fe2:	movs    	r1, #0x8c
0x001fe4:	movs    	r0, #0xf1
0x001fe6:	lsls    	r0, r0, #9
0x001fe8:	bl      	#0x7e90
0x001fec:	ldr     	r1, [pc, #0x14]
0x001fee:	movs    	r0, #1
0x001ff0:	add     	r1, sb
0x001ff2:	subs    	r1, #0x80
0x001ff4:	strb    	r0, [r1, #8]
0x001ff6:	ldr     	r0, [pc, #0xc]
0x001ff8:	movs    	r6, #0
0x001ffa:	add     	r0, sb
0x001ffc:	str     	r6, [r0, #0x20]
0x001ffe:	add     	sp, #0x14
0x002000:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002008 =====
0x002008:	push    	{r4, r5, r6, r7, lr}
0x00200a:	ldr     	r5, [pc, #0x1d4]
0x00200c:	sub     	sp, #0xc
0x00200e:	add     	r5, sb
0x002010:	ldr     	r0, [r5, #0x3c]
0x002012:	ldr     	r1, [r5, #0x58]
0x002014:	lsls    	r0, r0, #2
0x002016:	ldr     	r4, [r1, r0]
0x002018:	ldr     	r1, [pc, #0x1c8]
0x00201a:	add     	r1, pc
0x00201c:	ldr     	r2, [pc, #0x1c8]
0x00201e:	adds    	r0, r4, #0
0x002020:	add     	r2, sb
0x002022:	ldr     	r2, [r2]
0x002024:	blx     	r2
0x002026:	movs    	r7, #0xf1
0x002028:	lsls    	r7, r7, #9
0x00202a:	movs    	r6, #0
0x00202c:	cmp     	r0, #0
0x00202e:	bne     	#0x2114
0x002030:	movs    	r1, #0
0x002032:	str     	r1, [sp]
0x002034:	str     	r1, [sp, #4]
0x002036:	movs    	r2, #0
0x002038:	movs    	r1, #0x2c
0x00203a:	adds    	r3, r6, #0
0x00203c:	adds    	r0, r7, #0
0x00203e:	str     	r2, [sp, #8]
0x002040:	bl      	#0x7e90
0x002044:	movs    	r1, #0
0x002046:	str     	r1, [sp]
0x002048:	str     	r1, [sp, #4]
0x00204a:	movs    	r2, #0
0x00204c:	movs    	r1, #0x2c
0x00204e:	adds    	r3, r6, #0
0x002050:	adds    	r0, r7, #0
0x002052:	str     	r2, [sp, #8]
0x002054:	bl      	#0x7e90
0x002058:	ldr     	r4, [r5, #0x58]
0x00205a:	cmp     	r4, #0
0x00205c:	beq     	#0x2074
0x00205e:	movs    	r1, #0
0x002060:	movs    	r2, #0
0x002062:	str     	r2, [sp, #8]
0x002064:	str     	r1, [sp]
0x002066:	str     	r1, [sp, #4]
0x002068:	movs    	r1, #0x12
0x00206a:	adds    	r2, r4, #0
0x00206c:	adds    	r3, r6, #0
0x00206e:	adds    	r0, r7, #0
0x002070:	bl      	#0x7e90
0x002074:	ldr     	r1, [pc, #0x168]
0x002076:	str     	r6, [r5, #0x58]
0x002078:	add     	r1, sb
0x00207a:	adds    	r1, #0x80
0x00207c:	ldr     	r1, [r1, #0x50]
0x00207e:	movs    	r0, #1
0x002080:	ldr     	r2, [r1]
0x002082:	ldr     	r1, [r1, #0x10]
0x002084:	movs    	r3, #0
0x002086:	lsls    	r1, r1, #2
0x002088:	ldr     	r1, [r2, r1]
0x00208a:	movs    	r2, #0
0x00208c:	strb    	r0, [r1, #0x14]
0x00208e:	movs    	r1, #0
0x002090:	str     	r1, [sp]
0x002092:	str     	r1, [sp, #4]
0x002094:	movs    	r1, #0x34
0x002096:	adds    	r0, r7, #0
0x002098:	str     	r2, [sp, #8]
0x00209a:	bl      	#0x7e90
0x00209e:	movs    	r0, #4
0x0020a0:	ldr     	r1, [r5, #0x38]
0x0020a2:	bl      	#0x9ca4
0x0020a6:	ldr     	r4, [r5, #0x2c]
0x0020a8:	cmp     	r4, #0
0x0020aa:	beq     	#0x20c2
0x0020ac:	movs    	r1, #0
0x0020ae:	movs    	r2, #0
0x0020b0:	str     	r2, [sp, #8]
0x0020b2:	str     	r1, [sp]
0x0020b4:	str     	r1, [sp, #4]
0x0020b6:	movs    	r1, #9
0x0020b8:	adds    	r2, r4, #0
0x0020ba:	adds    	r3, r6, #0
0x0020bc:	adds    	r0, r7, #0
0x0020be:	bl      	#0x7e90
0x0020c2:	str     	r6, [r5, #0x2c]
0x0020c4:	movs    	r1, #0
0x0020c6:	movs    	r2, #0
0x0020c8:	str     	r2, [sp, #8]
0x0020ca:	str     	r1, [sp]
0x0020cc:	str     	r1, [sp, #4]
0x0020ce:	movs    	r1, #0xe1
0x0020d0:	movs    	r2, #0x53
0x0020d2:	adds    	r3, r6, #0
0x0020d4:	adds    	r0, r7, #0
0x0020d6:	bl      	#0x7e90
0x0020da:	cmp     	r0, #0
0x0020dc:	beq     	#0x2128
0x0020de:	movs    	r1, #0
0x0020e0:	movs    	r2, #0
0x0020e2:	str     	r2, [sp, #8]
0x0020e4:	str     	r1, [sp]
0x0020e6:	str     	r1, [sp, #4]
0x0020e8:	movs    	r1, #0xe1
0x0020ea:	movs    	r2, #0x53
0x0020ec:	adds    	r3, r6, #0
0x0020ee:	adds    	r0, r7, #0
0x0020f0:	bl      	#0x7e90
0x0020f4:	movs    	r2, #0
0x0020f6:	movs    	r1, #0
0x0020f8:	str     	r2, [sp, #8]
0x0020fa:	adds    	r3, r6, #0
0x0020fc:	adds    	r2, r0, #0
0x0020fe:	str     	r1, [sp]
0x002100:	str     	r1, [sp, #4]
0x002102:	movs    	r1, #0xa0
0x002104:	movs    	r0, #0xf1
0x002106:	lsls    	r0, r0, #9
0x002108:	bl      	#0x7e90
0x00210c:	movs    	r2, #0
0x00210e:	movs    	r1, #0
0x002110:	str     	r1, [sp]
0x002112:	b       	#0x2116
0x002114:	b       	#0x212c
0x002116:	str     	r1, [sp, #4]
0x002118:	str     	r2, [sp, #8]
0x00211a:	movs    	r2, #0x53
0x00211c:	movs    	r1, #0x14
0x00211e:	adds    	r3, r6, #0
0x002120:	movs    	r0, #0xf1
0x002122:	lsls    	r0, r0, #9
0x002124:	bl      	#0x7e90
0x002128:	add     	sp, #0xc
0x00212a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0021f4 =====
0x0021f4:	push    	{r4, r5, r6, r7, lr}
0x0021f6:	movs    	r5, #0
0x0021f8:	adds    	r4, r0, #0
0x0021fa:	movs    	r2, #0
0x0021fc:	movs    	r1, #0
0x0021fe:	movs    	r0, #0
0x002200:	sub     	sp, #0x1c
0x002202:	bl      	#0x7e40
0x002206:	movs    	r1, #0
0x002208:	movs    	r2, #0
0x00220a:	movs    	r6, #0
0x00220c:	adds    	r3, r6, #0
0x00220e:	str     	r2, [sp, #8]
0x002210:	str     	r1, [sp]
0x002212:	str     	r1, [sp, #4]
0x002214:	movs    	r1, #0x44
0x002216:	adds    	r2, r4, #0
0x002218:	movs    	r0, #0xf1
0x00221a:	lsls    	r0, r0, #9
0x00221c:	bl      	#0x7e90
0x002220:	movs    	r1, #0
0x002222:	str     	r1, [sp]
0x002224:	str     	r1, [sp, #4]
0x002226:	movs    	r2, #0
0x002228:	str     	r2, [sp, #8]
0x00222a:	movs    	r1, #0x46
0x00222c:	adds    	r3, r6, #0
0x00222e:	movs    	r0, #0xf1
0x002230:	lsls    	r0, r0, #9
0x002232:	ldr     	r2, [r4, #8]
0x002234:	bl      	#0x7e90
0x002238:	lsls    	r6, r0, #0x18
0x00223a:	asrs    	r6, r6, #0x18
0x00223c:	cmp     	r6, #0
0x00223e:	ble     	#0x2290
0x002240:	movs    	r1, #0
0x002242:	str     	r1, [sp]
0x002244:	str     	r1, [sp, #4]
0x002246:	movs    	r2, #0
0x002248:	str     	r2, [sp, #8]
0x00224a:	movs    	r1, #0x47
0x00224c:	movs    	r3, #0
0x00224e:	movs    	r0, #0xf1
0x002250:	lsls    	r0, r0, #9
0x002252:	ldr     	r2, [r4, #8]
0x002254:	bl      	#0x7e90
0x002258:	movs    	r1, #0
0x00225a:	movs    	r2, #0
0x00225c:	str     	r2, [sp, #8]
0x00225e:	str     	r1, [sp]
0x002260:	str     	r1, [sp, #4]
0x002262:	adds    	r7, r0, #0
0x002264:	movs    	r0, #0xf1
0x002266:	movs    	r1, #0xe1
0x002268:	movs    	r2, #0x5d
0x00226a:	movs    	r3, #0
0x00226c:	lsls    	r0, r0, #9
0x00226e:	bl      	#0x7e90
0x002272:	movs    	r2, #0
0x002274:	str     	r2, [sp, #8]
0x002276:	movs    	r1, #0
0x002278:	adds    	r2, r0, #0
0x00227a:	movs    	r0, #0xf1
0x00227c:	str     	r1, [sp]
0x00227e:	str     	r1, [sp, #4]
0x002280:	movs    	r1, #0x36
0x002282:	lsls    	r0, r0, #9
0x002284:	adds    	r3, r7, #0
0x002286:	bl      	#0x7e90
0x00228a:	adds    	r5, #1
0x00228c:	cmp     	r5, r6
0x00228e:	blt     	#0x2240
0x002290:	movs    	r1, #0
0x002292:	str     	r1, [sp]
0x002294:	str     	r1, [sp, #4]
0x002296:	movs    	r2, #0
0x002298:	str     	r2, [sp, #8]
0x00229a:	movs    	r1, #0x46
0x00229c:	movs    	r3, #0
0x00229e:	movs    	r0, #0xf1
0x0022a0:	lsls    	r0, r0, #9
0x0022a2:	ldr     	r2, [r4, #8]
0x0022a4:	bl      	#0x7e90
0x0022a8:	lsls    	r0, r0, #0x18
0x0022aa:	asrs    	r0, r0, #0x18
0x0022ac:	cmp     	r0, #1
0x0022ae:	bne     	#0x2396
0x0022b0:	movs    	r1, #0
0x0022b2:	str     	r1, [sp]
0x0022b4:	str     	r1, [sp, #4]
0x0022b6:	movs    	r2, #0
0x0022b8:	movs    	r7, #0
0x0022ba:	adds    	r3, r7, #0
0x0022bc:	str     	r2, [sp, #8]
0x0022be:	movs    	r1, #0x45
0x0022c0:	movs    	r0, #0xf1
0x0022c2:	lsls    	r0, r0, #9
0x0022c4:	ldr     	r2, [r4, #8]
0x0022c6:	bl      	#0x7e90
0x0022ca:	movs    	r1, #0
0x0022cc:	str     	r1, [sp]
0x0022ce:	str     	r1, [sp, #4]
0x0022d0:	movs    	r2, #0
0x0022d2:	str     	r2, [sp, #8]
0x0022d4:	movs    	r1, #0x45
0x0022d6:	adds    	r3, r7, #0
0x0022d8:	movs    	r0, #0xf1
0x0022da:	lsls    	r0, r0, #9
0x0022dc:	ldr     	r2, [r4, #8]
0x0022de:	bl      	#0x7e90
0x0022e2:	movs    	r1, #0
0x0022e4:	str     	r1, [sp]
0x0022e6:	str     	r1, [sp, #4]
0x0022e8:	str     	r0, [sp, #0x14]
0x0022ea:	movs    	r2, #0
0x0022ec:	str     	r2, [sp, #8]
0x0022ee:	movs    	r0, #0xf1
0x0022f0:	movs    	r1, #0x45
0x0022f2:	adds    	r3, r7, #0
0x0022f4:	lsls    	r0, r0, #9
0x0022f6:	ldr     	r2, [r4, #8]
0x0022f8:	bl      	#0x7e90
0x0022fc:	movs    	r1, #0
0x0022fe:	str     	r1, [sp]
0x002300:	str     	r1, [sp, #4]
0x002302:	adds    	r5, r0, #0
0x002304:	movs    	r2, #0
0x002306:	str     	r2, [sp, #8]
0x002308:	movs    	r0, #0xf1
0x00230a:	adds    	r3, r7, #0
0x00230c:	movs    	r1, #0x45
0x00230e:	lsls    	r0, r0, #9
0x002310:	ldr     	r2, [r4, #8]
0x002312:	bl      	#0x7e90
0x002316:	movs    	r1, #0
0x002318:	adds    	r6, r0, #0
0x00231a:	movs    	r2, #0
0x00231c:	str     	r2, [sp, #8]
0x00231e:	str     	r1, [sp]
0x002320:	str     	r1, [sp, #4]
0x002322:	movs    	r1, #0xe1

; ===== candidate_002640 =====
0x002640:	push    	{r4, r5, r6, r7, lr}
0x002642:	sub     	sp, #0xc
0x002644:	movs    	r1, #0
0x002646:	movs    	r2, #0
0x002648:	str     	r2, [sp, #8]
0x00264a:	str     	r1, [sp]
0x00264c:	str     	r1, [sp, #4]
0x00264e:	movs    	r7, #0xf1
0x002650:	lsls    	r7, r7, #9
0x002652:	movs    	r1, #0x44
0x002654:	adds    	r2, r0, #0
0x002656:	adds    	r4, r0, #0
0x002658:	movs    	r3, #0
0x00265a:	adds    	r0, r7, #0
0x00265c:	bl      	#0x7e90
0x002660:	movs    	r1, #0
0x002662:	str     	r1, [sp]
0x002664:	str     	r1, [sp, #4]
0x002666:	movs    	r2, #0
0x002668:	str     	r2, [sp, #8]
0x00266a:	movs    	r1, #0x46
0x00266c:	movs    	r3, #0
0x00266e:	adds    	r0, r7, #0
0x002670:	ldr     	r2, [r4, #8]
0x002672:	bl      	#0x7e90
0x002676:	movs    	r1, #0
0x002678:	movs    	r2, #0
0x00267a:	str     	r2, [sp, #8]
0x00267c:	str     	r1, [sp]
0x00267e:	str     	r1, [sp, #4]
0x002680:	lsls    	r3, r0, #0x18
0x002682:	asrs    	r3, r3, #0x18
0x002684:	movs    	r1, #0x14
0x002686:	movs    	r2, #0x50
0x002688:	adds    	r0, r7, #0
0x00268a:	bl      	#0x7e90
0x00268e:	adds    	r0, r4, #0
0x002690:	bl      	#0x8ba4
0x002694:	adds    	r5, r0, #0
0x002696:	adds    	r0, r4, #0
0x002698:	bl      	#0x8ba4
0x00269c:	movs    	r1, #0
0x00269e:	str     	r1, [sp]
0x0026a0:	str     	r1, [sp, #4]
0x0026a2:	movs    	r2, #0
0x0026a4:	str     	r2, [sp, #8]
0x0026a6:	movs    	r1, #0x46
0x0026a8:	adds    	r6, r0, #0
0x0026aa:	movs    	r3, #0
0x0026ac:	adds    	r0, r7, #0
0x0026ae:	ldr     	r2, [r4, #8]
0x0026b0:	bl      	#0x7e90
0x0026b4:	ldr     	r1, [pc, #0xe4]
0x0026b6:	ldr     	r4, [pc, #0xe4]
0x0026b8:	add     	r1, sb
0x0026ba:	str     	r0, [r1, #0x40]
0x0026bc:	add     	r4, sb
0x0026be:	adds    	r4, #0x80
0x0026c0:	str     	r5, [r4, #0x50]
0x0026c2:	movs    	r1, #0
0x0026c4:	movs    	r2, #0
0x0026c6:	str     	r2, [sp, #8]
0x0026c8:	str     	r1, [sp]
0x0026ca:	str     	r1, [sp, #4]
0x0026cc:	movs    	r1, #0x14
0x0026ce:	movs    	r2, #0x6a
0x0026d0:	adds    	r3, r5, #0
0x0026d2:	adds    	r0, r7, #0
0x0026d4:	bl      	#0x7e90
0x0026d8:	str     	r6, [r4, #0x54]
0x0026da:	movs    	r1, #0
0x0026dc:	movs    	r2, #0
0x0026de:	str     	r2, [sp, #8]
0x0026e0:	str     	r1, [sp]
0x0026e2:	str     	r1, [sp, #4]
0x0026e4:	movs    	r1, #0x14
0x0026e6:	movs    	r2, #0x6b
0x0026e8:	adds    	r3, r6, #0
0x0026ea:	adds    	r0, r7, #0
0x0026ec:	bl      	#0x7e90
0x0026f0:	movs    	r1, #0
0x0026f2:	str     	r1, [sp]
0x0026f4:	str     	r1, [sp, #4]
0x0026f6:	movs    	r1, #0xff
0x0026f8:	movs    	r2, #0
0x0026fa:	adds    	r1, #0x45
0x0026fc:	movs    	r3, #0
0x0026fe:	adds    	r0, r7, #0
0x002700:	str     	r2, [sp, #8]
0x002702:	bl      	#0x7e90
0x002706:	bl      	#0x6f2c
0x00270a:	movs    	r1, #0
0x00270c:	movs    	r2, #0
0x00270e:	str     	r2, [sp, #8]
0x002710:	str     	r1, [sp]
0x002712:	str     	r1, [sp, #4]
0x002714:	movs    	r1, #0xe1
0x002716:	movs    	r2, #0x50
0x002718:	movs    	r3, #0
0x00271a:	adds    	r0, r7, #0
0x00271c:	bl      	#0x7e90
0x002720:	cmp     	r0, #1
0x002722:	beq     	#0x2766
0x002724:	cmp     	r0, #2
0x002726:	beq     	#0x2780
0x002728:	cmp     	r0, #4
0x00272a:	beq     	#0x274c
0x00272c:	cmp     	r0, #5
0x00272e:	bne     	#0x2748
0x002730:	movs    	r2, #0
0x002732:	movs    	r1, #0
0x002734:	str     	r2, [sp, #8]
0x002736:	ldr     	r2, [pc, #0x68]
0x002738:	str     	r1, [sp]
0x00273a:	str     	r1, [sp, #4]
0x00273c:	movs    	r3, #0
0x00273e:	add     	r2, pc
0x002740:	movs    	r1, #0x33
0x002742:	adds    	r0, r7, #0
0x002744:	bl      	#0x7e90
0x002748:	add     	sp, #0xc
0x00274a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0027b0 =====
0x0027b0:	push    	{r4, r5, r6, r7, lr}
0x0027b2:	sub     	sp, #0xc
0x0027b4:	ldr     	r4, [sp, #0x24]
0x0027b6:	adds    	r7, r2, #0
0x0027b8:	adds    	r6, r1, #0
0x0027ba:	adds    	r5, r3, #0
0x0027bc:	cmp     	r4, #0
0x0027be:	ble     	#0x2816
0x0027c0:	movs    	r1, #0
0x0027c2:	movs    	r2, #0
0x0027c4:	str     	r2, [sp, #8]
0x0027c6:	str     	r1, [sp]
0x0027c8:	str     	r1, [sp, #4]
0x0027ca:	movs    	r1, #0xe1
0x0027cc:	movs    	r2, #0x4c
0x0027ce:	movs    	r3, #0
0x0027d0:	movs    	r0, #0xf1
0x0027d2:	lsls    	r0, r0, #9
0x0027d4:	bl      	#0x7e90
0x0027d8:	mov     	ip, r0
0x0027da:	movs    	r0, #2
0x0027dc:	movs    	r2, #0
0x0027de:	movs    	r1, #0
0x0027e0:	str     	r1, [sp, #4]
0x0027e2:	str     	r0, [sp]
0x0027e4:	movs    	r0, #0xf1
0x0027e6:	movs    	r1, #0x99
0x0027e8:	str     	r2, [sp, #8]
0x0027ea:	movs    	r3, #1
0x0027ec:	lsls    	r0, r0, #9
0x0027ee:	mov     	r2, ip
0x0027f0:	bl      	#0x7e90
0x0027f4:	cmp     	r0, r4
0x0027f6:	bge     	#0x2816
0x0027f8:	movs    	r2, #0
0x0027fa:	movs    	r1, #0
0x0027fc:	str     	r2, [sp, #8]
0x0027fe:	ldr     	r2, [pc, #0xc4]
0x002800:	str     	r1, [sp]
0x002802:	str     	r1, [sp, #4]
0x002804:	movs    	r3, #0
0x002806:	add     	r2, pc
0x002808:	movs    	r1, #0x33
0x00280a:	movs    	r0, #0xf1
0x00280c:	lsls    	r0, r0, #9
0x00280e:	bl      	#0x7e90
0x002812:	add     	sp, #0xc
0x002814:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0028cc =====
0x0028cc:	push    	{r4, r5, r6, r7, lr}
0x0028ce:	sub     	sp, #0xc
0x0028d0:	movs    	r1, #0
0x0028d2:	movs    	r2, #0
0x0028d4:	str     	r2, [sp, #8]
0x0028d6:	str     	r1, [sp]
0x0028d8:	str     	r1, [sp, #4]
0x0028da:	movs    	r7, #0xf1
0x0028dc:	movs    	r6, #0
0x0028de:	adds    	r3, r6, #0
0x0028e0:	lsls    	r7, r7, #9
0x0028e2:	movs    	r1, #0x44
0x0028e4:	adds    	r2, r0, #0
0x0028e6:	adds    	r4, r0, #0
0x0028e8:	adds    	r0, r7, #0
0x0028ea:	bl      	#0x7e90
0x0028ee:	movs    	r1, #0
0x0028f0:	str     	r1, [sp]
0x0028f2:	str     	r1, [sp, #4]
0x0028f4:	movs    	r2, #0
0x0028f6:	str     	r2, [sp, #8]
0x0028f8:	movs    	r1, #0x45
0x0028fa:	adds    	r3, r6, #0
0x0028fc:	adds    	r0, r7, #0
0x0028fe:	ldr     	r2, [r4, #8]
0x002900:	bl      	#0x7e90
0x002904:	movs    	r1, #0
0x002906:	str     	r1, [sp]
0x002908:	str     	r1, [sp, #4]
0x00290a:	movs    	r2, #0
0x00290c:	str     	r2, [sp, #8]
0x00290e:	movs    	r1, #0x46
0x002910:	adds    	r5, r0, #0
0x002912:	adds    	r3, r6, #0
0x002914:	adds    	r0, r7, #0
0x002916:	ldr     	r2, [r4, #8]
0x002918:	bl      	#0x7e90
0x00291c:	ldr     	r6, [pc, #0x54]
0x00291e:	lsls    	r4, r0, #0x18
0x002920:	add     	r6, sb
0x002922:	ldr     	r3, [r6, #0x50]
0x002924:	asrs    	r4, r4, #0x18
0x002926:	cmp     	r3, #0
0x002928:	beq     	#0x294c
0x00292a:	movs    	r1, #0
0x00292c:	movs    	r2, #0
0x00292e:	str     	r2, [sp, #8]
0x002930:	str     	r1, [sp]
0x002932:	str     	r1, [sp, #4]
0x002934:	movs    	r1, #0xa6
0x002936:	adds    	r2, r5, #0
0x002938:	adds    	r0, r7, #0
0x00293a:	ldr     	r3, [r3, #8]
0x00293c:	bl      	#0x7e90
0x002940:	cmp     	r0, #0
0x002942:	beq     	#0x294c
0x002944:	adds    	r0, #0x40
0x002946:	strb    	r4, [r0, #0xf]
0x002948:	add     	sp, #0xc
0x00294a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002978 =====
0x002978:	push    	{r4, r5, r6, r7, lr}
0x00297a:	ldr     	r7, [pc, #0x288]
0x00297c:	sub     	sp, #0x44
0x00297e:	add     	r7, sb
0x002980:	ldr     	r0, [r7, #0x50]
0x002982:	movs    	r4, #0
0x002984:	ldr     	r2, [r0, #0x10]
0x002986:	ldr     	r1, [r0]
0x002988:	lsls    	r3, r2, #2
0x00298a:	ldr     	r5, [r1, r3]
0x00298c:	ldr     	r1, [r0, #0x28]
0x00298e:	lsls    	r2, r2, #1
0x002990:	ldrsh   	r1, [r1, r2]
0x002992:	adds    	r3, r4, #0
0x002994:	str     	r1, [sp, #0x40]
0x002996:	ldr     	r0, [r0, #0x2c]
0x002998:	movs    	r1, #0
0x00299a:	ldrsh   	r0, [r0, r2]
0x00299c:	movs    	r2, #0
0x00299e:	str     	r2, [sp, #8]
0x0029a0:	str     	r1, [sp]
0x0029a2:	str     	r1, [sp, #4]
0x0029a4:	movs    	r1, #0xff
0x0029a6:	adds    	r2, r5, #0
0x0029a8:	str     	r0, [sp, #0x3c]
0x0029aa:	movs    	r0, #0xf1
0x0029ac:	adds    	r1, #0x2e
0x0029ae:	lsls    	r0, r0, #9
0x0029b0:	bl      	#0x7e90
0x0029b4:	lsls    	r0, r0, #0x18
0x0029b6:	asrs    	r0, r0, #0x18
0x0029b8:	str     	r0, [sp, #0x30]
0x0029ba:	add     	r2, sp, #0x34
0x0029bc:	str     	r2, [sp, #8]
0x0029be:	movs    	r0, #0
0x0029c0:	ldr     	r2, [pc, #0x244]
0x0029c2:	add     	r1, sp, #0x38
0x0029c4:	str     	r1, [sp, #4]
0x0029c6:	str     	r0, [sp]
0x0029c8:	adds    	r3, r4, #0
0x0029ca:	add     	r2, pc
0x0029cc:	movs    	r1, #0x2a
0x0029ce:	movs    	r0, #0xf1
0x0029d0:	lsls    	r0, r0, #9
0x0029d2:	bl      	#0x7e90
0x0029d6:	movs    	r1, #0
0x0029d8:	str     	r1, [sp]
0x0029da:	str     	r1, [sp, #4]
0x0029dc:	movs    	r2, #0
0x0029de:	str     	r2, [sp, #8]
0x0029e0:	movs    	r1, #0x11
0x0029e2:	movs    	r3, #4
0x0029e4:	movs    	r0, #0xf1
0x0029e6:	lsls    	r0, r0, #9
0x0029e8:	ldr     	r2, [r7, #0xc]
0x0029ea:	bl      	#0x7e90
0x0029ee:	movs    	r1, #0
0x0029f0:	adds    	r6, r0, #0
0x0029f2:	movs    	r2, #0
0x0029f4:	str     	r2, [sp, #8]
0x0029f6:	str     	r1, [sp]
0x0029f8:	str     	r1, [sp, #4]
0x0029fa:	movs    	r1, #0xe1
0x0029fc:	movs    	r2, #0x4a
0x0029fe:	movs    	r0, #0xf1
0x002a00:	adds    	r3, r4, #0
0x002a02:	lsls    	r0, r0, #9
0x002a04:	bl      	#0x7e90
0x002a08:	movs    	r1, #0
0x002a0a:	movs    	r2, #0
0x002a0c:	str     	r2, [sp, #8]
0x002a0e:	str     	r1, [sp]
0x002a10:	str     	r1, [sp, #4]
0x002a12:	str     	r0, [sp, #0xc]
0x002a14:	movs    	r0, #0xf1
0x002a16:	movs    	r1, #0xe1
0x002a18:	movs    	r2, #0x27
0x002a1a:	adds    	r3, r4, #0
0x002a1c:	lsls    	r0, r0, #9
0x002a1e:	bl      	#0x7e90
0x002a22:	blx     	#0x91c
0x002a26:	lsrs    	r0, r1, #0x1f
0x002a28:	adds    	r0, r0, r1
0x002a2a:	asrs    	r0, r0, #1
0x002a2c:	lsls    	r0, r0, #1
0x002a2e:	subs    	r0, r1, r0
0x002a30:	lsls    	r3, r0, #1
0x002a32:	ldr     	r1, [sp, #0x40]
0x002a34:	adds    	r0, r3, r0
0x002a36:	adds    	r0, r0, r1
0x002a38:	str     	r0, [sp, #0x10]
0x002a3a:	ldr     	r0, [sp, #0x3c]
0x002a3c:	movs    	r1, #0
0x002a3e:	subs    	r0, #0x1e
0x002a40:	movs    	r2, #0
0x002a42:	str     	r2, [sp, #8]
0x002a44:	str     	r0, [sp, #0x14]
0x002a46:	str     	r1, [sp]
0x002a48:	str     	r1, [sp, #4]
0x002a4a:	movs    	r1, #0xe1
0x002a4c:	movs    	r0, #0xf1
0x002a4e:	movs    	r2, #0x4a
0x002a50:	adds    	r3, r4, #0
0x002a52:	lsls    	r0, r0, #9
0x002a54:	str     	r4, [sp, #0x1c]
0x002a56:	str     	r4, [sp, #0x18]
0x002a58:	bl      	#0x7e90
0x002a5c:	movs    	r3, #8
0x002a5e:	ldrsh   	r0, [r0, r3]
0x002a60:	movs    	r1, #0
0x002a62:	movs    	r2, #0
0x002a64:	str     	r0, [sp, #0x20]
0x002a66:	str     	r1, [sp]
0x002a68:	str     	r2, [sp, #8]
0x002a6a:	str     	r1, [sp, #4]
0x002a6c:	movs    	r1, #0xe1
0x002a6e:	movs    	r2, #0x4a
0x002a70:	movs    	r0, #0xf1
0x002a72:	adds    	r3, r4, #0
0x002a74:	lsls    	r0, r0, #9
0x002a76:	bl      	#0x7e90
0x002a7a:	movs    	r3, #0xa
0x002a7c:	ldrsh   	r0, [r0, r3]
0x002a7e:	movs    	r1, #0
0x002a80:	movs    	r2, #0
0x002a82:	str     	r0, [sp, #0x24]
0x002a84:	movs    	r0, #0xff
0x002a86:	adds    	r0, #1
0x002a88:	str     	r0, [sp, #0x28]
0x002a8a:	str     	r1, [sp, #4]
0x002a8c:	str     	r1, [sp]
0x002a8e:	movs    	r1, #0x20
0x002a90:	str     	r2, [sp, #8]
0x002a92:	movs    	r0, #0xf1
0x002a94:	adds    	r3, r4, #0
0x002a96:	lsls    	r0, r0, #9
0x002a98:	add     	r2, sp, #0xc
0x002a9a:	str     	r4, [sp, #0x2c]
0x002a9c:	bl      	#0x7e90
0x002aa0:	movs    	r1, #0
0x002aa2:	movs    	r2, #0

; ===== candidate_002c0c =====
0x002c0c:	push    	{r4, r5, r6, r7, lr}
0x002c0e:	ldr     	r5, [pc, #0x270]
0x002c10:	sub     	sp, #0x3c
0x002c12:	add     	r5, sb
0x002c14:	ldr     	r0, [r5, #0x2c]
0x002c16:	bl      	#0x6268
0x002c1a:	adds    	r6, r0, #0
0x002c1c:	ldr     	r0, [r5, #0x2c]
0x002c1e:	bl      	#0x622c
0x002c22:	movs    	r1, #0
0x002c24:	movs    	r2, #0
0x002c26:	str     	r2, [sp, #8]
0x002c28:	str     	r1, [sp]
0x002c2a:	str     	r1, [sp, #4]
0x002c2c:	adds    	r4, r0, #0
0x002c2e:	ldr     	r0, [r5, #0x50]
0x002c30:	movs    	r1, #0x11
0x002c32:	ldr     	r2, [r0]
0x002c34:	movs    	r0, #0xf1
0x002c36:	movs    	r3, #4
0x002c38:	lsls    	r0, r0, #9
0x002c3a:	bl      	#0x7e90
0x002c3e:	ldr     	r1, [r5, #0x2c]
0x002c40:	blx     	#0x20
0x002c44:	adds    	r7, r1, #0
0x002c46:	cmp     	r6, #0
0x002c48:	beq     	#0x2d2e
0x002c4a:	ldr     	r0, [r4, #0x30]
0x002c4c:	movs    	r5, #0
0x002c4e:	adds    	r3, r0, #1
0x002c50:	bne     	#0x2d0a
0x002c52:	movs    	r1, #0
0x002c54:	movs    	r2, #0
0x002c56:	str     	r2, [sp, #8]
0x002c58:	str     	r1, [sp]
0x002c5a:	str     	r1, [sp, #4]
0x002c5c:	movs    	r1, #0xe1
0x002c5e:	movs    	r2, #0x4a
0x002c60:	adds    	r3, r5, #0
0x002c62:	movs    	r0, #0xf1
0x002c64:	lsls    	r0, r0, #9
0x002c66:	bl      	#0x7e90
0x002c6a:	movs    	r1, #0
0x002c6c:	movs    	r2, #0
0x002c6e:	str     	r2, [sp, #8]
0x002c70:	str     	r1, [sp]
0x002c72:	str     	r1, [sp, #4]
0x002c74:	str     	r0, [sp, #0x10]
0x002c76:	movs    	r0, #0xf1
0x002c78:	movs    	r1, #0xe1
0x002c7a:	movs    	r2, #0x27
0x002c7c:	adds    	r3, r5, #0
0x002c7e:	lsls    	r0, r0, #9
0x002c80:	bl      	#0x7e90
0x002c84:	blx     	#0x91c
0x002c88:	lsrs    	r0, r1, #0x1f
0x002c8a:	adds    	r0, r0, r1
0x002c8c:	asrs    	r0, r0, #1
0x002c8e:	lsls    	r0, r0, #1
0x002c90:	subs    	r0, r1, r0
0x002c92:	ldr     	r1, [r4, #0x28]
0x002c94:	lsls    	r2, r7, #1
0x002c96:	ldrsh   	r1, [r1, r2]
0x002c98:	lsls    	r3, r0, #1
0x002c9a:	adds    	r0, r3, r0
0x002c9c:	adds    	r0, r0, r1
0x002c9e:	str     	r0, [sp, #0x14]
0x002ca0:	ldr     	r0, [r4, #0x2c]
0x002ca2:	movs    	r1, #0
0x002ca4:	ldrsh   	r0, [r0, r2]
0x002ca6:	str     	r5, [sp, #0x20]
0x002ca8:	movs    	r2, #0
0x002caa:	subs    	r0, #0x1e
0x002cac:	str     	r0, [sp, #0x18]
0x002cae:	str     	r2, [sp, #8]
0x002cb0:	str     	r1, [sp]
0x002cb2:	str     	r1, [sp, #4]
0x002cb4:	movs    	r1, #0xe1
0x002cb6:	movs    	r2, #0x4a
0x002cb8:	movs    	r0, #0xf1
0x002cba:	adds    	r3, r5, #0
0x002cbc:	lsls    	r0, r0, #9
0x002cbe:	str     	r5, [sp, #0x1c]
0x002cc0:	bl      	#0x7e90
0x002cc4:	movs    	r3, #8
0x002cc6:	ldrsh   	r0, [r0, r3]
0x002cc8:	movs    	r1, #0
0x002cca:	movs    	r2, #0
0x002ccc:	str     	r0, [sp, #0x24]
0x002cce:	str     	r1, [sp, #4]
0x002cd0:	str     	r2, [sp, #8]
0x002cd2:	str     	r1, [sp]
0x002cd4:	movs    	r1, #0xe1
0x002cd6:	movs    	r2, #0x4a
0x002cd8:	movs    	r0, #0xf1
0x002cda:	adds    	r3, r5, #0
0x002cdc:	lsls    	r0, r0, #9
0x002cde:	bl      	#0x7e90
0x002ce2:	movs    	r3, #0xa
0x002ce4:	ldrsh   	r0, [r0, r3]
0x002ce6:	movs    	r1, #0
0x002ce8:	movs    	r2, #0
0x002cea:	str     	r0, [sp, #0x28]
0x002cec:	movs    	r0, #0xff
0x002cee:	adds    	r0, #1
0x002cf0:	str     	r0, [sp, #0x2c]
0x002cf2:	str     	r1, [sp]
0x002cf4:	str     	r1, [sp, #4]
0x002cf6:	movs    	r1, #0x20
0x002cf8:	movs    	r0, #0xf1
0x002cfa:	adds    	r3, r5, #0
0x002cfc:	str     	r2, [sp, #8]
0x002cfe:	add     	r2, sp, #0x10
0x002d00:	lsls    	r0, r0, #9
0x002d02:	str     	r5, [sp, #0x30]
0x002d04:	bl      	#0x7e90
0x002d08:	b       	#0x2de4
0x002d0a:	movs    	r1, #0
0x002d0c:	movs    	r2, #0
0x002d0e:	str     	r2, [sp, #8]
0x002d10:	str     	r1, [sp]
0x002d12:	str     	r1, [sp, #4]
0x002d14:	movs    	r1, #0xe1
0x002d16:	movs    	r2, #0x4a
0x002d18:	adds    	r3, r5, #0
0x002d1a:	movs    	r0, #0xf1
0x002d1c:	lsls    	r0, r0, #9
0x002d1e:	bl      	#0x7e90
0x002d22:	movs    	r2, #0
0x002d24:	movs    	r1, #0
0x002d26:	str     	r1, [sp]
0x002d28:	str     	r1, [sp, #4]
0x002d2a:	str     	r0, [sp, #0x10]
0x002d2c:	b       	#0x2d30
0x002d2e:	b       	#0x2e64
0x002d30:	str     	r2, [sp, #8]
0x002d32:	movs    	r2, #0x27
0x002d34:	adds    	r3, r5, #0
0x002d36:	movs    	r1, #0xe1
0x002d38:	movs    	r0, #0xf1
0x002d3a:	lsls    	r0, r0, #9

; ===== candidate_002e88 =====
0x002e88:	push    	{r4, r5, r6, r7, lr}
0x002e8a:	sub     	sp, #0x3c
0x002e8c:	ldr     	r4, [pc, #0x290]
0x002e8e:	movs    	r1, #0
0x002e90:	movs    	r2, #0
0x002e92:	str     	r2, [sp, #8]
0x002e94:	str     	r1, [sp]
0x002e96:	str     	r1, [sp, #4]
0x002e98:	add     	r4, sb
0x002e9a:	ldr     	r0, [r4, #0x50]
0x002e9c:	movs    	r1, #0x11
0x002e9e:	ldr     	r2, [r0]
0x002ea0:	movs    	r0, #0xf1
0x002ea2:	movs    	r3, #4
0x002ea4:	lsls    	r0, r0, #9
0x002ea6:	bl      	#0x7e90
0x002eaa:	ldr     	r1, [r4, #0x34]
0x002eac:	blx     	#0x20
0x002eb0:	cmp     	r0, #0
0x002eb2:	bne     	#0x2eb8
0x002eb4:	ldr     	r4, [r4, #0x50]
0x002eb6:	b       	#0x2eba
0x002eb8:	ldr     	r4, [r4, #0x54]
0x002eba:	ldr     	r0, [r4]
0x002ebc:	lsls    	r6, r1, #2
0x002ebe:	ldr     	r0, [r0, r6]
0x002ec0:	cmp     	r0, #0
0x002ec2:	beq     	#0x2fa8
0x002ec4:	ldr     	r2, [r4, #0x28]
0x002ec6:	lsls    	r0, r1, #1
0x002ec8:	ldrsh   	r1, [r2, r0]
0x002eca:	movs    	r5, #0
0x002ecc:	str     	r1, [sp, #0x34]
0x002ece:	ldr     	r1, [r4, #0x2c]
0x002ed0:	ldrsh   	r7, [r1, r0]
0x002ed2:	ldr     	r0, [r4, #0x30]
0x002ed4:	adds    	r3, r0, #1
0x002ed6:	bne     	#0x2f88
0x002ed8:	movs    	r1, #0
0x002eda:	movs    	r2, #0
0x002edc:	str     	r2, [sp, #8]
0x002ede:	str     	r1, [sp]
0x002ee0:	str     	r1, [sp, #4]
0x002ee2:	movs    	r1, #0xe1
0x002ee4:	movs    	r2, #0x4a
0x002ee6:	adds    	r3, r5, #0
0x002ee8:	movs    	r0, #0xf1
0x002eea:	lsls    	r0, r0, #9
0x002eec:	bl      	#0x7e90
0x002ef0:	movs    	r1, #0
0x002ef2:	movs    	r2, #0
0x002ef4:	str     	r2, [sp, #8]
0x002ef6:	str     	r1, [sp]
0x002ef8:	str     	r1, [sp, #4]
0x002efa:	str     	r0, [sp, #0x10]
0x002efc:	movs    	r0, #0xf1
0x002efe:	movs    	r1, #0xe1
0x002f00:	movs    	r2, #0x27
0x002f02:	adds    	r3, r5, #0
0x002f04:	lsls    	r0, r0, #9
0x002f06:	bl      	#0x7e90
0x002f0a:	blx     	#0x91c
0x002f0e:	lsrs    	r0, r1, #0x1f
0x002f10:	adds    	r0, r0, r1
0x002f12:	asrs    	r0, r0, #1
0x002f14:	lsls    	r0, r0, #1
0x002f16:	subs    	r0, r1, r0
0x002f18:	lsls    	r3, r0, #1
0x002f1a:	ldr     	r1, [sp, #0x34]
0x002f1c:	adds    	r0, r3, r0
0x002f1e:	adds    	r0, r0, r1
0x002f20:	movs    	r1, #0
0x002f22:	subs    	r7, #0x1e
0x002f24:	str     	r5, [sp, #0x20]
0x002f26:	movs    	r2, #0
0x002f28:	str     	r2, [sp, #8]
0x002f2a:	str     	r1, [sp]
0x002f2c:	str     	r1, [sp, #4]
0x002f2e:	str     	r0, [sp, #0x14]
0x002f30:	movs    	r0, #0xf1
0x002f32:	movs    	r1, #0xe1
0x002f34:	movs    	r2, #0x4a
0x002f36:	adds    	r3, r5, #0
0x002f38:	lsls    	r0, r0, #9
0x002f3a:	str     	r7, [sp, #0x18]
0x002f3c:	str     	r5, [sp, #0x1c]
0x002f3e:	bl      	#0x7e90
0x002f42:	movs    	r3, #8
0x002f44:	ldrsh   	r0, [r0, r3]
0x002f46:	movs    	r1, #0
0x002f48:	movs    	r2, #0
0x002f4a:	str     	r0, [sp, #0x24]
0x002f4c:	str     	r1, [sp, #4]
0x002f4e:	str     	r2, [sp, #8]
0x002f50:	str     	r1, [sp]
0x002f52:	movs    	r1, #0xe1
0x002f54:	movs    	r2, #0x4a
0x002f56:	movs    	r0, #0xf1
0x002f58:	adds    	r3, r5, #0
0x002f5a:	lsls    	r0, r0, #9
0x002f5c:	bl      	#0x7e90
0x002f60:	movs    	r3, #0xa
0x002f62:	ldrsh   	r0, [r0, r3]
0x002f64:	movs    	r1, #0
0x002f66:	movs    	r2, #0
0x002f68:	str     	r0, [sp, #0x28]
0x002f6a:	movs    	r0, #0xff
0x002f6c:	adds    	r0, #1
0x002f6e:	str     	r0, [sp, #0x2c]
0x002f70:	str     	r1, [sp]
0x002f72:	str     	r1, [sp, #4]
0x002f74:	movs    	r1, #0x20
0x002f76:	movs    	r0, #0xf1
0x002f78:	adds    	r3, r5, #0
0x002f7a:	str     	r2, [sp, #8]
0x002f7c:	add     	r2, sp, #0x10
0x002f7e:	lsls    	r0, r0, #9
0x002f80:	str     	r5, [sp, #0x30]
0x002f82:	bl      	#0x7e90
0x002f86:	b       	#0x3058
0x002f88:	movs    	r1, #0
0x002f8a:	movs    	r2, #0
0x002f8c:	str     	r2, [sp, #8]
0x002f8e:	str     	r1, [sp]
0x002f90:	str     	r1, [sp, #4]
0x002f92:	movs    	r1, #0xe1
0x002f94:	movs    	r2, #0x4a
0x002f96:	adds    	r3, r5, #0
0x002f98:	movs    	r0, #0xf1
0x002f9a:	lsls    	r0, r0, #9
0x002f9c:	bl      	#0x7e90
0x002fa0:	movs    	r2, #0
0x002fa2:	movs    	r1, #0
0x002fa4:	str     	r0, [sp, #0x10]
0x002fa6:	b       	#0x2faa
0x002fa8:	b       	#0x311a
0x002faa:	str     	r1, [sp]
0x002fac:	str     	r1, [sp, #4]
0x002fae:	str     	r2, [sp, #8]
0x002fb0:	movs    	r2, #0x27
0x002fb2:	movs    	r1, #0xe1

; ===== candidate_003128 =====
0x003128:	push    	{r4, r5, r6, r7, lr}
0x00312a:	sub     	sp, #0x3c
0x00312c:	movs    	r1, #0
0x00312e:	str     	r1, [sp]
0x003130:	str     	r1, [sp, #4]
0x003132:	movs    	r7, #0
0x003134:	movs    	r2, #0
0x003136:	adds    	r3, r7, #0
0x003138:	movs    	r1, #0x1c
0x00313a:	movs    	r4, #0x32
0x00313c:	movs    	r0, #0xf1
0x00313e:	lsls    	r0, r0, #9
0x003140:	str     	r2, [sp, #8]
0x003142:	bl      	#0x7e90
0x003146:	ldr     	r6, [pc, #0x3b0]
0x003148:	movs    	r3, #0x20
0x00314a:	add     	r6, sb
0x00314c:	ldrsh   	r0, [r6, r3]
0x00314e:	movs    	r1, #0
0x003150:	str     	r1, [sp]
0x003152:	str     	r1, [sp, #4]
0x003154:	movs    	r2, #0
0x003156:	str     	r0, [sp, #0x38]
0x003158:	movs    	r0, #0xf1
0x00315a:	movs    	r1, #0x1c
0x00315c:	adds    	r3, r7, #0
0x00315e:	movs    	r5, #0x1e
0x003160:	lsls    	r0, r0, #9
0x003162:	str     	r2, [sp, #8]
0x003164:	bl      	#0x7e90
0x003168:	movs    	r3, #0x20
0x00316a:	ldrsh   	r1, [r6, r3]
0x00316c:	adds    	r6, r5, #0
0x00316e:	movs    	r2, #0
0x003170:	subs    	r0, r0, r1
0x003172:	movs    	r1, #0
0x003174:	str     	r1, [sp]
0x003176:	str     	r1, [sp, #4]
0x003178:	str     	r0, [sp, #0x34]
0x00317a:	movs    	r0, #0xf1
0x00317c:	movs    	r1, #0x7d
0x00317e:	adds    	r3, r7, #0
0x003180:	lsls    	r0, r0, #9
0x003182:	str     	r2, [sp, #8]
0x003184:	bl      	#0x7e90
0x003188:	movs    	r2, #0
0x00318a:	movs    	r1, #0
0x00318c:	str     	r2, [sp, #8]
0x00318e:	movs    	r2, #0xff
0x003190:	str     	r1, [sp]
0x003192:	str     	r1, [sp, #4]
0x003194:	adds    	r3, r7, #0
0x003196:	adds    	r2, #0x32
0x003198:	movs    	r1, #0xe1
0x00319a:	movs    	r0, #0xf1
0x00319c:	lsls    	r0, r0, #9
0x00319e:	bl      	#0x7e90
0x0031a2:	cmp     	r0, #0
0x0031a4:	beq     	#0x31ac
0x0031a6:	movs    	r5, #0x11
0x0031a8:	movs    	r6, #0x11
0x0031aa:	movs    	r4, #0x21
0x0031ac:	ldr     	r1, [pc, #0x348]
0x0031ae:	add     	r1, sb
0x0031b0:	adds    	r1, #0x80
0x0031b2:	ldr     	r0, [r1]
0x0031b4:	cmp     	r0, #1
0x0031b6:	beq     	#0x31c0
0x0031b8:	cmp     	r0, #2
0x0031ba:	beq     	#0x31c0
0x0031bc:	cmp     	r0, #3
0x0031be:	bne     	#0x31f6
0x0031c0:	movs    	r1, #0
0x0031c2:	movs    	r2, #0
0x0031c4:	str     	r2, [sp, #8]
0x0031c6:	str     	r1, [sp]
0x0031c8:	str     	r1, [sp, #4]
0x0031ca:	movs    	r7, #0xf1
0x0031cc:	lsls    	r7, r7, #9
0x0031ce:	movs    	r1, #0xe1
0x0031d0:	movs    	r2, #0xed
0x0031d2:	movs    	r3, #0
0x0031d4:	adds    	r0, r7, #0
0x0031d6:	bl      	#0x7e90
0x0031da:	cmp     	r0, #0
0x0031dc:	ble     	#0x32c2
0x0031de:	movs    	r1, #0
0x0031e0:	str     	r1, [sp]
0x0031e2:	str     	r1, [sp, #4]
0x0031e4:	movs    	r1, #0xff
0x0031e6:	movs    	r2, #0
0x0031e8:	adds    	r1, #0x25
0x0031ea:	movs    	r3, #0
0x0031ec:	adds    	r0, r7, #0
0x0031ee:	str     	r2, [sp, #8]
0x0031f0:	bl      	#0x7e90
0x0031f4:	b       	#0x320e
0x0031f6:	movs    	r1, #0
0x0031f8:	movs    	r2, #0
0x0031fa:	str     	r2, [sp, #8]
0x0031fc:	str     	r1, [sp]
0x0031fe:	str     	r1, [sp, #4]
0x003200:	movs    	r1, #0x14
0x003202:	movs    	r2, #0xed
0x003204:	movs    	r3, #1
0x003206:	movs    	r0, #0xf1
0x003208:	lsls    	r0, r0, #9
0x00320a:	bl      	#0x7e90
0x00320e:	movs    	r1, #0
0x003210:	movs    	r2, #0
0x003212:	str     	r2, [sp, #8]
0x003214:	str     	r1, [sp]
0x003216:	str     	r1, [sp, #4]
0x003218:	movs    	r7, #0
0x00321a:	adds    	r3, r7, #0
0x00321c:	movs    	r1, #0xe1
0x00321e:	movs    	r2, #0x4b
0x003220:	movs    	r0, #0xf1
0x003222:	lsls    	r0, r0, #9
0x003224:	bl      	#0x7e90
0x003228:	cmp     	r0, #0
0x00322a:	beq     	#0x3270
0x00322c:	movs    	r1, #0
0x00322e:	str     	r1, [sp]
0x003230:	str     	r1, [sp, #4]
0x003232:	movs    	r2, #0
0x003234:	movs    	r1, #0x9f
0x003236:	adds    	r3, r7, #0
0x003238:	movs    	r0, #0xf1
0x00323a:	lsls    	r0, r0, #9
0x00323c:	str     	r2, [sp, #8]
0x00323e:	bl      	#0x7e90
0x003242:	movs    	r1, #0
0x003244:	str     	r1, [sp]
0x003246:	str     	r1, [sp, #4]
0x003248:	movs    	r2, #0
0x00324a:	movs    	r1, #0xa3
0x00324c:	adds    	r3, r7, #0
0x00324e:	movs    	r0, #0xf1
0x003250:	lsls    	r0, r0, #9
0x003252:	str     	r2, [sp, #8]

; ===== candidate_0035a2 =====
0x0035a2:	push    	{r4, r5, r6, r7, lr}
0x0035a4:	add     	r0, sb
0x0035a6:	ldr     	r0, [r0, #0x50]
0x0035a8:	sub     	sp, #0x4c
0x0035aa:	ldr     	r1, [r0, #4]
0x0035ac:	ldr     	r0, [r0, #0x10]
0x0035ae:	movs    	r2, #0
0x0035b0:	lsls    	r0, r0, #2
0x0035b2:	ldr     	r6, [r1, r0]
0x0035b4:	movs    	r1, #0
0x0035b6:	str     	r1, [sp]
0x0035b8:	str     	r1, [sp, #4]
0x0035ba:	str     	r2, [sp, #8]
0x0035bc:	adds    	r2, r6, #0
0x0035be:	movs    	r1, #0x26
0x0035c0:	movs    	r0, #0xf1
0x0035c2:	movs    	r3, #0
0x0035c4:	lsls    	r0, r0, #9
0x0035c6:	bl      	#0x7e90
0x0035ca:	adds    	r4, r0, #0
0x0035cc:	movs    	r0, #0x78
0x0035ce:	str     	r0, [sp, #0x40]
0x0035d0:	movs    	r1, #0
0x0035d2:	str     	r1, [sp]
0x0035d4:	str     	r1, [sp, #4]
0x0035d6:	movs    	r2, #0
0x0035d8:	movs    	r1, #0x1c
0x0035da:	movs    	r0, #0xf1
0x0035dc:	movs    	r3, #0
0x0035de:	lsls    	r0, r0, #9
0x0035e0:	str     	r2, [sp, #8]
0x0035e2:	bl      	#0x7e90
0x0035e6:	movs    	r1, #0
0x0035e8:	str     	r1, [sp]
0x0035ea:	str     	r1, [sp, #4]
0x0035ec:	adds    	r5, r0, #0
0x0035ee:	movs    	r2, #0
0x0035f0:	movs    	r0, #0xf1
0x0035f2:	movs    	r1, #0x1c
0x0035f4:	movs    	r3, #0
0x0035f6:	lsls    	r0, r0, #9
0x0035f8:	str     	r2, [sp, #8]
0x0035fa:	bl      	#0x7e90
0x0035fe:	subs    	r0, r0, r5
0x003600:	lsrs    	r1, r0, #0x1f
0x003602:	adds    	r0, r1, r0
0x003604:	asrs    	r7, r0, #1
0x003606:	movs    	r1, #0
0x003608:	movs    	r0, #0x1e
0x00360a:	movs    	r2, #0
0x00360c:	str     	r2, [sp, #8]
0x00360e:	str     	r0, [sp, #0x3c]
0x003610:	str     	r1, [sp]
0x003612:	str     	r1, [sp, #4]
0x003614:	movs    	r1, #0xe1
0x003616:	movs    	r0, #0xf1
0x003618:	movs    	r2, #0xed
0x00361a:	movs    	r3, #0
0x00361c:	lsls    	r0, r0, #9
0x00361e:	bl      	#0x7e90
0x003622:	cmp     	r0, #0
0x003624:	ble     	#0x370a
0x003626:	movs    	r1, #0
0x003628:	str     	r1, [sp]
0x00362a:	str     	r1, [sp, #4]
0x00362c:	movs    	r1, #0xff
0x00362e:	movs    	r2, #0
0x003630:	adds    	r1, #0x25
0x003632:	movs    	r3, #0
0x003634:	movs    	r0, #0xf1
0x003636:	lsls    	r0, r0, #9
0x003638:	str     	r2, [sp, #8]
0x00363a:	bl      	#0x7e90
0x00363e:	movs    	r2, #0
0x003640:	movs    	r1, #0
0x003642:	movs    	r0, #0
0x003644:	bl      	#0x7e40
0x003648:	cmp     	r4, #0
0x00364a:	ble     	#0x36c0
0x00364c:	ldr     	r0, [pc, #0x148]
0x00364e:	movs    	r1, #0
0x003650:	movs    	r2, #0
0x003652:	add     	r0, sb
0x003654:	subs    	r0, #0x80
0x003656:	str     	r2, [sp, #8]
0x003658:	str     	r1, [sp]
0x00365a:	str     	r1, [sp, #4]
0x00365c:	ldr     	r3, [r0, #0x38]
0x00365e:	movs    	r0, #0xf1
0x003660:	movs    	r1, #0x27
0x003662:	adds    	r2, r6, #0
0x003664:	lsls    	r0, r0, #9
0x003666:	bl      	#0x7e90
0x00366a:	str     	r0, [sp, #0x38]
0x00366c:	ldr     	r0, [pc, #0x128]
0x00366e:	str     	r7, [sp, #0x1c]
0x003670:	add     	r0, sb
0x003672:	subs    	r0, #0x48
0x003674:	str     	r0, [sp, #0x18]
0x003676:	ldr     	r0, [sp, #0x3c]
0x003678:	movs    	r1, #0
0x00367a:	str     	r0, [sp, #0x20]
0x00367c:	ldr     	r0, [sp, #0x40]
0x00367e:	movs    	r3, #0
0x003680:	str     	r0, [sp, #0x28]
0x003682:	movs    	r0, #4
0x003684:	str     	r5, [sp, #0x24]
0x003686:	movs    	r2, #0
0x003688:	str     	r1, [sp, #4]
0x00368a:	str     	r0, [sp, #0x2c]
0x00368c:	str     	r1, [sp]
0x00368e:	movs    	r1, #0x88
0x003690:	movs    	r0, #0xf1
0x003692:	str     	r2, [sp, #8]
0x003694:	str     	r3, [sp, #0x14]
0x003696:	str     	r6, [sp, #0x10]
0x003698:	str     	r4, [sp, #0x30]
0x00369a:	str     	r4, [sp, #0x34]
0x00369c:	add     	r2, sp, #0x10
0x00369e:	lsls    	r0, r0, #9
0x0036a0:	bl      	#0x7e90
0x0036a4:	movs    	r0, #1
0x0036a6:	movs    	r2, #0
0x0036a8:	movs    	r1, #0
0x0036aa:	str     	r1, [sp, #4]
0x0036ac:	str     	r0, [sp]
0x0036ae:	rsbs    	r3, r0, #0
0x0036b0:	movs    	r0, #0xf1
0x0036b2:	movs    	r1, #0x86
0x0036b4:	str     	r2, [sp, #8]
0x0036b6:	ldr     	r2, [sp, #0x38]
0x0036b8:	lsls    	r0, r0, #9
0x0036ba:	bl      	#0x7e90
0x0036be:	b       	#0x377c
0x0036c0:	ldr     	r4, [pc, #0xd8]
0x0036c2:	add     	r4, pc
0x0036c4:	movs    	r1, #0
0x0036c6:	movs    	r2, #0
0x0036c8:	str     	r2, [sp, #8]
0x0036ca:	str     	r1, [sp]
0x0036cc:	str     	r1, [sp, #4]

; ===== candidate_0037a0 =====
0x0037a0:	push    	{r4, r5, r6, r7, lr}
0x0037a2:	ldr     	r4, [pc, #0xcc]
0x0037a4:	sub     	sp, #0x2c
0x0037a6:	add     	r4, pc
0x0037a8:	movs    	r1, #0
0x0037aa:	str     	r1, [sp]
0x0037ac:	str     	r1, [sp, #4]
0x0037ae:	ldr     	r1, [pc, #0xc4]
0x0037b0:	movs    	r2, #0
0x0037b2:	str     	r2, [sp, #8]
0x0037b4:	add     	r1, sb
0x0037b6:	ldr     	r2, [r1, #0x58]
0x0037b8:	movs    	r1, #0x11
0x0037ba:	movs    	r3, #4
0x0037bc:	movs    	r0, #0xf1
0x0037be:	lsls    	r0, r0, #9
0x0037c0:	bl      	#0x7e90
0x0037c4:	adds    	r5, r0, #0
0x0037c6:	movs    	r0, #1
0x0037c8:	add     	r2, sp, #0x28
0x0037ca:	add     	r1, sp, #0x24
0x0037cc:	movs    	r6, #0
0x0037ce:	adds    	r3, r6, #0
0x0037d0:	str     	r1, [sp, #4]
0x0037d2:	str     	r2, [sp, #8]
0x0037d4:	str     	r0, [sp]
0x0037d6:	movs    	r0, #0xf1
0x0037d8:	adds    	r2, r4, #0
0x0037da:	movs    	r1, #0x2a
0x0037dc:	lsls    	r0, r0, #9
0x0037de:	bl      	#0x7e90
0x0037e2:	ldr     	r0, [sp, #0x28]
0x0037e4:	ldr     	r4, [sp, #0x24]
0x0037e6:	muls    	r0, r5, r0
0x0037e8:	movs    	r1, #0
0x0037ea:	adds    	r5, r0, #0
0x0037ec:	adds    	r5, #0xa
0x0037ee:	str     	r1, [sp]
0x0037f0:	str     	r1, [sp, #4]
0x0037f2:	movs    	r2, #0
0x0037f4:	adds    	r4, #0x28
0x0037f6:	adds    	r3, r6, #0
0x0037f8:	movs    	r1, #0x1c
0x0037fa:	movs    	r0, #0xf1
0x0037fc:	lsls    	r0, r0, #9
0x0037fe:	str     	r2, [sp, #8]
0x003800:	bl      	#0x7e90
0x003804:	subs    	r0, r0, r4
0x003806:	movs    	r1, #0
0x003808:	str     	r1, [sp]
0x00380a:	str     	r1, [sp, #4]
0x00380c:	asrs    	r7, r0, #1
0x00380e:	movs    	r2, #0
0x003810:	movs    	r0, #0xf1
0x003812:	movs    	r1, #0x1d
0x003814:	adds    	r3, r6, #0
0x003816:	lsls    	r0, r0, #9
0x003818:	str     	r2, [sp, #8]
0x00381a:	bl      	#0x7e90
0x00381e:	ldr     	r1, [pc, #0x54]
0x003820:	subs    	r0, r0, r5
0x003822:	add     	r1, sb
0x003824:	ldr     	r1, [r1, #0x58]
0x003826:	asrs    	r0, r0, #1
0x003828:	str     	r0, [sp, #0x14]
0x00382a:	ldr     	r0, [pc, #0x48]
0x00382c:	str     	r1, [sp, #0xc]
0x00382e:	add     	r0, sb
0x003830:	adds    	r0, #0x3c
0x003832:	str     	r0, [sp, #0x20]
0x003834:	movs    	r1, #0
0x003836:	movs    	r2, #0
0x003838:	str     	r1, [sp]
0x00383a:	str     	r1, [sp, #4]
0x00383c:	movs    	r1, #0x2b
0x00383e:	str     	r2, [sp, #8]
0x003840:	movs    	r0, #0xf1
0x003842:	adds    	r3, r6, #0
0x003844:	lsls    	r0, r0, #9
0x003846:	add     	r2, sp, #0xc
0x003848:	str     	r7, [sp, #0x10]
0x00384a:	str     	r4, [sp, #0x18]
0x00384c:	str     	r5, [sp, #0x1c]
0x00384e:	bl      	#0x7e90
0x003852:	movs    	r1, #0
0x003854:	movs    	r2, #0
0x003856:	str     	r2, [sp, #8]
0x003858:	str     	r1, [sp]
0x00385a:	str     	r1, [sp, #4]
0x00385c:	movs    	r1, #0x24
0x00385e:	movs    	r2, #1
0x003860:	movs    	r3, #1
0x003862:	movs    	r0, #0xf1
0x003864:	lsls    	r0, r0, #9
0x003866:	bl      	#0x7e90
0x00386a:	add     	sp, #0x2c
0x00386c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003878 =====
0x003878:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00387a:	movs    	r4, #0
0x00387c:	sub     	sp, #0x34
0x00387e:	adds    	r5, r0, #0
0x003880:	cmp     	r0, #0
0x003882:	str     	r4, [sp, #0x14]
0x003884:	beq     	#0x396a
0x003886:	movs    	r1, #0
0x003888:	str     	r1, [sp]
0x00388a:	str     	r1, [sp, #4]
0x00388c:	movs    	r2, #0
0x00388e:	movs    	r6, #0xf1
0x003890:	lsls    	r6, r6, #9
0x003892:	str     	r2, [sp, #8]
0x003894:	movs    	r1, #0x11
0x003896:	movs    	r3, #4
0x003898:	adds    	r0, r6, #0
0x00389a:	ldr     	r2, [r5]
0x00389c:	bl      	#0x7e90
0x0038a0:	str     	r0, [sp, #0x18]
0x0038a2:	ldr     	r2, [sp, #0x38]
0x0038a4:	adds    	r3, r2, #1
0x0038a6:	beq     	#0x38ac
0x0038a8:	ldr     	r0, [sp, #0x18]
0x0038aa:	str     	r0, [sp, #0x14]
0x0038ac:	ldr     	r0, [sp, #0x18]
0x0038ae:	cmp     	r0, #0
0x0038b0:	ble     	#0x396a
0x0038b2:	movs    	r0, #0
0x0038b4:	ldr     	r2, [sp, #0x38]
0x0038b6:	mvns    	r0, r0
0x0038b8:	cmp     	r2, r0
0x0038ba:	beq     	#0x38be
0x0038bc:	movs    	r0, #1
0x0038be:	str     	r0, [sp, #0x30]
0x0038c0:	lsls    	r1, r4, #2
0x0038c2:	ldr     	r0, [r5]
0x0038c4:	str     	r1, [sp, #0x2c]
0x0038c6:	ldr     	r0, [r0, r1]
0x0038c8:	str     	r0, [sp, #0x10]
0x0038ca:	cmp     	r0, #0
0x0038cc:	beq     	#0x39b4
0x0038ce:	movs    	r1, #0
0x0038d0:	movs    	r2, #0
0x0038d2:	ldr     	r0, [sp, #0x10]
0x0038d4:	str     	r2, [sp, #8]
0x0038d6:	str     	r1, [sp]
0x0038d8:	str     	r1, [sp, #4]
0x0038da:	ldr     	r0, [r0, #0x7c]
0x0038dc:	movs    	r1, #0x6e
0x0038de:	ldr     	r2, [r0, #0x1c]
0x0038e0:	movs    	r0, #0xf1
0x0038e2:	movs    	r3, #0
0x0038e4:	lsls    	r0, r0, #9
0x0038e6:	bl      	#0x7e90
0x0038ea:	ldr     	r7, [sp, #0x10]
0x0038ec:	adds    	r6, r0, #0
0x0038ee:	movs    	r3, #0xa
0x0038f0:	adds    	r7, #0x40
0x0038f2:	ldrsh   	r0, [r7, r3]
0x0038f4:	movs    	r2, #0
0x0038f6:	movs    	r1, #0
0x0038f8:	str     	r1, [sp, #4]
0x0038fa:	str     	r2, [sp, #8]
0x0038fc:	movs    	r3, #8
0x0038fe:	str     	r0, [sp]
0x003900:	ldrsh   	r0, [r7, r3]
0x003902:	movs    	r1, #0x74
0x003904:	adds    	r3, r0, #0
0x003906:	movs    	r0, #0xf1
0x003908:	adds    	r2, r6, #0
0x00390a:	lsls    	r0, r0, #9
0x00390c:	bl      	#0x7e90
0x003910:	ldr     	r1, [r5, #0x14]
0x003912:	lsls    	r0, r4, #1
0x003914:	ldrsh   	r1, [r1, r0]
0x003916:	ldr     	r2, [sp, #0x30]
0x003918:	ldr     	r7, [sp, #0x40]
0x00391a:	muls    	r1, r2, r1
0x00391c:	ldr     	r2, [sp, #0x3c]
0x00391e:	adds    	r7, #0x32
0x003920:	adds    	r6, r1, r2
0x003922:	ldr     	r1, [r5, #0x28]
0x003924:	strh    	r6, [r1, r0]
0x003926:	ldr     	r1, [r5, #0x2c]
0x003928:	strh    	r7, [r1, r0]
0x00392a:	ldr     	r0, [pc, #0x174]
0x00392c:	add     	r0, sb
0x00392e:	ldr     	r0, [r0]
0x003930:	cmp     	r0, #5
0x003932:	beq     	#0x3a1c
0x003934:	ldr     	r2, [sp, #0x5c]
0x003936:	adds    	r3, r6, #0
0x003938:	adds    	r1, r4, #0
0x00393a:	str     	r2, [sp, #4]
0x00393c:	ldr     	r2, [sp, #0x38]
0x00393e:	adds    	r0, r5, #0
0x003940:	str     	r7, [sp]
0x003942:	bl      	#0x4010
0x003946:	adds    	r3, r6, #0
0x003948:	adds    	r1, r4, #0
0x00394a:	adds    	r0, r5, #0
0x00394c:	str     	r7, [sp]
0x00394e:	ldr     	r2, [sp, #0x38]
0x003950:	bl      	#0x3aa4
0x003954:	ldr     	r1, [pc, #0x148]
0x003956:	add     	r1, sb
0x003958:	ldr     	r0, [r1]
0x00395a:	cmp     	r0, #2
0x00395c:	beq     	#0x39d0
0x00395e:	cmp     	r0, #3
0x003960:	bne     	#0x3a1e
0x003962:	ldr     	r2, [sp, #0x14]
0x003964:	adds    	r0, r2, r4
0x003966:	str     	r0, [sp, #0xc]
0x003968:	b       	#0x396c
0x00396a:	b       	#0x3a9a
0x00396c:	ldr     	r2, [r1, #0x5c]
0x00396e:	cmp     	r0, r2
0x003970:	blt     	#0x3a1e
0x003972:	ldr     	r0, [sp, #0xc]
0x003974:	ldr     	r1, [r1, #0x60]
0x003976:	cmp     	r0, r1
0x003978:	bge     	#0x3a1e
0x00397a:	movs    	r1, #0x32
0x00397c:	movs    	r2, #0
0x00397e:	str     	r2, [sp, #8]
0x003980:	subs    	r3, r7, r1
0x003982:	adds    	r2, r6, #0
0x003984:	str     	r1, [sp, #4]
0x003986:	subs    	r2, #0x19
0x003988:	str     	r1, [sp]
0x00398a:	movs    	r1, #0x2f
0x00398c:	movs    	r0, #0xf1
0x00398e:	lsls    	r0, r0, #9
0x003990:	str     	r2, [sp, #0x24]
0x003992:	str     	r3, [sp, #0x28]
0x003994:	bl      	#0x7e90
0x003998:	cmp     	r0, #1
0x00399a:	bne     	#0x3a1e
0x00399c:	ldr     	r1, [pc, #0x100]

; ===== candidate_003aa4 =====
0x003aa4:	push    	{r4, r5, r6, r7, lr}
0x003aa6:	sub     	sp, #0x4c
0x003aa8:	ldr     	r5, [sp, #0x60]
0x003aaa:	adds    	r4, r0, #0
0x003aac:	ldr     	r0, [r0, #8]
0x003aae:	lsls    	r6, r1, #2
0x003ab0:	ldr     	r3, [r0, r6]
0x003ab2:	cmp     	r3, #0
0x003ab4:	beq     	#0x3b9a
0x003ab6:	movs    	r1, #0
0x003ab8:	str     	r1, [sp]
0x003aba:	str     	r1, [sp, #4]
0x003abc:	movs    	r2, #0
0x003abe:	str     	r2, [sp, #8]
0x003ac0:	ldr     	r2, [r3, #0x70]
0x003ac2:	movs    	r3, #1
0x003ac4:	movs    	r1, #0x70
0x003ac6:	movs    	r0, #0xf1
0x003ac8:	lsls    	r0, r0, #9
0x003aca:	bl      	#0x7e90
0x003ace:	adds    	r7, r0, #0
0x003ad0:	movs    	r0, #0
0x003ad2:	add     	r2, sp, #0x3c
0x003ad4:	add     	r1, sp, #0x40
0x003ad6:	str     	r1, [sp, #4]
0x003ad8:	str     	r2, [sp, #8]
0x003ada:	str     	r0, [sp]
0x003adc:	ldr     	r0, [r4, #8]
0x003ade:	movs    	r1, #0x2a
0x003ae0:	ldr     	r0, [r0, r6]
0x003ae2:	movs    	r3, #0
0x003ae4:	ldr     	r2, [r0]
0x003ae6:	movs    	r0, #0xf1
0x003ae8:	lsls    	r0, r0, #9
0x003aea:	bl      	#0x7e90
0x003aee:	ldr     	r0, [r4, #8]
0x003af0:	movs    	r3, #0x4c
0x003af2:	ldr     	r0, [r0, r6]
0x003af4:	ldrsb   	r1, [r0, r3]
0x003af6:	movs    	r0, #0xa
0x003af8:	cmp     	r1, #0
0x003afa:	ldr     	r1, [r4, #0x30]
0x003afc:	ble     	#0x3be2
0x003afe:	adds    	r3, r1, #1
0x003b00:	bne     	#0x3ba2
0x003b02:	str     	r0, [sp, #0x28]
0x003b04:	movs    	r1, #0
0x003b06:	str     	r7, [sp, #0x24]
0x003b08:	movs    	r3, #2
0x003b0a:	movs    	r2, #0
0x003b0c:	str     	r2, [sp, #8]
0x003b0e:	str     	r3, [sp, #0x30]
0x003b10:	str     	r1, [sp, #4]
0x003b12:	str     	r1, [sp]
0x003b14:	movs    	r1, #0xe1
0x003b16:	movs    	r3, #0
0x003b18:	movs    	r2, #0x27
0x003b1a:	movs    	r0, #0xf1
0x003b1c:	lsls    	r0, r0, #9
0x003b1e:	str     	r5, [sp, #0x2c]
0x003b20:	bl      	#0x7e90
0x003b24:	str     	r0, [sp, #0x20]
0x003b26:	movs    	r1, #0
0x003b28:	movs    	r2, #0
0x003b2a:	str     	r2, [sp, #8]
0x003b2c:	str     	r1, [sp]
0x003b2e:	str     	r1, [sp, #4]
0x003b30:	movs    	r1, #0x38
0x003b32:	adds    	r2, r7, #0
0x003b34:	movs    	r0, #0xf1
0x003b36:	movs    	r3, #2
0x003b38:	lsls    	r0, r0, #9
0x003b3a:	bl      	#0x7e90
0x003b3e:	ldr     	r1, [sp, #0x20]
0x003b40:	blx     	#0x20
0x003b44:	str     	r1, [sp, #0x34]
0x003b46:	movs    	r1, #0
0x003b48:	movs    	r2, #0
0x003b4a:	str     	r1, [sp]
0x003b4c:	str     	r1, [sp, #4]
0x003b4e:	movs    	r3, #0
0x003b50:	movs    	r1, #0x39
0x003b52:	str     	r2, [sp, #8]
0x003b54:	movs    	r0, #0xf1
0x003b56:	lsls    	r0, r0, #9
0x003b58:	add     	r2, sp, #0x24
0x003b5a:	str     	r3, [sp, #0x38]
0x003b5c:	bl      	#0x7e90
0x003b60:	ldr     	r0, [r4, #8]
0x003b62:	movs    	r3, #2
0x003b64:	ldr     	r0, [r0, r6]
0x003b66:	add     	r7, sp, #0x14
0x003b68:	ldr     	r0, [r0]
0x003b6a:	str     	r3, [sp, #0x18]
0x003b6c:	str     	r0, [sp, #0x14]
0x003b6e:	movs    	r0, #0xff
0x003b70:	movs    	r3, #0
0x003b72:	str     	r0, [sp, #0x28]
0x003b74:	str     	r0, [sp, #0x2c]
0x003b76:	str     	r0, [sp, #0x30]
0x003b78:	movs    	r0, #1
0x003b7a:	str     	r3, [sp, #0x20]
0x003b7c:	str     	r3, [sp, #0x24]
0x003b7e:	str     	r5, [sp, #0x1c]
0x003b80:	movs    	r1, #0x20
0x003b82:	strb    	r0, [r1, r7]
0x003b84:	movs    	r1, #0
0x003b86:	movs    	r2, #0
0x003b88:	str     	r2, [sp, #8]
0x003b8a:	str     	r1, [sp]
0x003b8c:	str     	r1, [sp, #4]
0x003b8e:	movs    	r1, #0x25
0x003b90:	adds    	r2, r7, #0
0x003b92:	movs    	r0, #0xf1
0x003b94:	lsls    	r0, r0, #9
0x003b96:	str     	r3, [sp, #0x38]
0x003b98:	b       	#0x3b9c
0x003b9a:	b       	#0x3eee
0x003b9c:	bl      	#0x7e90
0x003ba0:	b       	#0x3e38
0x003ba2:	movs    	r1, #0
0x003ba4:	str     	r7, [sp, #0x24]
0x003ba6:	str     	r1, [sp, #4]
0x003ba8:	str     	r1, [sp]
0x003baa:	movs    	r2, #0
0x003bac:	movs    	r1, #0x1c
0x003bae:	movs    	r3, #0
0x003bb0:	movs    	r0, #0xf1
0x003bb2:	lsls    	r0, r0, #9
0x003bb4:	str     	r2, [sp, #8]
0x003bb6:	bl      	#0x7e90
0x003bba:	subs    	r0, #0xa
0x003bbc:	str     	r0, [sp, #0x28]
0x003bbe:	movs    	r1, #0
0x003bc0:	movs    	r3, #2
0x003bc2:	movs    	r2, #0
0x003bc4:	str     	r2, [sp, #8]
0x003bc6:	str     	r3, [sp, #0x30]
0x003bc8:	str     	r1, [sp]
0x003bca:	str     	r1, [sp, #4]
0x003bcc:	movs    	r1, #0xe1

; ===== candidate_004010 =====
0x004010:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x004012:	sub     	sp, #0x44
0x004014:	ldr     	r5, [sp, #0x68]
0x004016:	adds    	r7, r0, #0
0x004018:	ldr     	r0, [r0]
0x00401a:	lsls    	r1, r1, #2
0x00401c:	str     	r1, [sp, #0x40]
0x00401e:	ldr     	r4, [r0, r1]
0x004020:	movs    	r1, #0
0x004022:	movs    	r2, #0
0x004024:	str     	r2, [sp, #8]
0x004026:	str     	r1, [sp]
0x004028:	str     	r1, [sp, #4]
0x00402a:	ldr     	r0, [r4, #0x7c]
0x00402c:	movs    	r1, #0x6e
0x00402e:	ldr     	r2, [r0, #0x1c]
0x004030:	movs    	r0, #0xf1
0x004032:	movs    	r3, #0
0x004034:	lsls    	r0, r0, #9
0x004036:	bl      	#0x7e90
0x00403a:	str     	r0, [sp, #0x3c]
0x00403c:	movs    	r0, #0
0x00403e:	movs    	r1, #0
0x004040:	str     	r1, [sp, #0x30]
0x004042:	str     	r0, [sp, #0x38]
0x004044:	str     	r0, [sp, #0x34]
0x004046:	ldr     	r0, [r7, #0x24]
0x004048:	ldr     	r1, [sp, #0x40]
0x00404a:	ldr     	r6, [r0, r1]
0x00404c:	cmp     	r6, #0
0x00404e:	beq     	#0x4124
0x004050:	ldr     	r1, [pc, #0x26c]
0x004052:	movs    	r3, #1
0x004054:	ldrsb   	r0, [r6, r3]
0x004056:	add     	r1, sb
0x004058:	ldr     	r1, [r1, #0x30]
0x00405a:	cmp     	r0, r1
0x00405c:	bne     	#0x4124
0x00405e:	movs    	r0, #1
0x004060:	str     	r0, [sp, #0x38]
0x004062:	adds    	r0, r6, #0
0x004064:	bl      	#0x651c
0x004068:	movs    	r2, #0
0x00406a:	movs    	r1, #0
0x00406c:	str     	r2, [sp, #8]
0x00406e:	adds    	r2, r0, #0
0x004070:	str     	r1, [sp]
0x004072:	str     	r1, [sp, #4]
0x004074:	movs    	r1, #0x38
0x004076:	movs    	r0, #0xf1
0x004078:	movs    	r3, #0
0x00407a:	lsls    	r0, r0, #9
0x00407c:	bl      	#0x7e90
0x004080:	movs    	r3, #0
0x004082:	ldrsb   	r1, [r6, r3]
0x004084:	lsls    	r0, r0, #1
0x004086:	subs    	r0, r0, r1
0x004088:	lsrs    	r1, r0, #0x1f
0x00408a:	adds    	r0, r1, r0
0x00408c:	ldrb    	r1, [r6, #9]
0x00408e:	asrs    	r0, r0, #1
0x004090:	cmp     	r1, #0xff
0x004092:	beq     	#0x4124
0x004094:	movs    	r3, #9
0x004096:	ldrsb   	r1, [r6, r3]
0x004098:	cmp     	r1, r0
0x00409a:	bgt     	#0x4124
0x00409c:	movs    	r1, #0
0x00409e:	movs    	r2, #0
0x0040a0:	str     	r2, [sp, #8]
0x0040a2:	str     	r1, [sp]
0x0040a4:	str     	r1, [sp, #4]
0x0040a6:	movs    	r6, #0xf1
0x0040a8:	lsls    	r6, r6, #9
0x0040aa:	movs    	r1, #3
0x0040ac:	movs    	r2, #2
0x0040ae:	movs    	r3, #0
0x0040b0:	adds    	r0, r6, #0
0x0040b2:	bl      	#0x7e90
0x0040b6:	cmp     	r0, #0
0x0040b8:	bne     	#0x40be
0x0040ba:	movs    	r0, #1
0x0040bc:	b       	#0x40c2
0x0040be:	movs    	r0, #0
0x0040c0:	mvns    	r0, r0
0x0040c2:	movs    	r1, #0
0x0040c4:	movs    	r2, #0
0x0040c6:	str     	r2, [sp, #8]
0x0040c8:	str     	r1, [sp]
0x0040ca:	str     	r1, [sp, #4]
0x0040cc:	movs    	r1, #3
0x0040ce:	movs    	r2, #3
0x0040d0:	str     	r0, [sp, #0x2c]
0x0040d2:	movs    	r3, #0
0x0040d4:	adds    	r0, r6, #0
0x0040d6:	bl      	#0x7e90
0x0040da:	adds    	r1, r0, #0
0x0040dc:	ldr     	r0, [sp, #0x2c]
0x0040de:	movs    	r2, #0
0x0040e0:	muls    	r0, r1, r0
0x0040e2:	movs    	r1, #0
0x0040e4:	str     	r1, [sp]
0x0040e6:	str     	r1, [sp, #4]
0x0040e8:	str     	r2, [sp, #8]
0x0040ea:	str     	r0, [sp, #0x34]
0x0040ec:	movs    	r0, #0xf1
0x0040ee:	movs    	r2, #2
0x0040f0:	movs    	r1, #3
0x0040f2:	movs    	r3, #0
0x0040f4:	lsls    	r0, r0, #9
0x0040f6:	bl      	#0x7e90
0x0040fa:	cmp     	r0, #0
0x0040fc:	bne     	#0x4102
0x0040fe:	movs    	r1, #1
0x004100:	b       	#0x4106
0x004102:	movs    	r1, #0
0x004104:	mvns    	r1, r1
0x004106:	str     	r1, [sp, #0x2c]
0x004108:	movs    	r1, #0
0x00410a:	movs    	r2, #0
0x00410c:	str     	r2, [sp, #8]
0x00410e:	str     	r1, [sp]
0x004110:	str     	r1, [sp, #4]
0x004112:	movs    	r1, #3
0x004114:	movs    	r2, #3
0x004116:	movs    	r3, #0
0x004118:	adds    	r0, r6, #0
0x00411a:	bl      	#0x7e90
0x00411e:	ldr     	r1, [sp, #0x2c]
0x004120:	muls    	r1, r0, r1
0x004122:	str     	r1, [sp, #0x30]
0x004124:	ldr     	r0, [pc, #0x198]
0x004126:	add     	r0, sb
0x004128:	ldr     	r0, [r0]
0x00412a:	cmp     	r0, #4
0x00412c:	beq     	#0x4136
0x00412e:	cmp     	r0, #5
0x004130:	beq     	#0x4136
0x004132:	movs    	r0, #1
0x004134:	b       	#0x4138
0x004136:	movs    	r0, #0

; ===== candidate_0042c4 =====
0x0042c4:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0042c6:	sub     	sp, #0x1c
0x0042c8:	adds    	r4, r0, #0
0x0042ca:	ldr     	r0, [sp, #0x40]
0x0042cc:	movs    	r2, #0
0x0042ce:	adds    	r5, r0, #0
0x0042d0:	str     	r2, [sp, #0x14]
0x0042d2:	ldr     	r0, [r4, #4]
0x0042d4:	lsls    	r1, r1, #2
0x0042d6:	str     	r1, [sp, #0x18]
0x0042d8:	ldr     	r7, [r0, r1]
0x0042da:	movs    	r1, #0
0x0042dc:	str     	r1, [sp]
0x0042de:	str     	r1, [sp, #4]
0x0042e0:	str     	r2, [sp, #8]
0x0042e2:	subs    	r5, #0x3c
0x0042e4:	adds    	r2, r7, #0
0x0042e6:	movs    	r1, #0x26
0x0042e8:	movs    	r0, #0xf1
0x0042ea:	movs    	r3, #0
0x0042ec:	lsls    	r0, r0, #9
0x0042ee:	bl      	#0x7e90
0x0042f2:	adds    	r6, r0, #0
0x0042f4:	ldr     	r0, [r4]
0x0042f6:	ldr     	r1, [sp, #0x18]
0x0042f8:	cmp     	r6, #1
0x0042fa:	ldr     	r1, [r0, r1]
0x0042fc:	str     	r1, [sp, #0x10]
0x0042fe:	ble     	#0x437a
0x004300:	ldr     	r0, [sp, #0x24]
0x004302:	movs    	r4, #0
0x004304:	adds    	r3, r0, #1
0x004306:	beq     	#0x4322
0x004308:	movs    	r1, #0
0x00430a:	str     	r1, [sp]
0x00430c:	str     	r1, [sp, #4]
0x00430e:	movs    	r2, #0
0x004310:	movs    	r1, #0x1c
0x004312:	movs    	r3, #0
0x004314:	movs    	r0, #0xf1
0x004316:	lsls    	r0, r0, #9
0x004318:	str     	r2, [sp, #8]
0x00431a:	bl      	#0x7e90
0x00431e:	subs    	r0, #0x10
0x004320:	str     	r0, [sp, #0x14]
0x004322:	movs    	r1, #0
0x004324:	movs    	r2, #0
0x004326:	str     	r2, [sp, #8]
0x004328:	str     	r1, [sp]
0x00432a:	str     	r1, [sp, #4]
0x00432c:	adds    	r3, r4, #0
0x00432e:	adds    	r2, r7, #0
0x004330:	movs    	r1, #0x27
0x004332:	movs    	r0, #0xf1
0x004334:	lsls    	r0, r0, #9
0x004336:	bl      	#0x7e90
0x00433a:	mov     	ip, r0
0x00433c:	ldr     	r0, [r0]
0x00433e:	ldr     	r1, [sp, #0x10]
0x004340:	ldr     	r1, [r1]
0x004342:	cmp     	r0, r1
0x004344:	beq     	#0x4374
0x004346:	mov     	r0, ip
0x004348:	adds    	r0, #0x30
0x00434a:	ldrb    	r0, [r0, #3]
0x00434c:	cmp     	r0, #1
0x00434e:	bne     	#0x4374
0x004350:	ldr     	r0, [sp, #0x14]
0x004352:	movs    	r2, #0
0x004354:	str     	r0, [sp]
0x004356:	mov     	r0, ip
0x004358:	str     	r2, [sp, #8]
0x00435a:	str     	r5, [sp, #4]
0x00435c:	movs    	r3, #0xc
0x00435e:	ldrsh   	r0, [r0, r3]
0x004360:	movs    	r3, #0xf
0x004362:	mov     	r1, ip
0x004364:	ldrsb   	r2, [r1, r3]
0x004366:	adds    	r3, r0, #0
0x004368:	movs    	r0, #0xf1
0x00436a:	movs    	r1, #0xa5
0x00436c:	lsls    	r0, r0, #9
0x00436e:	bl      	#0x7e90
0x004372:	adds    	r5, #0x12
0x004374:	adds    	r4, #1
0x004376:	cmp     	r4, r6
0x004378:	blt     	#0x4322
0x00437a:	add     	sp, #0x2c
0x00437c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_004380 =====
0x004380:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x004382:	sub     	sp, #0xc
0x004384:	movs    	r2, #0
0x004386:	movs    	r1, #0
0x004388:	str     	r2, [sp, #8]
0x00438a:	adds    	r7, r0, #0
0x00438c:	adds    	r2, r0, #0
0x00438e:	str     	r1, [sp]
0x004390:	str     	r1, [sp, #4]
0x004392:	movs    	r1, #0x11
0x004394:	movs    	r0, #0xf1
0x004396:	movs    	r3, #4
0x004398:	lsls    	r0, r0, #9
0x00439a:	ldr     	r5, [sp, #0x30]
0x00439c:	bl      	#0x7e90
0x0043a0:	adds    	r6, r0, #0
0x0043a2:	movs    	r4, #0
0x0043a4:	cmp     	r0, #5
0x0043a6:	ble     	#0x43f0
0x0043a8:	cmp     	r5, #9
0x0043aa:	bge     	#0x43ec
0x0043ac:	adds    	r0, r7, #0
0x0043ae:	bl      	#0x61f0
0x0043b2:	adds    	r4, r0, #0
0x0043b4:	adds    	r0, r5, #0
0x0043b6:	cmp     	r5, #6
0x0043b8:	ble     	#0x43c8
0x0043ba:	movs    	r0, #5
0x0043bc:	cmp     	r5, #7
0x0043be:	beq     	#0x43c8
0x0043c0:	movs    	r0, #4
0x0043c2:	cmp     	r5, #8
0x0043c4:	beq     	#0x43c8
0x0043c6:	movs    	r0, #3
0x0043c8:	lsls    	r3, r0, #2
0x0043ca:	adds    	r0, r3, r0
0x0043cc:	ldr     	r1, [sp, #0x18]
0x0043ce:	lsls    	r0, r0, #1
0x0043d0:	subs    	r6, r1, r0
0x0043d2:	ldr     	r1, [sp, #0x10]
0x0043d4:	ldr     	r0, [sp, #0x14]
0x0043d6:	adds    	r2, r5, #0
0x0043d8:	bl      	#0x4610
0x0043dc:	movs    	r2, #0
0x0043de:	str     	r2, [sp]
0x0043e0:	adds    	r2, r6, #0
0x0043e2:	adds    	r1, r0, #0
0x0043e4:	adds    	r3, r5, #0
0x0043e6:	adds    	r0, r4, #0
0x0043e8:	bl      	#0x447c
0x0043ec:	add     	sp, #0x1c
0x0043ee:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00447c =====
0x00447c:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00447e:	movs    	r6, #0xf1
0x004480:	lsls    	r6, r6, #9
0x004482:	adds    	r5, r0, #0
0x004484:	movs    	r4, #0
0x004486:	cmp     	r0, #0
0x004488:	sub     	sp, #0x3c
0x00448a:	bne     	#0x44aa
0x00448c:	movs    	r2, #0
0x00448e:	movs    	r1, #0
0x004490:	ldr     	r3, [pc, #0x174]
0x004492:	str     	r1, [sp]
0x004494:	str     	r1, [sp, #4]
0x004496:	str     	r2, [sp, #8]
0x004498:	add     	r3, pc
0x00449a:	adds    	r2, r3, #0
0x00449c:	subs    	r2, #8
0x00449e:	movs    	r1, #0x35
0x0044a0:	adds    	r0, r6, #0
0x0044a2:	bl      	#0x7e90
0x0044a6:	adds    	r7, r0, #0
0x0044a8:	b       	#0x44c2
0x0044aa:	movs    	r1, #0
0x0044ac:	movs    	r2, #0
0x0044ae:	str     	r2, [sp, #8]
0x0044b0:	str     	r1, [sp]
0x0044b2:	str     	r1, [sp, #4]
0x0044b4:	movs    	r1, #0x3f
0x0044b6:	adds    	r2, r5, #0
0x0044b8:	movs    	r3, #0
0x0044ba:	adds    	r0, r6, #0
0x0044bc:	bl      	#0x7e90
0x0044c0:	adds    	r7, r0, #0
0x0044c2:	ldr     	r0, [sp, #0x40]
0x0044c4:	add     	r2, sp, #0x2c
0x0044c6:	str     	r0, [sp, #0x34]
0x0044c8:	movs    	r0, #0
0x0044ca:	add     	r1, sp, #0x30
0x0044cc:	str     	r1, [sp, #4]
0x0044ce:	str     	r0, [sp]
0x0044d0:	str     	r2, [sp, #8]
0x0044d2:	adds    	r2, r7, #0
0x0044d4:	movs    	r0, #0xf1
0x0044d6:	movs    	r1, #0x2a
0x0044d8:	movs    	r3, #0
0x0044da:	lsls    	r0, r0, #9
0x0044dc:	bl      	#0x7e90
0x0044e0:	ldr     	r0, [sp, #0x34]
0x0044e2:	ldr     	r1, [sp, #0x30]
0x0044e4:	movs    	r2, #0
0x0044e6:	adds    	r6, r0, r1
0x0044e8:	movs    	r1, #0
0x0044ea:	str     	r1, [sp]
0x0044ec:	str     	r1, [sp, #4]
0x0044ee:	movs    	r1, #0x1c
0x0044f0:	movs    	r0, #0xf1
0x0044f2:	movs    	r3, #0
0x0044f4:	lsls    	r0, r0, #9
0x0044f6:	str     	r2, [sp, #8]
0x0044f8:	bl      	#0x7e90
0x0044fc:	ldr     	r1, [sp, #0x48]
0x0044fe:	lsls    	r3, r1, #2
0x004500:	adds    	r1, r3, r1
0x004502:	subs    	r1, #0x1e
0x004504:	str     	r1, [sp, #0x38]
0x004506:	cmp     	r0, r6
0x004508:	bge     	#0x4536
0x00450a:	movs    	r1, #0
0x00450c:	str     	r1, [sp]
0x00450e:	str     	r1, [sp, #4]
0x004510:	movs    	r2, #0
0x004512:	movs    	r1, #0x1c
0x004514:	movs    	r3, #0
0x004516:	movs    	r0, #0xf1
0x004518:	lsls    	r0, r0, #9
0x00451a:	str     	r2, [sp, #8]
0x00451c:	bl      	#0x7e90
0x004520:	ldr     	r1, [sp, #0x30]
0x004522:	subs    	r0, r6, r0
0x004524:	subs    	r1, r6, r1
0x004526:	subs    	r0, r1, r0
0x004528:	ldr     	r1, [sp, #0x48]
0x00452a:	ldr     	r4, [sp, #0x38]
0x00452c:	lsls    	r3, r1, #1
0x00452e:	adds    	r1, r3, r1
0x004530:	subs    	r1, #0xf
0x004532:	subs    	r0, r0, r1
0x004534:	b       	#0x4544
0x004536:	ldr     	r0, [sp, #0x30]
0x004538:	subs    	r0, r6, r0
0x00453a:	bpl     	#0x4544
0x00453c:	ldr     	r1, [sp, #0x48]
0x00453e:	ldr     	r4, [sp, #0x38]
0x004540:	lsls    	r0, r1, #1
0x004542:	subs    	r0, #0xa
0x004544:	ldr     	r1, [pc, #0xc4]
0x004546:	cmp     	r5, #0
0x004548:	add     	r1, sb
0x00454a:	bne     	#0x458a
0x00454c:	ldr     	r1, [r1, #0x4c]
0x00454e:	subs    	r0, #4
0x004550:	str     	r0, [sp, #0x10]
0x004552:	ldr     	r0, [sp, #0x44]
0x004554:	movs    	r3, #8
0x004556:	adds    	r0, r0, r4
0x004558:	movs    	r4, #0
0x00455a:	str     	r4, [sp, #0x18]
0x00455c:	str     	r4, [sp, #0x1c]
0x00455e:	str     	r0, [sp, #0x14]
0x004560:	str     	r1, [sp, #0xc]
0x004562:	ldrsh   	r0, [r1, r3]
0x004564:	movs    	r3, #0xa
0x004566:	movs    	r2, #0
0x004568:	str     	r0, [sp, #0x20]
0x00456a:	ldrsh   	r0, [r1, r3]
0x00456c:	movs    	r1, #0
0x00456e:	str     	r1, [sp]
0x004570:	str     	r0, [sp, #0x24]
0x004572:	movs    	r0, #6
0x004574:	str     	r0, [sp, #0x28]
0x004576:	str     	r1, [sp, #4]
0x004578:	movs    	r1, #0x63
0x00457a:	str     	r2, [sp, #8]
0x00457c:	movs    	r0, #0xf1
0x00457e:	adds    	r3, r4, #0
0x004580:	lsls    	r0, r0, #9
0x004582:	add     	r2, sp, #0xc
0x004584:	bl      	#0x7e90
0x004588:	b       	#0x45ec
0x00458a:	ldr     	r3, [sp, #0x60]
0x00458c:	movs    	r2, #0xc
0x00458e:	cmp     	r3, #1
0x004590:	bne     	#0x45c0
0x004592:	str     	r0, [sp, #0x18]
0x004594:	ldr     	r0, [sp, #0x44]
0x004596:	str     	r5, [sp, #0x14]
0x004598:	adds    	r0, r0, r4
0x00459a:	str     	r0, [sp, #0x1c]
0x00459c:	ldr     	r0, [r1, #0x40]
0x00459e:	str     	r2, [sp, #0x24]
0x0045a0:	str     	r0, [sp, #0x20]

; ===== candidate_004610 =====
0x004610:	push    	{r4, r5, r6, r7, lr}
0x004612:	adds    	r4, r0, #0
0x004614:	ldr     	r0, [pc, #0xb0]
0x004616:	adds    	r7, r1, #0
0x004618:	adds    	r6, r2, #0
0x00461a:	movs    	r5, #1
0x00461c:	add     	r0, pc
0x00461e:	mov     	ip, r0
0x004620:	cmp     	r1, #0
0x004622:	sub     	sp, #0x1c
0x004624:	bne     	#0x462a
0x004626:	mvns    	r5, r1
0x004628:	b       	#0x462c
0x00462a:	subs    	r4, #0xf
0x00462c:	add     	r1, sp, #0x14
0x00462e:	movs    	r0, #0
0x004630:	str     	r0, [sp]
0x004632:	str     	r1, [sp, #4]
0x004634:	add     	r2, sp, #0x10
0x004636:	str     	r2, [sp, #8]
0x004638:	movs    	r1, #0x2a
0x00463a:	movs    	r0, #0xf1
0x00463c:	movs    	r3, #0
0x00463e:	lsls    	r0, r0, #9
0x004640:	mov     	r2, ip
0x004642:	bl      	#0x7e90
0x004646:	ldr     	r0, [sp, #0x14]
0x004648:	subs    	r2, r6, #4
0x00464a:	lsrs    	r1, r0, #0x1f
0x00464c:	adds    	r0, r1, r0
0x00464e:	adds    	r1, r5, #0
0x004650:	muls    	r1, r2, r1
0x004652:	asrs    	r0, r0, #1
0x004654:	lsls    	r3, r1, #2
0x004656:	adds    	r1, r3, r1
0x004658:	str     	r1, [sp, #0x18]
0x00465a:	subs    	r0, r4, r0
0x00465c:	adds    	r1, r0, r1
0x00465e:	str     	r1, [sp, #0xc]
0x004660:	movs    	r1, #0
0x004662:	str     	r1, [sp]
0x004664:	str     	r1, [sp, #4]
0x004666:	movs    	r2, #0
0x004668:	movs    	r1, #0x1c
0x00466a:	movs    	r0, #0xf1
0x00466c:	movs    	r3, #0
0x00466e:	lsls    	r0, r0, #9
0x004670:	str     	r2, [sp, #8]
0x004672:	bl      	#0x7e90
0x004676:	ldr     	r1, [sp, #0xc]
0x004678:	cmp     	r1, r0
0x00467a:	ble     	#0x4698
0x00467c:	movs    	r1, #0
0x00467e:	str     	r1, [sp]
0x004680:	str     	r1, [sp, #4]
0x004682:	movs    	r2, #0
0x004684:	movs    	r1, #0x1c
0x004686:	movs    	r3, #0
0x004688:	movs    	r0, #0xf1
0x00468a:	lsls    	r0, r0, #9
0x00468c:	str     	r2, [sp, #8]
0x00468e:	bl      	#0x7e90
0x004692:	ldr     	r1, [sp, #0x14]
0x004694:	subs    	r0, r0, r1
0x004696:	b       	#0x46bc
0x004698:	ldr     	r0, [sp, #0x14]
0x00469a:	ldr     	r2, [sp, #0x18]
0x00469c:	lsrs    	r1, r0, #0x1f
0x00469e:	adds    	r1, r1, r0
0x0046a0:	asrs    	r1, r1, #1
0x0046a2:	subs    	r1, r4, r1
0x0046a4:	adds    	r2, r1, r2
0x0046a6:	cmp     	r2, #0
0x0046a8:	bgt     	#0x46b2
0x0046aa:	lsls    	r1, r6, #1
0x0046ac:	adds    	r0, r1, r0
0x0046ae:	subs    	r0, #0xa
0x0046b0:	b       	#0x46bc
0x0046b2:	subs    	r6, #5
0x0046b4:	muls    	r5, r6, r5
0x0046b6:	lsls    	r0, r5, #4
0x0046b8:	subs    	r0, r0, r5
0x0046ba:	adds    	r0, r1, r0
0x0046bc:	cmp     	r7, #1
0x0046be:	bne     	#0x46c2
0x0046c0:	adds    	r0, #0x23
0x0046c2:	add     	sp, #0x1c
0x0046c4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0046cc =====
0x0046cc:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0046ce:	adds    	r5, r0, #0
0x0046d0:	adds    	r4, r3, #0
0x0046d2:	movs    	r3, #0xc
0x0046d4:	ldrsh   	r6, [r0, r3]
0x0046d6:	sub     	sp, #0x14
0x0046d8:	movs    	r1, #0
0x0046da:	movs    	r2, #0
0x0046dc:	str     	r2, [sp, #8]
0x0046de:	str     	r1, [sp]
0x0046e0:	str     	r1, [sp, #4]
0x0046e2:	movs    	r1, #0xe1
0x0046e4:	movs    	r2, #0x49
0x0046e6:	movs    	r0, #0xf1
0x0046e8:	movs    	r3, #0
0x0046ea:	lsls    	r0, r0, #9
0x0046ec:	ldr     	r7, [sp, #0x38]
0x0046ee:	bl      	#0x7e90
0x0046f2:	lsls    	r1, r6, #2
0x0046f4:	ldr     	r0, [r0, r1]
0x0046f6:	movs    	r3, #0x14
0x0046f8:	ldrsb   	r0, [r0, r3]
0x0046fa:	movs    	r1, #0x60
0x0046fc:	adds    	r6, r5, #0
0x0046fe:	str     	r0, [sp, #0x10]
0x004700:	movs    	r0, #1
0x004702:	strb    	r0, [r1, r5]
0x004704:	ldrb    	r0, [r5, #0x14]
0x004706:	adds    	r6, #0x50
0x004708:	cmp     	r0, #0
0x00470a:	beq     	#0x4712
0x00470c:	ldrb    	r0, [r5, #0x16]
0x00470e:	cmp     	r0, #0
0x004710:	bne     	#0x4756
0x004712:	ldrb    	r0, [r6, #8]
0x004714:	cmp     	r0, #0
0x004716:	bne     	#0x471c
0x004718:	movs    	r0, #1
0x00471a:	strb    	r0, [r6, #8]
0x00471c:	movs    	r1, #0
0x00471e:	movs    	r2, #0
0x004720:	str     	r2, [sp, #8]
0x004722:	str     	r1, [sp]
0x004724:	str     	r1, [sp, #4]
0x004726:	movs    	r1, #3
0x004728:	movs    	r2, #2
0x00472a:	movs    	r3, #0
0x00472c:	movs    	r0, #0xf1
0x00472e:	lsls    	r0, r0, #9
0x004730:	bl      	#0x7e90
0x004734:	ldrb    	r1, [r6, #8]
0x004736:	adds    	r0, #1
0x004738:	muls    	r0, r1, r0
0x00473a:	ldrb    	r1, [r6, #9]
0x00473c:	adds    	r0, r0, r1
0x00473e:	lsls    	r0, r0, #0x18
0x004740:	asrs    	r0, r0, #0x18
0x004742:	strb    	r0, [r6, #9]
0x004744:	cmp     	r0, #6
0x004746:	ble     	#0x474e
0x004748:	movs    	r0, #0xff
0x00474a:	strb    	r0, [r6, #8]
0x00474c:	b       	#0x4756
0x00474e:	adds    	r3, r0, #6
0x004750:	bge     	#0x4756
0x004752:	movs    	r0, #1
0x004754:	strb    	r0, [r6, #8]
0x004756:	movs    	r3, #0x28
0x004758:	ldrsh   	r0, [r5, r3]
0x00475a:	cmp     	r0, #0xa
0x00475c:	bhs     	#0x4790
0x00475e:	adr     	r3, #8
0x004760:	ldrb    	r3, [r3, r0]
0x004762:	lsls    	r3, r3, #1
0x004764:	add     	pc, r3
0x004766:	movs    	r0, r0
0x004768:	adds    	r4, #0x16
0x00476a:	ldr     	r6, [pc, #0x108]
0x00476c:	asrs    	r2, r5, #0x10
0x00476e:	cmp     	r2, #5
0x004770:	asrs    	r4, r2, #0x10
0x004772:	ldr     	r0, [sp, #0x10]
0x004774:	cmp     	r0, #1
0x004776:	bne     	#0x477a
0x004778:	subs    	r4, #5
0x00477a:	lsls    	r1, r7, #0x18
0x00477c:	asrs    	r1, r1, #0x18
0x00477e:	ldr     	r2, [sp, #0x3c]
0x004780:	str     	r1, [sp]
0x004782:	adds    	r3, r4, #0
0x004784:	str     	r2, [sp, #4]
0x004786:	ldr     	r2, [sp, #0x1c]
0x004788:	adds    	r0, r5, #0
0x00478a:	ldr     	r1, [sp, #0x18]
0x00478c:	bl      	#0x50f8
0x004790:	add     	sp, #0x24
0x004792:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_004814 =====
0x004814:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x004816:	ldr     	r1, [pc, #0x3e8]
0x004818:	adds    	r7, r3, #0
0x00481a:	movs    	r3, #0x11
0x00481c:	add     	r1, sb
0x00481e:	ldrsb   	r1, [r1, r3]
0x004820:	movs    	r5, #0
0x004822:	adds    	r4, r0, #0
0x004824:	adds    	r0, r5, #0
0x004826:	adds    	r6, r2, #0
0x004828:	cmp     	r1, #1
0x00482a:	sub     	sp, #0x4c
0x00482c:	bne     	#0x4870
0x00482e:	movs    	r1, #0
0x004830:	movs    	r2, #0
0x004832:	str     	r2, [sp, #8]
0x004834:	str     	r1, [sp]
0x004836:	str     	r1, [sp, #4]
0x004838:	movs    	r1, #3
0x00483a:	movs    	r2, #2
0x00483c:	adds    	r3, r5, #0
0x00483e:	movs    	r0, #0xf1
0x004840:	lsls    	r0, r0, #9
0x004842:	bl      	#0x7e90
0x004846:	cmp     	r0, #0
0x004848:	bne     	#0x484e
0x00484a:	movs    	r1, #1
0x00484c:	b       	#0x4852
0x00484e:	movs    	r1, #0
0x004850:	mvns    	r1, r1
0x004852:	str     	r1, [sp, #0x3c]
0x004854:	movs    	r1, #0
0x004856:	movs    	r2, #0
0x004858:	str     	r2, [sp, #8]
0x00485a:	str     	r1, [sp]
0x00485c:	str     	r1, [sp, #4]
0x00485e:	movs    	r1, #3
0x004860:	movs    	r2, #3
0x004862:	adds    	r3, r5, #0
0x004864:	movs    	r0, #0xf1
0x004866:	lsls    	r0, r0, #9
0x004868:	bl      	#0x7e90
0x00486c:	ldr     	r1, [sp, #0x3c]
0x00486e:	muls    	r0, r1, r0
0x004870:	ldr     	r1, [pc, #0x38c]
0x004872:	str     	r0, [sp, #0x40]
0x004874:	movs    	r3, #0x11
0x004876:	add     	r1, sb
0x004878:	ldrsb   	r1, [r1, r3]
0x00487a:	movs    	r0, #0
0x00487c:	cmp     	r1, #1
0x00487e:	bne     	#0x48be
0x004880:	movs    	r1, #0
0x004882:	movs    	r2, #0
0x004884:	str     	r2, [sp, #8]
0x004886:	str     	r1, [sp]
0x004888:	str     	r1, [sp, #4]
0x00488a:	movs    	r1, #3
0x00488c:	movs    	r2, #2
0x00488e:	movs    	r3, #0
0x004890:	movs    	r0, #0xf1
0x004892:	lsls    	r0, r0, #9
0x004894:	bl      	#0x7e90
0x004898:	cmp     	r0, #0
0x00489a:	bne     	#0x48a0
0x00489c:	movs    	r5, #1
0x00489e:	b       	#0x48a4
0x0048a0:	movs    	r5, #0
0x0048a2:	mvns    	r5, r5
0x0048a4:	movs    	r1, #0
0x0048a6:	movs    	r2, #0
0x0048a8:	str     	r2, [sp, #8]
0x0048aa:	str     	r1, [sp]
0x0048ac:	str     	r1, [sp, #4]
0x0048ae:	movs    	r1, #3
0x0048b0:	movs    	r2, #3
0x0048b2:	movs    	r3, #0
0x0048b4:	movs    	r0, #0xf1
0x0048b6:	lsls    	r0, r0, #9
0x0048b8:	bl      	#0x7e90
0x0048bc:	muls    	r0, r5, r0
0x0048be:	str     	r0, [sp, #0x3c]
0x0048c0:	ldr     	r0, [pc, #0x33c]
0x0048c2:	movs    	r3, #0x11
0x0048c4:	add     	r0, sb
0x0048c6:	ldrsb   	r0, [r0, r3]
0x0048c8:	cmp     	r0, #1
0x0048ca:	bne     	#0x48fe
0x0048cc:	ldr     	r0, [sp, #0x50]
0x0048ce:	str     	r7, [sp, #0x30]
0x0048d0:	ldr     	r1, [sp, #0x70]
0x0048d2:	str     	r0, [sp, #0x28]
0x0048d4:	str     	r1, [sp, #0x34]
0x0048d6:	movs    	r0, #1
0x0048d8:	str     	r4, [sp, #0x24]
0x0048da:	str     	r6, [sp, #0x2c]
0x0048dc:	add     	r3, sp, #0x20
0x0048de:	strb    	r0, [r3, #0x18]
0x0048e0:	movs    	r1, #0
0x0048e2:	str     	r1, [sp]
0x0048e4:	str     	r1, [sp, #4]
0x0048e6:	movs    	r2, #0
0x0048e8:	movs    	r1, #0xff
0x0048ea:	adds    	r1, #0x21
0x0048ec:	str     	r2, [sp, #8]
0x0048ee:	movs    	r0, #0xf1
0x0048f0:	movs    	r3, #0
0x0048f2:	lsls    	r0, r0, #9
0x0048f4:	add     	r2, sp, #0x24
0x0048f6:	bl      	#0x7e90
0x0048fa:	add     	sp, #0x5c
0x0048fc:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_004f20 =====
0x004f20:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x004f22:	adds    	r4, r0, #0
0x004f24:	adds    	r0, #0x80
0x004f26:	ldr     	r5, [r0, #4]
0x004f28:	sub     	sp, #0x24
0x004f2a:	cmp     	r5, #0
0x004f2c:	beq     	#0x4f52
0x004f2e:	ldr     	r0, [r5]
0x004f30:	cmp     	r0, #0x13
0x004f32:	bne     	#0x4fa0
0x004f34:	adds    	r2, r4, #0
0x004f36:	adds    	r2, #0xd0
0x004f38:	movs    	r3, #1
0x004f3a:	ldrsb   	r0, [r2, r3]
0x004f3c:	cmp     	r0, #0
0x004f3e:	ble     	#0x4f56
0x004f40:	movs    	r2, #0
0x004f42:	ldr     	r1, [sp, #0x48]
0x004f44:	str     	r2, [sp, #4]
0x004f46:	add     	r3, sp, #0x28
0x004f48:	str     	r1, [sp]
0x004f4a:	ldm     	r3, {r1, r2, r3}
0x004f4c:	adds    	r0, r4, #0
0x004f4e:	bl      	#0x52a0
0x004f52:	add     	sp, #0x34
0x004f54:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_005084 =====
0x005084:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x005086:	adds    	r7, r3, #0
0x005088:	movs    	r3, #0x2c
0x00508a:	adds    	r4, r0, #0
0x00508c:	ldrsh   	r0, [r0, r3]
0x00508e:	sub     	sp, #0x24
0x005090:	adds    	r6, r2, #0
0x005092:	cmp     	r0, #4
0x005094:	ldr     	r5, [sp, #0x48]
0x005096:	bge     	#0x50f2
0x005098:	movs    	r3, #0x2e
0x00509a:	movs    	r2, #4
0x00509c:	subs    	r0, r2, r0
0x00509e:	ldrsh   	r1, [r4, r3]
0x0050a0:	blx     	#0x20
0x0050a4:	cmp     	r1, #0
0x0050a6:	beq     	#0x50f2
0x0050a8:	ldr     	r0, [sp, #0x28]
0x0050aa:	str     	r6, [sp, #0x10]
0x0050ac:	str     	r7, [sp, #0x14]
0x0050ae:	adds    	r4, #0x40
0x0050b0:	movs    	r3, #8
0x0050b2:	str     	r0, [sp, #0xc]
0x0050b4:	ldrsh   	r0, [r4, r3]
0x0050b6:	movs    	r3, #0xa
0x0050b8:	movs    	r1, #0
0x0050ba:	str     	r0, [sp, #0x18]
0x0050bc:	ldrsh   	r0, [r4, r3]
0x0050be:	movs    	r4, #0
0x0050c0:	movs    	r2, #0
0x0050c2:	str     	r2, [sp, #8]
0x0050c4:	adds    	r3, r4, #0
0x0050c6:	str     	r1, [sp]
0x0050c8:	str     	r1, [sp, #4]
0x0050ca:	str     	r0, [sp, #0x1c]
0x0050cc:	movs    	r0, #0xf1
0x0050ce:	movs    	r1, #0x72
0x0050d0:	rsbs    	r2, r5, #0
0x0050d2:	lsls    	r0, r0, #9
0x0050d4:	bl      	#0x7e90
0x0050d8:	str     	r0, [sp, #0x20]
0x0050da:	movs    	r1, #0
0x0050dc:	movs    	r2, #0
0x0050de:	str     	r1, [sp]
0x0050e0:	str     	r1, [sp, #4]
0x0050e2:	movs    	r1, #0x39
0x0050e4:	str     	r2, [sp, #8]
0x0050e6:	movs    	r0, #0xf1
0x0050e8:	adds    	r3, r4, #0
0x0050ea:	lsls    	r0, r0, #9
0x0050ec:	add     	r2, sp, #0xc
0x0050ee:	bl      	#0x7e90
0x0050f2:	add     	sp, #0x34
0x0050f4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0050f8 =====
0x0050f8:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0050fa:	adds    	r7, r3, #0
0x0050fc:	sub     	sp, #0x24
0x0050fe:	adds    	r4, r0, #0
0x005100:	adds    	r0, #0x80
0x005102:	ldr     	r5, [sp, #0x48]
0x005104:	ldr     	r6, [r0, #4]
0x005106:	movs    	r1, #0
0x005108:	ldr     	r0, [pc, #0x18c]
0x00510a:	str     	r1, [sp]
0x00510c:	str     	r1, [sp, #4]
0x00510e:	movs    	r2, #0
0x005110:	str     	r2, [sp, #8]
0x005112:	add     	r0, sb
0x005114:	ldr     	r2, [r0, #0x7c]
0x005116:	movs    	r0, #0xf1
0x005118:	movs    	r1, #0x38
0x00511a:	movs    	r3, #0
0x00511c:	lsls    	r0, r0, #9
0x00511e:	bl      	#0x7e90
0x005122:	mov     	ip, r0
0x005124:	ldr     	r0, [r6]
0x005126:	cmp     	r0, #0x13
0x005128:	bne     	#0x5148
0x00512a:	movs    	r0, #0xd1
0x00512c:	ldrsb   	r0, [r0, r4]
0x00512e:	cmp     	r0, #0
0x005130:	ble     	#0x5148
0x005132:	movs    	r2, #0
0x005134:	str     	r2, [sp, #4]
0x005136:	adds    	r3, r7, #0
0x005138:	adds    	r0, r4, #0
0x00513a:	ldr     	r2, [sp, #0x2c]
0x00513c:	str     	r5, [sp]
0x00513e:	ldr     	r1, [sp, #0x28]
0x005140:	bl      	#0x52a0
0x005144:	add     	sp, #0x34
0x005146:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0052a0 =====
0x0052a0:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0052a2:	adds    	r4, r0, #0
0x0052a4:	adds    	r0, #0x30
0x0052a6:	ldrb    	r0, [r0, #3]
0x0052a8:	adds    	r7, r1, #0
0x0052aa:	sub     	sp, #0x3c
0x0052ac:	cmp     	r0, #0
0x0052ae:	beq     	#0x5394
0x0052b0:	adds    	r5, r4, #0
0x0052b2:	adds    	r5, #0x40
0x0052b4:	movs    	r3, #0xa
0x0052b6:	ldrsh   	r0, [r5, r3]
0x0052b8:	movs    	r2, #0
0x0052ba:	movs    	r1, #0
0x0052bc:	str     	r1, [sp, #4]
0x0052be:	str     	r2, [sp, #8]
0x0052c0:	movs    	r3, #8
0x0052c2:	str     	r0, [sp]
0x0052c4:	ldrsh   	r0, [r5, r3]
0x0052c6:	movs    	r1, #0x74
0x0052c8:	adds    	r3, r0, #0
0x0052ca:	movs    	r0, #0xf1
0x0052cc:	adds    	r2, r7, #0
0x0052ce:	lsls    	r0, r0, #9
0x0052d0:	bl      	#0x7e90
0x0052d4:	ldr     	r1, [r0]
0x0052d6:	movs    	r3, #0
0x0052d8:	lsrs    	r2, r1, #0x1f
0x0052da:	adds    	r1, r2, r1
0x0052dc:	ldr     	r2, [sp, #0x44]
0x0052de:	asrs    	r1, r1, #1
0x0052e0:	subs    	r6, r2, r1
0x0052e2:	ldr     	r0, [r0, #4]
0x0052e4:	ldr     	r1, [sp, #0x48]
0x0052e6:	movs    	r2, #0
0x0052e8:	subs    	r5, r1, r0
0x0052ea:	movs    	r1, #0
0x0052ec:	movs    	r0, #2
0x0052ee:	str     	r0, [sp]
0x0052f0:	str     	r1, [sp, #4]
0x0052f2:	subs    	r5, #4
0x0052f4:	str     	r2, [sp, #8]
0x0052f6:	adds    	r2, r4, #0
0x0052f8:	movs    	r1, #0x99
0x0052fa:	movs    	r0, #0xf1
0x0052fc:	lsls    	r0, r0, #9
0x0052fe:	bl      	#0x7e90
0x005302:	str     	r0, [sp, #0x38]
0x005304:	movs    	r0, #1
0x005306:	movs    	r2, #0
0x005308:	movs    	r1, #0
0x00530a:	str     	r1, [sp, #4]
0x00530c:	str     	r2, [sp, #8]
0x00530e:	str     	r0, [sp]
0x005310:	movs    	r0, #0xf1
0x005312:	adds    	r2, r4, #0
0x005314:	movs    	r1, #0x99
0x005316:	movs    	r3, #0
0x005318:	lsls    	r0, r0, #9
0x00531a:	bl      	#0x7e90
0x00531e:	ldr     	r1, [sp, #0x38]
0x005320:	movs    	r3, #0x64
0x005322:	muls    	r1, r3, r1
0x005324:	blx     	#0x20
0x005328:	lsls    	r3, r0, #4
0x00532a:	subs    	r0, r3, r0
0x00532c:	lsls    	r0, r0, #1
0x00532e:	blx     	#0x8fc
0x005332:	ldr     	r0, [sp, #0x44]
0x005334:	str     	r1, [sp, #0x34]
0x005336:	str     	r7, [sp, #0x20]
0x005338:	str     	r0, [sp, #0x24]
0x00533a:	ldr     	r0, [sp, #0x60]
0x00533c:	ldr     	r1, [sp, #0x48]
0x00533e:	str     	r0, [sp, #0x2c]
0x005340:	str     	r1, [sp, #0x28]
0x005342:	movs    	r0, #1
0x005344:	str     	r4, [sp, #0x1c]
0x005346:	add     	r3, sp, #0x20
0x005348:	strb    	r0, [r3, #0x10]
0x00534a:	movs    	r1, #0
0x00534c:	str     	r1, [sp]
0x00534e:	str     	r1, [sp, #4]
0x005350:	movs    	r2, #0
0x005352:	movs    	r1, #0xff
0x005354:	adds    	r1, #0x21
0x005356:	str     	r2, [sp, #8]
0x005358:	movs    	r0, #0xf1
0x00535a:	movs    	r3, #0
0x00535c:	lsls    	r0, r0, #9
0x00535e:	add     	r2, sp, #0x1c
0x005360:	bl      	#0x7e90
0x005364:	ldrb    	r0, [r4, #0x14]
0x005366:	cmp     	r0, #1
0x005368:	bne     	#0x540c
0x00536a:	movs    	r1, #0
0x00536c:	movs    	r2, #0
0x00536e:	str     	r2, [sp, #8]
0x005370:	str     	r1, [sp]
0x005372:	str     	r1, [sp, #4]
0x005374:	movs    	r7, #0
0x005376:	adds    	r3, r7, #0
0x005378:	movs    	r1, #0xe1
0x00537a:	movs    	r2, #0x11
0x00537c:	movs    	r0, #0xf1
0x00537e:	lsls    	r0, r0, #9
0x005380:	bl      	#0x7e90
0x005384:	str     	r0, [sp, #0x10]
0x005386:	movs    	r2, #0
0x005388:	movs    	r1, #0
0x00538a:	ldr     	r0, [sp, #0x44]
0x00538c:	str     	r1, [sp, #4]
0x00538e:	str     	r1, [sp]
0x005390:	str     	r0, [sp, #0x14]
0x005392:	b       	#0x5396
0x005394:	b       	#0x54ce
0x005396:	str     	r2, [sp, #8]
0x005398:	movs    	r2, #0x11
0x00539a:	adds    	r3, r7, #0
0x00539c:	movs    	r1, #0xe1
0x00539e:	movs    	r0, #0xf1
0x0053a0:	lsls    	r0, r0, #9
0x0053a2:	bl      	#0x7e90
0x0053a6:	movs    	r3, #0xa
0x0053a8:	ldrsh   	r0, [r0, r3]
0x0053aa:	ldr     	r1, [sp, #0x48]
0x0053ac:	str     	r7, [sp, #0x20]
0x0053ae:	subs    	r0, r1, r0
0x0053b0:	movs    	r1, #0
0x0053b2:	movs    	r2, #0
0x0053b4:	str     	r2, [sp, #8]
0x0053b6:	str     	r1, [sp]
0x0053b8:	str     	r1, [sp, #4]
0x0053ba:	str     	r0, [sp, #0x18]
0x0053bc:	movs    	r0, #0xf1
0x0053be:	movs    	r1, #0xe1
0x0053c0:	movs    	r2, #0x11
0x0053c2:	adds    	r3, r7, #0
0x0053c4:	lsls    	r0, r0, #9
0x0053c6:	str     	r7, [sp, #0x1c]
0x0053c8:	bl      	#0x7e90

; ===== candidate_0054dc =====
0x0054dc:	push    	{r4, r5, r6, r7, lr}
0x0054de:	sub     	sp, #0x34
0x0054e0:	movs    	r1, #0
0x0054e2:	str     	r1, [sp]
0x0054e4:	str     	r1, [sp, #4]
0x0054e6:	movs    	r1, #0xff
0x0054e8:	movs    	r5, #0xf1
0x0054ea:	movs    	r4, #0
0x0054ec:	movs    	r2, #0
0x0054ee:	adds    	r3, r4, #0
0x0054f0:	lsls    	r5, r5, #9
0x0054f2:	adds    	r1, #0x27
0x0054f4:	movs    	r7, #0x19
0x0054f6:	adds    	r0, r5, #0
0x0054f8:	str     	r2, [sp, #8]
0x0054fa:	bl      	#0x7e90
0x0054fe:	movs    	r1, #0
0x005500:	str     	r1, [sp]
0x005502:	str     	r1, [sp, #4]
0x005504:	movs    	r1, #0xff
0x005506:	movs    	r2, #0
0x005508:	adds    	r1, #0x26
0x00550a:	adds    	r3, r4, #0
0x00550c:	adds    	r0, r5, #0
0x00550e:	str     	r2, [sp, #8]
0x005510:	bl      	#0x7e90
0x005514:	movs    	r1, #0
0x005516:	movs    	r2, #0
0x005518:	str     	r2, [sp, #8]
0x00551a:	str     	r1, [sp]
0x00551c:	str     	r1, [sp, #4]
0x00551e:	movs    	r1, #0xe1
0x005520:	movs    	r2, #0xed
0x005522:	adds    	r3, r4, #0
0x005524:	adds    	r0, r5, #0
0x005526:	bl      	#0x7e90
0x00552a:	cmp     	r0, #0
0x00552c:	ble     	#0x5612
0x00552e:	movs    	r1, #0
0x005530:	str     	r1, [sp]
0x005532:	str     	r1, [sp, #4]
0x005534:	movs    	r1, #0xff
0x005536:	movs    	r2, #0
0x005538:	adds    	r1, #0x25
0x00553a:	adds    	r3, r4, #0
0x00553c:	adds    	r0, r5, #0
0x00553e:	str     	r2, [sp, #8]
0x005540:	bl      	#0x7e90
0x005544:	movs    	r2, #0
0x005546:	movs    	r1, #0
0x005548:	movs    	r0, #0
0x00554a:	bl      	#0x7e40
0x00554e:	movs    	r1, #0
0x005550:	str     	r1, [sp]
0x005552:	str     	r1, [sp, #4]
0x005554:	movs    	r2, #0
0x005556:	movs    	r1, #0x1c
0x005558:	adds    	r3, r4, #0
0x00555a:	adds    	r0, r5, #0
0x00555c:	str     	r2, [sp, #8]
0x00555e:	bl      	#0x7e90
0x005562:	movs    	r2, #0
0x005564:	str     	r0, [sp]
0x005566:	adds    	r3, r4, #0
0x005568:	movs    	r1, #0x32
0x00556a:	adds    	r0, r5, #0
0x00556c:	str     	r2, [sp, #8]
0x00556e:	str     	r7, [sp, #4]
0x005570:	bl      	#0x7e90
0x005574:	ldr     	r6, [pc, #0x1f0]
0x005576:	add     	r6, pc
0x005578:	add     	r2, sp, #0x2c
0x00557a:	add     	r1, sp, #0x30
0x00557c:	str     	r1, [sp, #4]
0x00557e:	str     	r2, [sp, #8]
0x005580:	movs    	r0, #0
0x005582:	str     	r0, [sp]
0x005584:	adds    	r2, r6, #0
0x005586:	movs    	r1, #0x2a
0x005588:	adds    	r3, r4, #0
0x00558a:	adds    	r0, r5, #0
0x00558c:	bl      	#0x7e90
0x005590:	movs    	r1, #0
0x005592:	str     	r1, [sp]
0x005594:	str     	r1, [sp, #4]
0x005596:	movs    	r2, #0
0x005598:	movs    	r1, #0x1c
0x00559a:	adds    	r3, r4, #0
0x00559c:	adds    	r0, r5, #0
0x00559e:	str     	r2, [sp, #8]
0x0055a0:	str     	r6, [sp, #0xc]
0x0055a2:	bl      	#0x7e90
0x0055a6:	ldr     	r1, [sp, #0x30]
0x0055a8:	str     	r4, [sp, #0x24]
0x0055aa:	adds    	r1, #0x14
0x0055ac:	subs    	r0, r0, r1
0x0055ae:	str     	r0, [sp, #0x10]
0x0055b0:	ldr     	r0, [sp, #0x2c]
0x0055b2:	movs    	r1, #0
0x0055b4:	subs    	r0, r7, r0
0x0055b6:	asrs    	r0, r0, #1
0x0055b8:	str     	r0, [sp, #0x14]
0x0055ba:	movs    	r0, #0xff
0x0055bc:	str     	r0, [sp, #0x20]
0x0055be:	movs    	r2, #0
0x0055c0:	str     	r1, [sp]
0x0055c2:	str     	r1, [sp, #4]
0x0055c4:	str     	r4, [sp, #0x28]
0x0055c6:	str     	r2, [sp, #8]
0x0055c8:	movs    	r1, #0x56
0x0055ca:	str     	r0, [sp, #0x18]
0x0055cc:	str     	r0, [sp, #0x1c]
0x0055ce:	adds    	r3, r4, #0
0x0055d0:	adds    	r0, r5, #0
0x0055d2:	add     	r2, sp, #0xc
0x0055d4:	bl      	#0x7e90
0x0055d8:	movs    	r1, #0
0x0055da:	movs    	r2, #0
0x0055dc:	str     	r2, [sp, #8]
0x0055de:	str     	r1, [sp]
0x0055e0:	str     	r1, [sp, #4]
0x0055e2:	movs    	r1, #0xe1
0x0055e4:	movs    	r2, #0x53
0x0055e6:	adds    	r3, r4, #0
0x0055e8:	adds    	r0, r5, #0
0x0055ea:	bl      	#0x7e90
0x0055ee:	ldr     	r6, [pc, #0x17c]
0x0055f0:	cmp     	r0, #0
0x0055f2:	add     	r6, sb
0x0055f4:	bne     	#0x562a
0x0055f6:	movs    	r1, #0
0x0055f8:	str     	r1, [sp]
0x0055fa:	str     	r1, [sp, #4]
0x0055fc:	movs    	r2, #0
0x0055fe:	movs    	r1, #0x34
0x005600:	adds    	r3, r4, #0
0x005602:	adds    	r0, r5, #0
0x005604:	str     	r2, [sp, #8]
0x005606:	bl      	#0x7e90
0x00560a:	movs    	r2, #0
0x00560c:	movs    	r1, #0

; ===== candidate_005770 =====
0x005770:	push    	{r4, r5, r6, r7, lr}
0x005772:	adds    	r6, r0, #0
0x005774:	ldr     	r0, [pc, #0xa0]
0x005776:	sub     	sp, #0x24
0x005778:	add     	r0, sb
0x00577a:	ldr     	r0, [r0, #8]
0x00577c:	adds    	r5, r1, #0
0x00577e:	str     	r1, [sp, #0x10]
0x005780:	adds    	r7, r2, #0
0x005782:	str     	r0, [sp, #0xc]
0x005784:	movs    	r0, #0x10
0x005786:	movs    	r1, #0
0x005788:	str     	r2, [sp, #0x14]
0x00578a:	movs    	r2, #0
0x00578c:	str     	r2, [sp, #8]
0x00578e:	str     	r1, [sp]
0x005790:	str     	r1, [sp, #4]
0x005792:	str     	r0, [sp, #0x18]
0x005794:	str     	r0, [sp, #0x1c]
0x005796:	movs    	r4, #0
0x005798:	adds    	r3, r4, #0
0x00579a:	movs    	r0, #0xf1
0x00579c:	movs    	r1, #0xe1
0x00579e:	movs    	r2, #0x46
0x0057a0:	lsls    	r0, r0, #9
0x0057a2:	bl      	#0x7e90
0x0057a6:	ldr     	r1, [r6]
0x0057a8:	movs    	r2, #0
0x0057aa:	lsls    	r1, r1, #2
0x0057ac:	ldr     	r0, [r0, r1]
0x0057ae:	movs    	r1, #0
0x0057b0:	ldr     	r0, [r0, #4]
0x0057b2:	str     	r1, [sp, #4]
0x0057b4:	str     	r0, [sp, #0x20]
0x0057b6:	str     	r1, [sp]
0x0057b8:	movs    	r1, #0x22
0x0057ba:	movs    	r0, #0xf1
0x0057bc:	str     	r2, [sp, #8]
0x0057be:	adds    	r3, r4, #0
0x0057c0:	lsls    	r0, r0, #9
0x0057c2:	add     	r2, sp, #0xc
0x0057c4:	bl      	#0x7e90
0x0057c8:	movs    	r1, #0
0x0057ca:	movs    	r2, #0
0x0057cc:	str     	r2, [sp, #8]
0x0057ce:	str     	r1, [sp]
0x0057d0:	str     	r1, [sp, #4]
0x0057d2:	movs    	r1, #0xe1
0x0057d4:	movs    	r2, #0x47
0x0057d6:	adds    	r3, r4, #0
0x0057d8:	movs    	r0, #0xf1
0x0057da:	lsls    	r0, r0, #9
0x0057dc:	bl      	#0x7e90
0x0057e0:	str     	r0, [sp, #0x14]
0x0057e2:	ldr     	r0, [r6, #4]
0x0057e4:	add     	r3, sp, #0
0x0057e6:	strh    	r0, [r3, #0x18]
0x0057e8:	adds    	r0, r7, #0
0x0057ea:	adds    	r0, #8
0x0057ec:	strh    	r5, [r3, #0x1a]
0x0057ee:	strh    	r0, [r3, #0x1c]
0x0057f0:	movs    	r0, #6
0x0057f2:	strh    	r0, [r3, #0x1e]
0x0057f4:	movs    	r0, #8
0x0057f6:	strh    	r0, [r3, #0x20]
0x0057f8:	strh    	r4, [r3, #0x22]
0x0057fa:	movs    	r1, #0
0x0057fc:	movs    	r2, #0
0x0057fe:	str     	r1, [sp]
0x005800:	str     	r1, [sp, #4]
0x005802:	movs    	r1, #0x71
0x005804:	str     	r2, [sp, #8]
0x005806:	adds    	r3, r4, #0
0x005808:	movs    	r0, #0xf1
0x00580a:	lsls    	r0, r0, #9
0x00580c:	add     	r2, sp, #0x14
0x00580e:	bl      	#0x7e90
0x005812:	add     	sp, #0x24
0x005814:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00581c =====
0x00581c:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00581e:	sub     	sp, #0x24
0x005820:	adds    	r6, r0, #0
0x005822:	adds    	r5, r3, #0
0x005824:	ldr     	r7, [sp, #0x48]
0x005826:	bl      	#0x651c
0x00582a:	adds    	r4, r0, #0
0x00582c:	beq     	#0x588e
0x00582e:	movs    	r1, #0
0x005830:	movs    	r2, #0
0x005832:	str     	r2, [sp, #8]
0x005834:	str     	r1, [sp]
0x005836:	str     	r1, [sp, #4]
0x005838:	movs    	r1, #0x38
0x00583a:	adds    	r2, r4, #0
0x00583c:	movs    	r3, #0
0x00583e:	movs    	r0, #0xf1
0x005840:	lsls    	r0, r0, #9
0x005842:	bl      	#0x7e90
0x005846:	movs    	r3, #0
0x005848:	ldrsb   	r1, [r6, r3]
0x00584a:	subs    	r1, r0, r1
0x00584c:	movs    	r0, #0
0x00584e:	cmp     	r5, r7
0x005850:	bne     	#0x585a
0x005852:	adds    	r3, r5, #1
0x005854:	beq     	#0x5860
0x005856:	movs    	r0, #1
0x005858:	b       	#0x5860
0x00585a:	adds    	r3, r5, #1
0x00585c:	beq     	#0x5860
0x00585e:	movs    	r0, #1
0x005860:	ldr     	r2, [pc, #0x30]
0x005862:	movs    	r3, #0
0x005864:	add     	r2, sb
0x005866:	str     	r6, [r2, #0x10]
0x005868:	ldr     	r2, [sp, #0x28]
0x00586a:	str     	r4, [sp, #0xc]
0x00586c:	str     	r2, [sp, #0x10]
0x00586e:	ldr     	r2, [sp, #0x2c]
0x005870:	str     	r1, [sp, #0x1c]
0x005872:	movs    	r1, #0
0x005874:	str     	r0, [sp, #0x20]
0x005876:	str     	r2, [sp, #0x14]
0x005878:	movs    	r2, #0
0x00587a:	str     	r1, [sp]
0x00587c:	str     	r1, [sp, #4]
0x00587e:	movs    	r1, #0x39
0x005880:	str     	r2, [sp, #8]
0x005882:	movs    	r0, #0xf1
0x005884:	lsls    	r0, r0, #9
0x005886:	add     	r2, sp, #0xc
0x005888:	str     	r3, [sp, #0x18]
0x00588a:	bl      	#0x7e90
0x00588e:	add     	sp, #0x34
0x005890:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_005898 =====
0x005898:	push    	{r4, r5, r6, r7, lr}
0x00589a:	ldr     	r7, [pc, #0x8c]
0x00589c:	movs    	r3, #2
0x00589e:	add     	r7, sb
0x0058a0:	ldrsb   	r0, [r7, r3]
0x0058a2:	sub     	sp, #0xc
0x0058a4:	cmp     	r0, #1
0x0058a6:	bne     	#0x5922
0x0058a8:	ldr     	r5, [pc, #0x7c]
0x0058aa:	add     	r5, sb
0x0058ac:	adds    	r5, #0x80
0x0058ae:	ldr     	r0, [r5, #0xc]
0x0058b0:	cmp     	r0, #0
0x0058b2:	beq     	#0x5922
0x0058b4:	movs    	r1, #0
0x0058b6:	movs    	r2, #0
0x0058b8:	str     	r2, [sp, #8]
0x0058ba:	str     	r1, [sp]
0x0058bc:	str     	r1, [sp, #4]
0x0058be:	movs    	r4, #0
0x0058c0:	movs    	r6, #0xf1
0x0058c2:	lsls    	r6, r6, #9
0x0058c4:	adds    	r3, r4, #0
0x0058c6:	movs    	r1, #0x14
0x0058c8:	movs    	r2, #0x4c
0x0058ca:	adds    	r0, r6, #0
0x0058cc:	bl      	#0x7e90
0x0058d0:	movs    	r1, #0
0x0058d2:	movs    	r2, #0
0x0058d4:	str     	r2, [sp, #8]
0x0058d6:	str     	r1, [sp]
0x0058d8:	str     	r1, [sp, #4]
0x0058da:	movs    	r1, #0x14
0x0058dc:	movs    	r2, #0x4d
0x0058de:	adds    	r3, r4, #0
0x0058e0:	adds    	r0, r6, #0
0x0058e2:	bl      	#0x7e90
0x0058e6:	strb    	r4, [r7, #2]
0x0058e8:	ldr     	r7, [r5, #0xc]
0x0058ea:	cmp     	r7, #0
0x0058ec:	beq     	#0x5904
0x0058ee:	movs    	r1, #0
0x0058f0:	movs    	r2, #0
0x0058f2:	str     	r2, [sp, #8]
0x0058f4:	str     	r1, [sp]
0x0058f6:	str     	r1, [sp, #4]
0x0058f8:	movs    	r1, #0x12
0x0058fa:	adds    	r2, r7, #0
0x0058fc:	adds    	r3, r4, #0
0x0058fe:	adds    	r0, r6, #0
0x005900:	bl      	#0x7e90
0x005904:	movs    	r0, #4
0x005906:	str     	r0, [r5]
0x005908:	str     	r4, [r5, #0xc]
0x00590a:	movs    	r1, #0
0x00590c:	str     	r1, [sp]
0x00590e:	str     	r1, [sp, #4]
0x005910:	movs    	r1, #0xff
0x005912:	movs    	r2, #0
0x005914:	adds    	r1, #0x23
0x005916:	adds    	r3, r4, #0
0x005918:	adds    	r0, r6, #0
0x00591a:	str     	r2, [sp, #8]
0x00591c:	bl      	#0x7e90
0x005920:	str     	r4, [r5]
0x005922:	add     	sp, #0xc
0x005924:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00592c =====
0x00592c:	push    	{r4, r5, r6, r7, lr}
0x00592e:	sub     	sp, #0xc
0x005930:	movs    	r1, #0
0x005932:	movs    	r2, #0
0x005934:	str     	r2, [sp, #8]
0x005936:	str     	r1, [sp]
0x005938:	str     	r1, [sp, #4]
0x00593a:	movs    	r6, #0xf1
0x00593c:	movs    	r4, #0
0x00593e:	adds    	r3, r4, #0
0x005940:	lsls    	r6, r6, #9
0x005942:	movs    	r1, #0xe1
0x005944:	movs    	r2, #0x5e
0x005946:	adds    	r0, r6, #0
0x005948:	bl      	#0x7e90
0x00594c:	cmp     	r0, #0
0x00594e:	beq     	#0x5a36
0x005950:	movs    	r1, #0
0x005952:	str     	r1, [sp]
0x005954:	str     	r1, [sp, #4]
0x005956:	movs    	r1, #0xff
0x005958:	movs    	r2, #0
0x00595a:	adds    	r1, #0x4c
0x00595c:	adds    	r3, r4, #0
0x00595e:	adds    	r0, r6, #0
0x005960:	str     	r2, [sp, #8]
0x005962:	bl      	#0x7e90
0x005966:	movs    	r2, #0
0x005968:	movs    	r1, #0
0x00596a:	str     	r2, [sp, #8]
0x00596c:	movs    	r2, #0xff
0x00596e:	str     	r1, [sp]
0x005970:	str     	r1, [sp, #4]
0x005972:	movs    	r1, #0x14
0x005974:	adds    	r2, #0x15
0x005976:	adds    	r3, r4, #0
0x005978:	adds    	r0, r6, #0
0x00597a:	bl      	#0x7e90
0x00597e:	ldr     	r7, [pc, #0x3e0]
0x005980:	add     	r7, sb
0x005982:	strb    	r4, [r7, #0xb]
0x005984:	ldr     	r5, [r7, #0x2c]
0x005986:	cmp     	r5, #0
0x005988:	beq     	#0x59a0
0x00598a:	movs    	r1, #0
0x00598c:	movs    	r2, #0
0x00598e:	str     	r2, [sp, #8]
0x005990:	str     	r1, [sp]
0x005992:	str     	r1, [sp, #4]
0x005994:	movs    	r1, #9
0x005996:	adds    	r2, r5, #0
0x005998:	adds    	r3, r4, #0
0x00599a:	adds    	r0, r6, #0
0x00599c:	bl      	#0x7e90
0x0059a0:	str     	r4, [r7, #0x2c]
0x0059a2:	movs    	r1, #0
0x0059a4:	movs    	r2, #0
0x0059a6:	str     	r2, [sp, #8]
0x0059a8:	str     	r1, [sp]
0x0059aa:	str     	r1, [sp, #4]
0x0059ac:	movs    	r1, #0x14
0x0059ae:	movs    	r2, #0x5e
0x0059b0:	adds    	r3, r4, #0
0x0059b2:	adds    	r0, r6, #0
0x0059b4:	bl      	#0x7e90
0x0059b8:	movs    	r1, #0
0x0059ba:	movs    	r2, #0
0x0059bc:	str     	r2, [sp, #8]
0x0059be:	str     	r1, [sp]
0x0059c0:	str     	r1, [sp, #4]
0x0059c2:	movs    	r1, #0x14
0x0059c4:	movs    	r2, #0x62
0x0059c6:	adds    	r3, r4, #0
0x0059c8:	movs    	r0, #0xf1
0x0059ca:	lsls    	r0, r0, #9
0x0059cc:	bl      	#0x7e90
0x0059d0:	movs    	r1, #0
0x0059d2:	movs    	r2, #0
0x0059d4:	str     	r2, [sp, #8]
0x0059d6:	str     	r1, [sp]
0x0059d8:	str     	r1, [sp, #4]
0x0059da:	movs    	r1, #0x14
0x0059dc:	movs    	r2, #0x4e
0x0059de:	adds    	r3, r4, #0
0x0059e0:	movs    	r0, #0xf1
0x0059e2:	lsls    	r0, r0, #9
0x0059e4:	bl      	#0x7e90
0x0059e8:	ldr     	r5, [r7, #0x28]
0x0059ea:	cmp     	r5, #0
0x0059ec:	beq     	#0x5a04
0x0059ee:	movs    	r1, #0
0x0059f0:	movs    	r2, #0
0x0059f2:	str     	r2, [sp, #8]
0x0059f4:	str     	r1, [sp]
0x0059f6:	str     	r1, [sp, #4]
0x0059f8:	movs    	r1, #9
0x0059fa:	adds    	r2, r5, #0
0x0059fc:	adds    	r3, r4, #0
0x0059fe:	adds    	r0, r6, #0
0x005a00:	bl      	#0x7e90
0x005a04:	ldr     	r7, [pc, #0x358]
0x005a06:	movs    	r1, #0
0x005a08:	add     	r7, sb
0x005a0a:	str     	r4, [r7, #0x28]
0x005a0c:	movs    	r2, #0
0x005a0e:	str     	r2, [sp, #8]
0x005a10:	str     	r1, [sp]
0x005a12:	str     	r1, [sp, #4]
0x005a14:	movs    	r1, #0x14
0x005a16:	movs    	r2, #0x63
0x005a18:	adds    	r3, r4, #0
0x005a1a:	adds    	r0, r6, #0
0x005a1c:	bl      	#0x7e90
0x005a20:	movs    	r1, #0
0x005a22:	movs    	r2, #0
0x005a24:	str     	r2, [sp, #8]
0x005a26:	str     	r1, [sp]
0x005a28:	str     	r1, [sp, #4]
0x005a2a:	movs    	r1, #0xe1
0x005a2c:	movs    	r2, #0x64
0x005a2e:	adds    	r3, r4, #0
0x005a30:	movs    	r0, #0xf1
0x005a32:	lsls    	r0, r0, #9
0x005a34:	b       	#0x5a38
0x005a36:	b       	#0x5e4c
0x005a38:	bl      	#0x7e90
0x005a3c:	cmp     	r0, #0
0x005a3e:	beq     	#0x5a86
0x005a40:	movs    	r1, #0
0x005a42:	movs    	r2, #0
0x005a44:	str     	r2, [sp, #8]
0x005a46:	str     	r1, [sp]
0x005a48:	str     	r1, [sp, #4]
0x005a4a:	movs    	r1, #0xe1
0x005a4c:	movs    	r2, #0x64
0x005a4e:	adds    	r3, r4, #0
0x005a50:	adds    	r0, r6, #0
0x005a52:	bl      	#0x7e90
0x005a56:	movs    	r2, #0
0x005a58:	movs    	r1, #0
0x005a5a:	str     	r2, [sp, #8]

; ===== candidate_005f6c =====
0x005f6c:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x005f6e:	adds    	r4, r1, #0
0x005f70:	sub     	sp, #0xc
0x005f72:	adds    	r5, r2, #0
0x005f74:	movs    	r1, #0
0x005f76:	movs    	r2, #0
0x005f78:	str     	r2, [sp, #8]
0x005f7a:	str     	r1, [sp]
0x005f7c:	str     	r1, [sp, #4]
0x005f7e:	adds    	r6, r3, #0
0x005f80:	movs    	r3, #0
0x005f82:	movs    	r1, #0xe1
0x005f84:	movs    	r2, #0xbf
0x005f86:	movs    	r0, #0xf1
0x005f88:	lsls    	r0, r0, #9
0x005f8a:	bl      	#0x7e90
0x005f8e:	movs    	r7, #1
0x005f90:	cmp     	r0, #0
0x005f92:	bne     	#0x5fac
0x005f94:	movs    	r1, #0
0x005f96:	movs    	r2, #0
0x005f98:	str     	r2, [sp, #8]
0x005f9a:	str     	r1, [sp]
0x005f9c:	str     	r1, [sp, #4]
0x005f9e:	movs    	r1, #0x14
0x005fa0:	movs    	r2, #0xbf
0x005fa2:	adds    	r3, r7, #0
0x005fa4:	movs    	r0, #0xf1
0x005fa6:	lsls    	r0, r0, #9
0x005fa8:	bl      	#0x7e90
0x005fac:	ldr     	r0, [sp, #0xc]
0x005fae:	cmp     	r0, #0x1f
0x005fb0:	bhs     	#0x5fbc
0x005fb2:	adr     	r3, #0xc
0x005fb4:	adds    	r3, r3, r0
0x005fb6:	ldrh    	r3, [r3, r0]
0x005fb8:	lsls    	r3, r3, #1
0x005fba:	add     	pc, r3
0x005fbc:	b       	#0x61d4
0x005fbe:	movs    	r0, r0
0x005fc0:	lsls    	r6, r4, #3
0x005fc2:	lsls    	r1, r6, #3
0x005fc4:	lsls    	r4, r7, #3
0x005fc6:	lsls    	r1, r0, #4
0x005fc8:	lsls    	r2, r4, #3
0x005fca:	lsls    	r6, r3, #3
0x005fcc:	lsls    	r1, r3, #3
0x005fce:	lsls    	r4, r2, #3
0x005fd0:	lsls    	r0, r2, #3
0x005fd2:	lsls    	r3, r1, #3
0x005fd4:	lsls    	r6, r7, #2
0x005fd6:	lsls    	r2, r7, #2
0x005fd8:	lsls    	r6, r6, #2
0x005fda:	lsls    	r4, r4, #2
0x005fdc:	lsls    	r5, r3, #2
0x005fde:	lsls    	r5, r2, #2
0x005fe0:	lsls    	r1, r3, #2
0x005fe2:	lsls    	r2, r7, #1
0x005fe4:	lsls    	r5, r6, #1
0x005fe6:	lsls    	r1, r6, #1
0x005fe8:	lsls    	r4, r5, #1
0x005fea:	lsls    	r0, r5, #1
0x005fec:	lsls    	r4, r4, #1
0x005fee:	lsls    	r0, r4, #1
0x005ff0:	lsls    	r3, r3, #1
0x005ff2:	lsls    	r6, r2, #1
0x005ff4:	lsls    	r1, r2, #1
0x005ff6:	lsls    	r5, r1, #1
0x005ff8:	movs    	r7, r6
0x005ffa:	movs    	r5, r4
0x005ffc:	movs    	r0, r4
0x005ffe:	bl      	#0x94ac
0x006002:	movs    	r0, #0
0x006004:	add     	sp, #0x1c
0x006006:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0061f0 =====
0x0061f0:	push    	{r4, lr}
0x0061f2:	sub     	sp, #0x10
0x0061f4:	movs    	r2, #0
0x0061f6:	movs    	r1, #0
0x0061f8:	str     	r2, [sp, #8]
0x0061fa:	adds    	r4, r0, #0
0x0061fc:	adds    	r2, r0, #0
0x0061fe:	str     	r1, [sp]
0x006200:	str     	r1, [sp, #4]
0x006202:	movs    	r1, #0x11
0x006204:	movs    	r0, #0xf1
0x006206:	movs    	r3, #4
0x006208:	lsls    	r0, r0, #9
0x00620a:	bl      	#0x7e90
0x00620e:	movs    	r1, #0
0x006210:	movs    	r2, #0
0x006212:	cmp     	r0, #0
0x006214:	ble     	#0x6224
0x006216:	lsls    	r3, r1, #2
0x006218:	ldr     	r3, [r4, r3]
0x00621a:	adds    	r1, #1
0x00621c:	ldr     	r3, [r3]
0x00621e:	adds    	r2, r3, r2
0x006220:	cmp     	r1, r0
0x006222:	blt     	#0x6216
0x006224:	adds    	r0, r2, #0
0x006226:	add     	sp, #0x10
0x006228:	pop     	{r4, pc}

; ===== candidate_00622c =====
0x00622c:	push    	{r4, r5, lr}
0x00622e:	sub     	sp, #0xc
0x006230:	ldr     	r4, [pc, #0x30]
0x006232:	movs    	r1, #0
0x006234:	movs    	r2, #0
0x006236:	str     	r2, [sp, #8]
0x006238:	str     	r1, [sp]
0x00623a:	str     	r1, [sp, #4]
0x00623c:	adds    	r5, r0, #0
0x00623e:	add     	r4, sb
0x006240:	ldr     	r0, [r4, #0x50]
0x006242:	movs    	r1, #0x11
0x006244:	ldr     	r2, [r0]
0x006246:	movs    	r0, #0xf1
0x006248:	movs    	r3, #4
0x00624a:	lsls    	r0, r0, #9
0x00624c:	bl      	#0x7e90
0x006250:	adds    	r1, r5, #0
0x006252:	blx     	#0x20
0x006256:	cmp     	r0, #0
0x006258:	bne     	#0x6260
0x00625a:	ldr     	r0, [r4, #0x50]
0x00625c:	add     	sp, #0xc
0x00625e:	pop     	{r4, r5, pc}

; ===== candidate_006268 =====
0x006268:	push    	{r4, r5, r6, lr}
0x00626a:	sub     	sp, #0x10
0x00626c:	adds    	r4, r0, #0
0x00626e:	ldr     	r0, [pc, #0x38]
0x006270:	movs    	r1, #0
0x006272:	movs    	r2, #0
0x006274:	str     	r2, [sp, #8]
0x006276:	str     	r1, [sp]
0x006278:	str     	r1, [sp, #4]
0x00627a:	add     	r0, sb
0x00627c:	ldr     	r0, [r0, #0x50]
0x00627e:	movs    	r1, #0x11
0x006280:	ldr     	r2, [r0]
0x006282:	movs    	r0, #0xf1
0x006284:	movs    	r3, #4
0x006286:	lsls    	r0, r0, #9
0x006288:	bl      	#0x7e90
0x00628c:	adds    	r5, r0, #0
0x00628e:	adds    	r0, r4, #0
0x006290:	bl      	#0x622c
0x006294:	adds    	r6, r0, #0
0x006296:	adds    	r1, r4, #0
0x006298:	adds    	r0, r5, #0
0x00629a:	blx     	#0x20
0x00629e:	ldr     	r0, [r6]
0x0062a0:	lsls    	r1, r1, #2
0x0062a2:	ldr     	r0, [r0, r1]
0x0062a4:	add     	sp, #0x10
0x0062a6:	pop     	{r4, r5, r6, pc}

; ===== candidate_00637c =====
0x00637c:	push    	{r4, r5, lr}
0x00637e:	adds    	r5, r0, #0
0x006380:	adds    	r4, r1, #0
0x006382:	sub     	sp, #0xc
0x006384:	movs    	r1, #0
0x006386:	str     	r1, [sp]
0x006388:	str     	r1, [sp, #4]
0x00638a:	movs    	r2, #0
0x00638c:	str     	r2, [sp, #8]
0x00638e:	movs    	r1, #0x11
0x006390:	movs    	r0, #0xf1
0x006392:	movs    	r3, #4
0x006394:	lsls    	r0, r0, #9
0x006396:	ldr     	r2, [r4, #0x54]
0x006398:	bl      	#0x7e90
0x00639c:	movs    	r1, #0
0x00639e:	cmp     	r0, #0
0x0063a0:	ble     	#0x63ba
0x0063a2:	ldr     	r2, [r4, #0x54]
0x0063a4:	lsls    	r3, r1, #2
0x0063a6:	ldr     	r3, [r2, r3]
0x0063a8:	ldr     	r3, [r3]
0x0063aa:	cmp     	r3, r5
0x0063ac:	bne     	#0x63b4
0x0063ae:	adds    	r0, r1, #0
0x0063b0:	add     	sp, #0xc
0x0063b2:	pop     	{r4, r5, pc}

; ===== candidate_0063c0 =====
0x0063c0:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x0063c2:	sub     	sp, #0xc
0x0063c4:	movs    	r1, #0
0x0063c6:	str     	r1, [sp]
0x0063c8:	str     	r1, [sp, #4]
0x0063ca:	adds    	r7, r0, #0
0x0063cc:	movs    	r2, #0
0x0063ce:	movs    	r0, #0xf1
0x0063d0:	movs    	r1, #0x13
0x0063d2:	movs    	r3, #0
0x0063d4:	lsls    	r0, r0, #9
0x0063d6:	str     	r2, [sp, #8]
0x0063d8:	bl      	#0x7e90
0x0063dc:	movs    	r1, #0
0x0063de:	adds    	r5, r0, #0
0x0063e0:	movs    	r2, #0
0x0063e2:	str     	r2, [sp, #8]
0x0063e4:	str     	r1, [sp]
0x0063e6:	str     	r1, [sp, #4]
0x0063e8:	movs    	r1, #0x11
0x0063ea:	adds    	r2, r7, #0
0x0063ec:	movs    	r0, #0xf1
0x0063ee:	movs    	r4, #0
0x0063f0:	movs    	r3, #4
0x0063f2:	lsls    	r0, r0, #9
0x0063f4:	bl      	#0x7e90
0x0063f8:	adds    	r6, r0, #0
0x0063fa:	cmp     	r0, #0
0x0063fc:	ble     	#0x642c
0x0063fe:	lsls    	r0, r4, #2
0x006400:	ldr     	r0, [r7, r0]
0x006402:	movs    	r3, #0xc
0x006404:	mov     	ip, r0
0x006406:	ldrsb   	r0, [r0, r3]
0x006408:	ldr     	r1, [sp, #0x10]
0x00640a:	cmp     	r0, r1
0x00640c:	bne     	#0x6426
0x00640e:	movs    	r1, #0
0x006410:	movs    	r2, #0
0x006412:	str     	r2, [sp, #8]
0x006414:	str     	r1, [sp]
0x006416:	str     	r1, [sp, #4]
0x006418:	movs    	r1, #0x36
0x00641a:	adds    	r2, r5, #0
0x00641c:	movs    	r0, #0xf1
0x00641e:	lsls    	r0, r0, #9
0x006420:	mov     	r3, ip
0x006422:	bl      	#0x7e90
0x006426:	adds    	r4, #1
0x006428:	cmp     	r4, r6
0x00642a:	blt     	#0x63fe
0x00642c:	movs    	r1, #0
0x00642e:	movs    	r2, #0
0x006430:	str     	r2, [sp, #8]
0x006432:	str     	r1, [sp]
0x006434:	str     	r1, [sp, #4]
0x006436:	movs    	r1, #0x26
0x006438:	adds    	r2, r5, #0
0x00643a:	movs    	r3, #0
0x00643c:	movs    	r0, #0xf1
0x00643e:	lsls    	r0, r0, #9
0x006440:	bl      	#0x7e90
0x006444:	movs    	r2, #0
0x006446:	movs    	r1, #0
0x006448:	str     	r2, [sp, #8]
0x00644a:	adds    	r4, r0, #0
0x00644c:	adds    	r2, r0, #0
0x00644e:	str     	r1, [sp]
0x006450:	str     	r1, [sp, #4]
0x006452:	movs    	r1, #0xa
0x006454:	movs    	r0, #0xf1
0x006456:	movs    	r3, #4
0x006458:	lsls    	r0, r0, #9
0x00645a:	bl      	#0x7e90
0x00645e:	adds    	r7, r0, #0
0x006460:	movs    	r6, #0
0x006462:	cmp     	r4, #0
0x006464:	ble     	#0x6488
0x006466:	movs    	r1, #0
0x006468:	movs    	r2, #0
0x00646a:	str     	r2, [sp, #8]
0x00646c:	str     	r1, [sp]
0x00646e:	str     	r1, [sp, #4]
0x006470:	adds    	r3, r6, #0
0x006472:	adds    	r2, r5, #0
0x006474:	movs    	r1, #0x27
0x006476:	movs    	r0, #0xf1
0x006478:	lsls    	r0, r0, #9
0x00647a:	bl      	#0x7e90
0x00647e:	lsls    	r1, r6, #2
0x006480:	adds    	r6, #1
0x006482:	cmp     	r6, r4
0x006484:	str     	r0, [r7, r1]
0x006486:	blt     	#0x6466
0x006488:	movs    	r1, #0
0x00648a:	movs    	r2, #0
0x00648c:	movs    	r4, #0
0x00648e:	adds    	r3, r4, #0
0x006490:	str     	r2, [sp, #8]
0x006492:	str     	r1, [sp]
0x006494:	str     	r1, [sp, #4]
0x006496:	movs    	r1, #0x28
0x006498:	adds    	r2, r5, #0
0x00649a:	movs    	r0, #0xf1
0x00649c:	lsls    	r0, r0, #9
0x00649e:	bl      	#0x7e90
0x0064a2:	movs    	r1, #0
0x0064a4:	movs    	r2, #0
0x0064a6:	str     	r2, [sp, #8]
0x0064a8:	str     	r1, [sp]
0x0064aa:	str     	r1, [sp, #4]
0x0064ac:	adds    	r3, r4, #0
0x0064ae:	adds    	r2, r5, #0
0x0064b0:	movs    	r1, #9
0x0064b2:	movs    	r0, #0xf1
0x0064b4:	lsls    	r0, r0, #9
0x0064b6:	bl      	#0x7e90
0x0064ba:	adds    	r0, r7, #0
0x0064bc:	add     	sp, #0x14
0x0064be:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0064c0 =====
0x0064c0:	push    	{r4, r5, r6, lr}
0x0064c2:	sub     	sp, #0x10
0x0064c4:	movs    	r1, #0
0x0064c6:	movs    	r2, #0
0x0064c8:	str     	r2, [sp, #8]
0x0064ca:	str     	r1, [sp]
0x0064cc:	str     	r1, [sp, #4]
0x0064ce:	movs    	r6, #0xf1
0x0064d0:	movs    	r4, #0
0x0064d2:	adds    	r3, r4, #0
0x0064d4:	lsls    	r6, r6, #9
0x0064d6:	movs    	r1, #3
0x0064d8:	movs    	r2, #3
0x0064da:	adds    	r0, r6, #0
0x0064dc:	bl      	#0x7e90
0x0064e0:	ldr     	r5, [pc, #0x34]
0x0064e2:	lsls    	r2, r0, #2
0x0064e4:	add     	r5, sb
0x0064e6:	ldr     	r1, [r5, #0x54]
0x0064e8:	ldr     	r1, [r1]
0x0064ea:	ldr     	r1, [r1, r2]
0x0064ec:	cmp     	r1, #0
0x0064ee:	bne     	#0x6512
0x0064f0:	movs    	r1, #0
0x0064f2:	movs    	r2, #0
0x0064f4:	str     	r2, [sp, #8]
0x0064f6:	str     	r1, [sp]
0x0064f8:	str     	r1, [sp, #4]
0x0064fa:	movs    	r1, #3
0x0064fc:	movs    	r2, #3
0x0064fe:	adds    	r3, r4, #0
0x006500:	adds    	r0, r6, #0
0x006502:	bl      	#0x7e90
0x006506:	ldr     	r1, [r5, #0x54]
0x006508:	lsls    	r2, r0, #2
0x00650a:	ldr     	r1, [r1]
0x00650c:	ldr     	r1, [r1, r2]
0x00650e:	cmp     	r1, #0
0x006510:	beq     	#0x64f0
0x006512:	add     	sp, #0x10
0x006514:	pop     	{r4, r5, r6, pc}

; ===== candidate_00651c =====
0x00651c:	push    	{r4, r5, r6, lr}
0x00651e:	ldr     	r5, [pc, #0x40]
0x006520:	movs    	r3, #8
0x006522:	ldrsb   	r2, [r0, r3]
0x006524:	add     	r5, sb
0x006526:	ldr     	r0, [r5, #0x3c]
0x006528:	lsls    	r4, r2, #2
0x00652a:	ldr     	r1, [r0, #0x60]
0x00652c:	ldr     	r0, [r0, #0x64]
0x00652e:	ldr     	r6, [r1, r4]
0x006530:	ldr     	r0, [r0, r4]
0x006532:	sub     	sp, #0x10
0x006534:	cmp     	r0, #0
0x006536:	bne     	#0x6556
0x006538:	movs    	r1, #0
0x00653a:	movs    	r2, #0
0x00653c:	str     	r2, [sp, #8]
0x00653e:	str     	r1, [sp]
0x006540:	str     	r1, [sp, #4]
0x006542:	movs    	r1, #0x37
0x006544:	adds    	r2, r6, #0
0x006546:	movs    	r3, #0
0x006548:	movs    	r0, #0xf1
0x00654a:	lsls    	r0, r0, #9
0x00654c:	bl      	#0x7e90
0x006550:	ldr     	r1, [r5, #0x3c]
0x006552:	ldr     	r1, [r1, #0x64]
0x006554:	str     	r0, [r1, r4]
0x006556:	ldr     	r0, [r5, #0x3c]
0x006558:	ldr     	r0, [r0, #0x64]
0x00655a:	ldr     	r0, [r0, r4]
0x00655c:	add     	sp, #0x10
0x00655e:	pop     	{r4, r5, r6, pc}

; ===== candidate_006564 =====
0x006564:	push    	{r4, r5, r6, lr}
0x006566:	sub     	sp, #0x10
0x006568:	movs    	r1, #0
0x00656a:	movs    	r2, #0
0x00656c:	str     	r2, [sp, #8]
0x00656e:	str     	r1, [sp]
0x006570:	str     	r1, [sp, #4]
0x006572:	movs    	r5, #0xf1
0x006574:	movs    	r4, #0
0x006576:	adds    	r3, r4, #0
0x006578:	lsls    	r5, r5, #9
0x00657a:	movs    	r1, #0xe1
0x00657c:	movs    	r2, #0x4c
0x00657e:	adds    	r0, r5, #0
0x006580:	bl      	#0x7e90
0x006584:	movs    	r1, #0
0x006586:	str     	r1, [sp]
0x006588:	str     	r1, [sp, #4]
0x00658a:	movs    	r2, #0
0x00658c:	str     	r2, [sp, #8]
0x00658e:	movs    	r1, #0xff
0x006590:	adds    	r1, #0x2e
0x006592:	adds    	r2, r0, #0
0x006594:	adds    	r3, r4, #0
0x006596:	adds    	r0, r5, #0
0x006598:	bl      	#0x7e90
0x00659c:	lsls    	r6, r0, #0x18
0x00659e:	asrs    	r6, r6, #0x18
0x0065a0:	movs    	r0, #3
0x0065a2:	bl      	#0x7b40
0x0065a6:	cmp     	r0, #0
0x0065a8:	bne     	#0x662c
0x0065aa:	cmp     	r6, #1
0x0065ac:	bne     	#0x662c
0x0065ae:	movs    	r1, #0
0x0065b0:	movs    	r2, #0
0x0065b2:	str     	r2, [sp, #8]
0x0065b4:	str     	r1, [sp]
0x0065b6:	str     	r1, [sp, #4]
0x0065b8:	movs    	r1, #0xe1
0x0065ba:	movs    	r2, #0x4c
0x0065bc:	adds    	r3, r4, #0
0x0065be:	adds    	r0, r5, #0
0x0065c0:	bl      	#0x7e90
0x0065c4:	ldr     	r0, [r0, #0x34]
0x0065c6:	cmp     	r0, #0
0x0065c8:	beq     	#0x660a
0x0065ca:	movs    	r1, #0
0x0065cc:	movs    	r2, #0
0x0065ce:	str     	r2, [sp, #8]
0x0065d0:	str     	r1, [sp]
0x0065d2:	str     	r1, [sp, #4]
0x0065d4:	movs    	r1, #0xe1
0x0065d6:	movs    	r2, #0x4c
0x0065d8:	adds    	r3, r4, #0
0x0065da:	adds    	r0, r5, #0
0x0065dc:	bl      	#0x7e90
0x0065e0:	ldr     	r0, [r0, #0x34]
0x0065e2:	movs    	r1, #0
0x0065e4:	ldr     	r6, [r0, #4]
0x0065e6:	movs    	r2, #0
0x0065e8:	str     	r2, [sp, #8]
0x0065ea:	str     	r1, [sp]
0x0065ec:	str     	r1, [sp, #4]
0x0065ee:	movs    	r1, #0x73
0x0065f0:	adds    	r2, r6, #0
0x0065f2:	adds    	r3, r4, #0
0x0065f4:	adds    	r0, r5, #0
0x0065f6:	bl      	#0x7e90
0x0065fa:	cmp     	r0, #6
0x0065fc:	bne     	#0x660a
0x0065fe:	movs    	r2, #1
0x006600:	movs    	r1, #0
0x006602:	movs    	r0, #3
0x006604:	bl      	#0x6650
0x006608:	b       	#0x6614
0x00660a:	movs    	r2, #1
0x00660c:	movs    	r1, #0
0x00660e:	movs    	r0, #0
0x006610:	bl      	#0x6650
0x006614:	movs    	r1, #0
0x006616:	movs    	r2, #0
0x006618:	str     	r2, [sp, #8]
0x00661a:	str     	r1, [sp]
0x00661c:	str     	r1, [sp, #4]
0x00661e:	movs    	r1, #0x9c
0x006620:	movs    	r2, #0x14
0x006622:	adds    	r3, r4, #0
0x006624:	adds    	r0, r5, #0
0x006626:	bl      	#0x7e90
0x00662a:	b       	#0x6646
0x00662c:	movs    	r1, #0
0x00662e:	str     	r1, [sp]
0x006630:	str     	r1, [sp, #4]
0x006632:	movs    	r2, #0
0x006634:	movs    	r1, #0x34
0x006636:	adds    	r3, r4, #0
0x006638:	adds    	r0, r5, #0
0x00663a:	str     	r2, [sp, #8]
0x00663c:	bl      	#0x7e90
0x006640:	movs    	r0, #1
0x006642:	bl      	#0x9d8c
0x006646:	bl      	#0x5898
0x00664a:	add     	sp, #0x10
0x00664c:	pop     	{r4, r5, r6, pc}

; ===== candidate_006650 =====
0x006650:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x006652:	sub     	sp, #0x10
0x006654:	adds    	r6, r1, #0
0x006656:	movs    	r1, #0
0x006658:	ldr     	r5, [pc, #0x98]
0x00665a:	movs    	r2, #0
0x00665c:	str     	r2, [sp, #8]
0x00665e:	str     	r1, [sp]
0x006660:	str     	r1, [sp, #4]
0x006662:	add     	r5, sb
0x006664:	ldr     	r0, [r5, #0x50]
0x006666:	movs    	r1, #0x11
0x006668:	ldr     	r2, [r0]
0x00666a:	movs    	r0, #0xf1
0x00666c:	movs    	r3, #4
0x00666e:	lsls    	r0, r0, #9
0x006670:	bl      	#0x7e90
0x006674:	movs    	r1, #0
0x006676:	adds    	r4, r0, #0
0x006678:	str     	r1, [sp]
0x00667a:	str     	r1, [sp, #4]
0x00667c:	movs    	r2, #0
0x00667e:	movs    	r7, #0
0x006680:	adds    	r3, r7, #0
0x006682:	movs    	r1, #0x34
0x006684:	movs    	r0, #0xf1
0x006686:	lsls    	r0, r0, #9
0x006688:	str     	r2, [sp, #8]
0x00668a:	bl      	#0x7e90
0x00668e:	movs    	r1, #0
0x006690:	movs    	r2, #0
0x006692:	str     	r2, [sp, #8]
0x006694:	str     	r1, [sp]
0x006696:	str     	r1, [sp, #4]
0x006698:	movs    	r1, #0x14
0x00669a:	movs    	r2, #0x17
0x00669c:	movs    	r3, #0x2e
0x00669e:	movs    	r0, #0xf1
0x0066a0:	lsls    	r0, r0, #9
0x0066a2:	bl      	#0x7e90
0x0066a6:	ldr     	r1, [pc, #0x4c]
0x0066a8:	str     	r4, [r5, #0x2c]
0x0066aa:	add     	r1, sb
0x0066ac:	subs    	r1, #0x80
0x0066ae:	ldr     	r0, [sp, #0x10]
0x0066b0:	cmp     	r6, #1
0x0066b2:	strb    	r0, [r1, #0xc]
0x0066b4:	bne     	#0x66bc
0x0066b6:	str     	r4, [r5, #0x60]
0x0066b8:	str     	r7, [r5, #0x5c]
0x0066ba:	b       	#0x66c6
0x0066bc:	cmp     	r6, #0
0x0066be:	bne     	#0x66c6
0x0066c0:	lsls    	r0, r4, #1
0x0066c2:	str     	r0, [r5, #0x60]
0x0066c4:	str     	r4, [r5, #0x5c]
0x0066c6:	ldr     	r0, [sp, #0x18]
0x0066c8:	cmp     	r0, #0
0x0066ca:	bne     	#0x66d2
0x0066cc:	ldr     	r0, [r5, #0x5c]
0x0066ce:	str     	r0, [r5, #0x2c]
0x0066d0:	b       	#0x66da
0x0066d2:	bl      	#0x64c0
0x0066d6:	adds    	r0, r0, r4
0x0066d8:	str     	r0, [r5, #0x2c]
0x0066da:	ldr     	r1, [pc, #0x18]
0x0066dc:	ldr     	r2, [r5, #0x5c]
0x0066de:	add     	r1, sb
0x0066e0:	adds    	r1, #0x2c
0x0066e2:	movs    	r0, #1
0x0066e4:	ldr     	r3, [r5, #0x60]
0x0066e6:	bl      	#0xc60
0x0066ea:	movs    	r0, #3
0x0066ec:	bl      	#0xa114
0x0066f0:	add     	sp, #0x1c
0x0066f2:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0066f8 =====
0x0066f8:	push    	{r4, r5, r6, r7, lr}
0x0066fa:	adds    	r5, r1, #0
0x0066fc:	sub     	sp, #0xc
0x0066fe:	movs    	r1, #0
0x006700:	movs    	r2, #0
0x006702:	str     	r2, [sp, #8]
0x006704:	str     	r1, [sp]
0x006706:	str     	r1, [sp, #4]
0x006708:	adds    	r4, r0, #0
0x00670a:	ldr     	r0, [r0, #0x7c]
0x00670c:	movs    	r6, #0
0x00670e:	ldr     	r2, [r0, #0x1c]
0x006710:	movs    	r0, #0xf1
0x006712:	adds    	r3, r6, #0
0x006714:	movs    	r1, #0x6e
0x006716:	lsls    	r0, r0, #9
0x006718:	bl      	#0x7e90
0x00671c:	adds    	r7, r0, #0
0x00671e:	adds    	r0, r4, #0
0x006720:	adds    	r0, #0x40
0x006722:	mov     	ip, r0
0x006724:	movs    	r3, #0xa
0x006726:	ldrsh   	r0, [r0, r3]
0x006728:	movs    	r2, #0
0x00672a:	movs    	r1, #0
0x00672c:	str     	r0, [sp]
0x00672e:	mov     	r0, ip
0x006730:	str     	r1, [sp, #4]
0x006732:	str     	r2, [sp, #8]
0x006734:	movs    	r3, #8
0x006736:	ldrsh   	r0, [r0, r3]
0x006738:	movs    	r1, #0x74
0x00673a:	adds    	r3, r0, #0
0x00673c:	movs    	r0, #0xf1
0x00673e:	adds    	r2, r7, #0
0x006740:	lsls    	r0, r0, #9
0x006742:	bl      	#0x7e90
0x006746:	adds    	r2, r0, #0
0x006748:	ldr     	r0, [r5, #4]
0x00674a:	bl      	#0x62ac
0x00674e:	ldr     	r1, [r2]
0x006750:	ldr     	r2, [r5, #8]
0x006752:	ldr     	r0, [r0, #0x14]
0x006754:	adds    	r1, #0x1e
0x006756:	lsls    	r2, r2, #1
0x006758:	strh    	r1, [r0, r2]
0x00675a:	movs    	r1, #0
0x00675c:	movs    	r2, #0
0x00675e:	str     	r2, [sp, #8]
0x006760:	str     	r1, [sp]
0x006762:	str     	r1, [sp, #4]
0x006764:	adds    	r3, r6, #0
0x006766:	adds    	r2, r4, #0
0x006768:	movs    	r1, #0x94
0x00676a:	movs    	r0, #0xf1
0x00676c:	lsls    	r0, r0, #9
0x00676e:	bl      	#0x7e90
0x006772:	movs    	r0, #0x84
0x006774:	str     	r5, [r0, r4]
0x006776:	movs    	r0, #4
0x006778:	strh    	r0, [r4, #0x28]
0x00677a:	add     	sp, #0xc
0x00677c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_006780 =====
0x006780:	push    	{r4, r5, r6, r7, lr}
0x006782:	sub     	sp, #0x14
0x006784:	movs    	r1, #0
0x006786:	str     	r1, [sp]
0x006788:	str     	r1, [sp, #4]
0x00678a:	movs    	r2, #0
0x00678c:	str     	r2, [sp, #8]
0x00678e:	movs    	r1, #0xff
0x006790:	movs    	r7, #0xf1
0x006792:	movs    	r4, #0
0x006794:	adds    	r3, r4, #0
0x006796:	lsls    	r7, r7, #9
0x006798:	adds    	r1, #0x2e
0x00679a:	adds    	r2, r0, #0
0x00679c:	adds    	r6, r0, #0
0x00679e:	movs    	r5, #0
0x0067a0:	adds    	r0, r7, #0
0x0067a2:	bl      	#0x7e90
0x0067a6:	lsls    	r0, r0, #0x18
0x0067a8:	asrs    	r0, r0, #0x18
0x0067aa:	ldr     	r1, [pc, #0x3e4]
0x0067ac:	str     	r0, [sp, #0x10]
0x0067ae:	movs    	r0, #0
0x0067b0:	add     	r1, sb
0x0067b2:	str     	r0, [r1, #0x24]
0x0067b4:	movs    	r1, #0
0x0067b6:	movs    	r2, #0
0x0067b8:	str     	r2, [sp, #8]
0x0067ba:	str     	r1, [sp, #4]
0x0067bc:	movs    	r1, #0x14
0x0067be:	movs    	r2, #0x4c
0x0067c0:	str     	r0, [sp]
0x0067c2:	adds    	r3, r6, #0
0x0067c4:	adds    	r0, r7, #0
0x0067c6:	bl      	#0x7e90
0x0067ca:	movs    	r1, #0
0x0067cc:	str     	r1, [sp]
0x0067ce:	str     	r1, [sp, #4]
0x0067d0:	movs    	r1, #0xff
0x0067d2:	movs    	r2, #0
0x0067d4:	adds    	r1, #0x29
0x0067d6:	movs    	r3, #0
0x0067d8:	adds    	r0, r7, #0
0x0067da:	str     	r2, [sp, #8]
0x0067dc:	bl      	#0x7e90
0x0067e0:	ldr     	r0, [pc, #0x3ac]
0x0067e2:	movs    	r3, #0x12
0x0067e4:	add     	r0, sb
0x0067e6:	ldrsb   	r0, [r0, r3]
0x0067e8:	cmp     	r0, #1
0x0067ea:	beq     	#0x6806
0x0067ec:	movs    	r0, #4
0x0067ee:	bl      	#0x7b40
0x0067f2:	cmp     	r0, #1
0x0067f4:	bne     	#0x6848
0x0067f6:	ldrb    	r0, [r6, #0x16]
0x0067f8:	cmp     	r0, #0
0x0067fa:	beq     	#0x6848
0x0067fc:	movs    	r0, #3
0x0067fe:	bl      	#0x7b40
0x006802:	cmp     	r0, #0
0x006804:	bne     	#0x6848
0x006806:	bl      	#0x6564
0x00680a:	movs    	r0, #4
0x00680c:	bl      	#0x7b40
0x006810:	cmp     	r0, #1
0x006812:	bne     	#0x6844
0x006814:	movs    	r2, #0
0x006816:	movs    	r1, #0
0x006818:	str     	r2, [sp, #8]
0x00681a:	ldr     	r2, [pc, #0x378]
0x00681c:	str     	r1, [sp]
0x00681e:	str     	r1, [sp, #4]
0x006820:	adds    	r3, r4, #0
0x006822:	add     	r2, pc
0x006824:	movs    	r1, #0x33
0x006826:	adds    	r0, r7, #0
0x006828:	bl      	#0x7e90
0x00682c:	movs    	r1, #0
0x00682e:	movs    	r2, #0
0x006830:	str     	r2, [sp, #8]
0x006832:	str     	r1, [sp]
0x006834:	str     	r1, [sp, #4]
0x006836:	movs    	r1, #0x14
0x006838:	movs    	r2, #0x4f
0x00683a:	movs    	r3, #8
0x00683c:	movs    	r0, #0xf1
0x00683e:	lsls    	r0, r0, #9
0x006840:	bl      	#0x7e90
0x006844:	add     	sp, #0x14
0x006846:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_006f2c =====
0x006f2c:	push    	{r4, r5, r6, r7, lr}
0x006f2e:	sub     	sp, #0x24
0x006f30:	movs    	r0, #0
0x006f32:	str     	r0, [sp, #0x20]
0x006f34:	str     	r0, [sp, #0x1c]
0x006f36:	str     	r0, [sp, #0x18]
0x006f38:	str     	r0, [sp, #0x14]
0x006f3a:	str     	r0, [sp, #0x10]
0x006f3c:	str     	r0, [sp, #0xc]
0x006f3e:	add     	r0, sp, #0x14
0x006f40:	add     	r2, sp, #0xc
0x006f42:	add     	r1, sp, #0x10
0x006f44:	str     	r1, [sp, #4]
0x006f46:	str     	r2, [sp, #8]
0x006f48:	str     	r0, [sp]
0x006f4a:	ldr     	r0, [pc, #0x3e4]
0x006f4c:	add     	r2, sp, #0x1c
0x006f4e:	add     	r1, sp, #0x20
0x006f50:	add     	r3, sp, #0x18
0x006f52:	bl      	#0x7e90
0x006f56:	ldr     	r7, [pc, #0x3dc]
0x006f58:	ldr     	r5, [pc, #0x3d8]
0x006f5a:	movs    	r3, #0
0x006f5c:	add     	r7, sb
0x006f5e:	add     	r5, sb
0x006f60:	subs    	r5, #0x80
0x006f62:	str     	r3, [r7, #0x24]
0x006f64:	mvns    	r0, r3
0x006f66:	str     	r0, [r5, #0x30]
0x006f68:	str     	r3, [r5, #0x2c]
0x006f6a:	strb    	r3, [r5]
0x006f6c:	str     	r3, [r5, #0x28]
0x006f6e:	movs    	r1, #0
0x006f70:	movs    	r2, #0
0x006f72:	str     	r2, [sp, #8]
0x006f74:	str     	r1, [sp]
0x006f76:	str     	r1, [sp, #4]
0x006f78:	movs    	r4, #0xf1
0x006f7a:	lsls    	r4, r4, #9
0x006f7c:	movs    	r1, #0xe1
0x006f7e:	movs    	r2, #0x53
0x006f80:	adds    	r0, r4, #0
0x006f82:	bl      	#0x7e90
0x006f86:	cmp     	r0, #0
0x006f88:	beq     	#0x6fce
0x006f8a:	movs    	r1, #0
0x006f8c:	movs    	r2, #0
0x006f8e:	str     	r2, [sp, #8]
0x006f90:	str     	r1, [sp]
0x006f92:	str     	r1, [sp, #4]
0x006f94:	movs    	r6, #0
0x006f96:	adds    	r3, r6, #0
0x006f98:	movs    	r1, #0xe1
0x006f9a:	movs    	r2, #0x53
0x006f9c:	adds    	r0, r4, #0
0x006f9e:	bl      	#0x7e90
0x006fa2:	movs    	r2, #0
0x006fa4:	movs    	r1, #0
0x006fa6:	str     	r2, [sp, #8]
0x006fa8:	adds    	r2, r0, #0
0x006faa:	str     	r1, [sp]
0x006fac:	str     	r1, [sp, #4]
0x006fae:	movs    	r1, #0xa0
0x006fb0:	adds    	r0, r4, #0
0x006fb2:	adds    	r3, r6, #0
0x006fb4:	bl      	#0x7e90
0x006fb8:	movs    	r1, #0
0x006fba:	movs    	r2, #0
0x006fbc:	str     	r2, [sp, #8]
0x006fbe:	str     	r1, [sp]
0x006fc0:	str     	r1, [sp, #4]
0x006fc2:	movs    	r1, #0x14
0x006fc4:	movs    	r2, #0x53
0x006fc6:	adds    	r3, r6, #0
0x006fc8:	adds    	r0, r4, #0
0x006fca:	bl      	#0x7e90
0x006fce:	movs    	r6, #0
0x006fd0:	strb    	r6, [r5, #1]
0x006fd2:	movs    	r1, #0
0x006fd4:	movs    	r2, #0
0x006fd6:	str     	r2, [sp, #8]
0x006fd8:	str     	r1, [sp]
0x006fda:	str     	r1, [sp, #4]
0x006fdc:	movs    	r1, #0x14
0x006fde:	movs    	r2, #0xf1
0x006fe0:	adds    	r3, r6, #0
0x006fe2:	adds    	r0, r4, #0
0x006fe4:	bl      	#0x7e90
0x006fe8:	strb    	r6, [r5, #0xb]
0x006fea:	movs    	r1, #0
0x006fec:	movs    	r2, #0
0x006fee:	str     	r2, [sp, #8]
0x006ff0:	str     	r1, [sp]
0x006ff2:	str     	r1, [sp, #4]
0x006ff4:	movs    	r1, #0x14
0x006ff6:	movs    	r2, #0x5c
0x006ff8:	adds    	r3, r6, #0
0x006ffa:	movs    	r0, #0xf1
0x006ffc:	lsls    	r0, r0, #9
0x006ffe:	bl      	#0x7e90
0x007002:	movs    	r1, #0
0x007004:	movs    	r2, #0
0x007006:	str     	r2, [sp, #8]
0x007008:	str     	r1, [sp]
0x00700a:	str     	r1, [sp, #4]
0x00700c:	movs    	r1, #0xe1
0x00700e:	movs    	r2, #0x5d
0x007010:	adds    	r3, r6, #0
0x007012:	movs    	r0, #0xf1
0x007014:	lsls    	r0, r0, #9
0x007016:	bl      	#0x7e90
0x00701a:	cmp     	r0, #0
0x00701c:	bne     	#0x704a
0x00701e:	movs    	r1, #0
0x007020:	str     	r1, [sp]
0x007022:	str     	r1, [sp, #4]
0x007024:	movs    	r2, #0
0x007026:	movs    	r1, #0x13
0x007028:	adds    	r3, r6, #0
0x00702a:	adds    	r0, r4, #0
0x00702c:	str     	r2, [sp, #8]
0x00702e:	bl      	#0x7e90
0x007032:	movs    	r1, #0
0x007034:	movs    	r2, #0
0x007036:	str     	r2, [sp, #8]
0x007038:	str     	r1, [sp]
0x00703a:	str     	r1, [sp, #4]
0x00703c:	adds    	r3, r0, #0
0x00703e:	movs    	r0, #0xf1
0x007040:	movs    	r1, #0x14
0x007042:	movs    	r2, #0x5d
0x007044:	lsls    	r0, r0, #9
0x007046:	bl      	#0x7e90
0x00704a:	movs    	r1, #0
0x00704c:	movs    	r2, #0
0x00704e:	str     	r2, [sp, #8]
0x007050:	str     	r1, [sp]
0x007052:	str     	r1, [sp, #4]
0x007054:	movs    	r1, #0x14
0x007056:	movs    	r2, #0x5e
0x007058:	movs    	r3, #1

; ===== candidate_0073d2 =====
0x0073d2:	push    	{r4, r5, lr}
0x0073d4:	add     	r0, sb
0x0073d6:	ldr     	r0, [r0, #0x50]
0x0073d8:	sub     	sp, #0xc
0x0073da:	ldr     	r1, [r0, #4]
0x0073dc:	ldr     	r0, [r0, #0x10]
0x0073de:	movs    	r2, #0
0x0073e0:	lsls    	r0, r0, #2
0x0073e2:	ldr     	r5, [r1, r0]
0x0073e4:	str     	r2, [sp, #8]
0x0073e6:	movs    	r1, #0
0x0073e8:	adds    	r2, r5, #0
0x0073ea:	movs    	r5, #0xf1
0x0073ec:	str     	r1, [sp]
0x0073ee:	str     	r1, [sp, #4]
0x0073f0:	movs    	r4, #0
0x0073f2:	adds    	r3, r4, #0
0x0073f4:	movs    	r1, #0x26
0x0073f6:	lsls    	r5, r5, #9
0x0073f8:	adds    	r0, r5, #0
0x0073fa:	bl      	#0x7e90
0x0073fe:	cmp     	r0, #1
0x007400:	bgt     	#0x741e
0x007402:	movs    	r2, #0
0x007404:	movs    	r1, #0
0x007406:	str     	r2, [sp, #8]
0x007408:	ldr     	r2, [pc, #0x4c]
0x00740a:	str     	r1, [sp]
0x00740c:	str     	r1, [sp, #4]
0x00740e:	adds    	r3, r4, #0
0x007410:	add     	r2, pc
0x007412:	movs    	r1, #0x33
0x007414:	adds    	r0, r5, #0
0x007416:	bl      	#0x7e90
0x00741a:	add     	sp, #0xc
0x00741c:	pop     	{r4, r5, pc}

; ===== candidate_00745c =====
0x00745c:	push    	{r4, r5, r6, r7, lr}
0x00745e:	ldr     	r7, [pc, #0x154]
0x007460:	sub     	sp, #0xc
0x007462:	add     	r7, sb
0x007464:	ldr     	r0, [r7, #0x50]
0x007466:	movs    	r5, #0xf1
0x007468:	ldr     	r1, [r0, #4]
0x00746a:	ldr     	r0, [r0, #0x10]
0x00746c:	movs    	r2, #0
0x00746e:	lsls    	r0, r0, #2
0x007470:	ldr     	r6, [r1, r0]
0x007472:	movs    	r1, #0
0x007474:	str     	r1, [sp]
0x007476:	str     	r1, [sp, #4]
0x007478:	movs    	r1, #0x34
0x00747a:	lsls    	r5, r5, #9
0x00747c:	movs    	r3, #0
0x00747e:	adds    	r0, r5, #0
0x007480:	str     	r2, [sp, #8]
0x007482:	bl      	#0x7e90
0x007486:	movs    	r1, #0
0x007488:	movs    	r2, #0
0x00748a:	str     	r2, [sp, #8]
0x00748c:	str     	r1, [sp]
0x00748e:	str     	r1, [sp, #4]
0x007490:	movs    	r1, #0x14
0x007492:	movs    	r2, #0x17
0x007494:	movs    	r3, #0x34
0x007496:	adds    	r0, r5, #0
0x007498:	bl      	#0x7e90
0x00749c:	ldr     	r4, [pc, #0x114]
0x00749e:	movs    	r0, #0
0x0074a0:	add     	r4, sb
0x0074a2:	subs    	r4, #0x80
0x0074a4:	str     	r0, [r4, #0x3c]
0x0074a6:	movs    	r2, #0
0x0074a8:	movs    	r1, #0
0x0074aa:	str     	r1, [sp, #4]
0x0074ac:	str     	r2, [sp, #8]
0x0074ae:	str     	r0, [sp]
0x0074b0:	adds    	r2, r6, #0
0x0074b2:	movs    	r1, #0x27
0x0074b4:	adds    	r0, r5, #0
0x0074b6:	ldr     	r3, [r4, #0x38]
0x0074b8:	bl      	#0x7e90
0x0074bc:	ldr     	r1, [r7, #0x50]
0x0074be:	ldr     	r2, [r1]
0x0074c0:	ldr     	r1, [r1, #0x10]
0x0074c2:	lsls    	r1, r1, #2
0x0074c4:	ldr     	r1, [r2, r1]
0x0074c6:	cmp     	r0, #0
0x0074c8:	beq     	#0x74d2
0x0074ca:	movs    	r2, #0x33
0x0074cc:	ldrb    	r2, [r2, r0]
0x0074ce:	cmp     	r2, #0
0x0074d0:	bne     	#0x74d6
0x0074d2:	movs    	r0, #0
0x0074d4:	b       	#0x74e0
0x0074d6:	cmp     	r0, r1
0x0074d8:	bne     	#0x74de
0x0074da:	movs    	r0, #0
0x0074dc:	b       	#0x74e0
0x0074de:	movs    	r0, #1
0x0074e0:	ldr     	r6, [pc, #0xd4]
0x0074e2:	add     	r6, pc
0x0074e4:	ldr     	r7, [pc, #0xd4]
0x0074e6:	add     	r7, pc
0x0074e8:	movs    	r3, #4
0x0074ea:	cmp     	r0, #0
0x0074ec:	beq     	#0x7560
0x0074ee:	movs    	r1, #0
0x0074f0:	movs    	r2, #0
0x0074f2:	str     	r2, [sp, #8]
0x0074f4:	str     	r1, [sp]
0x0074f6:	str     	r1, [sp, #4]
0x0074f8:	movs    	r1, #0xa
0x0074fa:	movs    	r2, #3
0x0074fc:	adds    	r0, r5, #0
0x0074fe:	bl      	#0x7e90
0x007502:	str     	r0, [r4, #0x58]
0x007504:	movs    	r2, #0
0x007506:	movs    	r1, #0
0x007508:	str     	r2, [sp, #8]
0x00750a:	adds    	r2, r6, #0
0x00750c:	str     	r1, [sp]
0x00750e:	str     	r1, [sp, #4]
0x007510:	adds    	r3, r7, #0
0x007512:	subs    	r2, #0x14
0x007514:	movs    	r1, #0x35
0x007516:	movs    	r0, #0xf1
0x007518:	lsls    	r0, r0, #9
0x00751a:	bl      	#0x7e90
0x00751e:	ldr     	r1, [r4, #0x58]
0x007520:	movs    	r2, #0
0x007522:	str     	r0, [r1]
0x007524:	movs    	r1, #0
0x007526:	str     	r1, [sp]
0x007528:	str     	r1, [sp, #4]
0x00752a:	str     	r2, [sp, #8]
0x00752c:	adds    	r3, r7, #0
0x00752e:	adds    	r2, r6, #0
0x007530:	movs    	r1, #0x35
0x007532:	movs    	r0, #0xf1
0x007534:	lsls    	r0, r0, #9
0x007536:	bl      	#0x7e90
0x00753a:	ldr     	r1, [r4, #0x58]
0x00753c:	movs    	r2, #0
0x00753e:	str     	r0, [r1, #4]
0x007540:	movs    	r1, #0
0x007542:	str     	r2, [sp, #8]
0x007544:	adds    	r2, r6, #0
0x007546:	str     	r1, [sp]
0x007548:	str     	r1, [sp, #4]
0x00754a:	adds    	r3, r7, #0
0x00754c:	subs    	r2, #8
0x00754e:	movs    	r1, #0x35
0x007550:	movs    	r0, #0xf1
0x007552:	lsls    	r0, r0, #9
0x007554:	bl      	#0x7e90
0x007558:	ldr     	r1, [r4, #0x58]
0x00755a:	str     	r0, [r1, #8]
0x00755c:	add     	sp, #0xc
0x00755e:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0075c4 =====
0x0075c4:	push    	{r4, r5, r6, lr}
0x0075c6:	ldr     	r4, [pc, #0x48]
0x0075c8:	sub     	sp, #0x10
0x0075ca:	adds    	r6, r1, #0
0x0075cc:	add     	r4, sb
0x0075ce:	strb    	r2, [r4, #1]
0x0075d0:	movs    	r1, #2
0x0075d2:	strh    	r1, [r0, #0x28]
0x0075d4:	movs    	r1, #5
0x0075d6:	strh    	r1, [r0, #0x2a]
0x0075d8:	movs    	r5, #0
0x0075da:	strh    	r5, [r0, #0x30]
0x0075dc:	strb    	r3, [r4, #0x11]
0x0075de:	ldr     	r0, [r4, #0x70]
0x0075e0:	cmp     	r0, #0
0x0075e2:	bne     	#0x7600
0x0075e4:	movs    	r2, #0
0x0075e6:	movs    	r1, #0
0x0075e8:	str     	r2, [sp, #8]
0x0075ea:	ldr     	r2, [pc, #0x28]
0x0075ec:	str     	r1, [sp]
0x0075ee:	str     	r1, [sp, #4]
0x0075f0:	adds    	r3, r5, #0
0x0075f2:	add     	r2, pc
0x0075f4:	movs    	r1, #0x37
0x0075f6:	movs    	r0, #0xf1
0x0075f8:	lsls    	r0, r0, #9
0x0075fa:	bl      	#0x7e90
0x0075fe:	str     	r0, [r4, #0x70]
0x007600:	cmp     	r6, #0
0x007602:	ble     	#0x760c
0x007604:	movs    	r0, #1
0x007606:	strb    	r0, [r4, #0xd]
0x007608:	add     	sp, #0x10
0x00760a:	pop     	{r4, r5, r6, pc}

; ===== candidate_007618 =====
0x007618:	push    	{r4, r5, lr}
0x00761a:	adds    	r5, r0, #0
0x00761c:	movs    	r0, #3
0x00761e:	sub     	sp, #0xc
0x007620:	strh    	r0, [r5, #0x28]
0x007622:	movs    	r4, #0
0x007624:	strh    	r4, [r5, #0x2e]
0x007626:	strh    	r4, [r5, #0x2c]
0x007628:	movs    	r1, #0
0x00762a:	str     	r1, [sp]
0x00762c:	str     	r1, [sp, #4]
0x00762e:	movs    	r2, #0
0x007630:	str     	r2, [sp, #8]
0x007632:	movs    	r3, #0xc
0x007634:	ldrsh   	r2, [r5, r3]
0x007636:	adds    	r3, r5, #0
0x007638:	movs    	r1, #0x8b
0x00763a:	movs    	r0, #0xf1
0x00763c:	lsls    	r0, r0, #9
0x00763e:	bl      	#0x7e90
0x007642:	movs    	r2, #0
0x007644:	movs    	r1, #0
0x007646:	ldr     	r3, [pc, #0x30]
0x007648:	str     	r1, [sp]
0x00764a:	str     	r1, [sp, #4]
0x00764c:	str     	r2, [sp, #8]
0x00764e:	add     	r3, pc
0x007650:	adds    	r2, r0, #0
0x007652:	movs    	r0, #0xf1
0x007654:	movs    	r1, #0x2d
0x007656:	lsls    	r0, r0, #9
0x007658:	bl      	#0x7e90
0x00765c:	movs    	r2, #0
0x00765e:	movs    	r1, #0
0x007660:	str     	r2, [sp, #8]
0x007662:	adds    	r3, r4, #0
0x007664:	adds    	r2, r0, #0
0x007666:	str     	r1, [sp]
0x007668:	str     	r1, [sp, #4]
0x00766a:	movs    	r1, #0x6f
0x00766c:	movs    	r0, #0xf1
0x00766e:	lsls    	r0, r0, #9
0x007670:	bl      	#0x7e90
0x007674:	add     	sp, #0xc
0x007676:	pop     	{r4, r5, pc}

; ===== candidate_00767c =====
0x00767c:	push    	{r4, r5, lr}
0x00767e:	sub     	sp, #0xc
0x007680:	movs    	r1, #0
0x007682:	movs    	r2, #0
0x007684:	str     	r2, [sp, #8]
0x007686:	str     	r1, [sp]
0x007688:	str     	r1, [sp, #4]
0x00768a:	movs    	r5, #0xf1
0x00768c:	lsls    	r5, r5, #9
0x00768e:	movs    	r1, #0x14
0x007690:	movs    	r2, #0x17
0x007692:	movs    	r3, #0x32
0x007694:	adds    	r0, r5, #0
0x007696:	bl      	#0x7e90
0x00769a:	ldr     	r1, [pc, #0x3c]
0x00769c:	movs    	r0, #2
0x00769e:	add     	r1, sb
0x0076a0:	str     	r0, [r1]
0x0076a2:	movs    	r1, #0
0x0076a4:	movs    	r2, #0
0x0076a6:	str     	r2, [sp, #8]
0x0076a8:	str     	r1, [sp]
0x0076aa:	str     	r1, [sp, #4]
0x0076ac:	movs    	r4, #0
0x0076ae:	adds    	r3, r4, #0
0x0076b0:	movs    	r1, #0xe1
0x0076b2:	movs    	r2, #0x51
0x0076b4:	adds    	r0, r5, #0
0x0076b6:	bl      	#0x7e90
0x0076ba:	cmp     	r0, #1
0x0076bc:	bne     	#0x76d2
0x0076be:	movs    	r1, #0
0x0076c0:	str     	r1, [sp]
0x0076c2:	str     	r1, [sp, #4]
0x0076c4:	movs    	r2, #0
0x0076c6:	movs    	r1, #0x34
0x0076c8:	adds    	r3, r4, #0
0x0076ca:	adds    	r0, r5, #0
0x0076cc:	str     	r2, [sp, #8]
0x0076ce:	bl      	#0x7e90
0x0076d2:	add     	sp, #0xc
0x0076d4:	pop     	{r4, r5, pc}

; ===== candidate_0076dc =====
0x0076dc:	push    	{r4, r5, lr}
0x0076de:	ldr     	r1, [pc, #0x58]
0x0076e0:	sub     	sp, #0xc
0x0076e2:	movs    	r0, #1
0x0076e4:	add     	r1, sb
0x0076e6:	str     	r0, [r1]
0x0076e8:	movs    	r1, #0
0x0076ea:	movs    	r2, #0
0x0076ec:	str     	r2, [sp, #8]
0x0076ee:	str     	r1, [sp]
0x0076f0:	str     	r1, [sp, #4]
0x0076f2:	movs    	r5, #0xf1
0x0076f4:	lsls    	r5, r5, #9
0x0076f6:	movs    	r1, #0x14
0x0076f8:	movs    	r2, #0x17
0x0076fa:	movs    	r3, #0x31
0x0076fc:	adds    	r0, r5, #0
0x0076fe:	bl      	#0x7e90
0x007702:	movs    	r1, #0
0x007704:	movs    	r2, #0
0x007706:	str     	r2, [sp, #8]
0x007708:	str     	r1, [sp]
0x00770a:	str     	r1, [sp, #4]
0x00770c:	movs    	r4, #0
0x00770e:	adds    	r3, r4, #0
0x007710:	movs    	r1, #0xe1
0x007712:	movs    	r2, #0x51
0x007714:	adds    	r0, r5, #0
0x007716:	bl      	#0x7e90
0x00771a:	cmp     	r0, #1
0x00771c:	bne     	#0x7732
0x00771e:	movs    	r1, #0
0x007720:	str     	r1, [sp]
0x007722:	str     	r1, [sp, #4]
0x007724:	movs    	r2, #0
0x007726:	movs    	r1, #0x34
0x007728:	adds    	r3, r4, #0
0x00772a:	adds    	r0, r5, #0
0x00772c:	str     	r2, [sp, #8]
0x00772e:	bl      	#0x7e90
0x007732:	add     	sp, #0xc
0x007734:	pop     	{r4, r5, pc}

; ===== candidate_00773c =====
0x00773c:	push    	{r4, lr}
0x00773e:	cmp     	r1, #0
0x007740:	beq     	#0x7768
0x007742:	movs    	r2, #6
0x007744:	strh    	r2, [r0, #0x28]
0x007746:	adds    	r2, r0, #0
0x007748:	movs    	r3, #0
0x00774a:	str     	r3, [r0, #0x70]
0x00774c:	adds    	r2, #0x40
0x00774e:	strh    	r3, [r2, #8]
0x007750:	strh    	r3, [r2, #0xa]
0x007752:	strh    	r3, [r2, #0xc]
0x007754:	movs    	r2, #0x84
0x007756:	str     	r1, [r2, r0]
0x007758:	ldr     	r2, [r1]
0x00775a:	adds    	r4, r0, #0
0x00775c:	adds    	r4, #0xd0
0x00775e:	cmp     	r2, #0x13
0x007760:	bne     	#0x776a
0x007762:	bl      	#0x637c
0x007766:	strb    	r0, [r4]
0x007768:	pop     	{r4, pc}

; ===== candidate_007770 =====
0x007770:	push    	{r4, lr}
0x007772:	movs    	r2, #0x84
0x007774:	str     	r1, [r2, r0]
0x007776:	movs    	r2, #1
0x007778:	strh    	r2, [r0, #0x28]
0x00777a:	movs    	r2, #0
0x00777c:	str     	r2, [r0, #0x70]
0x00777e:	ldr     	r2, [r1]
0x007780:	adds    	r4, r0, #0
0x007782:	adds    	r4, #0xd0
0x007784:	cmp     	r2, #0x13
0x007786:	bne     	#0x7790
0x007788:	bl      	#0x637c
0x00778c:	strb    	r0, [r4]
0x00778e:	pop     	{r4, pc}

; ===== candidate_0077ac =====
0x0077ac:	push    	{r4, r5, r6, lr}
0x0077ae:	sub     	sp, #0x10
0x0077b0:	movs    	r1, #0
0x0077b2:	str     	r1, [sp]
0x0077b4:	str     	r1, [sp, #4]
0x0077b6:	movs    	r4, #0
0x0077b8:	movs    	r2, #0
0x0077ba:	adds    	r3, r4, #0
0x0077bc:	movs    	r1, #0x34
0x0077be:	movs    	r0, #0xf1
0x0077c0:	lsls    	r0, r0, #9
0x0077c2:	str     	r2, [sp, #8]
0x0077c4:	bl      	#0x7e90
0x0077c8:	movs    	r1, #0
0x0077ca:	movs    	r2, #0
0x0077cc:	str     	r2, [sp, #8]
0x0077ce:	str     	r1, [sp]
0x0077d0:	str     	r1, [sp, #4]
0x0077d2:	movs    	r1, #0xe1
0x0077d4:	movs    	r2, #0x55
0x0077d6:	adds    	r3, r4, #0
0x0077d8:	movs    	r0, #0xf1
0x0077da:	lsls    	r0, r0, #9
0x0077dc:	bl      	#0x7e90
0x0077e0:	movs    	r1, #0
0x0077e2:	adds    	r5, r0, #0
0x0077e4:	movs    	r2, #0
0x0077e6:	str     	r2, [sp, #8]
0x0077e8:	str     	r1, [sp]
0x0077ea:	str     	r1, [sp, #4]
0x0077ec:	movs    	r1, #0xe1
0x0077ee:	movs    	r2, #0x56
0x0077f0:	movs    	r0, #0xf1
0x0077f2:	adds    	r3, r4, #0
0x0077f4:	lsls    	r0, r0, #9
0x0077f6:	bl      	#0x7e90
0x0077fa:	movs    	r2, #0
0x0077fc:	mvns    	r1, r2
0x0077fe:	str     	r2, [sp, #8]
0x007800:	adds    	r3, r5, #0
0x007802:	adds    	r2, r0, #0
0x007804:	str     	r1, [sp]
0x007806:	str     	r1, [sp, #4]
0x007808:	movs    	r1, #5
0x00780a:	movs    	r0, #0xf1
0x00780c:	lsls    	r0, r0, #9
0x00780e:	bl      	#0x7e90
0x007812:	movs    	r1, #0
0x007814:	movs    	r2, #0
0x007816:	str     	r2, [sp, #8]
0x007818:	str     	r1, [sp]
0x00781a:	str     	r1, [sp, #4]
0x00781c:	adds    	r3, r0, #0
0x00781e:	movs    	r0, #0xf1
0x007820:	movs    	r1, #0x14
0x007822:	movs    	r2, #0x56
0x007824:	lsls    	r0, r0, #9
0x007826:	bl      	#0x7e90
0x00782a:	movs    	r1, #0
0x00782c:	movs    	r2, #0
0x00782e:	str     	r2, [sp, #8]
0x007830:	str     	r1, [sp]
0x007832:	str     	r1, [sp, #4]
0x007834:	movs    	r3, #0xff
0x007836:	adds    	r3, #0x1b
0x007838:	movs    	r1, #0x14
0x00783a:	movs    	r2, #0x17
0x00783c:	movs    	r0, #0xf1
0x00783e:	lsls    	r0, r0, #9
0x007840:	bl      	#0x7e90
0x007844:	movs    	r1, #0
0x007846:	str     	r1, [sp]
0x007848:	str     	r1, [sp, #4]
0x00784a:	movs    	r2, #0
0x00784c:	movs    	r1, #0xe6
0x00784e:	adds    	r3, r4, #0
0x007850:	movs    	r0, #0xf1
0x007852:	lsls    	r0, r0, #9
0x007854:	str     	r2, [sp, #8]
0x007856:	bl      	#0x7e90
0x00785a:	movs    	r1, #0
0x00785c:	movs    	r2, #0
0x00785e:	str     	r2, [sp, #8]
0x007860:	str     	r1, [sp]
0x007862:	str     	r1, [sp, #4]
0x007864:	movs    	r1, #0x14
0x007866:	movs    	r2, #0x57
0x007868:	adds    	r3, r4, #0
0x00786a:	movs    	r0, #0xf1
0x00786c:	lsls    	r0, r0, #9
0x00786e:	bl      	#0x7e90
0x007872:	ldr     	r0, [pc, #0x30]
0x007874:	movs    	r1, #0
0x007876:	add     	r0, sb
0x007878:	str     	r4, [r0, #0x54]
0x00787a:	movs    	r2, #0
0x00787c:	str     	r2, [sp, #8]
0x00787e:	str     	r1, [sp]
0x007880:	str     	r1, [sp, #4]
0x007882:	movs    	r1, #0xe1
0x007884:	movs    	r2, #0x4c
0x007886:	movs    	r0, #0xf1
0x007888:	adds    	r3, r4, #0
0x00788a:	lsls    	r0, r0, #9
0x00788c:	bl      	#0x7e90
0x007890:	ldr     	r0, [r0, #0x10]
0x007892:	movs    	r1, #1
0x007894:	bl      	#0x63c0
0x007898:	ldr     	r1, [pc, #8]
0x00789a:	add     	r1, sb
0x00789c:	adds    	r1, #0x80
0x00789e:	str     	r0, [r1, #0x28]
0x0078a0:	add     	sp, #0x10
0x0078a2:	pop     	{r4, r5, r6, pc}

; ===== candidate_0078a8 =====
0x0078a8:	push    	{r4, lr}
0x0078aa:	movs    	r2, #0
0x0078ac:	sub     	sp, #0x10
0x0078ae:	mvns    	r1, r2
0x0078b0:	ldr     	r3, [pc, #0x70]
0x0078b2:	str     	r1, [sp]
0x0078b4:	str     	r1, [sp, #4]
0x0078b6:	str     	r2, [sp, #8]
0x0078b8:	add     	r3, pc
0x0078ba:	ldr     	r4, [pc, #0x6c]
0x0078bc:	movs    	r1, #5
0x0078be:	movs    	r0, #0xf1
0x0078c0:	add     	r4, sb
0x0078c2:	ldr     	r2, [r4, #0x40]
0x0078c4:	lsls    	r0, r0, #9
0x0078c6:	bl      	#0x7e90
0x0078ca:	movs    	r2, #0
0x0078cc:	str     	r0, [r4, #0x40]
0x0078ce:	mvns    	r1, r2
0x0078d0:	ldr     	r3, [pc, #0x58]
0x0078d2:	str     	r1, [sp]
0x0078d4:	str     	r1, [sp, #4]
0x0078d6:	str     	r2, [sp, #8]
0x0078d8:	add     	r3, pc
0x0078da:	movs    	r1, #5
0x0078dc:	movs    	r0, #0xf1
0x0078de:	lsls    	r0, r0, #9
0x0078e0:	ldr     	r2, [r4, #0x4c]
0x0078e2:	bl      	#0x7e90
0x0078e6:	movs    	r2, #0
0x0078e8:	str     	r0, [r4, #0x4c]
0x0078ea:	mvns    	r1, r2
0x0078ec:	ldr     	r3, [pc, #0x40]
0x0078ee:	str     	r1, [sp]
0x0078f0:	str     	r1, [sp, #4]
0x0078f2:	str     	r2, [sp, #8]
0x0078f4:	add     	r3, pc
0x0078f6:	movs    	r1, #5
0x0078f8:	movs    	r0, #0xf1
0x0078fa:	lsls    	r0, r0, #9
0x0078fc:	ldr     	r2, [r4, #0x44]
0x0078fe:	bl      	#0x7e90
0x007902:	movs    	r2, #0
0x007904:	str     	r0, [r4, #0x44]
0x007906:	mvns    	r1, r2
0x007908:	ldr     	r3, [pc, #0x28]
0x00790a:	str     	r1, [sp]
0x00790c:	str     	r1, [sp, #4]
0x00790e:	str     	r2, [sp, #8]
0x007910:	add     	r3, pc
0x007912:	movs    	r1, #5
0x007914:	movs    	r0, #0xf1
0x007916:	lsls    	r0, r0, #9
0x007918:	ldr     	r2, [r4, #0x48]
0x00791a:	bl      	#0x7e90
0x00791e:	str     	r0, [r4, #0x48]
0x007920:	add     	sp, #0x10
0x007922:	pop     	{r4, pc}

; ===== candidate_007938 =====
0x007938:	push    	{r4, r5, r6, r7, lr}
0x00793a:	sub     	sp, #0xc
0x00793c:	movs    	r1, #0
0x00793e:	str     	r1, [sp]
0x007940:	str     	r1, [sp, #4]
0x007942:	movs    	r2, #0
0x007944:	str     	r2, [sp, #8]
0x007946:	ldr     	r2, [r0]
0x007948:	adds    	r5, r0, #0
0x00794a:	movs    	r0, #0xf1
0x00794c:	movs    	r1, #0x11
0x00794e:	movs    	r3, #4
0x007950:	lsls    	r0, r0, #9
0x007952:	bl      	#0x7e90
0x007956:	adds    	r6, r0, #0
0x007958:	movs    	r4, #0
0x00795a:	cmp     	r0, #0
0x00795c:	ble     	#0x7984
0x00795e:	movs    	r7, #0
0x007960:	ldr     	r1, [r5]
0x007962:	lsls    	r0, r4, #2
0x007964:	ldr     	r1, [r1, r0]
0x007966:	cmp     	r1, #0
0x007968:	beq     	#0x797e
0x00796a:	adds    	r1, #0xa0
0x00796c:	strb    	r7, [r1, #0xc]
0x00796e:	ldr     	r1, [r5]
0x007970:	ldr     	r0, [r1, r0]
0x007972:	movs    	r1, #0x33
0x007974:	ldrb    	r1, [r1, r0]
0x007976:	cmp     	r1, #1
0x007978:	bne     	#0x797e
0x00797a:	bl      	#0x7798
0x00797e:	adds    	r4, #1
0x007980:	cmp     	r4, r6
0x007982:	blt     	#0x7960
0x007984:	add     	sp, #0xc
0x007986:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007988 =====
0x007988:	push    	{r4, r5, r6, r7, lr}
0x00798a:	sub     	sp, #0x14
0x00798c:	movs    	r1, #0
0x00798e:	str     	r1, [sp]
0x007990:	str     	r1, [sp, #4]
0x007992:	movs    	r2, #0
0x007994:	str     	r2, [sp, #8]
0x007996:	movs    	r5, #0xf1
0x007998:	lsls    	r5, r5, #9
0x00799a:	ldr     	r2, [r0]
0x00799c:	movs    	r1, #0x11
0x00799e:	adds    	r4, r0, #0
0x0079a0:	movs    	r3, #4
0x0079a2:	adds    	r0, r5, #0
0x0079a4:	bl      	#0x7e90
0x0079a8:	movs    	r6, #0
0x0079aa:	cmp     	r0, #0
0x0079ac:	str     	r0, [sp, #0x10]
0x0079ae:	ble     	#0x7a40
0x0079b0:	movs    	r7, #0
0x0079b2:	ldr     	r0, [r4, #0x18]
0x0079b4:	lsls    	r5, r6, #2
0x0079b6:	ldr     	r3, [r0, r5]
0x0079b8:	cmp     	r3, #0
0x0079ba:	beq     	#0x79f2
0x0079bc:	movs    	r2, #0
0x0079be:	movs    	r1, #0
0x0079c0:	str     	r2, [sp, #8]
0x0079c2:	adds    	r2, r3, #0
0x0079c4:	str     	r1, [sp]
0x0079c6:	str     	r1, [sp, #4]
0x0079c8:	movs    	r1, #0x28
0x0079ca:	adds    	r3, r7, #0
0x0079cc:	movs    	r0, #0xf1
0x0079ce:	lsls    	r0, r0, #9
0x0079d0:	bl      	#0x7e90
0x0079d4:	movs    	r1, #0
0x0079d6:	movs    	r2, #0
0x0079d8:	str     	r2, [sp, #8]
0x0079da:	str     	r1, [sp]
0x0079dc:	str     	r1, [sp, #4]
0x0079de:	ldr     	r0, [r4, #0x18]
0x0079e0:	movs    	r1, #9
0x0079e2:	ldr     	r2, [r0, r5]
0x0079e4:	movs    	r0, #0xf1
0x0079e6:	adds    	r3, r7, #0
0x0079e8:	lsls    	r0, r0, #9
0x0079ea:	bl      	#0x7e90
0x0079ee:	ldr     	r0, [r4, #0x18]
0x0079f0:	str     	r7, [r0, r5]
0x0079f2:	ldr     	r0, [r4, #0x1c]
0x0079f4:	ldr     	r3, [r0, r5]
0x0079f6:	cmp     	r3, #0
0x0079f8:	beq     	#0x7a30
0x0079fa:	movs    	r2, #0
0x0079fc:	movs    	r1, #0
0x0079fe:	str     	r2, [sp, #8]
0x007a00:	adds    	r2, r3, #0
0x007a02:	str     	r1, [sp]
0x007a04:	str     	r1, [sp, #4]
0x007a06:	movs    	r1, #0x28
0x007a08:	adds    	r3, r7, #0
0x007a0a:	movs    	r0, #0xf1
0x007a0c:	lsls    	r0, r0, #9
0x007a0e:	bl      	#0x7e90
0x007a12:	movs    	r1, #0
0x007a14:	movs    	r2, #0
0x007a16:	str     	r2, [sp, #8]
0x007a18:	str     	r1, [sp]
0x007a1a:	str     	r1, [sp, #4]
0x007a1c:	ldr     	r0, [r4, #0x1c]
0x007a1e:	movs    	r1, #9
0x007a20:	ldr     	r2, [r0, r5]
0x007a22:	movs    	r0, #0xf1
0x007a24:	adds    	r3, r7, #0
0x007a26:	lsls    	r0, r0, #9
0x007a28:	bl      	#0x7e90
0x007a2c:	ldr     	r0, [r4, #0x1c]
0x007a2e:	str     	r7, [r0, r5]
0x007a30:	ldr     	r0, [r4, #0x20]
0x007a32:	adds    	r6, #1
0x007a34:	str     	r7, [r0, r5]
0x007a36:	ldr     	r0, [r4, #0x24]
0x007a38:	str     	r7, [r0, r5]
0x007a3a:	ldr     	r0, [sp, #0x10]
0x007a3c:	cmp     	r6, r0
0x007a3e:	blt     	#0x79b2
0x007a40:	add     	sp, #0x14
0x007a42:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007a44 =====
0x007a44:	push    	{r4, r5, r6, lr}
0x007a46:	ldr     	r4, [pc, #0x70]
0x007a48:	movs    	r5, #0xf1
0x007a4a:	add     	r4, sb
0x007a4c:	ldr     	r0, [r4, #0x5c]
0x007a4e:	lsls    	r5, r5, #9
0x007a50:	movs    	r6, #0
0x007a52:	cmp     	r0, #0
0x007a54:	sub     	sp, #0x10
0x007a56:	bne     	#0x7a72
0x007a58:	movs    	r2, #0
0x007a5a:	movs    	r1, #0
0x007a5c:	str     	r2, [sp, #8]
0x007a5e:	ldr     	r2, [pc, #0x5c]
0x007a60:	str     	r1, [sp]
0x007a62:	str     	r1, [sp, #4]
0x007a64:	adds    	r3, r6, #0
0x007a66:	add     	r2, pc
0x007a68:	movs    	r1, #0x37
0x007a6a:	adds    	r0, r5, #0
0x007a6c:	bl      	#0x7e90
0x007a70:	str     	r0, [r4, #0x5c]
0x007a72:	ldr     	r0, [r4, #0x7c]
0x007a74:	cmp     	r0, #0
0x007a76:	bne     	#0x7a92
0x007a78:	movs    	r2, #0
0x007a7a:	movs    	r1, #0
0x007a7c:	str     	r2, [sp, #8]
0x007a7e:	ldr     	r2, [pc, #0x40]
0x007a80:	str     	r1, [sp]
0x007a82:	str     	r1, [sp, #4]
0x007a84:	adds    	r3, r6, #0
0x007a86:	add     	r2, pc
0x007a88:	movs    	r1, #0x37
0x007a8a:	adds    	r0, r5, #0
0x007a8c:	bl      	#0x7e90
0x007a90:	str     	r0, [r4, #0x7c]
0x007a92:	ldr     	r6, [r4, #0x74]
0x007a94:	cmp     	r6, #0
0x007a96:	bne     	#0x7ab2
0x007a98:	movs    	r2, #0
0x007a9a:	mvns    	r1, r2
0x007a9c:	ldr     	r3, [pc, #0x24]
0x007a9e:	str     	r1, [sp]
0x007aa0:	str     	r1, [sp, #4]
0x007aa2:	str     	r2, [sp, #8]
0x007aa4:	add     	r3, pc
0x007aa6:	adds    	r2, r6, #0
0x007aa8:	movs    	r1, #5
0x007aaa:	adds    	r0, r5, #0
0x007aac:	bl      	#0x7e90
0x007ab0:	str     	r0, [r4, #0x74]
0x007ab2:	add     	sp, #0x10
0x007ab4:	pop     	{r4, r5, r6, pc}

; ===== candidate_007ac8 =====
0x007ac8:	push    	{r4, lr}
0x007aca:	ldr     	r4, [pc, #0x2c]
0x007acc:	sub     	sp, #0x10
0x007ace:	add     	r4, sb
0x007ad0:	ldr     	r0, [r4, #0x60]
0x007ad2:	cmp     	r0, #0
0x007ad4:	bne     	#0x7af2
0x007ad6:	movs    	r2, #0
0x007ad8:	movs    	r1, #0
0x007ada:	str     	r2, [sp, #8]
0x007adc:	ldr     	r2, [pc, #0x1c]
0x007ade:	str     	r1, [sp]
0x007ae0:	str     	r1, [sp, #4]
0x007ae2:	movs    	r3, #0
0x007ae4:	add     	r2, pc
0x007ae6:	movs    	r1, #0x37
0x007ae8:	movs    	r0, #0xf1
0x007aea:	lsls    	r0, r0, #9
0x007aec:	bl      	#0x7e90
0x007af0:	str     	r0, [r4, #0x60]
0x007af2:	add     	sp, #0x10
0x007af4:	pop     	{r4, pc}

; ===== candidate_007b00 =====
0x007b00:	push    	{r4, lr}
0x007b02:	sub     	sp, #0x10
0x007b04:	movs    	r2, #0
0x007b06:	movs    	r1, #0
0x007b08:	str     	r2, [sp, #8]
0x007b0a:	adds    	r4, r0, #0
0x007b0c:	adds    	r2, r0, #0
0x007b0e:	str     	r1, [sp]
0x007b10:	str     	r1, [sp, #4]
0x007b12:	movs    	r1, #0x11
0x007b14:	movs    	r0, #0xf1
0x007b16:	movs    	r3, #4
0x007b18:	lsls    	r0, r0, #9
0x007b1a:	bl      	#0x7e90
0x007b1e:	movs    	r1, #0
0x007b20:	cmp     	r0, #0
0x007b22:	ble     	#0x7b3a
0x007b24:	lsls    	r2, r1, #2
0x007b26:	ldr     	r2, [r4, r2]
0x007b28:	ldr     	r2, [r2, #4]
0x007b2a:	cmp     	r2, #1
0x007b2c:	bne     	#0x7b34
0x007b2e:	movs    	r0, #1
0x007b30:	add     	sp, #0x10
0x007b32:	pop     	{r4, pc}

; ===== candidate_007b40 =====
0x007b40:	push    	{r4, r5, r6, r7, lr}
0x007b42:	ldr     	r6, [pc, #0x48]
0x007b44:	adds    	r5, r0, #0
0x007b46:	add     	r6, sb
0x007b48:	ldr     	r7, [r6, #0x28]
0x007b4a:	movs    	r4, #0
0x007b4c:	cmp     	r7, #0
0x007b4e:	sub     	sp, #0xc
0x007b50:	bne     	#0x7b58
0x007b52:	movs    	r0, #0
0x007b54:	add     	sp, #0xc
0x007b56:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007b90 =====
0x007b90:	push    	{r4, r5, r6, r7, lr}
0x007b92:	ldr     	r5, [pc, #0x1d8]
0x007b94:	movs    	r4, #0xf1
0x007b96:	lsls    	r4, r4, #9
0x007b98:	movs    	r7, #0
0x007b9a:	cmp     	r0, #0xd
0x007b9c:	sub     	sp, #0x1c
0x007b9e:	add     	r5, sb
0x007ba0:	beq     	#0x7c86
0x007ba2:	bgt     	#0x7c14
0x007ba4:	cmp     	r0, #2
0x007ba6:	beq     	#0x7bb4
0x007ba8:	cmp     	r0, #5
0x007baa:	beq     	#0x7c20
0x007bac:	cmp     	r0, #8
0x007bae:	beq     	#0x7c86
0x007bb0:	cmp     	r0, #0xc
0x007bb2:	bne     	#0x7c10
0x007bb4:	movs    	r1, #0
0x007bb6:	movs    	r2, #0
0x007bb8:	str     	r2, [sp, #8]
0x007bba:	str     	r1, [sp]
0x007bbc:	str     	r1, [sp, #4]
0x007bbe:	movs    	r1, #0xe1
0x007bc0:	movs    	r2, #0x54
0x007bc2:	adds    	r3, r7, #0
0x007bc4:	adds    	r0, r4, #0
0x007bc6:	bl      	#0x7e90
0x007bca:	movs    	r2, #0
0x007bcc:	str     	r2, [sp, #8]
0x007bce:	movs    	r1, #0
0x007bd0:	adds    	r3, r7, #0
0x007bd2:	adds    	r2, r0, #0
0x007bd4:	str     	r1, [sp, #4]
0x007bd6:	movs    	r1, #0x29
0x007bd8:	movs    	r0, #0xf1
0x007bda:	lsls    	r0, r0, #9
0x007bdc:	str     	r5, [sp]
0x007bde:	bl      	#0x7e90
0x007be2:	movs    	r1, #0
0x007be4:	movs    	r2, #0
0x007be6:	str     	r2, [sp, #8]
0x007be8:	str     	r1, [sp]
0x007bea:	str     	r1, [sp, #4]
0x007bec:	movs    	r1, #0x14
0x007bee:	movs    	r2, #0x57
0x007bf0:	adds    	r3, r7, #0
0x007bf2:	movs    	r0, #0xf1
0x007bf4:	lsls    	r0, r0, #9
0x007bf6:	bl      	#0x7e90
0x007bfa:	movs    	r1, #0
0x007bfc:	str     	r1, [sp]
0x007bfe:	str     	r1, [sp, #4]
0x007c00:	movs    	r2, #0
0x007c02:	movs    	r1, #0xe6
0x007c04:	adds    	r3, r7, #0
0x007c06:	movs    	r0, #0xf1
0x007c08:	lsls    	r0, r0, #9
0x007c0a:	str     	r2, [sp, #8]
0x007c0c:	bl      	#0x7e90
0x007c10:	add     	sp, #0x1c
0x007c12:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007d74 =====
0x007d74:	push    	{r4, r5, r6, r7, lr}
0x007d76:	sub     	sp, #0xc
0x007d78:	adds    	r6, r1, #0
0x007d7a:	adds    	r7, r2, #0
0x007d7c:	movs    	r1, #0
0x007d7e:	movs    	r2, #0
0x007d80:	adds    	r5, r0, #0
0x007d82:	str     	r2, [sp, #8]
0x007d84:	str     	r1, [sp]
0x007d86:	str     	r1, [sp, #4]
0x007d88:	movs    	r4, #0
0x007d8a:	adds    	r3, r4, #0
0x007d8c:	movs    	r1, #0xf
0x007d8e:	movs    	r2, #0x6c
0x007d90:	movs    	r0, #0xf1
0x007d92:	lsls    	r0, r0, #9
0x007d94:	bl      	#0x7e90
0x007d98:	str     	r4, [r0, #0x2c]
0x007d9a:	stm     	r0!, {r5, r6, r7}
0x007d9c:	subs    	r0, #0xc
0x007d9e:	str     	r4, [r0, #0x30]
0x007da0:	str     	r4, [r0, #0x38]
0x007da2:	str     	r4, [r0, #0x3c]
0x007da4:	str     	r4, [r0, #0x44]
0x007da6:	str     	r4, [r0, #0x14]
0x007da8:	str     	r4, [r0, #0x68]
0x007daa:	str     	r4, [r0, #0x54]
0x007dac:	str     	r4, [r0, #0x58]
0x007dae:	str     	r4, [r0, #0x5c]
0x007db0:	str     	r4, [r0, #0x60]
0x007db2:	str     	r4, [r0, #0x64]
0x007db4:	add     	sp, #0xc
0x007db6:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007db8 =====
0x007db8:	push    	{r3, r4, r5, lr}
0x007dba:	ldr     	r4, [pc, #0x74]
0x007dbc:	add     	r4, pc
0x007dbe:	ldr     	r0, [r4, #0x38]
0x007dc0:	movs    	r1, #0x14
0x007dc2:	ldr     	r2, [r0, #0x64]
0x007dc4:	ldr     	r0, [pc, #0x6c]
0x007dc6:	add     	r0, pc
0x007dc8:	blx     	r2
0x007dca:	movs    	r5, #0
0x007dcc:	mvns    	r5, r5
0x007dce:	cmp     	r0, r5
0x007dd0:	bne     	#0x7dd6
0x007dd2:	adds    	r0, r5, #0
0x007dd4:	pop     	{r3, r4, r5, pc}

; ===== candidate_007e40 =====
0x007e40:	push    	{r4, lr}
0x007e42:	sub     	sp, #0x10
0x007e44:	lsls    	r0, r0, #0x18
0x007e46:	lsrs    	r0, r0, #0x18
0x007e48:	str     	r0, [sp]
0x007e4a:	ldr     	r0, [pc, #0x38]
0x007e4c:	lsls    	r2, r2, #0x18
0x007e4e:	lsls    	r1, r1, #0x18
0x007e50:	lsrs    	r1, r1, #0x18
0x007e52:	lsrs    	r2, r2, #0x18
0x007e54:	str     	r2, [sp, #8]
0x007e56:	str     	r1, [sp, #4]
0x007e58:	add     	r0, pc
0x007e5a:	ldr     	r0, [r0, #0x38]
0x007e5c:	adds    	r1, r0, #0
0x007e5e:	adds    	r1, #0xff
0x007e60:	adds    	r1, #0x41
0x007e62:	ldr     	r2, [r1, #0x34]
0x007e64:	ldr     	r1, [r1, #0x30]
0x007e66:	ldr     	r2, [r2]
0x007e68:	ldr     	r1, [r1]
0x007e6a:	lsls    	r3, r2, #0x10
0x007e6c:	lsls    	r2, r1, #0x10
0x007e6e:	asrs    	r2, r2, #0x10
0x007e70:	asrs    	r3, r3, #0x10
0x007e72:	adds    	r0, #0xff
0x007e74:	adds    	r0, #0xc1
0x007e76:	ldr     	r4, [r0, #0x28]
0x007e78:	movs    	r1, #0
0x007e7a:	movs    	r0, #0
0x007e7c:	blx     	r4
0x007e7e:	add     	sp, #0x10
0x007e80:	pop     	{r4, pc}

; ===== candidate_007e90 =====
0x007e90:	push    	{r4, r5, r6, r7, lr}
0x007e92:	adds    	r5, r1, #0
0x007e94:	adds    	r4, r0, #0
0x007e96:	adds    	r6, r2, #0
0x007e98:	ldr     	r2, [pc, #0x28]
0x007e9a:	sub     	sp, #0x14
0x007e9c:	mov     	ip, r3
0x007e9e:	add     	r2, pc
0x007ea0:	ldr     	r0, [sp, #0x2c]
0x007ea2:	ldr     	r1, [sp, #0x30]
0x007ea4:	ldr     	r7, [sp, #0x28]
0x007ea6:	ldr     	r3, [r2, #0x3c]
0x007ea8:	movs    	r2, #2
0x007eaa:	str     	r2, [sp, #0xc]
0x007eac:	str     	r1, [sp, #8]
0x007eae:	str     	r0, [sp, #4]
0x007eb0:	str     	r7, [sp]
0x007eb2:	ldr     	r0, [r3, #0xc]
0x007eb4:	adds    	r1, r5, #0
0x007eb6:	adds    	r2, r6, #0
0x007eb8:	ldr     	r7, [r0, #0x28]
0x007eba:	adds    	r0, r4, #0
0x007ebc:	mov     	r3, ip
0x007ebe:	blx     	r7
0x007ec0:	add     	sp, #0x14
0x007ec2:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007ecc =====
0x007ecc:	push    	{r4, lr}
0x007ece:	movs    	r2, #0
0x007ed0:	add     	r0, pc
0x007ed2:	ldr     	r4, [r0, #0x3c]
0x007ed4:	sub     	sp, #0x10
0x007ed6:	movs    	r1, #0
0x007ed8:	str     	r1, [sp, #4]
0x007eda:	str     	r1, [sp, #8]
0x007edc:	str     	r2, [sp, #0xc]
0x007ede:	str     	r2, [sp]
0x007ee0:	ldr     	r0, [r4, #0xc]
0x007ee2:	ldr     	r2, [r0, #0x24]
0x007ee4:	ldr     	r4, [r0, #0x28]
0x007ee6:	blx     	r4
0x007ee8:	add     	sp, #0x10
0x007eea:	pop     	{r4, pc}

; ===== candidate_007ef0 =====
0x007ef0:	push    	{r4, lr}
0x007ef2:	ldr     	r0, [pc, #0x24]
0x007ef4:	sub     	sp, #0x10
0x007ef6:	add     	r0, pc
0x007ef8:	ldr     	r3, [r0, #0x3c]
0x007efa:	movs    	r2, #0
0x007efc:	movs    	r1, #0
0x007efe:	str     	r1, [sp, #4]
0x007f00:	str     	r1, [sp, #8]
0x007f02:	str     	r2, [sp, #0xc]
0x007f04:	str     	r2, [sp]
0x007f06:	ldr     	r0, [r3, #0xc]
0x007f08:	movs    	r3, #0
0x007f0a:	ldr     	r2, [r0, #0x24]
0x007f0c:	ldr     	r4, [r0, #0x28]
0x007f0e:	movs    	r1, #1
0x007f10:	blx     	r4
0x007f12:	add     	sp, #0x10
0x007f14:	pop     	{r4, pc}

; ===== candidate_007f30 =====
0x007f30:	push    	{r4, lr}
0x007f32:	sub     	sp, #0x10
0x007f34:	movs    	r2, #0
0x007f36:	movs    	r1, #0
0x007f38:	str     	r2, [sp, #8]
0x007f3a:	ldr     	r2, [pc, #0x3c]
0x007f3c:	str     	r1, [sp]
0x007f3e:	str     	r1, [sp, #4]
0x007f40:	movs    	r3, #0
0x007f42:	add     	r2, pc
0x007f44:	ldr     	r1, [pc, #0x34]
0x007f46:	ldr     	r0, [pc, #0x38]
0x007f48:	bl      	#0x7e90
0x007f4c:	ldr     	r3, [pc, #0x38]
0x007f4e:	ldr     	r4, [pc, #0x34]
0x007f50:	add     	r3, sb
0x007f52:	ldr     	r3, [r3]
0x007f54:	movs    	r2, #0x41
0x007f56:	movs    	r1, #0
0x007f58:	add     	r4, sb
0x007f5a:	adds    	r0, r4, #0
0x007f5c:	blx     	r3
0x007f5e:	bl      	#0x7f1c
0x007f62:	ldr     	r3, [pc, #0x28]
0x007f64:	adds    	r1, r0, #0
0x007f66:	add     	r3, sb
0x007f68:	ldr     	r3, [r3]
0x007f6a:	movs    	r2, #0x41
0x007f6c:	adds    	r0, r4, #0
0x007f6e:	blx     	r3
0x007f70:	movs    	r0, #0
0x007f72:	add     	sp, #0x10
0x007f74:	pop     	{r4, pc}

; ===== candidate_007f94 =====
0x007f94:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x007f96:	adds    	r7, r3, #0
0x007f98:	adds    	r6, r2, #0
0x007f9a:	adds    	r5, r0, #0
0x007f9c:	ldr     	r0, [r0]
0x007f9e:	sub     	sp, #4
0x007fa0:	mov     	r1, sb
0x007fa2:	str     	r1, [sp]
0x007fa4:	movs    	r4, #0
0x007fa6:	blx     	#0x2e0
0x007faa:	ldr     	r0, [sp, #8]
0x007fac:	cmp     	r0, #0xb
0x007fae:	bhs     	#0x801c
0x007fb0:	adr     	r3, #4
0x007fb2:	ldrb    	r3, [r3, r0]
0x007fb4:	lsls    	r3, r3, #1
0x007fb6:	add     	pc, r3
0x007fb8:	lsrs    	r5, r0, #0x1c
0x007fba:	subs    	r4, r3, #4
0x007fbc:	movs    	r4, #0x21
0x007fbe:	adds    	r1, #0x27
0x007fc0:	adds    	r1, #0x2b
0x007fc2:	movs    	r7, r5
0x007fc4:	ldr     	r1, [pc, #0x60]
0x007fc6:	ldr     	r0, [r5, #0xc]
0x007fc8:	add     	r1, sb
0x007fca:	str     	r0, [r1, #0x14]
0x007fcc:	bl      	#0x93c
0x007fd0:	bl      	#0x7f30
0x007fd4:	adds    	r4, r0, #0
0x007fd6:	b       	#0x801c
0x007fd8:	ldr     	r0, [r6]
0x007fda:	cmp     	r0, #8
0x007fdc:	bne     	#0x7fe6
0x007fde:	bl      	#0x7e8c
0x007fe2:	adds    	r4, r0, #0
0x007fe4:	b       	#0x801c
0x007fe6:	ldr     	r1, [r6, #4]
0x007fe8:	ldr     	r2, [r6, #8]
0x007fea:	bl      	#0x7e88
0x007fee:	adds    	r4, r0, #0
0x007ff0:	b       	#0x801c
0x007ff2:	bl      	#0x8224
0x007ff6:	b       	#0x801c
0x007ff8:	str     	r7, [r5, #0xc]
0x007ffa:	b       	#0x801c
0x007ffc:	bl      	#0x7f90
0x008000:	b       	#0x801c
0x008002:	bl      	#0x8060
0x008006:	b       	#0x801c
0x008008:	ldr     	r0, [pc, #0x1c]
0x00800a:	add     	r0, sb
0x00800c:	str     	r7, [r0, #0x1c]
0x00800e:	b       	#0x801c
0x008010:	ldr     	r0, [pc, #0x14]
0x008012:	add     	r0, sb
0x008014:	str     	r6, [r0, #0x20]
0x008016:	b       	#0x801c
0x008018:	ldr     	r4, [pc, #0x10]
0x00801a:	add     	r4, pc
0x00801c:	ldr     	r1, [sp]
0x00801e:	add     	sp, #0x14
0x008020:	adds    	r0, r4, #0
0x008022:	mov     	sb, r1
0x008024:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_008030 =====
0x008030:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x008032:	sub     	sp, #0xc
0x008034:	ldr     	r0, [sp, #0x38]
0x008036:	ldr     	r4, [sp, #0x3c]
0x008038:	ldr     	r6, [sp, #0x34]
0x00803a:	ldr     	r0, [r0]
0x00803c:	mov     	r7, sb
0x00803e:	movs    	r5, #0
0x008040:	blx     	#0x2e0
0x008044:	cmp     	r4, #0
0x008046:	beq     	#0x8056
0x008048:	ldr     	r1, [sp, #0x30]
0x00804a:	str     	r6, [sp, #4]
0x00804c:	add     	r3, sp, #0xc
0x00804e:	str     	r1, [sp]
0x008050:	ldm     	r3, {r0, r1, r2, r3}
0x008052:	blx     	r4
0x008054:	adds    	r5, r0, #0
0x008056:	mov     	sb, r7
0x008058:	adds    	r0, r5, #0
0x00805a:	add     	sp, #0x1c
0x00805c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0080c4 =====
0x0080c4:	push    	{r3, r4, r5, r6, r7, lr}
0x0080c6:	adds    	r4, r0, #0
0x0080c8:	ldr     	r0, [pc, #0x10c]
0x0080ca:	movs    	r5, #0
0x0080cc:	mvns    	r5, r5
0x0080ce:	mov     	ip, r2
0x0080d0:	add     	r0, pc
0x0080d2:	ldr     	r2, [r0, #0x38]
0x0080d4:	cmp     	r4, #0
0x0080d6:	bne     	#0x80e8
0x0080d8:	ldr     	r0, [pc, #0x100]
0x0080da:	ldr     	r2, [r2, #0x68]
0x0080dc:	movs    	r1, #0x7d
0x0080de:	lsls    	r1, r1, #3
0x0080e0:	add     	r0, pc
0x0080e2:	blx     	r2
0x0080e4:	adds    	r0, r5, #0
0x0080e6:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_0081f0 =====
0x0081f0:	push    	{r3, r4, r5, lr}
0x0081f2:	ldr     	r4, [pc, #0x28]
0x0081f4:	adds    	r5, r0, #0
0x0081f6:	add     	r4, pc
0x0081f8:	ldr     	r0, [r4, #0x38]
0x0081fa:	adds    	r0, #0x80
0x0081fc:	ldr     	r0, [r0, #4]
0x0081fe:	blx     	r0
0x008200:	adds    	r0, r0, r5
0x008202:	ldr     	r1, [pc, #0x1c]
0x008204:	add     	r1, sb
0x008206:	str     	r0, [r1, #0x10]
0x008208:	ldr     	r0, [r4, #0x38]
0x00820a:	adds    	r0, #0x80
0x00820c:	ldr     	r0, [r0]
0x00820e:	blx     	r0
0x008210:	ldr     	r0, [r4, #0x38]
0x008212:	ldr     	r1, [r0, #0x7c]
0x008214:	lsls    	r0, r5, #0x10
0x008216:	lsrs    	r0, r0, #0x10
0x008218:	blx     	r1
0x00821a:	pop     	{r3, r4, r5, pc}

; ===== candidate_008226 =====
0x008226:	push    	{r3, r4, r5, r6, r7, lr}
0x008228:	add     	r0, pc
0x00822a:	ldr     	r0, [r0, #0x38]
0x00822c:	adds    	r0, #0x80
0x00822e:	ldr     	r0, [r0, #4]
0x008230:	blx     	r0
0x008232:	movs    	r5, #0
0x008234:	ldr     	r6, [pc, #0xc8]
0x008236:	add     	r6, sb
0x008238:	ldr     	r1, [r6, #0x10]
0x00823a:	str     	r5, [r6, #0x10]
0x00823c:	subs    	r1, r0, r1
0x00823e:	ldr     	r0, [r6, #8]
0x008240:	adds    	r3, r1, #0
0x008242:	cmp     	r0, #0
0x008244:	beq     	#0x82fa
0x008246:	ldr     	r2, [r0, #8]
0x008248:	cmp     	r2, #0
0x00824a:	bne     	#0x82aa
0x00824c:	mvns    	r7, r2
0x00824e:	str     	r7, [r0, #8]
0x008250:	ldr     	r2, [r0, #0x18]
0x008252:	adds    	r4, r0, #0
0x008254:	cmp     	r1, #0x32
0x008256:	str     	r2, [r6, #8]
0x008258:	bge     	#0x825e
0x00825a:	movs    	r1, #0x32
0x00825c:	b       	#0x827a
0x00825e:	movs    	r2, #0x7d
0x008260:	lsls    	r2, r2, #4
0x008262:	cmp     	r1, r2
0x008264:	ble     	#0x827a
0x008266:	adds    	r1, r2, #0
0x008268:	b       	#0x827a
0x00826a:	movs    	r7, #0
0x00826c:	mvns    	r7, r7
0x00826e:	str     	r7, [r2, #8]
0x008270:	ldr     	r2, [r0, #0x18]
0x008272:	str     	r2, [r0, #0x1c]
0x008274:	ldr     	r0, [r2, #0x18]
0x008276:	str     	r0, [r6, #8]
0x008278:	adds    	r0, r2, #0
0x00827a:	ldr     	r2, [r0, #0x18]
0x00827c:	cmp     	r2, #0
0x00827e:	beq     	#0x8286
0x008280:	ldr     	r7, [r2, #8]
0x008282:	cmp     	r7, r1
0x008284:	blt     	#0x826a
0x008286:	str     	r5, [r0, #0x1c]
0x008288:	ldr     	r0, [r6, #8]
0x00828a:	cmp     	r0, #0
0x00828c:	beq     	#0x82ee
0x00828e:	cmp     	r3, #0
0x008290:	bge     	#0x8294
0x008292:	movs    	r3, #0
0x008294:	ldr     	r0, [r6, #8]
0x008296:	ldr     	r1, [r0, #8]
0x008298:	cmp     	r1, #0
0x00829a:	bge     	#0x82a0
0x00829c:	movs    	r1, #0
0x00829e:	str     	r5, [r0, #8]
0x0082a0:	ldr     	r2, [pc, #0x60]
0x0082a2:	cmp     	r1, r2
0x0082a4:	ble     	#0x82ae
0x0082a6:	adds    	r1, r2, #0
0x0082a8:	b       	#0x82ae
0x0082aa:	movs    	r4, #0
0x0082ac:	b       	#0x828e
0x0082ae:	ldr     	r2, [r0, #8]
0x0082b0:	subs    	r2, r2, r1
0x0082b2:	str     	r2, [r0, #8]
0x0082b4:	ldr     	r0, [r0, #0x18]
0x0082b6:	cmp     	r0, #0
0x0082b8:	bne     	#0x82ae
0x0082ba:	subs    	r0, r1, r3
0x0082bc:	cmp     	r0, #0
0x0082be:	bgt     	#0x82c2
0x0082c0:	movs    	r0, #0xa
0x0082c2:	bl      	#0x81f0
0x0082c6:	b       	#0x82ee
0x0082c8:	str     	r5, [r4, #8]
0x0082ca:	ldr     	r0, [r4, #0x1c]
0x0082cc:	adds    	r3, r5, #0
0x0082ce:	str     	r0, [r6, #0xc]
0x0082d0:	ldr     	r0, [r4, #0x14]
0x0082d2:	cmp     	r0, #0
0x0082d4:	beq     	#0x82e2
0x0082d6:	str     	r0, [sp]
0x0082d8:	movs    	r1, #0
0x0082da:	adds    	r0, r4, #0
0x0082dc:	ldr     	r2, [r4, #0x10]
0x0082de:	bl      	#0x80c4
0x0082e2:	ldr     	r1, [r4, #0xc]
0x0082e4:	cmp     	r1, #0
0x0082e6:	beq     	#0x82ec
0x0082e8:	ldr     	r0, [r4, #0x10]
0x0082ea:	blx     	r1
0x0082ec:	ldr     	r4, [r6, #0xc]
0x0082ee:	cmp     	r4, #0
0x0082f0:	beq     	#0x82f8
0x0082f2:	ldr     	r0, [r4, #8]
0x0082f4:	cmp     	r0, #0
0x0082f6:	blt     	#0x82c8
0x0082f8:	str     	r5, [r6, #0xc]
0x0082fa:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_008308 =====
0x008308:	push    	{r4, r5, r6, r7, lr}
0x00830a:	adds    	r5, r1, #0
0x00830c:	sub     	sp, #0x14
0x00830e:	movs    	r1, #0
0x008310:	str     	r1, [sp]
0x008312:	str     	r1, [sp, #4]
0x008314:	movs    	r2, #0
0x008316:	str     	r2, [sp, #8]
0x008318:	adds    	r4, r0, #0
0x00831a:	ldr     	r2, [r0, #8]
0x00831c:	movs    	r6, #0
0x00831e:	adds    	r3, r6, #0
0x008320:	movs    	r0, #0xf1
0x008322:	movs    	r1, #0x46
0x008324:	lsls    	r0, r0, #9
0x008326:	bl      	#0x7e90
0x00832a:	lsls    	r2, r0, #0x18
0x00832c:	asrs    	r2, r2, #0x18
0x00832e:	movs    	r1, #0
0x008330:	str     	r2, [sp, #0x10]
0x008332:	movs    	r2, #0
0x008334:	str     	r1, [sp]
0x008336:	str     	r1, [sp, #4]
0x008338:	movs    	r1, #0x45
0x00833a:	str     	r2, [sp, #8]
0x00833c:	movs    	r0, #0xf1
0x00833e:	adds    	r3, r6, #0
0x008340:	lsls    	r0, r0, #9
0x008342:	ldr     	r2, [r4, #8]
0x008344:	bl      	#0x7e90
0x008348:	movs    	r1, #0
0x00834a:	str     	r1, [sp]
0x00834c:	str     	r1, [sp, #4]
0x00834e:	str     	r0, [sp, #0xc]
0x008350:	movs    	r2, #0
0x008352:	str     	r2, [sp, #8]
0x008354:	movs    	r0, #0xf1
0x008356:	movs    	r1, #0x46
0x008358:	adds    	r3, r6, #0
0x00835a:	lsls    	r0, r0, #9
0x00835c:	ldr     	r2, [r4, #8]
0x00835e:	bl      	#0x7e90
0x008362:	movs    	r1, #0
0x008364:	str     	r1, [sp]
0x008366:	str     	r1, [sp, #4]
0x008368:	lsls    	r7, r0, #0x18
0x00836a:	movs    	r2, #0
0x00836c:	str     	r2, [sp, #8]
0x00836e:	asrs    	r7, r7, #0x18
0x008370:	movs    	r0, #0xf1
0x008372:	movs    	r1, #0x46
0x008374:	adds    	r3, r6, #0
0x008376:	lsls    	r0, r0, #9
0x008378:	ldr     	r2, [r4, #8]
0x00837a:	bl      	#0x7e90
0x00837e:	lsls    	r1, r0, #0x18
0x008380:	asrs    	r1, r1, #0x18
0x008382:	movs    	r0, #0
0x008384:	adds    	r3, r1, #1
0x008386:	beq     	#0x83a0
0x008388:	movs    	r1, #0
0x00838a:	movs    	r2, #0
0x00838c:	str     	r2, [sp, #8]
0x00838e:	str     	r1, [sp]
0x008390:	str     	r1, [sp, #4]
0x008392:	adds    	r3, r6, #0
0x008394:	adds    	r2, r4, #0
0x008396:	movs    	r1, #0x91
0x008398:	movs    	r0, #0xf1
0x00839a:	lsls    	r0, r0, #9
0x00839c:	bl      	#0x7e90
0x0083a0:	adds    	r1, r5, #0
0x0083a2:	ldr     	r2, [sp, #0x10]
0x0083a4:	adds    	r1, #0x20
0x0083a6:	strb    	r2, [r1, #1]
0x0083a8:	ldr     	r2, [sp, #0xc]
0x0083aa:	str     	r2, [r5, #0x24]
0x0083ac:	strb    	r7, [r1, #8]
0x0083ae:	str     	r0, [r5, #0x2c]
0x0083b0:	add     	sp, #0x14
0x0083b2:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0083b4 =====
0x0083b4:	push    	{r4, r5, r6, r7, lr}
0x0083b6:	sub     	sp, #0xc
0x0083b8:	adds    	r7, r1, #0
0x0083ba:	movs    	r1, #0
0x0083bc:	str     	r1, [sp]
0x0083be:	str     	r1, [sp, #4]
0x0083c0:	movs    	r2, #0
0x0083c2:	str     	r2, [sp, #8]
0x0083c4:	movs    	r4, #0xf1
0x0083c6:	movs    	r5, #0
0x0083c8:	adds    	r3, r5, #0
0x0083ca:	lsls    	r4, r4, #9
0x0083cc:	ldr     	r2, [r0, #8]
0x0083ce:	movs    	r1, #0x46
0x0083d0:	adds    	r6, r0, #0
0x0083d2:	adds    	r0, r4, #0
0x0083d4:	bl      	#0x7e90
0x0083d8:	adds    	r1, r7, #0
0x0083da:	adds    	r1, #0x40
0x0083dc:	strb    	r0, [r1]
0x0083de:	ldrb    	r0, [r1]
0x0083e0:	cmp     	r0, #1
0x0083e2:	bne     	#0x843e
0x0083e4:	movs    	r1, #0
0x0083e6:	str     	r1, [sp]
0x0083e8:	str     	r1, [sp, #4]
0x0083ea:	movs    	r2, #0
0x0083ec:	str     	r2, [sp, #8]
0x0083ee:	movs    	r1, #0x46
0x0083f0:	movs    	r3, #0
0x0083f2:	adds    	r0, r4, #0
0x0083f4:	ldr     	r2, [r6, #8]
0x0083f6:	bl      	#0x7e90
0x0083fa:	adds    	r5, r0, #0
0x0083fc:	cmp     	r0, #0
0x0083fe:	ble     	#0x843e
0x008400:	movs    	r1, #0
0x008402:	movs    	r2, #0
0x008404:	str     	r2, [sp, #8]
0x008406:	str     	r1, [sp]
0x008408:	str     	r1, [sp, #4]
0x00840a:	movs    	r1, #0xa
0x00840c:	adds    	r2, r5, #0
0x00840e:	movs    	r4, #0
0x008410:	movs    	r3, #1
0x008412:	movs    	r0, #0xf1
0x008414:	lsls    	r0, r0, #9
0x008416:	bl      	#0x7e90
0x00841a:	str     	r0, [r7, #0x68]
0x00841c:	movs    	r1, #0
0x00841e:	str     	r1, [sp]
0x008420:	str     	r1, [sp, #4]
0x008422:	movs    	r2, #0
0x008424:	str     	r2, [sp, #8]
0x008426:	movs    	r1, #0x46
0x008428:	movs    	r3, #0
0x00842a:	movs    	r0, #0xf1
0x00842c:	lsls    	r0, r0, #9
0x00842e:	ldr     	r2, [r6, #8]
0x008430:	bl      	#0x7e90
0x008434:	ldr     	r1, [r7, #0x68]
0x008436:	strb    	r0, [r1, r4]
0x008438:	adds    	r4, #1
0x00843a:	cmp     	r4, r5
0x00843c:	blt     	#0x841c
0x00843e:	add     	sp, #0xc
0x008440:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_008444 =====
0x008444:	push    	{r4, r5, r6, r7, lr}
0x008446:	adds    	r5, r1, #0
0x008448:	sub     	sp, #0x14
0x00844a:	movs    	r1, #0
0x00844c:	str     	r1, [sp]
0x00844e:	str     	r1, [sp, #4]
0x008450:	movs    	r2, #0
0x008452:	str     	r2, [sp, #8]
0x008454:	adds    	r6, r0, #0
0x008456:	ldr     	r2, [r0, #8]
0x008458:	movs    	r4, #0
0x00845a:	adds    	r3, r4, #0
0x00845c:	movs    	r0, #0xf1
0x00845e:	movs    	r1, #0x46
0x008460:	lsls    	r0, r0, #9
0x008462:	bl      	#0x7e90
0x008466:	lsls    	r0, r0, #0x18
0x008468:	movs    	r1, #0
0x00846a:	asrs    	r0, r0, #0x18
0x00846c:	str     	r0, [sp, #0x10]
0x00846e:	str     	r1, [sp]
0x008470:	str     	r1, [sp, #4]
0x008472:	movs    	r2, #0
0x008474:	str     	r2, [sp, #8]
0x008476:	movs    	r1, #0x46
0x008478:	movs    	r0, #0xf1
0x00847a:	adds    	r3, r4, #0
0x00847c:	lsls    	r0, r0, #9
0x00847e:	ldr     	r2, [r6, #8]
0x008480:	bl      	#0x7e90
0x008484:	lsls    	r7, r0, #0x18
0x008486:	ldr     	r0, [sp, #0x10]
0x008488:	movs    	r1, #0
0x00848a:	str     	r0, [r5, #0xc]
0x00848c:	movs    	r2, #0
0x00848e:	str     	r2, [sp, #8]
0x008490:	str     	r1, [sp]
0x008492:	str     	r1, [sp, #4]
0x008494:	asrs    	r7, r7, #0x18
0x008496:	adds    	r2, r7, #0
0x008498:	movs    	r1, #0xa
0x00849a:	movs    	r0, #0xf1
0x00849c:	movs    	r3, #1
0x00849e:	lsls    	r0, r0, #9
0x0084a0:	bl      	#0x7e90
0x0084a4:	str     	r0, [r5, #0x38]
0x0084a6:	movs    	r1, #0
0x0084a8:	movs    	r2, #0
0x0084aa:	str     	r2, [sp, #8]
0x0084ac:	str     	r1, [sp]
0x0084ae:	str     	r1, [sp, #4]
0x0084b0:	movs    	r1, #0xa
0x0084b2:	adds    	r2, r7, #0
0x0084b4:	movs    	r0, #0xf1
0x0084b6:	movs    	r3, #4
0x0084b8:	lsls    	r0, r0, #9
0x0084ba:	bl      	#0x7e90
0x0084be:	str     	r0, [r5, #0x3c]
0x0084c0:	cmp     	r7, #0
0x0084c2:	ble     	#0x8504
0x0084c4:	movs    	r1, #0
0x0084c6:	str     	r1, [sp]
0x0084c8:	str     	r1, [sp, #4]
0x0084ca:	movs    	r2, #0
0x0084cc:	str     	r2, [sp, #8]
0x0084ce:	movs    	r1, #0x46
0x0084d0:	movs    	r3, #0
0x0084d2:	movs    	r0, #0xf1
0x0084d4:	lsls    	r0, r0, #9
0x0084d6:	ldr     	r2, [r6, #8]
0x0084d8:	bl      	#0x7e90
0x0084dc:	ldr     	r1, [r5, #0x38]
0x0084de:	movs    	r2, #0
0x0084e0:	strb    	r0, [r1, r4]
0x0084e2:	movs    	r1, #0
0x0084e4:	str     	r1, [sp]
0x0084e6:	str     	r1, [sp, #4]
0x0084e8:	str     	r2, [sp, #8]
0x0084ea:	adds    	r2, r6, #0
0x0084ec:	movs    	r1, #0x79
0x0084ee:	movs    	r0, #0xf1
0x0084f0:	movs    	r3, #0
0x0084f2:	lsls    	r0, r0, #9
0x0084f4:	bl      	#0x7e90
0x0084f8:	lsls    	r2, r4, #2
0x0084fa:	ldr     	r1, [r5, #0x3c]
0x0084fc:	adds    	r4, #1
0x0084fe:	cmp     	r4, r7
0x008500:	str     	r0, [r1, r2]
0x008502:	blt     	#0x84c4
0x008504:	add     	sp, #0x14
0x008506:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_008508 =====
0x008508:	push    	{r4, r5, r6, r7, lr}
0x00850a:	adds    	r5, r1, #0
0x00850c:	sub     	sp, #0x14
0x00850e:	movs    	r1, #0
0x008510:	str     	r1, [sp]
0x008512:	str     	r1, [sp, #4]
0x008514:	movs    	r2, #0
0x008516:	str     	r2, [sp, #8]
0x008518:	adds    	r4, r0, #0
0x00851a:	ldr     	r2, [r0, #8]
0x00851c:	movs    	r6, #0
0x00851e:	adds    	r3, r6, #0
0x008520:	movs    	r0, #0xf1
0x008522:	movs    	r1, #0x45
0x008524:	lsls    	r0, r0, #9
0x008526:	bl      	#0x7e90
0x00852a:	movs    	r1, #0
0x00852c:	str     	r1, [sp]
0x00852e:	str     	r1, [sp, #4]
0x008530:	str     	r0, [sp, #0x10]
0x008532:	movs    	r2, #0
0x008534:	str     	r2, [sp, #8]
0x008536:	movs    	r0, #0xf1
0x008538:	movs    	r1, #0x47
0x00853a:	adds    	r3, r6, #0
0x00853c:	lsls    	r0, r0, #9
0x00853e:	ldr     	r2, [r4, #8]
0x008540:	bl      	#0x7e90
0x008544:	movs    	r1, #0
0x008546:	str     	r1, [sp]
0x008548:	str     	r1, [sp, #4]
0x00854a:	adds    	r7, r0, #0
0x00854c:	movs    	r2, #0
0x00854e:	str     	r2, [sp, #8]
0x008550:	movs    	r0, #0xf1
0x008552:	adds    	r3, r6, #0
0x008554:	movs    	r1, #0x46
0x008556:	lsls    	r0, r0, #9
0x008558:	ldr     	r2, [r4, #8]
0x00855a:	bl      	#0x7e90
0x00855e:	ldr     	r1, [sp, #0x10]
0x008560:	str     	r1, [r5, #0x48]
0x008562:	str     	r7, [r5, #0x44]
0x008564:	adds    	r5, #0x40
0x008566:	strb    	r0, [r5, #0xc]
0x008568:	add     	sp, #0x14
0x00856a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00856c =====
0x00856c:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x00856e:	sub     	sp, #0x2c
0x008570:	movs    	r1, #0
0x008572:	str     	r1, [sp]
0x008574:	str     	r1, [sp, #4]
0x008576:	movs    	r2, #0
0x008578:	str     	r2, [sp, #8]
0x00857a:	movs    	r6, #0xf1
0x00857c:	lsls    	r6, r6, #9
0x00857e:	ldr     	r2, [r0, #8]
0x008580:	movs    	r1, #0x46
0x008582:	movs    	r5, #0
0x008584:	adds    	r4, r0, #0
0x008586:	movs    	r3, #0
0x008588:	adds    	r0, r6, #0
0x00858a:	bl      	#0x7e90
0x00858e:	movs    	r1, #0
0x008590:	movs    	r2, #0
0x008592:	str     	r2, [sp, #8]
0x008594:	str     	r1, [sp]
0x008596:	str     	r1, [sp, #4]
0x008598:	movs    	r1, #0xa
0x00859a:	adds    	r2, r0, #0
0x00859c:	adds    	r7, r0, #0
0x00859e:	movs    	r3, #4
0x0085a0:	adds    	r0, r6, #0
0x0085a2:	bl      	#0x7e90
0x0085a6:	str     	r0, [sp, #0x28]
0x0085a8:	cmp     	r7, #0
0x0085aa:	ble     	#0x8692
0x0085ac:	movs    	r6, #0
0x0085ae:	movs    	r1, #0
0x0085b0:	str     	r1, [sp]
0x0085b2:	str     	r1, [sp, #4]
0x0085b4:	movs    	r2, #0
0x0085b6:	str     	r2, [sp, #8]
0x0085b8:	movs    	r1, #0x46
0x0085ba:	adds    	r3, r6, #0
0x0085bc:	movs    	r0, #0xf1
0x0085be:	lsls    	r0, r0, #9
0x0085c0:	ldr     	r2, [r4, #8]
0x0085c2:	bl      	#0x7e90
0x0085c6:	str     	r0, [sp, #0x24]
0x0085c8:	movs    	r1, #0
0x0085ca:	str     	r1, [sp]
0x0085cc:	str     	r1, [sp, #4]
0x0085ce:	movs    	r2, #0
0x0085d0:	str     	r2, [sp, #8]
0x0085d2:	movs    	r1, #0x46
0x0085d4:	movs    	r0, #0xf1
0x0085d6:	adds    	r3, r6, #0
0x0085d8:	lsls    	r0, r0, #9
0x0085da:	ldr     	r2, [r4, #8]
0x0085dc:	bl      	#0x7e90
0x0085e0:	str     	r0, [sp, #0x20]
0x0085e2:	movs    	r1, #0
0x0085e4:	str     	r1, [sp]
0x0085e6:	str     	r1, [sp, #4]
0x0085e8:	movs    	r2, #0
0x0085ea:	str     	r2, [sp, #8]
0x0085ec:	movs    	r1, #0x46
0x0085ee:	movs    	r0, #0xf1
0x0085f0:	adds    	r3, r6, #0
0x0085f2:	lsls    	r0, r0, #9
0x0085f4:	ldr     	r2, [r4, #8]
0x0085f6:	bl      	#0x7e90
0x0085fa:	movs    	r1, #0
0x0085fc:	str     	r1, [sp]
0x0085fe:	str     	r1, [sp, #4]
0x008600:	str     	r0, [sp, #0x1c]
0x008602:	movs    	r2, #0
0x008604:	str     	r2, [sp, #8]
0x008606:	movs    	r0, #0xf1
0x008608:	movs    	r1, #0x45
0x00860a:	adds    	r3, r6, #0
0x00860c:	lsls    	r0, r0, #9
0x00860e:	ldr     	r2, [r4, #8]
0x008610:	bl      	#0x7e90
0x008614:	movs    	r1, #0
0x008616:	str     	r1, [sp]
0x008618:	str     	r1, [sp, #4]
0x00861a:	str     	r0, [sp, #0x18]
0x00861c:	movs    	r2, #0
0x00861e:	str     	r2, [sp, #8]
0x008620:	movs    	r0, #0xf1
0x008622:	movs    	r1, #0x46
0x008624:	adds    	r3, r6, #0
0x008626:	lsls    	r0, r0, #9
0x008628:	ldr     	r2, [r4, #8]
0x00862a:	bl      	#0x7e90
0x00862e:	movs    	r1, #0
0x008630:	str     	r1, [sp]
0x008632:	str     	r1, [sp, #4]
0x008634:	str     	r0, [sp, #0x14]
0x008636:	movs    	r2, #0
0x008638:	str     	r2, [sp, #8]
0x00863a:	movs    	r0, #0xf1
0x00863c:	movs    	r1, #0x46
0x00863e:	adds    	r3, r6, #0
0x008640:	lsls    	r0, r0, #9
0x008642:	ldr     	r2, [r4, #8]
0x008644:	bl      	#0x7e90
0x008648:	movs    	r1, #0
0x00864a:	str     	r1, [sp]
0x00864c:	str     	r1, [sp, #4]
0x00864e:	str     	r0, [sp, #0x10]
0x008650:	movs    	r2, #0
0x008652:	str     	r2, [sp, #8]
0x008654:	movs    	r0, #0xf1
0x008656:	movs    	r1, #0x46
0x008658:	adds    	r3, r6, #0
0x00865a:	lsls    	r0, r0, #9
0x00865c:	ldr     	r2, [r4, #8]
0x00865e:	bl      	#0x7e90
0x008662:	movs    	r1, #0
0x008664:	movs    	r2, #0
0x008666:	str     	r2, [sp, #8]
0x008668:	str     	r1, [sp]
0x00866a:	str     	r1, [sp, #4]
0x00866c:	str     	r0, [sp, #0xc]
0x00866e:	movs    	r0, #0xf1
0x008670:	movs    	r1, #0xf
0x008672:	movs    	r2, #0x14
0x008674:	adds    	r3, r6, #0
0x008676:	lsls    	r0, r0, #9
0x008678:	bl      	#0x7e90
0x00867c:	ldr     	r1, [sp, #0x24]
0x00867e:	strb    	r1, [r0, #4]
0x008680:	ldr     	r1, [sp, #0x20]
0x008682:	strb    	r1, [r0, #5]
0x008684:	ldr     	r1, [sp, #0x1c]
0x008686:	strb    	r1, [r0, #6]
0x008688:	ldr     	r1, [sp, #0x18]
0x00868a:	str     	r1, [r0, #8]
0x00868c:	ldr     	r1, [sp, #0x14]
0x00868e:	strb    	r1, [r0, #0xc]
0x008690:	b       	#0x8694
0x008692:	b       	#0x86a8
0x008694:	ldr     	r1, [sp, #0x10]
0x008696:	strb    	r1, [r0, #0xd]
0x008698:	ldr     	r1, [sp, #0xc]

; ===== candidate_0086b4 =====
0x0086b4:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x0086b6:	sub     	sp, #0x1c
0x0086b8:	movs    	r1, #0
0x0086ba:	str     	r1, [sp]
0x0086bc:	str     	r1, [sp, #4]
0x0086be:	movs    	r2, #0
0x0086c0:	str     	r2, [sp, #8]
0x0086c2:	movs    	r7, #0xf1
0x0086c4:	lsls    	r7, r7, #9
0x0086c6:	ldr     	r2, [r0, #8]
0x0086c8:	movs    	r1, #0x46
0x0086ca:	adds    	r5, r0, #0
0x0086cc:	movs    	r4, #0
0x0086ce:	movs    	r3, #0
0x0086d0:	adds    	r0, r7, #0
0x0086d2:	bl      	#0x7e90
0x0086d6:	movs    	r1, #0
0x0086d8:	movs    	r2, #0
0x0086da:	str     	r2, [sp, #8]
0x0086dc:	str     	r1, [sp]
0x0086de:	str     	r1, [sp, #4]
0x0086e0:	movs    	r1, #0xa
0x0086e2:	adds    	r2, r0, #0
0x0086e4:	adds    	r6, r0, #0
0x0086e6:	movs    	r3, #4
0x0086e8:	adds    	r0, r7, #0
0x0086ea:	bl      	#0x7e90
0x0086ee:	str     	r0, [sp, #0x18]
0x0086f0:	cmp     	r6, #0
0x0086f2:	ble     	#0x8774
0x0086f4:	movs    	r7, #0
0x0086f6:	movs    	r1, #0
0x0086f8:	str     	r1, [sp]
0x0086fa:	str     	r1, [sp, #4]
0x0086fc:	movs    	r2, #0
0x0086fe:	str     	r2, [sp, #8]
0x008700:	movs    	r1, #0x46
0x008702:	adds    	r3, r7, #0
0x008704:	movs    	r0, #0xf1
0x008706:	lsls    	r0, r0, #9
0x008708:	ldr     	r2, [r5, #8]
0x00870a:	bl      	#0x7e90
0x00870e:	movs    	r1, #0
0x008710:	str     	r1, [sp]
0x008712:	str     	r1, [sp, #4]
0x008714:	str     	r0, [sp, #0x14]
0x008716:	movs    	r2, #0
0x008718:	str     	r2, [sp, #8]
0x00871a:	movs    	r0, #0xf1
0x00871c:	movs    	r1, #0x46
0x00871e:	adds    	r3, r7, #0
0x008720:	lsls    	r0, r0, #9
0x008722:	ldr     	r2, [r5, #8]
0x008724:	bl      	#0x7e90
0x008728:	movs    	r1, #0
0x00872a:	str     	r1, [sp]
0x00872c:	str     	r1, [sp, #4]
0x00872e:	str     	r0, [sp, #0x10]
0x008730:	movs    	r2, #0
0x008732:	str     	r2, [sp, #8]
0x008734:	movs    	r0, #0xf1
0x008736:	movs    	r1, #0x45
0x008738:	adds    	r3, r7, #0
0x00873a:	lsls    	r0, r0, #9
0x00873c:	ldr     	r2, [r5, #8]
0x00873e:	bl      	#0x7e90
0x008742:	movs    	r1, #0
0x008744:	movs    	r2, #0
0x008746:	str     	r2, [sp, #8]
0x008748:	str     	r1, [sp]
0x00874a:	str     	r1, [sp, #4]
0x00874c:	str     	r0, [sp, #0xc]
0x00874e:	movs    	r0, #0xf1
0x008750:	movs    	r1, #0xf
0x008752:	movs    	r2, #0xc
0x008754:	adds    	r3, r7, #0
0x008756:	lsls    	r0, r0, #9
0x008758:	bl      	#0x7e90
0x00875c:	ldr     	r1, [sp, #0x14]
0x00875e:	strb    	r1, [r0]
0x008760:	ldr     	r1, [sp, #0x10]
0x008762:	strb    	r1, [r0, #1]
0x008764:	ldr     	r1, [sp, #0xc]
0x008766:	str     	r1, [r0, #4]
0x008768:	lsls    	r1, r4, #2
0x00876a:	ldr     	r2, [sp, #0x18]
0x00876c:	adds    	r4, #1
0x00876e:	cmp     	r4, r6
0x008770:	str     	r0, [r2, r1]
0x008772:	blt     	#0x86f6
0x008774:	ldr     	r0, [sp, #0x18]
0x008776:	ldr     	r1, [sp, #0x20]
0x008778:	str     	r0, [r1, #0x58]
0x00877a:	add     	sp, #0x24
0x00877c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_008780 =====
0x008780:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x008782:	sub     	sp, #0x1c
0x008784:	movs    	r1, #0
0x008786:	str     	r1, [sp]
0x008788:	str     	r1, [sp, #4]
0x00878a:	movs    	r2, #0
0x00878c:	str     	r2, [sp, #8]
0x00878e:	movs    	r7, #0xf1
0x008790:	lsls    	r7, r7, #9
0x008792:	ldr     	r2, [r0, #8]
0x008794:	movs    	r1, #0x46
0x008796:	adds    	r5, r0, #0
0x008798:	movs    	r4, #0
0x00879a:	movs    	r3, #0
0x00879c:	adds    	r0, r7, #0
0x00879e:	bl      	#0x7e90
0x0087a2:	movs    	r1, #0
0x0087a4:	movs    	r2, #0
0x0087a6:	str     	r2, [sp, #8]
0x0087a8:	str     	r1, [sp]
0x0087aa:	str     	r1, [sp, #4]
0x0087ac:	movs    	r1, #0xa
0x0087ae:	adds    	r2, r0, #0
0x0087b0:	adds    	r6, r0, #0
0x0087b2:	movs    	r3, #4
0x0087b4:	adds    	r0, r7, #0
0x0087b6:	bl      	#0x7e90
0x0087ba:	str     	r0, [sp, #0x18]
0x0087bc:	cmp     	r6, #0
0x0087be:	ble     	#0x8840
0x0087c0:	movs    	r7, #0
0x0087c2:	movs    	r1, #0
0x0087c4:	str     	r1, [sp]
0x0087c6:	str     	r1, [sp, #4]
0x0087c8:	movs    	r2, #0
0x0087ca:	str     	r2, [sp, #8]
0x0087cc:	movs    	r1, #0x46
0x0087ce:	adds    	r3, r7, #0
0x0087d0:	movs    	r0, #0xf1
0x0087d2:	lsls    	r0, r0, #9
0x0087d4:	ldr     	r2, [r5, #8]
0x0087d6:	bl      	#0x7e90
0x0087da:	movs    	r1, #0
0x0087dc:	str     	r1, [sp]
0x0087de:	str     	r1, [sp, #4]
0x0087e0:	str     	r0, [sp, #0x14]
0x0087e2:	movs    	r2, #0
0x0087e4:	str     	r2, [sp, #8]
0x0087e6:	movs    	r0, #0xf1
0x0087e8:	movs    	r1, #0x46
0x0087ea:	adds    	r3, r7, #0
0x0087ec:	lsls    	r0, r0, #9
0x0087ee:	ldr     	r2, [r5, #8]
0x0087f0:	bl      	#0x7e90
0x0087f4:	movs    	r1, #0
0x0087f6:	str     	r1, [sp]
0x0087f8:	str     	r1, [sp, #4]
0x0087fa:	str     	r0, [sp, #0x10]
0x0087fc:	movs    	r2, #0
0x0087fe:	str     	r2, [sp, #8]
0x008800:	movs    	r0, #0xf1
0x008802:	movs    	r1, #0x46
0x008804:	adds    	r3, r7, #0
0x008806:	lsls    	r0, r0, #9
0x008808:	ldr     	r2, [r5, #8]
0x00880a:	bl      	#0x7e90
0x00880e:	movs    	r1, #0
0x008810:	movs    	r2, #0
0x008812:	str     	r2, [sp, #8]
0x008814:	str     	r1, [sp]
0x008816:	str     	r1, [sp, #4]
0x008818:	str     	r0, [sp, #0xc]
0x00881a:	movs    	r0, #0xf1
0x00881c:	movs    	r1, #0xf
0x00881e:	movs    	r2, #8
0x008820:	adds    	r3, r7, #0
0x008822:	lsls    	r0, r0, #9
0x008824:	bl      	#0x7e90
0x008828:	ldr     	r1, [sp, #0x14]
0x00882a:	strb    	r1, [r0]
0x00882c:	ldr     	r1, [sp, #0x10]
0x00882e:	strb    	r1, [r0, #1]
0x008830:	ldr     	r1, [sp, #0xc]
0x008832:	strb    	r1, [r0, #2]
0x008834:	lsls    	r1, r4, #2
0x008836:	ldr     	r2, [sp, #0x18]
0x008838:	adds    	r4, #1
0x00883a:	cmp     	r4, r6
0x00883c:	str     	r0, [r2, r1]
0x00883e:	blt     	#0x87c2
0x008840:	ldr     	r0, [sp, #0x18]
0x008842:	ldr     	r1, [sp, #0x20]
0x008844:	str     	r0, [r1, #0x5c]
0x008846:	add     	sp, #0x24
0x008848:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00884c =====
0x00884c:	push    	{r4, r5, r6, r7, lr}
0x00884e:	adds    	r5, r1, #0
0x008850:	sub     	sp, #0x14
0x008852:	movs    	r1, #0
0x008854:	str     	r1, [sp]
0x008856:	str     	r1, [sp, #4]
0x008858:	movs    	r2, #0
0x00885a:	str     	r2, [sp, #8]
0x00885c:	adds    	r4, r0, #0
0x00885e:	ldr     	r2, [r0, #8]
0x008860:	movs    	r6, #0
0x008862:	adds    	r3, r6, #0
0x008864:	movs    	r0, #0xf1
0x008866:	movs    	r1, #0x46
0x008868:	lsls    	r0, r0, #9
0x00886a:	bl      	#0x7e90
0x00886e:	lsls    	r1, r0, #0x18
0x008870:	asrs    	r1, r1, #0x18
0x008872:	str     	r1, [sp, #0x10]
0x008874:	movs    	r1, #0
0x008876:	str     	r1, [sp]
0x008878:	str     	r1, [sp, #4]
0x00887a:	movs    	r2, #0
0x00887c:	str     	r2, [sp, #8]
0x00887e:	movs    	r1, #0x46
0x008880:	movs    	r0, #0xf1
0x008882:	adds    	r3, r6, #0
0x008884:	lsls    	r0, r0, #9
0x008886:	ldr     	r2, [r4, #8]
0x008888:	bl      	#0x7e90
0x00888c:	movs    	r1, #0
0x00888e:	lsls    	r7, r0, #0x18
0x008890:	movs    	r2, #0
0x008892:	str     	r2, [sp, #8]
0x008894:	str     	r1, [sp]
0x008896:	str     	r1, [sp, #4]
0x008898:	adds    	r3, r6, #0
0x00889a:	adds    	r2, r4, #0
0x00889c:	movs    	r1, #0x79
0x00889e:	asrs    	r7, r7, #0x18
0x0088a0:	movs    	r0, #0xf1
0x0088a2:	lsls    	r0, r0, #9
0x0088a4:	bl      	#0x7e90
0x0088a8:	ldr     	r1, [sp, #0x10]
0x0088aa:	str     	r0, [r5, #0x14]
0x0088ac:	str     	r1, [r5, #0xc]
0x0088ae:	str     	r7, [r5, #0x10]
0x0088b0:	add     	sp, #0x14
0x0088b2:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0088b4 =====
0x0088b4:	push    	{r4, r5, r6, lr}
0x0088b6:	adds    	r5, r1, #0
0x0088b8:	sub     	sp, #0x10
0x0088ba:	movs    	r1, #0
0x0088bc:	str     	r1, [sp]
0x0088be:	str     	r1, [sp, #4]
0x0088c0:	movs    	r2, #0
0x0088c2:	str     	r2, [sp, #8]
0x0088c4:	adds    	r4, r0, #0
0x0088c6:	ldr     	r2, [r0, #8]
0x0088c8:	movs    	r6, #0
0x0088ca:	adds    	r3, r6, #0
0x0088cc:	movs    	r0, #0xf1
0x0088ce:	movs    	r1, #0x46
0x0088d0:	lsls    	r0, r0, #9
0x0088d2:	bl      	#0x7e90
0x0088d6:	adds    	r5, #0x30
0x0088d8:	strb    	r0, [r5, #4]
0x0088da:	movs    	r1, #0
0x0088dc:	str     	r1, [sp]
0x0088de:	str     	r1, [sp, #4]
0x0088e0:	movs    	r2, #0
0x0088e2:	str     	r2, [sp, #8]
0x0088e4:	movs    	r1, #0x46
0x0088e6:	movs    	r0, #0xf1
0x0088e8:	adds    	r3, r6, #0
0x0088ea:	lsls    	r0, r0, #9
0x0088ec:	ldr     	r2, [r4, #8]
0x0088ee:	bl      	#0x7e90
0x0088f2:	strb    	r0, [r5, #5]
0x0088f4:	movs    	r1, #0
0x0088f6:	str     	r1, [sp]
0x0088f8:	str     	r1, [sp, #4]
0x0088fa:	movs    	r2, #0
0x0088fc:	str     	r2, [sp, #8]
0x0088fe:	movs    	r1, #0x46
0x008900:	movs    	r0, #0xf1
0x008902:	adds    	r3, r6, #0
0x008904:	lsls    	r0, r0, #9
0x008906:	ldr     	r2, [r4, #8]
0x008908:	bl      	#0x7e90
0x00890c:	strb    	r0, [r5, #6]
0x00890e:	add     	sp, #0x10
0x008910:	pop     	{r4, r5, r6, pc}

; ===== candidate_008914 =====
0x008914:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x008916:	sub     	sp, #0x14
0x008918:	adds    	r7, r0, #0
0x00891a:	ldr     	r0, [sp, #0x18]
0x00891c:	ldr     	r0, [r0, #4]
0x00891e:	bl      	#0x62ac
0x008922:	movs    	r1, #0
0x008924:	str     	r1, [sp]
0x008926:	str     	r1, [sp, #4]
0x008928:	str     	r0, [sp, #0x10]
0x00892a:	movs    	r2, #0
0x00892c:	str     	r2, [sp, #8]
0x00892e:	movs    	r0, #0xf1
0x008930:	movs    	r1, #0x45
0x008932:	movs    	r4, #0
0x008934:	movs    	r3, #0
0x008936:	lsls    	r0, r0, #9
0x008938:	ldr     	r2, [r7, #8]
0x00893a:	bl      	#0x7e90
0x00893e:	movs    	r2, #0
0x008940:	movs    	r1, #0
0x008942:	str     	r2, [sp, #8]
0x008944:	adds    	r6, r0, #0
0x008946:	adds    	r2, r0, #0
0x008948:	str     	r1, [sp]
0x00894a:	str     	r1, [sp, #4]
0x00894c:	movs    	r1, #0xa
0x00894e:	movs    	r0, #0xf1
0x008950:	movs    	r3, #4
0x008952:	lsls    	r0, r0, #9
0x008954:	bl      	#0x7e90
0x008958:	adds    	r5, r0, #0
0x00895a:	cmp     	r6, #0
0x00895c:	ble     	#0x8980
0x00895e:	movs    	r1, #0
0x008960:	str     	r1, [sp]
0x008962:	str     	r1, [sp, #4]
0x008964:	movs    	r2, #0
0x008966:	str     	r2, [sp, #8]
0x008968:	movs    	r1, #0x45
0x00896a:	movs    	r3, #0
0x00896c:	movs    	r0, #0xf1
0x00896e:	lsls    	r0, r0, #9
0x008970:	ldr     	r2, [r7, #8]
0x008972:	bl      	#0x7e90
0x008976:	lsls    	r1, r4, #2
0x008978:	adds    	r4, #1
0x00897a:	cmp     	r4, r6
0x00897c:	str     	r0, [r5, r1]
0x00897e:	blt     	#0x895e
0x008980:	ldr     	r1, [pc, #0x58]
0x008982:	ldr     	r0, [sp, #0x10]
0x008984:	add     	r1, sb
0x008986:	ldr     	r1, [r1, #0x50]
0x008988:	cmp     	r0, r1
0x00898a:	bne     	#0x89c2
0x00898c:	ldr     	r0, [sp, #0x18]
0x00898e:	ldr     	r0, [r0, #8]
0x008990:	ldr     	r1, [sp, #0x10]
0x008992:	ldr     	r1, [r1, #0x10]
0x008994:	cmp     	r0, r1
0x008996:	bne     	#0x89c2
0x008998:	ldr     	r4, [pc, #0x40]
0x00899a:	add     	r4, sb
0x00899c:	subs    	r4, #0x80
0x00899e:	ldr     	r6, [r4, #0x28]
0x0089a0:	cmp     	r6, #0
0x0089a2:	beq     	#0x89bc
0x0089a4:	movs    	r1, #0
0x0089a6:	movs    	r2, #0
0x0089a8:	str     	r2, [sp, #8]
0x0089aa:	str     	r1, [sp]
0x0089ac:	str     	r1, [sp, #4]
0x0089ae:	movs    	r1, #9
0x0089b0:	adds    	r2, r6, #0
0x0089b2:	movs    	r3, #0
0x0089b4:	movs    	r0, #0xf1
0x0089b6:	lsls    	r0, r0, #9
0x0089b8:	bl      	#0x7e90
0x0089bc:	str     	r5, [r4, #0x28]
0x0089be:	add     	sp, #0x1c
0x0089c0:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0089e0 =====
0x0089e0:	push    	{r4, r5, r6, lr}
0x0089e2:	adds    	r5, r0, #0
0x0089e4:	ldr     	r0, [r1, #4]
0x0089e6:	adds    	r2, r1, #0
0x0089e8:	sub     	sp, #0x10
0x0089ea:	bl      	#0x62ac
0x0089ee:	ldr     	r1, [r2, #8]
0x0089f0:	ldr     	r0, [r0, #4]
0x0089f2:	lsls    	r1, r1, #2
0x0089f4:	ldr     	r4, [r0, r1]
0x0089f6:	movs    	r1, #0
0x0089f8:	str     	r1, [sp]
0x0089fa:	str     	r1, [sp, #4]
0x0089fc:	movs    	r2, #0
0x0089fe:	movs    	r6, #0xf1
0x008a00:	lsls    	r6, r6, #9
0x008a02:	str     	r2, [sp, #8]
0x008a04:	movs    	r1, #0x45
0x008a06:	movs    	r3, #0
0x008a08:	adds    	r0, r6, #0
0x008a0a:	ldr     	r2, [r5, #8]
0x008a0c:	bl      	#0x7e90
0x008a10:	movs    	r1, #0
0x008a12:	movs    	r2, #0
0x008a14:	str     	r2, [sp, #8]
0x008a16:	str     	r1, [sp]
0x008a18:	str     	r1, [sp, #4]
0x008a1a:	movs    	r1, #0x92
0x008a1c:	adds    	r2, r4, #0
0x008a1e:	adds    	r3, r0, #0
0x008a20:	adds    	r0, r6, #0
0x008a22:	bl      	#0x7e90
0x008a26:	adds    	r4, r0, #0
0x008a28:	beq     	#0x8a4c
0x008a2a:	movs    	r1, #0
0x008a2c:	movs    	r2, #0
0x008a2e:	str     	r2, [sp, #8]
0x008a30:	str     	r1, [sp]
0x008a32:	str     	r1, [sp, #4]
0x008a34:	movs    	r1, #0x91
0x008a36:	adds    	r2, r5, #0
0x008a38:	adds    	r3, r4, #0
0x008a3a:	adds    	r0, r6, #0
0x008a3c:	bl      	#0x7e90
0x008a40:	adds    	r4, #0x30
0x008a42:	ldrb    	r0, [r4, #3]
0x008a44:	cmp     	r0, #0
0x008a46:	bne     	#0x8a4c
0x008a48:	movs    	r0, #1
0x008a4a:	strb    	r0, [r4, #3]
0x008a4c:	add     	sp, #0x10
0x008a4e:	pop     	{r4, r5, r6, pc}

; ===== candidate_008a50 =====
0x008a50:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x008a52:	sub     	sp, #0x1c
0x008a54:	movs    	r1, #0
0x008a56:	str     	r1, [sp]
0x008a58:	str     	r1, [sp, #4]
0x008a5a:	movs    	r2, #0
0x008a5c:	str     	r2, [sp, #8]
0x008a5e:	adds    	r5, r0, #0
0x008a60:	ldr     	r2, [r0, #8]
0x008a62:	movs    	r4, #0
0x008a64:	adds    	r3, r4, #0
0x008a66:	movs    	r0, #0xf1
0x008a68:	movs    	r1, #0x46
0x008a6a:	lsls    	r0, r0, #9
0x008a6c:	bl      	#0x7e90
0x008a70:	lsls    	r1, r0, #0x18
0x008a72:	asrs    	r1, r1, #0x18
0x008a74:	str     	r1, [sp, #0x18]
0x008a76:	movs    	r1, #0
0x008a78:	str     	r1, [sp]
0x008a7a:	str     	r1, [sp, #4]
0x008a7c:	movs    	r2, #0
0x008a7e:	movs    	r1, #0x13
0x008a80:	movs    	r0, #0xf1
0x008a82:	adds    	r3, r4, #0
0x008a84:	lsls    	r0, r0, #9
0x008a86:	str     	r2, [sp, #8]
0x008a88:	bl      	#0x7e90
0x008a8c:	str     	r0, [sp, #0x14]
0x008a8e:	movs    	r0, #0
0x008a90:	ldr     	r1, [sp, #0x18]
0x008a92:	str     	r0, [sp, #0x10]
0x008a94:	cmp     	r1, #0
0x008a96:	ble     	#0x8b1a
0x008a98:	movs    	r1, #0
0x008a9a:	str     	r1, [sp]
0x008a9c:	str     	r1, [sp, #4]
0x008a9e:	movs    	r2, #0
0x008aa0:	movs    	r6, #0xf1
0x008aa2:	lsls    	r6, r6, #9
0x008aa4:	str     	r2, [sp, #8]
0x008aa6:	movs    	r1, #0x46
0x008aa8:	movs    	r3, #0
0x008aaa:	adds    	r0, r6, #0
0x008aac:	ldr     	r2, [r5, #8]
0x008aae:	bl      	#0x7e90
0x008ab2:	lsls    	r7, r0, #0x18
0x008ab4:	asrs    	r7, r7, #0x18
0x008ab6:	movs    	r4, #0
0x008ab8:	cmp     	r7, #0
0x008aba:	ble     	#0x8b0e
0x008abc:	movs    	r1, #0
0x008abe:	str     	r1, [sp]
0x008ac0:	str     	r1, [sp, #4]
0x008ac2:	movs    	r2, #0
0x008ac4:	movs    	r1, #0x13
0x008ac6:	movs    	r3, #0
0x008ac8:	adds    	r0, r6, #0
0x008aca:	str     	r2, [sp, #8]
0x008acc:	bl      	#0x7e90
0x008ad0:	adds    	r6, r0, #0
0x008ad2:	adds    	r0, r5, #0
0x008ad4:	bl      	#0x8fec
0x008ad8:	movs    	r1, #0
0x008ada:	adds    	r3, r0, #0
0x008adc:	movs    	r2, #0
0x008ade:	str     	r2, [sp, #8]
0x008ae0:	str     	r1, [sp]
0x008ae2:	str     	r1, [sp, #4]
0x008ae4:	movs    	r1, #0x36
0x008ae6:	adds    	r2, r6, #0
0x008ae8:	movs    	r0, #0xf1
0x008aea:	lsls    	r0, r0, #9
0x008aec:	bl      	#0x7e90
0x008af0:	adds    	r4, #1
0x008af2:	cmp     	r4, r7
0x008af4:	blt     	#0x8ad2
0x008af6:	movs    	r1, #0
0x008af8:	movs    	r2, #0
0x008afa:	str     	r1, [sp]
0x008afc:	str     	r1, [sp, #4]
0x008afe:	movs    	r1, #0x36
0x008b00:	str     	r2, [sp, #8]
0x008b02:	adds    	r3, r6, #0
0x008b04:	movs    	r0, #0xf1
0x008b06:	lsls    	r0, r0, #9
0x008b08:	ldr     	r2, [sp, #0x14]
0x008b0a:	bl      	#0x7e90
0x008b0e:	ldr     	r0, [sp, #0x10]
0x008b10:	ldr     	r1, [sp, #0x18]
0x008b12:	adds    	r0, #1
0x008b14:	str     	r0, [sp, #0x10]
0x008b16:	cmp     	r0, r1
0x008b18:	blt     	#0x8a98
0x008b1a:	movs    	r1, #0
0x008b1c:	str     	r1, [sp]
0x008b1e:	str     	r1, [sp, #4]
0x008b20:	movs    	r2, #0
0x008b22:	str     	r2, [sp, #8]
0x008b24:	movs    	r1, #0x46
0x008b26:	movs    	r3, #0
0x008b28:	movs    	r0, #0xf1
0x008b2a:	lsls    	r0, r0, #9
0x008b2c:	ldr     	r2, [r5, #8]
0x008b2e:	bl      	#0x7e90
0x008b32:	lsls    	r6, r0, #0x18
0x008b34:	movs    	r1, #0
0x008b36:	movs    	r2, #0
0x008b38:	str     	r2, [sp, #8]
0x008b3a:	str     	r1, [sp]
0x008b3c:	str     	r1, [sp, #4]
0x008b3e:	asrs    	r6, r6, #0x18
0x008b40:	adds    	r2, r6, #0
0x008b42:	movs    	r1, #0xa
0x008b44:	movs    	r0, #0xf1
0x008b46:	movs    	r3, #4
0x008b48:	lsls    	r0, r0, #9
0x008b4a:	bl      	#0x7e90
0x008b4e:	adds    	r7, r0, #0
0x008b50:	movs    	r4, #0
0x008b52:	cmp     	r6, #0
0x008b54:	ble     	#0x8b78
0x008b56:	movs    	r1, #0
0x008b58:	str     	r1, [sp]
0x008b5a:	str     	r1, [sp, #4]
0x008b5c:	movs    	r2, #0
0x008b5e:	str     	r2, [sp, #8]
0x008b60:	movs    	r1, #0x47
0x008b62:	movs    	r3, #0
0x008b64:	movs    	r0, #0xf1
0x008b66:	lsls    	r0, r0, #9
0x008b68:	ldr     	r2, [r5, #8]
0x008b6a:	bl      	#0x7e90
0x008b6e:	lsls    	r1, r4, #2
0x008b70:	adds    	r4, #1
0x008b72:	cmp     	r4, r6
0x008b74:	str     	r0, [r7, r1]
0x008b76:	blt     	#0x8b56
0x008b78:	movs    	r1, #0
0x008b7a:	movs    	r2, #0
0x008b7c:	str     	r2, [sp, #8]

; ===== candidate_008ba4 =====
0x008ba4:	push    	{r4, r5, r6, r7, lr}
0x008ba6:	sub     	sp, #0x34
0x008ba8:	adds    	r6, r0, #0
0x008baa:	movs    	r0, #0
0x008bac:	str     	r0, [sp, #0x24]
0x008bae:	movs    	r2, #0
0x008bb0:	movs    	r1, #0
0x008bb2:	str     	r1, [sp, #4]
0x008bb4:	str     	r2, [sp, #8]
0x008bb6:	str     	r0, [sp]
0x008bb8:	movs    	r7, #0
0x008bba:	adds    	r3, r7, #0
0x008bbc:	movs    	r0, #0xf1
0x008bbe:	movs    	r2, #0x34
0x008bc0:	movs    	r1, #0xf
0x008bc2:	movs    	r5, #0
0x008bc4:	lsls    	r0, r0, #9
0x008bc6:	bl      	#0x7e90
0x008bca:	str     	r7, [r0]
0x008bcc:	str     	r7, [r0, #4]
0x008bce:	str     	r7, [r0, #8]
0x008bd0:	movs    	r1, #0
0x008bd2:	str     	r1, [sp]
0x008bd4:	str     	r1, [sp, #4]
0x008bd6:	adds    	r4, r0, #0
0x008bd8:	movs    	r2, #0
0x008bda:	str     	r2, [sp, #8]
0x008bdc:	movs    	r0, #0xf1
0x008bde:	adds    	r3, r7, #0
0x008be0:	movs    	r1, #0x46
0x008be2:	lsls    	r0, r0, #9
0x008be4:	ldr     	r2, [r6, #8]
0x008be6:	bl      	#0x7e90
0x008bea:	lsls    	r0, r0, #0x18
0x008bec:	asrs    	r0, r0, #0x18
0x008bee:	str     	r0, [sp, #0x28]
0x008bf0:	strb    	r0, [r4, #0xc]
0x008bf2:	ldr     	r0, [sp, #0x28]
0x008bf4:	cmp     	r0, #1
0x008bf6:	bne     	#0x8c14
0x008bf8:	movs    	r1, #0
0x008bfa:	str     	r1, [sp]
0x008bfc:	str     	r1, [sp, #4]
0x008bfe:	movs    	r2, #0
0x008c00:	str     	r2, [sp, #8]
0x008c02:	movs    	r1, #0x45
0x008c04:	adds    	r3, r7, #0
0x008c06:	movs    	r0, #0xf1
0x008c08:	lsls    	r0, r0, #9
0x008c0a:	ldr     	r2, [r6, #8]
0x008c0c:	bl      	#0x7e90
0x008c10:	str     	r0, [sp, #0x24]
0x008c12:	str     	r0, [r4, #0x10]
0x008c14:	movs    	r1, #0
0x008c16:	str     	r1, [sp]
0x008c18:	str     	r1, [sp, #4]
0x008c1a:	movs    	r2, #0
0x008c1c:	str     	r2, [sp, #8]
0x008c1e:	movs    	r1, #0x45
0x008c20:	movs    	r3, #0
0x008c22:	movs    	r0, #0xf1
0x008c24:	lsls    	r0, r0, #9
0x008c26:	ldr     	r2, [r6, #8]
0x008c28:	bl      	#0x7e90
0x008c2c:	movs    	r2, #0
0x008c2e:	movs    	r1, #0
0x008c30:	str     	r2, [sp, #8]
0x008c32:	adds    	r7, r0, #0
0x008c34:	adds    	r2, r0, #0
0x008c36:	str     	r1, [sp]
0x008c38:	str     	r1, [sp, #4]
0x008c3a:	movs    	r1, #0xa
0x008c3c:	movs    	r0, #0xf1
0x008c3e:	movs    	r3, #4
0x008c40:	lsls    	r0, r0, #9
0x008c42:	bl      	#0x7e90
0x008c46:	str     	r0, [r4]
0x008c48:	movs    	r1, #0
0x008c4a:	movs    	r2, #0
0x008c4c:	str     	r2, [sp, #8]
0x008c4e:	str     	r1, [sp]
0x008c50:	str     	r1, [sp, #4]
0x008c52:	movs    	r1, #0xa
0x008c54:	adds    	r2, r7, #0
0x008c56:	movs    	r0, #0xf1
0x008c58:	movs    	r3, #4
0x008c5a:	lsls    	r0, r0, #9
0x008c5c:	bl      	#0x7e90
0x008c60:	str     	r0, [r4, #4]
0x008c62:	movs    	r1, #0
0x008c64:	movs    	r2, #0
0x008c66:	str     	r2, [sp, #8]
0x008c68:	str     	r1, [sp]
0x008c6a:	str     	r1, [sp, #4]
0x008c6c:	movs    	r1, #0xa
0x008c6e:	adds    	r2, r7, #0
0x008c70:	movs    	r0, #0xf1
0x008c72:	movs    	r3, #4
0x008c74:	lsls    	r0, r0, #9
0x008c76:	bl      	#0x7e90
0x008c7a:	str     	r0, [r4, #8]
0x008c7c:	movs    	r1, #0
0x008c7e:	movs    	r2, #0
0x008c80:	str     	r2, [sp, #8]
0x008c82:	str     	r1, [sp]
0x008c84:	str     	r1, [sp, #4]
0x008c86:	movs    	r1, #0xa
0x008c88:	adds    	r2, r7, #0
0x008c8a:	movs    	r0, #0xf1
0x008c8c:	movs    	r3, #4
0x008c8e:	lsls    	r0, r0, #9
0x008c90:	bl      	#0x7e90
0x008c94:	str     	r0, [r4, #0x18]
0x008c96:	movs    	r1, #0
0x008c98:	movs    	r2, #0
0x008c9a:	str     	r2, [sp, #8]
0x008c9c:	str     	r1, [sp]
0x008c9e:	str     	r1, [sp, #4]
0x008ca0:	movs    	r1, #0xa
0x008ca2:	adds    	r2, r7, #0
0x008ca4:	movs    	r0, #0xf1
0x008ca6:	movs    	r3, #4
0x008ca8:	lsls    	r0, r0, #9
0x008caa:	bl      	#0x7e90
0x008cae:	str     	r0, [r4, #0x1c]
0x008cb0:	movs    	r1, #0
0x008cb2:	movs    	r2, #0
0x008cb4:	str     	r2, [sp, #8]
0x008cb6:	str     	r1, [sp]
0x008cb8:	str     	r1, [sp, #4]
0x008cba:	movs    	r1, #0xa
0x008cbc:	adds    	r2, r7, #0
0x008cbe:	movs    	r0, #0xf1
0x008cc0:	movs    	r3, #4
0x008cc2:	lsls    	r0, r0, #9
0x008cc4:	bl      	#0x7e90
0x008cc8:	str     	r0, [r4, #0x24]
0x008cca:	movs    	r1, #0
0x008ccc:	movs    	r2, #0
0x008cce:	str     	r2, [sp, #8]
0x008cd0:	str     	r1, [sp]

; ===== candidate_008fec =====
0x008fec:	push    	{r4, r5, r6, r7, lr}
0x008fee:	sub     	sp, #0x24
0x008ff0:	movs    	r1, #0
0x008ff2:	movs    	r2, #0
0x008ff4:	str     	r2, [sp, #8]
0x008ff6:	str     	r1, [sp]
0x008ff8:	str     	r1, [sp, #4]
0x008ffa:	adds    	r4, r0, #0
0x008ffc:	movs    	r0, #0xf1
0x008ffe:	movs    	r1, #0xf
0x009000:	movs    	r2, #0x18
0x009002:	movs    	r6, #0
0x009004:	movs    	r3, #0
0x009006:	lsls    	r0, r0, #9
0x009008:	bl      	#0x7e90
0x00900c:	movs    	r1, #0
0x00900e:	str     	r1, [sp]
0x009010:	str     	r1, [sp, #4]
0x009012:	movs    	r2, #0
0x009014:	adds    	r5, r0, #0
0x009016:	movs    	r0, #0xf1
0x009018:	str     	r2, [sp, #8]
0x00901a:	movs    	r1, #0x46
0x00901c:	movs    	r7, #0
0x00901e:	movs    	r3, #0
0x009020:	lsls    	r0, r0, #9
0x009022:	ldr     	r2, [r4, #8]
0x009024:	bl      	#0x7e90
0x009028:	lsls    	r1, r0, #0x18
0x00902a:	asrs    	r1, r1, #0x18
0x00902c:	str     	r1, [sp, #0x20]
0x00902e:	movs    	r1, #0
0x009030:	str     	r1, [sp]
0x009032:	str     	r1, [sp, #4]
0x009034:	movs    	r2, #0
0x009036:	str     	r2, [sp, #8]
0x009038:	movs    	r1, #0x46
0x00903a:	movs    	r0, #0xf1
0x00903c:	movs    	r3, #0
0x00903e:	lsls    	r0, r0, #9
0x009040:	ldr     	r2, [r4, #8]
0x009042:	bl      	#0x7e90
0x009046:	lsls    	r1, r0, #0x18
0x009048:	asrs    	r1, r1, #0x18
0x00904a:	str     	r1, [sp, #0x1c]
0x00904c:	movs    	r1, #0
0x00904e:	str     	r1, [sp]
0x009050:	str     	r1, [sp, #4]
0x009052:	movs    	r2, #0
0x009054:	str     	r2, [sp, #8]
0x009056:	movs    	r1, #0x46
0x009058:	movs    	r0, #0xf1
0x00905a:	movs    	r3, #0
0x00905c:	lsls    	r0, r0, #9
0x00905e:	ldr     	r2, [r4, #8]
0x009060:	bl      	#0x7e90
0x009064:	lsls    	r0, r0, #0x18
0x009066:	movs    	r1, #0
0x009068:	asrs    	r0, r0, #0x18
0x00906a:	str     	r0, [sp, #0xc]
0x00906c:	str     	r1, [sp]
0x00906e:	str     	r1, [sp, #4]
0x009070:	movs    	r2, #0
0x009072:	str     	r2, [sp, #8]
0x009074:	movs    	r1, #0x46
0x009076:	movs    	r0, #0xf1
0x009078:	movs    	r3, #0
0x00907a:	lsls    	r0, r0, #9
0x00907c:	ldr     	r2, [r4, #8]
0x00907e:	bl      	#0x7e90
0x009082:	lsls    	r0, r0, #0x18
0x009084:	asrs    	r0, r0, #0x18
0x009086:	adds    	r3, r0, #1
0x009088:	beq     	#0x90a4
0x00908a:	movs    	r1, #0
0x00908c:	str     	r1, [sp]
0x00908e:	str     	r1, [sp, #4]
0x009090:	movs    	r2, #0
0x009092:	str     	r2, [sp, #8]
0x009094:	movs    	r1, #0x47
0x009096:	movs    	r3, #0
0x009098:	movs    	r0, #0xf1
0x00909a:	lsls    	r0, r0, #9
0x00909c:	ldr     	r2, [r4, #8]
0x00909e:	bl      	#0x7e90
0x0090a2:	adds    	r6, r0, #0
0x0090a4:	movs    	r1, #0
0x0090a6:	str     	r1, [sp]
0x0090a8:	str     	r1, [sp, #4]
0x0090aa:	movs    	r2, #0
0x0090ac:	str     	r2, [sp, #8]
0x0090ae:	movs    	r1, #0x46
0x0090b0:	movs    	r3, #0
0x0090b2:	movs    	r0, #0xf1
0x0090b4:	lsls    	r0, r0, #9
0x0090b6:	ldr     	r2, [r4, #8]
0x0090b8:	bl      	#0x7e90
0x0090bc:	lsls    	r0, r0, #0x18
0x0090be:	movs    	r1, #0
0x0090c0:	asrs    	r0, r0, #0x18
0x0090c2:	str     	r0, [sp, #0x18]
0x0090c4:	str     	r1, [sp]
0x0090c6:	str     	r1, [sp, #4]
0x0090c8:	movs    	r2, #0
0x0090ca:	str     	r2, [sp, #8]
0x0090cc:	movs    	r1, #0x46
0x0090ce:	movs    	r0, #0xf1
0x0090d0:	movs    	r3, #0
0x0090d2:	lsls    	r0, r0, #9
0x0090d4:	ldr     	r2, [r4, #8]
0x0090d6:	bl      	#0x7e90
0x0090da:	lsls    	r0, r0, #0x18
0x0090dc:	movs    	r1, #0
0x0090de:	asrs    	r0, r0, #0x18
0x0090e0:	str     	r0, [sp, #0x14]
0x0090e2:	str     	r1, [sp]
0x0090e4:	str     	r1, [sp, #4]
0x0090e6:	movs    	r2, #0
0x0090e8:	str     	r2, [sp, #8]
0x0090ea:	movs    	r1, #0x46
0x0090ec:	movs    	r0, #0xf1
0x0090ee:	movs    	r3, #0
0x0090f0:	lsls    	r0, r0, #9
0x0090f2:	ldr     	r2, [r4, #8]
0x0090f4:	bl      	#0x7e90
0x0090f8:	lsls    	r0, r0, #0x18
0x0090fa:	movs    	r1, #0
0x0090fc:	asrs    	r0, r0, #0x18
0x0090fe:	str     	r0, [sp, #0x10]
0x009100:	str     	r1, [sp]
0x009102:	str     	r1, [sp, #4]
0x009104:	movs    	r2, #0
0x009106:	str     	r2, [sp, #8]
0x009108:	movs    	r1, #0x46
0x00910a:	movs    	r0, #0xf1
0x00910c:	movs    	r3, #0
0x00910e:	lsls    	r0, r0, #9
0x009110:	ldr     	r2, [r4, #8]
0x009112:	bl      	#0x7e90
0x009116:	lsls    	r0, r0, #0x18
0x009118:	asrs    	r0, r0, #0x18

; ===== candidate_009174 =====
0x009174:	push    	{r4, r5, r6, r7, lr}
0x009176:	adds    	r4, r0, #0
0x009178:	ldr     	r0, [r0, #0x64]
0x00917a:	sub     	sp, #0x14
0x00917c:	cmp     	r0, #0
0x00917e:	beq     	#0x91a0
0x009180:	bl      	#0x93c4
0x009184:	movs    	r1, #0
0x009186:	str     	r1, [sp]
0x009188:	str     	r1, [sp, #4]
0x00918a:	movs    	r2, #0
0x00918c:	movs    	r5, #0
0x00918e:	adds    	r3, r5, #0
0x009190:	str     	r2, [sp, #8]
0x009192:	movs    	r1, #9
0x009194:	movs    	r0, #0xf1
0x009196:	lsls    	r0, r0, #9
0x009198:	ldr     	r2, [r4, #0x64]
0x00919a:	bl      	#0x7e90
0x00919e:	str     	r5, [r4, #0x64]
0x0091a0:	ldr     	r3, [r4, #0x68]
0x0091a2:	cmp     	r3, #0
0x0091a4:	beq     	#0x91c2
0x0091a6:	movs    	r2, #0
0x0091a8:	movs    	r1, #0
0x0091aa:	str     	r2, [sp, #8]
0x0091ac:	adds    	r2, r3, #0
0x0091ae:	str     	r1, [sp]
0x0091b0:	str     	r1, [sp, #4]
0x0091b2:	movs    	r5, #0
0x0091b4:	adds    	r3, r5, #0
0x0091b6:	movs    	r1, #9
0x0091b8:	movs    	r0, #0xf1
0x0091ba:	lsls    	r0, r0, #9
0x0091bc:	bl      	#0x7e90
0x0091c0:	str     	r5, [r4, #0x68]
0x0091c2:	ldr     	r3, [r4, #0x60]
0x0091c4:	cmp     	r3, #0
0x0091c6:	beq     	#0x91e0
0x0091c8:	movs    	r2, #0
0x0091ca:	movs    	r1, #0
0x0091cc:	str     	r2, [sp, #8]
0x0091ce:	adds    	r2, r3, #0
0x0091d0:	str     	r1, [sp]
0x0091d2:	str     	r1, [sp, #4]
0x0091d4:	movs    	r1, #0x12
0x0091d6:	movs    	r3, #0
0x0091d8:	movs    	r0, #0xf1
0x0091da:	lsls    	r0, r0, #9
0x0091dc:	bl      	#0x7e90
0x0091e0:	ldr     	r3, [r4, #0x54]
0x0091e2:	cmp     	r3, #0
0x0091e4:	beq     	#0x91fe
0x0091e6:	movs    	r2, #0
0x0091e8:	movs    	r1, #0
0x0091ea:	str     	r2, [sp, #8]
0x0091ec:	adds    	r2, r3, #0
0x0091ee:	str     	r1, [sp]
0x0091f0:	str     	r1, [sp, #4]
0x0091f2:	movs    	r1, #0x12
0x0091f4:	movs    	r3, #0
0x0091f6:	movs    	r0, #0xf1
0x0091f8:	lsls    	r0, r0, #9
0x0091fa:	bl      	#0x7e90
0x0091fe:	ldr     	r3, [r4, #0x58]
0x009200:	cmp     	r3, #0
0x009202:	beq     	#0x921c
0x009204:	movs    	r2, #0
0x009206:	movs    	r1, #0
0x009208:	str     	r2, [sp, #8]
0x00920a:	adds    	r2, r3, #0
0x00920c:	str     	r1, [sp]
0x00920e:	str     	r1, [sp, #4]
0x009210:	movs    	r1, #0x12
0x009212:	movs    	r3, #0
0x009214:	movs    	r0, #0xf1
0x009216:	lsls    	r0, r0, #9
0x009218:	bl      	#0x7e90
0x00921c:	ldr     	r3, [r4, #0x5c]
0x00921e:	cmp     	r3, #0
0x009220:	beq     	#0x923a
0x009222:	movs    	r2, #0
0x009224:	movs    	r1, #0
0x009226:	str     	r2, [sp, #8]
0x009228:	adds    	r2, r3, #0
0x00922a:	str     	r1, [sp]
0x00922c:	str     	r1, [sp, #4]
0x00922e:	movs    	r1, #0x12
0x009230:	movs    	r3, #0
0x009232:	movs    	r0, #0xf1
0x009234:	lsls    	r0, r0, #9
0x009236:	bl      	#0x7e90
0x00923a:	ldr     	r3, [r4, #0x30]
0x00923c:	cmp     	r3, #0
0x00923e:	beq     	#0x9328
0x009240:	movs    	r2, #0
0x009242:	movs    	r1, #0
0x009244:	str     	r2, [sp, #8]
0x009246:	adds    	r2, r3, #0
0x009248:	str     	r1, [sp]
0x00924a:	str     	r1, [sp, #4]
0x00924c:	movs    	r1, #0x26
0x00924e:	movs    	r3, #0
0x009250:	movs    	r0, #0xf1
0x009252:	lsls    	r0, r0, #9
0x009254:	bl      	#0x7e90
0x009258:	movs    	r7, #0
0x00925a:	cmp     	r0, #0
0x00925c:	str     	r0, [sp, #0x10]
0x00925e:	ble     	#0x92f8
0x009260:	movs    	r1, #0
0x009262:	str     	r1, [sp]
0x009264:	str     	r1, [sp, #4]
0x009266:	movs    	r2, #0
0x009268:	str     	r2, [sp, #8]
0x00926a:	movs    	r1, #0x27
0x00926c:	adds    	r3, r7, #0
0x00926e:	movs    	r0, #0xf1
0x009270:	lsls    	r0, r0, #9
0x009272:	ldr     	r2, [r4, #0x30]
0x009274:	bl      	#0x7e90
0x009278:	movs    	r2, #0
0x00927a:	movs    	r1, #0
0x00927c:	str     	r2, [sp, #8]
0x00927e:	adds    	r6, r0, #0
0x009280:	adds    	r2, r0, #0
0x009282:	str     	r1, [sp]
0x009284:	str     	r1, [sp, #4]
0x009286:	movs    	r1, #0x26
0x009288:	movs    	r0, #0xf1
0x00928a:	movs    	r3, #0
0x00928c:	lsls    	r0, r0, #9
0x00928e:	bl      	#0x7e90
0x009292:	movs    	r5, #0
0x009294:	cmp     	r0, #0
0x009296:	str     	r0, [sp, #0xc]
0x009298:	ble     	#0x92be
0x00929a:	movs    	r1, #0
0x00929c:	movs    	r2, #0
0x00929e:	str     	r2, [sp, #8]
0x0092a0:	str     	r1, [sp]

; ===== candidate_0093c4 =====
0x0093c4:	push    	{r4, r5, r6, r7, lr}
0x0093c6:	sub     	sp, #0x14
0x0093c8:	adds    	r5, r0, #0
0x0093ca:	beq     	#0x941a
0x0093cc:	movs    	r1, #0
0x0093ce:	movs    	r2, #0
0x0093d0:	str     	r2, [sp, #8]
0x0093d2:	str     	r1, [sp]
0x0093d4:	str     	r1, [sp, #4]
0x0093d6:	movs    	r6, #0xf1
0x0093d8:	lsls    	r6, r6, #9
0x0093da:	movs    	r1, #0x11
0x0093dc:	adds    	r2, r5, #0
0x0093de:	movs    	r4, #0
0x0093e0:	movs    	r3, #4
0x0093e2:	adds    	r0, r6, #0
0x0093e4:	bl      	#0x7e90
0x0093e8:	str     	r0, [sp, #0x10]
0x0093ea:	cmp     	r0, #0
0x0093ec:	ble     	#0x941a
0x0093ee:	lsls    	r6, r4, #2
0x0093f0:	ldr     	r7, [r5, r6]
0x0093f2:	cmp     	r7, #0
0x0093f4:	beq     	#0x940e
0x0093f6:	movs    	r1, #0
0x0093f8:	movs    	r2, #0
0x0093fa:	str     	r2, [sp, #8]
0x0093fc:	str     	r1, [sp]
0x0093fe:	str     	r1, [sp, #4]
0x009400:	movs    	r1, #0x4c
0x009402:	adds    	r2, r7, #0
0x009404:	movs    	r3, #0
0x009406:	movs    	r0, #0xf1
0x009408:	lsls    	r0, r0, #9
0x00940a:	bl      	#0x7e90
0x00940e:	movs    	r3, #0
0x009410:	str     	r3, [r5, r6]
0x009412:	ldr     	r0, [sp, #0x10]
0x009414:	adds    	r4, #1
0x009416:	cmp     	r4, r0
0x009418:	blt     	#0x93ee
0x00941a:	add     	sp, #0x14
0x00941c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_009420 =====
0x009420:	push    	{r4, r5, r6, r7, lr}
0x009422:	ldr     	r7, [pc, #0x84]
0x009424:	movs    	r4, #0
0x009426:	add     	r7, sb
0x009428:	ldr     	r5, [r7, #0x14]
0x00942a:	sub     	sp, #0xc
0x00942c:	cmp     	r5, #0
0x00942e:	beq     	#0x94a2
0x009430:	movs    	r1, #0
0x009432:	movs    	r2, #0
0x009434:	str     	r2, [sp, #8]
0x009436:	str     	r1, [sp]
0x009438:	str     	r1, [sp, #4]
0x00943a:	movs    	r6, #0xf1
0x00943c:	lsls    	r6, r6, #9
0x00943e:	movs    	r1, #0x26
0x009440:	adds    	r2, r5, #0
0x009442:	movs    	r3, #0
0x009444:	adds    	r0, r6, #0
0x009446:	bl      	#0x7e90
0x00944a:	adds    	r5, r0, #0
0x00944c:	cmp     	r0, #0
0x00944e:	ble     	#0x9470
0x009450:	movs    	r1, #0
0x009452:	str     	r1, [sp]
0x009454:	str     	r1, [sp, #4]
0x009456:	movs    	r2, #0
0x009458:	str     	r2, [sp, #8]
0x00945a:	movs    	r1, #0x27
0x00945c:	adds    	r3, r4, #0
0x00945e:	adds    	r0, r6, #0
0x009460:	ldr     	r2, [r7, #0x14]
0x009462:	bl      	#0x7e90
0x009466:	bl      	#0x9174
0x00946a:	adds    	r4, #1
0x00946c:	cmp     	r4, r5
0x00946e:	blt     	#0x9450
0x009470:	movs    	r1, #0
0x009472:	str     	r1, [sp]
0x009474:	str     	r1, [sp, #4]
0x009476:	movs    	r2, #0
0x009478:	movs    	r4, #0
0x00947a:	adds    	r3, r4, #0
0x00947c:	str     	r2, [sp, #8]
0x00947e:	movs    	r1, #0x28
0x009480:	adds    	r0, r6, #0
0x009482:	ldr     	r2, [r7, #0x14]
0x009484:	bl      	#0x7e90
0x009488:	movs    	r1, #0
0x00948a:	str     	r1, [sp]
0x00948c:	str     	r1, [sp, #4]
0x00948e:	movs    	r2, #0
0x009490:	str     	r2, [sp, #8]
0x009492:	movs    	r1, #9
0x009494:	adds    	r3, r4, #0
0x009496:	movs    	r0, #0xf1
0x009498:	lsls    	r0, r0, #9
0x00949a:	ldr     	r2, [r7, #0x14]
0x00949c:	bl      	#0x7e90
0x0094a0:	str     	r4, [r7, #0x14]
0x0094a2:	add     	sp, #0xc
0x0094a4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0094ac =====
0x0094ac:	push    	{r4, lr}
0x0094ae:	sub     	sp, #0x10
0x0094b0:	bl      	#0x9570
0x0094b4:	bl      	#0x98b4
0x0094b8:	bl      	#0x94f4
0x0094bc:	bl      	#0x9920
0x0094c0:	movs    	r1, #0
0x0094c2:	str     	r1, [sp]
0x0094c4:	str     	r1, [sp, #4]
0x0094c6:	movs    	r2, #0
0x0094c8:	movs    	r4, #0
0x0094ca:	adds    	r3, r4, #0
0x0094cc:	movs    	r1, #0x6c
0x0094ce:	movs    	r0, #0xf1
0x0094d0:	lsls    	r0, r0, #9
0x0094d2:	str     	r2, [sp, #8]
0x0094d4:	bl      	#0x7e90
0x0094d8:	movs    	r1, #0
0x0094da:	movs    	r2, #0
0x0094dc:	str     	r2, [sp, #8]
0x0094de:	str     	r1, [sp]
0x0094e0:	str     	r1, [sp, #4]
0x0094e2:	movs    	r1, #0x7c
0x0094e4:	movs    	r2, #1
0x0094e6:	adds    	r3, r4, #0
0x0094e8:	movs    	r0, #0xf1
0x0094ea:	lsls    	r0, r0, #9
0x0094ec:	bl      	#0x7e90
0x0094f0:	add     	sp, #0x10
0x0094f2:	pop     	{r4, pc}

; ===== candidate_0094f4 =====
0x0094f4:	push    	{r4, r5, lr}
0x0094f6:	sub     	sp, #0xc
0x0094f8:	movs    	r1, #0
0x0094fa:	str     	r1, [sp]
0x0094fc:	str     	r1, [sp, #4]
0x0094fe:	ldr     	r5, [pc, #0x6c]
0x009500:	movs    	r2, #0
0x009502:	movs    	r4, #0
0x009504:	adds    	r3, r4, #0
0x009506:	str     	r2, [sp, #8]
0x009508:	movs    	r1, #6
0x00950a:	movs    	r0, #0xf1
0x00950c:	add     	r5, sb
0x00950e:	ldr     	r2, [r5, #0x40]
0x009510:	lsls    	r0, r0, #9
0x009512:	bl      	#0x7e90
0x009516:	str     	r4, [r5, #0x40]
0x009518:	movs    	r1, #0
0x00951a:	str     	r1, [sp]
0x00951c:	str     	r1, [sp, #4]
0x00951e:	movs    	r2, #0
0x009520:	str     	r2, [sp, #8]
0x009522:	movs    	r1, #6
0x009524:	adds    	r3, r4, #0
0x009526:	movs    	r0, #0xf1
0x009528:	lsls    	r0, r0, #9
0x00952a:	ldr     	r2, [r5, #0x4c]
0x00952c:	bl      	#0x7e90
0x009530:	str     	r4, [r5, #0x4c]
0x009532:	movs    	r1, #0
0x009534:	str     	r1, [sp]
0x009536:	str     	r1, [sp, #4]
0x009538:	movs    	r2, #0
0x00953a:	str     	r2, [sp, #8]
0x00953c:	movs    	r1, #6
0x00953e:	adds    	r3, r4, #0
0x009540:	movs    	r0, #0xf1
0x009542:	lsls    	r0, r0, #9
0x009544:	ldr     	r2, [r5, #0x44]
0x009546:	bl      	#0x7e90
0x00954a:	str     	r4, [r5, #0x44]
0x00954c:	movs    	r1, #0
0x00954e:	str     	r1, [sp]
0x009550:	str     	r1, [sp, #4]
0x009552:	movs    	r2, #0
0x009554:	str     	r2, [sp, #8]
0x009556:	movs    	r1, #6
0x009558:	adds    	r3, r4, #0
0x00955a:	movs    	r0, #0xf1
0x00955c:	lsls    	r0, r0, #9
0x00955e:	ldr     	r2, [r5, #0x48]
0x009560:	bl      	#0x7e90
0x009564:	str     	r4, [r5, #0x48]
0x009566:	add     	sp, #0xc
0x009568:	pop     	{r4, r5, pc}

; ===== candidate_009570 =====
0x009570:	push    	{r4, r5, r6, r7, lr}
0x009572:	ldr     	r4, [pc, #0x4c]
0x009574:	movs    	r6, #0xf1
0x009576:	add     	r4, sb
0x009578:	ldr     	r7, [r4, #0x78]
0x00957a:	lsls    	r6, r6, #9
0x00957c:	movs    	r5, #0
0x00957e:	cmp     	r7, #0
0x009580:	sub     	sp, #0xc
0x009582:	beq     	#0x959c
0x009584:	movs    	r1, #0
0x009586:	movs    	r2, #0
0x009588:	str     	r2, [sp, #8]
0x00958a:	str     	r1, [sp]
0x00958c:	str     	r1, [sp, #4]
0x00958e:	movs    	r1, #0x4c
0x009590:	adds    	r2, r7, #0
0x009592:	adds    	r3, r5, #0
0x009594:	adds    	r0, r6, #0
0x009596:	bl      	#0x7e90
0x00959a:	str     	r5, [r4, #0x78]
0x00959c:	ldr     	r7, [r4, #0x70]
0x00959e:	cmp     	r7, #0
0x0095a0:	beq     	#0x95ba
0x0095a2:	movs    	r1, #0
0x0095a4:	movs    	r2, #0
0x0095a6:	str     	r2, [sp, #8]
0x0095a8:	str     	r1, [sp]
0x0095aa:	str     	r1, [sp, #4]
0x0095ac:	movs    	r1, #0x4c
0x0095ae:	adds    	r2, r7, #0
0x0095b0:	adds    	r3, r5, #0
0x0095b2:	adds    	r0, r6, #0
0x0095b4:	bl      	#0x7e90
0x0095b8:	str     	r5, [r4, #0x70]
0x0095ba:	add     	sp, #0xc
0x0095bc:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0095c4 =====
0x0095c4:	push    	{r4, r5, r6, r7, lr}
0x0095c6:	movs    	r6, #0
0x0095c8:	adds    	r4, r0, #0
0x0095ca:	cmp     	r0, #0
0x0095cc:	sub     	sp, #0x14
0x0095ce:	beq     	#0x96b4
0x0095d0:	movs    	r1, #0
0x0095d2:	str     	r1, [sp]
0x0095d4:	str     	r1, [sp, #4]
0x0095d6:	movs    	r2, #0
0x0095d8:	str     	r2, [sp, #8]
0x0095da:	movs    	r1, #0x11
0x0095dc:	movs    	r3, #4
0x0095de:	movs    	r0, #0xf1
0x0095e0:	lsls    	r0, r0, #9
0x0095e2:	ldr     	r2, [r4, #8]
0x0095e4:	bl      	#0x7e90
0x0095e8:	adds    	r7, r0, #0
0x0095ea:	cmp     	r0, #0
0x0095ec:	ble     	#0x9652
0x0095ee:	ldr     	r0, [r4, #8]
0x0095f0:	lsls    	r1, r6, #2
0x0095f2:	ldr     	r5, [r0, r1]
0x0095f4:	cmp     	r5, #0
0x0095f6:	beq     	#0x964c
0x0095f8:	ldr     	r3, [r5]
0x0095fa:	cmp     	r3, #0
0x0095fc:	beq     	#0x9616
0x0095fe:	movs    	r2, #0
0x009600:	movs    	r1, #0
0x009602:	str     	r2, [sp, #8]
0x009604:	adds    	r2, r3, #0
0x009606:	str     	r1, [sp]
0x009608:	str     	r1, [sp, #4]
0x00960a:	movs    	r1, #9
0x00960c:	movs    	r3, #0
0x00960e:	movs    	r0, #0xf1
0x009610:	lsls    	r0, r0, #9
0x009612:	bl      	#0x7e90
0x009616:	ldr     	r3, [r5, #0x70]
0x009618:	cmp     	r3, #0
0x00961a:	beq     	#0x9634
0x00961c:	movs    	r2, #0
0x00961e:	movs    	r1, #0
0x009620:	str     	r2, [sp, #8]
0x009622:	adds    	r2, r3, #0
0x009624:	str     	r1, [sp]
0x009626:	str     	r1, [sp, #4]
0x009628:	movs    	r1, #0x4a
0x00962a:	movs    	r3, #0
0x00962c:	movs    	r0, #0xf1
0x00962e:	lsls    	r0, r0, #9
0x009630:	bl      	#0x7e90
0x009634:	movs    	r1, #0
0x009636:	movs    	r2, #0
0x009638:	str     	r2, [sp, #8]
0x00963a:	str     	r1, [sp]
0x00963c:	str     	r1, [sp, #4]
0x00963e:	movs    	r1, #9
0x009640:	adds    	r2, r5, #0
0x009642:	movs    	r3, #0
0x009644:	movs    	r0, #0xf1
0x009646:	lsls    	r0, r0, #9
0x009648:	bl      	#0x7e90
0x00964c:	adds    	r6, #1
0x00964e:	cmp     	r6, r7
0x009650:	blt     	#0x95ee
0x009652:	movs    	r1, #0
0x009654:	str     	r1, [sp]
0x009656:	str     	r1, [sp, #4]
0x009658:	movs    	r2, #0
0x00965a:	movs    	r5, #0
0x00965c:	adds    	r3, r5, #0
0x00965e:	str     	r2, [sp, #8]
0x009660:	movs    	r1, #9
0x009662:	movs    	r0, #0xf1
0x009664:	lsls    	r0, r0, #9
0x009666:	ldr     	r2, [r4, #8]
0x009668:	bl      	#0x7e90
0x00966c:	movs    	r1, #0
0x00966e:	str     	r1, [sp]
0x009670:	str     	r1, [sp, #4]
0x009672:	movs    	r2, #0
0x009674:	str     	r2, [sp, #8]
0x009676:	movs    	r1, #9
0x009678:	adds    	r3, r5, #0
0x00967a:	movs    	r0, #0xf1
0x00967c:	lsls    	r0, r0, #9
0x00967e:	ldr     	r2, [r4, #0x20]
0x009680:	bl      	#0x7e90
0x009684:	movs    	r1, #0
0x009686:	str     	r1, [sp]
0x009688:	str     	r1, [sp, #4]
0x00968a:	movs    	r2, #0
0x00968c:	str     	r2, [sp, #8]
0x00968e:	movs    	r1, #9
0x009690:	adds    	r3, r5, #0
0x009692:	movs    	r0, #0xf1
0x009694:	lsls    	r0, r0, #9
0x009696:	ldr     	r2, [r4, #0x24]
0x009698:	bl      	#0x7e90
0x00969c:	ldr     	r0, [r4, #0x1c]
0x00969e:	cmp     	r0, #0
0x0096a0:	beq     	#0x9702
0x0096a2:	cmp     	r7, #0
0x0096a4:	ble     	#0x96ea
0x0096a6:	ldr     	r0, [r4, #0x1c]
0x0096a8:	lsls    	r1, r5, #2
0x0096aa:	ldr     	r6, [r0, r1]
0x0096ac:	cmp     	r6, #0
0x0096ae:	beq     	#0x96e4
0x0096b0:	movs    	r2, #0
0x0096b2:	b       	#0x96b6
0x0096b4:	b       	#0x98ae
0x0096b6:	movs    	r1, #0
0x0096b8:	str     	r1, [sp]
0x0096ba:	str     	r1, [sp, #4]
0x0096bc:	str     	r2, [sp, #8]
0x0096be:	adds    	r2, r6, #0
0x0096c0:	movs    	r1, #0x28
0x0096c2:	movs    	r3, #0
0x0096c4:	movs    	r0, #0xf1
0x0096c6:	lsls    	r0, r0, #9
0x0096c8:	bl      	#0x7e90
0x0096cc:	movs    	r1, #0
0x0096ce:	movs    	r2, #0
0x0096d0:	str     	r2, [sp, #8]
0x0096d2:	str     	r1, [sp]
0x0096d4:	str     	r1, [sp, #4]
0x0096d6:	movs    	r1, #9
0x0096d8:	adds    	r2, r6, #0
0x0096da:	movs    	r3, #0
0x0096dc:	movs    	r0, #0xf1
0x0096de:	lsls    	r0, r0, #9
0x0096e0:	bl      	#0x7e90
0x0096e4:	adds    	r5, #1
0x0096e6:	cmp     	r5, r7
0x0096e8:	blt     	#0x96a6
0x0096ea:	movs    	r1, #0
0x0096ec:	str     	r1, [sp]
0x0096ee:	str     	r1, [sp, #4]

; ===== candidate_0098b4 =====
0x0098b4:	push    	{r4, r5, r6, r7, lr}
0x0098b6:	ldr     	r4, [pc, #0x64]
0x0098b8:	movs    	r6, #0xf1
0x0098ba:	add     	r4, sb
0x0098bc:	ldr     	r7, [r4, #0x5c]
0x0098be:	lsls    	r6, r6, #9
0x0098c0:	movs    	r5, #0
0x0098c2:	cmp     	r7, #0
0x0098c4:	sub     	sp, #0xc
0x0098c6:	beq     	#0x98e0
0x0098c8:	movs    	r1, #0
0x0098ca:	movs    	r2, #0
0x0098cc:	str     	r2, [sp, #8]
0x0098ce:	str     	r1, [sp]
0x0098d0:	str     	r1, [sp, #4]
0x0098d2:	movs    	r1, #0x4c
0x0098d4:	adds    	r2, r7, #0
0x0098d6:	adds    	r3, r5, #0
0x0098d8:	adds    	r0, r6, #0
0x0098da:	bl      	#0x7e90
0x0098de:	str     	r5, [r4, #0x5c]
0x0098e0:	ldr     	r7, [r4, #0x7c]
0x0098e2:	cmp     	r7, #0
0x0098e4:	beq     	#0x98fe
0x0098e6:	movs    	r1, #0
0x0098e8:	movs    	r2, #0
0x0098ea:	str     	r2, [sp, #8]
0x0098ec:	str     	r1, [sp]
0x0098ee:	str     	r1, [sp, #4]
0x0098f0:	movs    	r1, #0x4c
0x0098f2:	adds    	r2, r7, #0
0x0098f4:	adds    	r3, r5, #0
0x0098f6:	adds    	r0, r6, #0
0x0098f8:	bl      	#0x7e90
0x0098fc:	str     	r5, [r4, #0x7c]
0x0098fe:	movs    	r1, #0
0x009900:	str     	r1, [sp]
0x009902:	str     	r1, [sp, #4]
0x009904:	movs    	r2, #0
0x009906:	str     	r2, [sp, #8]
0x009908:	movs    	r1, #6
0x00990a:	adds    	r3, r5, #0
0x00990c:	adds    	r0, r6, #0
0x00990e:	ldr     	r2, [r4, #0x74]
0x009910:	bl      	#0x7e90
0x009914:	str     	r0, [r4, #0x74]
0x009916:	add     	sp, #0xc
0x009918:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_009920 =====
0x009920:	push    	{r4, r5, r6, lr}
0x009922:	ldr     	r5, [pc, #0x2c]
0x009924:	sub     	sp, #0x10
0x009926:	add     	r5, sb
0x009928:	ldr     	r6, [r5, #0x60]
0x00992a:	cmp     	r6, #0
0x00992c:	beq     	#0x994a
0x00992e:	movs    	r1, #0
0x009930:	movs    	r2, #0
0x009932:	movs    	r4, #0
0x009934:	adds    	r3, r4, #0
0x009936:	str     	r2, [sp, #8]
0x009938:	str     	r1, [sp]
0x00993a:	str     	r1, [sp, #4]
0x00993c:	movs    	r1, #0x4c
0x00993e:	adds    	r2, r6, #0
0x009940:	movs    	r0, #0xf1
0x009942:	lsls    	r0, r0, #9
0x009944:	bl      	#0x7e90
0x009948:	str     	r4, [r5, #0x60]
0x00994a:	add     	sp, #0x10
0x00994c:	pop     	{r4, r5, r6, pc}

; ===== candidate_009954 =====
0x009954:	push    	{r4, r5, lr}
0x009956:	sub     	sp, #0xc
0x009958:	movs    	r1, #0
0x00995a:	movs    	r2, #0
0x00995c:	str     	r2, [sp, #8]
0x00995e:	str     	r1, [sp]
0x009960:	str     	r1, [sp, #4]
0x009962:	movs    	r4, #0
0x009964:	adds    	r3, r4, #0
0x009966:	movs    	r1, #0xe1
0x009968:	movs    	r2, #0x56
0x00996a:	movs    	r0, #0xf1
0x00996c:	lsls    	r0, r0, #9
0x00996e:	bl      	#0x7e90
0x009972:	movs    	r2, #0
0x009974:	movs    	r1, #0
0x009976:	str     	r2, [sp, #8]
0x009978:	adds    	r3, r4, #0
0x00997a:	adds    	r2, r0, #0
0x00997c:	str     	r1, [sp]
0x00997e:	str     	r1, [sp, #4]
0x009980:	movs    	r1, #6
0x009982:	movs    	r0, #0xf1
0x009984:	lsls    	r0, r0, #9
0x009986:	bl      	#0x7e90
0x00998a:	movs    	r1, #0
0x00998c:	movs    	r2, #0
0x00998e:	str     	r2, [sp, #8]
0x009990:	str     	r1, [sp]
0x009992:	str     	r1, [sp, #4]
0x009994:	movs    	r1, #0x14
0x009996:	movs    	r2, #0x56
0x009998:	adds    	r3, r4, #0
0x00999a:	movs    	r0, #0xf1
0x00999c:	lsls    	r0, r0, #9
0x00999e:	bl      	#0x7e90
0x0099a2:	movs    	r1, #0
0x0099a4:	str     	r1, [sp]
0x0099a6:	str     	r1, [sp, #4]
0x0099a8:	movs    	r2, #0
0x0099aa:	ldr     	r5, [pc, #0x44]
0x0099ac:	str     	r2, [sp, #8]
0x0099ae:	movs    	r1, #9
0x0099b0:	adds    	r3, r4, #0
0x0099b2:	movs    	r0, #0xf1
0x0099b4:	add     	r5, sb
0x0099b6:	ldr     	r2, [r5, #0x28]
0x0099b8:	lsls    	r0, r0, #9
0x0099ba:	bl      	#0x7e90
0x0099be:	str     	r4, [r5, #0x28]
0x0099c0:	movs    	r1, #0
0x0099c2:	str     	r1, [sp]
0x0099c4:	str     	r1, [sp, #4]
0x0099c6:	movs    	r2, #0
0x0099c8:	movs    	r1, #0xe6
0x0099ca:	adds    	r3, r4, #0
0x0099cc:	movs    	r0, #0xf1
0x0099ce:	lsls    	r0, r0, #9
0x0099d0:	str     	r2, [sp, #8]
0x0099d2:	bl      	#0x7e90
0x0099d6:	movs    	r1, #0
0x0099d8:	str     	r1, [sp]
0x0099da:	str     	r1, [sp, #4]
0x0099dc:	movs    	r2, #0
0x0099de:	movs    	r1, #0x2c
0x0099e0:	adds    	r3, r4, #0
0x0099e2:	movs    	r0, #0xf1
0x0099e4:	lsls    	r0, r0, #9
0x0099e6:	str     	r2, [sp, #8]
0x0099e8:	bl      	#0x7e90
0x0099ec:	add     	sp, #0xc
0x0099ee:	pop     	{r4, r5, pc}

; ===== candidate_0099f4 =====
0x0099f4:	push    	{r4, r5, r6, lr}
0x0099f6:	movs    	r6, #0xf1
0x0099f8:	ldr     	r3, [r0, #4]
0x0099fa:	lsls    	r6, r6, #9
0x0099fc:	movs    	r5, #0
0x0099fe:	adds    	r4, r0, #0
0x009a00:	cmp     	r3, #0
0x009a02:	sub     	sp, #0x10
0x009a04:	beq     	#0x9a1c
0x009a06:	movs    	r2, #0
0x009a08:	movs    	r1, #0
0x009a0a:	str     	r2, [sp, #8]
0x009a0c:	adds    	r2, r3, #0
0x009a0e:	str     	r1, [sp]
0x009a10:	str     	r1, [sp, #4]
0x009a12:	movs    	r1, #9
0x009a14:	adds    	r3, r5, #0
0x009a16:	adds    	r0, r6, #0
0x009a18:	bl      	#0x7e90
0x009a1c:	ldr     	r3, [r4, #0x10]
0x009a1e:	cmp     	r3, #0
0x009a20:	beq     	#0x9a38
0x009a22:	movs    	r2, #0
0x009a24:	movs    	r1, #0
0x009a26:	str     	r2, [sp, #8]
0x009a28:	adds    	r2, r3, #0
0x009a2a:	str     	r1, [sp]
0x009a2c:	str     	r1, [sp, #4]
0x009a2e:	movs    	r1, #9
0x009a30:	adds    	r3, r5, #0
0x009a32:	adds    	r0, r6, #0
0x009a34:	bl      	#0x7e90
0x009a38:	movs    	r1, #0
0x009a3a:	movs    	r2, #0
0x009a3c:	str     	r2, [sp, #8]
0x009a3e:	str     	r1, [sp]
0x009a40:	str     	r1, [sp, #4]
0x009a42:	movs    	r1, #9
0x009a44:	adds    	r2, r4, #0
0x009a46:	adds    	r3, r5, #0
0x009a48:	adds    	r0, r6, #0
0x009a4a:	bl      	#0x7e90
0x009a4e:	add     	sp, #0x10
0x009a50:	pop     	{r4, r5, r6, pc}

; ===== candidate_009a54 =====
0x009a54:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x009a56:	sub     	sp, #0x10
0x009a58:	movs    	r1, #0
0x009a5a:	movs    	r2, #0
0x009a5c:	str     	r2, [sp, #8]
0x009a5e:	str     	r1, [sp]
0x009a60:	str     	r1, [sp, #4]
0x009a62:	movs    	r4, #0
0x009a64:	adds    	r3, r4, #0
0x009a66:	movs    	r1, #0x14
0x009a68:	movs    	r2, #0x4e
0x009a6a:	movs    	r0, #0xf1
0x009a6c:	movs    	r5, #0xb7
0x009a6e:	lsls    	r0, r0, #9
0x009a70:	bl      	#0x7e90
0x009a74:	movs    	r1, #0
0x009a76:	movs    	r2, #0
0x009a78:	str     	r2, [sp, #8]
0x009a7a:	str     	r1, [sp]
0x009a7c:	str     	r1, [sp, #4]
0x009a7e:	adds    	r3, r4, #0
0x009a80:	adds    	r2, r5, #0
0x009a82:	movs    	r1, #0x17
0x009a84:	movs    	r0, #0xf1
0x009a86:	lsls    	r0, r0, #9
0x009a88:	bl      	#0x7e90
0x009a8c:	movs    	r1, #0
0x009a8e:	movs    	r2, #0
0x009a90:	str     	r2, [sp, #8]
0x009a92:	str     	r1, [sp]
0x009a94:	str     	r1, [sp, #4]
0x009a96:	movs    	r1, #0xe1
0x009a98:	movs    	r2, #0x1d
0x009a9a:	adds    	r3, r4, #0
0x009a9c:	movs    	r0, #0xf1
0x009a9e:	lsls    	r0, r0, #9
0x009aa0:	bl      	#0x7e90
0x009aa4:	movs    	r1, #0
0x009aa6:	adds    	r6, r0, #0
0x009aa8:	movs    	r2, #0
0x009aaa:	str     	r2, [sp, #8]
0x009aac:	str     	r1, [sp]
0x009aae:	str     	r1, [sp, #4]
0x009ab0:	movs    	r1, #0xe1
0x009ab2:	movs    	r2, #0x18
0x009ab4:	movs    	r0, #0xf1
0x009ab6:	adds    	r3, r4, #0
0x009ab8:	lsls    	r0, r0, #9
0x009aba:	bl      	#0x7e90
0x009abe:	ldr     	r7, [r0, #0xc]
0x009ac0:	movs    	r1, #0
0x009ac2:	movs    	r2, #0
0x009ac4:	str     	r2, [sp, #8]
0x009ac6:	str     	r1, [sp]
0x009ac8:	str     	r1, [sp, #4]
0x009aca:	movs    	r1, #0xe1
0x009acc:	movs    	r2, #0x18
0x009ace:	movs    	r0, #0xf1
0x009ad0:	adds    	r3, r4, #0
0x009ad2:	lsls    	r0, r0, #9
0x009ad4:	bl      	#0x7e90
0x009ad8:	ldr     	r3, [r0, #8]
0x009ada:	movs    	r2, #0
0x009adc:	str     	r2, [sp, #8]
0x009ade:	adds    	r2, r5, #0
0x009ae0:	movs    	r0, #0xf1
0x009ae2:	movs    	r1, #0x52
0x009ae4:	lsls    	r0, r0, #9
0x009ae6:	str     	r7, [sp]
0x009ae8:	str     	r6, [sp, #4]
0x009aea:	bl      	#0x7e90
0x009aee:	movs    	r1, #0
0x009af0:	movs    	r2, #0
0x009af2:	str     	r1, [sp]
0x009af4:	str     	r1, [sp, #4]
0x009af6:	movs    	r1, #0x19
0x009af8:	str     	r2, [sp, #8]
0x009afa:	adds    	r3, r4, #0
0x009afc:	movs    	r0, #0xf1
0x009afe:	lsls    	r0, r0, #9
0x009b00:	ldr     	r2, [sp, #0x10]
0x009b02:	bl      	#0x7e90
0x009b06:	movs    	r1, #0
0x009b08:	movs    	r2, #0
0x009b0a:	str     	r1, [sp]
0x009b0c:	str     	r1, [sp, #4]
0x009b0e:	movs    	r1, #0x19
0x009b10:	str     	r2, [sp, #8]
0x009b12:	adds    	r3, r4, #0
0x009b14:	movs    	r0, #0xf1
0x009b16:	lsls    	r0, r0, #9
0x009b18:	ldr     	r2, [sp, #0x14]
0x009b1a:	bl      	#0x7e90
0x009b1e:	movs    	r1, #0
0x009b20:	movs    	r2, #0
0x009b22:	str     	r1, [sp]
0x009b24:	str     	r1, [sp, #4]
0x009b26:	movs    	r1, #0x19
0x009b28:	str     	r2, [sp, #8]
0x009b2a:	adds    	r3, r4, #0
0x009b2c:	movs    	r0, #0xf1
0x009b2e:	lsls    	r0, r0, #9
0x009b30:	ldr     	r2, [sp, #0x18]
0x009b32:	bl      	#0x7e90
0x009b36:	movs    	r1, #0
0x009b38:	movs    	r2, #0
0x009b3a:	str     	r2, [sp, #8]
0x009b3c:	str     	r1, [sp]
0x009b3e:	str     	r1, [sp, #4]
0x009b40:	movs    	r1, #0x1b
0x009b42:	movs    	r2, #1
0x009b44:	adds    	r3, r4, #0
0x009b46:	movs    	r0, #0xf1
0x009b48:	lsls    	r0, r0, #9
0x009b4a:	bl      	#0x7e90
0x009b4e:	add     	sp, #0x1c
0x009b50:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_009b54 =====
0x009b54:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x009b56:	sub     	sp, #0x18
0x009b58:	movs    	r1, #0
0x009b5a:	adds    	r4, r2, #0
0x009b5c:	movs    	r2, #0
0x009b5e:	str     	r2, [sp, #8]
0x009b60:	str     	r1, [sp]
0x009b62:	str     	r1, [sp, #4]
0x009b64:	movs    	r7, #0xf1
0x009b66:	movs    	r5, #0
0x009b68:	adds    	r3, r5, #0
0x009b6a:	lsls    	r7, r7, #9
0x009b6c:	movs    	r1, #0x14
0x009b6e:	movs    	r2, #0x4e
0x009b70:	movs    	r6, #0xb7
0x009b72:	adds    	r0, r7, #0
0x009b74:	bl      	#0x7e90
0x009b78:	movs    	r1, #0
0x009b7a:	movs    	r2, #0
0x009b7c:	str     	r2, [sp, #8]
0x009b7e:	str     	r1, [sp]
0x009b80:	str     	r1, [sp, #4]
0x009b82:	movs    	r1, #0x17
0x009b84:	adds    	r2, r6, #0
0x009b86:	adds    	r3, r5, #0
0x009b88:	adds    	r0, r7, #0
0x009b8a:	bl      	#0x7e90
0x009b8e:	movs    	r1, #0
0x009b90:	movs    	r2, #0
0x009b92:	str     	r2, [sp, #8]
0x009b94:	str     	r1, [sp]
0x009b96:	str     	r1, [sp, #4]
0x009b98:	movs    	r1, #0xe1
0x009b9a:	movs    	r2, #0x1d
0x009b9c:	adds    	r3, r5, #0
0x009b9e:	adds    	r0, r7, #0
0x009ba0:	bl      	#0x7e90
0x009ba4:	movs    	r1, #0
0x009ba6:	movs    	r2, #0
0x009ba8:	str     	r2, [sp, #8]
0x009baa:	str     	r1, [sp]
0x009bac:	str     	r1, [sp, #4]
0x009bae:	movs    	r1, #0xe1
0x009bb0:	movs    	r2, #0x18
0x009bb2:	str     	r0, [sp, #0x14]
0x009bb4:	adds    	r3, r5, #0
0x009bb6:	adds    	r0, r7, #0
0x009bb8:	bl      	#0x7e90
0x009bbc:	ldr     	r0, [r0, #0xc]
0x009bbe:	movs    	r1, #0
0x009bc0:	movs    	r2, #0
0x009bc2:	str     	r2, [sp, #8]
0x009bc4:	str     	r1, [sp]
0x009bc6:	str     	r1, [sp, #4]
0x009bc8:	movs    	r1, #0xe1
0x009bca:	movs    	r2, #0x18
0x009bcc:	adds    	r3, r5, #0
0x009bce:	str     	r0, [sp, #0x10]
0x009bd0:	adds    	r0, r7, #0
0x009bd2:	bl      	#0x7e90
0x009bd6:	ldr     	r3, [r0, #8]
0x009bd8:	ldr     	r1, [sp, #0x14]
0x009bda:	ldr     	r0, [sp, #0x10]
0x009bdc:	movs    	r2, #0
0x009bde:	str     	r2, [sp, #8]
0x009be0:	str     	r1, [sp, #4]
0x009be2:	movs    	r1, #0x52
0x009be4:	adds    	r2, r6, #0
0x009be6:	str     	r0, [sp]
0x009be8:	adds    	r0, r7, #0
0x009bea:	bl      	#0x7e90
0x009bee:	movs    	r1, #0
0x009bf0:	movs    	r2, #0
0x009bf2:	str     	r1, [sp]
0x009bf4:	str     	r1, [sp, #4]
0x009bf6:	movs    	r1, #0x19
0x009bf8:	str     	r2, [sp, #8]
0x009bfa:	adds    	r3, r5, #0
0x009bfc:	adds    	r0, r7, #0
0x009bfe:	ldr     	r2, [sp, #0x18]
0x009c00:	bl      	#0x7e90
0x009c04:	cmp     	r4, #0
0x009c06:	bne     	#0x9c36
0x009c08:	movs    	r1, #0
0x009c0a:	movs    	r2, #0
0x009c0c:	str     	r2, [sp, #8]
0x009c0e:	str     	r1, [sp]
0x009c10:	str     	r1, [sp, #4]
0x009c12:	movs    	r1, #0x19
0x009c14:	movs    	r2, #1
0x009c16:	adds    	r3, r5, #0
0x009c18:	adds    	r0, r7, #0
0x009c1a:	bl      	#0x7e90
0x009c1e:	movs    	r1, #0
0x009c20:	movs    	r2, #0
0x009c22:	str     	r1, [sp]
0x009c24:	str     	r1, [sp, #4]
0x009c26:	movs    	r1, #0x19
0x009c28:	str     	r2, [sp, #8]
0x009c2a:	adds    	r3, r5, #0
0x009c2c:	adds    	r0, r7, #0
0x009c2e:	ldr     	r2, [sp, #0x1c]
0x009c30:	bl      	#0x7e90
0x009c34:	b       	#0x9c8a
0x009c36:	movs    	r1, #0
0x009c38:	movs    	r2, #0
0x009c3a:	str     	r2, [sp, #8]
0x009c3c:	str     	r1, [sp]
0x009c3e:	str     	r1, [sp, #4]
0x009c40:	movs    	r1, #0x11
0x009c42:	adds    	r2, r4, #0
0x009c44:	movs    	r3, #4
0x009c46:	adds    	r0, r7, #0
0x009c48:	bl      	#0x7e90
0x009c4c:	movs    	r2, #0
0x009c4e:	movs    	r1, #0
0x009c50:	str     	r2, [sp, #8]
0x009c52:	adds    	r6, r0, #0
0x009c54:	adds    	r2, r0, #0
0x009c56:	str     	r1, [sp]
0x009c58:	str     	r1, [sp, #4]
0x009c5a:	movs    	r1, #0x19
0x009c5c:	movs    	r0, #0xf1
0x009c5e:	movs    	r5, #0
0x009c60:	movs    	r3, #0
0x009c62:	lsls    	r0, r0, #9
0x009c64:	bl      	#0x7e90
0x009c68:	cmp     	r6, #0
0x009c6a:	ble     	#0x9c8a
0x009c6c:	movs    	r1, #0
0x009c6e:	str     	r1, [sp]
0x009c70:	str     	r1, [sp, #4]
0x009c72:	movs    	r2, #0
0x009c74:	str     	r2, [sp, #8]
0x009c76:	lsls    	r0, r5, #2
0x009c78:	ldr     	r2, [r4, r0]
0x009c7a:	movs    	r1, #0x19
0x009c7c:	movs    	r3, #0
0x009c7e:	adds    	r0, r7, #0
0x009c80:	bl      	#0x7e90
0x009c84:	adds    	r5, #1

; ===== candidate_009ca4 =====
0x009ca4:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x009ca6:	sub     	sp, #0xc
0x009ca8:	movs    	r1, #0
0x009caa:	movs    	r2, #0
0x009cac:	str     	r2, [sp, #8]
0x009cae:	str     	r1, [sp]
0x009cb0:	str     	r1, [sp, #4]
0x009cb2:	movs    	r4, #0
0x009cb4:	adds    	r3, r4, #0
0x009cb6:	movs    	r1, #0x14
0x009cb8:	movs    	r2, #0x4e
0x009cba:	movs    	r0, #0xf1
0x009cbc:	movs    	r5, #0xb7
0x009cbe:	lsls    	r0, r0, #9
0x009cc0:	bl      	#0x7e90
0x009cc4:	movs    	r1, #0
0x009cc6:	movs    	r2, #0
0x009cc8:	str     	r2, [sp, #8]
0x009cca:	str     	r1, [sp]
0x009ccc:	str     	r1, [sp, #4]
0x009cce:	adds    	r3, r4, #0
0x009cd0:	adds    	r2, r5, #0
0x009cd2:	movs    	r1, #0x17
0x009cd4:	movs    	r0, #0xf1
0x009cd6:	lsls    	r0, r0, #9
0x009cd8:	bl      	#0x7e90
0x009cdc:	movs    	r1, #0
0x009cde:	movs    	r2, #0
0x009ce0:	str     	r2, [sp, #8]
0x009ce2:	str     	r1, [sp]
0x009ce4:	str     	r1, [sp, #4]
0x009ce6:	movs    	r1, #0xe1
0x009ce8:	movs    	r2, #0x1d
0x009cea:	adds    	r3, r4, #0
0x009cec:	movs    	r0, #0xf1
0x009cee:	lsls    	r0, r0, #9
0x009cf0:	bl      	#0x7e90
0x009cf4:	movs    	r1, #0
0x009cf6:	adds    	r6, r0, #0
0x009cf8:	movs    	r2, #0
0x009cfa:	str     	r2, [sp, #8]
0x009cfc:	str     	r1, [sp]
0x009cfe:	str     	r1, [sp, #4]
0x009d00:	movs    	r1, #0xe1
0x009d02:	movs    	r2, #0x18
0x009d04:	movs    	r0, #0xf1
0x009d06:	adds    	r3, r4, #0
0x009d08:	lsls    	r0, r0, #9
0x009d0a:	bl      	#0x7e90
0x009d0e:	ldr     	r7, [r0, #0xc]
0x009d10:	movs    	r1, #0
0x009d12:	movs    	r2, #0
0x009d14:	str     	r2, [sp, #8]
0x009d16:	str     	r1, [sp]
0x009d18:	str     	r1, [sp, #4]
0x009d1a:	movs    	r1, #0xe1
0x009d1c:	movs    	r2, #0x18
0x009d1e:	movs    	r0, #0xf1
0x009d20:	adds    	r3, r4, #0
0x009d22:	lsls    	r0, r0, #9
0x009d24:	bl      	#0x7e90
0x009d28:	ldr     	r3, [r0, #8]
0x009d2a:	movs    	r2, #0
0x009d2c:	str     	r2, [sp, #8]
0x009d2e:	adds    	r2, r5, #0
0x009d30:	movs    	r0, #0xf1
0x009d32:	movs    	r1, #0x52
0x009d34:	lsls    	r0, r0, #9
0x009d36:	str     	r7, [sp]
0x009d38:	str     	r6, [sp, #4]
0x009d3a:	bl      	#0x7e90
0x009d3e:	movs    	r1, #0
0x009d40:	movs    	r2, #0
0x009d42:	str     	r1, [sp]
0x009d44:	str     	r1, [sp, #4]
0x009d46:	movs    	r1, #0x19
0x009d48:	str     	r2, [sp, #8]
0x009d4a:	adds    	r3, r4, #0
0x009d4c:	movs    	r0, #0xf1
0x009d4e:	lsls    	r0, r0, #9
0x009d50:	ldr     	r2, [sp, #0xc]
0x009d52:	bl      	#0x7e90
0x009d56:	movs    	r1, #0
0x009d58:	movs    	r2, #0
0x009d5a:	str     	r1, [sp]
0x009d5c:	str     	r1, [sp, #4]
0x009d5e:	movs    	r1, #0x19
0x009d60:	str     	r2, [sp, #8]
0x009d62:	adds    	r3, r4, #0
0x009d64:	movs    	r0, #0xf1
0x009d66:	lsls    	r0, r0, #9
0x009d68:	ldr     	r2, [sp, #0x10]
0x009d6a:	bl      	#0x7e90
0x009d6e:	movs    	r1, #0
0x009d70:	movs    	r2, #0
0x009d72:	str     	r2, [sp, #8]
0x009d74:	str     	r1, [sp]
0x009d76:	str     	r1, [sp, #4]
0x009d78:	movs    	r1, #0x1b
0x009d7a:	movs    	r2, #1
0x009d7c:	adds    	r3, r4, #0
0x009d7e:	movs    	r0, #0xf1
0x009d80:	lsls    	r0, r0, #9
0x009d82:	bl      	#0x7e90
0x009d86:	add     	sp, #0x14
0x009d88:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_009d8c =====
0x009d8c:	push    	{r0, r4, r5, r6, r7, lr}
0x009d8e:	sub     	sp, #0x10
0x009d90:	movs    	r1, #0
0x009d92:	movs    	r4, #0
0x009d94:	movs    	r2, #0
0x009d96:	str     	r2, [sp, #8]
0x009d98:	adds    	r3, r4, #0
0x009d9a:	str     	r1, [sp]
0x009d9c:	str     	r1, [sp, #4]
0x009d9e:	movs    	r5, #0xb7
0x009da0:	adds    	r2, r5, #0
0x009da2:	movs    	r1, #0x17
0x009da4:	movs    	r0, #0xf1
0x009da6:	lsls    	r0, r0, #9
0x009da8:	bl      	#0x7e90
0x009dac:	movs    	r1, #0
0x009dae:	movs    	r2, #0
0x009db0:	str     	r2, [sp, #8]
0x009db2:	str     	r1, [sp]
0x009db4:	str     	r1, [sp, #4]
0x009db6:	movs    	r1, #0xe1
0x009db8:	movs    	r2, #0x1d
0x009dba:	adds    	r3, r4, #0
0x009dbc:	movs    	r0, #0xf1
0x009dbe:	lsls    	r0, r0, #9
0x009dc0:	bl      	#0x7e90
0x009dc4:	movs    	r1, #0
0x009dc6:	adds    	r6, r0, #0
0x009dc8:	movs    	r2, #0
0x009dca:	str     	r2, [sp, #8]
0x009dcc:	str     	r1, [sp]
0x009dce:	str     	r1, [sp, #4]
0x009dd0:	movs    	r1, #0xe1
0x009dd2:	movs    	r2, #0x18
0x009dd4:	movs    	r0, #0xf1
0x009dd6:	adds    	r3, r4, #0
0x009dd8:	lsls    	r0, r0, #9
0x009dda:	bl      	#0x7e90
0x009dde:	ldr     	r7, [r0, #0xc]
0x009de0:	movs    	r1, #0
0x009de2:	movs    	r2, #0
0x009de4:	str     	r2, [sp, #8]
0x009de6:	str     	r1, [sp]
0x009de8:	str     	r1, [sp, #4]
0x009dea:	movs    	r1, #0xe1
0x009dec:	movs    	r2, #0x18
0x009dee:	movs    	r0, #0xf1
0x009df0:	adds    	r3, r4, #0
0x009df2:	lsls    	r0, r0, #9
0x009df4:	bl      	#0x7e90
0x009df8:	ldr     	r3, [r0, #8]
0x009dfa:	movs    	r2, #0
0x009dfc:	str     	r2, [sp, #8]
0x009dfe:	adds    	r2, r5, #0
0x009e00:	movs    	r0, #0xf1
0x009e02:	movs    	r1, #0x52
0x009e04:	lsls    	r0, r0, #9
0x009e06:	str     	r7, [sp]
0x009e08:	str     	r6, [sp, #4]
0x009e0a:	bl      	#0x7e90
0x009e0e:	movs    	r1, #0
0x009e10:	movs    	r2, #0
0x009e12:	str     	r1, [sp]
0x009e14:	str     	r1, [sp, #4]
0x009e16:	movs    	r1, #0x19
0x009e18:	str     	r2, [sp, #8]
0x009e1a:	adds    	r3, r4, #0
0x009e1c:	movs    	r0, #0xf1
0x009e1e:	lsls    	r0, r0, #9
0x009e20:	ldr     	r2, [sp, #0x10]
0x009e22:	bl      	#0x7e90
0x009e26:	movs    	r1, #0
0x009e28:	movs    	r2, #0
0x009e2a:	str     	r2, [sp, #8]
0x009e2c:	str     	r1, [sp]
0x009e2e:	str     	r1, [sp, #4]
0x009e30:	movs    	r1, #0x14
0x009e32:	movs    	r2, #0x4e
0x009e34:	adds    	r3, r4, #0
0x009e36:	movs    	r0, #0xf1
0x009e38:	lsls    	r0, r0, #9
0x009e3a:	bl      	#0x7e90
0x009e3e:	movs    	r1, #0
0x009e40:	movs    	r2, #0
0x009e42:	str     	r2, [sp, #8]
0x009e44:	str     	r1, [sp]
0x009e46:	str     	r1, [sp, #4]
0x009e48:	movs    	r1, #0x1b
0x009e4a:	movs    	r2, #1
0x009e4c:	adds    	r3, r4, #0
0x009e4e:	movs    	r0, #0xf1
0x009e50:	lsls    	r0, r0, #9
0x009e52:	bl      	#0x7e90
0x009e56:	add     	sp, #0x14
0x009e58:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_009e5c =====
0x009e5c:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x009e5e:	sub     	sp, #0xc
0x009e60:	movs    	r1, #0
0x009e62:	movs    	r2, #0
0x009e64:	str     	r2, [sp, #8]
0x009e66:	str     	r1, [sp]
0x009e68:	str     	r1, [sp, #4]
0x009e6a:	movs    	r4, #0
0x009e6c:	adds    	r3, r4, #0
0x009e6e:	movs    	r1, #0x14
0x009e70:	movs    	r2, #0x4e
0x009e72:	movs    	r0, #0xf1
0x009e74:	movs    	r5, #0xb7
0x009e76:	lsls    	r0, r0, #9
0x009e78:	bl      	#0x7e90
0x009e7c:	movs    	r1, #0
0x009e7e:	movs    	r2, #0
0x009e80:	str     	r2, [sp, #8]
0x009e82:	str     	r1, [sp]
0x009e84:	str     	r1, [sp, #4]
0x009e86:	adds    	r3, r4, #0
0x009e88:	adds    	r2, r5, #0
0x009e8a:	movs    	r1, #0x17
0x009e8c:	movs    	r0, #0xf1
0x009e8e:	lsls    	r0, r0, #9
0x009e90:	bl      	#0x7e90
0x009e94:	movs    	r1, #0
0x009e96:	movs    	r2, #0
0x009e98:	str     	r2, [sp, #8]
0x009e9a:	str     	r1, [sp]
0x009e9c:	str     	r1, [sp, #4]
0x009e9e:	movs    	r1, #0xe1
0x009ea0:	movs    	r2, #0x1d
0x009ea2:	adds    	r3, r4, #0
0x009ea4:	movs    	r0, #0xf1
0x009ea6:	lsls    	r0, r0, #9
0x009ea8:	bl      	#0x7e90
0x009eac:	movs    	r1, #0
0x009eae:	adds    	r6, r0, #0
0x009eb0:	movs    	r2, #0
0x009eb2:	str     	r2, [sp, #8]
0x009eb4:	str     	r1, [sp]
0x009eb6:	str     	r1, [sp, #4]
0x009eb8:	movs    	r1, #0xe1
0x009eba:	movs    	r2, #0x18
0x009ebc:	movs    	r0, #0xf1
0x009ebe:	adds    	r3, r4, #0
0x009ec0:	lsls    	r0, r0, #9
0x009ec2:	bl      	#0x7e90
0x009ec6:	ldr     	r7, [r0, #0xc]
0x009ec8:	movs    	r1, #0
0x009eca:	movs    	r2, #0
0x009ecc:	str     	r2, [sp, #8]
0x009ece:	str     	r1, [sp]
0x009ed0:	str     	r1, [sp, #4]
0x009ed2:	movs    	r1, #0xe1
0x009ed4:	movs    	r2, #0x18
0x009ed6:	movs    	r0, #0xf1
0x009ed8:	adds    	r3, r4, #0
0x009eda:	lsls    	r0, r0, #9
0x009edc:	bl      	#0x7e90
0x009ee0:	ldr     	r3, [r0, #8]
0x009ee2:	movs    	r2, #0
0x009ee4:	str     	r2, [sp, #8]
0x009ee6:	adds    	r2, r5, #0
0x009ee8:	movs    	r0, #0xf1
0x009eea:	movs    	r1, #0x52
0x009eec:	lsls    	r0, r0, #9
0x009eee:	str     	r7, [sp]
0x009ef0:	str     	r6, [sp, #4]
0x009ef2:	bl      	#0x7e90
0x009ef6:	movs    	r1, #0
0x009ef8:	movs    	r2, #0
0x009efa:	str     	r1, [sp]
0x009efc:	str     	r1, [sp, #4]
0x009efe:	movs    	r1, #0x19
0x009f00:	str     	r2, [sp, #8]
0x009f02:	adds    	r3, r4, #0
0x009f04:	movs    	r0, #0xf1
0x009f06:	lsls    	r0, r0, #9
0x009f08:	ldr     	r2, [sp, #0xc]
0x009f0a:	bl      	#0x7e90
0x009f0e:	movs    	r1, #0
0x009f10:	movs    	r2, #0
0x009f12:	str     	r1, [sp]
0x009f14:	str     	r1, [sp, #4]
0x009f16:	movs    	r1, #0x19
0x009f18:	str     	r2, [sp, #8]
0x009f1a:	adds    	r3, r4, #0
0x009f1c:	movs    	r0, #0xf1
0x009f1e:	lsls    	r0, r0, #9
0x009f20:	ldr     	r2, [sp, #0x10]
0x009f22:	bl      	#0x7e90
0x009f26:	movs    	r1, #0
0x009f28:	movs    	r2, #0
0x009f2a:	str     	r1, [sp]
0x009f2c:	str     	r1, [sp, #4]
0x009f2e:	movs    	r1, #0x19
0x009f30:	str     	r2, [sp, #8]
0x009f32:	adds    	r3, r4, #0
0x009f34:	movs    	r0, #0xf1
0x009f36:	lsls    	r0, r0, #9
0x009f38:	ldr     	r2, [sp, #0x14]
0x009f3a:	bl      	#0x7e90
0x009f3e:	movs    	r1, #0
0x009f40:	movs    	r2, #0
0x009f42:	str     	r1, [sp]
0x009f44:	str     	r1, [sp, #4]
0x009f46:	movs    	r1, #0x19
0x009f48:	str     	r2, [sp, #8]
0x009f4a:	adds    	r3, r4, #0
0x009f4c:	movs    	r0, #0xf1
0x009f4e:	lsls    	r0, r0, #9
0x009f50:	ldr     	r2, [sp, #0x18]
0x009f52:	bl      	#0x7e90
0x009f56:	movs    	r1, #0
0x009f58:	movs    	r2, #0
0x009f5a:	str     	r2, [sp, #8]
0x009f5c:	str     	r1, [sp]
0x009f5e:	str     	r1, [sp, #4]
0x009f60:	movs    	r1, #0x1b
0x009f62:	movs    	r2, #1
0x009f64:	adds    	r3, r4, #0
0x009f66:	movs    	r0, #0xf1
0x009f68:	lsls    	r0, r0, #9
0x009f6a:	bl      	#0x7e90
0x009f6e:	add     	sp, #0x1c
0x009f70:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_009f74 =====
0x009f74:	push    	{r4, r5, r6, r7, lr}
0x009f76:	sub     	sp, #0xc
0x009f78:	movs    	r1, #0
0x009f7a:	movs    	r4, #0
0x009f7c:	movs    	r2, #0
0x009f7e:	str     	r2, [sp, #8]
0x009f80:	adds    	r3, r4, #0
0x009f82:	str     	r1, [sp]
0x009f84:	str     	r1, [sp, #4]
0x009f86:	movs    	r5, #0x33
0x009f88:	adds    	r2, r5, #0
0x009f8a:	movs    	r1, #0x17
0x009f8c:	movs    	r0, #0xf1
0x009f8e:	lsls    	r0, r0, #9
0x009f90:	bl      	#0x7e90
0x009f94:	movs    	r1, #0
0x009f96:	movs    	r2, #0
0x009f98:	str     	r2, [sp, #8]
0x009f9a:	str     	r1, [sp]
0x009f9c:	str     	r1, [sp, #4]
0x009f9e:	movs    	r1, #0xe1
0x009fa0:	movs    	r2, #0x1d
0x009fa2:	adds    	r3, r4, #0
0x009fa4:	movs    	r0, #0xf1
0x009fa6:	lsls    	r0, r0, #9
0x009fa8:	bl      	#0x7e90
0x009fac:	movs    	r1, #0
0x009fae:	adds    	r6, r0, #0
0x009fb0:	movs    	r2, #0
0x009fb2:	str     	r2, [sp, #8]
0x009fb4:	str     	r1, [sp]
0x009fb6:	str     	r1, [sp, #4]
0x009fb8:	movs    	r1, #0xe1
0x009fba:	movs    	r2, #0x18
0x009fbc:	movs    	r0, #0xf1
0x009fbe:	adds    	r3, r4, #0
0x009fc0:	lsls    	r0, r0, #9
0x009fc2:	bl      	#0x7e90
0x009fc6:	ldr     	r7, [r0, #0xc]
0x009fc8:	movs    	r1, #0
0x009fca:	movs    	r2, #0
0x009fcc:	str     	r2, [sp, #8]
0x009fce:	str     	r1, [sp]
0x009fd0:	str     	r1, [sp, #4]
0x009fd2:	movs    	r1, #0xe1
0x009fd4:	movs    	r2, #0x18
0x009fd6:	movs    	r0, #0xf1
0x009fd8:	adds    	r3, r4, #0
0x009fda:	lsls    	r0, r0, #9
0x009fdc:	bl      	#0x7e90
0x009fe0:	ldr     	r3, [r0, #8]
0x009fe2:	movs    	r2, #0
0x009fe4:	str     	r2, [sp, #8]
0x009fe6:	adds    	r2, r5, #0
0x009fe8:	movs    	r0, #0xf1
0x009fea:	movs    	r1, #0x52
0x009fec:	lsls    	r0, r0, #9
0x009fee:	str     	r7, [sp]
0x009ff0:	str     	r6, [sp, #4]
0x009ff2:	bl      	#0x7e90
0x009ff6:	movs    	r1, #0
0x009ff8:	ldr     	r0, [pc, #0x34]
0x009ffa:	str     	r1, [sp]
0x009ffc:	str     	r1, [sp, #4]
0x009ffe:	movs    	r2, #0
0x00a000:	str     	r2, [sp, #8]
0x00a002:	add     	r0, sb
0x00a004:	ldr     	r2, [r0]
0x00a006:	movs    	r0, #0xf1
0x00a008:	movs    	r1, #0x1a
0x00a00a:	adds    	r3, r4, #0
0x00a00c:	lsls    	r0, r0, #9
0x00a00e:	bl      	#0x7e90
0x00a012:	movs    	r1, #0
0x00a014:	movs    	r2, #0
0x00a016:	str     	r2, [sp, #8]
0x00a018:	str     	r1, [sp]
0x00a01a:	str     	r1, [sp, #4]
0x00a01c:	movs    	r1, #0x1b
0x00a01e:	movs    	r2, #1
0x00a020:	adds    	r3, r4, #0
0x00a022:	movs    	r0, #0xf1
0x00a024:	lsls    	r0, r0, #9
0x00a026:	bl      	#0x7e90
0x00a02a:	add     	sp, #0xc
0x00a02c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a034 =====
0x00a034:	push    	{r4, r5, r6, r7, lr}
0x00a036:	sub     	sp, #0xc
0x00a038:	movs    	r1, #0
0x00a03a:	movs    	r5, #0
0x00a03c:	movs    	r2, #0
0x00a03e:	str     	r2, [sp, #8]
0x00a040:	adds    	r3, r5, #0
0x00a042:	str     	r1, [sp]
0x00a044:	str     	r1, [sp, #4]
0x00a046:	movs    	r4, #0xc3
0x00a048:	adds    	r2, r4, #0
0x00a04a:	movs    	r1, #0x17
0x00a04c:	movs    	r0, #0xf1
0x00a04e:	lsls    	r0, r0, #9
0x00a050:	bl      	#0x7e90
0x00a054:	movs    	r1, #0
0x00a056:	movs    	r2, #0
0x00a058:	str     	r2, [sp, #8]
0x00a05a:	str     	r1, [sp]
0x00a05c:	str     	r1, [sp, #4]
0x00a05e:	movs    	r1, #0xe1
0x00a060:	movs    	r2, #0x1d
0x00a062:	adds    	r3, r5, #0
0x00a064:	movs    	r0, #0xf1
0x00a066:	lsls    	r0, r0, #9
0x00a068:	bl      	#0x7e90
0x00a06c:	movs    	r1, #0
0x00a06e:	adds    	r6, r0, #0
0x00a070:	movs    	r2, #0
0x00a072:	str     	r2, [sp, #8]
0x00a074:	str     	r1, [sp]
0x00a076:	str     	r1, [sp, #4]
0x00a078:	movs    	r1, #0xe1
0x00a07a:	movs    	r2, #0x18
0x00a07c:	movs    	r0, #0xf1
0x00a07e:	adds    	r3, r5, #0
0x00a080:	lsls    	r0, r0, #9
0x00a082:	bl      	#0x7e90
0x00a086:	ldr     	r7, [r0, #0xc]
0x00a088:	movs    	r1, #0
0x00a08a:	movs    	r2, #0
0x00a08c:	str     	r2, [sp, #8]
0x00a08e:	str     	r1, [sp]
0x00a090:	str     	r1, [sp, #4]
0x00a092:	movs    	r1, #0xe1
0x00a094:	movs    	r2, #0x18
0x00a096:	movs    	r0, #0xf1
0x00a098:	adds    	r3, r5, #0
0x00a09a:	lsls    	r0, r0, #9
0x00a09c:	bl      	#0x7e90
0x00a0a0:	ldr     	r3, [r0, #8]
0x00a0a2:	movs    	r2, #0
0x00a0a4:	str     	r2, [sp, #8]
0x00a0a6:	adds    	r2, r4, #0
0x00a0a8:	movs    	r0, #0xf1
0x00a0aa:	movs    	r1, #0x52
0x00a0ac:	lsls    	r0, r0, #9
0x00a0ae:	str     	r7, [sp]
0x00a0b0:	str     	r6, [sp, #4]
0x00a0b2:	bl      	#0x7e90
0x00a0b6:	movs    	r1, #0
0x00a0b8:	str     	r1, [sp]
0x00a0ba:	str     	r1, [sp, #4]
0x00a0bc:	movs    	r2, #0
0x00a0be:	movs    	r1, #0x1b
0x00a0c0:	adds    	r3, r5, #0
0x00a0c2:	movs    	r0, #0xf1
0x00a0c4:	lsls    	r0, r0, #9
0x00a0c6:	str     	r2, [sp, #8]
0x00a0c8:	bl      	#0x7e90
0x00a0cc:	add     	sp, #0xc
0x00a0ce:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a0d0 =====
0x00a0d0:	push    	{r4, r5, lr}
0x00a0d2:	sub     	sp, #0xc
0x00a0d4:	movs    	r2, #0
0x00a0d6:	movs    	r1, #0
0x00a0d8:	str     	r2, [sp, #8]
0x00a0da:	adds    	r4, r0, #0
0x00a0dc:	adds    	r2, r0, #0
0x00a0de:	str     	r1, [sp]
0x00a0e0:	str     	r1, [sp, #4]
0x00a0e2:	movs    	r1, #0x11
0x00a0e4:	movs    	r0, #0xf1
0x00a0e6:	movs    	r3, #4
0x00a0e8:	lsls    	r0, r0, #9
0x00a0ea:	bl      	#0x7e90
0x00a0ee:	movs    	r1, #0
0x00a0f0:	cmp     	r0, #0
0x00a0f2:	ble     	#0xa10e
0x00a0f4:	movs    	r3, #0
0x00a0f6:	lsls    	r2, r1, #2
0x00a0f8:	ldr     	r2, [r4, r2]
0x00a0fa:	cmp     	r2, #0
0x00a0fc:	beq     	#0xa108
0x00a0fe:	movs    	r5, #0x33
0x00a100:	ldrb    	r5, [r5, r2]
0x00a102:	cmp     	r5, #0
0x00a104:	beq     	#0xa108
0x00a106:	strb    	r3, [r2, #0x14]
0x00a108:	adds    	r1, #1
0x00a10a:	cmp     	r1, r0
0x00a10c:	blt     	#0xa0f6
0x00a10e:	add     	sp, #0xc
0x00a110:	pop     	{r4, r5, pc}

; ===== candidate_00a12c =====
0x00a12c:	push    	{r4, r5, r6, r7, lr}
0x00a12e:	adds    	r5, r0, #0
0x00a130:	ldr     	r0, [r0]
0x00a132:	adds    	r6, r1, #0
0x00a134:	lsls    	r1, r1, #2
0x00a136:	ldr     	r4, [r0, r1]
0x00a138:	sub     	sp, #0x14
0x00a13a:	cmp     	r4, #0
0x00a13c:	beq     	#0xa1a0
0x00a13e:	movs    	r1, #0
0x00a140:	movs    	r2, #0
0x00a142:	str     	r2, [sp, #8]
0x00a144:	str     	r1, [sp]
0x00a146:	str     	r1, [sp, #4]
0x00a148:	ldr     	r0, [r4, #0x7c]
0x00a14a:	movs    	r7, #0
0x00a14c:	ldr     	r2, [r0, #0x1c]
0x00a14e:	movs    	r0, #0xf1
0x00a150:	adds    	r3, r7, #0
0x00a152:	movs    	r1, #0x6e
0x00a154:	lsls    	r0, r0, #9
0x00a156:	bl      	#0x7e90
0x00a15a:	movs    	r2, #0
0x00a15c:	str     	r2, [sp, #8]
0x00a15e:	movs    	r1, #0
0x00a160:	adds    	r2, r0, #0
0x00a162:	movs    	r0, #0xf1
0x00a164:	str     	r1, [sp]
0x00a166:	str     	r1, [sp, #4]
0x00a168:	movs    	r1, #0x74
0x00a16a:	lsls    	r0, r0, #9
0x00a16c:	adds    	r3, r7, #0
0x00a16e:	bl      	#0x7e90
0x00a172:	str     	r0, [sp, #0x10]
0x00a174:	adds    	r0, r4, #0
0x00a176:	bl      	#0x7798
0x00a17a:	movs    	r1, #0
0x00a17c:	movs    	r2, #0
0x00a17e:	str     	r2, [sp, #8]
0x00a180:	str     	r1, [sp]
0x00a182:	str     	r1, [sp, #4]
0x00a184:	movs    	r1, #3
0x00a186:	movs    	r2, #0x32
0x00a188:	adds    	r3, r7, #0
0x00a18a:	movs    	r0, #0xf1
0x00a18c:	lsls    	r0, r0, #9
0x00a18e:	bl      	#0x7e90
0x00a192:	ldr     	r1, [sp, #0x10]
0x00a194:	ldr     	r1, [r1]
0x00a196:	adds    	r0, r0, r1
0x00a198:	adds    	r0, #0x1e
0x00a19a:	ldr     	r1, [r5, #0x14]
0x00a19c:	lsls    	r2, r6, #1
0x00a19e:	strh    	r0, [r1, r2]
0x00a1a0:	add     	sp, #0x14
0x00a1a2:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a1a4 =====
0x00a1a4:	push    	{r4, r5, r6, r7, lr}
0x00a1a6:	sub     	sp, #0xc
0x00a1a8:	movs    	r2, #0
0x00a1aa:	movs    	r1, #0
0x00a1ac:	str     	r2, [sp, #8]
0x00a1ae:	adds    	r7, r0, #0
0x00a1b0:	adds    	r2, r0, #0
0x00a1b2:	str     	r1, [sp]
0x00a1b4:	str     	r1, [sp, #4]
0x00a1b6:	movs    	r1, #0x11
0x00a1b8:	movs    	r0, #0xf1
0x00a1ba:	movs    	r3, #4
0x00a1bc:	lsls    	r0, r0, #9
0x00a1be:	bl      	#0x7e90
0x00a1c2:	adds    	r6, r0, #0
0x00a1c4:	movs    	r4, #0
0x00a1c6:	cmp     	r0, #0
0x00a1c8:	ble     	#0xa1e4
0x00a1ca:	lsls    	r0, r4, #2
0x00a1cc:	ldr     	r5, [r7, r0]
0x00a1ce:	cmp     	r5, #0
0x00a1d0:	beq     	#0xa1de
0x00a1d2:	adds    	r0, r5, #0
0x00a1d4:	bl      	#0x7798
0x00a1d8:	movs    	r0, #0
0x00a1da:	adds    	r5, #0x80
0x00a1dc:	str     	r0, [r5, #4]
0x00a1de:	adds    	r4, #1
0x00a1e0:	cmp     	r4, r6
0x00a1e2:	blt     	#0xa1ca
0x00a1e4:	add     	sp, #0xc
0x00a1e6:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a1e8 =====
0x00a1e8:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x00a1ea:	adds    	r5, r1, #0
0x00a1ec:	ldr     	r1, [pc, #0x68]
0x00a1ee:	adds    	r4, r0, #0
0x00a1f0:	ldr     	r0, [r0]
0x00a1f2:	add     	r1, sb
0x00a1f4:	ldr     	r7, [r1, #0x2c]
0x00a1f6:	movs    	r6, #0xf1
0x00a1f8:	lsls    	r6, r6, #9
0x00a1fa:	cmp     	r0, r7
0x00a1fc:	sub     	sp, #0x10
0x00a1fe:	beq     	#0xa21a
0x00a200:	cmp     	r7, #0
0x00a202:	beq     	#0xa21a
0x00a204:	movs    	r1, #0
0x00a206:	movs    	r2, #0
0x00a208:	str     	r2, [sp, #8]
0x00a20a:	str     	r1, [sp]
0x00a20c:	str     	r1, [sp, #4]
0x00a20e:	movs    	r1, #9
0x00a210:	adds    	r2, r7, #0
0x00a212:	movs    	r3, #0
0x00a214:	adds    	r0, r6, #0
0x00a216:	bl      	#0x7e90
0x00a21a:	movs    	r2, #0
0x00a21c:	movs    	r1, #0
0x00a21e:	ldr     	r3, [pc, #0x3c]
0x00a220:	str     	r1, [sp]
0x00a222:	str     	r1, [sp, #4]
0x00a224:	str     	r2, [sp, #8]
0x00a226:	add     	r3, pc
0x00a228:	movs    	r1, #0x35
0x00a22a:	adds    	r0, r6, #0
0x00a22c:	ldr     	r2, [r4]
0x00a22e:	bl      	#0x7e90
0x00a232:	ldr     	r1, [pc, #0x24]
0x00a234:	movs    	r3, #0xe
0x00a236:	add     	r1, sb
0x00a238:	str     	r0, [r1, #0x2c]
0x00a23a:	ldr     	r0, [sp, #0x18]
0x00a23c:	str     	r0, [r1, #0x34]
0x00a23e:	ldr     	r0, [r4, #4]
0x00a240:	str     	r0, [r1, #0x30]
0x00a242:	ldr     	r0, [r5, #4]
0x00a244:	strb    	r0, [r1, #0xe]
0x00a246:	ldrb    	r0, [r4, #0x15]
0x00a248:	strb    	r0, [r1, #0xf]
0x00a24a:	ldrb    	r0, [r4, #0x16]
0x00a24c:	strb    	r0, [r1, #0x10]
0x00a24e:	ldrsh   	r0, [r5, r3]
0x00a250:	adds    	r1, #0x80
0x00a252:	str     	r0, [r1, #0x38]
0x00a254:	add     	sp, #0x1c
0x00a256:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a260 =====
0x00a260:	push    	{r4, r5, lr}
0x00a262:	ldr     	r3, [r0, #0x10]
0x00a264:	adds    	r4, r0, #0
0x00a266:	cmp     	r3, #0
0x00a268:	sub     	sp, #0xc
0x00a26a:	beq     	#0xa2a0
0x00a26c:	movs    	r2, #0
0x00a26e:	movs    	r1, #0
0x00a270:	str     	r2, [sp, #8]
0x00a272:	adds    	r2, r3, #0
0x00a274:	str     	r1, [sp]
0x00a276:	str     	r1, [sp, #4]
0x00a278:	movs    	r5, #0
0x00a27a:	adds    	r3, r5, #0
0x00a27c:	movs    	r1, #0x6f
0x00a27e:	movs    	r0, #0xf1
0x00a280:	lsls    	r0, r0, #9
0x00a282:	bl      	#0x7e90
0x00a286:	movs    	r1, #0
0x00a288:	str     	r1, [sp]
0x00a28a:	str     	r1, [sp, #4]
0x00a28c:	movs    	r2, #0
0x00a28e:	str     	r2, [sp, #8]
0x00a290:	movs    	r1, #9
0x00a292:	adds    	r3, r5, #0
0x00a294:	movs    	r0, #0xf1
0x00a296:	lsls    	r0, r0, #9
0x00a298:	ldr     	r2, [r4, #0x10]
0x00a29a:	bl      	#0x7e90
0x00a29e:	str     	r5, [r4, #0x10]
0x00a2a0:	add     	sp, #0xc
0x00a2a2:	pop     	{r4, r5, pc}

; ===== candidate_00a2a4 =====
0x00a2a4:	push    	{r4, r5, r6, r7, lr}
0x00a2a6:	sub     	sp, #0xc
0x00a2a8:	adds    	r6, r1, #0
0x00a2aa:	adds    	r4, r2, #0
0x00a2ac:	movs    	r1, #0
0x00a2ae:	movs    	r2, #0
0x00a2b0:	adds    	r7, r0, #0
0x00a2b2:	str     	r2, [sp, #8]
0x00a2b4:	str     	r1, [sp]
0x00a2b6:	str     	r1, [sp, #4]
0x00a2b8:	movs    	r5, #0
0x00a2ba:	adds    	r3, r5, #0
0x00a2bc:	movs    	r1, #0x67
0x00a2be:	movs    	r2, #0x2e
0x00a2c0:	movs    	r0, #0xf1
0x00a2c2:	lsls    	r0, r0, #9
0x00a2c4:	bl      	#0x7e90
0x00a2c8:	movs    	r1, #0
0x00a2ca:	movs    	r2, #0
0x00a2cc:	str     	r2, [sp, #8]
0x00a2ce:	str     	r1, [sp]
0x00a2d0:	str     	r1, [sp, #4]
0x00a2d2:	movs    	r1, #0x14
0x00a2d4:	movs    	r2, #0x4d
0x00a2d6:	adds    	r3, r4, #0
0x00a2d8:	movs    	r0, #0xf1
0x00a2da:	lsls    	r0, r0, #9
0x00a2dc:	bl      	#0x7e90
0x00a2e0:	movs    	r1, #0
0x00a2e2:	str     	r1, [sp]
0x00a2e4:	str     	r1, [sp, #4]
0x00a2e6:	movs    	r2, #0
0x00a2e8:	movs    	r1, #0x34
0x00a2ea:	adds    	r3, r5, #0
0x00a2ec:	movs    	r0, #0xf1
0x00a2ee:	lsls    	r0, r0, #9
0x00a2f0:	str     	r2, [sp, #8]
0x00a2f2:	bl      	#0x7e90
0x00a2f6:	ldr     	r2, [r4]
0x00a2f8:	ldr     	r1, [r6]
0x00a2fa:	adds    	r0, r7, #0
0x00a2fc:	bl      	#0x9a54
0x00a300:	add     	sp, #0xc
0x00a302:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a304 =====
0x00a304:	push    	{r4, r5, r6, r7, lr}
0x00a306:	ldr     	r0, [pc, #0x1ec]
0x00a308:	movs    	r7, #0xf1
0x00a30a:	add     	r0, sb
0x00a30c:	ldr     	r6, [r0, #0x50]
0x00a30e:	lsls    	r7, r7, #9
0x00a310:	movs    	r5, #0
0x00a312:	cmp     	r6, #0
0x00a314:	sub     	sp, #0x14
0x00a316:	beq     	#0xa35e
0x00a318:	movs    	r1, #0
0x00a31a:	movs    	r2, #0
0x00a31c:	str     	r2, [sp, #8]
0x00a31e:	str     	r1, [sp]
0x00a320:	str     	r1, [sp, #4]
0x00a322:	movs    	r0, #1
0x00a324:	str     	r0, [sp, #0x10]
0x00a326:	movs    	r1, #0x11
0x00a328:	adds    	r2, r6, #0
0x00a32a:	movs    	r4, #0
0x00a32c:	movs    	r3, #4
0x00a32e:	adds    	r0, r7, #0
0x00a330:	bl      	#0x7e90
0x00a334:	cmp     	r0, #0
0x00a336:	ble     	#0xa354
0x00a338:	ldr     	r1, [pc, #0x1b8]
0x00a33a:	add     	r1, sb
0x00a33c:	ldr     	r2, [r1, #0x50]
0x00a33e:	lsls    	r1, r4, #2
0x00a340:	ldr     	r1, [r2, r1]
0x00a342:	ldr     	r1, [r1, #4]
0x00a344:	cmp     	r1, #0
0x00a346:	bne     	#0xa408
0x00a348:	adds    	r4, #1
0x00a34a:	cmp     	r4, r0
0x00a34c:	blt     	#0xa33e
0x00a34e:	ldr     	r0, [sp, #0x10]
0x00a350:	cmp     	r0, #0
0x00a352:	beq     	#0xa408
0x00a354:	ldr     	r1, [pc, #0x19c]
0x00a356:	movs    	r0, #1
0x00a358:	add     	r1, sb
0x00a35a:	str     	r5, [r1, #0x50]
0x00a35c:	strb    	r0, [r1, #8]
0x00a35e:	ldr     	r6, [pc, #0x194]
0x00a360:	add     	r6, sb
0x00a362:	ldr     	r2, [r6, #0x4c]
0x00a364:	mov     	ip, r2
0x00a366:	cmp     	r2, #0
0x00a368:	beq     	#0xa3a8
0x00a36a:	movs    	r1, #0
0x00a36c:	movs    	r2, #0
0x00a36e:	str     	r1, [sp]
0x00a370:	str     	r1, [sp, #4]
0x00a372:	movs    	r0, #1
0x00a374:	str     	r0, [sp, #0x10]
0x00a376:	movs    	r1, #0x11
0x00a378:	str     	r2, [sp, #8]
0x00a37a:	movs    	r4, #0
0x00a37c:	movs    	r3, #4
0x00a37e:	adds    	r0, r7, #0
0x00a380:	mov     	r2, ip
0x00a382:	bl      	#0x7e90
0x00a386:	cmp     	r0, #0
0x00a388:	ble     	#0xa3a2
0x00a38a:	ldr     	r2, [r6, #0x4c]
0x00a38c:	lsls    	r1, r4, #2
0x00a38e:	ldr     	r1, [r2, r1]
0x00a390:	ldr     	r1, [r1, #8]
0x00a392:	cmp     	r1, #0
0x00a394:	bne     	#0xa408
0x00a396:	adds    	r4, #1
0x00a398:	cmp     	r4, r0
0x00a39a:	blt     	#0xa38c
0x00a39c:	ldr     	r0, [sp, #0x10]
0x00a39e:	cmp     	r0, #0
0x00a3a0:	beq     	#0xa408
0x00a3a2:	movs    	r0, #1
0x00a3a4:	str     	r5, [r6, #0x4c]
0x00a3a6:	strb    	r0, [r6, #8]
0x00a3a8:	ldr     	r2, [r6, #0x48]
0x00a3aa:	mov     	ip, r2
0x00a3ac:	cmp     	r2, #0
0x00a3ae:	beq     	#0xa3f0
0x00a3b0:	movs    	r1, #0
0x00a3b2:	movs    	r2, #0
0x00a3b4:	str     	r1, [sp]
0x00a3b6:	str     	r1, [sp, #4]
0x00a3b8:	movs    	r0, #1
0x00a3ba:	str     	r0, [sp, #0x10]
0x00a3bc:	movs    	r1, #0x11
0x00a3be:	str     	r2, [sp, #8]
0x00a3c0:	movs    	r4, #0
0x00a3c2:	movs    	r3, #4
0x00a3c4:	adds    	r0, r7, #0
0x00a3c6:	mov     	r2, ip
0x00a3c8:	bl      	#0x7e90
0x00a3cc:	cmp     	r0, #0
0x00a3ce:	ble     	#0xa3e8
0x00a3d0:	ldr     	r2, [r6, #0x48]
0x00a3d2:	lsls    	r1, r4, #2
0x00a3d4:	ldr     	r1, [r2, r1]
0x00a3d6:	ldr     	r1, [r1]
0x00a3d8:	cmp     	r1, #0
0x00a3da:	bne     	#0xa408
0x00a3dc:	adds    	r4, #1
0x00a3de:	cmp     	r4, r0
0x00a3e0:	blt     	#0xa3d2
0x00a3e2:	ldr     	r0, [sp, #0x10]
0x00a3e4:	cmp     	r0, #0
0x00a3e6:	beq     	#0xa408
0x00a3e8:	movs    	r0, #1
0x00a3ea:	str     	r5, [r6, #0x48]
0x00a3ec:	strb    	r0, [r6, #8]
0x00a3ee:	b       	#0xa3f8
0x00a3f0:	movs    	r3, #8
0x00a3f2:	ldrsb   	r0, [r6, r3]
0x00a3f4:	cmp     	r0, #0
0x00a3f6:	beq     	#0xa408
0x00a3f8:	ldr     	r4, [pc, #0xf8]
0x00a3fa:	add     	r4, sb
0x00a3fc:	adds    	r4, #0x80
0x00a3fe:	ldr     	r0, [r4, #0x1c]
0x00a400:	cmp     	r0, #0
0x00a402:	ble     	#0xa44a
0x00a404:	subs    	r0, #1
0x00a406:	str     	r0, [r4, #0x1c]
0x00a408:	add     	sp, #0x14
0x00a40a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a4fc =====
0x00a4fc:	push    	{r4, r5, r6, r7, lr}
0x00a4fe:	sub     	sp, #0xc
0x00a500:	ldr     	r7, [pc, #0xfc]
0x00a502:	movs    	r1, #0
0x00a504:	movs    	r2, #0
0x00a506:	str     	r2, [sp, #8]
0x00a508:	str     	r1, [sp]
0x00a50a:	str     	r1, [sp, #4]
0x00a50c:	add     	r7, sb
0x00a50e:	ldr     	r0, [r7, #0x50]
0x00a510:	movs    	r1, #0x11
0x00a512:	ldr     	r2, [r0]
0x00a514:	movs    	r0, #0xf1
0x00a516:	movs    	r6, #0x28
0x00a518:	movs    	r5, #1
0x00a51a:	movs    	r4, #0
0x00a51c:	movs    	r3, #4
0x00a51e:	lsls    	r0, r0, #9
0x00a520:	bl      	#0x7e90
0x00a524:	cmp     	r0, #0
0x00a526:	ble     	#0xa560
0x00a528:	ldr     	r1, [r7, #0x50]
0x00a52a:	lsls    	r3, r4, #2
0x00a52c:	ldr     	r2, [r1]
0x00a52e:	ldr     	r2, [r2, r3]
0x00a530:	cmp     	r2, #0
0x00a532:	beq     	#0xa55a
0x00a534:	ldr     	r2, [r1, #0x14]
0x00a536:	lsls    	r1, r4, #1
0x00a538:	adds    	r2, r2, r1
0x00a53a:	ldrh    	r3, [r2]
0x00a53c:	subs    	r3, r3, r6
0x00a53e:	lsls    	r3, r3, #0x10
0x00a540:	asrs    	r3, r3, #0x10
0x00a542:	strh    	r3, [r2]
0x00a544:	ldr     	r2, [r7, #0x50]
0x00a546:	ldr     	r2, [r2, #0x14]
0x00a548:	bpl     	#0xa54e
0x00a54a:	movs    	r3, #0
0x00a54c:	strh    	r3, [r2, r1]
0x00a54e:	ldr     	r2, [r7, #0x50]
0x00a550:	ldr     	r2, [r2, #0x14]
0x00a552:	ldrsh   	r1, [r2, r1]
0x00a554:	cmp     	r1, #0
0x00a556:	ble     	#0xa55a
0x00a558:	movs    	r5, #0
0x00a55a:	adds    	r4, #1
0x00a55c:	cmp     	r4, r0
0x00a55e:	blt     	#0xa528
0x00a560:	movs    	r1, #0
0x00a562:	cmp     	r0, #0
0x00a564:	ble     	#0xa59e
0x00a566:	ldr     	r2, [r7, #0x54]
0x00a568:	lsls    	r4, r1, #2
0x00a56a:	ldr     	r3, [r2]
0x00a56c:	ldr     	r3, [r3, r4]
0x00a56e:	cmp     	r3, #0
0x00a570:	beq     	#0xa598
0x00a572:	ldr     	r3, [r2, #0x14]
0x00a574:	lsls    	r2, r1, #1
0x00a576:	adds    	r3, r3, r2
0x00a578:	ldrh    	r4, [r3]
0x00a57a:	subs    	r4, r4, r6
0x00a57c:	lsls    	r4, r4, #0x10
0x00a57e:	asrs    	r4, r4, #0x10
0x00a580:	strh    	r4, [r3]
0x00a582:	ldr     	r3, [r7, #0x54]
0x00a584:	ldr     	r3, [r3, #0x14]
0x00a586:	bpl     	#0xa58c
0x00a588:	movs    	r4, #0
0x00a58a:	strh    	r4, [r3, r2]
0x00a58c:	ldr     	r3, [r7, #0x54]
0x00a58e:	ldr     	r3, [r3, #0x14]
0x00a590:	ldrsh   	r2, [r3, r2]
0x00a592:	cmp     	r2, #0
0x00a594:	ble     	#0xa598
0x00a596:	movs    	r5, #0
0x00a598:	adds    	r1, #1
0x00a59a:	cmp     	r1, r0
0x00a59c:	blt     	#0xa566
0x00a59e:	cmp     	r5, #1
0x00a5a0:	bne     	#0xa5f2
0x00a5a2:	ldr     	r1, [r7, #0x50]
0x00a5a4:	movs    	r2, #0
0x00a5a6:	ldr     	r0, [r1, #0x10]
0x00a5a8:	ldr     	r1, [r1]
0x00a5aa:	lsls    	r0, r0, #2
0x00a5ac:	ldr     	r4, [r1, r0]
0x00a5ae:	movs    	r1, #0
0x00a5b0:	str     	r2, [sp, #8]
0x00a5b2:	movs    	r2, #0xff
0x00a5b4:	str     	r1, [sp]
0x00a5b6:	str     	r1, [sp, #4]
0x00a5b8:	movs    	r5, #0
0x00a5ba:	movs    	r6, #0xf1
0x00a5bc:	lsls    	r6, r6, #9
0x00a5be:	adds    	r3, r5, #0
0x00a5c0:	movs    	r1, #0x14
0x00a5c2:	adds    	r2, #0x15
0x00a5c4:	adds    	r0, r6, #0
0x00a5c6:	bl      	#0x7e90
0x00a5ca:	cmp     	r4, #0
0x00a5cc:	beq     	#0xa5d6
0x00a5ce:	adds    	r0, r4, #0
0x00a5d0:	bl      	#0x6780
0x00a5d4:	b       	#0xa5f2
0x00a5d6:	bl      	#0xa034
0x00a5da:	movs    	r2, #0
0x00a5dc:	movs    	r1, #0
0x00a5de:	str     	r2, [sp, #8]
0x00a5e0:	ldr     	r2, [pc, #0x20]
0x00a5e2:	str     	r1, [sp]
0x00a5e4:	str     	r1, [sp, #4]
0x00a5e6:	adds    	r3, r5, #0
0x00a5e8:	add     	r2, pc
0x00a5ea:	movs    	r1, #0x9d
0x00a5ec:	adds    	r0, r6, #0
0x00a5ee:	bl      	#0x7e90
0x00a5f2:	ldr     	r0, [pc, #0xc]
0x00a5f4:	movs    	r5, #0
0x00a5f6:	add     	r0, sb
0x00a5f8:	subs    	r0, #0x80
0x00a5fa:	strb    	r5, [r0, #6]
0x00a5fc:	add     	sp, #0xc
0x00a5fe:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a608 =====
0x00a608:	push    	{r3, r4, r5, lr}
0x00a60a:	ldr     	r5, [pc, #0x5c]
0x00a60c:	add     	r5, sb
0x00a60e:	ldr     	r0, [r5, #0x50]
0x00a610:	bl      	#0xad20
0x00a614:	adds    	r4, r0, #0
0x00a616:	ldr     	r0, [r5, #0x54]
0x00a618:	bl      	#0xad20
0x00a61c:	cmp     	r4, #0
0x00a61e:	blt     	#0xa656
0x00a620:	cmp     	r0, #0
0x00a622:	blt     	#0xa656
0x00a624:	ldr     	r1, [r5, #0x30]
0x00a626:	cmp     	r4, r1
0x00a628:	bne     	#0xa658
0x00a62a:	adds    	r4, r5, #0
0x00a62c:	cmp     	r0, r1
0x00a62e:	bne     	#0xa658
0x00a630:	ldr     	r0, [r4, #4]
0x00a632:	str     	r0, [r4]
0x00a634:	ldr     	r0, [r4, #0x50]
0x00a636:	bl      	#0x7988
0x00a63a:	ldr     	r0, [r4, #0x54]
0x00a63c:	bl      	#0x7988
0x00a640:	ldr     	r0, [r4, #0x50]
0x00a642:	bl      	#0x7938
0x00a646:	ldr     	r0, [r4, #0x54]
0x00a648:	bl      	#0x7938
0x00a64c:	ldr     	r1, [pc, #0x18]
0x00a64e:	movs    	r0, #1
0x00a650:	add     	r1, sb
0x00a652:	subs    	r1, #0x80
0x00a654:	strb    	r0, [r1, #8]
0x00a656:	pop     	{r3, r4, r5, pc}

; ===== candidate_00a66c =====
0x00a66c:	push    	{r4, r5, r6, r7, lr}
0x00a66e:	adds    	r7, r0, #0
0x00a670:	adds    	r2, r0, #0
0x00a672:	adds    	r7, #0x80
0x00a674:	ldr     	r4, [r7, #4]
0x00a676:	ldr     	r0, [r4, #4]
0x00a678:	bl      	#0x62ac
0x00a67c:	adds    	r5, r2, #0
0x00a67e:	ldr     	r0, [r4]
0x00a680:	adds    	r5, #0xd0
0x00a682:	cmp     	r0, #0x15
0x00a684:	bne     	#0xa6a6
0x00a686:	movs    	r3, #0
0x00a688:	ldrsb   	r1, [r5, r3]
0x00a68a:	ldr     	r0, [r4, #0x5c]
0x00a68c:	lsls    	r1, r1, #2
0x00a68e:	ldr     	r0, [r0, r1]
0x00a690:	ldrsb   	r0, [r0, r3]
0x00a692:	bl      	#0x62ac
0x00a696:	movs    	r3, #0
0x00a698:	ldrsb   	r6, [r5, r3]
0x00a69a:	ldr     	r1, [r4, #0x5c]
0x00a69c:	lsls    	r3, r6, #2
0x00a69e:	ldr     	r1, [r1, r3]
0x00a6a0:	movs    	r3, #1
0x00a6a2:	ldrsb   	r1, [r1, r3]
0x00a6a4:	b       	#0xa6ae
0x00a6a6:	ldr     	r0, [r4, #4]
0x00a6a8:	bl      	#0x62ac
0x00a6ac:	ldr     	r1, [r4, #8]
0x00a6ae:	ldr     	r3, [r0, #0x14]
0x00a6b0:	lsls    	r1, r1, #1
0x00a6b2:	adds    	r3, r3, r1
0x00a6b4:	ldrh    	r6, [r3]
0x00a6b6:	subs    	r6, #0x28
0x00a6b8:	lsls    	r6, r6, #0x10
0x00a6ba:	asrs    	r6, r6, #0x10
0x00a6bc:	strh    	r6, [r3]
0x00a6be:	ldr     	r3, [r0, #0x14]
0x00a6c0:	bpl     	#0xa6c6
0x00a6c2:	movs    	r6, #0
0x00a6c4:	strh    	r6, [r3, r1]
0x00a6c6:	ldr     	r0, [r0, #0x14]
0x00a6c8:	ldrh    	r0, [r0, r1]
0x00a6ca:	cmp     	r0, #0
0x00a6cc:	bne     	#0xa6f4
0x00a6ce:	movs    	r6, #0
0x00a6d0:	ldr     	r1, [pc, #0x24]
0x00a6d2:	str     	r6, [r7, #4]
0x00a6d4:	movs    	r0, #1
0x00a6d6:	strb    	r0, [r2, #0x14]
0x00a6d8:	add     	r1, sb
0x00a6da:	strb    	r0, [r1, #8]
0x00a6dc:	adds    	r0, r2, #0
0x00a6de:	bl      	#0x7798
0x00a6e2:	ldr     	r0, [r4]
0x00a6e4:	cmp     	r0, #0x15
0x00a6e6:	bne     	#0xa6f4
0x00a6e8:	movs    	r3, #0
0x00a6ea:	ldrsb   	r1, [r5, r3]
0x00a6ec:	ldr     	r0, [r4, #0x5c]
0x00a6ee:	lsls    	r1, r1, #2
0x00a6f0:	ldr     	r0, [r0, r1]
0x00a6f2:	str     	r6, [r0, #4]
0x00a6f4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a6fc =====
0x00a6fc:	push    	{r4, r5, r6, r7, lr}
0x00a6fe:	ldr     	r1, [pc, #0xf0]
0x00a700:	ldr     	r5, [pc, #0xec]
0x00a702:	movs    	r3, #6
0x00a704:	add     	r1, sb
0x00a706:	ldrsb   	r0, [r1, r3]
0x00a708:	add     	r5, sb
0x00a70a:	adds    	r5, #0x80
0x00a70c:	movs    	r4, #0
0x00a70e:	cmp     	r0, #1
0x00a710:	sub     	sp, #0xc
0x00a712:	bne     	#0xa75c
0x00a714:	movs    	r3, #9
0x00a716:	ldrsb   	r0, [r1, r3]
0x00a718:	cmp     	r0, #1
0x00a71a:	bne     	#0xa75c
0x00a71c:	strb    	r0, [r1, #8]
0x00a71e:	str     	r4, [r1, #0x4c]
0x00a720:	str     	r4, [r1, #0x48]
0x00a722:	ldr     	r0, [r5, #0x50]
0x00a724:	ldr     	r0, [r0]
0x00a726:	bl      	#0xa1a4
0x00a72a:	ldr     	r0, [r5, #0x54]
0x00a72c:	ldr     	r0, [r0]
0x00a72e:	bl      	#0xa1a4
0x00a732:	ldr     	r0, [r5]
0x00a734:	cmp     	r0, #5
0x00a736:	bne     	#0xa75c
0x00a738:	ldr     	r0, [r5, #0x3c]
0x00a73a:	ldr     	r0, [r0, #0x64]
0x00a73c:	bl      	#0x93c4
0x00a740:	ldr     	r0, [r5, #4]
0x00a742:	str     	r0, [r5]
0x00a744:	ldr     	r0, [r5, #0x50]
0x00a746:	bl      	#0x7988
0x00a74a:	ldr     	r0, [r5, #0x54]
0x00a74c:	bl      	#0x7988
0x00a750:	ldr     	r0, [r5, #0x50]
0x00a752:	bl      	#0x7938
0x00a756:	ldr     	r0, [r5, #0x54]
0x00a758:	bl      	#0x7938
0x00a75c:	adds    	r6, r5, #0
0x00a75e:	ldr     	r0, [r5]
0x00a760:	movs    	r5, #0xf1
0x00a762:	lsls    	r5, r5, #9
0x00a764:	cmp     	r0, #0
0x00a766:	beq     	#0xa7d2
0x00a768:	movs    	r7, #0xff
0x00a76a:	adds    	r7, #0x15
0x00a76c:	cmp     	r0, #1
0x00a76e:	beq     	#0xa7d8
0x00a770:	cmp     	r0, #4
0x00a772:	beq     	#0xa7b6
0x00a774:	cmp     	r0, #5
0x00a776:	bne     	#0xa792
0x00a778:	movs    	r1, #0
0x00a77a:	movs    	r2, #0
0x00a77c:	str     	r2, [sp, #8]
0x00a77e:	str     	r1, [sp]
0x00a780:	str     	r1, [sp, #4]
0x00a782:	movs    	r1, #0x14
0x00a784:	adds    	r2, r7, #0
0x00a786:	adds    	r3, r4, #0
0x00a788:	adds    	r0, r5, #0
0x00a78a:	bl      	#0x7e90
0x00a78e:	bl      	#0xa608
0x00a792:	ldr     	r0, [r6, #0x50]
0x00a794:	bl      	#0xacac
0x00a798:	ldr     	r0, [r6, #0x54]
0x00a79a:	bl      	#0xacac
0x00a79e:	movs    	r1, #0
0x00a7a0:	str     	r1, [sp]
0x00a7a2:	str     	r1, [sp, #4]
0x00a7a4:	movs    	r2, #0
0x00a7a6:	movs    	r1, #0x89
0x00a7a8:	adds    	r3, r4, #0
0x00a7aa:	adds    	r0, r5, #0
0x00a7ac:	str     	r2, [sp, #8]
0x00a7ae:	bl      	#0x7e90
0x00a7b2:	add     	sp, #0xc
0x00a7b4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a7f4 =====
0x00a7f4:	push    	{r3, r4, r5, r6, r7, lr}
0x00a7f6:	adds    	r2, r0, #0
0x00a7f8:	adds    	r0, #0x80
0x00a7fa:	ldr     	r4, [r0, #4]
0x00a7fc:	movs    	r6, #1
0x00a7fe:	cmp     	r4, #0
0x00a800:	bne     	#0xa80a
0x00a802:	ldr     	r1, [pc, #0xf0]
0x00a804:	add     	r1, sb
0x00a806:	strb    	r6, [r1, #8]
0x00a808:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_00a8f8 =====
0x00a8f8:	push    	{r4, r5, r6, r7, lr}
0x00a8fa:	adds    	r4, r0, #0
0x00a8fc:	ldrh    	r0, [r0, #0x2a]
0x00a8fe:	sub     	sp, #0xc
0x00a900:	subs    	r0, #1
0x00a902:	lsls    	r0, r0, #0x10
0x00a904:	asrs    	r0, r0, #0x10
0x00a906:	strh    	r0, [r4, #0x2a]
0x00a908:	ldrh    	r1, [r4, #0x30]
0x00a90a:	adds    	r1, #1
0x00a90c:	strh    	r1, [r4, #0x30]
0x00a90e:	cmp     	r0, #0
0x00a910:	bgt     	#0xa93a
0x00a912:	adds    	r6, r4, #0
0x00a914:	ldr     	r0, [pc, #0x80]
0x00a916:	adds    	r6, #0x80
0x00a918:	ldr     	r5, [r6, #4]
0x00a91a:	movs    	r7, #0
0x00a91c:	add     	r0, sb
0x00a91e:	strb    	r7, [r0, #1]
0x00a920:	adds    	r0, r4, #0
0x00a922:	bl      	#0x7798
0x00a926:	cmp     	r5, #0
0x00a928:	beq     	#0xa93a
0x00a92a:	ldr     	r0, [r5]
0x00a92c:	cmp     	r0, #0x11
0x00a92e:	bne     	#0xa93e
0x00a930:	ldr     	r1, [pc, #0x64]
0x00a932:	movs    	r0, #1
0x00a934:	add     	r1, sb
0x00a936:	strb    	r0, [r1, #8]
0x00a938:	str     	r7, [r6, #4]
0x00a93a:	add     	sp, #0xc
0x00a93c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00a99c =====
0x00a99c:	push    	{r4, r5, r6, r7, lr}
0x00a99e:	adds    	r4, r0, #0
0x00a9a0:	movs    	r3, #0x2e
0x00a9a2:	ldrsh   	r0, [r0, r3]
0x00a9a4:	sub     	sp, #0xc
0x00a9a6:	cmp     	r0, #0
0x00a9a8:	bgt     	#0xaa8e
0x00a9aa:	ldrh    	r0, [r4, #0x2c]
0x00a9ac:	adds    	r0, #2
0x00a9ae:	lsls    	r0, r0, #0x10
0x00a9b0:	asrs    	r0, r0, #0x10
0x00a9b2:	strh    	r0, [r4, #0x2c]
0x00a9b4:	cmp     	r0, #4
0x00a9b6:	ble     	#0xaa90
0x00a9b8:	adds    	r6, r4, #0
0x00a9ba:	adds    	r6, #0x80
0x00a9bc:	ldr     	r5, [r6, #4]
0x00a9be:	movs    	r0, #4
0x00a9c0:	strh    	r0, [r4, #0x2c]
0x00a9c2:	movs    	r0, #0x33
0x00a9c4:	movs    	r7, #0
0x00a9c6:	strb    	r7, [r0, r4]
0x00a9c8:	adds    	r0, r4, #0
0x00a9ca:	bl      	#0x7798
0x00a9ce:	ldr     	r1, [pc, #0xf8]
0x00a9d0:	movs    	r0, #1
0x00a9d2:	str     	r7, [r6, #4]
0x00a9d4:	add     	r1, sb
0x00a9d6:	strb    	r0, [r1, #8]
0x00a9d8:	movs    	r1, #0
0x00a9da:	movs    	r2, #0
0x00a9dc:	str     	r2, [sp, #8]
0x00a9de:	str     	r1, [sp]
0x00a9e0:	str     	r1, [sp, #4]
0x00a9e2:	movs    	r1, #0xe1
0x00a9e4:	movs    	r2, #0x4c
0x00a9e6:	movs    	r0, #0xf1
0x00a9e8:	adds    	r3, r7, #0
0x00a9ea:	lsls    	r0, r0, #9
0x00a9ec:	bl      	#0x7e90
0x00a9f0:	cmp     	r0, r4
0x00a9f2:	bne     	#0xaa80
0x00a9f4:	ldr     	r0, [pc, #0xd0]
0x00a9f6:	add     	r0, sb
0x00a9f8:	ldr     	r3, [r0, #0x2c]
0x00a9fa:	cmp     	r3, #0
0x00a9fc:	beq     	#0xaa16
0x00a9fe:	movs    	r1, #0
0x00aa00:	movs    	r2, #0
0x00aa02:	str     	r2, [sp, #8]
0x00aa04:	str     	r1, [sp]
0x00aa06:	str     	r1, [sp, #4]
0x00aa08:	movs    	r0, #0xf1
0x00aa0a:	lsls    	r0, r0, #9
0x00aa0c:	movs    	r1, #9
0x00aa0e:	adds    	r2, r3, #0
0x00aa10:	adds    	r3, r7, #0
0x00aa12:	bl      	#0x7e90
0x00aa16:	ldr     	r0, [pc, #0xb0]
0x00aa18:	movs    	r1, #0
0x00aa1a:	add     	r0, sb
0x00aa1c:	str     	r7, [r0, #0x2c]
0x00aa1e:	movs    	r2, #0
0x00aa20:	str     	r2, [sp, #8]
0x00aa22:	str     	r1, [sp]
0x00aa24:	str     	r1, [sp, #4]
0x00aa26:	movs    	r1, #0xe1
0x00aa28:	movs    	r2, #0x53
0x00aa2a:	movs    	r0, #0xf1
0x00aa2c:	adds    	r3, r7, #0
0x00aa2e:	lsls    	r0, r0, #9
0x00aa30:	bl      	#0x7e90
0x00aa34:	cmp     	r0, #0
0x00aa36:	beq     	#0xaa80
0x00aa38:	movs    	r1, #0
0x00aa3a:	movs    	r2, #0
0x00aa3c:	str     	r2, [sp, #8]
0x00aa3e:	str     	r1, [sp]
0x00aa40:	str     	r1, [sp, #4]
0x00aa42:	movs    	r1, #0xe1
0x00aa44:	movs    	r2, #0x53
0x00aa46:	adds    	r3, r7, #0
0x00aa48:	movs    	r0, #0xf1
0x00aa4a:	lsls    	r0, r0, #9
0x00aa4c:	bl      	#0x7e90
0x00aa50:	movs    	r2, #0
0x00aa52:	str     	r2, [sp, #8]
0x00aa54:	movs    	r1, #0
0x00aa56:	adds    	r2, r0, #0
0x00aa58:	movs    	r0, #0xf1
0x00aa5a:	str     	r1, [sp]
0x00aa5c:	str     	r1, [sp, #4]
0x00aa5e:	movs    	r1, #0xa0
0x00aa60:	lsls    	r0, r0, #9
0x00aa62:	adds    	r3, r7, #0
0x00aa64:	bl      	#0x7e90
0x00aa68:	movs    	r1, #0
0x00aa6a:	movs    	r2, #0
0x00aa6c:	str     	r2, [sp, #8]
0x00aa6e:	str     	r1, [sp]
0x00aa70:	str     	r1, [sp, #4]
0x00aa72:	movs    	r1, #0x14
0x00aa74:	movs    	r2, #0x53
0x00aa76:	adds    	r3, r7, #0
0x00aa78:	movs    	r0, #0xf1
0x00aa7a:	lsls    	r0, r0, #9
0x00aa7c:	bl      	#0x7e90
0x00aa80:	ldr     	r1, [pc, #0x44]
0x00aa82:	add     	r1, sb
0x00aa84:	ldr     	r0, [r1, #0x50]
0x00aa86:	cmp     	r0, #0
0x00aa88:	beq     	#0xaa90
0x00aa8a:	cmp     	r5, #0
0x00aa8c:	b       	#0xaa92
0x00aa8e:	b       	#0xaac0
0x00aa90:	b       	#0xaab4
0x00aa92:	beq     	#0xaab4
0x00aa94:	ldr     	r0, [r5]
0x00aa96:	cmp     	r0, #0x15
0x00aa98:	bne     	#0xaab4
0x00aa9a:	movs    	r1, #0xd0
0x00aa9c:	ldrsb   	r1, [r1, r4]
0x00aa9e:	ldr     	r0, [r5, #0x5c]
0x00aaa0:	lsls    	r1, r1, #2
0x00aaa2:	ldr     	r0, [r0, r1]
0x00aaa4:	ldrb    	r1, [r0, #2]
0x00aaa6:	cmp     	r1, #0xff
0x00aaa8:	beq     	#0xaab2
0x00aaaa:	movs    	r0, #7
0x00aaac:	str     	r5, [r6, #4]
0x00aaae:	strh    	r0, [r4, #0x28]
0x00aab0:	b       	#0xaab4
0x00aab2:	str     	r7, [r0, #4]
0x00aab4:	ldrh    	r0, [r4, #0x2c]
0x00aab6:	movs    	r1, #4
0x00aab8:	subs    	r0, r1, r0
0x00aaba:	strh    	r0, [r4, #0x2e]
0x00aabc:	add     	sp, #0xc
0x00aabe:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00aacc =====
0x00aacc:	push    	{r0, r4, r5, r6, r7, lr}
0x00aace:	sub     	sp, #0x18
0x00aad0:	ldr     	r1, [sp, #0x18]
0x00aad2:	adds    	r1, #0x80
0x00aad4:	str     	r1, [sp, #0x14]
0x00aad6:	ldr     	r4, [r1, #4]
0x00aad8:	ldr     	r0, [r4]
0x00aada:	ldr     	r7, [sp, #0x18]
0x00aadc:	adds    	r7, #0xd0
0x00aade:	cmp     	r0, #0x15
0x00aae0:	bne     	#0xab6c
0x00aae2:	movs    	r3, #0
0x00aae4:	ldrsb   	r1, [r7, r3]
0x00aae6:	ldr     	r0, [r4, #0x5c]
0x00aae8:	lsls    	r1, r1, #2
0x00aaea:	ldr     	r0, [r0, r1]
0x00aaec:	ldrsb   	r0, [r0, r3]
0x00aaee:	bl      	#0x62ac
0x00aaf2:	movs    	r3, #0
0x00aaf4:	ldrsb   	r1, [r7, r3]
0x00aaf6:	adds    	r5, r0, #0
0x00aaf8:	ldr     	r0, [r4, #0x5c]
0x00aafa:	lsls    	r1, r1, #2
0x00aafc:	ldr     	r0, [r0, r1]
0x00aafe:	movs    	r3, #1
0x00ab00:	ldrsb   	r0, [r0, r3]
0x00ab02:	ldr     	r1, [r5]
0x00ab04:	movs    	r2, #0
0x00ab06:	lsls    	r0, r0, #2
0x00ab08:	ldr     	r6, [r1, r0]
0x00ab0a:	movs    	r1, #0
0x00ab0c:	str     	r1, [sp]
0x00ab0e:	str     	r1, [sp, #4]
0x00ab10:	str     	r2, [sp, #8]
0x00ab12:	ldr     	r0, [r6, #0x7c]
0x00ab14:	movs    	r1, #0x6e
0x00ab16:	ldr     	r2, [r0, #0x1c]
0x00ab18:	movs    	r0, #0xf1
0x00ab1a:	movs    	r3, #0
0x00ab1c:	lsls    	r0, r0, #9
0x00ab1e:	bl      	#0x7e90
0x00ab22:	movs    	r3, #0
0x00ab24:	ldrsb   	r1, [r7, r3]
0x00ab26:	mov     	ip, r0
0x00ab28:	ldr     	r0, [r4, #0x5c]
0x00ab2a:	lsls    	r1, r1, #2
0x00ab2c:	ldr     	r0, [r0, r1]
0x00ab2e:	movs    	r3, #2
0x00ab30:	ldrsb   	r0, [r0, r3]
0x00ab32:	movs    	r3, #0xa
0x00ab34:	movs    	r1, #0
0x00ab36:	str     	r0, [sp, #0xc]
0x00ab38:	adds    	r0, r6, #0
0x00ab3a:	adds    	r0, #0x40
0x00ab3c:	mov     	lr, r0
0x00ab3e:	ldrsh   	r0, [r0, r3]
0x00ab40:	movs    	r2, #0
0x00ab42:	str     	r2, [sp, #8]
0x00ab44:	str     	r0, [sp]
0x00ab46:	mov     	r0, lr
0x00ab48:	str     	r1, [sp, #4]
0x00ab4a:	movs    	r3, #8
0x00ab4c:	ldrsh   	r0, [r0, r3]
0x00ab4e:	movs    	r1, #0x74
0x00ab50:	mov     	r2, ip
0x00ab52:	adds    	r3, r0, #0
0x00ab54:	movs    	r0, #0xf1
0x00ab56:	lsls    	r0, r0, #9
0x00ab58:	bl      	#0x7e90
0x00ab5c:	movs    	r3, #0
0x00ab5e:	ldrsb   	r2, [r7, r3]
0x00ab60:	ldr     	r1, [r4, #0x5c]
0x00ab62:	lsls    	r2, r2, #2
0x00ab64:	ldr     	r1, [r1, r2]
0x00ab66:	movs    	r3, #1
0x00ab68:	ldrsb   	r1, [r1, r3]
0x00ab6a:	b       	#0xabc8
0x00ab6c:	ldr     	r0, [r4, #4]
0x00ab6e:	bl      	#0x62ac
0x00ab72:	adds    	r5, r0, #0
0x00ab74:	ldr     	r1, [r4, #8]
0x00ab76:	ldr     	r0, [r0]
0x00ab78:	lsls    	r1, r1, #2
0x00ab7a:	ldr     	r6, [r0, r1]
0x00ab7c:	movs    	r1, #0
0x00ab7e:	movs    	r2, #0
0x00ab80:	str     	r2, [sp, #8]
0x00ab82:	str     	r1, [sp]
0x00ab84:	str     	r1, [sp, #4]
0x00ab86:	ldr     	r0, [r6, #0x7c]
0x00ab88:	movs    	r1, #0x6e
0x00ab8a:	ldr     	r2, [r0, #0x1c]
0x00ab8c:	movs    	r0, #0xf1
0x00ab8e:	movs    	r3, #0
0x00ab90:	lsls    	r0, r0, #9
0x00ab92:	bl      	#0x7e90
0x00ab96:	mov     	ip, r0
0x00ab98:	movs    	r0, #0x20
0x00ab9a:	ldrsb   	r0, [r0, r4]
0x00ab9c:	movs    	r3, #0xa
0x00ab9e:	movs    	r2, #0
0x00aba0:	str     	r0, [sp, #0xc]
0x00aba2:	adds    	r0, r6, #0
0x00aba4:	adds    	r0, #0x40
0x00aba6:	mov     	lr, r0
0x00aba8:	ldrsh   	r0, [r0, r3]
0x00abaa:	movs    	r1, #0
0x00abac:	str     	r1, [sp, #4]
0x00abae:	str     	r0, [sp]
0x00abb0:	mov     	r0, lr
0x00abb2:	str     	r2, [sp, #8]
0x00abb4:	movs    	r3, #8
0x00abb6:	ldrsh   	r0, [r0, r3]
0x00abb8:	movs    	r1, #0x74
0x00abba:	mov     	r2, ip
0x00abbc:	adds    	r3, r0, #0
0x00abbe:	movs    	r0, #0xf1
0x00abc0:	lsls    	r0, r0, #9
0x00abc2:	bl      	#0x7e90
0x00abc6:	ldr     	r1, [r4, #8]
0x00abc8:	ldr     	r2, [r5, #0x14]
0x00abca:	lsls    	r3, r1, #1
0x00abcc:	adds    	r2, r2, r3
0x00abce:	ldrh    	r3, [r2]
0x00abd0:	adds    	r3, #0x28
0x00abd2:	lsls    	r3, r3, #0x10
0x00abd4:	asrs    	r3, r3, #0x10
0x00abd6:	strh    	r3, [r2]
0x00abd8:	ldr     	r0, [r0]
0x00abda:	adds    	r0, #0x1e
0x00abdc:	cmp     	r3, r0
0x00abde:	ble     	#0xaca4
0x00abe0:	lsls    	r1, r1, #2
0x00abe2:	ldr     	r0, [r5]
0x00abe4:	str     	r1, [sp, #0x10]
0x00abe6:	movs    	r2, #0
0x00abe8:	str     	r2, [r0, r1]
0x00abea:	ldr     	r0, [sp, #0xc]
0x00abec:	adds    	r3, r0, #1
0x00abee:	bne     	#0xac14
0x00abf0:	ldr     	r1, [pc, #0xb4]

; ===== candidate_00acac =====
0x00acac:	push    	{r4, r5, r6, r7, lr}
0x00acae:	adds    	r5, r0, #0
0x00acb0:	movs    	r4, #0
0x00acb2:	cmp     	r0, #0
0x00acb4:	sub     	sp, #0xc
0x00acb6:	beq     	#0xad18
0x00acb8:	movs    	r1, #0
0x00acba:	str     	r1, [sp]
0x00acbc:	str     	r1, [sp, #4]
0x00acbe:	movs    	r2, #0
0x00acc0:	str     	r2, [sp, #8]
0x00acc2:	movs    	r1, #0x11
0x00acc4:	movs    	r3, #4
0x00acc6:	movs    	r0, #0xf1
0x00acc8:	lsls    	r0, r0, #9
0x00acca:	ldr     	r2, [r5]
0x00accc:	bl      	#0x7e90
0x00acd0:	adds    	r7, r0, #0
0x00acd2:	cmp     	r0, #0
0x00acd4:	ble     	#0xad18
0x00acd6:	ldr     	r0, [r5]
0x00acd8:	lsls    	r6, r4, #2
0x00acda:	ldr     	r0, [r0, r6]
0x00acdc:	cmp     	r0, #0
0x00acde:	beq     	#0xace4
0x00ace0:	bl      	#0xaf90
0x00ace4:	ldr     	r0, [r5, #8]
0x00ace6:	ldr     	r0, [r0, r6]
0x00ace8:	cmp     	r0, #0
0x00acea:	beq     	#0xad12
0x00acec:	movs    	r1, #0x4c
0x00acee:	ldrsb   	r1, [r1, r0]
0x00acf0:	cmp     	r1, #0
0x00acf2:	ble     	#0xad12
0x00acf4:	adds    	r0, #0x4c
0x00acf6:	ldrb    	r1, [r0]
0x00acf8:	adds    	r1, #0xff
0x00acfa:	strb    	r1, [r0]
0x00acfc:	ldr     	r0, [r5, #8]
0x00acfe:	ldr     	r0, [r0, r6]
0x00ad00:	adds    	r0, #0x40
0x00ad02:	ldrb    	r0, [r0, #0xc]
0x00ad04:	cmp     	r0, #0
0x00ad06:	bne     	#0xad12
0x00ad08:	ldr     	r0, [pc, #0x10]
0x00ad0a:	add     	r0, sb
0x00ad0c:	ldr     	r0, [r0, #0x20]
0x00ad0e:	bl      	#0x1114
0x00ad12:	adds    	r4, #1
0x00ad14:	cmp     	r4, r7
0x00ad16:	blt     	#0xacd6
0x00ad18:	add     	sp, #0xc
0x00ad1a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00ad20 =====
0x00ad20:	push    	{r4, r5, r6, r7, lr}
0x00ad22:	sub     	sp, #0x24
0x00ad24:	movs    	r1, #0
0x00ad26:	str     	r1, [sp]
0x00ad28:	str     	r1, [sp, #4]
0x00ad2a:	movs    	r2, #0
0x00ad2c:	str     	r2, [sp, #8]
0x00ad2e:	movs    	r5, #0xf1
0x00ad30:	lsls    	r5, r5, #9
0x00ad32:	ldr     	r2, [r0]
0x00ad34:	movs    	r1, #0x11
0x00ad36:	adds    	r4, r0, #0
0x00ad38:	movs    	r3, #4
0x00ad3a:	adds    	r0, r5, #0
0x00ad3c:	bl      	#0x7e90
0x00ad40:	str     	r0, [sp, #0x1c]
0x00ad42:	ldr     	r0, [pc, #0x114]
0x00ad44:	movs    	r1, #0
0x00ad46:	str     	r1, [sp, #0x18]
0x00ad48:	add     	r0, sb
0x00ad4a:	ldr     	r6, [r0, #0x30]
0x00ad4c:	ldr     	r0, [sp, #0x1c]
0x00ad4e:	str     	r6, [sp, #0x14]
0x00ad50:	cmp     	r0, #0
0x00ad52:	ble     	#0xae32
0x00ad54:	ldr     	r0, [sp, #0x14]
0x00ad56:	adds    	r0, #1
0x00ad58:	str     	r0, [sp, #0x20]
0x00ad5a:	ldr     	r0, [r4, #0x1c]
0x00ad5c:	ldr     	r1, [sp, #0x18]
0x00ad5e:	lsls    	r5, r1, #2
0x00ad60:	ldr     	r3, [r0, r5]
0x00ad62:	cmp     	r3, #0
0x00ad64:	beq     	#0xadd0
0x00ad66:	movs    	r2, #0
0x00ad68:	movs    	r1, #0
0x00ad6a:	str     	r2, [sp, #8]
0x00ad6c:	adds    	r2, r3, #0
0x00ad6e:	str     	r1, [sp]
0x00ad70:	str     	r1, [sp, #4]
0x00ad72:	movs    	r1, #0x26
0x00ad74:	movs    	r3, #0
0x00ad76:	movs    	r0, #0xf1
0x00ad78:	lsls    	r0, r0, #9
0x00ad7a:	bl      	#0x7e90
0x00ad7e:	movs    	r7, #0
0x00ad80:	cmp     	r0, #0
0x00ad82:	str     	r0, [sp, #0x10]
0x00ad84:	ble     	#0xadd0
0x00ad86:	movs    	r1, #0
0x00ad88:	movs    	r2, #0
0x00ad8a:	str     	r2, [sp, #8]
0x00ad8c:	str     	r1, [sp]
0x00ad8e:	str     	r1, [sp, #4]
0x00ad90:	ldr     	r0, [r4, #0x1c]
0x00ad92:	movs    	r1, #0x27
0x00ad94:	ldr     	r2, [r0, r5]
0x00ad96:	movs    	r0, #0xf1
0x00ad98:	adds    	r3, r7, #0
0x00ad9a:	lsls    	r0, r0, #9
0x00ad9c:	bl      	#0x7e90
0x00ada0:	movs    	r3, #1
0x00ada2:	ldrsb   	r1, [r0, r3]
0x00ada4:	ldr     	r2, [sp, #0x14]
0x00ada6:	cmp     	r1, r2
0x00ada8:	bne     	#0xadc8
0x00adaa:	ldrb    	r1, [r0]
0x00adac:	adds    	r1, #0xff
0x00adae:	lsls    	r1, r1, #0x18
0x00adb0:	asrs    	r1, r1, #0x18
0x00adb2:	strb    	r1, [r0]
0x00adb4:	cmp     	r1, #0
0x00adb6:	bgt     	#0xadc0
0x00adb8:	movs    	r1, #0
0x00adba:	strb    	r1, [r0]
0x00adbc:	ldr     	r6, [sp, #0x20]
0x00adbe:	b       	#0xadc8
0x00adc0:	ldr     	r1, [r4, #0x24]
0x00adc2:	movs    	r6, #0
0x00adc4:	mvns    	r6, r6
0x00adc6:	str     	r0, [r1, r5]
0x00adc8:	ldr     	r0, [sp, #0x10]
0x00adca:	adds    	r7, #1
0x00adcc:	cmp     	r7, r0
0x00adce:	blt     	#0xad86
0x00add0:	ldr     	r0, [r4, #0x18]
0x00add2:	ldr     	r3, [r0, r5]
0x00add4:	cmp     	r3, #0
0x00add6:	beq     	#0xae44
0x00add8:	movs    	r2, #0
0x00adda:	movs    	r1, #0
0x00addc:	str     	r2, [sp, #8]
0x00adde:	adds    	r2, r3, #0
0x00ade0:	str     	r1, [sp]
0x00ade2:	str     	r1, [sp, #4]
0x00ade4:	movs    	r1, #0x26
0x00ade6:	movs    	r3, #0
0x00ade8:	movs    	r0, #0xf1
0x00adea:	lsls    	r0, r0, #9
0x00adec:	bl      	#0x7e90
0x00adf0:	movs    	r7, #0
0x00adf2:	cmp     	r0, #0
0x00adf4:	str     	r0, [sp, #0x10]
0x00adf6:	ble     	#0xae44
0x00adf8:	movs    	r1, #0
0x00adfa:	movs    	r2, #0
0x00adfc:	str     	r2, [sp, #8]
0x00adfe:	str     	r1, [sp]
0x00ae00:	str     	r1, [sp, #4]
0x00ae02:	ldr     	r0, [r4, #0x18]
0x00ae04:	movs    	r1, #0x27
0x00ae06:	ldr     	r2, [r0, r5]
0x00ae08:	movs    	r0, #0xf1
0x00ae0a:	adds    	r3, r7, #0
0x00ae0c:	lsls    	r0, r0, #9
0x00ae0e:	bl      	#0x7e90
0x00ae12:	movs    	r3, #1
0x00ae14:	ldrsb   	r1, [r0, r3]
0x00ae16:	ldr     	r2, [sp, #0x14]
0x00ae18:	cmp     	r1, r2
0x00ae1a:	bne     	#0xae3c
0x00ae1c:	ldrb    	r1, [r0]
0x00ae1e:	adds    	r1, #0xff
0x00ae20:	lsls    	r1, r1, #0x18
0x00ae22:	asrs    	r1, r1, #0x18
0x00ae24:	strb    	r1, [r0]
0x00ae26:	cmp     	r1, #0
0x00ae28:	bgt     	#0xae34
0x00ae2a:	movs    	r1, #0
0x00ae2c:	strb    	r1, [r0]
0x00ae2e:	ldr     	r6, [sp, #0x20]
0x00ae30:	b       	#0xae3c
0x00ae32:	b       	#0xae50
0x00ae34:	ldr     	r1, [r4, #0x20]
0x00ae36:	movs    	r6, #0
0x00ae38:	mvns    	r6, r6
0x00ae3a:	str     	r0, [r1, r5]
0x00ae3c:	ldr     	r0, [sp, #0x10]
0x00ae3e:	adds    	r7, #1
0x00ae40:	cmp     	r7, r0
0x00ae42:	blt     	#0xadf8

; ===== candidate_00ae5c =====
0x00ae5c:	push    	{r4, r5, r6, r7, lr}
0x00ae5e:	adds    	r5, r0, #0
0x00ae60:	adds    	r0, #0x80
0x00ae62:	sub     	sp, #0x24
0x00ae64:	str     	r0, [sp, #0x20]
0x00ae66:	ldr     	r7, [r0, #4]
0x00ae68:	movs    	r1, #0
0x00ae6a:	ldr     	r0, [pc, #0x120]
0x00ae6c:	str     	r1, [sp]
0x00ae6e:	str     	r1, [sp, #4]
0x00ae70:	movs    	r2, #0
0x00ae72:	str     	r2, [sp, #8]
0x00ae74:	movs    	r4, #0xf1
0x00ae76:	add     	r0, sb
0x00ae78:	ldr     	r2, [r0, #0x7c]
0x00ae7a:	lsls    	r4, r4, #9
0x00ae7c:	movs    	r1, #0x38
0x00ae7e:	movs    	r3, #0
0x00ae80:	adds    	r0, r4, #0
0x00ae82:	bl      	#0x7e90
0x00ae86:	str     	r0, [sp, #0x1c]
0x00ae88:	ldr     	r0, [r7]
0x00ae8a:	adds    	r6, r5, #0
0x00ae8c:	adds    	r6, #0xd0
0x00ae8e:	cmp     	r0, #0x13
0x00ae90:	bne     	#0xaea2
0x00ae92:	movs    	r3, #1
0x00ae94:	ldrsb   	r0, [r6, r3]
0x00ae96:	cmp     	r0, #0
0x00ae98:	ble     	#0xaea2
0x00ae9a:	adds    	r0, #0xff
0x00ae9c:	strb    	r0, [r6, #1]
0x00ae9e:	add     	sp, #0x24
0x00aea0:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00af90 =====
0x00af90:	push    	{r4, r5, r6, r7, lr}
0x00af92:	adds    	r4, r0, #0
0x00af94:	ldrb    	r0, [r0, #0x14]
0x00af96:	sub     	sp, #0xc
0x00af98:	cmp     	r0, #0
0x00af9a:	bne     	#0xb008
0x00af9c:	movs    	r0, #0x33
0x00af9e:	ldrb    	r0, [r0, r4]
0x00afa0:	cmp     	r0, #0
0x00afa2:	beq     	#0xb008
0x00afa4:	movs    	r1, #0
0x00afa6:	movs    	r2, #0
0x00afa8:	str     	r2, [sp, #8]
0x00afaa:	str     	r1, [sp]
0x00afac:	str     	r1, [sp, #4]
0x00afae:	movs    	r6, #0
0x00afb0:	adds    	r3, r6, #0
0x00afb2:	movs    	r1, #0xe1
0x00afb4:	movs    	r2, #0x27
0x00afb6:	movs    	r0, #0xf1
0x00afb8:	lsls    	r0, r0, #9
0x00afba:	bl      	#0x7e90
0x00afbe:	blx     	#0x91c
0x00afc2:	adds    	r5, r1, #0
0x00afc4:	movs    	r1, #0
0x00afc6:	movs    	r2, #0
0x00afc8:	str     	r2, [sp, #8]
0x00afca:	str     	r1, [sp]
0x00afcc:	str     	r1, [sp, #4]
0x00afce:	ldr     	r0, [r4, #0x7c]
0x00afd0:	movs    	r1, #0x6e
0x00afd2:	ldr     	r2, [r0, #0x1c]
0x00afd4:	movs    	r0, #0xf1
0x00afd6:	adds    	r3, r6, #0
0x00afd8:	lsls    	r0, r0, #9
0x00afda:	bl      	#0x7e90
0x00afde:	movs    	r1, #0
0x00afe0:	movs    	r2, #0
0x00afe2:	adds    	r6, r4, #0
0x00afe4:	adds    	r6, #0x40
0x00afe6:	str     	r2, [sp, #8]
0x00afe8:	str     	r1, [sp]
0x00afea:	str     	r1, [sp, #4]
0x00afec:	adds    	r7, r0, #0
0x00afee:	movs    	r3, #8
0x00aff0:	ldrsh   	r0, [r6, r3]
0x00aff2:	movs    	r1, #0x38
0x00aff4:	adds    	r3, r0, #0
0x00aff6:	movs    	r0, #0xf1
0x00aff8:	adds    	r2, r7, #0
0x00affa:	lsls    	r0, r0, #9
0x00affc:	bl      	#0x7e90
0x00b000:	adds    	r1, r5, #0
0x00b002:	blx     	#0x20
0x00b006:	strh    	r1, [r6, #0xa]
0x00b008:	movs    	r3, #0x28
0x00b00a:	ldrsh   	r0, [r4, r3]
0x00b00c:	cmp     	r0, #0xa
0x00b00e:	bhs     	#0xb028
0x00b010:	adr     	r3, #4
0x00b012:	ldrb    	r3, [r3, r0]
0x00b014:	lsls    	r3, r3, #1
0x00b016:	add     	pc, r3
0x00b018:	asrs    	r7, r0, #4
0x00b01a:	adds    	r5, r2, r4
0x00b01c:	asrs    	r1, r1, #0x14
0x00b01e:	lsrs    	r4, r0, #0x14
0x00b020:	asrs    	r7, r0, #0x14
0x00b022:	adds    	r0, r4, #0
0x00b024:	bl      	#0xae5c
0x00b028:	add     	sp, #0xc
0x00b02a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00b064 =====
0x00b064:	push    	{r0, r1, r2, r3, r6, r7, lr}
0x00b066:	cbz     	r5, #0xb0dc
0x00b068:	beq     	#0xb006
0x00b06a:	bgt     	#0xafe0
0x00b06c:	beq     	#0xb01c
0x00b06e:	movs    	r0, r0
0x00b070:	ldc2l   	p10, c13, [r5, #0x350]
0x00b074:	blo     	#0xb010
0x00b076:	bgt     	#0xb004
0x00b078:	beq     	#0xb028
0x00b07a:	cmp     	r6, #0x2e
0x00b07c:	movs    	r6, r5
0x00b07e:	movs    	r0, r0
0x00b080:	ldrb    	r7, [r6, #5]
0x00b082:	str     	r7, [r3, #0x24]
0x00b084:	ldr     	r1, [r4, #0x74]
0x00b086:	ldr     	r2, [r5, #0x14]
0x00b088:	adds    	r1, #0x21
0x00b08a:	adds    	r0, #0x32
0x00b08c:	adds    	r1, #0x21
0x00b08e:	cmp     	r6, #0x34
0x00b090:	ldr     	r2, [r4, #0x54]
0x00b092:	lsls    	r0, r6, #1
0x00b094:	ldrb    	r7, [r6, #5]
0x00b096:	strb    	r7, [r3, #0xd]
0x00b098:	str     	r0, [r5, #0x14]
0x00b09a:	str     	r6, [r5, #0x24]
0x00b09c:	movs    	r1, #0x69
0x00b09e:	adds    	r4, #0x34
0x00b0a0:	adds    	r1, #0x21
0x00b0a2:	cmp     	r6, #0x34
0x00b0a4:	ldr     	r2, [r4, #0x54]
0x00b0a6:	lsls    	r0, r6, #1
0x00b0a8:	str     	r2, [r4, #0x54]
0x00b0aa:	strb    	r1, [r4, #0x11]
0x00b0ac:	str     	r4, [r6, #0x14]
0x00b0ae:	ldr     	r3, [r4, #0x34]
0x00b0b0:	str     	r0, [r0, #0x14]
0x00b0b2:	strb    	r4, [r6, #0x11]
0x00b0b4:	str     	r1, [r4, #0x34]
0x00b0b6:	cmp     	r6, #0x6b
0x00b0b8:	ldr     	r1, [r4, #0x64]
0x00b0ba:	lsls    	r1, r5, #1
0x00b0bc:	adds    	r2, #0x31
0x00b0be:	movs    	r1, r6
0x00b0c0:	push    	{r1, r2, r3, r6, r7}
0x00b0c2:	stc2l   	p0, c13, [r3], {0xd6}
0x00b0c6:	movs    	r0, r0
0x00b0c8:	movs    	r0, r0
0x00b0ca:	movs    	r0, r0
0x00b0cc:	pop     	{r0, r4, r5}
0x00b0ce:	lsls    	r6, r6, #2
0x00b0d0:	adr     	r1, #0x344
0x00b0d2:	b.w     	#0x1e005e

; ===== candidate_00b0c0 =====
0x00b0c0:	push    	{r1, r2, r3, r6, r7}
0x00b0c2:	stc2l   	p0, c13, [r3], {0xd6}
0x00b0c6:	movs    	r0, r0
0x00b0c8:	movs    	r0, r0
0x00b0ca:	movs    	r0, r0
0x00b0cc:	pop     	{r0, r4, r5}
0x00b0ce:	lsls    	r6, r6, #2
0x00b0d0:	adr     	r1, #0x344
0x00b0d2:	b.w     	#0x1e005e

; ===== candidate_00b0de =====
0x00b0de:	push    	{r0, r1, r2, r3, r4, r5, r7}

; ===== candidate_00b128 =====
0x00b128:	push    	{r0, r1, r2, r4, r6, r7}
0x00b12a:	add     	r4, sp, #0x330
0x00b12c:	beq     	#0xb0dc
0x00b12e:	add     	r4, sp, #0x28c
0x00b130:	b       	#0xaeca
0x00b132:	b       	#0xb6da
0x00b134:	adr     	r5, #0x2e4

; ===== candidate_00b158 =====
0x00b158:	push    	{r0, r1, r2, r4, r6, r7}
0x00b15a:	add     	r4, sp, #0x330
0x00b15c:	add     	r4, sp, #0x28c
0x00b15e:	udf     	#0xce
0x00b160:	add     	r0, sp, #0x2dc
0x00b162:	cbnz    	r2, #0xb198
0x00b164:	stm     	r3!, {r0, r1, r4, r6, r7}
0x00b166:	pop     	{r2, r3, r4, r5, r7}
0x00b168:	bgt     	#0xb0f4
0x00b16a:	adr     	r1, #0x28c
0x00b16c:	movs    	r0, r0
0x00b16e:	movs    	r0, r0
0x00b170:	itt     	gt
0x00b172:	subgt   	sp, #0x11c
0x00b174:	udf     	#0xce
0x00b176:	add     	r0, sp, #0x2dc
0x00b178:	pop     	{r0, r2, r4, r6, r7, pc}

; ===== candidate_00b18e =====
0x00b18e:	push    	{r0, r1, r2, r3, r4, r5, r7}

; ===== candidate_00b2d4 =====
0x00b2d4:	push    	{r0, r1, r2, r4, r6, r7}
0x00b2d6:	add     	r4, sp, #0x330
0x00b2d8:	bl      	#0xff0d5c7c
0x00b2dc:	movs    	r0, r0
0x00b2de:	movs    	r0, r0
0x00b2e0:	udf     	#0xce
0x00b2e2:	movs    	r0, r0
0x00b2e4:	adr     	r1, #0x344
0x00b2e6:	bl      	#0x1df860
0x00b2ea:	bvc     	#0xb266
0x00b2ec:	pop     	{r2, r3, r4, r5, r7}
0x00b2ee:	bgt     	#0xb27a
0x00b2f0:	movs    	r0, r0
0x00b2f2:	movs    	r0, r0
0x00b2f4:	bgt     	#0xb280
0x00b2f6:	itttt   	gt
0x00b2f8:	cbnz    	r2, #0xb368
0x00b2fa:	cbnz    	r1, #0xb36c
0x00b2fc:	addgt   	r4, sp, #0x28c
0x00b2fe:	cbnz    	r2, #0xb36e
0x00b300:	bgt     	#0xb28c
0x00b302:	cbnz    	r2, #0xb338
0x00b304:	stm     	r3!, {r0, r1, r4, r6, r7}
0x00b306:	ldm     	r3!, {r2, r4, r5, r7}
0x00b308:	pop     	{r2, r3, r4, r5, r7}
0x00b30a:	bgt     	#0xb296
0x00b30c:	adr     	r1, #0x28c
0x00b30e:	movs    	r0, r0
0x00b310:	cbnz    	r1, #0xb380
0x00b312:	add     	r7, sp, #0x2d8
0x00b314:	pop     	{r2, r3, r4, r5, r7}
0x00b316:	bgt     	#0xb2a2
0x00b318:	cbnz    	r2, #0xb388
0x00b31a:	bgt     	#0xb2a6
0x00b31c:	cbz     	r6, #0xb354
0x00b31e:	blo     	#0xb29c
0x00b320:	cbnz    	r2, #0xb356
0x00b322:	stm     	r3!, {r0, r1, r4, r6, r7}
0x00b324:	adr     	r1, #0x28c
0x00b326:	movs    	r0, r0
0x00b328:	b.w     	#0x5c4298
0x00b32c:	movs    	r0, r0
0x00b32e:	movs    	r0, r0
0x00b330:	pop     	{r2, r3, r4, r5, r7}
0x00b332:	bgt     	#0xb2be
0x00b334:	movs    	r0, r0
0x00b336:	movs    	r0, r0
0x00b338:	stm     	r4!, {r0, r6, r7}
0x00b33a:	stcl    	p0, c0, [ip], {0}
0x00b33e:	movs    	r0, r0
0x00b340:	cbz     	r1, #0xb3b0
0x00b342:	ldc2    	p15, c14, [r0], #0x338

; ===== candidate_00b34e =====
0x00b34e:	push    	{r0, r1, r2, r3, r4, r5, r7}

; ===== candidate_00b4a8 =====
0x00b4a8:	push    	{r0, r1, r5}
0x00b4aa:	cbnz    	r3, #0xb520
0x00b4ac:	pop     	{r1, r3, r4, r5, r6, r7}
0x00b4ae:	bmi     	#0xb460
0x00b4b0:	ldm     	r6, {r0, r2, r3, r4, r6, r7}
0x00b4b2:	ite     	lt

; ===== candidate_00b4e4 =====
0x00b4e4:	push    	{r0, r2, r3, r6, r7, lr}
0x00b4e6:	add     	r6, sp, #0x33c
0x00b4e8:	pop     	{r0, r2, r4, r6, r7, pc}
0x00b4ea:	movs    	r1, r4
0x00b4ec:	add     	r2, sp, #0x2fc
0x00b4ee:	pop     	{r1, r3, r6, r7}
0x00b4f0:	pop     	{r0, r2, r4, r6, r7, pc}
