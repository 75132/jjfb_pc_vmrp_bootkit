; fallback candidate disassembly from Thumb prologues; true code is ARM entry + Thumb functions.

; ARM entry
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0x2c04
0x000018:	pop     	{r4, pc}
0x00001c:	andeq   	r4, r0, r8, ror r7
0x000020:	ands    	r2, r0, #128, #8
0x000024:	rsbmi   	r0, r0, #0
0x000028:	eors    	r3, r2, r1, asr #32
0x00002c:	rsbhs   	r1, r1, #0
0x000030:	rsbs    	ip, r0, r1, lsr #3
0x000034:	blo     	#0xbc
0x000038:	rsbs    	ip, r0, r1, lsr #8
0x00003c:	blo     	#0x80
0x000040:	lsl     	r0, r0, #8
0x000044:	orr     	r2, r2, #0xff000000
0x000048:	rsbs    	ip, r0, r1, lsr #4
0x00004c:	blo     	#0xb0
0x000050:	rsbs    	ip, r0, r1, lsr #8
0x000054:	blo     	#0x80
0x000058:	lsl     	r0, r0, #8
0x00005c:	orr     	r2, r2, #0xff0000
0x000060:	rsbs    	ip, r0, r1, lsr #8
0x000064:	lslhs   	r0, r0, #8
0x000068:	orrhs   	r2, r2, #0xff00
0x00006c:	rsbs    	ip, r0, r1, lsr #4
0x000070:	blo     	#0xb0
0x000074:	rsbs    	ip, r0, #0
0x000078:	bhs     	#0xf8
0x00007c:	lsrhs   	r0, r0, #8
0x000080:	rsbs    	ip, r0, r1, lsr #7
0x000084:	subhs   	r1, r1, r0, lsl #7
0x000088:	adc     	r2, r2, r2
0x00008c:	rsbs    	ip, r0, r1, lsr #6
0x000090:	subhs   	r1, r1, r0, lsl #6
0x000094:	adc     	r2, r2, r2
0x000098:	rsbs    	ip, r0, r1, lsr #5
0x00009c:	subhs   	r1, r1, r0, lsl #5
0x0000a0:	adc     	r2, r2, r2
0x0000a4:	rsbs    	ip, r0, r1, lsr #4
0x0000a8:	subhs   	r1, r1, r0, lsl #4
0x0000ac:	adc     	r2, r2, r2
0x0000b0:	rsbs    	ip, r0, r1, lsr #3
0x0000b4:	subhs   	r1, r1, r0, lsl #3
0x0000b8:	adc     	r2, r2, r2
0x0000bc:	rsbs    	ip, r0, r1, lsr #2
0x0000c0:	subhs   	r1, r1, r0, lsl #2
0x0000c4:	adc     	r2, r2, r2
0x0000c8:	rsbs    	ip, r0, r1, lsr #1
0x0000cc:	subhs   	r1, r1, r0, lsl #1
0x0000d0:	adc     	r2, r2, r2
0x0000d4:	rsbs    	ip, r0, r1
0x0000d8:	subhs   	r1, r1, r0
0x0000dc:	adcs    	r2, r2, r2
0x0000e0:	bhs     	#0x7c
0x0000e4:	eors    	r0, r2, r3, asr #31
0x0000e8:	add     	r0, r0, r3, lsr #31
0x0000ec:	rsbhs   	r1, r1, #0
0x0000f0:	bx      	lr
0x0000f4:	andeq   	r4, r0, r8, ror r7
0x0000f8:	mov     	r0, #2
0x0000fc:	mov     	r1, #2
0x000100:	b       	#0x118
0x000104:	strmi   	r4, [r8, -r0, lsl #14]

; ===== candidate_000008 =====
0x000008:	ands    	r0, r2
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	lsrs    	r2, r7, #0xb

; ===== candidate_00000a =====
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	lsrs    	r2, r7, #0xb

; ===== candidate_00011a =====
0x00011a:	stmdb   	sp!, {r2}

; ===== candidate_000134 =====
0x000134:	push    	{r4, r5, r6, lr}
0x000136:	ldr     	r6, [pc, #0x38]
0x000138:	adds    	r5, r1, #0
0x00013a:	adds    	r1, r0, #0
0x00013c:	adds    	r4, r0, #0
0x00013e:	add     	r6, pc
0x000140:	adds    	r0, r6, #0
0x000142:	bl      	#0x146
0x000146:	adds    	r2, r0, #0
0x000148:	cmp     	r0, r6
0x00014a:	bne     	#0x15a
0x00014c:	adds    	r1, r5, #0
0x00014e:	adds    	r0, r4, #0
0x000150:	bl      	#0x194
0x000154:	pop     	{r4, r5, r6}
0x000156:	pop     	{r3}
0x000158:	bx      	r3
0x00015a:	ldr     	r0, [pc, #0x18]
0x00015c:	add     	r0, pc
0x00015e:	cmp     	r2, r0
0x000160:	beq     	#0x16a
0x000162:	adds    	r1, r5, #0
0x000164:	adds    	r0, r4, #0
0x000166:	bl      	#0x108
0x00016a:	movs    	r0, #0
0x00016c:	b       	#0x154
0x00016e:	movs    	r0, r0
0x000170:	mcr2    	p15, #6, pc, c5, c7, #7
0x000174:	mcr2    	p15, #5, pc, c5, c7, #7
0x000178:	bx      	pc

; ===== candidate_000194 =====
0x000194:	push    	{r3, r4, r5, lr}
0x000196:	subs    	r2, r0, #1
0x000198:	cmp     	r2, #0xd
0x00019a:	adr     	r4, #0x90
0x00019c:	bhs     	#0x1ec
0x00019e:	movs    	r2, #0x17
0x0001a0:	ldr     	r3, [pc, #0x8c]
0x0001a2:	muls    	r2, r0, r2
0x0001a4:	add     	r3, pc
0x0001a6:	adds    	r5, r2, r3
0x0001a8:	subs    	r5, #0x17
0x0001aa:	cmp     	r0, #2
0x0001ac:	bne     	#0x1d8
0x0001ae:	lsls    	r0, r1, #5
0x0001b0:	bpl     	#0x1b6
0x0001b2:	adr     	r4, #0x80
0x0001b4:	b       	#0x1ee
0x0001b6:	ldr     	r0, [pc, #0x90]
0x0001b8:	ands    	r0, r1
0x0001ba:	beq     	#0x1c0
0x0001bc:	adr     	r4, #0x8c
0x0001be:	b       	#0x1ee
0x0001c0:	lsls    	r0, r1, #3
0x0001c2:	bpl     	#0x1c8
0x0001c4:	adr     	r4, #0x94
0x0001c6:	b       	#0x1ee
0x0001c8:	lsls    	r0, r1, #2
0x0001ca:	bpl     	#0x1d0
0x0001cc:	adr     	r4, #0x98
0x0001ce:	b       	#0x1ee
0x0001d0:	lsls    	r0, r1, #1
0x0001d2:	bpl     	#0x1ee
0x0001d4:	adr     	r4, #0x9c
0x0001d6:	b       	#0x1ee
0x0001d8:	cmp     	r0, #8
0x0001da:	bne     	#0x1e0
0x0001dc:	adds    	r4, r1, #0
0x0001de:	b       	#0x1ee
0x0001e0:	cmp     	r0, #9
0x0001e2:	bne     	#0x1ee
0x0001e4:	cmp     	r1, #1
0x0001e6:	bne     	#0x1ee
0x0001e8:	adr     	r5, #0x98
0x0001ea:	b       	#0x1ee
0x0001ec:	adr     	r5, #0xac
0x0001ee:	movs    	r0, #0xa
0x0001f0:	bl      	#0x2b4
0x0001f4:	ldrb    	r0, [r5]
0x0001f6:	cmp     	r0, #0
0x0001f8:	beq     	#0x208
0x0001fa:	ldrb    	r0, [r5]
0x0001fc:	adds    	r5, #1
0x0001fe:	bl      	#0x2b4
0x000202:	ldrb    	r0, [r5]
0x000204:	cmp     	r0, #0
0x000206:	bne     	#0x1fa
0x000208:	ldrb    	r0, [r4]
0x00020a:	cmp     	r0, #0
0x00020c:	beq     	#0x21c
0x00020e:	ldrb    	r0, [r4]
0x000210:	adds    	r4, #1
0x000212:	bl      	#0x2b4
0x000216:	ldrb    	r0, [r4]
0x000218:	cmp     	r0, #0
0x00021a:	bne     	#0x20e
0x00021c:	movs    	r0, #0xa
0x00021e:	bl      	#0x2b4
0x000222:	pop     	{r3, r4, r5}
0x000224:	pop     	{r3}
0x000226:	movs    	r0, #1
0x000228:	bx      	r3
0x00022a:	movs    	r0, r0
0x00022c:	movs    	r0, r0
0x00022e:	movs    	r0, r0
0x000230:	subs    	r5, #0xa0
0x000232:	movs    	r0, r0
0x000234:	ldr     	r1, [r1, #0x64]
0x000236:	str     	r6, [r6, #0x14]
0x000238:	ldr     	r4, [r5, #0x14]
0x00023a:	movs    	r0, #0x64
0x00023c:	strb    	r7, [r1, #1]
0x00023e:	strb    	r5, [r4, #9]
0x000240:	strb    	r1, [r4, #0x11]
0x000242:	ldr     	r1, [r5, #0x74]
0x000244:	lsls    	r6, r5, #1
0x000246:	movs    	r0, r0
0x000248:	movs    	r2, r0
0x00024a:	lsrs    	r0, r0, #0x20
0x00024c:	ldr     	r4, [r0, #0x14]
0x00024e:	ldr     	r6, [r6, #0x14]
0x000250:	str     	r4, [r4, #0x54]
0x000252:	tst     	r0, r4
0x000254:	movs    	r0, #0x79
0x000256:	str     	r2, [r3, #0x54]
0x000258:	ldr     	r2, [r6, #0x74]
0x00025a:	movs    	r0, r0
0x00025c:	strb    	r7, [r1, #0x19]
0x00025e:	strb    	r5, [r4, #9]
0x000260:	ldr     	r6, [r4, #0x44]
0x000262:	strb    	r7, [r5, #0x1d]
0x000264:	movs    	r0, r0
0x000266:	movs    	r0, r0
0x000268:	ldr     	r5, [r2, #0x64]
0x00026a:	str     	r4, [r4, #0x54]
0x00026c:	str     	r2, [r6, #0x64]
0x00026e:	ldr     	r4, [r5, #0x74]
0x000270:	lsls    	r7, r6, #1
0x000272:	movs    	r0, r0
0x000274:	ldr     	r1, [r1, #0x64]
0x000276:	ldrb    	r5, [r4, #1]
0x000278:	str     	r1, [r4, #0x34]
0x00027a:	movs    	r0, #0x74
0x00027c:	str     	r2, [r2, #0x54]
0x00027e:	strb    	r3, [r6, #0x15]
0x000280:	strb    	r4, [r5, #0x11]
0x000282:	movs    	r0, r0
0x000284:	movs    	r0, #0x3a
0x000286:	str     	r0, [r1, #0x54]
0x000288:	strb    	r1, [r4, #1]
0x00028a:	ldr     	r0, [r4, #0x50]
0x00028c:	ldr     	r5, [r4, #0x54]
0x00028e:	strb    	r7, [r5, #9]
0x000290:	movs    	r0, #0x79
0x000292:	ldr     	r3, [r4, #0x74]
0x000294:	strb    	r2, [r6, #9]
0x000296:	strb    	r5, [r6, #1]
0x000298:	str     	r4, [r6, #0x54]
0x00029a:	lsls    	r4, r4, #1
0x00029c:	ldr     	r5, [r2, #0x64]
0x00029e:	ldr     	r3, [r5, #0x64]
0x0002a0:	strb    	r7, [r5, #0x1d]
0x0002a2:	movs    	r0, #0x6e
0x0002a4:	ldr     	r3, [r6, #0x14]
0x0002a6:	ldr     	r7, [r4, #0x64]
0x0002a8:	ldr     	r1, [r4, #0x44]
0x0002aa:	movs    	r0, r0
0x0002ac:	bx      	pc

; ===== candidate_0002b4 =====
0x0002b4:	push    	{r3, lr}
0x0002b6:	add     	r3, sp, #0
0x0002b8:	strb    	r0, [r3]
0x0002ba:	movs    	r0, #3
0x0002bc:	mov     	r1, sp
0x0002be:	svc     	#0xab
0x0002c0:	add     	sp, #4
0x0002c2:	pop     	{r3}
0x0002c4:	bx      	r3
0x0002c6:	movs    	r0, r0
0x0002c8:	movs    	r0, r1
0x0002ca:	b       	#0xfffffe0c
0x0002cc:	asrs    	r0, r1, #0x20
0x0002ce:	b       	#0xfffffe10
0x0002d0:	movs    	r1, r0
0x0002d2:	b       	#0x3d6
0x0002d4:	vrhadd.u16	d14, d14, d31
0x0002d8:	movs    	r4, r0
0x0002da:	movs    	r0, r0
0x0002dc:	lsls    	r4, r3, #6
0x0002de:	movs    	r0, r0
0x0002e0:	str     	r0, [sp]
0x0002e2:	b       	#0x626
0x0002e4:	vrhadd.u16	d14, d14, d31
0x0002e8:	adds    	r0, #0x14
0x0002ea:	b       	#0xfffffe2c
0x0002ec:	cmp     	r7, #0xc0
0x0002ee:	b       	#0x632
0x0002f0:	stm     	r0!, {r0, r1, r4, r7}
0x0002f2:	b       	#0x478
0x0002f4:	adds    	r0, #0x18
0x0002f6:	b       	#0xaba
0x0002f8:	asrs    	r1, r0, #7
0x0002fa:	b       	#0x3c2
0x0002fc:	lsls    	r3, r2, #6
0x0002fe:	b       	#0x342
0x000300:	vrhadd.u16	d14, d14, d31
0x000304:	strh    	r7, [r3, #0x28]
0x000306:	str     	r3, [r5, r7]
0x000308:	push    	{r4, r5, lr}
0x00030a:	ldr     	r4, [pc, #0xb4]
0x00030c:	movs    	r2, #0x1c
0x00030e:	add     	r4, pc
0x000310:	ldr     	r0, [r4, #0x38]
0x000312:	movs    	r1, #0
0x000314:	ldr     	r3, [r0, #0x38]
0x000316:	ldr     	r0, [pc, #0xac]
0x000318:	sub     	sp, #0xc
0x00031a:	add     	r0, sb
0x00031c:	blx     	r3
0x00031e:	movs    	r2, #0
0x000320:	movs    	r0, #0
0x000322:	str     	r0, [sp]
0x000324:	ldr     	r1, [pc, #0x9c]
0x000326:	movs    	r3, #0
0x000328:	add     	r1, sb
0x00032a:	str     	r1, [sp, #4]
0x00032c:	movs    	r1, #0x64
0x00032e:	movs    	r0, #1
0x000330:	str     	r2, [sp, #8]
0x000332:	bl      	#0x2cdc
0x000336:	ldr     	r1, [pc, #0x8c]
0x000338:	movs    	r0, #0
0x00033a:	add     	r1, sb
0x00033c:	subs    	r1, #0x7c
0x00033e:	str     	r0, [r1, #8]
0x000340:	ldr     	r5, [pc, #0x80]
0x000342:	str     	r0, [r1, #0x10]
0x000344:	str     	r0, [r1, #0xc]
0x000346:	add     	r5, sb
0x000348:	subs    	r5, #0xfc
0x00034a:	movs    	r0, #1
0x00034c:	str     	r0, [r5, #0x18]
0x00034e:	ldr     	r0, [r4, #0x38]
0x000350:	ldr     	r2, [pc, #0x74]
0x000352:	ldr     	r1, [r0, #0x68]
0x000354:	add     	r2, sb
0x000356:	str     	r1, [r5, #0x2c]
0x000358:	ldr     	r1, [r0, #0xc]
0x00035a:	ldr     	r4, [pc, #0x70]
0x00035c:	str     	r1, [r5, #0x30]
0x00035e:	ldr     	r1, [r0, #0x10]
0x000360:	str     	r1, [r5, #0x34]
0x000362:	ldr     	r1, [r0, #0x14]
0x000364:	str     	r1, [r5, #0x38]
0x000366:	ldr     	r1, [r0, #0x18]
0x000368:	str     	r1, [r5, #0x3c]
0x00036a:	ldr     	r1, [r0, #0x1c]
0x00036c:	str     	r1, [r5, #0x40]
0x00036e:	ldr     	r1, [r0, #0x20]
0x000370:	str     	r1, [r5, #0x44]
0x000372:	ldr     	r1, [r0, #0x24]
0x000374:	str     	r1, [r5, #0x48]
0x000376:	ldr     	r1, [r0, #0x28]
0x000378:	str     	r1, [r5, #0x4c]
0x00037a:	ldr     	r1, [r0, #0x2c]
0x00037c:	str     	r1, [r5, #0x50]
0x00037e:	ldr     	r1, [r0, #0x30]
0x000380:	str     	r1, [r5, #0x54]
0x000382:	ldr     	r1, [r0, #0x34]
0x000384:	str     	r1, [r5, #0x58]
0x000386:	ldr     	r1, [r0, #0x38]
0x000388:	str     	r1, [r5, #0x5c]
0x00038a:	ldr     	r1, [r0, #0x3c]
0x00038c:	str     	r1, [r5, #0x60]
0x00038e:	ldr     	r1, [r0, #0x40]
0x000390:	str     	r1, [r5, #0x64]
0x000392:	ldr     	r1, [r0, #0x44]
0x000394:	str     	r1, [r5, #0x68]
0x000396:	ldr     	r1, [r0, #0x48]
0x000398:	str     	r1, [r5, #0x6c]
0x00039a:	ldr     	r1, [r0, #0x4c]
0x00039c:	str     	r1, [r5, #0x70]
0x00039e:	movs    	r1, #0
0x0003a0:	str     	r1, [r2]
0x0003a2:	movs    	r1, #1
0x0003a4:	lsls    	r1, r1, #9
0x0003a6:	adds    	r0, r0, r1
0x0003a8:	ldr     	r3, [r0, #8]
0x0003aa:	movs    	r1, #7
0x0003ac:	adds    	r2, r4, #0
0x0003ae:	movs    	r0, #0
0x0003b0:	blx     	r3
0x0003b2:	cmp     	r0, r4
0x0003b4:	bne     	#0x3ba
0x0003b6:	subs    	r0, #2
0x0003b8:	str     	r0, [r5, #0x28]
0x0003ba:	add     	sp, #0xc
0x0003bc:	pop     	{r4, r5, pc}

; ===== candidate_000308 =====
0x000308:	push    	{r4, r5, lr}
0x00030a:	ldr     	r4, [pc, #0xb4]
0x00030c:	movs    	r2, #0x1c
0x00030e:	add     	r4, pc
0x000310:	ldr     	r0, [r4, #0x38]
0x000312:	movs    	r1, #0
0x000314:	ldr     	r3, [r0, #0x38]
0x000316:	ldr     	r0, [pc, #0xac]
0x000318:	sub     	sp, #0xc
0x00031a:	add     	r0, sb
0x00031c:	blx     	r3
0x00031e:	movs    	r2, #0
0x000320:	movs    	r0, #0
0x000322:	str     	r0, [sp]
0x000324:	ldr     	r1, [pc, #0x9c]
0x000326:	movs    	r3, #0
0x000328:	add     	r1, sb
0x00032a:	str     	r1, [sp, #4]
0x00032c:	movs    	r1, #0x64
0x00032e:	movs    	r0, #1
0x000330:	str     	r2, [sp, #8]
0x000332:	bl      	#0x2cdc
0x000336:	ldr     	r1, [pc, #0x8c]
0x000338:	movs    	r0, #0
0x00033a:	add     	r1, sb
0x00033c:	subs    	r1, #0x7c
0x00033e:	str     	r0, [r1, #8]
0x000340:	ldr     	r5, [pc, #0x80]
0x000342:	str     	r0, [r1, #0x10]
0x000344:	str     	r0, [r1, #0xc]
0x000346:	add     	r5, sb
0x000348:	subs    	r5, #0xfc
0x00034a:	movs    	r0, #1
0x00034c:	str     	r0, [r5, #0x18]
0x00034e:	ldr     	r0, [r4, #0x38]
0x000350:	ldr     	r2, [pc, #0x74]
0x000352:	ldr     	r1, [r0, #0x68]
0x000354:	add     	r2, sb
0x000356:	str     	r1, [r5, #0x2c]
0x000358:	ldr     	r1, [r0, #0xc]
0x00035a:	ldr     	r4, [pc, #0x70]
0x00035c:	str     	r1, [r5, #0x30]
0x00035e:	ldr     	r1, [r0, #0x10]
0x000360:	str     	r1, [r5, #0x34]
0x000362:	ldr     	r1, [r0, #0x14]
0x000364:	str     	r1, [r5, #0x38]
0x000366:	ldr     	r1, [r0, #0x18]
0x000368:	str     	r1, [r5, #0x3c]
0x00036a:	ldr     	r1, [r0, #0x1c]
0x00036c:	str     	r1, [r5, #0x40]
0x00036e:	ldr     	r1, [r0, #0x20]
0x000370:	str     	r1, [r5, #0x44]
0x000372:	ldr     	r1, [r0, #0x24]
0x000374:	str     	r1, [r5, #0x48]
0x000376:	ldr     	r1, [r0, #0x28]
0x000378:	str     	r1, [r5, #0x4c]
0x00037a:	ldr     	r1, [r0, #0x2c]
0x00037c:	str     	r1, [r5, #0x50]
0x00037e:	ldr     	r1, [r0, #0x30]
0x000380:	str     	r1, [r5, #0x54]
0x000382:	ldr     	r1, [r0, #0x34]
0x000384:	str     	r1, [r5, #0x58]
0x000386:	ldr     	r1, [r0, #0x38]
0x000388:	str     	r1, [r5, #0x5c]
0x00038a:	ldr     	r1, [r0, #0x3c]
0x00038c:	str     	r1, [r5, #0x60]
0x00038e:	ldr     	r1, [r0, #0x40]
0x000390:	str     	r1, [r5, #0x64]
0x000392:	ldr     	r1, [r0, #0x44]
0x000394:	str     	r1, [r5, #0x68]
0x000396:	ldr     	r1, [r0, #0x48]
0x000398:	str     	r1, [r5, #0x6c]
0x00039a:	ldr     	r1, [r0, #0x4c]
0x00039c:	str     	r1, [r5, #0x70]
0x00039e:	movs    	r1, #0
0x0003a0:	str     	r1, [r2]
0x0003a2:	movs    	r1, #1
0x0003a4:	lsls    	r1, r1, #9
0x0003a6:	adds    	r0, r0, r1
0x0003a8:	ldr     	r3, [r0, #8]
0x0003aa:	movs    	r1, #7
0x0003ac:	adds    	r2, r4, #0
0x0003ae:	movs    	r0, #0
0x0003b0:	blx     	r3
0x0003b2:	cmp     	r0, r4
0x0003b4:	bne     	#0x3ba
0x0003b6:	subs    	r0, #2
0x0003b8:	str     	r0, [r5, #0x28]
0x0003ba:	add     	sp, #0xc
0x0003bc:	pop     	{r4, r5, pc}

; ===== candidate_0003d0 =====
0x0003d0:	push    	{r4, r5, r6, r7, lr}
0x0003d2:	sub     	sp, #0x14
0x0003d4:	movs    	r7, #0
0x0003d6:	movs    	r2, #0
0x0003d8:	movs    	r1, #0
0x0003da:	str     	r2, [sp, #8]
0x0003dc:	adds    	r3, r7, #0
0x0003de:	adds    	r5, r0, #0
0x0003e0:	adds    	r2, r0, #0
0x0003e2:	str     	r1, [sp]
0x0003e4:	str     	r1, [sp, #4]
0x0003e6:	movs    	r1, #0x44
0x0003e8:	movs    	r0, #0xf1
0x0003ea:	movs    	r4, #0
0x0003ec:	lsls    	r0, r0, #9
0x0003ee:	bl      	#0x2cdc
0x0003f2:	ldr     	r0, [pc, #0x1e8]
0x0003f4:	movs    	r1, #0
0x0003f6:	add     	r0, sb
0x0003f8:	strb    	r7, [r0]
0x0003fa:	str     	r1, [sp]
0x0003fc:	str     	r1, [sp, #4]
0x0003fe:	movs    	r2, #0
0x000400:	str     	r2, [sp, #8]
0x000402:	movs    	r1, #0x45
0x000404:	movs    	r0, #0xf1
0x000406:	adds    	r3, r7, #0
0x000408:	lsls    	r0, r0, #9
0x00040a:	ldr     	r2, [r5, #8]
0x00040c:	bl      	#0x2cdc
0x000410:	movs    	r1, #0
0x000412:	str     	r1, [sp]
0x000414:	str     	r1, [sp, #4]
0x000416:	adds    	r6, r0, #0
0x000418:	movs    	r2, #0
0x00041a:	str     	r2, [sp, #8]
0x00041c:	movs    	r0, #0xf1
0x00041e:	adds    	r3, r7, #0
0x000420:	movs    	r1, #0x45
0x000422:	lsls    	r0, r0, #9
0x000424:	ldr     	r2, [r5, #8]
0x000426:	bl      	#0x2cdc
0x00042a:	movs    	r1, #0
0x00042c:	adds    	r7, r0, #0
0x00042e:	movs    	r2, #0
0x000430:	str     	r2, [sp, #8]
0x000432:	str     	r1, [sp]
0x000434:	str     	r1, [sp, #4]
0x000436:	movs    	r1, #0x14
0x000438:	movs    	r2, #0x6d
0x00043a:	movs    	r0, #0xf1
0x00043c:	adds    	r3, r6, #0
0x00043e:	lsls    	r0, r0, #9
0x000440:	bl      	#0x2cdc
0x000444:	ldr     	r1, [pc, #0x194]
0x000446:	add     	r1, sb
0x000448:	str     	r7, [r1, #4]
0x00044a:	movs    	r1, #0
0x00044c:	str     	r1, [sp]
0x00044e:	str     	r1, [sp, #4]
0x000450:	movs    	r2, #0
0x000452:	movs    	r7, #0
0x000454:	movs    	r6, #0xf1
0x000456:	lsls    	r6, r6, #9
0x000458:	adds    	r3, r7, #0
0x00045a:	str     	r2, [sp, #8]
0x00045c:	movs    	r1, #0x46
0x00045e:	adds    	r0, r6, #0
0x000460:	ldr     	r2, [r5, #8]
0x000462:	bl      	#0x2cdc
0x000466:	lsls    	r0, r0, #0x18
0x000468:	cmp     	r0, #0
0x00046a:	ble     	#0x4d4
0x00046c:	cmp     	r4, #0
0x00046e:	bne     	#0x486
0x000470:	movs    	r1, #0
0x000472:	str     	r1, [sp]
0x000474:	str     	r1, [sp, #4]
0x000476:	movs    	r2, #0
0x000478:	movs    	r1, #0x13
0x00047a:	adds    	r3, r7, #0
0x00047c:	adds    	r0, r6, #0
0x00047e:	str     	r2, [sp, #8]
0x000480:	bl      	#0x2cdc
0x000484:	adds    	r4, r0, #0
0x000486:	movs    	r1, #0
0x000488:	movs    	r2, #0
0x00048a:	str     	r2, [sp, #8]
0x00048c:	str     	r1, [sp]
0x00048e:	str     	r1, [sp, #4]
0x000490:	movs    	r1, #0xa8
0x000492:	adds    	r2, r5, #0
0x000494:	adds    	r3, r7, #0
0x000496:	adds    	r0, r6, #0
0x000498:	bl      	#0x2cdc
0x00049c:	movs    	r1, #0
0x00049e:	str     	r1, [sp]
0x0004a0:	str     	r1, [sp, #4]
0x0004a2:	adds    	r6, r0, #0
0x0004a4:	movs    	r2, #0
0x0004a6:	str     	r2, [sp, #8]
0x0004a8:	movs    	r0, #0xf1
0x0004aa:	adds    	r3, r7, #0
0x0004ac:	movs    	r1, #0x46
0x0004ae:	lsls    	r0, r0, #9
0x0004b0:	ldr     	r2, [r5, #8]
0x0004b2:	bl      	#0x2cdc
0x0004b6:	movs    	r1, #0x45
0x0004b8:	strb    	r0, [r1, r6]
0x0004ba:	movs    	r1, #0
0x0004bc:	movs    	r2, #0
0x0004be:	str     	r2, [sp, #8]
0x0004c0:	str     	r1, [sp]
0x0004c2:	str     	r1, [sp, #4]
0x0004c4:	adds    	r3, r6, #0
0x0004c6:	adds    	r2, r4, #0
0x0004c8:	movs    	r1, #0x36
0x0004ca:	movs    	r0, #0xf1
0x0004cc:	lsls    	r0, r0, #9
0x0004ce:	bl      	#0x2cdc
0x0004d2:	b       	#0x44a
0x0004d4:	cmp     	r4, #0
0x0004d6:	bne     	#0x4f2
0x0004d8:	movs    	r1, #0
0x0004da:	str     	r1, [sp]
0x0004dc:	str     	r1, [sp, #4]
0x0004de:	movs    	r2, #0
0x0004e0:	movs    	r1, #0xa
0x0004e2:	movs    	r3, #4
0x0004e4:	movs    	r0, #0xf1
0x0004e6:	lsls    	r0, r0, #9
0x0004e8:	str     	r2, [sp, #8]
0x0004ea:	bl      	#0x2cdc
0x0004ee:	str     	r0, [sp, #0xc]
0x0004f0:	b       	#0x588
0x0004f2:	movs    	r1, #0
0x0004f4:	movs    	r2, #0
0x0004f6:	str     	r2, [sp, #8]
0x0004f8:	str     	r1, [sp]
0x0004fa:	str     	r1, [sp, #4]
0x0004fc:	movs    	r1, #0x26

; ===== candidate_0005e0 =====
0x0005e0:	push    	{r4, r5, r6, r7, lr}
0x0005e2:	sub     	sp, #0x14
0x0005e4:	movs    	r7, #0
0x0005e6:	movs    	r2, #0
0x0005e8:	movs    	r1, #0
0x0005ea:	str     	r2, [sp, #8]
0x0005ec:	adds    	r3, r7, #0
0x0005ee:	adds    	r5, r0, #0
0x0005f0:	adds    	r2, r0, #0
0x0005f2:	str     	r1, [sp]
0x0005f4:	str     	r1, [sp, #4]
0x0005f6:	movs    	r1, #0x44
0x0005f8:	movs    	r0, #0xf1
0x0005fa:	movs    	r4, #0
0x0005fc:	lsls    	r0, r0, #9
0x0005fe:	bl      	#0x2cdc
0x000602:	ldr     	r0, [pc, #0x1d8]
0x000604:	movs    	r1, #0
0x000606:	add     	r0, sb
0x000608:	strb    	r7, [r0]
0x00060a:	str     	r1, [sp]
0x00060c:	str     	r1, [sp, #4]
0x00060e:	movs    	r2, #0
0x000610:	str     	r2, [sp, #8]
0x000612:	movs    	r1, #0x45
0x000614:	movs    	r0, #0xf1
0x000616:	adds    	r3, r7, #0
0x000618:	lsls    	r0, r0, #9
0x00061a:	ldr     	r2, [r5, #8]
0x00061c:	bl      	#0x2cdc
0x000620:	movs    	r1, #0
0x000622:	str     	r1, [sp]
0x000624:	str     	r1, [sp, #4]
0x000626:	adds    	r6, r0, #0
0x000628:	movs    	r2, #0
0x00062a:	str     	r2, [sp, #8]
0x00062c:	movs    	r0, #0xf1
0x00062e:	adds    	r3, r7, #0
0x000630:	movs    	r1, #0x45
0x000632:	lsls    	r0, r0, #9
0x000634:	ldr     	r2, [r5, #8]
0x000636:	bl      	#0x2cdc
0x00063a:	movs    	r1, #0
0x00063c:	adds    	r7, r0, #0
0x00063e:	movs    	r2, #0
0x000640:	str     	r2, [sp, #8]
0x000642:	str     	r1, [sp]
0x000644:	str     	r1, [sp, #4]
0x000646:	movs    	r1, #0x14
0x000648:	movs    	r2, #0x6d
0x00064a:	movs    	r0, #0xf1
0x00064c:	adds    	r3, r6, #0
0x00064e:	lsls    	r0, r0, #9
0x000650:	bl      	#0x2cdc
0x000654:	ldr     	r1, [pc, #0x184]
0x000656:	add     	r1, sb
0x000658:	str     	r7, [r1, #4]
0x00065a:	movs    	r1, #0
0x00065c:	str     	r1, [sp]
0x00065e:	str     	r1, [sp, #4]
0x000660:	movs    	r2, #0
0x000662:	movs    	r7, #0xf1
0x000664:	lsls    	r7, r7, #9
0x000666:	str     	r2, [sp, #8]
0x000668:	movs    	r1, #0x46
0x00066a:	movs    	r3, #0
0x00066c:	adds    	r0, r7, #0
0x00066e:	ldr     	r2, [r5, #8]
0x000670:	bl      	#0x2cdc
0x000674:	lsls    	r0, r0, #0x18
0x000676:	cmp     	r0, #0
0x000678:	ble     	#0x6d2
0x00067a:	cmp     	r4, #0
0x00067c:	bne     	#0x694
0x00067e:	movs    	r1, #0
0x000680:	str     	r1, [sp]
0x000682:	str     	r1, [sp, #4]
0x000684:	movs    	r2, #0
0x000686:	movs    	r1, #0x13
0x000688:	movs    	r3, #0
0x00068a:	adds    	r0, r7, #0
0x00068c:	str     	r2, [sp, #8]
0x00068e:	bl      	#0x2cdc
0x000692:	adds    	r4, r0, #0
0x000694:	adds    	r0, r5, #0
0x000696:	bl      	#0x3278
0x00069a:	movs    	r1, #0
0x00069c:	str     	r1, [sp]
0x00069e:	str     	r1, [sp, #4]
0x0006a0:	movs    	r2, #0
0x0006a2:	str     	r2, [sp, #8]
0x0006a4:	movs    	r1, #0x46
0x0006a6:	adds    	r6, r0, #0
0x0006a8:	movs    	r3, #0
0x0006aa:	adds    	r0, r7, #0
0x0006ac:	ldr     	r2, [r5, #8]
0x0006ae:	bl      	#0x2cdc
0x0006b2:	adds    	r1, r0, #0
0x0006b4:	movs    	r0, #0x30
0x0006b6:	strb    	r1, [r0, r6]
0x0006b8:	movs    	r1, #0
0x0006ba:	movs    	r2, #0
0x0006bc:	str     	r2, [sp, #8]
0x0006be:	str     	r1, [sp]
0x0006c0:	str     	r1, [sp, #4]
0x0006c2:	adds    	r3, r6, #0
0x0006c4:	adds    	r2, r4, #0
0x0006c6:	movs    	r1, #0x36
0x0006c8:	movs    	r0, #0xf1
0x0006ca:	lsls    	r0, r0, #9
0x0006cc:	bl      	#0x2cdc
0x0006d0:	b       	#0x65a
0x0006d2:	cmp     	r4, #0
0x0006d4:	bne     	#0x6f0
0x0006d6:	movs    	r1, #0
0x0006d8:	str     	r1, [sp]
0x0006da:	str     	r1, [sp, #4]
0x0006dc:	movs    	r2, #0
0x0006de:	movs    	r1, #0xa
0x0006e0:	movs    	r3, #4
0x0006e2:	movs    	r0, #0xf1
0x0006e4:	lsls    	r0, r0, #9
0x0006e6:	str     	r2, [sp, #8]
0x0006e8:	bl      	#0x2cdc
0x0006ec:	str     	r0, [sp, #0xc]
0x0006ee:	b       	#0x786
0x0006f0:	movs    	r1, #0
0x0006f2:	movs    	r2, #0
0x0006f4:	str     	r2, [sp, #8]
0x0006f6:	str     	r1, [sp]
0x0006f8:	str     	r1, [sp, #4]
0x0006fa:	movs    	r1, #0x26
0x0006fc:	adds    	r2, r4, #0
0x0006fe:	movs    	r6, #0
0x000700:	movs    	r3, #0
0x000702:	movs    	r0, #0xf1
0x000704:	lsls    	r0, r0, #9
0x000706:	bl      	#0x2cdc
0x00070a:	movs    	r2, #0
0x00070c:	movs    	r1, #0
0x00070e:	str     	r2, [sp, #8]

; ===== candidate_0007e0 =====
0x0007e0:	push    	{r4, r5, lr}
0x0007e2:	sub     	sp, #0xc
0x0007e4:	movs    	r5, #0
0x0007e6:	movs    	r2, #0
0x0007e8:	movs    	r1, #0
0x0007ea:	str     	r2, [sp, #8]
0x0007ec:	adds    	r3, r5, #0
0x0007ee:	adds    	r4, r0, #0
0x0007f0:	adds    	r2, r0, #0
0x0007f2:	str     	r1, [sp]
0x0007f4:	str     	r1, [sp, #4]
0x0007f6:	movs    	r1, #0x44
0x0007f8:	movs    	r0, #0xf1
0x0007fa:	lsls    	r0, r0, #9
0x0007fc:	bl      	#0x2cdc
0x000800:	movs    	r1, #0
0x000802:	movs    	r2, #0
0x000804:	str     	r2, [sp, #8]
0x000806:	str     	r1, [sp]
0x000808:	str     	r1, [sp, #4]
0x00080a:	adds    	r3, r5, #0
0x00080c:	adds    	r2, r4, #0
0x00080e:	movs    	r1, #0x91
0x000810:	movs    	r0, #0xf1
0x000812:	lsls    	r0, r0, #9
0x000814:	bl      	#0x2cdc
0x000818:	movs    	r1, #0
0x00081a:	adds    	r4, r0, #0
0x00081c:	str     	r1, [sp]
0x00081e:	str     	r1, [sp, #4]
0x000820:	movs    	r2, #0
0x000822:	movs    	r1, #0x2c
0x000824:	movs    	r0, #0xf1
0x000826:	adds    	r3, r5, #0
0x000828:	lsls    	r0, r0, #9
0x00082a:	str     	r2, [sp, #8]
0x00082c:	bl      	#0x2cdc
0x000830:	movs    	r1, #0
0x000832:	movs    	r2, #0
0x000834:	str     	r2, [sp, #8]
0x000836:	str     	r1, [sp]
0x000838:	str     	r1, [sp, #4]
0x00083a:	movs    	r1, #0x14
0x00083c:	movs    	r2, #0x6e
0x00083e:	adds    	r3, r4, #0
0x000840:	movs    	r0, #0xf1
0x000842:	lsls    	r0, r0, #9
0x000844:	bl      	#0x2cdc
0x000848:	movs    	r1, #0
0x00084a:	movs    	r2, #0
0x00084c:	str     	r2, [sp, #8]
0x00084e:	str     	r1, [sp]
0x000850:	str     	r1, [sp, #4]
0x000852:	adds    	r3, r5, #0
0x000854:	adds    	r2, r4, #0
0x000856:	movs    	r1, #0x81
0x000858:	movs    	r0, #0xf1
0x00085a:	lsls    	r0, r0, #9
0x00085c:	bl      	#0x2cdc
0x000860:	add     	sp, #0xc
0x000862:	pop     	{r4, r5, pc}

; ===== candidate_000864 =====
0x000864:	push    	{r4, r5, r6, r7, lr}
0x000866:	ldr     	r5, [pc, #0x3d8]
0x000868:	movs    	r3, #0
0x00086a:	add     	r5, sb
0x00086c:	ldrsb   	r0, [r5, r3]
0x00086e:	movs    	r7, #0xf1
0x000870:	lsls    	r7, r7, #9
0x000872:	movs    	r6, #0
0x000874:	cmp     	r0, #0
0x000876:	sub     	sp, #0x14
0x000878:	bne     	#0x94a
0x00087a:	ldr     	r0, [r5, #0x20]
0x00087c:	ldr     	r1, [r5, #0x1c]
0x00087e:	lsls    	r0, r0, #2
0x000880:	ldr     	r4, [r1, r0]
0x000882:	ldr     	r1, [pc, #0x3c0]
0x000884:	add     	r1, pc
0x000886:	ldr     	r2, [pc, #0x3c0]
0x000888:	adds    	r0, r4, #0
0x00088a:	add     	r2, sb
0x00088c:	ldr     	r2, [r2]
0x00088e:	blx     	r2
0x000890:	cmp     	r0, #0
0x000892:	bne     	#0x960
0x000894:	ldr     	r0, [r5, #0xc]
0x000896:	cmp     	r0, #0
0x000898:	beq     	#0x8ac
0x00089a:	ldr     	r1, [r5, #8]
0x00089c:	lsls    	r1, r1, #2
0x00089e:	ldr     	r0, [r0, r1]
0x0008a0:	movs    	r3, #0x30
0x0008a2:	ldr     	r4, [r0, #0x18]
0x0008a4:	ldr     	r5, [r0, #0x1c]
0x0008a6:	ldrsb   	r0, [r0, r3]
0x0008a8:	str     	r0, [sp, #0x10]
0x0008aa:	b       	#0x8be
0x0008ac:	ldr     	r0, [r5, #8]
0x0008ae:	ldr     	r1, [r5, #0x10]
0x0008b0:	lsls    	r0, r0, #2
0x0008b2:	ldr     	r0, [r1, r0]
0x0008b4:	movs    	r3, #0x45
0x0008b6:	ldr     	r4, [r0, #0x28]
0x0008b8:	ldr     	r5, [r0, #0x2c]
0x0008ba:	ldrsb   	r0, [r0, r3]
0x0008bc:	str     	r0, [sp, #0x10]
0x0008be:	movs    	r1, #0
0x0008c0:	movs    	r2, #0
0x0008c2:	str     	r2, [sp, #8]
0x0008c4:	str     	r1, [sp]
0x0008c6:	str     	r1, [sp, #4]
0x0008c8:	movs    	r1, #0xe1
0x0008ca:	movs    	r2, #0x18
0x0008cc:	adds    	r3, r6, #0
0x0008ce:	adds    	r0, r7, #0
0x0008d0:	bl      	#0x2cdc
0x0008d4:	ldr     	r0, [r0, #8]
0x0008d6:	cmp     	r0, r4
0x0008d8:	bne     	#0x92a
0x0008da:	movs    	r1, #0
0x0008dc:	movs    	r2, #0
0x0008de:	str     	r2, [sp, #8]
0x0008e0:	str     	r1, [sp]
0x0008e2:	str     	r1, [sp, #4]
0x0008e4:	movs    	r1, #0xe1
0x0008e6:	movs    	r2, #0x18
0x0008e8:	adds    	r3, r6, #0
0x0008ea:	adds    	r0, r7, #0
0x0008ec:	bl      	#0x2cdc
0x0008f0:	ldr     	r0, [r0, #0xc]
0x0008f2:	cmp     	r0, r5
0x0008f4:	bne     	#0x92a
0x0008f6:	movs    	r1, #0
0x0008f8:	movs    	r2, #0
0x0008fa:	str     	r2, [sp, #8]
0x0008fc:	str     	r1, [sp]
0x0008fe:	str     	r1, [sp, #4]
0x000900:	movs    	r1, #0x9c
0x000902:	movs    	r2, #0x12
0x000904:	adds    	r3, r6, #0
0x000906:	adds    	r0, r7, #0
0x000908:	bl      	#0x2cdc
0x00090c:	movs    	r2, #0
0x00090e:	movs    	r1, #0
0x000910:	str     	r2, [sp, #8]
0x000912:	ldr     	r2, [pc, #0x338]
0x000914:	str     	r1, [sp]
0x000916:	str     	r1, [sp, #4]
0x000918:	adds    	r3, r6, #0
0x00091a:	add     	r2, pc
0x00091c:	movs    	r1, #0x33
0x00091e:	movs    	r0, #0xf1
0x000920:	lsls    	r0, r0, #9
0x000922:	bl      	#0x2cdc
0x000926:	add     	sp, #0x14
0x000928:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000eb8 =====
0x000eb8:	push    	{r4, r5, r6, r7, lr}
0x000eba:	sub     	sp, #0x74
0x000ebc:	movs    	r0, #0
0x000ebe:	movs    	r1, #0x32
0x000ec0:	str     	r1, [sp, #0x50]
0x000ec2:	movs    	r1, #0
0x000ec4:	str     	r0, [sp, #0x48]
0x000ec6:	str     	r0, [sp, #0x44]
0x000ec8:	movs    	r2, #0
0x000eca:	str     	r2, [sp, #8]
0x000ecc:	str     	r1, [sp, #4]
0x000ece:	movs    	r5, #0xf1
0x000ed0:	movs    	r7, #0
0x000ed2:	movs    	r6, #0x19
0x000ed4:	adds    	r3, r7, #0
0x000ed6:	lsls    	r5, r5, #9
0x000ed8:	movs    	r1, #0xe1
0x000eda:	movs    	r2, #0xed
0x000edc:	str     	r0, [sp]
0x000ede:	movs    	r4, #0x1a
0x000ee0:	adds    	r0, r5, #0
0x000ee2:	str     	r6, [sp, #0x3c]
0x000ee4:	bl      	#0x2cdc
0x000ee8:	cmp     	r0, #0
0x000eea:	ble     	#0xfd2
0x000eec:	movs    	r1, #0
0x000eee:	str     	r1, [sp]
0x000ef0:	str     	r1, [sp, #4]
0x000ef2:	movs    	r1, #0xff
0x000ef4:	movs    	r2, #0
0x000ef6:	adds    	r1, #0x25
0x000ef8:	adds    	r3, r7, #0
0x000efa:	adds    	r0, r5, #0
0x000efc:	str     	r2, [sp, #8]
0x000efe:	bl      	#0x2cdc
0x000f02:	movs    	r2, #0
0x000f04:	movs    	r1, #0
0x000f06:	movs    	r0, #0
0x000f08:	bl      	#0x2c8c
0x000f0c:	movs    	r1, #1
0x000f0e:	movs    	r2, #1
0x000f10:	str     	r2, [sp, #8]
0x000f12:	str     	r1, [sp]
0x000f14:	str     	r1, [sp, #4]
0x000f16:	movs    	r1, #0x55
0x000f18:	movs    	r2, #0
0x000f1a:	adds    	r3, r7, #0
0x000f1c:	adds    	r0, r5, #0
0x000f1e:	bl      	#0x2cdc
0x000f22:	movs    	r1, #0
0x000f24:	movs    	r2, #0
0x000f26:	str     	r2, [sp, #8]
0x000f28:	str     	r1, [sp]
0x000f2a:	str     	r1, [sp, #4]
0x000f2c:	movs    	r1, #0xe1
0x000f2e:	movs    	r2, #0x2d
0x000f30:	adds    	r3, r7, #0
0x000f32:	adds    	r0, r5, #0
0x000f34:	bl      	#0x2cdc
0x000f38:	movs    	r1, #0
0x000f3a:	str     	r0, [sp, #0x60]
0x000f3c:	movs    	r2, #0
0x000f3e:	str     	r2, [sp, #8]
0x000f40:	str     	r1, [sp]
0x000f42:	str     	r1, [sp, #4]
0x000f44:	movs    	r1, #0xe1
0x000f46:	movs    	r2, #0x2e
0x000f48:	adds    	r3, r7, #0
0x000f4a:	adds    	r0, r5, #0
0x000f4c:	bl      	#0x2cdc
0x000f50:	str     	r0, [sp, #0x5c]
0x000f52:	movs    	r0, #0
0x000f54:	movs    	r1, #0
0x000f56:	str     	r1, [sp, #4]
0x000f58:	str     	r0, [sp, #0x58]
0x000f5a:	str     	r0, [sp]
0x000f5c:	movs    	r2, #0
0x000f5e:	movs    	r0, #0xf1
0x000f60:	movs    	r1, #0x1c
0x000f62:	movs    	r5, #0x1a
0x000f64:	adds    	r3, r7, #0
0x000f66:	lsls    	r0, r0, #9
0x000f68:	str     	r2, [sp, #8]
0x000f6a:	bl      	#0x2cdc
0x000f6e:	lsls    	r0, r0, #0x10
0x000f70:	asrs    	r0, r0, #0x10
0x000f72:	movs    	r2, #0
0x000f74:	str     	r0, [sp]
0x000f76:	movs    	r0, #0xf1
0x000f78:	str     	r2, [sp, #8]
0x000f7a:	adds    	r3, r5, #0
0x000f7c:	movs    	r1, #0x32
0x000f7e:	lsls    	r0, r0, #9
0x000f80:	ldr     	r2, [sp, #0x58]
0x000f82:	str     	r4, [sp, #4]
0x000f84:	bl      	#0x2cdc
0x000f88:	ldr     	r5, [pc, #0x3d0]
0x000f8a:	add     	r5, pc
0x000f8c:	ldr     	r0, [pc, #0x3d0]
0x000f8e:	add     	r0, sb
0x000f90:	ldr     	r0, [r0, #0x10]
0x000f92:	cmp     	r0, #0
0x000f94:	beq     	#0xf98
0x000f96:	adds    	r5, #0xc
0x000f98:	add     	r2, sp, #0x5c
0x000f9a:	add     	r1, sp, #0x60
0x000f9c:	str     	r1, [sp, #4]
0x000f9e:	str     	r2, [sp, #8]
0x000fa0:	movs    	r0, #0
0x000fa2:	movs    	r7, #0
0x000fa4:	movs    	r4, #0xf1
0x000fa6:	lsls    	r4, r4, #9
0x000fa8:	adds    	r3, r7, #0
0x000faa:	str     	r0, [sp]
0x000fac:	adds    	r2, r5, #0
0x000fae:	movs    	r1, #0x2a
0x000fb0:	adds    	r0, r4, #0
0x000fb2:	bl      	#0x2cdc
0x000fb6:	movs    	r1, #0
0x000fb8:	str     	r1, [sp]
0x000fba:	str     	r1, [sp, #4]
0x000fbc:	movs    	r2, #0
0x000fbe:	movs    	r1, #0x1c
0x000fc0:	adds    	r3, r7, #0
0x000fc2:	adds    	r0, r4, #0
0x000fc4:	str     	r2, [sp, #8]
0x000fc6:	str     	r5, [sp, #0x18]
0x000fc8:	bl      	#0x2cdc
0x000fcc:	ldr     	r1, [sp, #0x60]
0x000fce:	subs    	r0, r0, r1
0x000fd0:	b       	#0xfd4
0x000fd2:	b       	#0x1658
0x000fd4:	lsrs    	r1, r0, #0x1f
0x000fd6:	adds    	r0, r1, r0
0x000fd8:	asrs    	r0, r0, #1
0x000fda:	str     	r0, [sp, #0x1c]
0x000fdc:	movs    	r0, #0x20
0x000fde:	str     	r0, [sp, #0x20]
0x000fe0:	movs    	r0, #0xff
0x000fe2:	movs    	r1, #0
0x000fe4:	str     	r0, [sp, #0x24]

; ===== candidate_001664 =====
0x001664:	push    	{r4, r5, r6, r7, lr}
0x001666:	ldr     	r4, [pc, #0x150]
0x001668:	sub     	sp, #0x34
0x00166a:	add     	r4, pc
0x00166c:	bl      	#0xeb8
0x001670:	movs    	r1, #0
0x001672:	str     	r1, [sp]
0x001674:	str     	r1, [sp, #4]
0x001676:	movs    	r7, #0
0x001678:	adds    	r3, r7, #0
0x00167a:	movs    	r1, #0xff
0x00167c:	movs    	r2, #0
0x00167e:	adds    	r1, #0x47
0x001680:	movs    	r0, #0xf1
0x001682:	lsls    	r0, r0, #9
0x001684:	str     	r2, [sp, #8]
0x001686:	bl      	#0x2cdc
0x00168a:	add     	r2, sp, #0x28
0x00168c:	add     	r1, sp, #0x2c
0x00168e:	movs    	r0, #0
0x001690:	str     	r0, [sp]
0x001692:	str     	r1, [sp, #4]
0x001694:	str     	r2, [sp, #8]
0x001696:	adds    	r3, r7, #0
0x001698:	adds    	r2, r4, #0
0x00169a:	movs    	r1, #0x2a
0x00169c:	movs    	r0, #0xf1
0x00169e:	lsls    	r0, r0, #9
0x0016a0:	bl      	#0x2cdc
0x0016a4:	movs    	r1, #0
0x0016a6:	ldr     	r0, [pc, #0x114]
0x0016a8:	str     	r1, [sp]
0x0016aa:	str     	r1, [sp, #4]
0x0016ac:	movs    	r2, #0
0x0016ae:	str     	r2, [sp, #8]
0x0016b0:	ldr     	r5, [sp, #0x2c]
0x0016b2:	add     	r0, sb
0x0016b4:	ldr     	r2, [r0, #0x1c]
0x0016b6:	movs    	r0, #0xf1
0x0016b8:	movs    	r1, #0x11
0x0016ba:	movs    	r3, #4
0x0016bc:	lsls    	r0, r0, #9
0x0016be:	bl      	#0x2cdc
0x0016c2:	ldr     	r1, [sp, #0x28]
0x0016c4:	movs    	r2, #0
0x0016c6:	muls    	r0, r1, r0
0x0016c8:	movs    	r1, #0
0x0016ca:	adds    	r6, r0, #0
0x0016cc:	movs    	r0, #5
0x0016ce:	str     	r0, [sp, #0x30]
0x0016d0:	adds    	r6, #0xa
0x0016d2:	str     	r1, [sp]
0x0016d4:	str     	r1, [sp, #4]
0x0016d6:	movs    	r1, #0x1d
0x0016d8:	adds    	r3, r7, #0
0x0016da:	movs    	r0, #0xf1
0x0016dc:	lsls    	r0, r0, #9
0x0016de:	str     	r2, [sp, #8]
0x0016e0:	bl      	#0x2cdc
0x0016e4:	subs    	r4, r0, r6
0x0016e6:	ldr     	r0, [pc, #0xd4]
0x0016e8:	movs    	r1, #0
0x0016ea:	add     	r0, sb
0x0016ec:	ldr     	r0, [r0, #0x1c]
0x0016ee:	str     	r6, [sp, #0x20]
0x0016f0:	str     	r0, [sp, #0x10]
0x0016f2:	ldr     	r0, [sp, #0x30]
0x0016f4:	subs    	r4, #0x14
0x0016f6:	str     	r0, [sp, #0x14]
0x0016f8:	ldr     	r0, [pc, #0xc0]
0x0016fa:	movs    	r2, #0
0x0016fc:	add     	r0, sb
0x0016fe:	adds    	r0, #0x20
0x001700:	str     	r0, [sp, #0x24]
0x001702:	str     	r1, [sp, #4]
0x001704:	str     	r1, [sp]
0x001706:	movs    	r1, #0x2b
0x001708:	movs    	r0, #0xf1
0x00170a:	adds    	r3, r7, #0
0x00170c:	str     	r2, [sp, #8]
0x00170e:	add     	r2, sp, #0x10
0x001710:	lsls    	r0, r0, #9
0x001712:	str     	r4, [sp, #0x18]
0x001714:	str     	r5, [sp, #0x1c]
0x001716:	bl      	#0x2cdc
0x00171a:	ldr     	r0, [pc, #0xa0]
0x00171c:	movs    	r3, #0
0x00171e:	add     	r0, sb
0x001720:	ldrsb   	r0, [r0, r3]
0x001722:	cmp     	r0, #1
0x001724:	bne     	#0x179a
0x001726:	ldr     	r7, [pc, #0x94]
0x001728:	add     	r7, sb
0x00172a:	ldr     	r0, [r7, #0x24]
0x00172c:	cmp     	r0, #0
0x00172e:	beq     	#0x179a
0x001730:	ldr     	r6, [pc, #0x8c]
0x001732:	adds    	r5, #5
0x001734:	add     	r6, pc
0x001736:	add     	r2, sp, #0x28
0x001738:	add     	r1, sp, #0x2c
0x00173a:	movs    	r0, #0
0x00173c:	str     	r0, [sp]
0x00173e:	str     	r1, [sp, #4]
0x001740:	str     	r2, [sp, #8]
0x001742:	adds    	r2, r6, #0
0x001744:	movs    	r1, #0x2a
0x001746:	movs    	r0, #0xf1
0x001748:	lsls    	r0, r0, #9
0x00174a:	bl      	#0x2cdc
0x00174e:	movs    	r1, #0
0x001750:	str     	r1, [sp]
0x001752:	str     	r1, [sp, #4]
0x001754:	movs    	r2, #0
0x001756:	str     	r2, [sp, #8]
0x001758:	movs    	r1, #0x11
0x00175a:	ldr     	r6, [sp, #0x2c]
0x00175c:	movs    	r3, #4
0x00175e:	movs    	r0, #0xf1
0x001760:	lsls    	r0, r0, #9
0x001762:	ldr     	r2, [r7, #0x24]
0x001764:	bl      	#0x2cdc
0x001768:	ldr     	r1, [sp, #0x28]
0x00176a:	movs    	r2, #0
0x00176c:	muls    	r0, r1, r0
0x00176e:	ldr     	r1, [r7, #0x24]
0x001770:	adds    	r0, #0xa
0x001772:	str     	r0, [sp, #0x20]
0x001774:	ldr     	r0, [pc, #0x44]
0x001776:	str     	r1, [sp, #0x10]
0x001778:	add     	r0, sb
0x00177a:	adds    	r0, #0x28
0x00177c:	str     	r0, [sp, #0x24]
0x00177e:	movs    	r1, #0
0x001780:	str     	r1, [sp]
0x001782:	str     	r1, [sp, #4]
0x001784:	movs    	r1, #0x2b
0x001786:	movs    	r0, #0xf1
0x001788:	str     	r2, [sp, #8]
0x00178a:	movs    	r3, #0
0x00178c:	lsls    	r0, r0, #9

; ===== candidate_0017c4 =====
0x0017c4:	push    	{r4, r5, r6, r7, lr}
0x0017c6:	sub     	sp, #0x2c
0x0017c8:	movs    	r1, #0
0x0017ca:	str     	r1, [sp]
0x0017cc:	str     	r1, [sp, #4]
0x0017ce:	ldr     	r1, [pc, #0xf8]
0x0017d0:	movs    	r2, #0
0x0017d2:	str     	r2, [sp, #8]
0x0017d4:	add     	r1, sb
0x0017d6:	ldr     	r0, [r1, #0x34]
0x0017d8:	movs    	r4, #0xf1
0x0017da:	lsls    	r4, r4, #9
0x0017dc:	movs    	r1, #0x11
0x0017de:	movs    	r3, #4
0x0017e0:	ldr     	r2, [r0, #4]
0x0017e2:	adds    	r0, r4, #0
0x0017e4:	bl      	#0x2cdc
0x0017e8:	movs    	r1, #0
0x0017ea:	movs    	r2, #0
0x0017ec:	str     	r2, [sp, #8]
0x0017ee:	str     	r1, [sp]
0x0017f0:	str     	r1, [sp, #4]
0x0017f2:	movs    	r6, #0
0x0017f4:	adds    	r3, r6, #0
0x0017f6:	movs    	r1, #0xe1
0x0017f8:	movs    	r2, #0xed
0x0017fa:	adds    	r5, r0, #0
0x0017fc:	adds    	r0, r4, #0
0x0017fe:	bl      	#0x2cdc
0x001802:	cmp     	r0, #0
0x001804:	ble     	#0x18c2
0x001806:	movs    	r1, #0
0x001808:	str     	r1, [sp]
0x00180a:	str     	r1, [sp, #4]
0x00180c:	movs    	r1, #0xff
0x00180e:	movs    	r2, #0
0x001810:	adds    	r1, #0x25
0x001812:	adds    	r3, r6, #0
0x001814:	adds    	r0, r4, #0
0x001816:	str     	r2, [sp, #8]
0x001818:	bl      	#0x2cdc
0x00181c:	add     	r2, sp, #0x24
0x00181e:	str     	r2, [sp, #8]
0x001820:	movs    	r0, #0
0x001822:	ldr     	r2, [pc, #0xa8]
0x001824:	add     	r1, sp, #0x28
0x001826:	str     	r1, [sp, #4]
0x001828:	str     	r0, [sp]
0x00182a:	adds    	r3, r6, #0
0x00182c:	add     	r2, pc
0x00182e:	movs    	r1, #0x2a
0x001830:	adds    	r0, r4, #0
0x001832:	bl      	#0x2cdc
0x001836:	ldr     	r0, [sp, #0x24]
0x001838:	ldr     	r4, [sp, #0x28]
0x00183a:	movs    	r1, #0
0x00183c:	muls    	r5, r0, r5
0x00183e:	str     	r1, [sp]
0x001840:	str     	r1, [sp, #4]
0x001842:	movs    	r2, #0
0x001844:	adds    	r4, #0x14
0x001846:	adds    	r5, #0xa
0x001848:	adds    	r3, r6, #0
0x00184a:	movs    	r1, #0x1c
0x00184c:	movs    	r0, #0xf1
0x00184e:	lsls    	r0, r0, #9
0x001850:	str     	r2, [sp, #8]
0x001852:	bl      	#0x2cdc
0x001856:	subs    	r0, r0, r4
0x001858:	lsrs    	r1, r0, #0x1f
0x00185a:	adds    	r0, r1, r0
0x00185c:	movs    	r1, #0
0x00185e:	str     	r1, [sp]
0x001860:	str     	r1, [sp, #4]
0x001862:	asrs    	r7, r0, #1
0x001864:	movs    	r2, #0
0x001866:	movs    	r0, #0xf1
0x001868:	movs    	r1, #0x1d
0x00186a:	adds    	r3, r6, #0
0x00186c:	lsls    	r0, r0, #9
0x00186e:	str     	r2, [sp, #8]
0x001870:	bl      	#0x2cdc
0x001874:	subs    	r0, r0, r5
0x001876:	lsrs    	r1, r0, #0x1f
0x001878:	adds    	r0, r1, r0
0x00187a:	ldr     	r1, [pc, #0x4c]
0x00187c:	asrs    	r0, r0, #1
0x00187e:	add     	r1, sb
0x001880:	ldr     	r1, [r1, #0x34]
0x001882:	ldr     	r2, [r1, #4]
0x001884:	adds    	r1, #8
0x001886:	str     	r1, [sp, #0x20]
0x001888:	movs    	r1, #0
0x00188a:	str     	r2, [sp, #0xc]
0x00188c:	movs    	r2, #0
0x00188e:	str     	r1, [sp]
0x001890:	str     	r1, [sp, #4]
0x001892:	str     	r0, [sp, #0x14]
0x001894:	movs    	r0, #0xf1
0x001896:	movs    	r1, #0x2b
0x001898:	str     	r2, [sp, #8]
0x00189a:	adds    	r3, r6, #0
0x00189c:	lsls    	r0, r0, #9
0x00189e:	add     	r2, sp, #0xc
0x0018a0:	str     	r7, [sp, #0x10]
0x0018a2:	str     	r4, [sp, #0x18]
0x0018a4:	str     	r5, [sp, #0x1c]
0x0018a6:	bl      	#0x2cdc
0x0018aa:	movs    	r1, #0
0x0018ac:	movs    	r2, #0
0x0018ae:	str     	r2, [sp, #8]
0x0018b0:	str     	r1, [sp]
0x0018b2:	str     	r1, [sp, #4]
0x0018b4:	movs    	r1, #0x24
0x0018b6:	movs    	r2, #1
0x0018b8:	movs    	r3, #1
0x0018ba:	movs    	r0, #0xf1
0x0018bc:	lsls    	r0, r0, #9
0x0018be:	bl      	#0x2cdc
0x0018c2:	add     	sp, #0x2c
0x0018c4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0018d0 =====
0x0018d0:	push    	{r4, r5, r6, r7, lr}
0x0018d2:	sub     	sp, #0x54
0x0018d4:	movs    	r1, #0
0x0018d6:	movs    	r2, #0
0x0018d8:	str     	r2, [sp, #8]
0x0018da:	str     	r1, [sp]
0x0018dc:	str     	r1, [sp, #4]
0x0018de:	movs    	r4, #0xf1
0x0018e0:	movs    	r0, #0x19
0x0018e2:	str     	r0, [sp, #0x34]
0x0018e4:	lsls    	r4, r4, #9
0x0018e6:	movs    	r1, #0xe1
0x0018e8:	movs    	r2, #0xed
0x0018ea:	movs    	r7, #0x19
0x0018ec:	movs    	r6, #0x1e
0x0018ee:	movs    	r5, #0
0x0018f0:	movs    	r3, #0
0x0018f2:	adds    	r0, r4, #0
0x0018f4:	bl      	#0x2cdc
0x0018f8:	cmp     	r0, #0
0x0018fa:	ble     	#0x19e0
0x0018fc:	movs    	r1, #0
0x0018fe:	str     	r1, [sp]
0x001900:	str     	r1, [sp, #4]
0x001902:	movs    	r1, #0xff
0x001904:	movs    	r2, #0
0x001906:	adds    	r1, #0x25
0x001908:	movs    	r3, #0
0x00190a:	adds    	r0, r4, #0
0x00190c:	str     	r2, [sp, #8]
0x00190e:	bl      	#0x2cdc
0x001912:	movs    	r2, #0
0x001914:	movs    	r1, #0
0x001916:	movs    	r0, #0
0x001918:	bl      	#0x2c8c
0x00191c:	movs    	r1, #1
0x00191e:	movs    	r2, #1
0x001920:	str     	r2, [sp, #8]
0x001922:	str     	r1, [sp]
0x001924:	str     	r1, [sp, #4]
0x001926:	movs    	r1, #0x55
0x001928:	movs    	r2, #0
0x00192a:	movs    	r3, #0
0x00192c:	adds    	r0, r4, #0
0x00192e:	bl      	#0x2cdc
0x001932:	movs    	r1, #0
0x001934:	str     	r1, [sp]
0x001936:	str     	r1, [sp, #4]
0x001938:	movs    	r2, #0
0x00193a:	movs    	r1, #0x1c
0x00193c:	movs    	r3, #0
0x00193e:	adds    	r0, r4, #0
0x001940:	str     	r2, [sp, #8]
0x001942:	bl      	#0x2cdc
0x001946:	ldr     	r1, [sp, #0x34]
0x001948:	adds    	r4, r0, #0
0x00194a:	movs    	r2, #0
0x00194c:	str     	r0, [sp]
0x00194e:	str     	r1, [sp, #4]
0x001950:	movs    	r1, #0x32
0x001952:	movs    	r0, #0xf1
0x001954:	adds    	r3, r7, #0
0x001956:	lsls    	r0, r0, #9
0x001958:	str     	r2, [sp, #8]
0x00195a:	bl      	#0x2cdc
0x00195e:	ldr     	r7, [pc, #0x3dc]
0x001960:	add     	r7, pc
0x001962:	movs    	r1, #0
0x001964:	movs    	r2, #0
0x001966:	str     	r2, [sp, #8]
0x001968:	str     	r1, [sp]
0x00196a:	str     	r1, [sp, #4]
0x00196c:	movs    	r1, #0xe1
0x00196e:	movs    	r2, #0x17
0x001970:	movs    	r3, #0
0x001972:	movs    	r0, #0xf1
0x001974:	lsls    	r0, r0, #9
0x001976:	bl      	#0x2cdc
0x00197a:	subs    	r0, #0xff
0x00197c:	subs    	r0, #0x23
0x00197e:	bne     	#0x1982
0x001980:	adds    	r7, #0x14
0x001982:	add     	r2, sp, #0x44
0x001984:	add     	r1, sp, #0x48
0x001986:	movs    	r0, #0
0x001988:	str     	r0, [sp]
0x00198a:	str     	r1, [sp, #4]
0x00198c:	str     	r2, [sp, #8]
0x00198e:	adds    	r2, r7, #0
0x001990:	movs    	r1, #0x2a
0x001992:	movs    	r0, #0xf1
0x001994:	movs    	r3, #0
0x001996:	lsls    	r0, r0, #9
0x001998:	bl      	#0x2cdc
0x00199c:	ldr     	r0, [sp, #0x48]
0x00199e:	movs    	r3, #0
0x0019a0:	subs    	r0, r4, r0
0x0019a2:	lsrs    	r1, r0, #0x1f
0x0019a4:	adds    	r0, r1, r0
0x0019a6:	asrs    	r0, r0, #1
0x0019a8:	str     	r0, [sp, #0x18]
0x0019aa:	movs    	r0, #0x1e
0x0019ac:	str     	r0, [sp, #0x1c]
0x0019ae:	movs    	r0, #0xff
0x0019b0:	str     	r0, [sp, #0x20]
0x0019b2:	str     	r0, [sp, #0x24]
0x0019b4:	str     	r0, [sp, #0x28]
0x0019b6:	movs    	r1, #0
0x0019b8:	movs    	r2, #0
0x0019ba:	str     	r1, [sp]
0x0019bc:	str     	r1, [sp, #4]
0x0019be:	movs    	r1, #0x56
0x0019c0:	str     	r2, [sp, #8]
0x0019c2:	movs    	r0, #0xf1
0x0019c4:	lsls    	r0, r0, #9
0x0019c6:	add     	r2, sp, #0x14
0x0019c8:	str     	r3, [sp, #0x2c]
0x0019ca:	str     	r3, [sp, #0x30]
0x0019cc:	str     	r7, [sp, #0x14]
0x0019ce:	bl      	#0x2cdc
0x0019d2:	movs    	r1, #0
0x0019d4:	movs    	r2, #0
0x0019d6:	str     	r2, [sp, #8]
0x0019d8:	movs    	r3, #0
0x0019da:	str     	r1, [sp]
0x0019dc:	str     	r1, [sp, #4]
0x0019de:	b       	#0x19e2
0x0019e0:	b       	#0x1dbc
0x0019e2:	movs    	r1, #0x1d
0x0019e4:	movs    	r0, #0xf1
0x0019e6:	lsls    	r0, r0, #9
0x0019e8:	bl      	#0x2cdc
0x0019ec:	adds    	r1, r0, #0
0x0019ee:	subs    	r1, #0x32
0x0019f0:	str     	r1, [sp, #4]
0x0019f2:	movs    	r2, #0
0x0019f4:	movs    	r1, #0x2e
0x0019f6:	movs    	r0, #0xf1
0x0019f8:	movs    	r3, #0x32
0x0019fa:	lsls    	r0, r0, #9
0x0019fc:	str     	r2, [sp, #8]

; ===== candidate_001dc8 =====
0x001dc8:	push    	{r4, r5, r6, r7, lr}
0x001dca:	ldr     	r6, [pc, #0x120]
0x001dcc:	adds    	r4, r0, #0
0x001dce:	adds    	r5, r1, #0
0x001dd0:	sub     	sp, #0xc
0x001dd2:	add     	r6, pc
0x001dd4:	movs    	r7, #0
0x001dd6:	cmp     	r0, #0
0x001dd8:	ble     	#0x1e5e
0x001dda:	movs    	r1, #0
0x001ddc:	movs    	r2, #0
0x001dde:	adds    	r3, r6, #0
0x001de0:	adds    	r3, #0x24
0x001de2:	str     	r2, [sp, #8]
0x001de4:	str     	r1, [sp]
0x001de6:	str     	r1, [sp, #4]
0x001de8:	movs    	r1, #0x2d
0x001dea:	adds    	r2, r6, #0
0x001dec:	movs    	r0, #0xf1
0x001dee:	lsls    	r0, r0, #9
0x001df0:	bl      	#0x2cdc
0x001df4:	movs    	r1, #0
0x001df6:	adds    	r6, r0, #0
0x001df8:	movs    	r2, #0
0x001dfa:	str     	r2, [sp, #8]
0x001dfc:	str     	r1, [sp]
0x001dfe:	str     	r1, [sp, #4]
0x001e00:	adds    	r3, r7, #0
0x001e02:	adds    	r2, r4, #0
0x001e04:	movs    	r1, #0x3f
0x001e06:	movs    	r0, #0xf1
0x001e08:	lsls    	r0, r0, #9
0x001e0a:	bl      	#0x2cdc
0x001e0e:	movs    	r1, #0
0x001e10:	adds    	r4, r0, #0
0x001e12:	movs    	r2, #0
0x001e14:	adds    	r3, r0, #0
0x001e16:	str     	r2, [sp, #8]
0x001e18:	str     	r1, [sp]
0x001e1a:	str     	r1, [sp, #4]
0x001e1c:	movs    	r1, #0x2d
0x001e1e:	adds    	r2, r6, #0
0x001e20:	movs    	r0, #0xf1
0x001e22:	lsls    	r0, r0, #9
0x001e24:	bl      	#0x2cdc
0x001e28:	movs    	r1, #0
0x001e2a:	adds    	r6, r0, #0
0x001e2c:	movs    	r2, #0
0x001e2e:	str     	r2, [sp, #8]
0x001e30:	str     	r1, [sp]
0x001e32:	str     	r1, [sp, #4]
0x001e34:	adds    	r3, r7, #0
0x001e36:	adds    	r2, r4, #0
0x001e38:	movs    	r1, #9
0x001e3a:	movs    	r0, #0xf1
0x001e3c:	lsls    	r0, r0, #9
0x001e3e:	bl      	#0x2cdc
0x001e42:	movs    	r2, #0
0x001e44:	movs    	r1, #0
0x001e46:	ldr     	r3, [pc, #0xa8]
0x001e48:	str     	r1, [sp]
0x001e4a:	str     	r1, [sp, #4]
0x001e4c:	str     	r2, [sp, #8]
0x001e4e:	add     	r3, pc
0x001e50:	adds    	r2, r6, #0
0x001e52:	movs    	r1, #0x2d
0x001e54:	movs    	r0, #0xf1
0x001e56:	lsls    	r0, r0, #9
0x001e58:	bl      	#0x2cdc
0x001e5c:	adds    	r6, r0, #0
0x001e5e:	cmp     	r5, #0
0x001e60:	ble     	#0x1ee6
0x001e62:	movs    	r2, #0
0x001e64:	movs    	r1, #0
0x001e66:	ldr     	r3, [pc, #0x8c]
0x001e68:	str     	r1, [sp]
0x001e6a:	str     	r1, [sp, #4]
0x001e6c:	str     	r2, [sp, #8]
0x001e6e:	add     	r3, pc
0x001e70:	adds    	r2, r6, #0
0x001e72:	movs    	r1, #0x2d
0x001e74:	movs    	r0, #0xf1
0x001e76:	lsls    	r0, r0, #9
0x001e78:	bl      	#0x2cdc
0x001e7c:	movs    	r1, #0
0x001e7e:	adds    	r4, r0, #0
0x001e80:	movs    	r2, #0
0x001e82:	str     	r2, [sp, #8]
0x001e84:	str     	r1, [sp]
0x001e86:	str     	r1, [sp, #4]
0x001e88:	adds    	r3, r7, #0
0x001e8a:	adds    	r2, r5, #0
0x001e8c:	movs    	r1, #0x3f
0x001e8e:	movs    	r0, #0xf1
0x001e90:	lsls    	r0, r0, #9
0x001e92:	bl      	#0x2cdc
0x001e96:	movs    	r1, #0
0x001e98:	adds    	r5, r0, #0
0x001e9a:	movs    	r2, #0
0x001e9c:	adds    	r3, r0, #0
0x001e9e:	str     	r2, [sp, #8]
0x001ea0:	str     	r1, [sp]
0x001ea2:	str     	r1, [sp, #4]
0x001ea4:	movs    	r1, #0x2d
0x001ea6:	adds    	r2, r4, #0
0x001ea8:	movs    	r0, #0xf1
0x001eaa:	lsls    	r0, r0, #9
0x001eac:	bl      	#0x2cdc
0x001eb0:	movs    	r1, #0
0x001eb2:	adds    	r4, r0, #0
0x001eb4:	movs    	r2, #0
0x001eb6:	str     	r2, [sp, #8]
0x001eb8:	str     	r1, [sp]
0x001eba:	str     	r1, [sp, #4]
0x001ebc:	adds    	r3, r7, #0
0x001ebe:	adds    	r2, r5, #0
0x001ec0:	movs    	r1, #9
0x001ec2:	movs    	r0, #0xf1
0x001ec4:	lsls    	r0, r0, #9
0x001ec6:	bl      	#0x2cdc
0x001eca:	movs    	r2, #0
0x001ecc:	movs    	r1, #0
0x001ece:	ldr     	r3, [pc, #0x28]
0x001ed0:	str     	r1, [sp]
0x001ed2:	str     	r1, [sp, #4]
0x001ed4:	str     	r2, [sp, #8]
0x001ed6:	add     	r3, pc
0x001ed8:	adds    	r2, r4, #0
0x001eda:	movs    	r1, #0x2d
0x001edc:	movs    	r0, #0xf1
0x001ede:	lsls    	r0, r0, #9
0x001ee0:	bl      	#0x2cdc
0x001ee4:	adds    	r6, r0, #0
0x001ee6:	adds    	r0, r6, #0
0x001ee8:	add     	sp, #0xc
0x001eea:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_001efc =====
0x001efc:	push    	{lr}
0x001efe:	sub     	sp, #0xc
0x001f00:	movs    	r1, #0
0x001f02:	movs    	r2, #0
0x001f04:	str     	r2, [sp, #8]
0x001f06:	str     	r1, [sp]
0x001f08:	str     	r1, [sp, #4]
0x001f0a:	movs    	r1, #0xe1
0x001f0c:	movs    	r2, #0x15
0x001f0e:	movs    	r3, #0
0x001f10:	movs    	r0, #0xf1
0x001f12:	lsls    	r0, r0, #9
0x001f14:	bl      	#0x2cdc
0x001f18:	subs    	r0, #0x7d
0x001f1a:	blx     	#0x2e8
0x001f1e:	adds    	r0, r1, #0
0x001f20:	add     	sp, #0xc
0x001f22:	pop     	{pc}

; ===== candidate_001f24 =====
0x001f24:	push    	{r4, r5, r6, r7, lr}
0x001f26:	sub     	sp, #0xc
0x001f28:	movs    	r1, #0
0x001f2a:	movs    	r2, #0
0x001f2c:	str     	r2, [sp, #8]
0x001f2e:	str     	r1, [sp]
0x001f30:	str     	r1, [sp, #4]
0x001f32:	movs    	r7, #0xf1
0x001f34:	movs    	r5, #0
0x001f36:	adds    	r3, r5, #0
0x001f38:	lsls    	r7, r7, #9
0x001f3a:	movs    	r1, #0xe1
0x001f3c:	movs    	r2, #0x17
0x001f3e:	adds    	r4, r0, #0
0x001f40:	adds    	r0, r7, #0
0x001f42:	bl      	#0x2cdc
0x001f46:	ldr     	r6, [pc, #0x88]
0x001f48:	subs    	r0, #0xff
0x001f4a:	subs    	r0, #0x1e
0x001f4c:	add     	r6, sb
0x001f4e:	bne     	#0x1f5a
0x001f50:	ldr     	r0, [r6, #0x10]
0x001f52:	bl      	#0x3498
0x001f56:	str     	r4, [r6, #0x10]
0x001f58:	b       	#0x1fb6
0x001f5a:	movs    	r1, #0
0x001f5c:	str     	r1, [sp]
0x001f5e:	str     	r1, [sp, #4]
0x001f60:	movs    	r2, #0
0x001f62:	movs    	r1, #0x34
0x001f64:	adds    	r3, r5, #0
0x001f66:	adds    	r0, r7, #0
0x001f68:	str     	r2, [sp, #8]
0x001f6a:	bl      	#0x2cdc
0x001f6e:	movs    	r1, #0
0x001f70:	movs    	r2, #0
0x001f72:	str     	r2, [sp, #8]
0x001f74:	str     	r1, [sp]
0x001f76:	str     	r1, [sp, #4]
0x001f78:	movs    	r3, #0xff
0x001f7a:	adds    	r3, #0x1e
0x001f7c:	movs    	r1, #0x14
0x001f7e:	movs    	r2, #0x17
0x001f80:	movs    	r0, #0xf1
0x001f82:	lsls    	r0, r0, #9
0x001f84:	bl      	#0x2cdc
0x001f88:	str     	r4, [r6, #0x10]
0x001f8a:	ldr     	r0, [r6, #0x14]
0x001f8c:	cmp     	r0, #0
0x001f8e:	bne     	#0x1fb6
0x001f90:	movs    	r1, #0
0x001f92:	movs    	r2, #0
0x001f94:	str     	r2, [sp, #8]
0x001f96:	str     	r1, [sp]
0x001f98:	str     	r1, [sp, #4]
0x001f9a:	movs    	r1, #0xf
0x001f9c:	movs    	r2, #0x14
0x001f9e:	adds    	r3, r5, #0
0x001fa0:	adds    	r0, r7, #0
0x001fa2:	bl      	#0x2cdc
0x001fa6:	str     	r0, [r6, #0x14]
0x001fa8:	movs    	r1, #0
0x001faa:	mvns    	r1, r1
0x001fac:	strb    	r5, [r0]
0x001fae:	str     	r1, [r0, #4]
0x001fb0:	str     	r1, [r0, #8]
0x001fb2:	str     	r5, [r0, #0xc]
0x001fb4:	str     	r5, [r0, #0x10]
0x001fb6:	movs    	r1, #0
0x001fb8:	str     	r1, [sp]
0x001fba:	str     	r1, [sp, #4]
0x001fbc:	movs    	r2, #0
0x001fbe:	movs    	r1, #0xba
0x001fc0:	adds    	r3, r5, #0
0x001fc2:	adds    	r0, r7, #0
0x001fc4:	str     	r2, [sp, #8]
0x001fc6:	bl      	#0x2cdc
0x001fca:	str     	r5, [r6, #8]
0x001fcc:	add     	sp, #0xc
0x001fce:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_001fd4 =====
0x001fd4:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x001fd6:	sub     	sp, #0xc
0x001fd8:	adds    	r7, r1, #0
0x001fda:	movs    	r1, #0
0x001fdc:	str     	r1, [sp]
0x001fde:	str     	r1, [sp, #4]
0x001fe0:	movs    	r5, #0xf1
0x001fe2:	movs    	r4, #0
0x001fe4:	movs    	r2, #0
0x001fe6:	adds    	r3, r4, #0
0x001fe8:	lsls    	r5, r5, #9
0x001fea:	movs    	r1, #0x34
0x001fec:	adds    	r0, r5, #0
0x001fee:	str     	r2, [sp, #8]
0x001ff0:	bl      	#0x2cdc
0x001ff4:	ldr     	r6, [pc, #0x5c]
0x001ff6:	movs    	r1, #0
0x001ff8:	add     	r6, sb
0x001ffa:	str     	r4, [r6, #0x38]
0x001ffc:	movs    	r2, #0
0x001ffe:	str     	r2, [sp, #8]
0x002000:	str     	r1, [sp]
0x002002:	str     	r1, [sp, #4]
0x002004:	movs    	r1, #0x14
0x002006:	movs    	r2, #0x6c
0x002008:	adds    	r3, r4, #0
0x00200a:	adds    	r0, r5, #0
0x00200c:	bl      	#0x2cdc
0x002010:	subs    	r7, #0xff
0x002012:	subs    	r7, #0x29
0x002014:	bne     	#0x2030
0x002016:	movs    	r1, #0
0x002018:	movs    	r2, #0
0x00201a:	str     	r2, [sp, #8]
0x00201c:	str     	r1, [sp]
0x00201e:	str     	r1, [sp, #4]
0x002020:	movs    	r3, #0xff
0x002022:	adds    	r3, #0x23
0x002024:	movs    	r1, #0x14
0x002026:	movs    	r2, #0x17
0x002028:	adds    	r0, r5, #0
0x00202a:	bl      	#0x2cdc
0x00202e:	b       	#0x2048
0x002030:	movs    	r1, #0
0x002032:	movs    	r2, #0
0x002034:	str     	r2, [sp, #8]
0x002036:	str     	r1, [sp]
0x002038:	str     	r1, [sp, #4]
0x00203a:	movs    	r3, #0xff
0x00203c:	adds    	r3, #0x21
0x00203e:	movs    	r1, #0x14
0x002040:	movs    	r2, #0x17
0x002042:	adds    	r0, r5, #0
0x002044:	bl      	#0x2cdc
0x002048:	ldr     	r0, [sp, #0xc]
0x00204a:	str     	r0, [r6, #0x30]
0x00204c:	str     	r4, [r6, #0x34]
0x00204e:	add     	sp, #0x14
0x002050:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002058 =====
0x002058:	push    	{r4, r5, r6, r7, lr}
0x00205a:	sub     	sp, #0xc
0x00205c:	movs    	r1, #0
0x00205e:	movs    	r2, #0
0x002060:	str     	r2, [sp, #8]
0x002062:	str     	r1, [sp]
0x002064:	str     	r1, [sp, #4]
0x002066:	movs    	r7, #0xf1
0x002068:	movs    	r5, #0
0x00206a:	adds    	r3, r5, #0
0x00206c:	lsls    	r7, r7, #9
0x00206e:	movs    	r1, #0xe1
0x002070:	movs    	r2, #0x17
0x002072:	adds    	r4, r0, #0
0x002074:	adds    	r0, r7, #0
0x002076:	bl      	#0x2cdc
0x00207a:	ldr     	r6, [pc, #0x88]
0x00207c:	subs    	r0, #0xff
0x00207e:	subs    	r0, #0x1d
0x002080:	add     	r6, sb
0x002082:	bne     	#0x208c
0x002084:	bl      	#0x35a4
0x002088:	str     	r4, [r6, #0xc]
0x00208a:	b       	#0x20e8
0x00208c:	movs    	r1, #0
0x00208e:	str     	r1, [sp]
0x002090:	str     	r1, [sp, #4]
0x002092:	movs    	r2, #0
0x002094:	movs    	r1, #0x34
0x002096:	adds    	r3, r5, #0
0x002098:	adds    	r0, r7, #0
0x00209a:	str     	r2, [sp, #8]
0x00209c:	bl      	#0x2cdc
0x0020a0:	movs    	r1, #0
0x0020a2:	movs    	r2, #0
0x0020a4:	str     	r2, [sp, #8]
0x0020a6:	str     	r1, [sp]
0x0020a8:	str     	r1, [sp, #4]
0x0020aa:	movs    	r3, #0xff
0x0020ac:	adds    	r3, #0x1d
0x0020ae:	movs    	r1, #0x14
0x0020b0:	movs    	r2, #0x17
0x0020b2:	movs    	r0, #0xf1
0x0020b4:	lsls    	r0, r0, #9
0x0020b6:	bl      	#0x2cdc
0x0020ba:	str     	r4, [r6, #0xc]
0x0020bc:	ldr     	r0, [r6, #0x14]
0x0020be:	cmp     	r0, #0
0x0020c0:	bne     	#0x20e8
0x0020c2:	movs    	r1, #0
0x0020c4:	movs    	r2, #0
0x0020c6:	str     	r2, [sp, #8]
0x0020c8:	str     	r1, [sp]
0x0020ca:	str     	r1, [sp, #4]
0x0020cc:	movs    	r1, #0xf
0x0020ce:	movs    	r2, #0x14
0x0020d0:	adds    	r3, r5, #0
0x0020d2:	adds    	r0, r7, #0
0x0020d4:	bl      	#0x2cdc
0x0020d8:	str     	r0, [r6, #0x14]
0x0020da:	movs    	r1, #0
0x0020dc:	mvns    	r1, r1
0x0020de:	strb    	r5, [r0]
0x0020e0:	str     	r1, [r0, #4]
0x0020e2:	str     	r1, [r0, #8]
0x0020e4:	str     	r5, [r0, #0xc]
0x0020e6:	str     	r5, [r0, #0x10]
0x0020e8:	movs    	r1, #0
0x0020ea:	str     	r1, [sp]
0x0020ec:	str     	r1, [sp, #4]
0x0020ee:	movs    	r2, #0
0x0020f0:	movs    	r1, #0xba
0x0020f2:	adds    	r3, r5, #0
0x0020f4:	adds    	r0, r7, #0
0x0020f6:	str     	r2, [sp, #8]
0x0020f8:	bl      	#0x2cdc
0x0020fc:	str     	r5, [r6, #8]
0x0020fe:	add     	sp, #0xc
0x002100:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002108 =====
0x002108:	push    	{r0, r4, r5, r6, r7, lr}
0x00210a:	sub     	sp, #0x10
0x00210c:	movs    	r1, #0
0x00210e:	str     	r1, [sp]
0x002110:	str     	r1, [sp, #4]
0x002112:	movs    	r7, #0xf1
0x002114:	movs    	r2, #0
0x002116:	lsls    	r7, r7, #9
0x002118:	movs    	r1, #0x13
0x00211a:	movs    	r3, #0
0x00211c:	adds    	r0, r7, #0
0x00211e:	str     	r2, [sp, #8]
0x002120:	bl      	#0x2cdc
0x002124:	ldr     	r6, [pc, #0x304]
0x002126:	adds    	r4, r0, #0
0x002128:	add     	r6, sb
0x00212a:	movs    	r0, #0
0x00212c:	str     	r0, [r6, #0x20]
0x00212e:	adds    	r1, r6, #0
0x002130:	str     	r0, [r1, #0x28]
0x002132:	ldr     	r0, [sp, #0x10]
0x002134:	movs    	r5, #0
0x002136:	subs    	r0, #0xff
0x002138:	subs    	r0, #0x1f
0x00213a:	bne     	#0x21f0
0x00213c:	ldr     	r0, [r6, #0xc]
0x00213e:	mov     	ip, r0
0x002140:	cmp     	r0, #0
0x002142:	beq     	#0x21ee
0x002144:	movs    	r1, #0
0x002146:	movs    	r2, #0
0x002148:	str     	r1, [sp]
0x00214a:	str     	r1, [sp, #4]
0x00214c:	movs    	r1, #0x11
0x00214e:	str     	r2, [sp, #8]
0x002150:	movs    	r3, #4
0x002152:	adds    	r0, r7, #0
0x002154:	mov     	r2, ip
0x002156:	bl      	#0x2cdc
0x00215a:	cmp     	r0, #0
0x00215c:	ble     	#0x21ee
0x00215e:	movs    	r2, #0
0x002160:	movs    	r1, #0
0x002162:	ldr     	r3, [pc, #0x2cc]
0x002164:	str     	r1, [sp]
0x002166:	str     	r1, [sp, #4]
0x002168:	str     	r2, [sp, #8]
0x00216a:	add     	r3, pc
0x00216c:	adds    	r2, r3, #0
0x00216e:	subs    	r2, #0xa4
0x002170:	movs    	r1, #0x35
0x002172:	adds    	r0, r7, #0
0x002174:	bl      	#0x2cdc
0x002178:	movs    	r1, #0
0x00217a:	movs    	r2, #0
0x00217c:	str     	r2, [sp, #8]
0x00217e:	str     	r1, [sp]
0x002180:	str     	r1, [sp, #4]
0x002182:	movs    	r1, #0x36
0x002184:	adds    	r2, r4, #0
0x002186:	adds    	r3, r0, #0
0x002188:	adds    	r0, r7, #0
0x00218a:	bl      	#0x2cdc
0x00218e:	movs    	r2, #0
0x002190:	movs    	r1, #0
0x002192:	ldr     	r3, [pc, #0x2a0]
0x002194:	str     	r1, [sp]
0x002196:	str     	r1, [sp, #4]
0x002198:	str     	r2, [sp, #8]
0x00219a:	add     	r3, pc
0x00219c:	adds    	r2, r3, #0
0x00219e:	subs    	r2, #0xd8
0x0021a0:	movs    	r1, #0x35
0x0021a2:	adds    	r0, r7, #0
0x0021a4:	bl      	#0x2cdc
0x0021a8:	movs    	r1, #0
0x0021aa:	movs    	r2, #0
0x0021ac:	str     	r2, [sp, #8]
0x0021ae:	str     	r1, [sp]
0x0021b0:	str     	r1, [sp, #4]
0x0021b2:	movs    	r1, #0x36
0x0021b4:	adds    	r2, r4, #0
0x0021b6:	adds    	r3, r0, #0
0x0021b8:	adds    	r0, r7, #0
0x0021ba:	bl      	#0x2cdc
0x0021be:	movs    	r2, #0
0x0021c0:	movs    	r1, #0
0x0021c2:	ldr     	r3, [pc, #0x274]
0x0021c4:	str     	r1, [sp]
0x0021c6:	str     	r1, [sp, #4]
0x0021c8:	str     	r2, [sp, #8]
0x0021ca:	add     	r3, pc
0x0021cc:	adds    	r2, r3, #0
0x0021ce:	subs    	r2, #0xbc
0x0021d0:	movs    	r1, #0x35
0x0021d2:	adds    	r0, r7, #0
0x0021d4:	bl      	#0x2cdc
0x0021d8:	movs    	r1, #0
0x0021da:	movs    	r2, #0
0x0021dc:	str     	r2, [sp, #8]
0x0021de:	str     	r1, [sp]
0x0021e0:	str     	r1, [sp, #4]
0x0021e2:	movs    	r1, #0x36
0x0021e4:	adds    	r2, r4, #0
0x0021e6:	adds    	r3, r0, #0
0x0021e8:	adds    	r0, r7, #0
0x0021ea:	bl      	#0x2cdc
0x0021ee:	b       	#0x22ac
0x0021f0:	ldr     	r0, [r6, #0x10]
0x0021f2:	mov     	ip, r0
0x0021f4:	cmp     	r0, #0
0x0021f6:	beq     	#0x22ac
0x0021f8:	movs    	r1, #0
0x0021fa:	movs    	r2, #0
0x0021fc:	str     	r1, [sp]
0x0021fe:	str     	r1, [sp, #4]
0x002200:	movs    	r1, #0x11
0x002202:	str     	r2, [sp, #8]
0x002204:	movs    	r3, #4
0x002206:	adds    	r0, r7, #0
0x002208:	mov     	r2, ip
0x00220a:	bl      	#0x2cdc
0x00220e:	cmp     	r0, #0
0x002210:	ble     	#0x22ac
0x002212:	movs    	r2, #0
0x002214:	movs    	r1, #0
0x002216:	ldr     	r3, [pc, #0x224]
0x002218:	str     	r1, [sp]
0x00221a:	str     	r1, [sp, #4]
0x00221c:	str     	r2, [sp, #8]
0x00221e:	add     	r3, pc
0x002220:	adds    	r2, r3, #0
0x002222:	subs    	r2, #0x40
0x002224:	movs    	r1, #0x35
0x002226:	adds    	r0, r7, #0
0x002228:	bl      	#0x2cdc
0x00222c:	movs    	r1, #0
0x00222e:	adds    	r3, r0, #0
0x002230:	movs    	r2, #0
0x002232:	str     	r2, [sp, #8]
0x002234:	str     	r1, [sp]

; ===== candidate_002480 =====
0x002480:	push    	{r4, r5, r6, r7, lr}
0x002482:	sub     	sp, #0xc
0x002484:	movs    	r1, #0
0x002486:	str     	r1, [sp]
0x002488:	str     	r1, [sp, #4]
0x00248a:	ldr     	r5, [pc, #0x158]
0x00248c:	movs    	r2, #0
0x00248e:	movs    	r4, #0xf1
0x002490:	movs    	r6, #4
0x002492:	adds    	r3, r6, #0
0x002494:	lsls    	r4, r4, #9
0x002496:	str     	r2, [sp, #8]
0x002498:	movs    	r1, #0x11
0x00249a:	adds    	r7, r0, #0
0x00249c:	add     	r5, sb
0x00249e:	ldr     	r2, [r5, #0x1c]
0x0024a0:	adds    	r0, r4, #0
0x0024a2:	bl      	#0x2cdc
0x0024a6:	mov     	ip, r0
0x0024a8:	movs    	r3, #0
0x0024aa:	ldrsb   	r0, [r5, r3]
0x0024ac:	cmp     	r0, #1
0x0024ae:	bne     	#0x24c8
0x0024b0:	movs    	r1, #0
0x0024b2:	str     	r1, [sp]
0x0024b4:	str     	r1, [sp, #4]
0x0024b6:	movs    	r2, #0
0x0024b8:	str     	r2, [sp, #8]
0x0024ba:	movs    	r1, #0x11
0x0024bc:	adds    	r3, r6, #0
0x0024be:	adds    	r0, r4, #0
0x0024c0:	ldr     	r2, [r5, #0x24]
0x0024c2:	bl      	#0x2cdc
0x0024c6:	mov     	ip, r0
0x0024c8:	adds    	r1, r7, #0
0x0024ca:	ldr     	r7, [pc, #0x118]
0x0024cc:	ldr     	r0, [pc, #0x114]
0x0024ce:	add     	r7, sb
0x0024d0:	add     	r0, sb
0x0024d2:	adds    	r0, #0x28
0x0024d4:	adds    	r7, #0x20
0x0024d6:	movs    	r6, #0
0x0024d8:	cmp     	r1, #0xd
0x0024da:	beq     	#0x2580
0x0024dc:	bgt     	#0x250e
0x0024de:	cmp     	r1, #2
0x0024e0:	beq     	#0x24ee
0x0024e2:	cmp     	r1, #5
0x0024e4:	beq     	#0x251e
0x0024e6:	cmp     	r1, #8
0x0024e8:	beq     	#0x2580
0x0024ea:	cmp     	r1, #0xc
0x0024ec:	bne     	#0x250a
0x0024ee:	movs    	r3, #0
0x0024f0:	ldrsb   	r1, [r5, r3]
0x0024f2:	cmp     	r1, #0
0x0024f4:	bne     	#0x2568
0x0024f6:	movs    	r2, #0
0x0024f8:	str     	r1, [sp, #4]
0x0024fa:	movs    	r1, #0x29
0x0024fc:	str     	r2, [sp, #8]
0x0024fe:	adds    	r3, r6, #0
0x002500:	adds    	r0, r4, #0
0x002502:	mov     	r2, ip
0x002504:	str     	r7, [sp]
0x002506:	bl      	#0x2cdc
0x00250a:	add     	sp, #0xc
0x00250c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0025ec =====
0x0025ec:	push    	{r4, r5, r6, r7, lr}
0x0025ee:	sub     	sp, #0xc
0x0025f0:	ldr     	r5, [pc, #0x90]
0x0025f2:	movs    	r1, #0
0x0025f4:	movs    	r2, #0
0x0025f6:	str     	r2, [sp, #8]
0x0025f8:	str     	r1, [sp]
0x0025fa:	str     	r1, [sp, #4]
0x0025fc:	adds    	r6, r0, #0
0x0025fe:	add     	r5, sb
0x002600:	ldr     	r0, [r5, #0x34]
0x002602:	movs    	r4, #0xf1
0x002604:	lsls    	r4, r4, #9
0x002606:	movs    	r1, #0x11
0x002608:	movs    	r3, #4
0x00260a:	ldr     	r2, [r0, #4]
0x00260c:	adds    	r0, r4, #0
0x00260e:	bl      	#0x2cdc
0x002612:	adds    	r7, r0, #0
0x002614:	movs    	r3, #0
0x002616:	cmp     	r6, #0xd
0x002618:	beq     	#0x2668
0x00261a:	bgt     	#0x2648
0x00261c:	cmp     	r6, #2
0x00261e:	beq     	#0x262c
0x002620:	cmp     	r6, #5
0x002622:	beq     	#0x2654
0x002624:	cmp     	r6, #8
0x002626:	beq     	#0x2668
0x002628:	cmp     	r6, #0xc
0x00262a:	bne     	#0x2644
0x00262c:	ldr     	r0, [r5, #0x34]
0x00262e:	movs    	r2, #0
0x002630:	movs    	r1, #0
0x002632:	str     	r1, [sp, #4]
0x002634:	str     	r2, [sp, #8]
0x002636:	adds    	r0, #8
0x002638:	str     	r0, [sp]
0x00263a:	adds    	r2, r7, #0
0x00263c:	movs    	r1, #0x29
0x00263e:	adds    	r0, r4, #0
0x002640:	bl      	#0x2cdc
0x002644:	add     	sp, #0xc
0x002646:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002688 =====
0x002688:	push    	{r4, r5, r6, r7, lr}
0x00268a:	sub     	sp, #0xc
0x00268c:	adds    	r5, r0, #0
0x00268e:	movs    	r1, #0
0x002690:	ldr     	r0, [pc, #0x2a4]
0x002692:	str     	r1, [sp]
0x002694:	str     	r1, [sp, #4]
0x002696:	movs    	r2, #0
0x002698:	str     	r2, [sp, #8]
0x00269a:	movs    	r4, #0xf1
0x00269c:	add     	r0, sb
0x00269e:	ldr     	r2, [r0, #0x30]
0x0026a0:	lsls    	r4, r4, #9
0x0026a2:	movs    	r1, #0x11
0x0026a4:	movs    	r3, #4
0x0026a6:	adds    	r0, r4, #0
0x0026a8:	bl      	#0x2cdc
0x0026ac:	adds    	r6, r0, #0
0x0026ae:	ldr     	r0, [pc, #0x288]
0x0026b0:	movs    	r7, #0
0x0026b2:	add     	r0, sb
0x0026b4:	adds    	r0, #0x38
0x0026b6:	cmp     	r5, #0xd
0x0026b8:	beq     	#0x27a0
0x0026ba:	bgt     	#0x26e6
0x0026bc:	cmp     	r5, #2
0x0026be:	beq     	#0x26cc
0x0026c0:	cmp     	r5, #5
0x0026c2:	beq     	#0x26f2
0x0026c4:	cmp     	r5, #8
0x0026c6:	beq     	#0x27a0
0x0026c8:	cmp     	r5, #0xc
0x0026ca:	bne     	#0x26e2
0x0026cc:	movs    	r2, #0
0x0026ce:	movs    	r1, #0
0x0026d0:	str     	r1, [sp, #4]
0x0026d2:	str     	r2, [sp, #8]
0x0026d4:	adds    	r2, r6, #1
0x0026d6:	movs    	r1, #0x29
0x0026d8:	str     	r0, [sp]
0x0026da:	adds    	r3, r7, #0
0x0026dc:	adds    	r0, r4, #0
0x0026de:	bl      	#0x2cdc
0x0026e2:	add     	sp, #0xc
0x0026e4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002940 =====
0x002940:	push    	{r0, r4, r5, r6, r7, lr}
0x002942:	ldr     	r5, [pc, #0x2b4]
0x002944:	movs    	r4, #0xf1
0x002946:	add     	r5, sb
0x002948:	ldr     	r7, [r5, #0xc]
0x00294a:	lsls    	r4, r4, #9
0x00294c:	movs    	r6, #0
0x00294e:	movs    	r3, #4
0x002950:	cmp     	r7, #0
0x002952:	sub     	sp, #0x10
0x002954:	beq     	#0x296e
0x002956:	movs    	r1, #0
0x002958:	movs    	r2, #0
0x00295a:	str     	r2, [sp, #8]
0x00295c:	str     	r1, [sp]
0x00295e:	str     	r1, [sp, #4]
0x002960:	movs    	r1, #0x11
0x002962:	adds    	r2, r7, #0
0x002964:	adds    	r0, r4, #0
0x002966:	bl      	#0x2cdc
0x00296a:	adds    	r6, r0, #0
0x00296c:	b       	#0x298a
0x00296e:	ldr     	r7, [r5, #0x10]
0x002970:	cmp     	r7, #0
0x002972:	beq     	#0x298a
0x002974:	movs    	r1, #0
0x002976:	movs    	r2, #0
0x002978:	str     	r2, [sp, #8]
0x00297a:	str     	r1, [sp]
0x00297c:	str     	r1, [sp, #4]
0x00297e:	movs    	r1, #0x11
0x002980:	adds    	r2, r7, #0
0x002982:	adds    	r0, r4, #0
0x002984:	bl      	#0x2cdc
0x002988:	adds    	r6, r0, #0
0x00298a:	ldr     	r0, [sp, #0x10]
0x00298c:	subs    	r0, #2
0x00298e:	cmp     	r0, #0x13
0x002990:	bhs     	#0x299c
0x002992:	adr     	r3, #0xc
0x002994:	adds    	r3, r3, r0
0x002996:	ldrh    	r3, [r3, r0]
0x002998:	lsls    	r3, r3, #1
0x00299a:	add     	pc, r3
0x00299c:	add     	sp, #0x14
0x00299e:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002c04 =====
0x002c04:	push    	{r3, r4, r5, lr}
0x002c06:	ldr     	r4, [pc, #0x74]
0x002c08:	add     	r4, pc
0x002c0a:	ldr     	r0, [r4, #0x38]
0x002c0c:	movs    	r1, #0x14
0x002c0e:	ldr     	r2, [r0, #0x64]
0x002c10:	ldr     	r0, [pc, #0x6c]
0x002c12:	add     	r0, pc
0x002c14:	blx     	r2
0x002c16:	movs    	r5, #0
0x002c18:	mvns    	r5, r5
0x002c1a:	cmp     	r0, r5
0x002c1c:	bne     	#0x2c22
0x002c1e:	adds    	r0, r5, #0
0x002c20:	pop     	{r3, r4, r5, pc}

; ===== candidate_002c8c =====
0x002c8c:	push    	{r4, lr}
0x002c8e:	sub     	sp, #0x10
0x002c90:	lsls    	r0, r0, #0x18
0x002c92:	lsrs    	r0, r0, #0x18
0x002c94:	str     	r0, [sp]
0x002c96:	ldr     	r0, [pc, #0x38]
0x002c98:	lsls    	r2, r2, #0x18
0x002c9a:	lsls    	r1, r1, #0x18
0x002c9c:	lsrs    	r1, r1, #0x18
0x002c9e:	lsrs    	r2, r2, #0x18
0x002ca0:	str     	r2, [sp, #8]
0x002ca2:	str     	r1, [sp, #4]
0x002ca4:	add     	r0, pc
0x002ca6:	ldr     	r0, [r0, #0x38]
0x002ca8:	adds    	r1, r0, #0
0x002caa:	adds    	r1, #0xff
0x002cac:	adds    	r1, #0x41
0x002cae:	ldr     	r2, [r1, #0x34]
0x002cb0:	ldr     	r1, [r1, #0x30]
0x002cb2:	ldr     	r2, [r2]
0x002cb4:	ldr     	r1, [r1]
0x002cb6:	lsls    	r3, r2, #0x10
0x002cb8:	lsls    	r2, r1, #0x10
0x002cba:	asrs    	r2, r2, #0x10
0x002cbc:	asrs    	r3, r3, #0x10
0x002cbe:	adds    	r0, #0xff
0x002cc0:	adds    	r0, #0xc1
0x002cc2:	ldr     	r4, [r0, #0x28]
0x002cc4:	movs    	r1, #0
0x002cc6:	movs    	r0, #0
0x002cc8:	blx     	r4
0x002cca:	add     	sp, #0x10
0x002ccc:	pop     	{r4, pc}

; ===== candidate_002cdc =====
0x002cdc:	push    	{r4, r5, r6, r7, lr}
0x002cde:	adds    	r5, r1, #0
0x002ce0:	adds    	r4, r0, #0
0x002ce2:	adds    	r6, r2, #0
0x002ce4:	ldr     	r2, [pc, #0x28]
0x002ce6:	sub     	sp, #0x14
0x002ce8:	mov     	ip, r3
0x002cea:	add     	r2, pc
0x002cec:	ldr     	r0, [sp, #0x2c]
0x002cee:	ldr     	r1, [sp, #0x30]
0x002cf0:	ldr     	r7, [sp, #0x28]
0x002cf2:	ldr     	r3, [r2, #0x3c]
0x002cf4:	movs    	r2, #2
0x002cf6:	str     	r2, [sp, #0xc]
0x002cf8:	str     	r1, [sp, #8]
0x002cfa:	str     	r0, [sp, #4]
0x002cfc:	str     	r7, [sp]
0x002cfe:	ldr     	r0, [r3, #0xc]
0x002d00:	adds    	r1, r5, #0
0x002d02:	adds    	r2, r6, #0
0x002d04:	ldr     	r7, [r0, #0x28]
0x002d06:	adds    	r0, r4, #0
0x002d08:	mov     	r3, ip
0x002d0a:	blx     	r7
0x002d0c:	add     	sp, #0x14
0x002d0e:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002d18 =====
0x002d18:	push    	{r4, lr}
0x002d1a:	movs    	r2, #0
0x002d1c:	add     	r0, pc
0x002d1e:	ldr     	r4, [r0, #0x3c]
0x002d20:	sub     	sp, #0x10
0x002d22:	movs    	r1, #0
0x002d24:	str     	r1, [sp, #4]
0x002d26:	str     	r1, [sp, #8]
0x002d28:	str     	r2, [sp, #0xc]
0x002d2a:	str     	r2, [sp]
0x002d2c:	ldr     	r0, [r4, #0xc]
0x002d2e:	ldr     	r2, [r0, #0x24]
0x002d30:	ldr     	r4, [r0, #0x28]
0x002d32:	blx     	r4
0x002d34:	add     	sp, #0x10
0x002d36:	pop     	{r4, pc}

; ===== candidate_002d3c =====
0x002d3c:	push    	{r4, lr}
0x002d3e:	ldr     	r0, [pc, #0x24]
0x002d40:	sub     	sp, #0x10
0x002d42:	add     	r0, pc
0x002d44:	ldr     	r3, [r0, #0x3c]
0x002d46:	movs    	r2, #0
0x002d48:	movs    	r1, #0
0x002d4a:	str     	r1, [sp, #4]
0x002d4c:	str     	r1, [sp, #8]
0x002d4e:	str     	r2, [sp, #0xc]
0x002d50:	str     	r2, [sp]
0x002d52:	ldr     	r0, [r3, #0xc]
0x002d54:	movs    	r3, #0
0x002d56:	ldr     	r2, [r0, #0x24]
0x002d58:	ldr     	r4, [r0, #0x28]
0x002d5a:	movs    	r1, #1
0x002d5c:	blx     	r4
0x002d5e:	add     	sp, #0x10
0x002d60:	pop     	{r4, pc}

; ===== candidate_002d7c =====
0x002d7c:	push    	{r4, lr}
0x002d7e:	sub     	sp, #0x10
0x002d80:	movs    	r2, #0
0x002d82:	movs    	r1, #0
0x002d84:	str     	r2, [sp, #8]
0x002d86:	ldr     	r2, [pc, #0x3c]
0x002d88:	str     	r1, [sp]
0x002d8a:	str     	r1, [sp, #4]
0x002d8c:	movs    	r3, #0
0x002d8e:	add     	r2, pc
0x002d90:	ldr     	r1, [pc, #0x34]
0x002d92:	ldr     	r0, [pc, #0x38]
0x002d94:	bl      	#0x2cdc
0x002d98:	ldr     	r3, [pc, #0x38]
0x002d9a:	ldr     	r4, [pc, #0x34]
0x002d9c:	add     	r3, sb
0x002d9e:	ldr     	r3, [r3]
0x002da0:	movs    	r2, #0x41
0x002da2:	movs    	r1, #0
0x002da4:	add     	r4, sb
0x002da6:	adds    	r0, r4, #0
0x002da8:	blx     	r3
0x002daa:	bl      	#0x2d68
0x002dae:	ldr     	r3, [pc, #0x28]
0x002db0:	adds    	r1, r0, #0
0x002db2:	add     	r3, sb
0x002db4:	ldr     	r3, [r3]
0x002db6:	movs    	r2, #0x41
0x002db8:	adds    	r0, r4, #0
0x002dba:	blx     	r3
0x002dbc:	movs    	r0, #0
0x002dbe:	add     	sp, #0x10
0x002dc0:	pop     	{r4, pc}

; ===== candidate_002de0 =====
0x002de0:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x002de2:	adds    	r7, r3, #0
0x002de4:	adds    	r6, r2, #0
0x002de6:	adds    	r5, r0, #0
0x002de8:	ldr     	r0, [r0]
0x002dea:	sub     	sp, #4
0x002dec:	mov     	r1, sb
0x002dee:	str     	r1, [sp]
0x002df0:	movs    	r4, #0
0x002df2:	blx     	#0x2e0
0x002df6:	ldr     	r0, [sp, #8]
0x002df8:	cmp     	r0, #0xb
0x002dfa:	bhs     	#0x2e68
0x002dfc:	adr     	r3, #4
0x002dfe:	ldrb    	r3, [r3, r0]
0x002e00:	lsls    	r3, r3, #1
0x002e02:	add     	pc, r3
0x002e04:	lsrs    	r5, r0, #0x1c
0x002e06:	subs    	r4, r3, #4
0x002e08:	movs    	r4, #0x21
0x002e0a:	adds    	r1, #0x27
0x002e0c:	adds    	r1, #0x2b
0x002e0e:	movs    	r7, r5
0x002e10:	ldr     	r1, [pc, #0x60]
0x002e12:	ldr     	r0, [r5, #0xc]
0x002e14:	add     	r1, sb
0x002e16:	str     	r0, [r1, #0x14]
0x002e18:	bl      	#0x308
0x002e1c:	bl      	#0x2d7c
0x002e20:	adds    	r4, r0, #0
0x002e22:	b       	#0x2e68
0x002e24:	ldr     	r0, [r6]
0x002e26:	cmp     	r0, #8
0x002e28:	bne     	#0x2e32
0x002e2a:	bl      	#0x2cd8
0x002e2e:	adds    	r4, r0, #0
0x002e30:	b       	#0x2e68
0x002e32:	ldr     	r1, [r6, #4]
0x002e34:	ldr     	r2, [r6, #8]
0x002e36:	bl      	#0x2cd4
0x002e3a:	adds    	r4, r0, #0
0x002e3c:	b       	#0x2e68
0x002e3e:	bl      	#0x3070
0x002e42:	b       	#0x2e68
0x002e44:	str     	r7, [r5, #0xc]
0x002e46:	b       	#0x2e68
0x002e48:	bl      	#0x2ddc
0x002e4c:	b       	#0x2e68
0x002e4e:	bl      	#0x2eac
0x002e52:	b       	#0x2e68
0x002e54:	ldr     	r0, [pc, #0x1c]
0x002e56:	add     	r0, sb
0x002e58:	str     	r7, [r0, #0x1c]
0x002e5a:	b       	#0x2e68
0x002e5c:	ldr     	r0, [pc, #0x14]
0x002e5e:	add     	r0, sb
0x002e60:	str     	r6, [r0, #0x20]
0x002e62:	b       	#0x2e68
0x002e64:	ldr     	r4, [pc, #0x10]
0x002e66:	add     	r4, pc
0x002e68:	ldr     	r1, [sp]
0x002e6a:	add     	sp, #0x14
0x002e6c:	adds    	r0, r4, #0
0x002e6e:	mov     	sb, r1
0x002e70:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002e7c =====
0x002e7c:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x002e7e:	sub     	sp, #0xc
0x002e80:	ldr     	r0, [sp, #0x38]
0x002e82:	ldr     	r4, [sp, #0x3c]
0x002e84:	ldr     	r6, [sp, #0x34]
0x002e86:	ldr     	r0, [r0]
0x002e88:	mov     	r7, sb
0x002e8a:	movs    	r5, #0
0x002e8c:	blx     	#0x2e0
0x002e90:	cmp     	r4, #0
0x002e92:	beq     	#0x2ea2
0x002e94:	ldr     	r1, [sp, #0x30]
0x002e96:	str     	r6, [sp, #4]
0x002e98:	add     	r3, sp, #0xc
0x002e9a:	str     	r1, [sp]
0x002e9c:	ldm     	r3, {r0, r1, r2, r3}
0x002e9e:	blx     	r4
0x002ea0:	adds    	r5, r0, #0
0x002ea2:	mov     	sb, r7
0x002ea4:	adds    	r0, r5, #0
0x002ea6:	add     	sp, #0x1c
0x002ea8:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002f10 =====
0x002f10:	push    	{r3, r4, r5, r6, r7, lr}
0x002f12:	adds    	r4, r0, #0
0x002f14:	ldr     	r0, [pc, #0x10c]
0x002f16:	movs    	r5, #0
0x002f18:	mvns    	r5, r5
0x002f1a:	mov     	ip, r2
0x002f1c:	add     	r0, pc
0x002f1e:	ldr     	r2, [r0, #0x38]
0x002f20:	cmp     	r4, #0
0x002f22:	bne     	#0x2f34
0x002f24:	ldr     	r0, [pc, #0x100]
0x002f26:	ldr     	r2, [r2, #0x68]
0x002f28:	movs    	r1, #0x7d
0x002f2a:	lsls    	r1, r1, #3
0x002f2c:	add     	r0, pc
0x002f2e:	blx     	r2
0x002f30:	adds    	r0, r5, #0
0x002f32:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_00303c =====
0x00303c:	push    	{r3, r4, r5, lr}
0x00303e:	ldr     	r4, [pc, #0x28]
0x003040:	adds    	r5, r0, #0
0x003042:	add     	r4, pc
0x003044:	ldr     	r0, [r4, #0x38]
0x003046:	adds    	r0, #0x80
0x003048:	ldr     	r0, [r0, #4]
0x00304a:	blx     	r0
0x00304c:	adds    	r0, r0, r5
0x00304e:	ldr     	r1, [pc, #0x1c]
0x003050:	add     	r1, sb
0x003052:	str     	r0, [r1, #0x10]
0x003054:	ldr     	r0, [r4, #0x38]
0x003056:	adds    	r0, #0x80
0x003058:	ldr     	r0, [r0]
0x00305a:	blx     	r0
0x00305c:	ldr     	r0, [r4, #0x38]
0x00305e:	ldr     	r1, [r0, #0x7c]
0x003060:	lsls    	r0, r5, #0x10
0x003062:	lsrs    	r0, r0, #0x10
0x003064:	blx     	r1
0x003066:	pop     	{r3, r4, r5, pc}

; ===== candidate_003072 =====
0x003072:	push    	{r3, r4, r5, r6, r7, lr}
0x003074:	add     	r0, pc
0x003076:	ldr     	r0, [r0, #0x38]
0x003078:	adds    	r0, #0x80
0x00307a:	ldr     	r0, [r0, #4]
0x00307c:	blx     	r0
0x00307e:	movs    	r5, #0
0x003080:	ldr     	r6, [pc, #0xc8]
0x003082:	add     	r6, sb
0x003084:	ldr     	r1, [r6, #0x10]
0x003086:	str     	r5, [r6, #0x10]
0x003088:	subs    	r1, r0, r1
0x00308a:	ldr     	r0, [r6, #8]
0x00308c:	adds    	r3, r1, #0
0x00308e:	cmp     	r0, #0
0x003090:	beq     	#0x3146
0x003092:	ldr     	r2, [r0, #8]
0x003094:	cmp     	r2, #0
0x003096:	bne     	#0x30f6
0x003098:	mvns    	r7, r2
0x00309a:	str     	r7, [r0, #8]
0x00309c:	ldr     	r2, [r0, #0x18]
0x00309e:	adds    	r4, r0, #0
0x0030a0:	cmp     	r1, #0x32
0x0030a2:	str     	r2, [r6, #8]
0x0030a4:	bge     	#0x30aa
0x0030a6:	movs    	r1, #0x32
0x0030a8:	b       	#0x30c6
0x0030aa:	movs    	r2, #0x7d
0x0030ac:	lsls    	r2, r2, #4
0x0030ae:	cmp     	r1, r2
0x0030b0:	ble     	#0x30c6
0x0030b2:	adds    	r1, r2, #0
0x0030b4:	b       	#0x30c6
0x0030b6:	movs    	r7, #0
0x0030b8:	mvns    	r7, r7
0x0030ba:	str     	r7, [r2, #8]
0x0030bc:	ldr     	r2, [r0, #0x18]
0x0030be:	str     	r2, [r0, #0x1c]
0x0030c0:	ldr     	r0, [r2, #0x18]
0x0030c2:	str     	r0, [r6, #8]
0x0030c4:	adds    	r0, r2, #0
0x0030c6:	ldr     	r2, [r0, #0x18]
0x0030c8:	cmp     	r2, #0
0x0030ca:	beq     	#0x30d2
0x0030cc:	ldr     	r7, [r2, #8]
0x0030ce:	cmp     	r7, r1
0x0030d0:	blt     	#0x30b6
0x0030d2:	str     	r5, [r0, #0x1c]
0x0030d4:	ldr     	r0, [r6, #8]
0x0030d6:	cmp     	r0, #0
0x0030d8:	beq     	#0x313a
0x0030da:	cmp     	r3, #0
0x0030dc:	bge     	#0x30e0
0x0030de:	movs    	r3, #0
0x0030e0:	ldr     	r0, [r6, #8]
0x0030e2:	ldr     	r1, [r0, #8]
0x0030e4:	cmp     	r1, #0
0x0030e6:	bge     	#0x30ec
0x0030e8:	movs    	r1, #0
0x0030ea:	str     	r5, [r0, #8]
0x0030ec:	ldr     	r2, [pc, #0x60]
0x0030ee:	cmp     	r1, r2
0x0030f0:	ble     	#0x30fa
0x0030f2:	adds    	r1, r2, #0
0x0030f4:	b       	#0x30fa
0x0030f6:	movs    	r4, #0
0x0030f8:	b       	#0x30da
0x0030fa:	ldr     	r2, [r0, #8]
0x0030fc:	subs    	r2, r2, r1
0x0030fe:	str     	r2, [r0, #8]
0x003100:	ldr     	r0, [r0, #0x18]
0x003102:	cmp     	r0, #0
0x003104:	bne     	#0x30fa
0x003106:	subs    	r0, r1, r3
0x003108:	cmp     	r0, #0
0x00310a:	bgt     	#0x310e
0x00310c:	movs    	r0, #0xa
0x00310e:	bl      	#0x303c
0x003112:	b       	#0x313a
0x003114:	str     	r5, [r4, #8]
0x003116:	ldr     	r0, [r4, #0x1c]
0x003118:	adds    	r3, r5, #0
0x00311a:	str     	r0, [r6, #0xc]
0x00311c:	ldr     	r0, [r4, #0x14]
0x00311e:	cmp     	r0, #0
0x003120:	beq     	#0x312e
0x003122:	str     	r0, [sp]
0x003124:	movs    	r1, #0
0x003126:	adds    	r0, r4, #0
0x003128:	ldr     	r2, [r4, #0x10]
0x00312a:	bl      	#0x2f10
0x00312e:	ldr     	r1, [r4, #0xc]
0x003130:	cmp     	r1, #0
0x003132:	beq     	#0x3138
0x003134:	ldr     	r0, [r4, #0x10]
0x003136:	blx     	r1
0x003138:	ldr     	r4, [r6, #0xc]
0x00313a:	cmp     	r4, #0
0x00313c:	beq     	#0x3144
0x00313e:	ldr     	r0, [r4, #8]
0x003140:	cmp     	r0, #0
0x003142:	blt     	#0x3114
0x003144:	str     	r5, [r6, #0xc]
0x003146:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_003154 =====
0x003154:	push    	{r4, r5, r6, r7, lr}
0x003156:	sub     	sp, #0x1c
0x003158:	movs    	r1, #0
0x00315a:	movs    	r2, #0
0x00315c:	str     	r1, [sp, #0x14]
0x00315e:	str     	r1, [sp, #4]
0x003160:	str     	r2, [sp]
0x003162:	str     	r2, [sp, #8]
0x003164:	movs    	r6, #0xf1
0x003166:	movs    	r4, #0
0x003168:	adds    	r3, r4, #0
0x00316a:	lsls    	r6, r6, #9
0x00316c:	ldr     	r2, [r0, #8]
0x00316e:	movs    	r1, #0x45
0x003170:	adds    	r5, r0, #0
0x003172:	adds    	r0, r6, #0
0x003174:	bl      	#0x2cdc
0x003178:	movs    	r1, #0
0x00317a:	movs    	r2, #0
0x00317c:	str     	r2, [sp, #8]
0x00317e:	str     	r1, [sp]
0x003180:	str     	r1, [sp, #4]
0x003182:	movs    	r7, #4
0x003184:	adds    	r3, r7, #0
0x003186:	movs    	r1, #0xa
0x003188:	adds    	r2, r0, #0
0x00318a:	str     	r0, [sp, #0x10]
0x00318c:	adds    	r0, r6, #0
0x00318e:	bl      	#0x2cdc
0x003192:	str     	r0, [sp, #0x18]
0x003194:	ldr     	r0, [sp, #0x10]
0x003196:	cmp     	r0, #0
0x003198:	ble     	#0x3270
0x00319a:	movs    	r1, #0
0x00319c:	str     	r1, [sp]
0x00319e:	str     	r1, [sp, #4]
0x0031a0:	movs    	r2, #0
0x0031a2:	movs    	r4, #0
0x0031a4:	adds    	r3, r4, #0
0x0031a6:	str     	r2, [sp, #8]
0x0031a8:	movs    	r1, #0x47
0x0031aa:	movs    	r0, #0xf1
0x0031ac:	lsls    	r0, r0, #9
0x0031ae:	ldr     	r2, [r5, #8]
0x0031b0:	bl      	#0x2cdc
0x0031b4:	movs    	r1, #0
0x0031b6:	str     	r1, [sp]
0x0031b8:	str     	r1, [sp, #4]
0x0031ba:	str     	r0, [sp, #0xc]
0x0031bc:	movs    	r2, #0
0x0031be:	str     	r2, [sp, #8]
0x0031c0:	movs    	r0, #0xf1
0x0031c2:	movs    	r1, #0x46
0x0031c4:	adds    	r3, r4, #0
0x0031c6:	lsls    	r0, r0, #9
0x0031c8:	ldr     	r2, [r5, #8]
0x0031ca:	bl      	#0x2cdc
0x0031ce:	lsls    	r0, r0, #0x18
0x0031d0:	asrs    	r0, r0, #0x18
0x0031d2:	movs    	r6, #0
0x0031d4:	adds    	r3, r0, #1
0x0031d6:	beq     	#0x3232
0x0031d8:	movs    	r1, #0
0x0031da:	str     	r1, [sp]
0x0031dc:	str     	r1, [sp, #4]
0x0031de:	movs    	r2, #0
0x0031e0:	str     	r2, [sp, #8]
0x0031e2:	movs    	r1, #0x45
0x0031e4:	movs    	r3, #0
0x0031e6:	movs    	r0, #0xf1
0x0031e8:	lsls    	r0, r0, #9
0x0031ea:	ldr     	r2, [r5, #8]
0x0031ec:	bl      	#0x2cdc
0x0031f0:	movs    	r2, #0
0x0031f2:	movs    	r1, #0
0x0031f4:	str     	r2, [sp, #8]
0x0031f6:	adds    	r7, r0, #0
0x0031f8:	adds    	r2, r0, #0
0x0031fa:	str     	r1, [sp]
0x0031fc:	str     	r1, [sp, #4]
0x0031fe:	movs    	r1, #0xa
0x003200:	movs    	r0, #0xf1
0x003202:	movs    	r3, #4
0x003204:	lsls    	r0, r0, #9
0x003206:	bl      	#0x2cdc
0x00320a:	adds    	r6, r0, #0
0x00320c:	cmp     	r7, #0
0x00320e:	ble     	#0x3232
0x003210:	movs    	r1, #0
0x003212:	str     	r1, [sp]
0x003214:	str     	r1, [sp, #4]
0x003216:	movs    	r2, #0
0x003218:	str     	r2, [sp, #8]
0x00321a:	movs    	r1, #0x47
0x00321c:	movs    	r3, #0
0x00321e:	movs    	r0, #0xf1
0x003220:	lsls    	r0, r0, #9
0x003222:	ldr     	r2, [r5, #8]
0x003224:	bl      	#0x2cdc
0x003228:	lsls    	r1, r4, #2
0x00322a:	adds    	r4, #1
0x00322c:	cmp     	r4, r7
0x00322e:	str     	r0, [r6, r1]
0x003230:	blt     	#0x3210
0x003232:	movs    	r1, #0
0x003234:	movs    	r2, #0
0x003236:	str     	r2, [sp, #8]
0x003238:	str     	r1, [sp]
0x00323a:	str     	r1, [sp, #4]
0x00323c:	movs    	r4, #0
0x00323e:	adds    	r3, r4, #0
0x003240:	movs    	r1, #0xf
0x003242:	movs    	r2, #0xc
0x003244:	movs    	r0, #0xf1
0x003246:	lsls    	r0, r0, #9
0x003248:	bl      	#0x2cdc
0x00324c:	ldr     	r1, [sp, #0x14]
0x00324e:	ldr     	r2, [sp, #0x18]
0x003250:	lsls    	r1, r1, #2
0x003252:	str     	r0, [r2, r1]
0x003254:	ldr     	r2, [sp, #0xc]
0x003256:	str     	r2, [r0]
0x003258:	ldr     	r2, [sp, #0x18]
0x00325a:	ldr     	r0, [r2, r1]
0x00325c:	str     	r6, [r0, #4]
0x00325e:	ldr     	r2, [sp, #0x18]
0x003260:	ldr     	r0, [r2, r1]
0x003262:	strb    	r4, [r0, #8]
0x003264:	ldr     	r1, [sp, #0x14]
0x003266:	ldr     	r0, [sp, #0x10]
0x003268:	adds    	r1, #1
0x00326a:	str     	r1, [sp, #0x14]
0x00326c:	cmp     	r1, r0
0x00326e:	blt     	#0x319a
0x003270:	ldr     	r0, [sp, #0x18]
0x003272:	add     	sp, #0x1c
0x003274:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003278 =====
0x003278:	push    	{r4, r5, r6, lr}
0x00327a:	sub     	sp, #0x10
0x00327c:	movs    	r1, #0
0x00327e:	adds    	r5, r0, #0
0x003280:	movs    	r2, #0
0x003282:	str     	r2, [sp, #8]
0x003284:	str     	r1, [sp]
0x003286:	str     	r1, [sp, #4]
0x003288:	movs    	r6, #0
0x00328a:	adds    	r3, r6, #0
0x00328c:	movs    	r1, #0xf
0x00328e:	movs    	r2, #0x34
0x003290:	movs    	r0, #0xf1
0x003292:	lsls    	r0, r0, #9
0x003294:	bl      	#0x2cdc
0x003298:	movs    	r1, #0
0x00329a:	str     	r1, [sp]
0x00329c:	str     	r1, [sp, #4]
0x00329e:	adds    	r4, r0, #0
0x0032a0:	movs    	r2, #0
0x0032a2:	str     	r2, [sp, #8]
0x0032a4:	movs    	r0, #0xf1
0x0032a6:	adds    	r3, r6, #0
0x0032a8:	movs    	r1, #0x45
0x0032aa:	lsls    	r0, r0, #9
0x0032ac:	ldr     	r2, [r5, #8]
0x0032ae:	bl      	#0x2cdc
0x0032b2:	str     	r0, [r4]
0x0032b4:	movs    	r1, #0
0x0032b6:	str     	r1, [sp]
0x0032b8:	str     	r1, [sp, #4]
0x0032ba:	movs    	r2, #0
0x0032bc:	str     	r2, [sp, #8]
0x0032be:	movs    	r1, #0x45
0x0032c0:	movs    	r0, #0xf1
0x0032c2:	adds    	r3, r6, #0
0x0032c4:	lsls    	r0, r0, #9
0x0032c6:	ldr     	r2, [r5, #8]
0x0032c8:	bl      	#0x2cdc
0x0032cc:	str     	r0, [r4, #4]
0x0032ce:	movs    	r1, #0
0x0032d0:	str     	r1, [sp]
0x0032d2:	str     	r1, [sp, #4]
0x0032d4:	movs    	r2, #0
0x0032d6:	str     	r2, [sp, #8]
0x0032d8:	movs    	r1, #0x45
0x0032da:	movs    	r0, #0xf1
0x0032dc:	adds    	r3, r6, #0
0x0032de:	lsls    	r0, r0, #9
0x0032e0:	ldr     	r2, [r5, #8]
0x0032e2:	bl      	#0x2cdc
0x0032e6:	str     	r0, [r4, #8]
0x0032e8:	movs    	r1, #0
0x0032ea:	str     	r1, [sp]
0x0032ec:	str     	r1, [sp, #4]
0x0032ee:	movs    	r2, #0
0x0032f0:	str     	r2, [sp, #8]
0x0032f2:	movs    	r1, #0x45
0x0032f4:	movs    	r0, #0xf1
0x0032f6:	adds    	r3, r6, #0
0x0032f8:	lsls    	r0, r0, #9
0x0032fa:	ldr     	r2, [r5, #8]
0x0032fc:	bl      	#0x2cdc
0x003300:	str     	r0, [r4, #0xc]
0x003302:	movs    	r1, #0
0x003304:	str     	r1, [sp]
0x003306:	str     	r1, [sp, #4]
0x003308:	movs    	r2, #0
0x00330a:	str     	r2, [sp, #8]
0x00330c:	movs    	r1, #0x45
0x00330e:	movs    	r0, #0xf1
0x003310:	adds    	r3, r6, #0
0x003312:	lsls    	r0, r0, #9
0x003314:	ldr     	r2, [r5, #8]
0x003316:	bl      	#0x2cdc
0x00331a:	str     	r0, [r4, #0x10]
0x00331c:	movs    	r1, #0
0x00331e:	str     	r1, [sp]
0x003320:	str     	r1, [sp, #4]
0x003322:	movs    	r2, #0
0x003324:	str     	r2, [sp, #8]
0x003326:	movs    	r1, #0x45
0x003328:	movs    	r0, #0xf1
0x00332a:	adds    	r3, r6, #0
0x00332c:	lsls    	r0, r0, #9
0x00332e:	ldr     	r2, [r5, #8]
0x003330:	bl      	#0x2cdc
0x003334:	str     	r0, [r4, #0x14]
0x003336:	movs    	r1, #0
0x003338:	str     	r1, [sp]
0x00333a:	str     	r1, [sp, #4]
0x00333c:	movs    	r2, #0
0x00333e:	str     	r2, [sp, #8]
0x003340:	movs    	r1, #0x45
0x003342:	movs    	r0, #0xf1
0x003344:	adds    	r3, r6, #0
0x003346:	lsls    	r0, r0, #9
0x003348:	ldr     	r2, [r5, #8]
0x00334a:	bl      	#0x2cdc
0x00334e:	str     	r0, [r4, #0x18]
0x003350:	movs    	r1, #0
0x003352:	str     	r1, [sp]
0x003354:	str     	r1, [sp, #4]
0x003356:	movs    	r2, #0
0x003358:	str     	r2, [sp, #8]
0x00335a:	movs    	r1, #0x45
0x00335c:	movs    	r0, #0xf1
0x00335e:	adds    	r3, r6, #0
0x003360:	lsls    	r0, r0, #9
0x003362:	ldr     	r2, [r5, #8]
0x003364:	bl      	#0x2cdc
0x003368:	str     	r0, [r4, #0x1c]
0x00336a:	movs    	r1, #0
0x00336c:	str     	r1, [sp]
0x00336e:	str     	r1, [sp, #4]
0x003370:	movs    	r2, #0
0x003372:	str     	r2, [sp, #8]
0x003374:	movs    	r1, #0x47
0x003376:	movs    	r0, #0xf1
0x003378:	adds    	r3, r6, #0
0x00337a:	lsls    	r0, r0, #9
0x00337c:	ldr     	r2, [r5, #8]
0x00337e:	bl      	#0x2cdc
0x003382:	str     	r0, [r4, #0x20]
0x003384:	movs    	r1, #0
0x003386:	str     	r1, [sp]
0x003388:	str     	r1, [sp, #4]
0x00338a:	movs    	r2, #0
0x00338c:	str     	r2, [sp, #8]
0x00338e:	movs    	r1, #0x45
0x003390:	movs    	r0, #0xf1
0x003392:	adds    	r3, r6, #0
0x003394:	lsls    	r0, r0, #9
0x003396:	ldr     	r2, [r5, #8]
0x003398:	bl      	#0x2cdc
0x00339c:	str     	r0, [r4, #0x24]
0x00339e:	movs    	r1, #0
0x0033a0:	str     	r1, [sp]
0x0033a2:	str     	r1, [sp, #4]
0x0033a4:	movs    	r2, #0
0x0033a6:	str     	r2, [sp, #8]

; ===== candidate_0033d8 =====
0x0033d8:	push    	{r4, r5, lr}
0x0033da:	ldr     	r5, [pc, #0x48]
0x0033dc:	movs    	r4, #0xff
0x0033de:	add     	r5, sb
0x0033e0:	ldr     	r0, [r5, #0xc]
0x0033e2:	adds    	r4, #0x24
0x0033e4:	cmp     	r0, #0
0x0033e6:	sub     	sp, #0xc
0x0033e8:	bne     	#0x33ec
0x0033ea:	subs    	r4, #1
0x0033ec:	bl      	#0x35a4
0x0033f0:	ldr     	r0, [r5, #0x10]
0x0033f2:	bl      	#0x3498
0x0033f6:	movs    	r3, #0
0x0033f8:	str     	r3, [r5, #0x10]
0x0033fa:	movs    	r1, #0
0x0033fc:	str     	r1, [sp]
0x0033fe:	str     	r1, [sp, #4]
0x003400:	movs    	r2, #0
0x003402:	movs    	r1, #0x34
0x003404:	movs    	r0, #0xf1
0x003406:	lsls    	r0, r0, #9
0x003408:	str     	r2, [sp, #8]
0x00340a:	bl      	#0x2cdc
0x00340e:	bl      	#0x1efc
0x003412:	movs    	r1, #0
0x003414:	mvns    	r1, r1
0x003416:	adds    	r2, r0, #0
0x003418:	adds    	r0, r4, #0
0x00341a:	bl      	#0x3644
0x00341e:	add     	sp, #0xc
0x003420:	pop     	{r4, r5, pc}

; ===== candidate_003428 =====
0x003428:	push    	{r4, r5, r6, lr}
0x00342a:	ldr     	r5, [pc, #0x68]
0x00342c:	movs    	r4, #0
0x00342e:	add     	r5, sb
0x003430:	ldr     	r0, [r5, #0x14]
0x003432:	sub     	sp, #0x10
0x003434:	cmp     	r0, #0
0x003436:	beq     	#0x348c
0x003438:	movs    	r6, #0xf1
0x00343a:	ldr     	r3, [r0, #0xc]
0x00343c:	lsls    	r6, r6, #9
0x00343e:	cmp     	r3, #0
0x003440:	beq     	#0x3458
0x003442:	movs    	r2, #0
0x003444:	movs    	r1, #0
0x003446:	str     	r2, [sp, #8]
0x003448:	adds    	r2, r3, #0
0x00344a:	str     	r1, [sp]
0x00344c:	str     	r1, [sp, #4]
0x00344e:	movs    	r1, #9
0x003450:	adds    	r3, r4, #0
0x003452:	adds    	r0, r6, #0
0x003454:	bl      	#0x2cdc
0x003458:	ldr     	r0, [r5, #0x14]
0x00345a:	ldr     	r3, [r0, #0x10]
0x00345c:	cmp     	r3, #0
0x00345e:	beq     	#0x3476
0x003460:	movs    	r2, #0
0x003462:	movs    	r1, #0
0x003464:	str     	r2, [sp, #8]
0x003466:	adds    	r2, r3, #0
0x003468:	str     	r1, [sp]
0x00346a:	str     	r1, [sp, #4]
0x00346c:	movs    	r1, #9
0x00346e:	adds    	r3, r4, #0
0x003470:	adds    	r0, r6, #0
0x003472:	bl      	#0x2cdc
0x003476:	movs    	r1, #0
0x003478:	str     	r1, [sp]
0x00347a:	str     	r1, [sp, #4]
0x00347c:	movs    	r2, #0
0x00347e:	str     	r2, [sp, #8]
0x003480:	movs    	r1, #9
0x003482:	adds    	r3, r4, #0
0x003484:	adds    	r0, r6, #0
0x003486:	ldr     	r2, [r5, #0x14]
0x003488:	bl      	#0x2cdc
0x00348c:	str     	r4, [r5, #0x14]
0x00348e:	add     	sp, #0x10
0x003490:	pop     	{r4, r5, r6, pc}

; ===== candidate_003498 =====
0x003498:	push    	{r4, r5, r6, r7, lr}
0x00349a:	sub     	sp, #0xc
0x00349c:	adds    	r5, r0, #0
0x00349e:	beq     	#0x34fa
0x0034a0:	movs    	r1, #0
0x0034a2:	movs    	r2, #0
0x0034a4:	str     	r2, [sp, #8]
0x0034a6:	str     	r1, [sp]
0x0034a8:	str     	r1, [sp, #4]
0x0034aa:	movs    	r1, #0x11
0x0034ac:	adds    	r2, r5, #0
0x0034ae:	movs    	r3, #4
0x0034b0:	movs    	r0, #0xf1
0x0034b2:	lsls    	r0, r0, #9
0x0034b4:	bl      	#0x2cdc
0x0034b8:	adds    	r6, r0, #0
0x0034ba:	movs    	r4, #0
0x0034bc:	cmp     	r0, #0
0x0034be:	ble     	#0x34e2
0x0034c0:	lsls    	r0, r4, #2
0x0034c2:	ldr     	r7, [r5, r0]
0x0034c4:	movs    	r1, #0
0x0034c6:	movs    	r2, #0
0x0034c8:	str     	r2, [sp, #8]
0x0034ca:	str     	r1, [sp]
0x0034cc:	str     	r1, [sp, #4]
0x0034ce:	movs    	r1, #0x8e
0x0034d0:	adds    	r2, r7, #0
0x0034d2:	movs    	r0, #0xf1
0x0034d4:	movs    	r3, #0
0x0034d6:	lsls    	r0, r0, #9
0x0034d8:	bl      	#0x2cdc
0x0034dc:	adds    	r4, #1
0x0034de:	cmp     	r4, r6
0x0034e0:	blt     	#0x34c0
0x0034e2:	movs    	r1, #0
0x0034e4:	movs    	r2, #0
0x0034e6:	str     	r2, [sp, #8]
0x0034e8:	str     	r1, [sp]
0x0034ea:	str     	r1, [sp, #4]
0x0034ec:	movs    	r1, #9
0x0034ee:	adds    	r2, r5, #0
0x0034f0:	movs    	r3, #0
0x0034f2:	movs    	r0, #0xf1
0x0034f4:	lsls    	r0, r0, #9
0x0034f6:	bl      	#0x2cdc
0x0034fa:	add     	sp, #0xc
0x0034fc:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003500 =====
0x003500:	push    	{r4, r5, r6, r7, lr}
0x003502:	sub     	sp, #0xc
0x003504:	adds    	r6, r0, #0
0x003506:	beq     	#0x359e
0x003508:	movs    	r1, #0
0x00350a:	movs    	r2, #0
0x00350c:	str     	r2, [sp, #8]
0x00350e:	str     	r1, [sp]
0x003510:	str     	r1, [sp, #4]
0x003512:	movs    	r1, #0x11
0x003514:	adds    	r2, r6, #0
0x003516:	movs    	r3, #4
0x003518:	movs    	r0, #0xf1
0x00351a:	lsls    	r0, r0, #9
0x00351c:	bl      	#0x2cdc
0x003520:	adds    	r7, r0, #0
0x003522:	movs    	r4, #0
0x003524:	cmp     	r0, #0
0x003526:	ble     	#0x3586
0x003528:	lsls    	r0, r4, #2
0x00352a:	ldr     	r5, [r6, r0]
0x00352c:	ldr     	r3, [r5]
0x00352e:	cmp     	r3, #0
0x003530:	beq     	#0x354a
0x003532:	movs    	r2, #0
0x003534:	movs    	r1, #0
0x003536:	str     	r2, [sp, #8]
0x003538:	adds    	r2, r3, #0
0x00353a:	str     	r1, [sp]
0x00353c:	str     	r1, [sp, #4]
0x00353e:	movs    	r1, #9
0x003540:	movs    	r3, #0
0x003542:	movs    	r0, #0xf1
0x003544:	lsls    	r0, r0, #9
0x003546:	bl      	#0x2cdc
0x00354a:	ldr     	r3, [r5, #4]
0x00354c:	cmp     	r3, #0
0x00354e:	beq     	#0x3568
0x003550:	movs    	r2, #0
0x003552:	movs    	r1, #0
0x003554:	str     	r2, [sp, #8]
0x003556:	adds    	r2, r3, #0
0x003558:	str     	r1, [sp]
0x00355a:	str     	r1, [sp, #4]
0x00355c:	movs    	r1, #0x12
0x00355e:	movs    	r3, #0
0x003560:	movs    	r0, #0xf1
0x003562:	lsls    	r0, r0, #9
0x003564:	bl      	#0x2cdc
0x003568:	movs    	r1, #0
0x00356a:	movs    	r2, #0
0x00356c:	str     	r2, [sp, #8]
0x00356e:	str     	r1, [sp]
0x003570:	str     	r1, [sp, #4]
0x003572:	movs    	r1, #9
0x003574:	adds    	r2, r5, #0
0x003576:	movs    	r3, #0
0x003578:	movs    	r0, #0xf1
0x00357a:	lsls    	r0, r0, #9
0x00357c:	bl      	#0x2cdc
0x003580:	adds    	r4, #1
0x003582:	cmp     	r4, r7
0x003584:	blt     	#0x3528
0x003586:	movs    	r1, #0
0x003588:	movs    	r2, #0
0x00358a:	str     	r2, [sp, #8]
0x00358c:	str     	r1, [sp]
0x00358e:	str     	r1, [sp, #4]
0x003590:	movs    	r1, #9
0x003592:	adds    	r2, r6, #0
0x003594:	movs    	r3, #0
0x003596:	movs    	r0, #0xf1
0x003598:	lsls    	r0, r0, #9
0x00359a:	bl      	#0x2cdc
0x00359e:	add     	sp, #0xc
0x0035a0:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0035a4 =====
0x0035a4:	push    	{r4, r5, r6, r7, lr}
0x0035a6:	ldr     	r0, [pc, #0x98]
0x0035a8:	movs    	r7, #0
0x0035aa:	add     	r0, sb
0x0035ac:	ldr     	r4, [r0, #0xc]
0x0035ae:	sub     	sp, #0xc
0x0035b0:	cmp     	r4, #0
0x0035b2:	beq     	#0x3636
0x0035b4:	movs    	r1, #0
0x0035b6:	movs    	r2, #0
0x0035b8:	str     	r2, [sp, #8]
0x0035ba:	str     	r1, [sp]
0x0035bc:	str     	r1, [sp, #4]
0x0035be:	movs    	r1, #0x11
0x0035c0:	adds    	r2, r4, #0
0x0035c2:	movs    	r3, #4
0x0035c4:	movs    	r0, #0xf1
0x0035c6:	lsls    	r0, r0, #9
0x0035c8:	bl      	#0x2cdc
0x0035cc:	adds    	r6, r0, #0
0x0035ce:	movs    	r4, #0
0x0035d0:	cmp     	r0, #0
0x0035d2:	ble     	#0x361a
0x0035d4:	ldr     	r1, [pc, #0x68]
0x0035d6:	lsls    	r0, r4, #2
0x0035d8:	add     	r1, sb
0x0035da:	ldr     	r1, [r1, #0xc]
0x0035dc:	ldr     	r5, [r1, r0]
0x0035de:	ldr     	r3, [r5, #0x20]
0x0035e0:	cmp     	r3, #0
0x0035e2:	beq     	#0x35fc
0x0035e4:	movs    	r2, #0
0x0035e6:	movs    	r1, #0
0x0035e8:	str     	r2, [sp, #8]
0x0035ea:	adds    	r2, r3, #0
0x0035ec:	str     	r1, [sp]
0x0035ee:	str     	r1, [sp, #4]
0x0035f0:	movs    	r1, #9
0x0035f2:	adds    	r3, r7, #0
0x0035f4:	movs    	r0, #0xf1
0x0035f6:	lsls    	r0, r0, #9
0x0035f8:	bl      	#0x2cdc
0x0035fc:	movs    	r1, #0
0x0035fe:	movs    	r2, #0
0x003600:	str     	r2, [sp, #8]
0x003602:	str     	r1, [sp]
0x003604:	str     	r1, [sp, #4]
0x003606:	adds    	r3, r7, #0
0x003608:	adds    	r2, r5, #0
0x00360a:	movs    	r1, #9
0x00360c:	movs    	r0, #0xf1
0x00360e:	lsls    	r0, r0, #9
0x003610:	bl      	#0x2cdc
0x003614:	adds    	r4, #1
0x003616:	cmp     	r4, r6
0x003618:	blt     	#0x35d4
0x00361a:	movs    	r1, #0
0x00361c:	ldr     	r0, [pc, #0x20]
0x00361e:	str     	r1, [sp]
0x003620:	str     	r1, [sp, #4]
0x003622:	movs    	r2, #0
0x003624:	str     	r2, [sp, #8]
0x003626:	add     	r0, sb
0x003628:	ldr     	r2, [r0, #0xc]
0x00362a:	movs    	r0, #0xf1
0x00362c:	movs    	r1, #9
0x00362e:	adds    	r3, r7, #0
0x003630:	lsls    	r0, r0, #9
0x003632:	bl      	#0x2cdc
0x003636:	ldr     	r0, [pc, #8]
0x003638:	add     	r0, sb
0x00363a:	str     	r7, [r0, #0xc]
0x00363c:	add     	sp, #0xc
0x00363e:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003644 =====
0x003644:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x003646:	sub     	sp, #0x10
0x003648:	movs    	r1, #0
0x00364a:	movs    	r2, #0
0x00364c:	str     	r2, [sp, #8]
0x00364e:	str     	r1, [sp]
0x003650:	str     	r1, [sp, #4]
0x003652:	movs    	r7, #0xf1
0x003654:	movs    	r6, #0
0x003656:	adds    	r3, r6, #0
0x003658:	lsls    	r7, r7, #9
0x00365a:	movs    	r1, #0x17
0x00365c:	adds    	r2, r0, #0
0x00365e:	adds    	r4, r0, #0
0x003660:	adds    	r0, r7, #0
0x003662:	bl      	#0x2cdc
0x003666:	movs    	r1, #0
0x003668:	movs    	r2, #0
0x00366a:	str     	r2, [sp, #8]
0x00366c:	str     	r1, [sp]
0x00366e:	str     	r1, [sp, #4]
0x003670:	movs    	r1, #0xe1
0x003672:	movs    	r2, #0x1d
0x003674:	adds    	r3, r6, #0
0x003676:	adds    	r0, r7, #0
0x003678:	bl      	#0x2cdc
0x00367c:	movs    	r1, #0
0x00367e:	movs    	r2, #0
0x003680:	str     	r2, [sp, #8]
0x003682:	str     	r1, [sp]
0x003684:	str     	r1, [sp, #4]
0x003686:	movs    	r1, #0xe1
0x003688:	movs    	r2, #0x18
0x00368a:	str     	r0, [sp, #0xc]
0x00368c:	adds    	r3, r6, #0
0x00368e:	adds    	r0, r7, #0
0x003690:	bl      	#0x2cdc
0x003694:	ldr     	r5, [r0, #0xc]
0x003696:	movs    	r1, #0
0x003698:	movs    	r2, #0
0x00369a:	str     	r2, [sp, #8]
0x00369c:	str     	r1, [sp]
0x00369e:	str     	r1, [sp, #4]
0x0036a0:	movs    	r1, #0xe1
0x0036a2:	movs    	r2, #0x18
0x0036a4:	adds    	r3, r6, #0
0x0036a6:	adds    	r0, r7, #0
0x0036a8:	bl      	#0x2cdc
0x0036ac:	ldr     	r3, [r0, #8]
0x0036ae:	ldr     	r1, [sp, #0xc]
0x0036b0:	movs    	r2, #0
0x0036b2:	str     	r2, [sp, #8]
0x0036b4:	str     	r1, [sp, #4]
0x0036b6:	movs    	r1, #0x52
0x0036b8:	adds    	r2, r4, #0
0x0036ba:	adds    	r0, r7, #0
0x0036bc:	str     	r5, [sp]
0x0036be:	bl      	#0x2cdc
0x0036c2:	movs    	r1, #0
0x0036c4:	movs    	r2, #0
0x0036c6:	str     	r1, [sp]
0x0036c8:	str     	r1, [sp, #4]
0x0036ca:	movs    	r1, #0x19
0x0036cc:	str     	r2, [sp, #8]
0x0036ce:	adds    	r3, r6, #0
0x0036d0:	adds    	r0, r7, #0
0x0036d2:	ldr     	r2, [sp, #0x14]
0x0036d4:	bl      	#0x2cdc
0x0036d8:	movs    	r1, #0
0x0036da:	movs    	r2, #0
0x0036dc:	str     	r1, [sp]
0x0036de:	str     	r1, [sp, #4]
0x0036e0:	movs    	r1, #0x19
0x0036e2:	str     	r2, [sp, #8]
0x0036e4:	adds    	r3, r6, #0
0x0036e6:	adds    	r0, r7, #0
0x0036e8:	ldr     	r2, [sp, #0x18]
0x0036ea:	bl      	#0x2cdc
0x0036ee:	ldr     	r4, [pc, #0x194]
0x0036f0:	add     	r4, sb
0x0036f2:	ldr     	r0, [r4, #0x14]
0x0036f4:	cmp     	r0, #0
0x0036f6:	bne     	#0x3750
0x0036f8:	movs    	r1, #0
0x0036fa:	movs    	r2, #0
0x0036fc:	str     	r2, [sp, #8]
0x0036fe:	str     	r1, [sp]
0x003700:	str     	r1, [sp, #4]
0x003702:	movs    	r1, #0x1a
0x003704:	movs    	r2, #1
0x003706:	adds    	r3, r6, #0
0x003708:	adds    	r0, r7, #0
0x00370a:	bl      	#0x2cdc
0x00370e:	movs    	r1, #0
0x003710:	str     	r1, [sp]
0x003712:	str     	r1, [sp, #4]
0x003714:	movs    	r2, #0
0x003716:	movs    	r1, #0x1a
0x003718:	adds    	r3, r6, #0
0x00371a:	adds    	r0, r7, #0
0x00371c:	str     	r2, [sp, #8]
0x00371e:	bl      	#0x2cdc
0x003722:	movs    	r1, #0
0x003724:	movs    	r2, #0
0x003726:	str     	r2, [sp, #8]
0x003728:	mvns    	r2, r1
0x00372a:	str     	r1, [sp]
0x00372c:	str     	r1, [sp, #4]
0x00372e:	movs    	r1, #0x19
0x003730:	adds    	r3, r6, #0
0x003732:	adds    	r0, r7, #0
0x003734:	bl      	#0x2cdc
0x003738:	movs    	r1, #0
0x00373a:	movs    	r2, #0
0x00373c:	str     	r2, [sp, #8]
0x00373e:	mvns    	r2, r1
0x003740:	str     	r1, [sp]
0x003742:	str     	r1, [sp, #4]
0x003744:	movs    	r1, #0x19
0x003746:	adds    	r3, r6, #0
0x003748:	adds    	r0, r7, #0
0x00374a:	bl      	#0x2cdc
0x00374e:	b       	#0x386a
0x003750:	movs    	r1, #0
0x003752:	str     	r1, [sp]
0x003754:	str     	r1, [sp, #4]
0x003756:	movs    	r2, #0
0x003758:	movs    	r1, #0x1a
0x00375a:	adds    	r3, r6, #0
0x00375c:	adds    	r0, r7, #0
0x00375e:	str     	r2, [sp, #8]
0x003760:	bl      	#0x2cdc
0x003764:	movs    	r1, #0
0x003766:	movs    	r2, #0
0x003768:	str     	r2, [sp, #8]
0x00376a:	str     	r1, [sp]
0x00376c:	str     	r1, [sp, #4]
0x00376e:	ldr     	r0, [r4, #0x14]
0x003770:	movs    	r3, #0
0x003772:	ldrsb   	r2, [r0, r3]
0x003774:	movs    	r0, #0xf1

; ===== candidate_003888 =====
0x003888:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x00388a:	sub     	sp, #0x10
0x00388c:	movs    	r1, #0
0x00388e:	movs    	r5, #0xff
0x003890:	movs    	r2, #0
0x003892:	movs    	r4, #0
0x003894:	adds    	r3, r4, #0
0x003896:	str     	r2, [sp, #8]
0x003898:	adds    	r5, #0x25
0x00389a:	str     	r1, [sp]
0x00389c:	str     	r1, [sp, #4]
0x00389e:	movs    	r1, #0x17
0x0038a0:	adds    	r2, r5, #0
0x0038a2:	movs    	r0, #0xf1
0x0038a4:	lsls    	r0, r0, #9
0x0038a6:	bl      	#0x2cdc
0x0038aa:	movs    	r1, #0
0x0038ac:	movs    	r2, #0
0x0038ae:	str     	r2, [sp, #8]
0x0038b0:	str     	r1, [sp]
0x0038b2:	str     	r1, [sp, #4]
0x0038b4:	movs    	r1, #0xe1
0x0038b6:	movs    	r2, #0x1d
0x0038b8:	adds    	r3, r4, #0
0x0038ba:	movs    	r0, #0xf1
0x0038bc:	lsls    	r0, r0, #9
0x0038be:	bl      	#0x2cdc
0x0038c2:	movs    	r1, #0
0x0038c4:	adds    	r6, r0, #0
0x0038c6:	movs    	r2, #0
0x0038c8:	str     	r2, [sp, #8]
0x0038ca:	str     	r1, [sp]
0x0038cc:	str     	r1, [sp, #4]
0x0038ce:	movs    	r1, #0xe1
0x0038d0:	movs    	r2, #0x18
0x0038d2:	movs    	r0, #0xf1
0x0038d4:	adds    	r3, r4, #0
0x0038d6:	lsls    	r0, r0, #9
0x0038d8:	bl      	#0x2cdc
0x0038dc:	ldr     	r7, [r0, #0xc]
0x0038de:	movs    	r1, #0
0x0038e0:	movs    	r2, #0
0x0038e2:	str     	r2, [sp, #8]
0x0038e4:	str     	r1, [sp]
0x0038e6:	str     	r1, [sp, #4]
0x0038e8:	movs    	r1, #0xe1
0x0038ea:	movs    	r2, #0x18
0x0038ec:	movs    	r0, #0xf1
0x0038ee:	adds    	r3, r4, #0
0x0038f0:	lsls    	r0, r0, #9
0x0038f2:	bl      	#0x2cdc
0x0038f6:	ldr     	r3, [r0, #8]
0x0038f8:	movs    	r2, #0
0x0038fa:	str     	r2, [sp, #8]
0x0038fc:	adds    	r2, r5, #0
0x0038fe:	movs    	r0, #0xf1
0x003900:	movs    	r1, #0x52
0x003902:	lsls    	r0, r0, #9
0x003904:	str     	r7, [sp]
0x003906:	str     	r6, [sp, #4]
0x003908:	bl      	#0x2cdc
0x00390c:	movs    	r1, #0
0x00390e:	movs    	r2, #0
0x003910:	str     	r1, [sp]
0x003912:	str     	r1, [sp, #4]
0x003914:	movs    	r1, #0x19
0x003916:	str     	r2, [sp, #8]
0x003918:	adds    	r3, r4, #0
0x00391a:	movs    	r0, #0xf1
0x00391c:	lsls    	r0, r0, #9
0x00391e:	ldr     	r2, [sp, #0x10]
0x003920:	bl      	#0x2cdc
0x003924:	movs    	r1, #0
0x003926:	movs    	r2, #0
0x003928:	str     	r1, [sp]
0x00392a:	str     	r1, [sp, #4]
0x00392c:	movs    	r1, #0x19
0x00392e:	str     	r2, [sp, #8]
0x003930:	adds    	r3, r4, #0
0x003932:	movs    	r0, #0xf1
0x003934:	lsls    	r0, r0, #9
0x003936:	ldr     	r2, [sp, #0x14]
0x003938:	bl      	#0x2cdc
0x00393c:	movs    	r1, #0
0x00393e:	movs    	r2, #0
0x003940:	str     	r1, [sp]
0x003942:	str     	r1, [sp, #4]
0x003944:	movs    	r1, #0x19
0x003946:	str     	r2, [sp, #8]
0x003948:	adds    	r3, r4, #0
0x00394a:	movs    	r0, #0xf1
0x00394c:	lsls    	r0, r0, #9
0x00394e:	ldr     	r2, [sp, #0x18]
0x003950:	bl      	#0x2cdc
0x003954:	movs    	r1, #0
0x003956:	movs    	r2, #0
0x003958:	str     	r2, [sp, #8]
0x00395a:	str     	r1, [sp]
0x00395c:	str     	r1, [sp, #4]
0x00395e:	movs    	r1, #0x1b
0x003960:	movs    	r2, #1
0x003962:	adds    	r3, r4, #0
0x003964:	movs    	r0, #0xf1
0x003966:	lsls    	r0, r0, #9
0x003968:	bl      	#0x2cdc
0x00396c:	add     	sp, #0x1c
0x00396e:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003970 =====
0x003970:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x003972:	sub     	sp, #0xc
0x003974:	adds    	r4, r1, #0
0x003976:	movs    	r1, #0
0x003978:	adds    	r5, r2, #0
0x00397a:	movs    	r2, #0
0x00397c:	str     	r2, [sp, #8]
0x00397e:	str     	r1, [sp]
0x003980:	str     	r1, [sp, #4]
0x003982:	movs    	r6, #0xf1
0x003984:	adds    	r7, r3, #0
0x003986:	movs    	r3, #0
0x003988:	lsls    	r6, r6, #9
0x00398a:	movs    	r1, #0xe1
0x00398c:	movs    	r2, #0xc2
0x00398e:	adds    	r0, r6, #0
0x003990:	bl      	#0x2cdc
0x003994:	cmp     	r0, #0
0x003996:	bne     	#0x39ae
0x003998:	movs    	r1, #0
0x00399a:	movs    	r2, #0
0x00399c:	str     	r2, [sp, #8]
0x00399e:	str     	r1, [sp]
0x0039a0:	str     	r1, [sp, #4]
0x0039a2:	movs    	r1, #0x14
0x0039a4:	movs    	r2, #0xc2
0x0039a6:	movs    	r3, #1
0x0039a8:	adds    	r0, r6, #0
0x0039aa:	bl      	#0x2cdc
0x0039ae:	ldr     	r0, [sp, #0xc]
0x0039b0:	cmp     	r0, #0x12
0x0039b2:	blo     	#0x39b6
0x0039b4:	b       	#0x3aca
0x0039b6:	adr     	r3, #8
0x0039b8:	ldrb    	r3, [r3, r0]
0x0039ba:	lsls    	r3, r3, #1
0x0039bc:	add     	pc, r3
0x0039be:	movs    	r0, r0
0x0039c0:	ldrsb   	r3, [r1, r1]
0x0039c2:	asrs    	r1, r1, #4
0x0039c4:	asrs    	r4, r2, #0x1c
0x0039c6:	movs    	r0, #0x41
0x0039c8:	mov     	r3, r3
0x0039ca:	ldrb    	r1, [r0, #0x16]
0x0039cc:	strb    	r1, [r7, #0x15]
0x0039ce:	ldr     	r0, [r6, #0x34]
0x0039d0:	str     	r6, [r4, #0x14]
0x0039d2:	adds    	r2, r7, #0
0x0039d4:	adds    	r1, r5, #0
0x0039d6:	adds    	r0, r4, #0
0x0039d8:	bl      	#0x3644
0x0039dc:	movs    	r0, #0
0x0039de:	add     	sp, #0x1c
0x0039e0:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003bf2 =====
0x003bf2:	push    	{r0, r1, r2, r3, r4, r5, r7}
0x003bf4:	bl      	#0xff0c6170
0x003bf8:	movs    	r0, r0
0x003bfa:	movs    	r0, r0
0x003bfc:	bl      	#0xff0c6178
0x003c00:	stm     	r7!, {r1, r3, r6, r7}
0x003c02:	bmi     	#0x3bb4

; ===== candidate_003c66 =====
0x003c66:	push    	{r1, r2, r4, r6, r7, lr}
0x003c68:	adr     	r1, #0x28c
0x003c6a:	movs    	r0, r0

; ===== candidate_003c96 =====
0x003c96:	push    	{r1, r2, r4, r6, r7, lr}
0x003c98:	adr     	r1, #0x28c
0x003c9a:	movs    	r0, r0
0x003c9c:	svc     	#0xb8
