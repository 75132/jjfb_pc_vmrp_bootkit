; fallback candidate disassembly from Thumb prologues; true code is ARM entry + Thumb functions.

; ARM entry
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0x85bc
0x000018:	pop     	{r4, pc}
0x00001c:	andeq   	r4, r0, r8, ror r7
0x000020:	ands    	r2, r0, #128, #8
0x000024:	rsbmi   	r0, r0, #0
0x000028:	eors    	r3, r2, r1, asr #32
0x00002c:	rsbhs   	r1, r1, #0
0x000030:	rsbs    	ip, r0, r1, lsr #3
0x000034:	blo     	#0xbc
0x000038:	rsbs    	ip, r0, r1, lsr #8
0x00003c:	blo     	#0x80
0x000040:	lsl     	r0, r0, #8
0x000044:	orr     	r2, r2, #0xff000000
0x000048:	rsbs    	ip, r0, r1, lsr #4
0x00004c:	blo     	#0xb0
0x000050:	rsbs    	ip, r0, r1, lsr #8
0x000054:	blo     	#0x80
0x000058:	lsl     	r0, r0, #8
0x00005c:	orr     	r2, r2, #0xff0000
0x000060:	rsbs    	ip, r0, r1, lsr #8
0x000064:	lslhs   	r0, r0, #8
0x000068:	orrhs   	r2, r2, #0xff00
0x00006c:	rsbs    	ip, r0, r1, lsr #4
0x000070:	blo     	#0xb0
0x000074:	rsbs    	ip, r0, #0
0x000078:	bhs     	#0xf8
0x00007c:	lsrhs   	r0, r0, #8
0x000080:	rsbs    	ip, r0, r1, lsr #7
0x000084:	subhs   	r1, r1, r0, lsl #7
0x000088:	adc     	r2, r2, r2
0x00008c:	rsbs    	ip, r0, r1, lsr #6
0x000090:	subhs   	r1, r1, r0, lsl #6
0x000094:	adc     	r2, r2, r2
0x000098:	rsbs    	ip, r0, r1, lsr #5
0x00009c:	subhs   	r1, r1, r0, lsl #5
0x0000a0:	adc     	r2, r2, r2
0x0000a4:	rsbs    	ip, r0, r1, lsr #4
0x0000a8:	subhs   	r1, r1, r0, lsl #4
0x0000ac:	adc     	r2, r2, r2
0x0000b0:	rsbs    	ip, r0, r1, lsr #3
0x0000b4:	subhs   	r1, r1, r0, lsl #3
0x0000b8:	adc     	r2, r2, r2
0x0000bc:	rsbs    	ip, r0, r1, lsr #2
0x0000c0:	subhs   	r1, r1, r0, lsl #2
0x0000c4:	adc     	r2, r2, r2
0x0000c8:	rsbs    	ip, r0, r1, lsr #1
0x0000cc:	subhs   	r1, r1, r0, lsl #1
0x0000d0:	adc     	r2, r2, r2
0x0000d4:	rsbs    	ip, r0, r1
0x0000d8:	subhs   	r1, r1, r0
0x0000dc:	adcs    	r2, r2, r2
0x0000e0:	bhs     	#0x7c
0x0000e4:	eors    	r0, r2, r3, asr #31
0x0000e8:	add     	r0, r0, r3, lsr #31
0x0000ec:	rsbhs   	r1, r1, #0
0x0000f0:	bx      	lr
0x0000f4:	andeq   	r4, r0, r8, ror r7
0x0000f8:	mov     	r0, #2
0x0000fc:	mov     	r1, #2
0x000100:	b       	#0x118
0x000104:	strmi   	r4, [r8, -r0, lsl #14]

; ===== candidate_000008 =====
0x000008:	ands    	r0, r2
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	movs    	r1, #0x68

; ===== candidate_00000a =====
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	movs    	r1, #0x68

; ===== candidate_00011a =====
0x00011a:	stmdb   	sp!, {r2}

; ===== candidate_000134 =====
0x000134:	push    	{r4, r5, r6, lr}
0x000136:	ldr     	r6, [pc, #0x38]
0x000138:	adds    	r5, r1, #0
0x00013a:	adds    	r1, r0, #0
0x00013c:	adds    	r4, r0, #0
0x00013e:	add     	r6, pc
0x000140:	adds    	r0, r6, #0
0x000142:	bl      	#0x146
0x000146:	adds    	r2, r0, #0
0x000148:	cmp     	r0, r6
0x00014a:	bne     	#0x15a
0x00014c:	adds    	r1, r5, #0
0x00014e:	adds    	r0, r4, #0
0x000150:	bl      	#0x194
0x000154:	pop     	{r4, r5, r6}
0x000156:	pop     	{r3}
0x000158:	bx      	r3
0x00015a:	ldr     	r0, [pc, #0x18]
0x00015c:	add     	r0, pc
0x00015e:	cmp     	r2, r0
0x000160:	beq     	#0x16a
0x000162:	adds    	r1, r5, #0
0x000164:	adds    	r0, r4, #0
0x000166:	bl      	#0x108
0x00016a:	movs    	r0, #0
0x00016c:	b       	#0x154
0x00016e:	movs    	r0, r0
0x000170:	mcr2    	p15, #6, pc, c5, c7, #7
0x000174:	mcr2    	p15, #5, pc, c5, c7, #7
0x000178:	bx      	pc

; ===== candidate_000194 =====
0x000194:	push    	{r3, r4, r5, lr}
0x000196:	subs    	r2, r0, #1
0x000198:	cmp     	r2, #0xd
0x00019a:	adr     	r4, #0x90
0x00019c:	bhs     	#0x1ec
0x00019e:	movs    	r2, #0x17
0x0001a0:	ldr     	r3, [pc, #0x8c]
0x0001a2:	muls    	r2, r0, r2
0x0001a4:	add     	r3, pc
0x0001a6:	adds    	r5, r2, r3
0x0001a8:	subs    	r5, #0x17
0x0001aa:	cmp     	r0, #2
0x0001ac:	bne     	#0x1d8
0x0001ae:	lsls    	r0, r1, #5
0x0001b0:	bpl     	#0x1b6
0x0001b2:	adr     	r4, #0x80
0x0001b4:	b       	#0x1ee
0x0001b6:	ldr     	r0, [pc, #0x90]
0x0001b8:	ands    	r0, r1
0x0001ba:	beq     	#0x1c0
0x0001bc:	adr     	r4, #0x8c
0x0001be:	b       	#0x1ee
0x0001c0:	lsls    	r0, r1, #3
0x0001c2:	bpl     	#0x1c8
0x0001c4:	adr     	r4, #0x94
0x0001c6:	b       	#0x1ee
0x0001c8:	lsls    	r0, r1, #2
0x0001ca:	bpl     	#0x1d0
0x0001cc:	adr     	r4, #0x98
0x0001ce:	b       	#0x1ee
0x0001d0:	lsls    	r0, r1, #1
0x0001d2:	bpl     	#0x1ee
0x0001d4:	adr     	r4, #0x9c
0x0001d6:	b       	#0x1ee
0x0001d8:	cmp     	r0, #8
0x0001da:	bne     	#0x1e0
0x0001dc:	adds    	r4, r1, #0
0x0001de:	b       	#0x1ee
0x0001e0:	cmp     	r0, #9
0x0001e2:	bne     	#0x1ee
0x0001e4:	cmp     	r1, #1
0x0001e6:	bne     	#0x1ee
0x0001e8:	adr     	r5, #0x98
0x0001ea:	b       	#0x1ee
0x0001ec:	adr     	r5, #0xac
0x0001ee:	movs    	r0, #0xa
0x0001f0:	bl      	#0x2b4
0x0001f4:	ldrb    	r0, [r5]
0x0001f6:	cmp     	r0, #0
0x0001f8:	beq     	#0x208
0x0001fa:	ldrb    	r0, [r5]
0x0001fc:	adds    	r5, #1
0x0001fe:	bl      	#0x2b4
0x000202:	ldrb    	r0, [r5]
0x000204:	cmp     	r0, #0
0x000206:	bne     	#0x1fa
0x000208:	ldrb    	r0, [r4]
0x00020a:	cmp     	r0, #0
0x00020c:	beq     	#0x21c
0x00020e:	ldrb    	r0, [r4]
0x000210:	adds    	r4, #1
0x000212:	bl      	#0x2b4
0x000216:	ldrb    	r0, [r4]
0x000218:	cmp     	r0, #0
0x00021a:	bne     	#0x20e
0x00021c:	movs    	r0, #0xa
0x00021e:	bl      	#0x2b4
0x000222:	pop     	{r3, r4, r5}
0x000224:	pop     	{r3}
0x000226:	movs    	r0, #1
0x000228:	bx      	r3
0x00022a:	movs    	r0, r0
0x00022c:	movs    	r0, r0
0x00022e:	movs    	r0, r0
0x000230:	adr     	r6, #0x2f0
0x000232:	movs    	r0, r0
0x000234:	ldr     	r1, [r1, #0x64]
0x000236:	str     	r6, [r6, #0x14]
0x000238:	ldr     	r4, [r5, #0x14]
0x00023a:	movs    	r0, #0x64
0x00023c:	strb    	r7, [r1, #1]
0x00023e:	strb    	r5, [r4, #9]
0x000240:	strb    	r1, [r4, #0x11]
0x000242:	ldr     	r1, [r5, #0x74]
0x000244:	lsls    	r6, r5, #1
0x000246:	movs    	r0, r0
0x000248:	movs    	r2, r0
0x00024a:	lsrs    	r0, r0, #0x20
0x00024c:	ldr     	r4, [r0, #0x14]
0x00024e:	ldr     	r6, [r6, #0x14]
0x000250:	str     	r4, [r4, #0x54]
0x000252:	tst     	r0, r4
0x000254:	movs    	r0, #0x79
0x000256:	str     	r2, [r3, #0x54]
0x000258:	ldr     	r2, [r6, #0x74]
0x00025a:	movs    	r0, r0
0x00025c:	strb    	r7, [r1, #0x19]
0x00025e:	strb    	r5, [r4, #9]
0x000260:	ldr     	r6, [r4, #0x44]
0x000262:	strb    	r7, [r5, #0x1d]
0x000264:	movs    	r0, r0
0x000266:	movs    	r0, r0
0x000268:	ldr     	r5, [r2, #0x64]
0x00026a:	str     	r4, [r4, #0x54]
0x00026c:	str     	r2, [r6, #0x64]
0x00026e:	ldr     	r4, [r5, #0x74]
0x000270:	lsls    	r7, r6, #1
0x000272:	movs    	r0, r0
0x000274:	ldr     	r1, [r1, #0x64]
0x000276:	ldrb    	r5, [r4, #1]
0x000278:	str     	r1, [r4, #0x34]
0x00027a:	movs    	r0, #0x74
0x00027c:	str     	r2, [r2, #0x54]
0x00027e:	strb    	r3, [r6, #0x15]
0x000280:	strb    	r4, [r5, #0x11]
0x000282:	movs    	r0, r0
0x000284:	movs    	r0, #0x3a
0x000286:	str     	r0, [r1, #0x54]
0x000288:	strb    	r1, [r4, #1]
0x00028a:	ldr     	r0, [r4, #0x50]
0x00028c:	ldr     	r5, [r4, #0x54]
0x00028e:	strb    	r7, [r5, #9]
0x000290:	movs    	r0, #0x79
0x000292:	ldr     	r3, [r4, #0x74]
0x000294:	strb    	r2, [r6, #9]
0x000296:	strb    	r5, [r6, #1]
0x000298:	str     	r4, [r6, #0x54]
0x00029a:	lsls    	r4, r4, #1
0x00029c:	ldr     	r5, [r2, #0x64]
0x00029e:	ldr     	r3, [r5, #0x64]
0x0002a0:	strb    	r7, [r5, #0x1d]
0x0002a2:	movs    	r0, #0x6e
0x0002a4:	ldr     	r3, [r6, #0x14]
0x0002a6:	ldr     	r7, [r4, #0x64]
0x0002a8:	ldr     	r1, [r4, #0x44]
0x0002aa:	movs    	r0, r0
0x0002ac:	bx      	pc

; ===== candidate_0002b4 =====
0x0002b4:	push    	{r3, lr}
0x0002b6:	add     	r3, sp, #0
0x0002b8:	strb    	r0, [r3]
0x0002ba:	movs    	r0, #3
0x0002bc:	mov     	r1, sp
0x0002be:	svc     	#0xab
0x0002c0:	add     	sp, #4
0x0002c2:	pop     	{r3}
0x0002c4:	bx      	r3
0x0002c6:	movs    	r0, r0
0x0002c8:	movs    	r0, r1
0x0002ca:	b       	#0xfffffe0c
0x0002cc:	asrs    	r0, r1, #0x20
0x0002ce:	b       	#0xfffffe10
0x0002d0:	movs    	r1, r0
0x0002d2:	b       	#0x3d6
0x0002d4:	vrhadd.u16	d14, d14, d31
0x0002d8:	movs    	r4, r1
0x0002da:	movs    	r0, r0
0x0002dc:	lsls    	r0, r1, #7
0x0002de:	movs    	r0, r0
0x0002e0:	str     	r0, [sp]
0x0002e2:	b       	#0x626
0x0002e4:	vrhadd.u16	d14, d14, d31
0x0002e8:	adds    	r0, #0x14
0x0002ea:	b       	#0xfffffe2c
0x0002ec:	cmp     	r7, #0xc0
0x0002ee:	b       	#0x632
0x0002f0:	stm     	r0!, {r0, r1, r4, r7}
0x0002f2:	b       	#0x478
0x0002f4:	adds    	r0, #0xc
0x0002f6:	b       	#0xfffffe38
0x0002f8:	asrs    	r1, r0, #0xd
0x0002fa:	b       	#0x3c2
0x0002fc:	lsls    	r3, r2, #6
0x0002fe:	b       	#0x342
0x000300:	vrhadd.u16	d14, d14, d31
0x000304:	ldr     	r5, [pc, #0x34c]
0x000306:	asrs    	r2, r4, #1

; ===== candidate_00030c =====
0x00030c:	push    	{r4, r5, lr}
0x00030e:	ldr     	r4, [pc, #0xb4]
0x000310:	movs    	r2, #0x1c
0x000312:	add     	r4, pc
0x000314:	ldr     	r0, [r4, #0x38]
0x000316:	movs    	r1, #0
0x000318:	ldr     	r3, [r0, #0x38]
0x00031a:	ldr     	r0, [pc, #0xac]
0x00031c:	sub     	sp, #0xc
0x00031e:	add     	r0, sb
0x000320:	blx     	r3
0x000322:	movs    	r2, #0
0x000324:	movs    	r0, #0
0x000326:	str     	r0, [sp]
0x000328:	ldr     	r1, [pc, #0x9c]
0x00032a:	movs    	r3, #0
0x00032c:	add     	r1, sb
0x00032e:	str     	r1, [sp, #4]
0x000330:	movs    	r1, #0x64
0x000332:	movs    	r0, #1
0x000334:	str     	r2, [sp, #8]
0x000336:	bl      	#0x8694
0x00033a:	ldr     	r1, [pc, #0x8c]
0x00033c:	movs    	r0, #0
0x00033e:	add     	r1, sb
0x000340:	subs    	r1, #0x7c
0x000342:	str     	r0, [r1, #8]
0x000344:	ldr     	r5, [pc, #0x80]
0x000346:	str     	r0, [r1, #0x10]
0x000348:	str     	r0, [r1, #0xc]
0x00034a:	add     	r5, sb
0x00034c:	subs    	r5, #0xfc
0x00034e:	movs    	r0, #1
0x000350:	str     	r0, [r5, #0x18]
0x000352:	ldr     	r0, [r4, #0x38]
0x000354:	ldr     	r2, [pc, #0x74]
0x000356:	ldr     	r1, [r0, #0x68]
0x000358:	add     	r2, sb
0x00035a:	str     	r1, [r5, #0x2c]
0x00035c:	ldr     	r1, [r0, #0xc]
0x00035e:	ldr     	r4, [pc, #0x70]
0x000360:	str     	r1, [r5, #0x30]
0x000362:	ldr     	r1, [r0, #0x10]
0x000364:	str     	r1, [r5, #0x34]
0x000366:	ldr     	r1, [r0, #0x14]
0x000368:	str     	r1, [r5, #0x38]
0x00036a:	ldr     	r1, [r0, #0x18]
0x00036c:	str     	r1, [r5, #0x3c]
0x00036e:	ldr     	r1, [r0, #0x1c]
0x000370:	str     	r1, [r5, #0x40]
0x000372:	ldr     	r1, [r0, #0x20]
0x000374:	str     	r1, [r5, #0x44]
0x000376:	ldr     	r1, [r0, #0x24]
0x000378:	str     	r1, [r5, #0x48]
0x00037a:	ldr     	r1, [r0, #0x28]
0x00037c:	str     	r1, [r5, #0x4c]
0x00037e:	ldr     	r1, [r0, #0x2c]
0x000380:	str     	r1, [r5, #0x50]
0x000382:	ldr     	r1, [r0, #0x30]
0x000384:	str     	r1, [r5, #0x54]
0x000386:	ldr     	r1, [r0, #0x34]
0x000388:	str     	r1, [r5, #0x58]
0x00038a:	ldr     	r1, [r0, #0x38]
0x00038c:	str     	r1, [r5, #0x5c]
0x00038e:	ldr     	r1, [r0, #0x3c]
0x000390:	str     	r1, [r5, #0x60]
0x000392:	ldr     	r1, [r0, #0x40]
0x000394:	str     	r1, [r5, #0x64]
0x000396:	ldr     	r1, [r0, #0x44]
0x000398:	str     	r1, [r5, #0x68]
0x00039a:	ldr     	r1, [r0, #0x48]
0x00039c:	str     	r1, [r5, #0x6c]
0x00039e:	ldr     	r1, [r0, #0x4c]
0x0003a0:	str     	r1, [r5, #0x70]
0x0003a2:	movs    	r1, #0
0x0003a4:	str     	r1, [r2]
0x0003a6:	movs    	r1, #1
0x0003a8:	lsls    	r1, r1, #9
0x0003aa:	adds    	r0, r0, r1
0x0003ac:	ldr     	r3, [r0, #8]
0x0003ae:	movs    	r1, #7
0x0003b0:	adds    	r2, r4, #0
0x0003b2:	movs    	r0, #0
0x0003b4:	blx     	r3
0x0003b6:	cmp     	r0, r4
0x0003b8:	bne     	#0x3be
0x0003ba:	subs    	r0, #2
0x0003bc:	str     	r0, [r5, #0x28]
0x0003be:	add     	sp, #0xc
0x0003c0:	pop     	{r4, r5, pc}

; ===== candidate_0003d4 =====
0x0003d4:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x0003d6:	sub     	sp, #0x10
0x0003d8:	adds    	r5, r2, #0
0x0003da:	movs    	r2, #0
0x0003dc:	movs    	r1, #0
0x0003de:	str     	r2, [sp, #8]
0x0003e0:	adds    	r7, r0, #0
0x0003e2:	adds    	r2, r0, #0
0x0003e4:	str     	r1, [sp]
0x0003e6:	str     	r1, [sp, #4]
0x0003e8:	movs    	r1, #0x26
0x0003ea:	movs    	r0, #0xf1
0x0003ec:	movs    	r3, #0
0x0003ee:	lsls    	r0, r0, #9
0x0003f0:	bl      	#0x8694
0x0003f4:	adds    	r6, r0, #0
0x0003f6:	movs    	r4, #0
0x0003f8:	cmp     	r0, #0
0x0003fa:	ble     	#0x422
0x0003fc:	movs    	r1, #0
0x0003fe:	movs    	r2, #0
0x000400:	str     	r2, [sp, #8]
0x000402:	str     	r1, [sp]
0x000404:	str     	r1, [sp, #4]
0x000406:	adds    	r3, r4, #0
0x000408:	adds    	r2, r7, #0
0x00040a:	movs    	r1, #0x27
0x00040c:	movs    	r0, #0xf1
0x00040e:	lsls    	r0, r0, #9
0x000410:	bl      	#0x8694
0x000414:	lsls    	r1, r5, #2
0x000416:	ldr     	r2, [sp, #0x14]
0x000418:	adds    	r5, #1
0x00041a:	adds    	r4, #1
0x00041c:	cmp     	r4, r6
0x00041e:	str     	r0, [r2, r1]
0x000420:	blt     	#0x3fc
0x000422:	adds    	r0, r5, #0
0x000424:	add     	sp, #0x1c
0x000426:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000428 =====
0x000428:	push    	{r4, r5, lr}
0x00042a:	sub     	sp, #0xc
0x00042c:	movs    	r1, #0
0x00042e:	movs    	r2, #0
0x000430:	str     	r2, [sp, #8]
0x000432:	str     	r1, [sp]
0x000434:	str     	r1, [sp, #4]
0x000436:	movs    	r5, #0
0x000438:	adds    	r3, r5, #0
0x00043a:	movs    	r1, #0xe1
0x00043c:	movs    	r2, #0x5b
0x00043e:	movs    	r0, #0xf1
0x000440:	lsls    	r0, r0, #9
0x000442:	bl      	#0x8694
0x000446:	ldr     	r4, [r0]
0x000448:	movs    	r1, #0
0x00044a:	movs    	r2, #0
0x00044c:	str     	r2, [sp, #8]
0x00044e:	str     	r1, [sp]
0x000450:	str     	r1, [sp, #4]
0x000452:	adds    	r3, r5, #0
0x000454:	adds    	r2, r4, #0
0x000456:	movs    	r1, #0x90
0x000458:	movs    	r0, #0xf1
0x00045a:	lsls    	r0, r0, #9
0x00045c:	bl      	#0x8694
0x000460:	movs    	r2, #0
0x000462:	movs    	r1, #0
0x000464:	str     	r2, [sp, #8]
0x000466:	adds    	r4, r0, #0
0x000468:	adds    	r3, r5, #0
0x00046a:	adds    	r2, r0, #0
0x00046c:	str     	r1, [sp]
0x00046e:	str     	r1, [sp, #4]
0x000470:	movs    	r1, #0x8f
0x000472:	movs    	r0, #0xf1
0x000474:	lsls    	r0, r0, #9
0x000476:	bl      	#0x8694
0x00047a:	movs    	r1, #0
0x00047c:	movs    	r2, #0
0x00047e:	str     	r2, [sp, #8]
0x000480:	str     	r1, [sp]
0x000482:	str     	r1, [sp, #4]
0x000484:	adds    	r3, r5, #0
0x000486:	adds    	r2, r4, #0
0x000488:	movs    	r1, #0x8e
0x00048a:	movs    	r0, #0xf1
0x00048c:	lsls    	r0, r0, #9
0x00048e:	bl      	#0x8694
0x000492:	movs    	r1, #0
0x000494:	str     	r1, [sp]
0x000496:	str     	r1, [sp, #4]
0x000498:	movs    	r2, #0
0x00049a:	movs    	r1, #0x2c
0x00049c:	adds    	r3, r5, #0
0x00049e:	movs    	r0, #0xf1
0x0004a0:	lsls    	r0, r0, #9
0x0004a2:	str     	r2, [sp, #8]
0x0004a4:	bl      	#0x8694
0x0004a8:	add     	sp, #0xc
0x0004aa:	pop     	{r4, r5, pc}

; ===== candidate_0004ac =====
0x0004ac:	push    	{r4, r5, r6, r7, lr}
0x0004ae:	sub     	sp, #0xc
0x0004b0:	movs    	r1, #0
0x0004b2:	movs    	r2, #0
0x0004b4:	str     	r2, [sp, #8]
0x0004b6:	str     	r1, [sp]
0x0004b8:	str     	r1, [sp, #4]
0x0004ba:	adds    	r6, r0, #0
0x0004bc:	movs    	r0, #0xf1
0x0004be:	movs    	r1, #0xe1
0x0004c0:	movs    	r2, #6
0x0004c2:	movs    	r3, #0
0x0004c4:	lsls    	r0, r0, #9
0x0004c6:	bl      	#0x8694
0x0004ca:	movs    	r2, #0
0x0004cc:	movs    	r1, #0
0x0004ce:	movs    	r7, #4
0x0004d0:	adds    	r3, r7, #0
0x0004d2:	str     	r2, [sp, #8]
0x0004d4:	adds    	r2, r0, #0
0x0004d6:	str     	r1, [sp]
0x0004d8:	str     	r1, [sp, #4]
0x0004da:	movs    	r1, #0x11
0x0004dc:	movs    	r0, #0xf1
0x0004de:	lsls    	r0, r0, #9
0x0004e0:	bl      	#0x8694
0x0004e4:	movs    	r1, #0
0x0004e6:	movs    	r2, #0
0x0004e8:	str     	r2, [sp, #8]
0x0004ea:	str     	r1, [sp]
0x0004ec:	str     	r1, [sp, #4]
0x0004ee:	adds    	r5, r0, #0
0x0004f0:	movs    	r0, #0xf1
0x0004f2:	movs    	r1, #0xe1
0x0004f4:	movs    	r2, #6
0x0004f6:	movs    	r4, #0
0x0004f8:	movs    	r3, #0
0x0004fa:	lsls    	r0, r0, #9
0x0004fc:	bl      	#0x8694
0x000500:	ldr     	r1, [pc, #0xe4]
0x000502:	movs    	r2, #0
0x000504:	add     	r1, sb
0x000506:	str     	r0, [r1, #0x4c]
0x000508:	movs    	r1, #0
0x00050a:	str     	r1, [sp]
0x00050c:	str     	r1, [sp, #4]
0x00050e:	str     	r2, [sp, #8]
0x000510:	adds    	r3, r7, #0
0x000512:	adds    	r2, r5, #0
0x000514:	movs    	r1, #0xa
0x000516:	movs    	r0, #0xf1
0x000518:	lsls    	r0, r0, #9
0x00051a:	bl      	#0x8694
0x00051e:	adds    	r7, r0, #0
0x000520:	cmp     	r5, #0
0x000522:	ble     	#0x544
0x000524:	movs    	r1, #0
0x000526:	str     	r1, [sp]
0x000528:	str     	r1, [sp, #4]
0x00052a:	movs    	r2, #0
0x00052c:	movs    	r1, #0x13
0x00052e:	movs    	r3, #0
0x000530:	movs    	r0, #0xf1
0x000532:	lsls    	r0, r0, #9
0x000534:	str     	r2, [sp, #8]
0x000536:	bl      	#0x8694
0x00053a:	lsls    	r1, r4, #2
0x00053c:	adds    	r4, #1
0x00053e:	cmp     	r4, r5
0x000540:	str     	r0, [r7, r1]
0x000542:	blt     	#0x524
0x000544:	movs    	r1, #0
0x000546:	movs    	r2, #0
0x000548:	str     	r2, [sp, #8]
0x00054a:	str     	r1, [sp]
0x00054c:	str     	r1, [sp, #4]
0x00054e:	movs    	r1, #0x14
0x000550:	movs    	r2, #6
0x000552:	adds    	r3, r7, #0
0x000554:	movs    	r0, #0xf1
0x000556:	lsls    	r0, r0, #9
0x000558:	bl      	#0x8694
0x00055c:	movs    	r1, #0
0x00055e:	movs    	r2, #0
0x000560:	movs    	r4, #0
0x000562:	adds    	r3, r4, #0
0x000564:	str     	r2, [sp, #8]
0x000566:	str     	r1, [sp]
0x000568:	str     	r1, [sp, #4]
0x00056a:	movs    	r1, #0x44
0x00056c:	adds    	r2, r6, #0
0x00056e:	movs    	r0, #0xf1
0x000570:	lsls    	r0, r0, #9
0x000572:	bl      	#0x8694
0x000576:	movs    	r1, #0
0x000578:	str     	r1, [sp]
0x00057a:	str     	r1, [sp, #4]
0x00057c:	movs    	r2, #0
0x00057e:	str     	r2, [sp, #8]
0x000580:	movs    	r1, #0x46
0x000582:	adds    	r3, r4, #0
0x000584:	movs    	r0, #0xf1
0x000586:	lsls    	r0, r0, #9
0x000588:	ldr     	r2, [r6, #8]
0x00058a:	bl      	#0x8694
0x00058e:	adds    	r5, r0, #0
0x000590:	cmp     	r0, #0
0x000592:	ble     	#0x5ca
0x000594:	movs    	r1, #0
0x000596:	movs    	r2, #0
0x000598:	str     	r2, [sp, #8]
0x00059a:	str     	r1, [sp]
0x00059c:	str     	r1, [sp, #4]
0x00059e:	movs    	r1, #0xa8
0x0005a0:	adds    	r2, r6, #0
0x0005a2:	movs    	r3, #0
0x0005a4:	movs    	r0, #0xf1
0x0005a6:	lsls    	r0, r0, #9
0x0005a8:	bl      	#0x8694
0x0005ac:	movs    	r2, #0
0x0005ae:	movs    	r1, #0
0x0005b0:	str     	r2, [sp, #8]
0x0005b2:	adds    	r2, r0, #0
0x0005b4:	str     	r1, [sp]
0x0005b6:	str     	r1, [sp, #4]
0x0005b8:	movs    	r1, #0xa9
0x0005ba:	movs    	r0, #0xf1
0x0005bc:	movs    	r3, #1
0x0005be:	lsls    	r0, r0, #9
0x0005c0:	bl      	#0x8694
0x0005c4:	adds    	r4, #1
0x0005c6:	cmp     	r4, r5
0x0005c8:	blt     	#0x594
0x0005ca:	movs    	r2, #0
0x0005cc:	movs    	r1, #0
0x0005ce:	str     	r2, [sp, #8]
0x0005d0:	movs    	r2, #0x62
0x0005d2:	str     	r1, [sp]
0x0005d4:	str     	r1, [sp, #4]
0x0005d6:	movs    	r1, #0x84
0x0005d8:	mvns    	r2, r2

; ===== candidate_0005ec =====
0x0005ec:	push    	{r4, r5, lr}
0x0005ee:	sub     	sp, #0xc
0x0005f0:	movs    	r5, #0
0x0005f2:	movs    	r2, #0
0x0005f4:	movs    	r1, #0
0x0005f6:	str     	r2, [sp, #8]
0x0005f8:	adds    	r3, r5, #0
0x0005fa:	adds    	r4, r0, #0
0x0005fc:	adds    	r2, r0, #0
0x0005fe:	str     	r1, [sp]
0x000600:	str     	r1, [sp, #4]
0x000602:	movs    	r1, #0x44
0x000604:	movs    	r0, #0xf1
0x000606:	lsls    	r0, r0, #9
0x000608:	bl      	#0x8694
0x00060c:	movs    	r1, #0
0x00060e:	str     	r1, [sp]
0x000610:	str     	r1, [sp, #4]
0x000612:	movs    	r2, #0
0x000614:	str     	r2, [sp, #8]
0x000616:	movs    	r1, #0x45
0x000618:	adds    	r3, r5, #0
0x00061a:	movs    	r0, #0xf1
0x00061c:	lsls    	r0, r0, #9
0x00061e:	ldr     	r2, [r4, #8]
0x000620:	bl      	#0x8694
0x000624:	ldr     	r1, [pc, #0x34]
0x000626:	movs    	r2, #0
0x000628:	add     	r1, sb
0x00062a:	str     	r0, [r1]
0x00062c:	movs    	r1, #0
0x00062e:	str     	r1, [sp]
0x000630:	str     	r1, [sp, #4]
0x000632:	movs    	r1, #0x2c
0x000634:	movs    	r0, #0xf1
0x000636:	adds    	r3, r5, #0
0x000638:	lsls    	r0, r0, #9
0x00063a:	str     	r2, [sp, #8]
0x00063c:	bl      	#0x8694
0x000640:	movs    	r1, #0
0x000642:	movs    	r2, #0
0x000644:	str     	r2, [sp, #8]
0x000646:	str     	r1, [sp]
0x000648:	str     	r1, [sp, #4]
0x00064a:	movs    	r1, #0x9c
0x00064c:	movs    	r2, #0x14
0x00064e:	adds    	r3, r5, #0
0x000650:	movs    	r0, #0xf1
0x000652:	lsls    	r0, r0, #9
0x000654:	bl      	#0x8694
0x000658:	add     	sp, #0xc
0x00065a:	pop     	{r4, r5, pc}

; ===== candidate_000660 =====
0x000660:	push    	{r4, r5, r6, r7, lr}
0x000662:	sub     	sp, #0xc
0x000664:	movs    	r1, #0
0x000666:	adds    	r6, r0, #0
0x000668:	movs    	r2, #0
0x00066a:	str     	r2, [sp, #8]
0x00066c:	str     	r1, [sp]
0x00066e:	str     	r1, [sp, #4]
0x000670:	movs    	r4, #0
0x000672:	adds    	r3, r4, #0
0x000674:	movs    	r1, #0xe1
0x000676:	movs    	r2, #0x52
0x000678:	movs    	r0, #0xf1
0x00067a:	lsls    	r0, r0, #9
0x00067c:	bl      	#0x8694
0x000680:	movs    	r2, #0
0x000682:	movs    	r1, #0
0x000684:	str     	r2, [sp, #8]
0x000686:	adds    	r3, r4, #0
0x000688:	adds    	r2, r0, #0
0x00068a:	str     	r1, [sp]
0x00068c:	str     	r1, [sp, #4]
0x00068e:	movs    	r1, #0x26
0x000690:	movs    	r0, #0xf1
0x000692:	lsls    	r0, r0, #9
0x000694:	bl      	#0x8694
0x000698:	movs    	r1, #0
0x00069a:	subs    	r5, r0, #1
0x00069c:	movs    	r2, #0
0x00069e:	str     	r2, [sp, #8]
0x0006a0:	str     	r1, [sp]
0x0006a2:	str     	r1, [sp, #4]
0x0006a4:	movs    	r1, #0xe1
0x0006a6:	movs    	r2, #0x52
0x0006a8:	movs    	r0, #0xf1
0x0006aa:	adds    	r3, r4, #0
0x0006ac:	lsls    	r0, r0, #9
0x0006ae:	bl      	#0x8694
0x0006b2:	movs    	r2, #0
0x0006b4:	movs    	r1, #0
0x0006b6:	str     	r2, [sp, #8]
0x0006b8:	adds    	r3, r5, #0
0x0006ba:	adds    	r2, r0, #0
0x0006bc:	str     	r1, [sp]
0x0006be:	str     	r1, [sp, #4]
0x0006c0:	movs    	r1, #0x27
0x0006c2:	movs    	r0, #0xf1
0x0006c4:	lsls    	r0, r0, #9
0x0006c6:	bl      	#0x8694
0x0006ca:	movs    	r1, #0
0x0006cc:	adds    	r5, r0, #0
0x0006ce:	movs    	r2, #0
0x0006d0:	str     	r2, [sp, #8]
0x0006d2:	str     	r1, [sp]
0x0006d4:	str     	r1, [sp, #4]
0x0006d6:	adds    	r3, r4, #0
0x0006d8:	adds    	r2, r6, #0
0x0006da:	movs    	r1, #0x44
0x0006dc:	movs    	r0, #0xf1
0x0006de:	lsls    	r0, r0, #9
0x0006e0:	bl      	#0x8694
0x0006e4:	movs    	r1, #0
0x0006e6:	str     	r1, [sp]
0x0006e8:	str     	r1, [sp, #4]
0x0006ea:	movs    	r2, #0
0x0006ec:	str     	r2, [sp, #8]
0x0006ee:	movs    	r1, #0x45
0x0006f0:	adds    	r3, r4, #0
0x0006f2:	movs    	r0, #0xf1
0x0006f4:	lsls    	r0, r0, #9
0x0006f6:	ldr     	r2, [r6, #8]
0x0006f8:	bl      	#0x8694
0x0006fc:	str     	r0, [r5]
0x0006fe:	movs    	r0, #1
0x000700:	strb    	r0, [r5, #0x14]
0x000702:	movs    	r2, #0
0x000704:	movs    	r1, #0
0x000706:	str     	r2, [sp, #8]
0x000708:	ldr     	r2, [pc, #0x14]
0x00070a:	str     	r1, [sp]
0x00070c:	str     	r1, [sp, #4]
0x00070e:	adds    	r3, r4, #0
0x000710:	add     	r2, pc
0x000712:	movs    	r1, #0x33
0x000714:	movs    	r0, #0xf1
0x000716:	lsls    	r0, r0, #9
0x000718:	bl      	#0x8694
0x00071c:	add     	sp, #0xc
0x00071e:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000724 =====
0x000724:	push    	{r4, r5, r6, r7, lr}
0x000726:	ldr     	r1, [pc, #0x3c4]
0x000728:	sub     	sp, #0x14
0x00072a:	adds    	r4, r0, #0
0x00072c:	add     	r1, pc
0x00072e:	ldr     	r7, [pc, #0x3c0]
0x000730:	add     	r7, sb
0x000732:	ldr     	r2, [r7]
0x000734:	blx     	r2
0x000736:	movs    	r5, #0xf1
0x000738:	lsls    	r5, r5, #9
0x00073a:	movs    	r6, #0
0x00073c:	cmp     	r0, #0
0x00073e:	bne     	#0x826
0x000740:	movs    	r1, #0
0x000742:	movs    	r2, #0
0x000744:	str     	r2, [sp, #8]
0x000746:	str     	r1, [sp]
0x000748:	str     	r1, [sp, #4]
0x00074a:	movs    	r1, #0xe1
0x00074c:	movs    	r2, #0x20
0x00074e:	adds    	r3, r6, #0
0x000750:	adds    	r0, r5, #0
0x000752:	bl      	#0x8694
0x000756:	cmp     	r0, #0
0x000758:	bne     	#0x828
0x00075a:	movs    	r1, #0
0x00075c:	movs    	r2, #0
0x00075e:	str     	r2, [sp, #8]
0x000760:	str     	r1, [sp]
0x000762:	str     	r1, [sp, #4]
0x000764:	movs    	r1, #0xe1
0x000766:	movs    	r2, #0x5b
0x000768:	adds    	r3, r6, #0
0x00076a:	adds    	r7, r5, #0
0x00076c:	adds    	r0, r5, #0
0x00076e:	bl      	#0x8694
0x000772:	ldr     	r4, [r0, #4]
0x000774:	movs    	r1, #0
0x000776:	movs    	r2, #0
0x000778:	str     	r2, [sp, #8]
0x00077a:	str     	r1, [sp]
0x00077c:	str     	r1, [sp, #4]
0x00077e:	movs    	r1, #0xe1
0x000780:	movs    	r2, #0x5b
0x000782:	adds    	r3, r6, #0
0x000784:	adds    	r0, r5, #0
0x000786:	bl      	#0x8694
0x00078a:	movs    	r1, #0
0x00078c:	movs    	r2, #0
0x00078e:	str     	r2, [sp, #8]
0x000790:	str     	r1, [sp]
0x000792:	str     	r1, [sp, #4]
0x000794:	movs    	r1, #0xb1
0x000796:	adds    	r2, r0, #0
0x000798:	adds    	r3, r4, #0
0x00079a:	adds    	r0, r5, #0
0x00079c:	bl      	#0x8694
0x0007a0:	movs    	r2, #0
0x0007a2:	adds    	r3, r0, #0
0x0007a4:	movs    	r1, #0
0x0007a6:	str     	r2, [sp, #8]
0x0007a8:	ldr     	r2, [pc, #0x348]
0x0007aa:	str     	r1, [sp]
0x0007ac:	str     	r1, [sp, #4]
0x0007ae:	add     	r2, pc
0x0007b0:	movs    	r1, #0x2d
0x0007b2:	adds    	r0, r5, #0
0x0007b4:	bl      	#0x8694
0x0007b8:	movs    	r1, #0
0x0007ba:	movs    	r2, #0
0x0007bc:	str     	r2, [sp, #8]
0x0007be:	str     	r1, [sp]
0x0007c0:	str     	r1, [sp, #4]
0x0007c2:	movs    	r1, #0xe1
0x0007c4:	movs    	r2, #0x5b
0x0007c6:	adds    	r4, r0, #0
0x0007c8:	adds    	r3, r6, #0
0x0007ca:	adds    	r0, r5, #0
0x0007cc:	bl      	#0x8694
0x0007d0:	ldrb    	r0, [r0, #0x1a]
0x0007d2:	cmp     	r0, #1
0x0007d4:	bne     	#0x858
0x0007d6:	movs    	r1, #0
0x0007d8:	movs    	r2, #0
0x0007da:	str     	r2, [sp, #8]
0x0007dc:	str     	r1, [sp]
0x0007de:	str     	r1, [sp, #4]
0x0007e0:	movs    	r1, #0xe1
0x0007e2:	movs    	r2, #0x5b
0x0007e4:	adds    	r3, r6, #0
0x0007e6:	adds    	r0, r7, #0
0x0007e8:	bl      	#0x8694
0x0007ec:	movs    	r3, #8
0x0007ee:	ldrsh   	r5, [r0, r3]
0x0007f0:	cmp     	r5, #0
0x0007f2:	ble     	#0x858
0x0007f4:	movs    	r1, #0
0x0007f6:	movs    	r2, #0
0x0007f8:	str     	r2, [sp, #8]
0x0007fa:	str     	r1, [sp]
0x0007fc:	str     	r1, [sp, #4]
0x0007fe:	movs    	r1, #0x3f
0x000800:	adds    	r2, r5, #0
0x000802:	adds    	r3, r6, #0
0x000804:	adds    	r0, r7, #0
0x000806:	bl      	#0x8694
0x00080a:	movs    	r2, #0
0x00080c:	adds    	r5, r0, #0
0x00080e:	movs    	r1, #0
0x000810:	ldr     	r3, [pc, #0x2e4]
0x000812:	str     	r1, [sp]
0x000814:	str     	r1, [sp, #4]
0x000816:	str     	r2, [sp, #8]
0x000818:	add     	r3, pc
0x00081a:	adds    	r2, r4, #0
0x00081c:	movs    	r1, #0x2d
0x00081e:	adds    	r0, r7, #0
0x000820:	bl      	#0x8694
0x000824:	b       	#0x82a
0x000826:	b       	#0x8da
0x000828:	b       	#0x88c
0x00082a:	movs    	r1, #0
0x00082c:	movs    	r2, #0
0x00082e:	str     	r2, [sp, #8]
0x000830:	str     	r1, [sp]
0x000832:	str     	r1, [sp, #4]
0x000834:	movs    	r1, #0x2d
0x000836:	adds    	r2, r0, #0
0x000838:	adds    	r3, r5, #0
0x00083a:	adds    	r0, r7, #0
0x00083c:	bl      	#0x8694
0x000840:	movs    	r1, #0
0x000842:	movs    	r2, #0
0x000844:	str     	r2, [sp, #8]
0x000846:	str     	r1, [sp]
0x000848:	str     	r1, [sp, #4]
0x00084a:	movs    	r1, #9
0x00084c:	adds    	r2, r5, #0
0x00084e:	adds    	r4, r0, #0
0x000850:	adds    	r3, r6, #0

; ===== candidate_002200 =====
0x002200:	push    	{r4, r5, r6, r7, lr}
0x002202:	sub     	sp, #0x14
0x002204:	movs    	r1, #0
0x002206:	movs    	r2, #0
0x002208:	str     	r2, [sp, #8]
0x00220a:	str     	r1, [sp]
0x00220c:	str     	r1, [sp, #4]
0x00220e:	movs    	r7, #0xf1
0x002210:	movs    	r6, #0
0x002212:	adds    	r3, r6, #0
0x002214:	lsls    	r7, r7, #9
0x002216:	movs    	r1, #0xe1
0x002218:	movs    	r2, #0x5b
0x00221a:	adds    	r0, r7, #0
0x00221c:	bl      	#0x8694
0x002220:	ldr     	r4, [r0]
0x002222:	movs    	r1, #0
0x002224:	movs    	r2, #0
0x002226:	str     	r2, [sp, #8]
0x002228:	str     	r1, [sp]
0x00222a:	str     	r1, [sp, #4]
0x00222c:	movs    	r1, #0x90
0x00222e:	adds    	r2, r4, #0
0x002230:	adds    	r3, r6, #0
0x002232:	adds    	r0, r7, #0
0x002234:	bl      	#0x8694
0x002238:	movs    	r1, #0
0x00223a:	movs    	r2, #0
0x00223c:	str     	r2, [sp, #8]
0x00223e:	str     	r1, [sp]
0x002240:	str     	r1, [sp, #4]
0x002242:	movs    	r1, #0xe1
0x002244:	movs    	r2, #6
0x002246:	adds    	r4, r0, #0
0x002248:	movs    	r5, #0
0x00224a:	adds    	r3, r6, #0
0x00224c:	adds    	r0, r7, #0
0x00224e:	bl      	#0x8694
0x002252:	str     	r0, [sp, #0x10]
0x002254:	movs    	r1, #0
0x002256:	ldr     	r0, [pc, #0xd0]
0x002258:	movs    	r2, #0
0x00225a:	str     	r2, [sp, #8]
0x00225c:	str     	r1, [sp]
0x00225e:	str     	r1, [sp, #4]
0x002260:	add     	r0, sb
0x002262:	ldr     	r3, [r0, #0x4c]
0x002264:	movs    	r1, #0x14
0x002266:	movs    	r2, #6
0x002268:	adds    	r0, r7, #0
0x00226a:	bl      	#0x8694
0x00226e:	ldrb    	r0, [r4, #0x1a]
0x002270:	cmp     	r0, #1
0x002272:	bne     	#0x22b2
0x002274:	movs    	r1, #0
0x002276:	str     	r1, [sp]
0x002278:	str     	r1, [sp, #4]
0x00227a:	movs    	r2, #0
0x00227c:	str     	r2, [sp, #8]
0x00227e:	movs    	r1, #0xcb
0x002280:	movs    	r3, #1
0x002282:	adds    	r0, r7, #0
0x002284:	ldr     	r2, [r4, #4]
0x002286:	bl      	#0x8694
0x00228a:	cmp     	r0, #0
0x00228c:	beq     	#0x229a
0x00228e:	ldrh    	r1, [r0, #8]
0x002290:	ldrh    	r2, [r4, #8]
0x002292:	adds    	r1, r1, r2
0x002294:	strh    	r1, [r0, #8]
0x002296:	movs    	r5, #1
0x002298:	b       	#0x22c8
0x00229a:	movs    	r1, #0
0x00229c:	movs    	r2, #0
0x00229e:	str     	r2, [sp, #8]
0x0022a0:	str     	r1, [sp]
0x0022a2:	str     	r1, [sp, #4]
0x0022a4:	movs    	r1, #0xa9
0x0022a6:	adds    	r2, r4, #0
0x0022a8:	adds    	r3, r6, #0
0x0022aa:	adds    	r0, r7, #0
0x0022ac:	bl      	#0x8694
0x0022b0:	b       	#0x22c8
0x0022b2:	movs    	r1, #0
0x0022b4:	movs    	r2, #0
0x0022b6:	str     	r2, [sp, #8]
0x0022b8:	str     	r1, [sp]
0x0022ba:	str     	r1, [sp, #4]
0x0022bc:	movs    	r1, #0xa9
0x0022be:	adds    	r2, r4, #0
0x0022c0:	adds    	r3, r6, #0
0x0022c2:	adds    	r0, r7, #0
0x0022c4:	bl      	#0x8694
0x0022c8:	movs    	r1, #0
0x0022ca:	movs    	r2, #0
0x0022cc:	str     	r2, [sp, #8]
0x0022ce:	str     	r1, [sp]
0x0022d0:	str     	r1, [sp, #4]
0x0022d2:	movs    	r1, #0x14
0x0022d4:	movs    	r2, #6
0x0022d6:	adds    	r0, r7, #0
0x0022d8:	ldr     	r3, [sp, #0x10]
0x0022da:	bl      	#0x8694
0x0022de:	movs    	r1, #0
0x0022e0:	movs    	r2, #0
0x0022e2:	str     	r2, [sp, #8]
0x0022e4:	str     	r1, [sp]
0x0022e6:	str     	r1, [sp, #4]
0x0022e8:	adds    	r3, r6, #0
0x0022ea:	adds    	r2, r4, #0
0x0022ec:	movs    	r1, #0x8f
0x0022ee:	movs    	r0, #0xf1
0x0022f0:	lsls    	r0, r0, #9
0x0022f2:	bl      	#0x8694
0x0022f6:	cmp     	r5, #1
0x0022f8:	bne     	#0x2310
0x0022fa:	movs    	r1, #0
0x0022fc:	movs    	r2, #0
0x0022fe:	str     	r2, [sp, #8]
0x002300:	str     	r1, [sp]
0x002302:	str     	r1, [sp, #4]
0x002304:	movs    	r1, #0x8e
0x002306:	adds    	r2, r4, #0
0x002308:	adds    	r3, r6, #0
0x00230a:	adds    	r0, r7, #0
0x00230c:	bl      	#0x8694
0x002310:	movs    	r1, #0
0x002312:	str     	r1, [sp]
0x002314:	str     	r1, [sp, #4]
0x002316:	movs    	r2, #0
0x002318:	movs    	r1, #0x2c
0x00231a:	adds    	r3, r6, #0
0x00231c:	adds    	r0, r7, #0
0x00231e:	str     	r2, [sp, #8]
0x002320:	bl      	#0x8694
0x002324:	add     	sp, #0x14
0x002326:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00232c =====
0x00232c:	push    	{r4, r5, r6, r7, lr}
0x00232e:	sub     	sp, #0xc
0x002330:	movs    	r6, #0
0x002332:	movs    	r2, #0
0x002334:	movs    	r1, #0
0x002336:	str     	r2, [sp, #8]
0x002338:	adds    	r3, r6, #0
0x00233a:	adds    	r5, r0, #0
0x00233c:	adds    	r2, r0, #0
0x00233e:	str     	r1, [sp]
0x002340:	str     	r1, [sp, #4]
0x002342:	movs    	r1, #0x44
0x002344:	movs    	r0, #0xf1
0x002346:	movs    	r4, #0
0x002348:	lsls    	r0, r0, #9
0x00234a:	bl      	#0x8694
0x00234e:	movs    	r1, #0
0x002350:	str     	r1, [sp]
0x002352:	str     	r1, [sp, #4]
0x002354:	movs    	r2, #0
0x002356:	str     	r2, [sp, #8]
0x002358:	movs    	r1, #0x46
0x00235a:	adds    	r3, r6, #0
0x00235c:	movs    	r0, #0xf1
0x00235e:	lsls    	r0, r0, #9
0x002360:	ldr     	r2, [r5, #8]
0x002362:	bl      	#0x8694
0x002366:	movs    	r1, #0
0x002368:	lsls    	r7, r0, #0x18
0x00236a:	str     	r1, [sp]
0x00236c:	str     	r1, [sp, #4]
0x00236e:	movs    	r2, #0
0x002370:	movs    	r1, #0x13
0x002372:	asrs    	r7, r7, #0x18
0x002374:	movs    	r0, #0xf1
0x002376:	adds    	r3, r6, #0
0x002378:	lsls    	r0, r0, #9
0x00237a:	str     	r2, [sp, #8]
0x00237c:	bl      	#0x8694
0x002380:	adds    	r6, r0, #0
0x002382:	cmp     	r7, #0
0x002384:	ble     	#0x23be
0x002386:	movs    	r1, #0
0x002388:	movs    	r2, #0
0x00238a:	str     	r2, [sp, #8]
0x00238c:	str     	r1, [sp]
0x00238e:	str     	r1, [sp, #4]
0x002390:	movs    	r1, #0xff
0x002392:	adds    	r2, r5, #0
0x002394:	adds    	r1, #8
0x002396:	movs    	r3, #0
0x002398:	movs    	r0, #0xf1
0x00239a:	lsls    	r0, r0, #9
0x00239c:	bl      	#0x8694
0x0023a0:	movs    	r1, #0
0x0023a2:	adds    	r3, r0, #0
0x0023a4:	movs    	r2, #0
0x0023a6:	str     	r2, [sp, #8]
0x0023a8:	str     	r1, [sp]
0x0023aa:	str     	r1, [sp, #4]
0x0023ac:	movs    	r1, #0x36
0x0023ae:	adds    	r2, r6, #0
0x0023b0:	movs    	r0, #0xf1
0x0023b2:	lsls    	r0, r0, #9
0x0023b4:	bl      	#0x8694
0x0023b8:	adds    	r4, #1
0x0023ba:	cmp     	r4, r7
0x0023bc:	blt     	#0x2386
0x0023be:	movs    	r1, #0
0x0023c0:	str     	r1, [sp]
0x0023c2:	str     	r1, [sp, #4]
0x0023c4:	movs    	r2, #0
0x0023c6:	movs    	r4, #0
0x0023c8:	movs    	r7, #0xf1
0x0023ca:	lsls    	r7, r7, #9
0x0023cc:	adds    	r3, r4, #0
0x0023ce:	str     	r2, [sp, #8]
0x0023d0:	movs    	r1, #0x45
0x0023d2:	adds    	r0, r7, #0
0x0023d4:	ldr     	r2, [r5, #8]
0x0023d6:	bl      	#0x8694
0x0023da:	movs    	r1, #0
0x0023dc:	movs    	r2, #0
0x0023de:	str     	r2, [sp, #8]
0x0023e0:	str     	r1, [sp]
0x0023e2:	str     	r1, [sp, #4]
0x0023e4:	movs    	r1, #0x90
0x0023e6:	adds    	r2, r0, #0
0x0023e8:	adds    	r3, r4, #0
0x0023ea:	adds    	r0, r7, #0
0x0023ec:	bl      	#0x8694
0x0023f0:	adds    	r5, r0, #0
0x0023f2:	ldrh    	r0, [r0, #8]
0x0023f4:	subs    	r0, #1
0x0023f6:	lsls    	r1, r0, #0x10
0x0023f8:	asrs    	r1, r1, #0x10
0x0023fa:	strh    	r1, [r5, #8]
0x0023fc:	cmp     	r1, #0
0x0023fe:	bgt     	#0x242c
0x002400:	movs    	r1, #0
0x002402:	movs    	r2, #0
0x002404:	str     	r2, [sp, #8]
0x002406:	str     	r1, [sp]
0x002408:	str     	r1, [sp, #4]
0x00240a:	movs    	r1, #0x8f
0x00240c:	adds    	r2, r5, #0
0x00240e:	adds    	r3, r4, #0
0x002410:	adds    	r0, r7, #0
0x002412:	bl      	#0x8694
0x002416:	movs    	r1, #0
0x002418:	movs    	r2, #0
0x00241a:	str     	r2, [sp, #8]
0x00241c:	str     	r1, [sp]
0x00241e:	str     	r1, [sp, #4]
0x002420:	movs    	r1, #0x8e
0x002422:	adds    	r2, r5, #0
0x002424:	adds    	r3, r4, #0
0x002426:	adds    	r0, r7, #0
0x002428:	bl      	#0x8694
0x00242c:	movs    	r1, #0
0x00242e:	str     	r1, [sp]
0x002430:	str     	r1, [sp, #4]
0x002432:	movs    	r2, #0
0x002434:	movs    	r1, #0x2c
0x002436:	adds    	r3, r4, #0
0x002438:	adds    	r0, r7, #0
0x00243a:	str     	r2, [sp, #8]
0x00243c:	bl      	#0x8694
0x002440:	movs    	r1, #0
0x002442:	movs    	r2, #0
0x002444:	str     	r2, [sp, #8]
0x002446:	str     	r1, [sp]
0x002448:	str     	r1, [sp, #4]
0x00244a:	movs    	r1, #0xe1
0x00244c:	movs    	r2, #0x5b
0x00244e:	adds    	r3, r4, #0
0x002450:	movs    	r0, #0xf1
0x002452:	lsls    	r0, r0, #9
0x002454:	bl      	#0x8694
0x002458:	adds    	r1, r0, #0
0x00245a:	adds    	r0, r6, #0

; ===== candidate_002464 =====
0x002464:	push    	{r4, r5, r6, r7, lr}
0x002466:	adds    	r6, r0, #0
0x002468:	ldr     	r0, [pc, #0x88]
0x00246a:	sub     	sp, #0xc
0x00246c:	add     	r0, sb
0x00246e:	ldr     	r0, [r0, #0x2c]
0x002470:	cmp     	r0, #0
0x002472:	bne     	#0x24f0
0x002474:	movs    	r1, #0
0x002476:	movs    	r2, #0
0x002478:	movs    	r5, #0
0x00247a:	adds    	r3, r5, #0
0x00247c:	str     	r2, [sp, #8]
0x00247e:	str     	r1, [sp]
0x002480:	str     	r1, [sp, #4]
0x002482:	movs    	r1, #0x44
0x002484:	adds    	r2, r6, #0
0x002486:	movs    	r4, #0
0x002488:	movs    	r0, #0xf1
0x00248a:	lsls    	r0, r0, #9
0x00248c:	bl      	#0x8694
0x002490:	movs    	r1, #0
0x002492:	str     	r1, [sp]
0x002494:	str     	r1, [sp, #4]
0x002496:	movs    	r2, #0
0x002498:	str     	r2, [sp, #8]
0x00249a:	movs    	r1, #0x45
0x00249c:	adds    	r3, r5, #0
0x00249e:	movs    	r0, #0xf1
0x0024a0:	lsls    	r0, r0, #9
0x0024a2:	ldr     	r2, [r6, #8]
0x0024a4:	bl      	#0x8694
0x0024a8:	movs    	r2, #0
0x0024aa:	movs    	r1, #0
0x0024ac:	str     	r2, [sp, #8]
0x0024ae:	adds    	r5, r0, #0
0x0024b0:	adds    	r2, r0, #0
0x0024b2:	str     	r1, [sp]
0x0024b4:	str     	r1, [sp, #4]
0x0024b6:	movs    	r1, #0xa
0x0024b8:	movs    	r0, #0xf1
0x0024ba:	movs    	r3, #4
0x0024bc:	lsls    	r0, r0, #9
0x0024be:	bl      	#0x8694
0x0024c2:	adds    	r7, r0, #0
0x0024c4:	cmp     	r5, #0
0x0024c6:	ble     	#0x24ea
0x0024c8:	movs    	r1, #0
0x0024ca:	str     	r1, [sp]
0x0024cc:	str     	r1, [sp, #4]
0x0024ce:	movs    	r2, #0
0x0024d0:	str     	r2, [sp, #8]
0x0024d2:	movs    	r1, #0x45
0x0024d4:	movs    	r3, #0
0x0024d6:	movs    	r0, #0xf1
0x0024d8:	lsls    	r0, r0, #9
0x0024da:	ldr     	r2, [r6, #8]
0x0024dc:	bl      	#0x8694
0x0024e0:	lsls    	r1, r4, #2
0x0024e2:	adds    	r4, #1
0x0024e4:	cmp     	r4, r5
0x0024e6:	str     	r0, [r7, r1]
0x0024e8:	blt     	#0x24c8
0x0024ea:	adds    	r0, r7, #0
0x0024ec:	bl      	#0x563c
0x0024f0:	add     	sp, #0xc
0x0024f2:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0024f8 =====
0x0024f8:	push    	{r4, r5, r6, r7, lr}
0x0024fa:	sub     	sp, #0xc
0x0024fc:	movs    	r1, #0
0x0024fe:	movs    	r2, #0
0x002500:	str     	r2, [sp, #8]
0x002502:	str     	r1, [sp]
0x002504:	str     	r1, [sp, #4]
0x002506:	adds    	r5, r0, #0
0x002508:	movs    	r0, #0xf1
0x00250a:	movs    	r1, #0xe1
0x00250c:	movs    	r2, #6
0x00250e:	movs    	r3, #0
0x002510:	lsls    	r0, r0, #9
0x002512:	bl      	#0x8694
0x002516:	movs    	r2, #0
0x002518:	movs    	r1, #0
0x00251a:	movs    	r7, #4
0x00251c:	adds    	r3, r7, #0
0x00251e:	str     	r2, [sp, #8]
0x002520:	adds    	r2, r0, #0
0x002522:	str     	r1, [sp]
0x002524:	str     	r1, [sp, #4]
0x002526:	movs    	r1, #0x11
0x002528:	movs    	r0, #0xf1
0x00252a:	lsls    	r0, r0, #9
0x00252c:	bl      	#0x8694
0x002530:	movs    	r1, #0
0x002532:	movs    	r2, #0
0x002534:	str     	r2, [sp, #8]
0x002536:	str     	r1, [sp]
0x002538:	str     	r1, [sp, #4]
0x00253a:	adds    	r6, r0, #0
0x00253c:	movs    	r0, #0xf1
0x00253e:	movs    	r1, #0xe1
0x002540:	movs    	r2, #6
0x002542:	movs    	r4, #0
0x002544:	movs    	r3, #0
0x002546:	lsls    	r0, r0, #9
0x002548:	bl      	#0x8694
0x00254c:	ldr     	r1, [pc, #0x1a8]
0x00254e:	movs    	r2, #0
0x002550:	add     	r1, sb
0x002552:	str     	r0, [r1, #0x4c]
0x002554:	movs    	r1, #0
0x002556:	str     	r1, [sp]
0x002558:	str     	r1, [sp, #4]
0x00255a:	str     	r2, [sp, #8]
0x00255c:	adds    	r3, r7, #0
0x00255e:	adds    	r2, r6, #0
0x002560:	movs    	r1, #0xa
0x002562:	movs    	r0, #0xf1
0x002564:	lsls    	r0, r0, #9
0x002566:	bl      	#0x8694
0x00256a:	adds    	r7, r0, #0
0x00256c:	cmp     	r6, #0
0x00256e:	ble     	#0x2590
0x002570:	movs    	r1, #0
0x002572:	str     	r1, [sp]
0x002574:	str     	r1, [sp, #4]
0x002576:	movs    	r2, #0
0x002578:	movs    	r1, #0x13
0x00257a:	movs    	r3, #0
0x00257c:	movs    	r0, #0xf1
0x00257e:	lsls    	r0, r0, #9
0x002580:	str     	r2, [sp, #8]
0x002582:	bl      	#0x8694
0x002586:	lsls    	r1, r4, #2
0x002588:	adds    	r4, #1
0x00258a:	cmp     	r4, r6
0x00258c:	str     	r0, [r7, r1]
0x00258e:	blt     	#0x2570
0x002590:	movs    	r1, #0
0x002592:	movs    	r2, #0
0x002594:	str     	r2, [sp, #8]
0x002596:	str     	r1, [sp]
0x002598:	str     	r1, [sp, #4]
0x00259a:	movs    	r1, #0x14
0x00259c:	movs    	r2, #6
0x00259e:	adds    	r3, r7, #0
0x0025a0:	movs    	r0, #0xf1
0x0025a2:	lsls    	r0, r0, #9
0x0025a4:	bl      	#0x8694
0x0025a8:	movs    	r1, #0
0x0025aa:	movs    	r2, #0
0x0025ac:	movs    	r4, #0
0x0025ae:	adds    	r3, r4, #0
0x0025b0:	str     	r2, [sp, #8]
0x0025b2:	str     	r1, [sp]
0x0025b4:	str     	r1, [sp, #4]
0x0025b6:	movs    	r1, #0x44
0x0025b8:	adds    	r2, r5, #0
0x0025ba:	movs    	r0, #0xf1
0x0025bc:	lsls    	r0, r0, #9
0x0025be:	bl      	#0x8694
0x0025c2:	movs    	r1, #0
0x0025c4:	str     	r1, [sp]
0x0025c6:	str     	r1, [sp, #4]
0x0025c8:	movs    	r2, #0
0x0025ca:	str     	r2, [sp, #8]
0x0025cc:	movs    	r1, #0x45
0x0025ce:	adds    	r3, r4, #0
0x0025d0:	movs    	r0, #0xf1
0x0025d2:	lsls    	r0, r0, #9
0x0025d4:	ldr     	r2, [r5, #8]
0x0025d6:	bl      	#0x8694
0x0025da:	movs    	r2, #0
0x0025dc:	movs    	r1, #0
0x0025de:	str     	r2, [sp, #8]
0x0025e0:	adds    	r4, r0, #0
0x0025e2:	adds    	r2, r0, #0
0x0025e4:	str     	r1, [sp]
0x0025e6:	str     	r1, [sp, #4]
0x0025e8:	movs    	r1, #0xa
0x0025ea:	movs    	r0, #0xf1
0x0025ec:	movs    	r3, #4
0x0025ee:	lsls    	r0, r0, #9
0x0025f0:	bl      	#0x8694
0x0025f4:	movs    	r1, #0
0x0025f6:	movs    	r2, #0
0x0025f8:	str     	r2, [sp, #8]
0x0025fa:	str     	r1, [sp]
0x0025fc:	str     	r1, [sp, #4]
0x0025fe:	adds    	r3, r0, #0
0x002600:	movs    	r0, #0xf1
0x002602:	movs    	r1, #0x14
0x002604:	movs    	r2, #0xb1
0x002606:	lsls    	r0, r0, #9
0x002608:	bl      	#0x8694
0x00260c:	movs    	r6, #0
0x00260e:	cmp     	r4, #0
0x002610:	ble     	#0x264e
0x002612:	movs    	r1, #0
0x002614:	str     	r1, [sp]
0x002616:	str     	r1, [sp, #4]
0x002618:	movs    	r2, #0
0x00261a:	str     	r2, [sp, #8]
0x00261c:	movs    	r1, #0x45
0x00261e:	movs    	r3, #0
0x002620:	movs    	r0, #0xf1
0x002622:	lsls    	r0, r0, #9
0x002624:	ldr     	r2, [r5, #8]

; ===== candidate_0026fc =====
0x0026fc:	push    	{r4, r5, r6, r7, lr}
0x0026fe:	adds    	r5, r0, #0
0x002700:	ldr     	r0, [pc, #0x244]
0x002702:	movs    	r4, #0
0x002704:	sub     	sp, #0x24
0x002706:	add     	r0, pc
0x002708:	movs    	r1, #0
0x00270a:	movs    	r2, #0
0x00270c:	str     	r2, [sp, #8]
0x00270e:	str     	r1, [sp]
0x002710:	str     	r1, [sp, #4]
0x002712:	str     	r0, [sp, #0x1c]
0x002714:	movs    	r7, #0
0x002716:	adds    	r3, r7, #0
0x002718:	movs    	r0, #0xf1
0x00271a:	movs    	r1, #0xe1
0x00271c:	movs    	r2, #0x5b
0x00271e:	movs    	r6, #0
0x002720:	lsls    	r0, r0, #9
0x002722:	bl      	#0x8694
0x002726:	ldrb    	r0, [r0, #0x1a]
0x002728:	cmp     	r0, #1
0x00272a:	bne     	#0x272e
0x00272c:	movs    	r6, #1
0x00272e:	movs    	r1, #0
0x002730:	movs    	r2, #0
0x002732:	movs    	r7, #0
0x002734:	adds    	r3, r7, #0
0x002736:	str     	r2, [sp, #8]
0x002738:	str     	r1, [sp]
0x00273a:	str     	r1, [sp, #4]
0x00273c:	movs    	r1, #0x44
0x00273e:	adds    	r2, r5, #0
0x002740:	movs    	r0, #0xf1
0x002742:	lsls    	r0, r0, #9
0x002744:	bl      	#0x8694
0x002748:	movs    	r1, #0
0x00274a:	str     	r1, [sp]
0x00274c:	str     	r1, [sp, #4]
0x00274e:	movs    	r2, #0
0x002750:	str     	r2, [sp, #8]
0x002752:	movs    	r1, #0x45
0x002754:	adds    	r3, r7, #0
0x002756:	movs    	r0, #0xf1
0x002758:	lsls    	r0, r0, #9
0x00275a:	ldr     	r2, [r5, #8]
0x00275c:	bl      	#0x8694
0x002760:	movs    	r1, #0
0x002762:	str     	r1, [sp]
0x002764:	str     	r1, [sp, #4]
0x002766:	str     	r0, [sp, #0x14]
0x002768:	movs    	r2, #0
0x00276a:	str     	r2, [sp, #8]
0x00276c:	movs    	r0, #0xf1
0x00276e:	movs    	r1, #0x45
0x002770:	adds    	r3, r7, #0
0x002772:	lsls    	r0, r0, #9
0x002774:	ldr     	r2, [r5, #8]
0x002776:	bl      	#0x8694
0x00277a:	str     	r0, [sp, #0x20]
0x00277c:	movs    	r1, #0
0x00277e:	movs    	r2, #0
0x002780:	str     	r2, [sp, #8]
0x002782:	str     	r1, [sp]
0x002784:	str     	r1, [sp, #4]
0x002786:	movs    	r1, #0xe1
0x002788:	movs    	r2, #0x5b
0x00278a:	movs    	r0, #0xf1
0x00278c:	adds    	r3, r7, #0
0x00278e:	lsls    	r0, r0, #9
0x002790:	bl      	#0x8694
0x002794:	ldr     	r3, [r0, #4]
0x002796:	movs    	r1, #0
0x002798:	movs    	r2, #0
0x00279a:	str     	r2, [sp, #8]
0x00279c:	str     	r1, [sp]
0x00279e:	str     	r1, [sp, #4]
0x0027a0:	str     	r3, [sp, #0x10]
0x0027a2:	adds    	r3, r7, #0
0x0027a4:	movs    	r1, #0xe1
0x0027a6:	movs    	r2, #0x5b
0x0027a8:	movs    	r0, #0xf1
0x0027aa:	lsls    	r0, r0, #9
0x0027ac:	bl      	#0x8694
0x0027b0:	movs    	r2, #0
0x0027b2:	movs    	r1, #0
0x0027b4:	str     	r2, [sp, #8]
0x0027b6:	adds    	r2, r0, #0
0x0027b8:	str     	r1, [sp]
0x0027ba:	str     	r1, [sp, #4]
0x0027bc:	movs    	r1, #0xb1
0x0027be:	movs    	r0, #0xf1
0x0027c0:	lsls    	r0, r0, #9
0x0027c2:	ldr     	r3, [sp, #0x10]
0x0027c4:	bl      	#0x8694
0x0027c8:	movs    	r1, #0
0x0027ca:	movs    	r2, #0
0x0027cc:	str     	r1, [sp]
0x0027ce:	str     	r1, [sp, #4]
0x0027d0:	adds    	r3, r0, #0
0x0027d2:	movs    	r0, #0xf1
0x0027d4:	movs    	r1, #0x2d
0x0027d6:	str     	r2, [sp, #8]
0x0027d8:	ldr     	r2, [sp, #0x1c]
0x0027da:	lsls    	r0, r0, #9
0x0027dc:	bl      	#0x8694
0x0027e0:	adds    	r7, r0, #0
0x0027e2:	cmp     	r6, #0
0x0027e4:	bne     	#0x2804
0x0027e6:	movs    	r2, #0
0x0027e8:	movs    	r1, #0
0x0027ea:	ldr     	r3, [pc, #0x160]
0x0027ec:	str     	r1, [sp]
0x0027ee:	str     	r1, [sp, #4]
0x0027f0:	str     	r2, [sp, #8]
0x0027f2:	add     	r3, pc
0x0027f4:	adds    	r2, r7, #0
0x0027f6:	movs    	r1, #0x2d
0x0027f8:	movs    	r0, #0xf1
0x0027fa:	lsls    	r0, r0, #9
0x0027fc:	bl      	#0x8694
0x002800:	str     	r0, [sp, #0x1c]
0x002802:	b       	#0x2886
0x002804:	movs    	r1, #0
0x002806:	movs    	r2, #0
0x002808:	str     	r1, [sp]
0x00280a:	str     	r1, [sp, #4]
0x00280c:	movs    	r1, #0x3f
0x00280e:	str     	r2, [sp, #8]
0x002810:	movs    	r3, #0
0x002812:	movs    	r0, #0xf1
0x002814:	lsls    	r0, r0, #9
0x002816:	ldr     	r2, [sp, #0x14]
0x002818:	bl      	#0x8694
0x00281c:	movs    	r2, #0
0x00281e:	movs    	r1, #0
0x002820:	ldr     	r3, [pc, #0x12c]
0x002822:	str     	r1, [sp]
0x002824:	str     	r1, [sp, #4]
0x002826:	str     	r2, [sp, #8]
0x002828:	str     	r0, [sp, #0x18]

; ===== candidate_002958 =====
0x002958:	push    	{r4, r5, r6, r7, lr}
0x00295a:	sub     	sp, #0xc
0x00295c:	movs    	r5, #0
0x00295e:	movs    	r2, #0
0x002960:	movs    	r1, #0
0x002962:	str     	r2, [sp, #8]
0x002964:	adds    	r3, r5, #0
0x002966:	adds    	r6, r0, #0
0x002968:	adds    	r2, r0, #0
0x00296a:	str     	r1, [sp]
0x00296c:	str     	r1, [sp, #4]
0x00296e:	movs    	r1, #0x44
0x002970:	movs    	r0, #0xf1
0x002972:	movs    	r4, #0
0x002974:	lsls    	r0, r0, #9
0x002976:	bl      	#0x8694
0x00297a:	movs    	r1, #0
0x00297c:	str     	r1, [sp]
0x00297e:	str     	r1, [sp, #4]
0x002980:	movs    	r2, #0
0x002982:	str     	r2, [sp, #8]
0x002984:	movs    	r1, #0x45
0x002986:	adds    	r3, r5, #0
0x002988:	movs    	r0, #0xf1
0x00298a:	lsls    	r0, r0, #9
0x00298c:	ldr     	r2, [r6, #8]
0x00298e:	bl      	#0x8694
0x002992:	movs    	r2, #0
0x002994:	movs    	r1, #0
0x002996:	str     	r2, [sp, #8]
0x002998:	adds    	r5, r0, #0
0x00299a:	adds    	r2, r0, #0
0x00299c:	str     	r1, [sp]
0x00299e:	str     	r1, [sp, #4]
0x0029a0:	movs    	r1, #0xa
0x0029a2:	movs    	r0, #0xf1
0x0029a4:	movs    	r3, #4
0x0029a6:	lsls    	r0, r0, #9
0x0029a8:	bl      	#0x8694
0x0029ac:	adds    	r7, r0, #0
0x0029ae:	cmp     	r5, #0
0x0029b0:	ble     	#0x29d4
0x0029b2:	movs    	r1, #0
0x0029b4:	str     	r1, [sp]
0x0029b6:	str     	r1, [sp, #4]
0x0029b8:	movs    	r2, #0
0x0029ba:	str     	r2, [sp, #8]
0x0029bc:	movs    	r1, #0x45
0x0029be:	movs    	r3, #0
0x0029c0:	movs    	r0, #0xf1
0x0029c2:	lsls    	r0, r0, #9
0x0029c4:	ldr     	r2, [r6, #8]
0x0029c6:	bl      	#0x8694
0x0029ca:	lsls    	r1, r4, #2
0x0029cc:	adds    	r4, #1
0x0029ce:	cmp     	r4, r5
0x0029d0:	str     	r0, [r7, r1]
0x0029d2:	blt     	#0x29b2
0x0029d4:	adds    	r1, r7, #0
0x0029d6:	movs    	r0, #0
0x0029d8:	bl      	#0x8b0c
0x0029dc:	add     	sp, #0xc
0x0029de:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0029e0 =====
0x0029e0:	push    	{r4, r5, r6, r7, lr}
0x0029e2:	sub     	sp, #0x14
0x0029e4:	movs    	r7, #0
0x0029e6:	movs    	r2, #0
0x0029e8:	movs    	r1, #0
0x0029ea:	str     	r2, [sp, #8]
0x0029ec:	adds    	r3, r7, #0
0x0029ee:	adds    	r6, r0, #0
0x0029f0:	adds    	r2, r0, #0
0x0029f2:	str     	r1, [sp]
0x0029f4:	str     	r1, [sp, #4]
0x0029f6:	movs    	r1, #0x44
0x0029f8:	movs    	r0, #0xf1
0x0029fa:	movs    	r4, #0
0x0029fc:	lsls    	r0, r0, #9
0x0029fe:	bl      	#0x8694
0x002a02:	movs    	r1, #0
0x002a04:	str     	r1, [sp]
0x002a06:	str     	r1, [sp, #4]
0x002a08:	movs    	r2, #0
0x002a0a:	str     	r2, [sp, #8]
0x002a0c:	movs    	r1, #0x45
0x002a0e:	adds    	r3, r7, #0
0x002a10:	movs    	r0, #0xf1
0x002a12:	lsls    	r0, r0, #9
0x002a14:	ldr     	r2, [r6, #8]
0x002a16:	bl      	#0x8694
0x002a1a:	movs    	r1, #0
0x002a1c:	movs    	r2, #0
0x002a1e:	str     	r2, [sp, #8]
0x002a20:	str     	r1, [sp]
0x002a22:	str     	r1, [sp, #4]
0x002a24:	adds    	r3, r0, #0
0x002a26:	movs    	r0, #0xf1
0x002a28:	movs    	r1, #0x14
0x002a2a:	movs    	r2, #0x69
0x002a2c:	lsls    	r0, r0, #9
0x002a2e:	bl      	#0x8694
0x002a32:	movs    	r1, #0
0x002a34:	str     	r1, [sp]
0x002a36:	str     	r1, [sp, #4]
0x002a38:	movs    	r2, #0
0x002a3a:	str     	r2, [sp, #8]
0x002a3c:	movs    	r1, #0x45
0x002a3e:	adds    	r3, r7, #0
0x002a40:	movs    	r0, #0xf1
0x002a42:	lsls    	r0, r0, #9
0x002a44:	ldr     	r2, [r6, #8]
0x002a46:	bl      	#0x8694
0x002a4a:	str     	r0, [sp, #0x10]
0x002a4c:	cmp     	r0, #0
0x002a4e:	ble     	#0x2aba
0x002a50:	movs    	r1, #0
0x002a52:	str     	r1, [sp]
0x002a54:	str     	r1, [sp, #4]
0x002a56:	movs    	r2, #0
0x002a58:	str     	r2, [sp, #8]
0x002a5a:	movs    	r1, #0x45
0x002a5c:	adds    	r3, r7, #0
0x002a5e:	movs    	r0, #0xf1
0x002a60:	lsls    	r0, r0, #9
0x002a62:	ldr     	r2, [r6, #8]
0x002a64:	bl      	#0x8694
0x002a68:	movs    	r2, #0
0x002a6a:	movs    	r1, #0
0x002a6c:	str     	r2, [sp, #8]
0x002a6e:	adds    	r3, r7, #0
0x002a70:	adds    	r2, r0, #0
0x002a72:	str     	r1, [sp]
0x002a74:	str     	r1, [sp, #4]
0x002a76:	movs    	r1, #0x90
0x002a78:	movs    	r0, #0xf1
0x002a7a:	lsls    	r0, r0, #9
0x002a7c:	bl      	#0x8694
0x002a80:	movs    	r2, #0
0x002a82:	movs    	r1, #0
0x002a84:	str     	r2, [sp, #8]
0x002a86:	adds    	r5, r0, #0
0x002a88:	adds    	r3, r7, #0
0x002a8a:	adds    	r2, r0, #0
0x002a8c:	str     	r1, [sp]
0x002a8e:	str     	r1, [sp, #4]
0x002a90:	movs    	r1, #0x8f
0x002a92:	movs    	r0, #0xf1
0x002a94:	lsls    	r0, r0, #9
0x002a96:	bl      	#0x8694
0x002a9a:	movs    	r1, #0
0x002a9c:	movs    	r2, #0
0x002a9e:	str     	r2, [sp, #8]
0x002aa0:	str     	r1, [sp]
0x002aa2:	str     	r1, [sp, #4]
0x002aa4:	adds    	r3, r7, #0
0x002aa6:	adds    	r2, r5, #0
0x002aa8:	movs    	r1, #0x8e
0x002aaa:	movs    	r0, #0xf1
0x002aac:	lsls    	r0, r0, #9
0x002aae:	bl      	#0x8694
0x002ab2:	ldr     	r0, [sp, #0x10]
0x002ab4:	adds    	r4, #1
0x002ab6:	cmp     	r4, r0
0x002ab8:	blt     	#0x2a50
0x002aba:	ldr     	r0, [pc, #0x50]
0x002abc:	movs    	r1, #0
0x002abe:	add     	r0, sb
0x002ac0:	str     	r7, [r0, #0x50]
0x002ac2:	str     	r1, [sp]
0x002ac4:	str     	r1, [sp, #4]
0x002ac6:	movs    	r2, #0
0x002ac8:	movs    	r1, #0x2c
0x002aca:	movs    	r0, #0xf1
0x002acc:	adds    	r3, r7, #0
0x002ace:	lsls    	r0, r0, #9
0x002ad0:	str     	r2, [sp, #8]
0x002ad2:	bl      	#0x8694
0x002ad6:	movs    	r1, #0
0x002ad8:	str     	r1, [sp]
0x002ada:	str     	r1, [sp, #4]
0x002adc:	movs    	r2, #0
0x002ade:	movs    	r1, #0xe6
0x002ae0:	adds    	r3, r7, #0
0x002ae2:	movs    	r0, #0xf1
0x002ae4:	lsls    	r0, r0, #9
0x002ae6:	str     	r2, [sp, #8]
0x002ae8:	bl      	#0x8694
0x002aec:	movs    	r2, #0
0x002aee:	movs    	r1, #0
0x002af0:	str     	r2, [sp, #8]
0x002af2:	ldr     	r2, [pc, #0x1c]
0x002af4:	str     	r1, [sp]
0x002af6:	str     	r1, [sp, #4]
0x002af8:	adds    	r3, r7, #0
0x002afa:	add     	r2, pc
0x002afc:	movs    	r1, #0x33
0x002afe:	movs    	r0, #0xf1
0x002b00:	lsls    	r0, r0, #9
0x002b02:	bl      	#0x8694
0x002b06:	add     	sp, #0x14
0x002b08:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002b14 =====
0x002b14:	push    	{r4, r5, r6, r7, lr}
0x002b16:	sub     	sp, #0xc
0x002b18:	movs    	r1, #0
0x002b1a:	adds    	r4, r0, #0
0x002b1c:	movs    	r2, #0
0x002b1e:	str     	r2, [sp, #8]
0x002b20:	adds    	r3, r0, #0
0x002b22:	str     	r1, [sp]
0x002b24:	str     	r1, [sp, #4]
0x002b26:	movs    	r1, #0x14
0x002b28:	movs    	r0, #0xf1
0x002b2a:	movs    	r2, #0x5b
0x002b2c:	lsls    	r0, r0, #9
0x002b2e:	bl      	#0x8694
0x002b32:	movs    	r1, #0
0x002b34:	movs    	r2, #0
0x002b36:	str     	r2, [sp, #8]
0x002b38:	str     	r1, [sp]
0x002b3a:	str     	r1, [sp, #4]
0x002b3c:	movs    	r1, #0xe1
0x002b3e:	movs    	r2, #0xad
0x002b40:	movs    	r3, #0
0x002b42:	movs    	r0, #0xf1
0x002b44:	lsls    	r0, r0, #9
0x002b46:	bl      	#0x8694
0x002b4a:	cmp     	r0, #0xe
0x002b4c:	bhs     	#0x2b58
0x002b4e:	adr     	r3, #0xc
0x002b50:	adds    	r3, r3, r0
0x002b52:	ldrh    	r3, [r3, r0]
0x002b54:	lsls    	r3, r3, #1
0x002b56:	add     	pc, r3
0x002b58:	add     	sp, #0xc
0x002b5a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003234 =====
0x003234:	push    	{r4, r5, r6, r7, lr}
0x003236:	sub     	sp, #0x14
0x003238:	movs    	r4, #0
0x00323a:	movs    	r2, #0
0x00323c:	movs    	r1, #0
0x00323e:	str     	r2, [sp, #8]
0x003240:	adds    	r3, r4, #0
0x003242:	adds    	r6, r0, #0
0x003244:	adds    	r2, r0, #0
0x003246:	str     	r1, [sp]
0x003248:	str     	r1, [sp, #4]
0x00324a:	movs    	r1, #0x44
0x00324c:	movs    	r0, #0xf1
0x00324e:	lsls    	r0, r0, #9
0x003250:	bl      	#0x8694
0x003254:	movs    	r1, #0
0x003256:	str     	r1, [sp]
0x003258:	str     	r1, [sp, #4]
0x00325a:	movs    	r2, #0
0x00325c:	str     	r2, [sp, #8]
0x00325e:	movs    	r1, #0x45
0x003260:	adds    	r3, r4, #0
0x003262:	movs    	r0, #0xf1
0x003264:	lsls    	r0, r0, #9
0x003266:	ldr     	r2, [r6, #8]
0x003268:	bl      	#0x8694
0x00326c:	movs    	r1, #0
0x00326e:	str     	r1, [sp]
0x003270:	str     	r1, [sp, #4]
0x003272:	adds    	r5, r0, #0
0x003274:	movs    	r2, #0
0x003276:	str     	r2, [sp, #8]
0x003278:	movs    	r0, #0xf1
0x00327a:	adds    	r3, r4, #0
0x00327c:	movs    	r1, #0x46
0x00327e:	lsls    	r0, r0, #9
0x003280:	ldr     	r2, [r6, #8]
0x003282:	bl      	#0x8694
0x003286:	lsls    	r0, r0, #0x18
0x003288:	movs    	r1, #0
0x00328a:	asrs    	r0, r0, #0x18
0x00328c:	str     	r0, [sp, #0x10]
0x00328e:	str     	r1, [sp]
0x003290:	str     	r1, [sp, #4]
0x003292:	movs    	r2, #0
0x003294:	str     	r2, [sp, #8]
0x003296:	movs    	r1, #0x46
0x003298:	movs    	r0, #0xf1
0x00329a:	adds    	r3, r4, #0
0x00329c:	lsls    	r0, r0, #9
0x00329e:	ldr     	r2, [r6, #8]
0x0032a0:	bl      	#0x8694
0x0032a4:	lsls    	r0, r0, #0x18
0x0032a6:	movs    	r1, #0
0x0032a8:	asrs    	r0, r0, #0x18
0x0032aa:	movs    	r2, #0
0x0032ac:	str     	r2, [sp, #8]
0x0032ae:	str     	r0, [sp, #0xc]
0x0032b0:	str     	r1, [sp]
0x0032b2:	str     	r1, [sp, #4]
0x0032b4:	adds    	r3, r4, #0
0x0032b6:	adds    	r2, r5, #0
0x0032b8:	movs    	r1, #0x90
0x0032ba:	movs    	r0, #0xf1
0x0032bc:	lsls    	r0, r0, #9
0x0032be:	bl      	#0x8694
0x0032c2:	adds    	r5, r0, #0
0x0032c4:	ldr     	r0, [sp, #0x10]
0x0032c6:	movs    	r1, #0
0x0032c8:	strb    	r0, [r5, #0x18]
0x0032ca:	str     	r1, [sp]
0x0032cc:	str     	r1, [sp, #4]
0x0032ce:	movs    	r2, #0
0x0032d0:	movs    	r1, #0x6b
0x0032d2:	movs    	r0, #0xf1
0x0032d4:	adds    	r3, r4, #0
0x0032d6:	lsls    	r0, r0, #9
0x0032d8:	str     	r2, [sp, #8]
0x0032da:	bl      	#0x8694
0x0032de:	movs    	r1, #0
0x0032e0:	str     	r1, [sp]
0x0032e2:	str     	r1, [sp, #4]
0x0032e4:	movs    	r2, #0
0x0032e6:	movs    	r1, #0x6a
0x0032e8:	adds    	r3, r4, #0
0x0032ea:	movs    	r0, #0xf1
0x0032ec:	lsls    	r0, r0, #9
0x0032ee:	str     	r2, [sp, #8]
0x0032f0:	bl      	#0x8694
0x0032f4:	ldr     	r0, [sp, #0x10]
0x0032f6:	cmp     	r0, #1
0x0032f8:	bne     	#0x3388
0x0032fa:	ldr     	r0, [r5, #4]
0x0032fc:	bl      	#0x7a98
0x003300:	cmp     	r0, #0
0x003302:	beq     	#0x3388
0x003304:	movs    	r2, #0
0x003306:	movs    	r1, #0
0x003308:	str     	r2, [sp, #8]
0x00330a:	movs    	r2, #0xff
0x00330c:	str     	r1, [sp]
0x00330e:	str     	r1, [sp, #4]
0x003310:	movs    	r7, #0xf1
0x003312:	lsls    	r7, r7, #9
0x003314:	movs    	r1, #0xe1
0x003316:	adds    	r2, #0x22
0x003318:	movs    	r3, #0
0x00331a:	adds    	r0, r7, #0
0x00331c:	bl      	#0x8694
0x003320:	movs    	r1, #0
0x003322:	movs    	r2, #0
0x003324:	str     	r2, [sp, #8]
0x003326:	str     	r1, [sp]
0x003328:	str     	r1, [sp, #4]
0x00332a:	movs    	r1, #0x11
0x00332c:	adds    	r2, r0, #0
0x00332e:	movs    	r3, #4
0x003330:	adds    	r0, r7, #0
0x003332:	bl      	#0x8694
0x003336:	adds    	r6, r0, #0
0x003338:	cmp     	r0, #0
0x00333a:	ble     	#0x3388
0x00333c:	movs    	r2, #0
0x00333e:	movs    	r1, #0
0x003340:	str     	r2, [sp, #8]
0x003342:	movs    	r2, #0xff
0x003344:	str     	r1, [sp]
0x003346:	str     	r1, [sp, #4]
0x003348:	movs    	r1, #0xe1
0x00334a:	adds    	r2, #0x22
0x00334c:	movs    	r3, #0
0x00334e:	movs    	r0, #0xf1
0x003350:	lsls    	r0, r0, #9
0x003352:	bl      	#0x8694
0x003356:	lsls    	r1, r4, #2
0x003358:	ldr     	r0, [r0, r1]
0x00335a:	ldr     	r7, [r0]
0x00335c:	ldr     	r0, [r5, #4]
0x00335e:	cmp     	r7, r0
0x003360:	beq     	#0x3382
0x003362:	movs    	r1, #0

; ===== candidate_00343c =====
0x00343c:	push    	{r4, r5, r6, r7, lr}
0x00343e:	sub     	sp, #0x14
0x003440:	movs    	r5, #0
0x003442:	movs    	r2, #0
0x003444:	movs    	r1, #0
0x003446:	str     	r2, [sp, #8]
0x003448:	adds    	r3, r5, #0
0x00344a:	adds    	r6, r0, #0
0x00344c:	adds    	r2, r0, #0
0x00344e:	str     	r1, [sp]
0x003450:	str     	r1, [sp, #4]
0x003452:	movs    	r1, #0x44
0x003454:	movs    	r0, #0xf1
0x003456:	lsls    	r0, r0, #9
0x003458:	bl      	#0x8694
0x00345c:	movs    	r1, #0
0x00345e:	str     	r1, [sp]
0x003460:	str     	r1, [sp, #4]
0x003462:	movs    	r2, #0
0x003464:	str     	r2, [sp, #8]
0x003466:	movs    	r1, #0x45
0x003468:	adds    	r3, r5, #0
0x00346a:	movs    	r0, #0xf1
0x00346c:	lsls    	r0, r0, #9
0x00346e:	ldr     	r2, [r6, #8]
0x003470:	bl      	#0x8694
0x003474:	movs    	r1, #0
0x003476:	str     	r1, [sp]
0x003478:	str     	r1, [sp, #4]
0x00347a:	adds    	r4, r0, #0
0x00347c:	movs    	r2, #0
0x00347e:	str     	r2, [sp, #8]
0x003480:	movs    	r0, #0xf1
0x003482:	adds    	r3, r5, #0
0x003484:	movs    	r1, #0x45
0x003486:	lsls    	r0, r0, #9
0x003488:	ldr     	r2, [r6, #8]
0x00348a:	bl      	#0x8694
0x00348e:	movs    	r1, #0
0x003490:	adds    	r7, r0, #0
0x003492:	movs    	r2, #0
0x003494:	str     	r2, [sp, #8]
0x003496:	str     	r1, [sp]
0x003498:	str     	r1, [sp, #4]
0x00349a:	adds    	r3, r5, #0
0x00349c:	adds    	r2, r4, #0
0x00349e:	movs    	r1, #0x90
0x0034a0:	movs    	r0, #0xf1
0x0034a2:	lsls    	r0, r0, #9
0x0034a4:	bl      	#0x8694
0x0034a8:	movs    	r1, #0
0x0034aa:	adds    	r4, r0, #0
0x0034ac:	movs    	r2, #0
0x0034ae:	str     	r2, [sp, #8]
0x0034b0:	str     	r1, [sp]
0x0034b2:	str     	r1, [sp, #4]
0x0034b4:	adds    	r3, r5, #0
0x0034b6:	adds    	r2, r7, #0
0x0034b8:	movs    	r1, #0x3f
0x0034ba:	movs    	r0, #0xf1
0x0034bc:	lsls    	r0, r0, #9
0x0034be:	bl      	#0x8694
0x0034c2:	adds    	r6, r0, #0
0x0034c4:	movs    	r2, #0
0x0034c6:	movs    	r1, #0
0x0034c8:	str     	r2, [sp, #8]
0x0034ca:	movs    	r2, #4
0x0034cc:	str     	r1, [sp]
0x0034ce:	str     	r1, [sp, #4]
0x0034d0:	adds    	r3, r5, #0
0x0034d2:	movs    	r1, #2
0x0034d4:	ldr     	r0, [pc, #0x1a4]
0x0034d6:	bl      	#0x8694
0x0034da:	movs    	r2, #0
0x0034dc:	movs    	r1, #0
0x0034de:	str     	r2, [sp, #8]
0x0034e0:	movs    	r2, #5
0x0034e2:	str     	r1, [sp]
0x0034e4:	str     	r1, [sp, #4]
0x0034e6:	str     	r0, [sp, #0xc]
0x0034e8:	adds    	r3, r5, #0
0x0034ea:	movs    	r1, #2
0x0034ec:	ldr     	r0, [pc, #0x18c]
0x0034ee:	bl      	#0x8694
0x0034f2:	lsls    	r1, r0, #2
0x0034f4:	ldr     	r0, [sp, #0xc]
0x0034f6:	movs    	r2, #0
0x0034f8:	ldr     	r0, [r0, r1]
0x0034fa:	movs    	r1, #0
0x0034fc:	ldr     	r3, [r0]
0x0034fe:	str     	r2, [sp, #8]
0x003500:	ldr     	r2, [pc, #0x17c]
0x003502:	str     	r1, [sp]
0x003504:	str     	r1, [sp, #4]
0x003506:	add     	r2, pc
0x003508:	movs    	r1, #0x2d
0x00350a:	movs    	r0, #0xf1
0x00350c:	lsls    	r0, r0, #9
0x00350e:	bl      	#0x8694
0x003512:	movs    	r2, #0
0x003514:	movs    	r1, #0
0x003516:	ldr     	r3, [pc, #0x16c]
0x003518:	str     	r1, [sp]
0x00351a:	str     	r1, [sp, #4]
0x00351c:	str     	r2, [sp, #8]
0x00351e:	add     	r3, pc
0x003520:	adds    	r2, r0, #0
0x003522:	movs    	r0, #0xf1
0x003524:	movs    	r1, #0x2d
0x003526:	lsls    	r0, r0, #9
0x003528:	bl      	#0x8694
0x00352c:	movs    	r2, #0
0x00352e:	str     	r2, [sp, #8]
0x003530:	movs    	r1, #0
0x003532:	adds    	r2, r0, #0
0x003534:	movs    	r0, #0xf1
0x003536:	str     	r1, [sp]
0x003538:	str     	r1, [sp, #4]
0x00353a:	movs    	r1, #0x2d
0x00353c:	lsls    	r0, r0, #9
0x00353e:	adds    	r3, r6, #0
0x003540:	bl      	#0x8694
0x003544:	movs    	r2, #0
0x003546:	movs    	r1, #0
0x003548:	ldr     	r3, [pc, #0x13c]
0x00354a:	str     	r1, [sp]
0x00354c:	str     	r1, [sp, #4]
0x00354e:	str     	r2, [sp, #8]
0x003550:	add     	r3, pc
0x003552:	adds    	r2, r0, #0
0x003554:	movs    	r0, #0xf1
0x003556:	movs    	r1, #0x2d
0x003558:	lsls    	r0, r0, #9
0x00355a:	bl      	#0x8694
0x00355e:	movs    	r1, #0
0x003560:	movs    	r2, #0
0x003562:	str     	r2, [sp, #8]
0x003564:	str     	r1, [sp]
0x003566:	str     	r1, [sp, #4]
0x003568:	str     	r0, [sp, #0x10]
0x00356a:	adds    	r3, r5, #0

; ===== candidate_00368c =====
0x00368c:	push    	{r4, r5, r6, r7, lr}
0x00368e:	adds    	r7, r0, #0
0x003690:	adds    	r7, #0x30
0x003692:	movs    	r3, #9
0x003694:	ldrsb   	r6, [r7, r3]
0x003696:	movs    	r3, #0xa
0x003698:	adds    	r4, r0, #0
0x00369a:	ldrsb   	r0, [r7, r3]
0x00369c:	sub     	sp, #0x24
0x00369e:	movs    	r3, #0xb
0x0036a0:	str     	r0, [sp, #0x20]
0x0036a2:	ldrsb   	r0, [r7, r3]
0x0036a4:	adds    	r5, r1, #0
0x0036a6:	str     	r0, [sp, #0x1c]
0x0036a8:	adds    	r0, r1, #0
0x0036aa:	bl      	#0x5900
0x0036ae:	adds    	r0, r5, #0
0x0036b0:	bl      	#0x58a0
0x0036b4:	movs    	r1, #0
0x0036b6:	movs    	r2, #0
0x0036b8:	str     	r2, [sp, #8]
0x0036ba:	str     	r1, [sp]
0x0036bc:	str     	r1, [sp, #4]
0x0036be:	str     	r0, [sp, #0x18]
0x0036c0:	movs    	r0, #0xf1
0x0036c2:	movs    	r1, #0xe1
0x0036c4:	movs    	r2, #0x20
0x0036c6:	movs    	r3, #0
0x0036c8:	lsls    	r0, r0, #9
0x0036ca:	bl      	#0x8694
0x0036ce:	cmp     	r0, #0
0x0036d0:	bne     	#0x37b6
0x0036d2:	ldr     	r0, [sp, #0x1c]
0x0036d4:	cmp     	r0, #1
0x0036d6:	bne     	#0x36da
0x0036d8:	movs    	r6, #0
0x0036da:	ldr     	r0, [sp, #0x20]
0x0036dc:	ldr     	r1, [sp, #0x18]
0x0036de:	cmp     	r0, r1
0x0036e0:	beq     	#0x36e4
0x0036e2:	movs    	r6, #0
0x0036e4:	movs    	r1, #0
0x0036e6:	movs    	r2, #0
0x0036e8:	str     	r2, [sp, #8]
0x0036ea:	str     	r1, [sp]
0x0036ec:	str     	r1, [sp, #4]
0x0036ee:	movs    	r1, #0xb1
0x0036f0:	adds    	r2, r4, #0
0x0036f2:	movs    	r0, #0xf1
0x0036f4:	lsls    	r0, r0, #9
0x0036f6:	ldr     	r3, [r4, #4]
0x0036f8:	bl      	#0x8694
0x0036fc:	movs    	r2, #0
0x0036fe:	adds    	r3, r0, #0
0x003700:	movs    	r1, #0
0x003702:	str     	r2, [sp, #8]
0x003704:	ldr     	r2, [pc, #0x380]
0x003706:	str     	r1, [sp]
0x003708:	str     	r1, [sp, #4]
0x00370a:	add     	r2, pc
0x00370c:	movs    	r1, #0x2d
0x00370e:	movs    	r0, #0xf1
0x003710:	lsls    	r0, r0, #9
0x003712:	bl      	#0x8694
0x003716:	movs    	r2, #0
0x003718:	movs    	r1, #0
0x00371a:	ldr     	r3, [pc, #0x370]
0x00371c:	str     	r1, [sp]
0x00371e:	str     	r1, [sp, #4]
0x003720:	str     	r2, [sp, #8]
0x003722:	add     	r3, pc
0x003724:	adds    	r2, r0, #0
0x003726:	movs    	r0, #0xf1
0x003728:	movs    	r1, #0x2d
0x00372a:	lsls    	r0, r0, #9
0x00372c:	bl      	#0x8694
0x003730:	mov     	ip, r0
0x003732:	ldrb    	r0, [r7, #9]
0x003734:	cmp     	r0, #0
0x003736:	bne     	#0x3756
0x003738:	movs    	r2, #0
0x00373a:	movs    	r1, #0
0x00373c:	ldr     	r3, [pc, #0x350]
0x00373e:	str     	r1, [sp]
0x003740:	str     	r1, [sp, #4]
0x003742:	str     	r2, [sp, #8]
0x003744:	add     	r3, pc
0x003746:	movs    	r1, #0x2d
0x003748:	movs    	r0, #0xf1
0x00374a:	lsls    	r0, r0, #9
0x00374c:	mov     	r2, ip
0x00374e:	bl      	#0x8694
0x003752:	adds    	r4, r0, #0
0x003754:	b       	#0x3828
0x003756:	movs    	r2, #0
0x003758:	movs    	r1, #0
0x00375a:	ldr     	r3, [pc, #0x330]
0x00375c:	str     	r1, [sp]
0x00375e:	str     	r1, [sp, #4]
0x003760:	str     	r2, [sp, #8]
0x003762:	add     	r3, pc
0x003764:	movs    	r1, #0x2d
0x003766:	movs    	r0, #0xf1
0x003768:	lsls    	r0, r0, #9
0x00376a:	mov     	r2, ip
0x00376c:	bl      	#0x8694
0x003770:	movs    	r1, #0
0x003772:	str     	r1, [sp]
0x003774:	movs    	r2, #0
0x003776:	str     	r1, [sp, #4]
0x003778:	str     	r0, [sp, #0x14]
0x00377a:	movs    	r0, #0xf1
0x00377c:	movs    	r1, #0xed
0x00377e:	str     	r2, [sp, #8]
0x003780:	movs    	r3, #0
0x003782:	lsls    	r0, r0, #9
0x003784:	ldr     	r2, [sp, #0x20]
0x003786:	bl      	#0x8694
0x00378a:	movs    	r1, #0
0x00378c:	movs    	r2, #0
0x00378e:	str     	r1, [sp]
0x003790:	str     	r1, [sp, #4]
0x003792:	adds    	r3, r0, #0
0x003794:	movs    	r0, #0xf1
0x003796:	movs    	r1, #0x2d
0x003798:	str     	r2, [sp, #8]
0x00379a:	ldr     	r2, [sp, #0x14]
0x00379c:	lsls    	r0, r0, #9
0x00379e:	bl      	#0x8694
0x0037a2:	movs    	r2, #0
0x0037a4:	movs    	r1, #0
0x0037a6:	ldr     	r3, [pc, #0x2ec]
0x0037a8:	str     	r1, [sp]
0x0037aa:	str     	r1, [sp, #4]
0x0037ac:	str     	r2, [sp, #8]
0x0037ae:	add     	r3, pc
0x0037b0:	adds    	r2, r0, #0
0x0037b2:	movs    	r1, #0x2d
0x0037b4:	b       	#0x37b8
0x0037b6:	b       	#0x3a4c
0x0037b8:	movs    	r0, #0xf1

; ===== candidate_003abc =====
0x003abc:	push    	{r4, r5, r6, r7, lr}
0x003abe:	sub     	sp, #0xc
0x003ac0:	movs    	r1, #0
0x003ac2:	movs    	r2, #0
0x003ac4:	str     	r2, [sp, #8]
0x003ac6:	str     	r1, [sp]
0x003ac8:	str     	r1, [sp, #4]
0x003aca:	movs    	r5, #0xf1
0x003acc:	movs    	r7, #0
0x003ace:	adds    	r3, r7, #0
0x003ad0:	lsls    	r5, r5, #9
0x003ad2:	movs    	r1, #0x44
0x003ad4:	adds    	r2, r0, #0
0x003ad6:	adds    	r6, r0, #0
0x003ad8:	adds    	r0, r5, #0
0x003ada:	bl      	#0x8694
0x003ade:	movs    	r2, #0
0x003ae0:	movs    	r1, #0
0x003ae2:	movs    	r0, #0
0x003ae4:	bl      	#0x8644
0x003ae8:	movs    	r1, #0
0x003aea:	movs    	r2, #0
0x003aec:	str     	r2, [sp, #8]
0x003aee:	str     	r1, [sp]
0x003af0:	str     	r1, [sp, #4]
0x003af2:	movs    	r1, #0xa8
0x003af4:	adds    	r2, r6, #0
0x003af6:	adds    	r3, r7, #0
0x003af8:	adds    	r0, r5, #0
0x003afa:	bl      	#0x8694
0x003afe:	movs    	r1, #0
0x003b00:	str     	r1, [sp]
0x003b02:	str     	r1, [sp, #4]
0x003b04:	movs    	r2, #0
0x003b06:	str     	r2, [sp, #8]
0x003b08:	movs    	r1, #0x45
0x003b0a:	adds    	r4, r0, #0
0x003b0c:	adds    	r3, r7, #0
0x003b0e:	adds    	r0, r5, #0
0x003b10:	ldr     	r2, [r6, #8]
0x003b12:	bl      	#0x8694
0x003b16:	movs    	r2, #0
0x003b18:	movs    	r1, #0
0x003b1a:	str     	r2, [sp, #8]
0x003b1c:	adds    	r2, r0, #0
0x003b1e:	str     	r1, [sp]
0x003b20:	str     	r1, [sp, #4]
0x003b22:	movs    	r1, #0x90
0x003b24:	adds    	r0, r5, #0
0x003b26:	adds    	r3, r7, #0
0x003b28:	bl      	#0x8694
0x003b2c:	adds    	r7, r0, #0
0x003b2e:	ldrh    	r0, [r0, #8]
0x003b30:	subs    	r0, #1
0x003b32:	lsls    	r1, r0, #0x10
0x003b34:	asrs    	r1, r1, #0x10
0x003b36:	strh    	r1, [r7, #8]
0x003b38:	cmp     	r1, #0
0x003b3a:	bgt     	#0x3b68
0x003b3c:	movs    	r1, #0
0x003b3e:	movs    	r2, #0
0x003b40:	str     	r2, [sp, #8]
0x003b42:	str     	r1, [sp]
0x003b44:	str     	r1, [sp, #4]
0x003b46:	movs    	r1, #0x8f
0x003b48:	adds    	r2, r7, #0
0x003b4a:	movs    	r3, #0
0x003b4c:	adds    	r0, r5, #0
0x003b4e:	bl      	#0x8694
0x003b52:	movs    	r1, #0
0x003b54:	movs    	r2, #0
0x003b56:	str     	r2, [sp, #8]
0x003b58:	str     	r1, [sp]
0x003b5a:	str     	r1, [sp, #4]
0x003b5c:	movs    	r1, #0x8e
0x003b5e:	adds    	r2, r7, #0
0x003b60:	movs    	r3, #0
0x003b62:	adds    	r0, r5, #0
0x003b64:	bl      	#0x8694
0x003b68:	movs    	r1, #0
0x003b6a:	str     	r1, [sp]
0x003b6c:	str     	r1, [sp, #4]
0x003b6e:	movs    	r2, #0
0x003b70:	str     	r2, [sp, #8]
0x003b72:	movs    	r1, #0x90
0x003b74:	movs    	r3, #0
0x003b76:	movs    	r0, #0xf1
0x003b78:	lsls    	r0, r0, #9
0x003b7a:	ldr     	r2, [r4]
0x003b7c:	bl      	#0x8694
0x003b80:	adds    	r5, r0, #0
0x003b82:	bl      	#0x5844
0x003b86:	adds    	r7, r0, #0
0x003b88:	adds    	r3, r0, #1
0x003b8a:	beq     	#0x3ba6
0x003b8c:	movs    	r1, #0
0x003b8e:	movs    	r2, #0
0x003b90:	str     	r2, [sp, #8]
0x003b92:	str     	r1, [sp]
0x003b94:	str     	r1, [sp, #4]
0x003b96:	movs    	r1, #0xff
0x003b98:	adds    	r2, r5, #0
0x003b9a:	adds    	r3, r4, #0
0x003b9c:	adds    	r1, #0x35
0x003b9e:	movs    	r0, #0xf1
0x003ba0:	lsls    	r0, r0, #9
0x003ba2:	bl      	#0x8694
0x003ba6:	movs    	r1, #0
0x003ba8:	movs    	r2, #0
0x003baa:	str     	r2, [sp, #8]
0x003bac:	str     	r1, [sp]
0x003bae:	str     	r1, [sp, #4]
0x003bb0:	movs    	r1, #0x8f
0x003bb2:	adds    	r2, r5, #0
0x003bb4:	movs    	r3, #0
0x003bb6:	movs    	r0, #0xf1
0x003bb8:	lsls    	r0, r0, #9
0x003bba:	bl      	#0x8694
0x003bbe:	movs    	r1, #0
0x003bc0:	movs    	r2, #0
0x003bc2:	str     	r2, [sp, #8]
0x003bc4:	str     	r1, [sp]
0x003bc6:	str     	r1, [sp, #4]
0x003bc8:	movs    	r1, #0x8e
0x003bca:	adds    	r2, r5, #0
0x003bcc:	movs    	r3, #0
0x003bce:	movs    	r0, #0xf1
0x003bd0:	lsls    	r0, r0, #9
0x003bd2:	bl      	#0x8694
0x003bd6:	adds    	r3, r7, #1
0x003bd8:	beq     	#0x3c26
0x003bda:	movs    	r1, #0
0x003bdc:	str     	r1, [sp]
0x003bde:	str     	r1, [sp, #4]
0x003be0:	movs    	r2, #0
0x003be2:	movs    	r5, #0
0x003be4:	adds    	r3, r5, #0
0x003be6:	str     	r2, [sp, #8]
0x003be8:	movs    	r1, #0x73
0x003bea:	movs    	r0, #0xf1
0x003bec:	lsls    	r0, r0, #9

; ===== candidate_003cb0 =====
0x003cb0:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x003cb2:	sub     	sp, #0x84
0x003cb4:	add     	r7, sp, #0xa8
0x003cb6:	ldm     	r7, {r4, r5, r7}
0x003cb8:	movs    	r1, #0
0x003cba:	movs    	r2, #0
0x003cbc:	str     	r2, [sp, #8]
0x003cbe:	str     	r1, [sp]
0x003cc0:	str     	r1, [sp, #4]
0x003cc2:	movs    	r6, #0
0x003cc4:	adds    	r3, r6, #0
0x003cc6:	movs    	r1, #0xe1
0x003cc8:	movs    	r2, #0x2d
0x003cca:	movs    	r0, #0xf1
0x003ccc:	lsls    	r0, r0, #9
0x003cce:	bl      	#0x8694
0x003cd2:	movs    	r1, #0
0x003cd4:	movs    	r2, #0
0x003cd6:	str     	r2, [sp, #8]
0x003cd8:	str     	r1, [sp]
0x003cda:	str     	r1, [sp, #4]
0x003cdc:	movs    	r1, #0xe1
0x003cde:	movs    	r2, #0x2e
0x003ce0:	adds    	r3, r6, #0
0x003ce2:	movs    	r0, #0xf1
0x003ce4:	lsls    	r0, r0, #9
0x003ce6:	bl      	#0x8694
0x003cea:	ldr     	r0, [sp, #0x90]
0x003cec:	adds    	r1, r4, #0
0x003cee:	str     	r0, [sp, #0x4c]
0x003cf0:	ldr     	r0, [pc, #0x3cc]
0x003cf2:	add     	r0, sb
0x003cf4:	ldr     	r0, [r0, #4]
0x003cf6:	str     	r0, [sp, #0x44]
0x003cf8:	blx     	#0x20
0x003cfc:	str     	r0, [sp, #0x3c]
0x003cfe:	ldr     	r0, [sp, #0x44]
0x003d00:	adds    	r1, r5, #0
0x003d02:	blx     	#0x20
0x003d06:	movs    	r1, #0
0x003d08:	str     	r0, [sp, #0x38]
0x003d0a:	str     	r1, [sp]
0x003d0c:	str     	r1, [sp, #4]
0x003d0e:	ldr     	r1, [sp, #0x38]
0x003d10:	ldr     	r0, [sp, #0x3c]
0x003d12:	movs    	r2, #0
0x003d14:	muls    	r0, r1, r0
0x003d16:	str     	r2, [sp, #8]
0x003d18:	adds    	r3, r0, #0
0x003d1a:	movs    	r0, #0xf1
0x003d1c:	movs    	r2, #0xaa
0x003d1e:	movs    	r1, #0x14
0x003d20:	lsls    	r0, r0, #9
0x003d22:	bl      	#0x8694
0x003d26:	movs    	r1, #0
0x003d28:	movs    	r2, #0
0x003d2a:	str     	r2, [sp, #8]
0x003d2c:	str     	r1, [sp]
0x003d2e:	str     	r1, [sp, #4]
0x003d30:	movs    	r1, #0xe1
0x003d32:	movs    	r2, #0xaa
0x003d34:	adds    	r3, r6, #0
0x003d36:	movs    	r0, #0xf1
0x003d38:	lsls    	r0, r0, #9
0x003d3a:	bl      	#0x8694
0x003d3e:	movs    	r1, #0
0x003d40:	movs    	r2, #0
0x003d42:	str     	r2, [sp, #8]
0x003d44:	str     	r1, [sp]
0x003d46:	str     	r1, [sp, #4]
0x003d48:	adds    	r3, r0, #0
0x003d4a:	movs    	r0, #0xf1
0x003d4c:	movs    	r1, #0x14
0x003d4e:	movs    	r2, #0xa9
0x003d50:	lsls    	r0, r0, #9
0x003d52:	bl      	#0x8694
0x003d56:	movs    	r1, #0
0x003d58:	movs    	r2, #0
0x003d5a:	str     	r2, [sp, #8]
0x003d5c:	str     	r1, [sp]
0x003d5e:	str     	r1, [sp, #4]
0x003d60:	movs    	r1, #0xe1
0x003d62:	movs    	r2, #0xa7
0x003d64:	adds    	r3, r6, #0
0x003d66:	movs    	r0, #0xf1
0x003d68:	lsls    	r0, r0, #9
0x003d6a:	bl      	#0x8694
0x003d6e:	movs    	r1, #0
0x003d70:	adds    	r5, r0, #0
0x003d72:	movs    	r2, #0
0x003d74:	str     	r2, [sp, #8]
0x003d76:	str     	r1, [sp]
0x003d78:	str     	r1, [sp, #4]
0x003d7a:	movs    	r1, #0xe1
0x003d7c:	movs    	r2, #0xaa
0x003d7e:	movs    	r0, #0xf1
0x003d80:	adds    	r3, r6, #0
0x003d82:	lsls    	r0, r0, #9
0x003d84:	bl      	#0x8694
0x003d88:	adds    	r1, r5, #0
0x003d8a:	blx     	#0x20
0x003d8e:	movs    	r1, #0
0x003d90:	movs    	r2, #0
0x003d92:	str     	r2, [sp, #8]
0x003d94:	str     	r1, [sp]
0x003d96:	str     	r1, [sp, #4]
0x003d98:	adds    	r3, r0, #0
0x003d9a:	movs    	r0, #0xf1
0x003d9c:	movs    	r1, #0x14
0x003d9e:	movs    	r2, #0xa8
0x003da0:	lsls    	r0, r0, #9
0x003da2:	bl      	#0x8694
0x003da6:	movs    	r1, #0
0x003da8:	movs    	r2, #0
0x003daa:	str     	r2, [sp, #8]
0x003dac:	str     	r1, [sp]
0x003dae:	str     	r1, [sp, #4]
0x003db0:	movs    	r1, #0xe1
0x003db2:	movs    	r2, #0xa7
0x003db4:	adds    	r3, r6, #0
0x003db6:	movs    	r0, #0xf1
0x003db8:	lsls    	r0, r0, #9
0x003dba:	bl      	#0x8694
0x003dbe:	movs    	r1, #0
0x003dc0:	adds    	r5, r0, #0
0x003dc2:	movs    	r2, #0
0x003dc4:	str     	r2, [sp, #8]
0x003dc6:	str     	r1, [sp]
0x003dc8:	str     	r1, [sp, #4]
0x003dca:	movs    	r1, #0xe1
0x003dcc:	movs    	r2, #0xaa
0x003dce:	movs    	r0, #0xf1
0x003dd0:	adds    	r3, r6, #0
0x003dd2:	lsls    	r0, r0, #9
0x003dd4:	bl      	#0x8694
0x003dd8:	adds    	r1, r5, #0
0x003dda:	blx     	#0x20
0x003dde:	cmp     	r1, #0
0x003de0:	beq     	#0x3e12
0x003de2:	movs    	r1, #0
0x003de4:	movs    	r2, #0

; ===== candidate_0042e4 =====
0x0042e4:	push    	{r4, r5, r6, r7, lr}
0x0042e6:	ldr     	r4, [pc, #0xf8]
0x0042e8:	sub     	sp, #0x2c
0x0042ea:	add     	r4, pc
0x0042ec:	movs    	r1, #0
0x0042ee:	movs    	r2, #0
0x0042f0:	str     	r2, [sp, #8]
0x0042f2:	str     	r1, [sp]
0x0042f4:	str     	r1, [sp, #4]
0x0042f6:	movs    	r6, #0
0x0042f8:	adds    	r3, r6, #0
0x0042fa:	movs    	r1, #0xe1
0x0042fc:	movs    	r2, #0x28
0x0042fe:	movs    	r0, #0xf1
0x004300:	lsls    	r0, r0, #9
0x004302:	bl      	#0x8694
0x004306:	movs    	r1, #0
0x004308:	adds    	r5, r0, #0
0x00430a:	movs    	r2, #0
0x00430c:	str     	r2, [sp, #8]
0x00430e:	str     	r1, [sp]
0x004310:	str     	r1, [sp, #4]
0x004312:	movs    	r1, #0xe1
0x004314:	movs    	r2, #0x29
0x004316:	movs    	r0, #0xf1
0x004318:	adds    	r3, r6, #0
0x00431a:	lsls    	r0, r0, #9
0x00431c:	bl      	#0x8694
0x004320:	adds    	r3, r0, #0
0x004322:	add     	r2, sp, #0x28
0x004324:	add     	r1, sp, #0x24
0x004326:	str     	r1, [sp, #4]
0x004328:	str     	r2, [sp, #8]
0x00432a:	adds    	r2, r4, #0
0x00432c:	movs    	r1, #0x2a
0x00432e:	movs    	r0, #0xf1
0x004330:	lsls    	r0, r0, #9
0x004332:	str     	r5, [sp]
0x004334:	bl      	#0x8694
0x004338:	movs    	r1, #0
0x00433a:	ldr     	r4, [sp, #0x24]
0x00433c:	str     	r1, [sp, #4]
0x00433e:	str     	r1, [sp]
0x004340:	ldr     	r1, [pc, #0xa0]
0x004342:	movs    	r2, #0
0x004344:	str     	r2, [sp, #8]
0x004346:	add     	r1, sb
0x004348:	ldr     	r2, [r1, #0x64]
0x00434a:	movs    	r1, #0x11
0x00434c:	movs    	r3, #4
0x00434e:	movs    	r0, #0xf1
0x004350:	adds    	r4, #0x28
0x004352:	lsls    	r0, r0, #9
0x004354:	bl      	#0x8694
0x004358:	ldr     	r1, [sp, #0x28]
0x00435a:	movs    	r2, #0
0x00435c:	muls    	r0, r1, r0
0x00435e:	movs    	r1, #0
0x004360:	adds    	r5, r0, #0
0x004362:	adds    	r5, #0xa
0x004364:	str     	r1, [sp]
0x004366:	str     	r1, [sp, #4]
0x004368:	movs    	r1, #0x1c
0x00436a:	adds    	r3, r6, #0
0x00436c:	movs    	r0, #0xf1
0x00436e:	lsls    	r0, r0, #9
0x004370:	str     	r2, [sp, #8]
0x004372:	bl      	#0x8694
0x004376:	subs    	r0, r0, r4
0x004378:	movs    	r1, #0
0x00437a:	str     	r1, [sp]
0x00437c:	str     	r1, [sp, #4]
0x00437e:	asrs    	r7, r0, #1
0x004380:	movs    	r2, #0
0x004382:	movs    	r0, #0xf1
0x004384:	movs    	r1, #0x1d
0x004386:	adds    	r3, r6, #0
0x004388:	lsls    	r0, r0, #9
0x00438a:	str     	r2, [sp, #8]
0x00438c:	bl      	#0x8694
0x004390:	ldr     	r1, [pc, #0x50]
0x004392:	subs    	r0, r0, r5
0x004394:	add     	r1, sb
0x004396:	ldr     	r1, [r1, #0x64]
0x004398:	asrs    	r0, r0, #1
0x00439a:	str     	r0, [sp, #0x14]
0x00439c:	ldr     	r0, [pc, #0x44]
0x00439e:	str     	r1, [sp, #0xc]
0x0043a0:	add     	r0, sb
0x0043a2:	adds    	r0, #0x14
0x0043a4:	str     	r0, [sp, #0x20]
0x0043a6:	movs    	r1, #0
0x0043a8:	movs    	r2, #0
0x0043aa:	str     	r1, [sp]
0x0043ac:	str     	r1, [sp, #4]
0x0043ae:	movs    	r1, #0x2b
0x0043b0:	str     	r2, [sp, #8]
0x0043b2:	movs    	r0, #0xf1
0x0043b4:	adds    	r3, r6, #0
0x0043b6:	lsls    	r0, r0, #9
0x0043b8:	add     	r2, sp, #0xc
0x0043ba:	str     	r7, [sp, #0x10]
0x0043bc:	str     	r4, [sp, #0x18]
0x0043be:	str     	r5, [sp, #0x1c]
0x0043c0:	bl      	#0x8694
0x0043c4:	movs    	r1, #0
0x0043c6:	movs    	r2, #0
0x0043c8:	str     	r2, [sp, #8]
0x0043ca:	str     	r1, [sp]
0x0043cc:	str     	r1, [sp, #4]
0x0043ce:	movs    	r1, #0x24
0x0043d0:	movs    	r2, #1
0x0043d2:	movs    	r3, #1
0x0043d4:	movs    	r0, #0xf1
0x0043d6:	lsls    	r0, r0, #9
0x0043d8:	bl      	#0x8694
0x0043dc:	add     	sp, #0x2c
0x0043de:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0043e8 =====
0x0043e8:	push    	{r4, r5, r6, r7, lr}
0x0043ea:	sub     	sp, #0x4c
0x0043ec:	movs    	r1, #0x1e
0x0043ee:	str     	r1, [sp, #0x30]
0x0043f0:	movs    	r7, #0xa
0x0043f2:	movs    	r0, #0x32
0x0043f4:	str     	r0, [sp, #0x2c]
0x0043f6:	movs    	r1, #0
0x0043f8:	movs    	r6, #0
0x0043fa:	movs    	r4, #0x19
0x0043fc:	movs    	r2, #0
0x0043fe:	movs    	r0, #0
0x004400:	str     	r7, [sp, #0x38]
0x004402:	bl      	#0x8644
0x004406:	ldr     	r7, [pc, #0x3dc]
0x004408:	add     	r7, pc
0x00440a:	movs    	r1, #0
0x00440c:	str     	r1, [sp]
0x00440e:	str     	r1, [sp, #4]
0x004410:	movs    	r2, #0
0x004412:	movs    	r5, #0
0x004414:	adds    	r3, r5, #0
0x004416:	movs    	r1, #0x1c
0x004418:	movs    	r0, #0xf1
0x00441a:	lsls    	r0, r0, #9
0x00441c:	str     	r2, [sp, #8]
0x00441e:	bl      	#0x8694
0x004422:	movs    	r2, #0
0x004424:	str     	r0, [sp]
0x004426:	movs    	r0, #0xf1
0x004428:	adds    	r3, r5, #0
0x00442a:	movs    	r1, #0x32
0x00442c:	lsls    	r0, r0, #9
0x00442e:	str     	r2, [sp, #8]
0x004430:	str     	r4, [sp, #4]
0x004432:	bl      	#0x8694
0x004436:	add     	r2, sp, #0x40
0x004438:	add     	r1, sp, #0x44
0x00443a:	movs    	r0, #0
0x00443c:	str     	r0, [sp]
0x00443e:	str     	r1, [sp, #4]
0x004440:	str     	r2, [sp, #8]
0x004442:	adds    	r3, r5, #0
0x004444:	adds    	r2, r7, #0
0x004446:	movs    	r1, #0x2a
0x004448:	movs    	r0, #0xf1
0x00444a:	lsls    	r0, r0, #9
0x00444c:	bl      	#0x8694
0x004450:	movs    	r1, #0
0x004452:	str     	r1, [sp]
0x004454:	str     	r1, [sp, #4]
0x004456:	movs    	r2, #0
0x004458:	movs    	r1, #0x1c
0x00445a:	adds    	r3, r5, #0
0x00445c:	movs    	r0, #0xf1
0x00445e:	lsls    	r0, r0, #9
0x004460:	str     	r2, [sp, #8]
0x004462:	str     	r7, [sp, #0xc]
0x004464:	bl      	#0x8694
0x004468:	ldr     	r1, [sp, #0x44]
0x00446a:	str     	r5, [sp, #0x24]
0x00446c:	subs    	r0, r0, r1
0x00446e:	lsrs    	r1, r0, #0x1f
0x004470:	adds    	r0, r1, r0
0x004472:	asrs    	r0, r0, #1
0x004474:	str     	r0, [sp, #0x10]
0x004476:	movs    	r0, #5
0x004478:	str     	r0, [sp, #0x14]
0x00447a:	movs    	r0, #0xff
0x00447c:	str     	r0, [sp, #0x20]
0x00447e:	movs    	r1, #0
0x004480:	movs    	r2, #0
0x004482:	str     	r1, [sp]
0x004484:	str     	r1, [sp, #4]
0x004486:	str     	r0, [sp, #0x18]
0x004488:	str     	r0, [sp, #0x1c]
0x00448a:	str     	r5, [sp, #0x28]
0x00448c:	str     	r2, [sp, #8]
0x00448e:	movs    	r0, #0xf1
0x004490:	movs    	r1, #0x56
0x004492:	adds    	r3, r5, #0
0x004494:	lsls    	r0, r0, #9
0x004496:	add     	r2, sp, #0xc
0x004498:	bl      	#0x8694
0x00449c:	movs    	r1, #0
0x00449e:	str     	r1, [sp]
0x0044a0:	str     	r1, [sp, #4]
0x0044a2:	movs    	r2, #0
0x0044a4:	movs    	r1, #0x1d
0x0044a6:	adds    	r3, r5, #0
0x0044a8:	movs    	r0, #0xf1
0x0044aa:	lsls    	r0, r0, #9
0x0044ac:	str     	r2, [sp, #8]
0x0044ae:	bl      	#0x8694
0x0044b2:	subs    	r0, #0x69
0x0044b4:	movs    	r1, #0
0x0044b6:	str     	r1, [sp]
0x0044b8:	str     	r1, [sp, #4]
0x0044ba:	str     	r0, [sp, #0x34]
0x0044bc:	movs    	r2, #0
0x0044be:	movs    	r0, #0xf1
0x0044c0:	movs    	r1, #0x1c
0x0044c2:	adds    	r3, r5, #0
0x0044c4:	lsls    	r0, r0, #9
0x0044c6:	str     	r2, [sp, #8]
0x0044c8:	bl      	#0x8694
0x0044cc:	ldr     	r1, [sp, #0x2c]
0x0044ce:	movs    	r2, #0
0x0044d0:	str     	r0, [sp]
0x0044d2:	str     	r1, [sp, #4]
0x0044d4:	movs    	r1, #0x31
0x0044d6:	movs    	r0, #0xf1
0x0044d8:	adds    	r3, r4, #0
0x0044da:	lsls    	r0, r0, #9
0x0044dc:	str     	r2, [sp, #8]
0x0044de:	bl      	#0x8694
0x0044e2:	movs    	r1, #0
0x0044e4:	str     	r1, [sp]
0x0044e6:	str     	r1, [sp, #4]
0x0044e8:	movs    	r2, #0
0x0044ea:	movs    	r1, #0x1c
0x0044ec:	adds    	r3, r5, #0
0x0044ee:	movs    	r0, #0xf1
0x0044f0:	lsls    	r0, r0, #9
0x0044f2:	str     	r2, [sp, #8]
0x0044f4:	bl      	#0x8694
0x0044f8:	ldr     	r1, [sp, #0x34]
0x0044fa:	movs    	r2, #0
0x0044fc:	str     	r0, [sp]
0x0044fe:	str     	r1, [sp, #4]
0x004500:	movs    	r1, #0x2e
0x004502:	movs    	r0, #0xf1
0x004504:	movs    	r3, #0x4b
0x004506:	lsls    	r0, r0, #9
0x004508:	str     	r2, [sp, #8]
0x00450a:	bl      	#0x8694
0x00450e:	movs    	r1, #0
0x004510:	str     	r1, [sp]
0x004512:	str     	r1, [sp, #4]
0x004514:	movs    	r2, #0
0x004516:	movs    	r1, #0x1c

; ===== candidate_0049d0 =====
0x0049d0:	push    	{r4, r5, r6, r7, lr}
0x0049d2:	sub     	sp, #0x5c
0x0049d4:	movs    	r1, #0
0x0049d6:	str     	r1, [sp]
0x0049d8:	str     	r1, [sp, #4]
0x0049da:	movs    	r5, #0
0x0049dc:	movs    	r2, #0
0x0049de:	adds    	r3, r5, #0
0x0049e0:	movs    	r1, #0x1c
0x0049e2:	movs    	r0, #0xf1
0x0049e4:	lsls    	r0, r0, #9
0x0049e6:	str     	r2, [sp, #8]
0x0049e8:	bl      	#0x8694
0x0049ec:	adds    	r4, r0, #0
0x0049ee:	movs    	r0, #0
0x0049f0:	str     	r0, [sp, #0x48]
0x0049f2:	movs    	r1, #0
0x0049f4:	str     	r1, [sp, #4]
0x0049f6:	str     	r0, [sp]
0x0049f8:	movs    	r7, #0x1a
0x0049fa:	movs    	r2, #0
0x0049fc:	movs    	r0, #0xf1
0x0049fe:	movs    	r1, #0xba
0x004a00:	adds    	r3, r5, #0
0x004a02:	movs    	r6, #0xa5
0x004a04:	lsls    	r0, r0, #9
0x004a06:	str     	r2, [sp, #8]
0x004a08:	str     	r7, [sp, #0x50]
0x004a0a:	bl      	#0x8694
0x004a0e:	movs    	r1, #0
0x004a10:	str     	r1, [sp]
0x004a12:	str     	r1, [sp, #4]
0x004a14:	movs    	r1, #0xff
0x004a16:	movs    	r2, #0
0x004a18:	adds    	r3, r5, #0
0x004a1a:	adds    	r1, #0x26
0x004a1c:	movs    	r0, #0xf1
0x004a1e:	lsls    	r0, r0, #9
0x004a20:	str     	r2, [sp, #8]
0x004a22:	bl      	#0x8694
0x004a26:	movs    	r2, #0
0x004a28:	movs    	r1, #0
0x004a2a:	str     	r2, [sp, #8]
0x004a2c:	movs    	r2, #0xff
0x004a2e:	str     	r1, [sp]
0x004a30:	str     	r1, [sp, #4]
0x004a32:	adds    	r3, r5, #0
0x004a34:	adds    	r2, #0x2b
0x004a36:	movs    	r1, #0xe1
0x004a38:	movs    	r0, #0xf1
0x004a3a:	lsls    	r0, r0, #9
0x004a3c:	bl      	#0x8694
0x004a40:	cmp     	r0, #0
0x004a42:	beq     	#0x4a54
0x004a44:	ldr     	r1, [pc, #0x3dc]
0x004a46:	movs    	r3, #2
0x004a48:	add     	r1, sb
0x004a4a:	ldrsb   	r0, [r1, r3]
0x004a4c:	cmp     	r0, #6
0x004a4e:	bge     	#0x4a54
0x004a50:	adds    	r0, #1
0x004a52:	strb    	r0, [r1, #2]
0x004a54:	movs    	r1, #0
0x004a56:	movs    	r2, #0
0x004a58:	str     	r2, [sp, #8]
0x004a5a:	str     	r1, [sp]
0x004a5c:	str     	r1, [sp, #4]
0x004a5e:	movs    	r5, #0xf1
0x004a60:	lsls    	r5, r5, #9
0x004a62:	movs    	r1, #0xe1
0x004a64:	movs    	r2, #0xed
0x004a66:	movs    	r3, #0
0x004a68:	adds    	r0, r5, #0
0x004a6a:	bl      	#0x8694
0x004a6e:	cmp     	r0, #0
0x004a70:	bgt     	#0x4a9e
0x004a72:	ldr     	r1, [pc, #0x3b0]
0x004a74:	movs    	r3, #2
0x004a76:	add     	r1, sb
0x004a78:	ldrsb   	r0, [r1, r3]
0x004a7a:	cmp     	r0, #6
0x004a7c:	bge     	#0x4a86
0x004a7e:	adds    	r0, #1
0x004a80:	strb    	r0, [r1, #2]
0x004a82:	add     	sp, #0x5c
0x004a84:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0053f0 =====
0x0053f0:	push    	{r4, r5, r6, r7, lr}
0x0053f2:	ldr     	r4, [pc, #0x50]
0x0053f4:	movs    	r6, #0xf1
0x0053f6:	add     	r4, sb
0x0053f8:	ldr     	r7, [r4, #0x64]
0x0053fa:	lsls    	r6, r6, #9
0x0053fc:	movs    	r5, #0
0x0053fe:	cmp     	r7, #0
0x005400:	sub     	sp, #0xc
0x005402:	beq     	#0x541a
0x005404:	movs    	r1, #0
0x005406:	movs    	r2, #0
0x005408:	str     	r2, [sp, #8]
0x00540a:	str     	r1, [sp]
0x00540c:	str     	r1, [sp, #4]
0x00540e:	movs    	r1, #0x12
0x005410:	adds    	r2, r7, #0
0x005412:	adds    	r3, r5, #0
0x005414:	adds    	r0, r6, #0
0x005416:	bl      	#0x8694
0x00541a:	str     	r5, [r4, #0x64]
0x00541c:	movs    	r1, #0
0x00541e:	str     	r1, [sp]
0x005420:	str     	r1, [sp, #4]
0x005422:	movs    	r2, #0
0x005424:	movs    	r1, #0xe6
0x005426:	adds    	r3, r5, #0
0x005428:	adds    	r0, r6, #0
0x00542a:	str     	r2, [sp, #8]
0x00542c:	bl      	#0x8694
0x005430:	ldr     	r0, [r4, #0x60]
0x005432:	cmp     	r0, #0xb
0x005434:	bne     	#0x543e
0x005436:	movs    	r0, #0xa
0x005438:	str     	r0, [r4, #0x60]
0x00543a:	add     	sp, #0xc
0x00543c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_005448 =====
0x005448:	push    	{r4, r5, r6, r7, lr}
0x00544a:	ldr     	r4, [pc, #0x1ec]
0x00544c:	movs    	r6, #0
0x00544e:	add     	r4, sb
0x005450:	ldr     	r0, [r4, #0xc]
0x005452:	sub     	sp, #0xc
0x005454:	adds    	r0, #0x63
0x005456:	cmp     	r0, #0
0x005458:	bne     	#0x553e
0x00545a:	movs    	r1, #0
0x00545c:	movs    	r2, #0
0x00545e:	str     	r2, [sp, #8]
0x005460:	str     	r1, [sp]
0x005462:	str     	r1, [sp, #4]
0x005464:	movs    	r1, #0xe1
0x005466:	movs    	r2, #6
0x005468:	adds    	r3, r6, #0
0x00546a:	movs    	r0, #0xf1
0x00546c:	lsls    	r0, r0, #9
0x00546e:	bl      	#0x8694
0x005472:	movs    	r2, #0
0x005474:	movs    	r1, #0
0x005476:	str     	r2, [sp, #8]
0x005478:	adds    	r2, r0, #0
0x00547a:	str     	r1, [sp]
0x00547c:	str     	r1, [sp, #4]
0x00547e:	movs    	r1, #0x11
0x005480:	movs    	r0, #0xf1
0x005482:	movs    	r3, #4
0x005484:	lsls    	r0, r0, #9
0x005486:	bl      	#0x8694
0x00548a:	adds    	r7, r0, #0
0x00548c:	movs    	r4, #0
0x00548e:	cmp     	r0, #0
0x005490:	ble     	#0x54e4
0x005492:	movs    	r1, #0
0x005494:	movs    	r2, #0
0x005496:	str     	r2, [sp, #8]
0x005498:	str     	r1, [sp]
0x00549a:	str     	r1, [sp, #4]
0x00549c:	movs    	r1, #0xe1
0x00549e:	movs    	r2, #6
0x0054a0:	adds    	r3, r6, #0
0x0054a2:	movs    	r0, #0xf1
0x0054a4:	lsls    	r0, r0, #9
0x0054a6:	bl      	#0x8694
0x0054aa:	lsls    	r1, r4, #2
0x0054ac:	ldr     	r5, [r0, r1]
0x0054ae:	movs    	r1, #0
0x0054b0:	movs    	r2, #0
0x0054b2:	str     	r2, [sp, #8]
0x0054b4:	str     	r1, [sp]
0x0054b6:	str     	r1, [sp, #4]
0x0054b8:	adds    	r3, r6, #0
0x0054ba:	adds    	r2, r5, #0
0x0054bc:	movs    	r1, #0xf2
0x0054be:	movs    	r0, #0xf1
0x0054c0:	lsls    	r0, r0, #9
0x0054c2:	bl      	#0x8694
0x0054c6:	movs    	r1, #0
0x0054c8:	movs    	r2, #0
0x0054ca:	str     	r2, [sp, #8]
0x0054cc:	str     	r1, [sp]
0x0054ce:	str     	r1, [sp, #4]
0x0054d0:	adds    	r3, r6, #0
0x0054d2:	adds    	r2, r5, #0
0x0054d4:	movs    	r1, #9
0x0054d6:	movs    	r0, #0xf1
0x0054d8:	lsls    	r0, r0, #9
0x0054da:	bl      	#0x8694
0x0054de:	adds    	r4, #1
0x0054e0:	cmp     	r4, r7
0x0054e2:	blt     	#0x5492
0x0054e4:	movs    	r1, #0
0x0054e6:	movs    	r2, #0
0x0054e8:	str     	r2, [sp, #8]
0x0054ea:	str     	r1, [sp]
0x0054ec:	str     	r1, [sp, #4]
0x0054ee:	movs    	r1, #0xe1
0x0054f0:	movs    	r2, #6
0x0054f2:	adds    	r3, r6, #0
0x0054f4:	movs    	r0, #0xf1
0x0054f6:	lsls    	r0, r0, #9
0x0054f8:	bl      	#0x8694
0x0054fc:	movs    	r2, #0
0x0054fe:	movs    	r1, #0
0x005500:	str     	r2, [sp, #8]
0x005502:	adds    	r3, r6, #0
0x005504:	adds    	r2, r0, #0
0x005506:	str     	r1, [sp]
0x005508:	str     	r1, [sp, #4]
0x00550a:	movs    	r1, #9
0x00550c:	movs    	r0, #0xf1
0x00550e:	lsls    	r0, r0, #9
0x005510:	bl      	#0x8694
0x005514:	movs    	r1, #0
0x005516:	movs    	r2, #0
0x005518:	str     	r2, [sp, #8]
0x00551a:	str     	r1, [sp]
0x00551c:	str     	r1, [sp, #4]
0x00551e:	ldr     	r4, [pc, #0x118]
0x005520:	movs    	r1, #0x14
0x005522:	movs    	r2, #6
0x005524:	movs    	r0, #0xf1
0x005526:	add     	r4, sb
0x005528:	ldr     	r3, [r4, #0x4c]
0x00552a:	lsls    	r0, r0, #9
0x00552c:	bl      	#0x8694
0x005530:	movs    	r2, #0
0x005532:	str     	r6, [r4, #0x4c]
0x005534:	movs    	r1, #0
0x005536:	str     	r1, [sp]
0x005538:	str     	r1, [sp, #4]
0x00553a:	str     	r2, [sp, #8]
0x00553c:	b       	#0x5540
0x00553e:	b       	#0x554c
0x005540:	adds    	r3, r6, #0
0x005542:	movs    	r1, #0xf6
0x005544:	movs    	r0, #0xf1
0x005546:	lsls    	r0, r0, #9
0x005548:	bl      	#0x8694
0x00554c:	movs    	r1, #0
0x00554e:	movs    	r2, #0
0x005550:	str     	r2, [sp, #8]
0x005552:	str     	r1, [sp]
0x005554:	str     	r1, [sp, #4]
0x005556:	movs    	r4, #0xf1
0x005558:	lsls    	r4, r4, #9
0x00555a:	movs    	r1, #0xe1
0x00555c:	movs    	r2, #0xb0
0x00555e:	adds    	r3, r6, #0
0x005560:	adds    	r0, r4, #0
0x005562:	bl      	#0x8694
0x005566:	cmp     	r0, #1
0x005568:	bne     	#0x5584
0x00556a:	movs    	r1, #0
0x00556c:	movs    	r2, #0
0x00556e:	str     	r2, [sp, #8]
0x005570:	str     	r1, [sp]
0x005572:	str     	r1, [sp, #4]
0x005574:	movs    	r1, #0xe1

; ===== candidate_00563c =====
0x00563c:	push    	{r4, r5, r6, r7, lr}
0x00563e:	sub     	sp, #0x14
0x005640:	movs    	r2, #0
0x005642:	movs    	r1, #0
0x005644:	str     	r2, [sp, #8]
0x005646:	adds    	r6, r0, #0
0x005648:	adds    	r2, r0, #0
0x00564a:	str     	r1, [sp]
0x00564c:	str     	r1, [sp, #4]
0x00564e:	movs    	r1, #0x11
0x005650:	movs    	r0, #0xf1
0x005652:	movs    	r3, #4
0x005654:	lsls    	r0, r0, #9
0x005656:	bl      	#0x8694
0x00565a:	movs    	r4, #0
0x00565c:	movs    	r7, #0
0x00565e:	cmp     	r0, #0
0x005660:	str     	r0, [sp, #0x10]
0x005662:	ble     	#0x56ba
0x005664:	lsls    	r0, r4, #2
0x005666:	ldr     	r5, [r6, r0]
0x005668:	movs    	r1, #0
0x00566a:	movs    	r2, #0
0x00566c:	str     	r2, [sp, #8]
0x00566e:	str     	r1, [sp]
0x005670:	str     	r1, [sp, #4]
0x005672:	adds    	r3, r7, #0
0x005674:	adds    	r2, r5, #0
0x005676:	movs    	r1, #0x90
0x005678:	movs    	r0, #0xf1
0x00567a:	lsls    	r0, r0, #9
0x00567c:	bl      	#0x8694
0x005680:	movs    	r2, #0
0x005682:	movs    	r1, #0
0x005684:	str     	r2, [sp, #8]
0x005686:	adds    	r5, r0, #0
0x005688:	adds    	r3, r7, #0
0x00568a:	adds    	r2, r0, #0
0x00568c:	str     	r1, [sp]
0x00568e:	str     	r1, [sp, #4]
0x005690:	movs    	r1, #0x8f
0x005692:	movs    	r0, #0xf1
0x005694:	lsls    	r0, r0, #9
0x005696:	bl      	#0x8694
0x00569a:	movs    	r1, #0
0x00569c:	movs    	r2, #0
0x00569e:	str     	r2, [sp, #8]
0x0056a0:	str     	r1, [sp]
0x0056a2:	str     	r1, [sp, #4]
0x0056a4:	adds    	r3, r7, #0
0x0056a6:	adds    	r2, r5, #0
0x0056a8:	movs    	r1, #0x8e
0x0056aa:	movs    	r0, #0xf1
0x0056ac:	lsls    	r0, r0, #9
0x0056ae:	bl      	#0x8694
0x0056b2:	ldr     	r0, [sp, #0x10]
0x0056b4:	adds    	r4, #1
0x0056b6:	cmp     	r4, r0
0x0056b8:	blt     	#0x5664
0x0056ba:	movs    	r1, #0
0x0056bc:	movs    	r2, #0
0x0056be:	str     	r2, [sp, #8]
0x0056c0:	str     	r1, [sp]
0x0056c2:	str     	r1, [sp, #4]
0x0056c4:	adds    	r3, r7, #0
0x0056c6:	adds    	r2, r6, #0
0x0056c8:	movs    	r1, #9
0x0056ca:	movs    	r0, #0xf1
0x0056cc:	lsls    	r0, r0, #9
0x0056ce:	bl      	#0x8694
0x0056d2:	movs    	r1, #0
0x0056d4:	movs    	r2, #0
0x0056d6:	str     	r2, [sp, #8]
0x0056d8:	str     	r1, [sp]
0x0056da:	str     	r1, [sp, #4]
0x0056dc:	movs    	r1, #0x14
0x0056de:	movs    	r2, #0x20
0x0056e0:	adds    	r3, r7, #0
0x0056e2:	movs    	r0, #0xf1
0x0056e4:	lsls    	r0, r0, #9
0x0056e6:	bl      	#0x8694
0x0056ea:	movs    	r1, #0
0x0056ec:	str     	r1, [sp]
0x0056ee:	str     	r1, [sp, #4]
0x0056f0:	movs    	r2, #0
0x0056f2:	movs    	r1, #0xe6
0x0056f4:	adds    	r3, r7, #0
0x0056f6:	movs    	r0, #0xf1
0x0056f8:	lsls    	r0, r0, #9
0x0056fa:	str     	r2, [sp, #8]
0x0056fc:	bl      	#0x8694
0x005700:	movs    	r2, #0
0x005702:	movs    	r1, #0
0x005704:	str     	r2, [sp, #8]
0x005706:	ldr     	r2, [pc, #0x18]
0x005708:	str     	r1, [sp]
0x00570a:	str     	r1, [sp, #4]
0x00570c:	adds    	r3, r7, #0
0x00570e:	add     	r2, pc
0x005710:	movs    	r1, #0x33
0x005712:	movs    	r0, #0xf1
0x005714:	lsls    	r0, r0, #9
0x005716:	bl      	#0x8694
0x00571a:	add     	sp, #0x14
0x00571c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_005726 =====
0x005726:	push    	{lr}
0x005728:	movs    	r3, #1
0x00572a:	add     	r0, sb
0x00572c:	ldrsb   	r1, [r0, r3]
0x00572e:	sub     	sp, #0xc
0x005730:	cmp     	r1, #0
0x005732:	bne     	#0x574e
0x005734:	movs    	r2, #0
0x005736:	str     	r2, [sp, #8]
0x005738:	str     	r1, [sp]
0x00573a:	str     	r1, [sp, #4]
0x00573c:	movs    	r1, #0xe1
0x00573e:	movs    	r2, #0x58
0x005740:	movs    	r3, #0
0x005742:	movs    	r0, #0xf1
0x005744:	lsls    	r0, r0, #9
0x005746:	bl      	#0x8694
0x00574a:	add     	sp, #0xc
0x00574c:	pop     	{pc}

; ===== candidate_0057d4 =====
0x0057d4:	push    	{r4, lr}
0x0057d6:	sub     	sp, #0x10
0x0057d8:	movs    	r2, #0
0x0057da:	movs    	r1, #0
0x0057dc:	str     	r2, [sp, #8]
0x0057de:	adds    	r2, r0, #0
0x0057e0:	str     	r1, [sp]
0x0057e2:	str     	r1, [sp, #4]
0x0057e4:	movs    	r1, #0x73
0x0057e6:	movs    	r0, #0xf1
0x0057e8:	movs    	r3, #0
0x0057ea:	lsls    	r0, r0, #9
0x0057ec:	bl      	#0x8694
0x0057f0:	ldr     	r1, [pc, #0x3c]
0x0057f2:	add     	r1, pc
0x0057f4:	subs    	r0, #4
0x0057f6:	cmp     	r0, #8
0x0057f8:	bhs     	#0x5828
0x0057fa:	adr     	r3, #8
0x0057fc:	ldrb    	r3, [r3, r0]
0x0057fe:	lsls    	r3, r3, #1
0x005800:	add     	pc, r3
0x005802:	movs    	r0, r0
0x005804:	lsls    	r4, r0, #0x1c
0x005806:	asrs    	r2, r2, #8
0x005808:	lsrs    	r2, r1, #0x14
0x00580a:	asrs    	r2, r2, #0x20
0x00580c:	ldr     	r1, [pc, #0x24]
0x00580e:	add     	r1, pc
0x005810:	b       	#0x5828
0x005812:	ldr     	r1, [pc, #0x24]
0x005814:	add     	r1, pc
0x005816:	b       	#0x5828
0x005818:	ldr     	r1, [pc, #0x14]
0x00581a:	add     	r1, pc
0x00581c:	b       	#0x5828
0x00581e:	ldr     	r1, [pc, #0x1c]
0x005820:	add     	r1, pc
0x005822:	b       	#0x5828
0x005824:	ldr     	r1, [pc, #0x18]
0x005826:	add     	r1, pc
0x005828:	adds    	r0, r1, #0
0x00582a:	add     	sp, #0x10
0x00582c:	pop     	{r4, pc}

; ===== candidate_005844 =====
0x005844:	push    	{r4, r5, r6, lr}
0x005846:	sub     	sp, #0x10
0x005848:	movs    	r1, #0
0x00584a:	str     	r1, [sp]
0x00584c:	str     	r1, [sp, #4]
0x00584e:	movs    	r2, #0
0x005850:	str     	r2, [sp, #8]
0x005852:	adds    	r4, r0, #0
0x005854:	ldr     	r2, [r0, #4]
0x005856:	movs    	r5, #0
0x005858:	adds    	r3, r5, #0
0x00585a:	movs    	r0, #0xf1
0x00585c:	movs    	r1, #0x73
0x00585e:	lsls    	r0, r0, #9
0x005860:	bl      	#0x8694
0x005864:	lsls    	r6, r0, #0x10
0x005866:	movs    	r1, #0
0x005868:	movs    	r2, #0
0x00586a:	str     	r2, [sp, #8]
0x00586c:	str     	r1, [sp]
0x00586e:	str     	r1, [sp, #4]
0x005870:	asrs    	r6, r6, #0x10
0x005872:	adds    	r3, r5, #0
0x005874:	adds    	r2, r6, #0
0x005876:	movs    	r1, #0xd9
0x005878:	movs    	r0, #0xf1
0x00587a:	lsls    	r0, r0, #9
0x00587c:	bl      	#0x8694
0x005880:	movs    	r2, #0
0x005882:	movs    	r1, #0
0x005884:	str     	r2, [sp, #8]
0x005886:	adds    	r2, r0, #0
0x005888:	str     	r1, [sp]
0x00588a:	str     	r1, [sp, #4]
0x00588c:	movs    	r1, #0xff
0x00588e:	adds    	r3, r4, #0
0x005890:	adds    	r1, #6
0x005892:	movs    	r0, #0xf1
0x005894:	lsls    	r0, r0, #9
0x005896:	bl      	#0x8694
0x00589a:	add     	sp, #0x10
0x00589c:	pop     	{r4, r5, r6, pc}

; ===== candidate_0058a0 =====
0x0058a0:	push    	{r4, r5, r6, lr}
0x0058a2:	sub     	sp, #0x10
0x0058a4:	movs    	r1, #0
0x0058a6:	str     	r1, [sp]
0x0058a8:	str     	r1, [sp, #4]
0x0058aa:	movs    	r2, #0
0x0058ac:	str     	r2, [sp, #8]
0x0058ae:	adds    	r4, r0, #0
0x0058b0:	ldr     	r2, [r0, #4]
0x0058b2:	movs    	r6, #0
0x0058b4:	adds    	r3, r6, #0
0x0058b6:	movs    	r0, #0xf1
0x0058b8:	movs    	r1, #0x73
0x0058ba:	lsls    	r0, r0, #9
0x0058bc:	bl      	#0x8694
0x0058c0:	movs    	r1, #0
0x0058c2:	adds    	r5, r0, #0
0x0058c4:	movs    	r2, #0
0x0058c6:	str     	r2, [sp, #8]
0x0058c8:	str     	r1, [sp]
0x0058ca:	str     	r1, [sp, #4]
0x0058cc:	movs    	r1, #0xe1
0x0058ce:	movs    	r2, #5
0x0058d0:	movs    	r0, #0xf1
0x0058d2:	adds    	r3, r6, #0
0x0058d4:	lsls    	r0, r0, #9
0x0058d6:	bl      	#0x8694
0x0058da:	lsls    	r1, r5, #2
0x0058dc:	ldr     	r5, [r0, r1]
0x0058de:	movs    	r1, #0
0x0058e0:	movs    	r2, #0
0x0058e2:	str     	r2, [sp, #8]
0x0058e4:	str     	r1, [sp]
0x0058e6:	str     	r1, [sp, #4]
0x0058e8:	movs    	r1, #0x83
0x0058ea:	adds    	r2, r5, #0
0x0058ec:	movs    	r0, #0xf1
0x0058ee:	lsls    	r0, r0, #9
0x0058f0:	ldr     	r3, [r4, #4]
0x0058f2:	bl      	#0x8694
0x0058f6:	movs    	r3, #0x1a
0x0058f8:	ldrsb   	r0, [r0, r3]
0x0058fa:	add     	sp, #0x10
0x0058fc:	pop     	{r4, r5, r6, pc}

; ===== candidate_005900 =====
0x005900:	push    	{r4, r5, r6, lr}
0x005902:	sub     	sp, #0x10
0x005904:	movs    	r1, #0
0x005906:	str     	r1, [sp]
0x005908:	str     	r1, [sp, #4]
0x00590a:	movs    	r2, #0
0x00590c:	str     	r2, [sp, #8]
0x00590e:	adds    	r4, r0, #0
0x005910:	ldr     	r2, [r0, #4]
0x005912:	movs    	r6, #0
0x005914:	adds    	r3, r6, #0
0x005916:	movs    	r0, #0xf1
0x005918:	movs    	r1, #0x73
0x00591a:	lsls    	r0, r0, #9
0x00591c:	bl      	#0x8694
0x005920:	movs    	r1, #0
0x005922:	adds    	r5, r0, #0
0x005924:	movs    	r2, #0
0x005926:	str     	r2, [sp, #8]
0x005928:	str     	r1, [sp]
0x00592a:	str     	r1, [sp, #4]
0x00592c:	movs    	r1, #0xe1
0x00592e:	movs    	r2, #5
0x005930:	movs    	r0, #0xf1
0x005932:	adds    	r3, r6, #0
0x005934:	lsls    	r0, r0, #9
0x005936:	bl      	#0x8694
0x00593a:	lsls    	r1, r5, #2
0x00593c:	ldr     	r5, [r0, r1]
0x00593e:	movs    	r1, #0
0x005940:	movs    	r2, #0
0x005942:	str     	r2, [sp, #8]
0x005944:	str     	r1, [sp]
0x005946:	str     	r1, [sp, #4]
0x005948:	movs    	r1, #0x83
0x00594a:	adds    	r2, r5, #0
0x00594c:	movs    	r0, #0xf1
0x00594e:	lsls    	r0, r0, #9
0x005950:	ldr     	r3, [r4, #4]
0x005952:	bl      	#0x8694
0x005956:	movs    	r3, #0x1b
0x005958:	ldrsb   	r0, [r0, r3]
0x00595a:	add     	sp, #0x10
0x00595c:	pop     	{r4, r5, r6, pc}

; ===== candidate_005960 =====
0x005960:	push    	{r4, r5, r6, r7, lr}
0x005962:	sub     	sp, #0xc
0x005964:	movs    	r1, #0
0x005966:	movs    	r5, #0xff
0x005968:	movs    	r2, #0
0x00596a:	str     	r2, [sp, #8]
0x00596c:	adds    	r5, #0x31
0x00596e:	str     	r1, [sp]
0x005970:	str     	r1, [sp, #4]
0x005972:	movs    	r7, #0xf1
0x005974:	lsls    	r7, r7, #9
0x005976:	movs    	r1, #0xe1
0x005978:	adds    	r2, r5, #0
0x00597a:	adds    	r6, r0, #0
0x00597c:	movs    	r4, #0
0x00597e:	movs    	r3, #0
0x005980:	adds    	r0, r7, #0
0x005982:	bl      	#0x8694
0x005986:	cmp     	r0, #0
0x005988:	bne     	#0x598e
0x00598a:	add     	sp, #0xc
0x00598c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_005a14 =====
0x005a14:	push    	{r4, r5, r6, r7, lr}
0x005a16:	ldr     	r1, [r0, #4]
0x005a18:	ldr     	r4, [pc, #0x2c0]
0x005a1a:	sub     	sp, #0x1c
0x005a1c:	mov     	ip, r1
0x005a1e:	add     	r4, pc
0x005a20:	adds    	r0, #8
0x005a22:	ldm     	r0!, {r5, r6, r7}
0x005a24:	cmp     	r1, #0
0x005a26:	bgt     	#0x5a3a
0x005a28:	cmp     	r5, #0
0x005a2a:	bgt     	#0x5a3a
0x005a2c:	cmp     	r6, #0
0x005a2e:	bgt     	#0x5a3a
0x005a30:	cmp     	r7, #0
0x005a32:	bne     	#0x5a3a
0x005a34:	movs    	r0, #0
0x005a36:	add     	sp, #0x1c
0x005a38:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_005d04 =====
0x005d04:	push    	{r4, r5, r6, r7, lr}
0x005d06:	sub     	sp, #0x14
0x005d08:	movs    	r1, #0
0x005d0a:	str     	r1, [sp]
0x005d0c:	str     	r1, [sp, #4]
0x005d0e:	movs    	r7, #0xf1
0x005d10:	movs    	r6, #0
0x005d12:	movs    	r2, #0
0x005d14:	adds    	r3, r6, #0
0x005d16:	lsls    	r7, r7, #9
0x005d18:	movs    	r1, #0x13
0x005d1a:	adds    	r4, r0, #0
0x005d1c:	adds    	r0, r7, #0
0x005d1e:	str     	r2, [sp, #8]
0x005d20:	bl      	#0x8694
0x005d24:	adds    	r5, r0, #0
0x005d26:	ldr     	r0, [pc, #0x3c8]
0x005d28:	add     	r0, sb
0x005d2a:	ldr     	r3, [r0, #0x64]
0x005d2c:	cmp     	r3, #0
0x005d2e:	beq     	#0x5d46
0x005d30:	movs    	r1, #0
0x005d32:	movs    	r2, #0
0x005d34:	str     	r2, [sp, #8]
0x005d36:	str     	r1, [sp]
0x005d38:	str     	r1, [sp, #4]
0x005d3a:	movs    	r1, #0x12
0x005d3c:	adds    	r2, r3, #0
0x005d3e:	adds    	r0, r7, #0
0x005d40:	adds    	r3, r6, #0
0x005d42:	bl      	#0x8694
0x005d46:	ldr     	r0, [pc, #0x3a8]
0x005d48:	movs    	r3, #0
0x005d4a:	add     	r0, sb
0x005d4c:	str     	r3, [r0, #0x64]
0x005d4e:	ldr     	r1, [pc, #0x3a0]
0x005d50:	movs    	r0, #0
0x005d52:	add     	r1, sb
0x005d54:	strb    	r0, [r1]
0x005d56:	movs    	r1, #0
0x005d58:	movs    	r2, #0
0x005d5a:	str     	r2, [sp, #8]
0x005d5c:	str     	r1, [sp, #4]
0x005d5e:	movs    	r1, #0x14
0x005d60:	movs    	r2, #0x5b
0x005d62:	str     	r0, [sp]
0x005d64:	adds    	r3, r4, #0
0x005d66:	adds    	r0, r7, #0
0x005d68:	bl      	#0x8694
0x005d6c:	ldr     	r0, [pc, #0x380]
0x005d6e:	ldr     	r6, [pc, #0x384]
0x005d70:	add     	r0, sb
0x005d72:	ldr     	r0, [r0, #0xc]
0x005d74:	adds    	r1, r0, #0
0x005d76:	adds    	r1, #0x63
0x005d78:	add     	r6, pc
0x005d7a:	bne     	#0x5dde
0x005d7c:	movs    	r2, #0
0x005d7e:	str     	r2, [sp, #8]
0x005d80:	ldr     	r2, [pc, #0x374]
0x005d82:	adds    	r3, r6, #0
0x005d84:	str     	r1, [sp]
0x005d86:	str     	r1, [sp, #4]
0x005d88:	add     	r2, pc
0x005d8a:	movs    	r1, #0x35
0x005d8c:	adds    	r0, r7, #0
0x005d8e:	bl      	#0x8694
0x005d92:	movs    	r1, #0
0x005d94:	adds    	r3, r0, #0
0x005d96:	movs    	r2, #0
0x005d98:	str     	r2, [sp, #8]
0x005d9a:	str     	r1, [sp]
0x005d9c:	str     	r1, [sp, #4]
0x005d9e:	movs    	r1, #0x36
0x005da0:	adds    	r2, r5, #0
0x005da2:	movs    	r0, #0xf1
0x005da4:	lsls    	r0, r0, #9
0x005da6:	bl      	#0x8694
0x005daa:	movs    	r2, #0
0x005dac:	movs    	r1, #0
0x005dae:	str     	r2, [sp, #8]
0x005db0:	ldr     	r2, [pc, #0x348]
0x005db2:	str     	r1, [sp]
0x005db4:	str     	r1, [sp, #4]
0x005db6:	adds    	r3, r6, #0
0x005db8:	add     	r2, pc
0x005dba:	movs    	r1, #0x35
0x005dbc:	movs    	r0, #0xf1
0x005dbe:	lsls    	r0, r0, #9
0x005dc0:	bl      	#0x8694
0x005dc4:	movs    	r1, #0
0x005dc6:	adds    	r3, r0, #0
0x005dc8:	movs    	r2, #0
0x005dca:	str     	r2, [sp, #8]
0x005dcc:	str     	r1, [sp]
0x005dce:	str     	r1, [sp, #4]
0x005dd0:	movs    	r1, #0x36
0x005dd2:	adds    	r2, r5, #0
0x005dd4:	movs    	r0, #0xf1
0x005dd6:	lsls    	r0, r0, #9
0x005dd8:	bl      	#0x8694
0x005ddc:	b       	#0x5ee0
0x005dde:	adds    	r0, #0x62
0x005de0:	bne     	#0x5e2e
0x005de2:	movs    	r1, #0
0x005de4:	str     	r1, [sp]
0x005de6:	str     	r1, [sp, #4]
0x005de8:	movs    	r2, #0
0x005dea:	str     	r2, [sp, #8]
0x005dec:	movs    	r1, #0xea
0x005dee:	movs    	r3, #0
0x005df0:	adds    	r0, r7, #0
0x005df2:	ldr     	r2, [r4, #4]
0x005df4:	bl      	#0x8694
0x005df8:	cmp     	r0, #0
0x005dfa:	bne     	#0x5ee0
0x005dfc:	movs    	r2, #0
0x005dfe:	movs    	r1, #0
0x005e00:	str     	r2, [sp, #8]
0x005e02:	ldr     	r2, [pc, #0x2fc]
0x005e04:	str     	r1, [sp]
0x005e06:	str     	r1, [sp, #4]
0x005e08:	adds    	r3, r6, #0
0x005e0a:	add     	r2, pc
0x005e0c:	movs    	r1, #0x35
0x005e0e:	adds    	r0, r7, #0
0x005e10:	bl      	#0x8694
0x005e14:	movs    	r1, #0
0x005e16:	adds    	r3, r0, #0
0x005e18:	movs    	r2, #0
0x005e1a:	str     	r2, [sp, #8]
0x005e1c:	str     	r1, [sp]
0x005e1e:	str     	r1, [sp, #4]
0x005e20:	movs    	r1, #0x36
0x005e22:	adds    	r2, r5, #0
0x005e24:	movs    	r0, #0xf1
0x005e26:	lsls    	r0, r0, #9
0x005e28:	bl      	#0x8694
0x005e2c:	b       	#0x5ee0
0x005e2e:	movs    	r3, #8
0x005e30:	ldrsh   	r0, [r4, r3]

; ===== candidate_0064c4 =====
0x0064c4:	push    	{r4, r5, lr}
0x0064c6:	sub     	sp, #0xc
0x0064c8:	movs    	r1, #0
0x0064ca:	movs    	r2, #0
0x0064cc:	str     	r2, [sp, #8]
0x0064ce:	str     	r1, [sp]
0x0064d0:	str     	r1, [sp, #4]
0x0064d2:	movs    	r4, #0
0x0064d4:	adds    	r3, r4, #0
0x0064d6:	movs    	r1, #0xe1
0x0064d8:	movs    	r2, #0x80
0x0064da:	movs    	r0, #0xf1
0x0064dc:	lsls    	r0, r0, #9
0x0064de:	bl      	#0x8694
0x0064e2:	movs    	r2, #0
0x0064e4:	mvns    	r1, r2
0x0064e6:	ldr     	r3, [pc, #0x94]
0x0064e8:	str     	r1, [sp]
0x0064ea:	str     	r1, [sp, #4]
0x0064ec:	str     	r2, [sp, #8]
0x0064ee:	add     	r3, pc
0x0064f0:	adds    	r2, r0, #0
0x0064f2:	movs    	r0, #0xf1
0x0064f4:	movs    	r1, #5
0x0064f6:	lsls    	r0, r0, #9
0x0064f8:	bl      	#0x8694
0x0064fc:	movs    	r1, #0
0x0064fe:	movs    	r2, #0
0x006500:	str     	r2, [sp, #8]
0x006502:	str     	r1, [sp]
0x006504:	str     	r1, [sp, #4]
0x006506:	adds    	r3, r0, #0
0x006508:	movs    	r0, #0xf1
0x00650a:	movs    	r1, #0x14
0x00650c:	movs    	r2, #0x80
0x00650e:	lsls    	r0, r0, #9
0x006510:	bl      	#0x8694
0x006514:	movs    	r1, #0
0x006516:	movs    	r2, #0
0x006518:	str     	r2, [sp, #8]
0x00651a:	str     	r1, [sp]
0x00651c:	str     	r1, [sp, #4]
0x00651e:	movs    	r1, #0xe1
0x006520:	movs    	r2, #0x9f
0x006522:	adds    	r3, r4, #0
0x006524:	movs    	r0, #0xf1
0x006526:	lsls    	r0, r0, #9
0x006528:	bl      	#0x8694
0x00652c:	movs    	r2, #0
0x00652e:	mvns    	r1, r2
0x006530:	ldr     	r3, [pc, #0x4c]
0x006532:	str     	r1, [sp]
0x006534:	str     	r1, [sp, #4]
0x006536:	str     	r2, [sp, #8]
0x006538:	add     	r3, pc
0x00653a:	adds    	r2, r0, #0
0x00653c:	movs    	r0, #0xf1
0x00653e:	movs    	r1, #5
0x006540:	lsls    	r0, r0, #9
0x006542:	bl      	#0x8694
0x006546:	movs    	r1, #0
0x006548:	movs    	r2, #0
0x00654a:	str     	r2, [sp, #8]
0x00654c:	str     	r1, [sp]
0x00654e:	str     	r1, [sp, #4]
0x006550:	adds    	r3, r0, #0
0x006552:	movs    	r0, #0xf1
0x006554:	movs    	r1, #0x14
0x006556:	movs    	r2, #0x9f
0x006558:	lsls    	r0, r0, #9
0x00655a:	bl      	#0x8694
0x00655e:	movs    	r1, #0
0x006560:	movs    	r2, #0
0x006562:	str     	r2, [sp, #8]
0x006564:	str     	r1, [sp]
0x006566:	str     	r1, [sp, #4]
0x006568:	movs    	r1, #0x14
0x00656a:	movs    	r2, #0x98
0x00656c:	adds    	r3, r4, #0
0x00656e:	movs    	r0, #0xf1
0x006570:	lsls    	r0, r0, #9
0x006572:	bl      	#0x8694
0x006576:	add     	sp, #0xc
0x006578:	pop     	{r4, r5, pc}

; ===== candidate_006584 =====
0x006584:	push    	{r4, r5, r6, r7, lr}
0x006586:	sub     	sp, #0x1c
0x006588:	movs    	r1, #0
0x00658a:	movs    	r2, #0
0x00658c:	str     	r2, [sp, #8]
0x00658e:	str     	r1, [sp]
0x006590:	str     	r1, [sp, #4]
0x006592:	movs    	r5, #0
0x006594:	adds    	r3, r5, #0
0x006596:	movs    	r1, #0xe1
0x006598:	movs    	r2, #5
0x00659a:	movs    	r0, #0xf1
0x00659c:	lsls    	r0, r0, #9
0x00659e:	bl      	#0x8694
0x0065a2:	movs    	r2, #0
0x0065a4:	movs    	r1, #0
0x0065a6:	str     	r2, [sp, #8]
0x0065a8:	adds    	r2, r0, #0
0x0065aa:	str     	r1, [sp]
0x0065ac:	str     	r1, [sp, #4]
0x0065ae:	movs    	r1, #0x11
0x0065b0:	movs    	r0, #0xf1
0x0065b2:	movs    	r3, #4
0x0065b4:	lsls    	r0, r0, #9
0x0065b6:	bl      	#0x8694
0x0065ba:	ldr     	r7, [pc, #0x1f0]
0x0065bc:	adds    	r6, r0, #0
0x0065be:	add     	r7, sb
0x0065c0:	str     	r5, [r7, #0x14]
0x0065c2:	str     	r5, [r7, #0x54]
0x0065c4:	str     	r5, [r7, #0x58]
0x0065c6:	str     	r5, [r7, #0x5c]
0x0065c8:	movs    	r4, #0
0x0065ca:	bl      	#0x64c4
0x0065ce:	ldr     	r1, [pc, #0x1e0]
0x0065d0:	movs    	r0, #0x1d
0x0065d2:	str     	r5, [r7, #0x10]
0x0065d4:	add     	r1, sb
0x0065d6:	str     	r0, [r1, #4]
0x0065d8:	movs    	r1, #0
0x0065da:	movs    	r2, #0
0x0065dc:	str     	r2, [sp, #8]
0x0065de:	str     	r1, [sp]
0x0065e0:	str     	r1, [sp, #4]
0x0065e2:	movs    	r1, #0xe1
0x0065e4:	movs    	r2, #0xbc
0x0065e6:	movs    	r0, #0xf1
0x0065e8:	adds    	r3, r5, #0
0x0065ea:	lsls    	r0, r0, #9
0x0065ec:	bl      	#0x8694
0x0065f0:	cmp     	r0, #0
0x0065f2:	bne     	#0x663c
0x0065f4:	movs    	r1, #0
0x0065f6:	movs    	r2, #0
0x0065f8:	str     	r2, [sp, #8]
0x0065fa:	str     	r1, [sp]
0x0065fc:	str     	r1, [sp, #4]
0x0065fe:	movs    	r1, #0xe1
0x006600:	movs    	r2, #0xa7
0x006602:	movs    	r3, #0
0x006604:	movs    	r0, #0xf1
0x006606:	lsls    	r0, r0, #9
0x006608:	bl      	#0x8694
0x00660c:	movs    	r2, #0
0x00660e:	movs    	r1, #0
0x006610:	str     	r2, [sp, #8]
0x006612:	adds    	r2, r0, #0
0x006614:	str     	r1, [sp]
0x006616:	str     	r1, [sp, #4]
0x006618:	movs    	r1, #0xa
0x00661a:	movs    	r0, #0xf1
0x00661c:	movs    	r3, #4
0x00661e:	lsls    	r0, r0, #9
0x006620:	bl      	#0x8694
0x006624:	movs    	r1, #0
0x006626:	movs    	r2, #0
0x006628:	str     	r2, [sp, #8]
0x00662a:	str     	r1, [sp]
0x00662c:	str     	r1, [sp, #4]
0x00662e:	adds    	r3, r0, #0
0x006630:	movs    	r0, #0xf1
0x006632:	movs    	r1, #0x14
0x006634:	movs    	r2, #0xbc
0x006636:	lsls    	r0, r0, #9
0x006638:	bl      	#0x8694
0x00663c:	movs    	r5, #0
0x00663e:	cmp     	r6, #0
0x006640:	ble     	#0x66d4
0x006642:	movs    	r7, #0
0x006644:	movs    	r1, #0
0x006646:	movs    	r2, #0
0x006648:	str     	r2, [sp, #8]
0x00664a:	str     	r1, [sp]
0x00664c:	str     	r1, [sp, #4]
0x00664e:	movs    	r1, #0xe1
0x006650:	movs    	r2, #5
0x006652:	adds    	r3, r7, #0
0x006654:	movs    	r0, #0xf1
0x006656:	lsls    	r0, r0, #9
0x006658:	bl      	#0x8694
0x00665c:	lsls    	r1, r5, #2
0x00665e:	str     	r1, [sp, #0x18]
0x006660:	ldr     	r0, [r0, r1]
0x006662:	ldrb    	r0, [r0, #9]
0x006664:	cmp     	r0, #1
0x006666:	bne     	#0x66ce
0x006668:	movs    	r1, #0
0x00666a:	movs    	r2, #0
0x00666c:	str     	r2, [sp, #8]
0x00666e:	str     	r1, [sp]
0x006670:	str     	r1, [sp, #4]
0x006672:	movs    	r1, #0xe1
0x006674:	movs    	r2, #6
0x006676:	adds    	r3, r7, #0
0x006678:	movs    	r0, #0xf1
0x00667a:	lsls    	r0, r0, #9
0x00667c:	bl      	#0x8694
0x006680:	movs    	r1, #0
0x006682:	movs    	r2, #0
0x006684:	str     	r2, [sp, #8]
0x006686:	str     	r1, [sp]
0x006688:	str     	r1, [sp, #4]
0x00668a:	str     	r0, [sp, #0xc]
0x00668c:	movs    	r0, #0xf1
0x00668e:	movs    	r1, #0xe1
0x006690:	movs    	r2, #5
0x006692:	adds    	r3, r7, #0
0x006694:	lsls    	r0, r0, #9
0x006696:	bl      	#0x8694
0x00669a:	ldr     	r1, [sp, #0x18]
0x00669c:	movs    	r3, #0
0x00669e:	ldr     	r0, [r0, r1]
0x0066a0:	movs    	r2, #0
0x0066a2:	ldrsh   	r0, [r0, r3]
0x0066a4:	adds    	r3, r7, #0
0x0066a6:	lsls    	r1, r0, #2
0x0066a8:	ldr     	r0, [sp, #0xc]
0x0066aa:	ldr     	r0, [r0, r1]
0x0066ac:	movs    	r1, #0
0x0066ae:	str     	r1, [sp]
0x0066b0:	str     	r1, [sp, #4]

; ===== candidate_0067b4 =====
0x0067b4:	push    	{r4, r5, r6, r7, lr}
0x0067b6:	sub     	sp, #0xc
0x0067b8:	movs    	r1, #0
0x0067ba:	str     	r1, [sp]
0x0067bc:	str     	r1, [sp, #4]
0x0067be:	movs    	r7, #0xf1
0x0067c0:	movs    	r6, #0
0x0067c2:	movs    	r2, #0
0x0067c4:	adds    	r3, r6, #0
0x0067c6:	lsls    	r7, r7, #9
0x0067c8:	movs    	r1, #0x13
0x0067ca:	adds    	r4, r0, #0
0x0067cc:	adds    	r0, r7, #0
0x0067ce:	str     	r2, [sp, #8]
0x0067d0:	bl      	#0x8694
0x0067d4:	adds    	r5, r0, #0
0x0067d6:	ldr     	r0, [pc, #0x20c]
0x0067d8:	add     	r0, sb
0x0067da:	ldr     	r3, [r0, #0x64]
0x0067dc:	cmp     	r3, #0
0x0067de:	beq     	#0x67f6
0x0067e0:	movs    	r1, #0
0x0067e2:	movs    	r2, #0
0x0067e4:	str     	r2, [sp, #8]
0x0067e6:	str     	r1, [sp]
0x0067e8:	str     	r1, [sp, #4]
0x0067ea:	movs    	r1, #0x12
0x0067ec:	adds    	r2, r3, #0
0x0067ee:	adds    	r0, r7, #0
0x0067f0:	adds    	r3, r6, #0
0x0067f2:	bl      	#0x8694
0x0067f6:	ldr     	r0, [pc, #0x1ec]
0x0067f8:	movs    	r6, #0
0x0067fa:	add     	r0, sb
0x0067fc:	str     	r6, [r0, #0x64]
0x0067fe:	movs    	r1, #0
0x006800:	movs    	r2, #0
0x006802:	str     	r2, [sp, #8]
0x006804:	str     	r1, [sp]
0x006806:	str     	r1, [sp, #4]
0x006808:	movs    	r1, #0x14
0x00680a:	movs    	r2, #0x5b
0x00680c:	adds    	r3, r4, #0
0x00680e:	adds    	r0, r7, #0
0x006810:	bl      	#0x8694
0x006814:	movs    	r1, #0
0x006816:	movs    	r2, #0
0x006818:	str     	r2, [sp, #8]
0x00681a:	str     	r1, [sp]
0x00681c:	str     	r1, [sp, #4]
0x00681e:	movs    	r1, #0xe1
0x006820:	movs    	r2, #0x18
0x006822:	movs    	r3, #0
0x006824:	movs    	r0, #0xf1
0x006826:	lsls    	r0, r0, #9
0x006828:	bl      	#0x8694
0x00682c:	ldr     	r6, [r0, #0xc]
0x00682e:	movs    	r1, #0
0x006830:	movs    	r2, #0
0x006832:	str     	r2, [sp, #8]
0x006834:	str     	r1, [sp]
0x006836:	str     	r1, [sp, #4]
0x006838:	movs    	r1, #0xe1
0x00683a:	movs    	r2, #0xab
0x00683c:	movs    	r0, #0xf1
0x00683e:	movs    	r3, #0
0x006840:	lsls    	r0, r0, #9
0x006842:	bl      	#0x8694
0x006846:	adds    	r1, r6, #0
0x006848:	ldr     	r6, [pc, #0x19c]
0x00684a:	add     	r6, pc
0x00684c:	cmp     	r1, r0
0x00684e:	bne     	#0x6882
0x006850:	movs    	r2, #0
0x006852:	movs    	r1, #0
0x006854:	str     	r2, [sp, #8]
0x006856:	ldr     	r2, [pc, #0x194]
0x006858:	str     	r1, [sp]
0x00685a:	str     	r1, [sp, #4]
0x00685c:	adds    	r3, r6, #0
0x00685e:	add     	r2, pc
0x006860:	movs    	r1, #0x35
0x006862:	adds    	r0, r7, #0
0x006864:	bl      	#0x8694
0x006868:	movs    	r1, #0
0x00686a:	adds    	r3, r0, #0
0x00686c:	movs    	r2, #0
0x00686e:	str     	r2, [sp, #8]
0x006870:	str     	r1, [sp]
0x006872:	str     	r1, [sp, #4]
0x006874:	movs    	r1, #0x36
0x006876:	adds    	r2, r5, #0
0x006878:	movs    	r0, #0xf1
0x00687a:	lsls    	r0, r0, #9
0x00687c:	bl      	#0x8694
0x006880:	b       	#0x68b2
0x006882:	movs    	r2, #0
0x006884:	movs    	r1, #0
0x006886:	str     	r2, [sp, #8]
0x006888:	ldr     	r2, [pc, #0x164]
0x00688a:	str     	r1, [sp]
0x00688c:	str     	r1, [sp, #4]
0x00688e:	adds    	r3, r6, #0
0x006890:	add     	r2, pc
0x006892:	movs    	r1, #0x35
0x006894:	adds    	r0, r7, #0
0x006896:	bl      	#0x8694
0x00689a:	movs    	r1, #0
0x00689c:	adds    	r3, r0, #0
0x00689e:	movs    	r2, #0
0x0068a0:	str     	r2, [sp, #8]
0x0068a2:	str     	r1, [sp]
0x0068a4:	str     	r1, [sp, #4]
0x0068a6:	movs    	r1, #0x36
0x0068a8:	adds    	r2, r5, #0
0x0068aa:	movs    	r0, #0xf1
0x0068ac:	lsls    	r0, r0, #9
0x0068ae:	bl      	#0x8694
0x0068b2:	movs    	r1, #0
0x0068b4:	str     	r1, [sp]
0x0068b6:	str     	r1, [sp, #4]
0x0068b8:	movs    	r2, #0
0x0068ba:	str     	r2, [sp, #8]
0x0068bc:	ldr     	r2, [r4, #4]
0x0068be:	movs    	r4, #0
0x0068c0:	adds    	r3, r4, #0
0x0068c2:	movs    	r1, #0xe7
0x0068c4:	adds    	r0, r7, #0
0x0068c6:	bl      	#0x8694
0x0068ca:	cmp     	r0, #1
0x0068cc:	bne     	#0x68fe
0x0068ce:	movs    	r2, #0
0x0068d0:	movs    	r1, #0
0x0068d2:	str     	r2, [sp, #8]
0x0068d4:	ldr     	r2, [pc, #0x11c]
0x0068d6:	str     	r1, [sp]
0x0068d8:	str     	r1, [sp, #4]
0x0068da:	adds    	r3, r6, #0
0x0068dc:	add     	r2, pc
0x0068de:	movs    	r1, #0x35
0x0068e0:	adds    	r0, r7, #0

; ===== candidate_0069fc =====
0x0069fc:	push    	{r4, lr}
0x0069fe:	sub     	sp, #0x10
0x006a00:	movs    	r1, #0
0x006a02:	str     	r1, [sp]
0x006a04:	str     	r1, [sp, #4]
0x006a06:	movs    	r4, #0
0x006a08:	movs    	r2, #0
0x006a0a:	adds    	r3, r4, #0
0x006a0c:	movs    	r1, #0x34
0x006a0e:	movs    	r0, #0xf1
0x006a10:	lsls    	r0, r0, #9
0x006a12:	str     	r2, [sp, #8]
0x006a14:	bl      	#0x8694
0x006a18:	movs    	r1, #0
0x006a1a:	str     	r1, [sp]
0x006a1c:	str     	r1, [sp, #4]
0x006a1e:	movs    	r2, #0
0x006a20:	movs    	r1, #0xba
0x006a22:	adds    	r3, r4, #0
0x006a24:	movs    	r0, #0xf1
0x006a26:	lsls    	r0, r0, #9
0x006a28:	str     	r2, [sp, #8]
0x006a2a:	bl      	#0x8694
0x006a2e:	movs    	r1, #0
0x006a30:	movs    	r2, #0
0x006a32:	str     	r2, [sp, #8]
0x006a34:	str     	r1, [sp]
0x006a36:	str     	r1, [sp, #4]
0x006a38:	movs    	r1, #0x14
0x006a3a:	movs    	r2, #0x17
0x006a3c:	movs    	r3, #0x25
0x006a3e:	movs    	r0, #0xf1
0x006a40:	lsls    	r0, r0, #9
0x006a42:	bl      	#0x8694
0x006a46:	bl      	#0x6584
0x006a4a:	add     	sp, #0x10
0x006a4c:	pop     	{r4, pc}

; ===== candidate_006a50 =====
0x006a50:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x006a52:	sub     	sp, #0xc
0x006a54:	movs    	r1, #0
0x006a56:	movs    	r2, #0
0x006a58:	str     	r2, [sp, #8]
0x006a5a:	str     	r1, [sp]
0x006a5c:	str     	r1, [sp, #4]
0x006a5e:	movs    	r7, #0xf1
0x006a60:	movs    	r5, #0
0x006a62:	adds    	r3, r5, #0
0x006a64:	lsls    	r7, r7, #9
0x006a66:	movs    	r1, #0xe1
0x006a68:	movs    	r2, #0x17
0x006a6a:	adds    	r4, r0, #0
0x006a6c:	adds    	r0, r7, #0
0x006a6e:	bl      	#0x8694
0x006a72:	subs    	r0, #0xff
0x006a74:	subs    	r0, #0x16
0x006a76:	beq     	#0x6a8c
0x006a78:	movs    	r1, #0
0x006a7a:	str     	r1, [sp]
0x006a7c:	str     	r1, [sp, #4]
0x006a7e:	movs    	r2, #0
0x006a80:	movs    	r1, #0x34
0x006a82:	adds    	r3, r5, #0
0x006a84:	adds    	r0, r7, #0
0x006a86:	str     	r2, [sp, #8]
0x006a88:	bl      	#0x8694
0x006a8c:	ldr     	r6, [pc, #0x40]
0x006a8e:	movs    	r1, #0
0x006a90:	add     	r6, sb
0x006a92:	str     	r4, [r6, #0x40]
0x006a94:	ldr     	r0, [sp, #0x10]
0x006a96:	movs    	r2, #0
0x006a98:	str     	r0, [r6, #0x44]
0x006a9a:	str     	r1, [sp]
0x006a9c:	str     	r1, [sp, #4]
0x006a9e:	movs    	r1, #0xe6
0x006aa0:	adds    	r3, r5, #0
0x006aa2:	adds    	r0, r7, #0
0x006aa4:	str     	r2, [sp, #8]
0x006aa6:	bl      	#0x8694
0x006aaa:	movs    	r0, #1
0x006aac:	str     	r0, [r6, #0x48]
0x006aae:	cmp     	r4, #0
0x006ab0:	beq     	#0x6ab4
0x006ab2:	b       	#0x6ab4
0x006ab4:	movs    	r1, #0
0x006ab6:	movs    	r2, #0
0x006ab8:	str     	r2, [sp, #8]
0x006aba:	str     	r1, [sp]
0x006abc:	str     	r1, [sp, #4]
0x006abe:	movs    	r3, #0xff
0x006ac0:	adds    	r3, #0x16
0x006ac2:	movs    	r1, #0x14
0x006ac4:	movs    	r2, #0x17
0x006ac6:	adds    	r0, r7, #0
0x006ac8:	bl      	#0x8694
0x006acc:	add     	sp, #0x14
0x006ace:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_006ad4 =====
0x006ad4:	push    	{r4, r5, r6, r7, lr}
0x006ad6:	sub     	sp, #0x2c
0x006ad8:	movs    	r1, #0
0x006ada:	movs    	r2, #0
0x006adc:	str     	r2, [sp, #8]
0x006ade:	str     	r1, [sp]
0x006ae0:	str     	r1, [sp, #4]
0x006ae2:	movs    	r4, #0xf1
0x006ae4:	movs    	r6, #0
0x006ae6:	adds    	r3, r6, #0
0x006ae8:	lsls    	r4, r4, #9
0x006aea:	movs    	r1, #0xe1
0x006aec:	movs    	r2, #5
0x006aee:	adds    	r7, r0, #0
0x006af0:	adds    	r0, r4, #0
0x006af2:	bl      	#0x8694
0x006af6:	movs    	r1, #0
0x006af8:	movs    	r2, #0
0x006afa:	str     	r2, [sp, #8]
0x006afc:	str     	r1, [sp]
0x006afe:	str     	r1, [sp, #4]
0x006b00:	movs    	r1, #0x11
0x006b02:	adds    	r2, r0, #0
0x006b04:	movs    	r3, #4
0x006b06:	adds    	r0, r4, #0
0x006b08:	bl      	#0x8694
0x006b0c:	str     	r0, [sp, #0x28]
0x006b0e:	movs    	r0, #0
0x006b10:	str     	r0, [sp, #0x20]
0x006b12:	ldr     	r0, [pc, #0x3e0]
0x006b14:	ldr     	r1, [pc, #0x3e0]
0x006b16:	add     	r0, sb
0x006b18:	str     	r6, [r0, #0x14]
0x006b1a:	str     	r6, [r0, #0x54]
0x006b1c:	str     	r6, [r0, #0x58]
0x006b1e:	str     	r6, [r0, #0x5c]
0x006b20:	str     	r7, [r0, #0xc]
0x006b22:	str     	r6, [r0, #0x18]
0x006b24:	str     	r6, [r0, #0x10]
0x006b26:	movs    	r0, #0x1d
0x006b28:	add     	r1, sb
0x006b2a:	str     	r0, [r1, #4]
0x006b2c:	adds    	r0, r7, #0
0x006b2e:	adds    	r0, #0x63
0x006b30:	bne     	#0x6b7c
0x006b32:	movs    	r2, #0
0x006b34:	movs    	r1, #0
0x006b36:	str     	r2, [sp, #8]
0x006b38:	movs    	r2, #0xff
0x006b3a:	str     	r1, [sp]
0x006b3c:	str     	r1, [sp, #4]
0x006b3e:	movs    	r1, #0xe1
0x006b40:	adds    	r2, #0x1f
0x006b42:	adds    	r3, r6, #0
0x006b44:	adds    	r0, r4, #0
0x006b46:	bl      	#0x8694
0x006b4a:	movs    	r1, #0
0x006b4c:	movs    	r2, #0
0x006b4e:	str     	r2, [sp, #8]
0x006b50:	str     	r1, [sp]
0x006b52:	str     	r1, [sp, #4]
0x006b54:	movs    	r1, #0x14
0x006b56:	movs    	r2, #0xa6
0x006b58:	adds    	r3, r0, #0
0x006b5a:	adds    	r0, r4, #0
0x006b5c:	bl      	#0x8694
0x006b60:	movs    	r2, #0
0x006b62:	movs    	r1, #0
0x006b64:	str     	r2, [sp, #8]
0x006b66:	movs    	r2, #0xff
0x006b68:	str     	r1, [sp]
0x006b6a:	str     	r1, [sp, #4]
0x006b6c:	movs    	r1, #0xe1
0x006b6e:	adds    	r2, #0x33
0x006b70:	adds    	r3, r6, #0
0x006b72:	adds    	r0, r4, #0
0x006b74:	bl      	#0x8694
0x006b78:	adds    	r5, r0, #0
0x006b7a:	b       	#0x6bc4
0x006b7c:	movs    	r1, #0
0x006b7e:	movs    	r2, #0
0x006b80:	str     	r2, [sp, #8]
0x006b82:	str     	r1, [sp]
0x006b84:	str     	r1, [sp, #4]
0x006b86:	movs    	r1, #0xe1
0x006b88:	movs    	r2, #0xa5
0x006b8a:	adds    	r3, r6, #0
0x006b8c:	adds    	r0, r4, #0
0x006b8e:	bl      	#0x8694
0x006b92:	movs    	r1, #0
0x006b94:	movs    	r2, #0
0x006b96:	str     	r2, [sp, #8]
0x006b98:	str     	r1, [sp]
0x006b9a:	str     	r1, [sp, #4]
0x006b9c:	adds    	r3, r0, #0
0x006b9e:	movs    	r0, #0xf1
0x006ba0:	movs    	r1, #0x14
0x006ba2:	movs    	r2, #0xa6
0x006ba4:	lsls    	r0, r0, #9
0x006ba6:	bl      	#0x8694
0x006baa:	movs    	r1, #0
0x006bac:	movs    	r2, #0
0x006bae:	str     	r2, [sp, #8]
0x006bb0:	str     	r1, [sp]
0x006bb2:	str     	r1, [sp, #4]
0x006bb4:	movs    	r1, #0xe1
0x006bb6:	movs    	r2, #0xa7
0x006bb8:	adds    	r3, r6, #0
0x006bba:	movs    	r0, #0xf1
0x006bbc:	lsls    	r0, r0, #9
0x006bbe:	bl      	#0x8694
0x006bc2:	adds    	r5, r0, #0
0x006bc4:	movs    	r1, #0
0x006bc6:	movs    	r2, #0
0x006bc8:	str     	r2, [sp, #8]
0x006bca:	str     	r1, [sp]
0x006bcc:	str     	r1, [sp, #4]
0x006bce:	movs    	r1, #0xe1
0x006bd0:	movs    	r2, #0xbc
0x006bd2:	movs    	r3, #0
0x006bd4:	movs    	r0, #0xf1
0x006bd6:	lsls    	r0, r0, #9
0x006bd8:	bl      	#0x8694
0x006bdc:	cmp     	r0, #0
0x006bde:	bne     	#0x6c10
0x006be0:	movs    	r1, #0
0x006be2:	movs    	r2, #0
0x006be4:	str     	r2, [sp, #8]
0x006be6:	str     	r1, [sp]
0x006be8:	str     	r1, [sp, #4]
0x006bea:	movs    	r1, #0xa
0x006bec:	adds    	r2, r5, #0
0x006bee:	movs    	r3, #4
0x006bf0:	movs    	r0, #0xf1
0x006bf2:	lsls    	r0, r0, #9
0x006bf4:	bl      	#0x8694
0x006bf8:	movs    	r1, #0
0x006bfa:	movs    	r2, #0
0x006bfc:	str     	r2, [sp, #8]
0x006bfe:	str     	r1, [sp]
0x006c00:	str     	r1, [sp, #4]

; ===== candidate_007660 =====
0x007660:	push    	{r4, r5, r6, r7, lr}
0x007662:	sub     	sp, #0x14
0x007664:	movs    	r1, #0
0x007666:	movs    	r2, #0
0x007668:	str     	r2, [sp, #8]
0x00766a:	str     	r1, [sp]
0x00766c:	str     	r1, [sp, #4]
0x00766e:	movs    	r5, #0
0x007670:	adds    	r3, r5, #0
0x007672:	movs    	r1, #0xe1
0x007674:	movs    	r2, #5
0x007676:	movs    	r0, #0xf1
0x007678:	lsls    	r0, r0, #9
0x00767a:	bl      	#0x8694
0x00767e:	movs    	r2, #0
0x007680:	movs    	r1, #0
0x007682:	str     	r2, [sp, #8]
0x007684:	adds    	r2, r0, #0
0x007686:	str     	r1, [sp]
0x007688:	str     	r1, [sp, #4]
0x00768a:	movs    	r1, #0x11
0x00768c:	movs    	r0, #0xf1
0x00768e:	movs    	r3, #4
0x007690:	lsls    	r0, r0, #9
0x007692:	bl      	#0x8694
0x007696:	ldr     	r6, [pc, #0x304]
0x007698:	ldr     	r1, [pc, #0x304]
0x00769a:	add     	r6, sb
0x00769c:	str     	r5, [r6, #0x14]
0x00769e:	str     	r5, [r6, #0x54]
0x0076a0:	str     	r5, [r6, #0x58]
0x0076a2:	adds    	r7, r0, #0
0x0076a4:	movs    	r4, #0
0x0076a6:	mvns    	r0, r4
0x0076a8:	str     	r5, [r6, #0x5c]
0x0076aa:	add     	r1, sb
0x0076ac:	str     	r0, [r1]
0x0076ae:	bl      	#0x64c4
0x0076b2:	ldr     	r1, [pc, #0x2ec]
0x0076b4:	movs    	r0, #0x1d
0x0076b6:	str     	r5, [r6, #0x10]
0x0076b8:	add     	r1, sb
0x0076ba:	str     	r0, [r1, #4]
0x0076bc:	movs    	r1, #0
0x0076be:	movs    	r2, #0
0x0076c0:	str     	r2, [sp, #8]
0x0076c2:	str     	r1, [sp]
0x0076c4:	str     	r1, [sp, #4]
0x0076c6:	movs    	r1, #0xe1
0x0076c8:	movs    	r2, #0xa5
0x0076ca:	movs    	r0, #0xf1
0x0076cc:	adds    	r3, r5, #0
0x0076ce:	lsls    	r0, r0, #9
0x0076d0:	bl      	#0x8694
0x0076d4:	movs    	r1, #0
0x0076d6:	movs    	r2, #0
0x0076d8:	str     	r2, [sp, #8]
0x0076da:	str     	r1, [sp]
0x0076dc:	str     	r1, [sp, #4]
0x0076de:	adds    	r3, r0, #0
0x0076e0:	movs    	r0, #0xf1
0x0076e2:	movs    	r1, #0x14
0x0076e4:	movs    	r2, #0xa6
0x0076e6:	lsls    	r0, r0, #9
0x0076e8:	bl      	#0x8694
0x0076ec:	movs    	r1, #0
0x0076ee:	movs    	r2, #0
0x0076f0:	str     	r2, [sp, #8]
0x0076f2:	str     	r1, [sp]
0x0076f4:	str     	r1, [sp, #4]
0x0076f6:	movs    	r1, #0xe1
0x0076f8:	movs    	r2, #0xbc
0x0076fa:	adds    	r3, r5, #0
0x0076fc:	movs    	r0, #0xf1
0x0076fe:	lsls    	r0, r0, #9
0x007700:	bl      	#0x8694
0x007704:	cmp     	r0, #0
0x007706:	bne     	#0x7750
0x007708:	movs    	r1, #0
0x00770a:	movs    	r2, #0
0x00770c:	str     	r2, [sp, #8]
0x00770e:	str     	r1, [sp]
0x007710:	str     	r1, [sp, #4]
0x007712:	movs    	r1, #0xe1
0x007714:	movs    	r2, #0xa7
0x007716:	movs    	r3, #0
0x007718:	movs    	r0, #0xf1
0x00771a:	lsls    	r0, r0, #9
0x00771c:	bl      	#0x8694
0x007720:	movs    	r2, #0
0x007722:	movs    	r1, #0
0x007724:	str     	r2, [sp, #8]
0x007726:	adds    	r2, r0, #0
0x007728:	str     	r1, [sp]
0x00772a:	str     	r1, [sp, #4]
0x00772c:	movs    	r1, #0xa
0x00772e:	movs    	r0, #0xf1
0x007730:	movs    	r3, #4
0x007732:	lsls    	r0, r0, #9
0x007734:	bl      	#0x8694
0x007738:	movs    	r1, #0
0x00773a:	movs    	r2, #0
0x00773c:	str     	r2, [sp, #8]
0x00773e:	str     	r1, [sp]
0x007740:	str     	r1, [sp, #4]
0x007742:	adds    	r3, r0, #0
0x007744:	movs    	r0, #0xf1
0x007746:	movs    	r1, #0x14
0x007748:	movs    	r2, #0xbc
0x00774a:	lsls    	r0, r0, #9
0x00774c:	bl      	#0x8694
0x007750:	movs    	r1, #0
0x007752:	movs    	r2, #0
0x007754:	str     	r2, [sp, #8]
0x007756:	str     	r1, [sp]
0x007758:	str     	r1, [sp, #4]
0x00775a:	movs    	r1, #0xe1
0x00775c:	movs    	r2, #0xa7
0x00775e:	movs    	r5, #0
0x007760:	movs    	r3, #0
0x007762:	movs    	r0, #0xf1
0x007764:	lsls    	r0, r0, #9
0x007766:	bl      	#0x8694
0x00776a:	cmp     	r0, #0
0x00776c:	ble     	#0x77aa
0x00776e:	movs    	r6, #0
0x007770:	movs    	r1, #0
0x007772:	movs    	r2, #0
0x007774:	str     	r2, [sp, #8]
0x007776:	str     	r1, [sp]
0x007778:	str     	r1, [sp, #4]
0x00777a:	movs    	r1, #0xe1
0x00777c:	movs    	r2, #0xbc
0x00777e:	adds    	r3, r6, #0
0x007780:	movs    	r0, #0xf1
0x007782:	lsls    	r0, r0, #9
0x007784:	bl      	#0x8694
0x007788:	lsls    	r1, r5, #2
0x00778a:	str     	r6, [r0, r1]
0x00778c:	movs    	r1, #0
0x00778e:	movs    	r2, #0

; ===== candidate_0079a4 =====
0x0079a4:	push    	{r4, r5, r6, lr}
0x0079a6:	adds    	r6, r1, #0
0x0079a8:	adds    	r1, r0, #0
0x0079aa:	ldr     	r0, [pc, #0xe8]
0x0079ac:	sub     	sp, #0x10
0x0079ae:	add     	r0, sb
0x0079b0:	ldr     	r0, [r0, #4]
0x0079b2:	adds    	r5, r0, #0
0x0079b4:	blx     	#0x20
0x0079b8:	adds    	r4, r0, #0
0x0079ba:	adds    	r1, r6, #0
0x0079bc:	adds    	r0, r5, #0
0x0079be:	blx     	#0x20
0x0079c2:	movs    	r1, #0
0x0079c4:	movs    	r2, #0
0x0079c6:	muls    	r0, r4, r0
0x0079c8:	str     	r2, [sp, #8]
0x0079ca:	str     	r1, [sp]
0x0079cc:	str     	r1, [sp, #4]
0x0079ce:	movs    	r6, #0xf1
0x0079d0:	lsls    	r6, r6, #9
0x0079d2:	movs    	r1, #0x14
0x0079d4:	movs    	r2, #0xaa
0x0079d6:	adds    	r3, r0, #0
0x0079d8:	adds    	r0, r6, #0
0x0079da:	bl      	#0x8694
0x0079de:	movs    	r1, #0
0x0079e0:	movs    	r2, #0
0x0079e2:	str     	r2, [sp, #8]
0x0079e4:	str     	r1, [sp]
0x0079e6:	str     	r1, [sp, #4]
0x0079e8:	movs    	r4, #0
0x0079ea:	adds    	r3, r4, #0
0x0079ec:	movs    	r1, #0xe1
0x0079ee:	movs    	r2, #0xa7
0x0079f0:	adds    	r0, r6, #0
0x0079f2:	bl      	#0x8694
0x0079f6:	movs    	r1, #0
0x0079f8:	movs    	r2, #0
0x0079fa:	str     	r2, [sp, #8]
0x0079fc:	str     	r1, [sp]
0x0079fe:	str     	r1, [sp, #4]
0x007a00:	movs    	r1, #0xe1
0x007a02:	movs    	r2, #0xaa
0x007a04:	adds    	r5, r0, #0
0x007a06:	adds    	r3, r4, #0
0x007a08:	adds    	r0, r6, #0
0x007a0a:	bl      	#0x8694
0x007a0e:	adds    	r1, r5, #0
0x007a10:	blx     	#0x20
0x007a14:	movs    	r1, #0
0x007a16:	movs    	r2, #0
0x007a18:	str     	r2, [sp, #8]
0x007a1a:	str     	r1, [sp]
0x007a1c:	str     	r1, [sp, #4]
0x007a1e:	movs    	r1, #0x14
0x007a20:	movs    	r2, #0xa8
0x007a22:	adds    	r3, r0, #0
0x007a24:	adds    	r0, r6, #0
0x007a26:	bl      	#0x8694
0x007a2a:	movs    	r1, #0
0x007a2c:	movs    	r2, #0
0x007a2e:	str     	r2, [sp, #8]
0x007a30:	str     	r1, [sp]
0x007a32:	str     	r1, [sp, #4]
0x007a34:	movs    	r1, #0xe1
0x007a36:	movs    	r2, #0xa7
0x007a38:	adds    	r3, r4, #0
0x007a3a:	adds    	r0, r6, #0
0x007a3c:	bl      	#0x8694
0x007a40:	movs    	r1, #0
0x007a42:	movs    	r2, #0
0x007a44:	str     	r2, [sp, #8]
0x007a46:	str     	r1, [sp]
0x007a48:	str     	r1, [sp, #4]
0x007a4a:	movs    	r1, #0xe1
0x007a4c:	movs    	r2, #0xaa
0x007a4e:	adds    	r5, r0, #0
0x007a50:	adds    	r3, r4, #0
0x007a52:	adds    	r0, r6, #0
0x007a54:	bl      	#0x8694
0x007a58:	adds    	r1, r5, #0
0x007a5a:	blx     	#0x20
0x007a5e:	cmp     	r1, #0
0x007a60:	beq     	#0x7a8e
0x007a62:	movs    	r1, #0
0x007a64:	movs    	r2, #0
0x007a66:	str     	r2, [sp, #8]
0x007a68:	str     	r1, [sp]
0x007a6a:	str     	r1, [sp, #4]
0x007a6c:	movs    	r1, #0xe1
0x007a6e:	movs    	r2, #0xa8
0x007a70:	adds    	r3, r4, #0
0x007a72:	adds    	r0, r6, #0
0x007a74:	bl      	#0x8694
0x007a78:	movs    	r1, #0
0x007a7a:	movs    	r2, #0
0x007a7c:	str     	r2, [sp, #8]
0x007a7e:	str     	r1, [sp]
0x007a80:	str     	r1, [sp, #4]
0x007a82:	movs    	r1, #0x14
0x007a84:	movs    	r2, #0xa8
0x007a86:	adds    	r3, r0, #1
0x007a88:	adds    	r0, r6, #0
0x007a8a:	bl      	#0x8694
0x007a8e:	add     	sp, #0x10
0x007a90:	pop     	{r4, r5, r6, pc}

; ===== candidate_007a98 =====
0x007a98:	push    	{r4, r5, r6, r7, lr}
0x007a9a:	sub     	sp, #0xc
0x007a9c:	movs    	r2, #0
0x007a9e:	movs    	r1, #0
0x007aa0:	str     	r2, [sp, #8]
0x007aa2:	movs    	r2, #0xff
0x007aa4:	str     	r1, [sp]
0x007aa6:	str     	r1, [sp, #4]
0x007aa8:	movs    	r7, #0xf1
0x007aaa:	lsls    	r7, r7, #9
0x007aac:	movs    	r1, #0xe1
0x007aae:	adds    	r2, #0x22
0x007ab0:	adds    	r6, r0, #0
0x007ab2:	movs    	r3, #0
0x007ab4:	adds    	r0, r7, #0
0x007ab6:	bl      	#0x8694
0x007aba:	movs    	r1, #0
0x007abc:	movs    	r2, #0
0x007abe:	str     	r2, [sp, #8]
0x007ac0:	str     	r1, [sp]
0x007ac2:	str     	r1, [sp, #4]
0x007ac4:	movs    	r1, #0x11
0x007ac6:	adds    	r2, r0, #0
0x007ac8:	movs    	r3, #4
0x007aca:	adds    	r0, r7, #0
0x007acc:	bl      	#0x8694
0x007ad0:	adds    	r5, r0, #0
0x007ad2:	movs    	r4, #0
0x007ad4:	cmp     	r0, #0
0x007ad6:	ble     	#0x7b0a
0x007ad8:	movs    	r7, #0
0x007ada:	movs    	r2, #0
0x007adc:	movs    	r1, #0
0x007ade:	str     	r2, [sp, #8]
0x007ae0:	movs    	r2, #0xff
0x007ae2:	str     	r1, [sp]
0x007ae4:	str     	r1, [sp, #4]
0x007ae6:	adds    	r3, r7, #0
0x007ae8:	adds    	r2, #0x22
0x007aea:	movs    	r1, #0xe1
0x007aec:	movs    	r0, #0xf1
0x007aee:	lsls    	r0, r0, #9
0x007af0:	bl      	#0x8694
0x007af4:	lsls    	r1, r4, #2
0x007af6:	ldr     	r0, [r0, r1]
0x007af8:	ldr     	r0, [r0]
0x007afa:	cmp     	r0, r6
0x007afc:	bne     	#0x7b04
0x007afe:	movs    	r0, #1
0x007b00:	add     	sp, #0xc
0x007b02:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007b10 =====
0x007b10:	push    	{r4, r5, r6, r7, lr}
0x007b12:	sub     	sp, #0xc
0x007b14:	movs    	r1, #0
0x007b16:	str     	r1, [sp]
0x007b18:	str     	r1, [sp, #4]
0x007b1a:	ldr     	r5, [pc, #0x88]
0x007b1c:	movs    	r2, #0
0x007b1e:	movs    	r4, #0xf1
0x007b20:	lsls    	r4, r4, #9
0x007b22:	str     	r2, [sp, #8]
0x007b24:	movs    	r1, #0x11
0x007b26:	adds    	r6, r0, #0
0x007b28:	movs    	r3, #4
0x007b2a:	add     	r5, sb
0x007b2c:	ldr     	r2, [r5, #0x64]
0x007b2e:	adds    	r0, r4, #0
0x007b30:	bl      	#0x8694
0x007b34:	adds    	r7, r0, #0
0x007b36:	ldr     	r0, [pc, #0x6c]
0x007b38:	movs    	r3, #0
0x007b3a:	add     	r0, sb
0x007b3c:	adds    	r0, #0x14
0x007b3e:	cmp     	r6, #0xd
0x007b40:	beq     	#0x7b86
0x007b42:	bgt     	#0x7b6c
0x007b44:	cmp     	r6, #2
0x007b46:	beq     	#0x7b54
0x007b48:	cmp     	r6, #5
0x007b4a:	beq     	#0x7b78
0x007b4c:	cmp     	r6, #8
0x007b4e:	beq     	#0x7b86
0x007b50:	cmp     	r6, #0xc
0x007b52:	bne     	#0x7b68
0x007b54:	movs    	r2, #0
0x007b56:	movs    	r1, #0
0x007b58:	str     	r1, [sp, #4]
0x007b5a:	str     	r2, [sp, #8]
0x007b5c:	adds    	r2, r7, #0
0x007b5e:	movs    	r1, #0x29
0x007b60:	str     	r0, [sp]
0x007b62:	adds    	r0, r4, #0
0x007b64:	bl      	#0x8694
0x007b68:	add     	sp, #0xc
0x007b6a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_007baa =====
0x007baa:	push    	{r4, r5, r6, r7, lr}
0x007bac:	movs    	r1, #0
0x007bae:	sub     	sp, #0x14
0x007bb0:	subs    	r0, #2
0x007bb2:	add     	r2, sb
0x007bb4:	strb    	r1, [r2, #2]
0x007bb6:	cmp     	r0, #0x13
0x007bb8:	bhs     	#0x7bc4
0x007bba:	adr     	r3, #0xc
0x007bbc:	adds    	r3, r3, r0
0x007bbe:	ldrh    	r3, [r3, r0]
0x007bc0:	lsls    	r3, r3, #1
0x007bc2:	add     	pc, r3
0x007bc4:	add     	sp, #0x14
0x007bc6:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_008128 =====
0x008128:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00812a:	sub     	sp, #0xc
0x00812c:	adds    	r4, r1, #0
0x00812e:	movs    	r1, #0
0x008130:	adds    	r5, r2, #0
0x008132:	movs    	r2, #0
0x008134:	str     	r2, [sp, #8]
0x008136:	str     	r1, [sp]
0x008138:	str     	r1, [sp, #4]
0x00813a:	movs    	r6, #0xf1
0x00813c:	lsls    	r6, r6, #9
0x00813e:	movs    	r1, #0xe1
0x008140:	movs    	r2, #0xc8
0x008142:	movs    	r3, #0
0x008144:	adds    	r0, r6, #0
0x008146:	ldr     	r7, [sp, #0x30]
0x008148:	bl      	#0x8694
0x00814c:	cmp     	r0, #0
0x00814e:	bne     	#0x8166
0x008150:	movs    	r1, #0
0x008152:	movs    	r2, #0
0x008154:	str     	r2, [sp, #8]
0x008156:	str     	r1, [sp]
0x008158:	str     	r1, [sp, #4]
0x00815a:	movs    	r1, #0x14
0x00815c:	movs    	r2, #0xc8
0x00815e:	movs    	r3, #1
0x008160:	adds    	r0, r6, #0
0x008162:	bl      	#0x8694
0x008166:	ldr     	r0, [sp, #0xc]
0x008168:	cmp     	r0, #0x21
0x00816a:	bhs     	#0x8176
0x00816c:	adr     	r3, #8
0x00816e:	adds    	r3, r3, r0
0x008170:	ldrh    	r3, [r3, r0]
0x008172:	lsls    	r3, r3, #1
0x008174:	add     	pc, r3
0x008176:	b       	#0x83c0
0x008178:	lsls    	r6, r1, #4
0x00817a:	lsls    	r1, r3, #4
0x00817c:	lsls    	r1, r1, #4
0x00817e:	lsls    	r3, r6, #3
0x008180:	lsls    	r1, r4, #3
0x008182:	lsls    	r4, r3, #3
0x008184:	lsls    	r7, r2, #3
0x008186:	lsls    	r2, r2, #3
0x008188:	lsls    	r5, r1, #3
0x00818a:	lsls    	r1, r6, #2
0x00818c:	lsls    	r5, r5, #2
0x00818e:	lsls    	r0, r5, #2
0x008190:	lsls    	r3, r4, #2
0x008192:	lsls    	r6, r3, #2
0x008194:	lsls    	r7, r0, #2
0x008196:	lsls    	r2, r0, #2
0x008198:	lsls    	r5, r7, #1
0x00819a:	lsls    	r7, r6, #1
0x00819c:	lsls    	r2, r6, #1
0x00819e:	lsls    	r4, r5, #1
0x0081a0:	lsls    	r0, r5, #1
0x0081a2:	lsls    	r3, r4, #1
0x0081a4:	lsls    	r5, r3, #1
0x0081a6:	lsls    	r0, r3, #1
0x0081a8:	lsls    	r0, r2, #1
0x0081aa:	lsls    	r3, r1, #1
0x0081ac:	lsls    	r7, r0, #1
0x0081ae:	lsls    	r3, r0, #1
0x0081b0:	movs    	r7, r7
0x0081b2:	movs    	r2, r7
0x0081b4:	movs    	r5, r6
0x0081b6:	movs    	r0, r6
0x0081b8:	movs    	r1, r4
0x0081ba:	movs    	r2, #0
0x0081bc:	movs    	r1, #0
0x0081be:	str     	r2, [sp, #8]
0x0081c0:	movs    	r2, #0x61
0x0081c2:	str     	r1, [sp]
0x0081c4:	str     	r1, [sp, #4]
0x0081c6:	movs    	r1, #0x84
0x0081c8:	mvns    	r2, r2
0x0081ca:	movs    	r3, #0
0x0081cc:	adds    	r0, r6, #0
0x0081ce:	bl      	#0x8694
0x0081d2:	movs    	r0, #0
0x0081d4:	add     	sp, #0x1c
0x0081d6:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0083d8 =====
0x0083d8:	push    	{r4, r5, r6, lr}
0x0083da:	ldr     	r2, [pc, #0x1d8]
0x0083dc:	adds    	r1, r0, #0
0x0083de:	add     	r2, sb
0x0083e0:	subs    	r2, #0x48
0x0083e2:	ldr     	r0, [pc, #0x1d0]
0x0083e4:	movs    	r4, #0xf1
0x0083e6:	lsls    	r4, r4, #9
0x0083e8:	movs    	r3, #1
0x0083ea:	cmp     	r1, #0xf
0x0083ec:	ldr     	r5, [r2, #0x40]
0x0083ee:	sub     	sp, #0x10
0x0083f0:	add     	r0, sb
0x0083f2:	beq     	#0x8488
0x0083f4:	bgt     	#0x8424
0x0083f6:	cmp     	r1, #4
0x0083f8:	beq     	#0x8406
0x0083fa:	cmp     	r1, #5
0x0083fc:	beq     	#0x8430
0x0083fe:	cmp     	r1, #6
0x008400:	beq     	#0x8488
0x008402:	cmp     	r1, #0xe
0x008404:	bne     	#0x8420
0x008406:	cmp     	r5, #0
0x008408:	beq     	#0x8472
0x00840a:	movs    	r2, #0
0x00840c:	movs    	r1, #0
0x00840e:	str     	r1, [sp, #4]
0x008410:	str     	r2, [sp, #8]
0x008412:	movs    	r2, #3
0x008414:	movs    	r1, #0x29
0x008416:	str     	r0, [sp]
0x008418:	movs    	r3, #0
0x00841a:	adds    	r0, r4, #0
0x00841c:	bl      	#0x8694
0x008420:	add     	sp, #0x10
0x008422:	pop     	{r4, r5, r6, pc}

; ===== candidate_0085bc =====
0x0085bc:	push    	{r3, r4, r5, lr}
0x0085be:	ldr     	r4, [pc, #0x74]
0x0085c0:	add     	r4, pc
0x0085c2:	ldr     	r0, [r4, #0x38]
0x0085c4:	movs    	r1, #0x14
0x0085c6:	ldr     	r2, [r0, #0x64]
0x0085c8:	ldr     	r0, [pc, #0x6c]
0x0085ca:	add     	r0, pc
0x0085cc:	blx     	r2
0x0085ce:	movs    	r5, #0
0x0085d0:	mvns    	r5, r5
0x0085d2:	cmp     	r0, r5
0x0085d4:	bne     	#0x85da
0x0085d6:	adds    	r0, r5, #0
0x0085d8:	pop     	{r3, r4, r5, pc}

; ===== candidate_008644 =====
0x008644:	push    	{r4, lr}
0x008646:	sub     	sp, #0x10
0x008648:	lsls    	r0, r0, #0x18
0x00864a:	lsrs    	r0, r0, #0x18
0x00864c:	str     	r0, [sp]
0x00864e:	ldr     	r0, [pc, #0x38]
0x008650:	lsls    	r2, r2, #0x18
0x008652:	lsls    	r1, r1, #0x18
0x008654:	lsrs    	r1, r1, #0x18
0x008656:	lsrs    	r2, r2, #0x18
0x008658:	str     	r2, [sp, #8]
0x00865a:	str     	r1, [sp, #4]
0x00865c:	add     	r0, pc
0x00865e:	ldr     	r0, [r0, #0x38]
0x008660:	adds    	r1, r0, #0
0x008662:	adds    	r1, #0xff
0x008664:	adds    	r1, #0x41
0x008666:	ldr     	r2, [r1, #0x34]
0x008668:	ldr     	r1, [r1, #0x30]
0x00866a:	ldr     	r2, [r2]
0x00866c:	ldr     	r1, [r1]
0x00866e:	lsls    	r3, r2, #0x10
0x008670:	lsls    	r2, r1, #0x10
0x008672:	asrs    	r2, r2, #0x10
0x008674:	asrs    	r3, r3, #0x10
0x008676:	adds    	r0, #0xff
0x008678:	adds    	r0, #0xc1
0x00867a:	ldr     	r4, [r0, #0x28]
0x00867c:	movs    	r1, #0
0x00867e:	movs    	r0, #0
0x008680:	blx     	r4
0x008682:	add     	sp, #0x10
0x008684:	pop     	{r4, pc}

; ===== candidate_008694 =====
0x008694:	push    	{r4, r5, r6, r7, lr}
0x008696:	adds    	r5, r1, #0
0x008698:	adds    	r4, r0, #0
0x00869a:	adds    	r6, r2, #0
0x00869c:	ldr     	r2, [pc, #0x28]
0x00869e:	sub     	sp, #0x14
0x0086a0:	mov     	ip, r3
0x0086a2:	add     	r2, pc
0x0086a4:	ldr     	r0, [sp, #0x2c]
0x0086a6:	ldr     	r1, [sp, #0x30]
0x0086a8:	ldr     	r7, [sp, #0x28]
0x0086aa:	ldr     	r3, [r2, #0x3c]
0x0086ac:	movs    	r2, #2
0x0086ae:	str     	r2, [sp, #0xc]
0x0086b0:	str     	r1, [sp, #8]
0x0086b2:	str     	r0, [sp, #4]
0x0086b4:	str     	r7, [sp]
0x0086b6:	ldr     	r0, [r3, #0xc]
0x0086b8:	adds    	r1, r5, #0
0x0086ba:	adds    	r2, r6, #0
0x0086bc:	ldr     	r7, [r0, #0x28]
0x0086be:	adds    	r0, r4, #0
0x0086c0:	mov     	r3, ip
0x0086c2:	blx     	r7
0x0086c4:	add     	sp, #0x14
0x0086c6:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0086d0 =====
0x0086d0:	push    	{r4, lr}
0x0086d2:	movs    	r2, #0
0x0086d4:	add     	r0, pc
0x0086d6:	ldr     	r4, [r0, #0x3c]
0x0086d8:	sub     	sp, #0x10
0x0086da:	movs    	r1, #0
0x0086dc:	str     	r1, [sp, #4]
0x0086de:	str     	r1, [sp, #8]
0x0086e0:	str     	r2, [sp, #0xc]
0x0086e2:	str     	r2, [sp]
0x0086e4:	ldr     	r0, [r4, #0xc]
0x0086e6:	ldr     	r2, [r0, #0x24]
0x0086e8:	ldr     	r4, [r0, #0x28]
0x0086ea:	blx     	r4
0x0086ec:	add     	sp, #0x10
0x0086ee:	pop     	{r4, pc}

; ===== candidate_0086f4 =====
0x0086f4:	push    	{r4, lr}
0x0086f6:	ldr     	r0, [pc, #0x24]
0x0086f8:	sub     	sp, #0x10
0x0086fa:	add     	r0, pc
0x0086fc:	ldr     	r3, [r0, #0x3c]
0x0086fe:	movs    	r2, #0
0x008700:	movs    	r1, #0
0x008702:	str     	r1, [sp, #4]
0x008704:	str     	r1, [sp, #8]
0x008706:	str     	r2, [sp, #0xc]
0x008708:	str     	r2, [sp]
0x00870a:	ldr     	r0, [r3, #0xc]
0x00870c:	movs    	r3, #0
0x00870e:	ldr     	r2, [r0, #0x24]
0x008710:	ldr     	r4, [r0, #0x28]
0x008712:	movs    	r1, #1
0x008714:	blx     	r4
0x008716:	add     	sp, #0x10
0x008718:	pop     	{r4, pc}

; ===== candidate_008734 =====
0x008734:	push    	{r4, lr}
0x008736:	sub     	sp, #0x10
0x008738:	movs    	r2, #0
0x00873a:	movs    	r1, #0
0x00873c:	str     	r2, [sp, #8]
0x00873e:	ldr     	r2, [pc, #0x3c]
0x008740:	str     	r1, [sp]
0x008742:	str     	r1, [sp, #4]
0x008744:	movs    	r3, #0
0x008746:	add     	r2, pc
0x008748:	ldr     	r1, [pc, #0x34]
0x00874a:	ldr     	r0, [pc, #0x38]
0x00874c:	bl      	#0x8694
0x008750:	ldr     	r3, [pc, #0x38]
0x008752:	ldr     	r4, [pc, #0x34]
0x008754:	add     	r3, sb
0x008756:	ldr     	r3, [r3]
0x008758:	movs    	r2, #0x41
0x00875a:	movs    	r1, #0
0x00875c:	add     	r4, sb
0x00875e:	adds    	r0, r4, #0
0x008760:	blx     	r3
0x008762:	bl      	#0x8720
0x008766:	ldr     	r3, [pc, #0x28]
0x008768:	adds    	r1, r0, #0
0x00876a:	add     	r3, sb
0x00876c:	ldr     	r3, [r3]
0x00876e:	movs    	r2, #0x41
0x008770:	adds    	r0, r4, #0
0x008772:	blx     	r3
0x008774:	movs    	r0, #0
0x008776:	add     	sp, #0x10
0x008778:	pop     	{r4, pc}

; ===== candidate_008798 =====
0x008798:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00879a:	adds    	r7, r3, #0
0x00879c:	adds    	r6, r2, #0
0x00879e:	adds    	r5, r0, #0
0x0087a0:	ldr     	r0, [r0]
0x0087a2:	sub     	sp, #4
0x0087a4:	mov     	r1, sb
0x0087a6:	str     	r1, [sp]
0x0087a8:	movs    	r4, #0
0x0087aa:	blx     	#0x2e0
0x0087ae:	ldr     	r0, [sp, #8]
0x0087b0:	cmp     	r0, #0xb
0x0087b2:	bhs     	#0x8820
0x0087b4:	adr     	r3, #4
0x0087b6:	ldrb    	r3, [r3, r0]
0x0087b8:	lsls    	r3, r3, #1
0x0087ba:	add     	pc, r3
0x0087bc:	lsrs    	r5, r0, #0x1c
0x0087be:	subs    	r4, r3, #4
0x0087c0:	movs    	r4, #0x21
0x0087c2:	adds    	r1, #0x27
0x0087c4:	adds    	r1, #0x2b
0x0087c6:	movs    	r7, r5
0x0087c8:	ldr     	r1, [pc, #0x60]
0x0087ca:	ldr     	r0, [r5, #0xc]
0x0087cc:	add     	r1, sb
0x0087ce:	str     	r0, [r1, #0x14]
0x0087d0:	bl      	#0x30c
0x0087d4:	bl      	#0x8734
0x0087d8:	adds    	r4, r0, #0
0x0087da:	b       	#0x8820
0x0087dc:	ldr     	r0, [r6]
0x0087de:	cmp     	r0, #8
0x0087e0:	bne     	#0x87ea
0x0087e2:	bl      	#0x8690
0x0087e6:	adds    	r4, r0, #0
0x0087e8:	b       	#0x8820
0x0087ea:	ldr     	r1, [r6, #4]
0x0087ec:	ldr     	r2, [r6, #8]
0x0087ee:	bl      	#0x868c
0x0087f2:	adds    	r4, r0, #0
0x0087f4:	b       	#0x8820
0x0087f6:	bl      	#0x8a28
0x0087fa:	b       	#0x8820
0x0087fc:	str     	r7, [r5, #0xc]
0x0087fe:	b       	#0x8820
0x008800:	bl      	#0x8794
0x008804:	b       	#0x8820
0x008806:	bl      	#0x8864
0x00880a:	b       	#0x8820
0x00880c:	ldr     	r0, [pc, #0x1c]
0x00880e:	add     	r0, sb
0x008810:	str     	r7, [r0, #0x1c]
0x008812:	b       	#0x8820
0x008814:	ldr     	r0, [pc, #0x14]
0x008816:	add     	r0, sb
0x008818:	str     	r6, [r0, #0x20]
0x00881a:	b       	#0x8820
0x00881c:	ldr     	r4, [pc, #0x10]
0x00881e:	add     	r4, pc
0x008820:	ldr     	r1, [sp]
0x008822:	add     	sp, #0x14
0x008824:	adds    	r0, r4, #0
0x008826:	mov     	sb, r1
0x008828:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_008834 =====
0x008834:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x008836:	sub     	sp, #0xc
0x008838:	ldr     	r0, [sp, #0x38]
0x00883a:	ldr     	r4, [sp, #0x3c]
0x00883c:	ldr     	r6, [sp, #0x34]
0x00883e:	ldr     	r0, [r0]
0x008840:	mov     	r7, sb
0x008842:	movs    	r5, #0
0x008844:	blx     	#0x2e0
0x008848:	cmp     	r4, #0
0x00884a:	beq     	#0x885a
0x00884c:	ldr     	r1, [sp, #0x30]
0x00884e:	str     	r6, [sp, #4]
0x008850:	add     	r3, sp, #0xc
0x008852:	str     	r1, [sp]
0x008854:	ldm     	r3, {r0, r1, r2, r3}
0x008856:	blx     	r4
0x008858:	adds    	r5, r0, #0
0x00885a:	mov     	sb, r7
0x00885c:	adds    	r0, r5, #0
0x00885e:	add     	sp, #0x1c
0x008860:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0088c8 =====
0x0088c8:	push    	{r3, r4, r5, r6, r7, lr}
0x0088ca:	adds    	r4, r0, #0
0x0088cc:	ldr     	r0, [pc, #0x10c]
0x0088ce:	movs    	r5, #0
0x0088d0:	mvns    	r5, r5
0x0088d2:	mov     	ip, r2
0x0088d4:	add     	r0, pc
0x0088d6:	ldr     	r2, [r0, #0x38]
0x0088d8:	cmp     	r4, #0
0x0088da:	bne     	#0x88ec
0x0088dc:	ldr     	r0, [pc, #0x100]
0x0088de:	ldr     	r2, [r2, #0x68]
0x0088e0:	movs    	r1, #0x7d
0x0088e2:	lsls    	r1, r1, #3
0x0088e4:	add     	r0, pc
0x0088e6:	blx     	r2
0x0088e8:	adds    	r0, r5, #0
0x0088ea:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_0089f4 =====
0x0089f4:	push    	{r3, r4, r5, lr}
0x0089f6:	ldr     	r4, [pc, #0x28]
0x0089f8:	adds    	r5, r0, #0
0x0089fa:	add     	r4, pc
0x0089fc:	ldr     	r0, [r4, #0x38]
0x0089fe:	adds    	r0, #0x80
0x008a00:	ldr     	r0, [r0, #4]
0x008a02:	blx     	r0
0x008a04:	adds    	r0, r0, r5
0x008a06:	ldr     	r1, [pc, #0x1c]
0x008a08:	add     	r1, sb
0x008a0a:	str     	r0, [r1, #0x10]
0x008a0c:	ldr     	r0, [r4, #0x38]
0x008a0e:	adds    	r0, #0x80
0x008a10:	ldr     	r0, [r0]
0x008a12:	blx     	r0
0x008a14:	ldr     	r0, [r4, #0x38]
0x008a16:	ldr     	r1, [r0, #0x7c]
0x008a18:	lsls    	r0, r5, #0x10
0x008a1a:	lsrs    	r0, r0, #0x10
0x008a1c:	blx     	r1
0x008a1e:	pop     	{r3, r4, r5, pc}

; ===== candidate_008a2a =====
0x008a2a:	push    	{r3, r4, r5, r6, r7, lr}
0x008a2c:	add     	r0, pc
0x008a2e:	ldr     	r0, [r0, #0x38]
0x008a30:	adds    	r0, #0x80
0x008a32:	ldr     	r0, [r0, #4]
0x008a34:	blx     	r0
0x008a36:	movs    	r5, #0
0x008a38:	ldr     	r6, [pc, #0xc8]
0x008a3a:	add     	r6, sb
0x008a3c:	ldr     	r1, [r6, #0x10]
0x008a3e:	str     	r5, [r6, #0x10]
0x008a40:	subs    	r1, r0, r1
0x008a42:	ldr     	r0, [r6, #8]
0x008a44:	adds    	r3, r1, #0
0x008a46:	cmp     	r0, #0
0x008a48:	beq     	#0x8afe
0x008a4a:	ldr     	r2, [r0, #8]
0x008a4c:	cmp     	r2, #0
0x008a4e:	bne     	#0x8aae
0x008a50:	mvns    	r7, r2
0x008a52:	str     	r7, [r0, #8]
0x008a54:	ldr     	r2, [r0, #0x18]
0x008a56:	adds    	r4, r0, #0
0x008a58:	cmp     	r1, #0x32
0x008a5a:	str     	r2, [r6, #8]
0x008a5c:	bge     	#0x8a62
0x008a5e:	movs    	r1, #0x32
0x008a60:	b       	#0x8a7e
0x008a62:	movs    	r2, #0x7d
0x008a64:	lsls    	r2, r2, #4
0x008a66:	cmp     	r1, r2
0x008a68:	ble     	#0x8a7e
0x008a6a:	adds    	r1, r2, #0
0x008a6c:	b       	#0x8a7e
0x008a6e:	movs    	r7, #0
0x008a70:	mvns    	r7, r7
0x008a72:	str     	r7, [r2, #8]
0x008a74:	ldr     	r2, [r0, #0x18]
0x008a76:	str     	r2, [r0, #0x1c]
0x008a78:	ldr     	r0, [r2, #0x18]
0x008a7a:	str     	r0, [r6, #8]
0x008a7c:	adds    	r0, r2, #0
0x008a7e:	ldr     	r2, [r0, #0x18]
0x008a80:	cmp     	r2, #0
0x008a82:	beq     	#0x8a8a
0x008a84:	ldr     	r7, [r2, #8]
0x008a86:	cmp     	r7, r1
0x008a88:	blt     	#0x8a6e
0x008a8a:	str     	r5, [r0, #0x1c]
0x008a8c:	ldr     	r0, [r6, #8]
0x008a8e:	cmp     	r0, #0
0x008a90:	beq     	#0x8af2
0x008a92:	cmp     	r3, #0
0x008a94:	bge     	#0x8a98
0x008a96:	movs    	r3, #0
0x008a98:	ldr     	r0, [r6, #8]
0x008a9a:	ldr     	r1, [r0, #8]
0x008a9c:	cmp     	r1, #0
0x008a9e:	bge     	#0x8aa4
0x008aa0:	movs    	r1, #0
0x008aa2:	str     	r5, [r0, #8]
0x008aa4:	ldr     	r2, [pc, #0x60]
0x008aa6:	cmp     	r1, r2
0x008aa8:	ble     	#0x8ab2
0x008aaa:	adds    	r1, r2, #0
0x008aac:	b       	#0x8ab2
0x008aae:	movs    	r4, #0
0x008ab0:	b       	#0x8a92
0x008ab2:	ldr     	r2, [r0, #8]
0x008ab4:	subs    	r2, r2, r1
0x008ab6:	str     	r2, [r0, #8]
0x008ab8:	ldr     	r0, [r0, #0x18]
0x008aba:	cmp     	r0, #0
0x008abc:	bne     	#0x8ab2
0x008abe:	subs    	r0, r1, r3
0x008ac0:	cmp     	r0, #0
0x008ac2:	bgt     	#0x8ac6
0x008ac4:	movs    	r0, #0xa
0x008ac6:	bl      	#0x89f4
0x008aca:	b       	#0x8af2
0x008acc:	str     	r5, [r4, #8]
0x008ace:	ldr     	r0, [r4, #0x1c]
0x008ad0:	adds    	r3, r5, #0
0x008ad2:	str     	r0, [r6, #0xc]
0x008ad4:	ldr     	r0, [r4, #0x14]
0x008ad6:	cmp     	r0, #0
0x008ad8:	beq     	#0x8ae6
0x008ada:	str     	r0, [sp]
0x008adc:	movs    	r1, #0
0x008ade:	adds    	r0, r4, #0
0x008ae0:	ldr     	r2, [r4, #0x10]
0x008ae2:	bl      	#0x88c8
0x008ae6:	ldr     	r1, [r4, #0xc]
0x008ae8:	cmp     	r1, #0
0x008aea:	beq     	#0x8af0
0x008aec:	ldr     	r0, [r4, #0x10]
0x008aee:	blx     	r1
0x008af0:	ldr     	r4, [r6, #0xc]
0x008af2:	cmp     	r4, #0
0x008af4:	beq     	#0x8afc
0x008af6:	ldr     	r0, [r4, #8]
0x008af8:	cmp     	r0, #0
0x008afa:	blt     	#0x8acc
0x008afc:	str     	r5, [r6, #0xc]
0x008afe:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_008b0c =====
0x008b0c:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x008b0e:	sub     	sp, #0x14
0x008b10:	movs    	r1, #0
0x008b12:	movs    	r2, #0
0x008b14:	str     	r2, [sp, #8]
0x008b16:	str     	r1, [sp]
0x008b18:	str     	r1, [sp, #4]
0x008b1a:	movs    	r4, #0xf1
0x008b1c:	movs    	r5, #0
0x008b1e:	adds    	r3, r5, #0
0x008b20:	lsls    	r4, r4, #9
0x008b22:	movs    	r1, #0x14
0x008b24:	movs    	r2, #0x20
0x008b26:	adds    	r6, r0, #0
0x008b28:	adds    	r0, r4, #0
0x008b2a:	bl      	#0x8694
0x008b2e:	movs    	r1, #0
0x008b30:	str     	r1, [sp]
0x008b32:	str     	r1, [sp, #4]
0x008b34:	movs    	r2, #0
0x008b36:	movs    	r1, #0xe6
0x008b38:	adds    	r3, r5, #0
0x008b3a:	adds    	r0, r4, #0
0x008b3c:	str     	r2, [sp, #8]
0x008b3e:	bl      	#0x8694
0x008b42:	movs    	r1, #0
0x008b44:	str     	r1, [sp]
0x008b46:	str     	r1, [sp, #4]
0x008b48:	movs    	r2, #0
0x008b4a:	movs    	r1, #0x2c
0x008b4c:	adds    	r3, r5, #0
0x008b4e:	adds    	r0, r4, #0
0x008b50:	str     	r2, [sp, #8]
0x008b52:	bl      	#0x8694
0x008b56:	cmp     	r6, #0
0x008b58:	bne     	#0x8c38
0x008b5a:	movs    	r1, #0
0x008b5c:	movs    	r2, #0
0x008b5e:	str     	r2, [sp, #8]
0x008b60:	str     	r1, [sp]
0x008b62:	str     	r1, [sp, #4]
0x008b64:	movs    	r1, #0xe1
0x008b66:	movs    	r2, #6
0x008b68:	adds    	r7, r5, #0
0x008b6a:	adds    	r3, r5, #0
0x008b6c:	adds    	r0, r4, #0
0x008b6e:	bl      	#0x8694
0x008b72:	movs    	r1, #0
0x008b74:	movs    	r2, #0
0x008b76:	str     	r1, [sp]
0x008b78:	str     	r1, [sp, #4]
0x008b7a:	movs    	r1, #0x11
0x008b7c:	str     	r2, [sp, #8]
0x008b7e:	adds    	r6, r0, #0
0x008b80:	movs    	r3, #4
0x008b82:	adds    	r0, r4, #0
0x008b84:	ldr     	r2, [sp, #0x18]
0x008b86:	bl      	#0x8694
0x008b8a:	str     	r0, [sp, #0x10]
0x008b8c:	cmp     	r0, #0
0x008b8e:	ble     	#0x8c74
0x008b90:	ldr     	r1, [sp, #0x18]
0x008b92:	lsls    	r0, r5, #2
0x008b94:	ldr     	r4, [r1, r0]
0x008b96:	movs    	r1, #0
0x008b98:	movs    	r2, #0
0x008b9a:	str     	r2, [sp, #8]
0x008b9c:	str     	r1, [sp]
0x008b9e:	str     	r1, [sp, #4]
0x008ba0:	adds    	r3, r7, #0
0x008ba2:	adds    	r2, r4, #0
0x008ba4:	movs    	r1, #0x90
0x008ba6:	movs    	r0, #0xf1
0x008ba8:	lsls    	r0, r0, #9
0x008baa:	bl      	#0x8694
0x008bae:	adds    	r4, r0, #0
0x008bb0:	movs    	r1, #0
0x008bb2:	ldr     	r0, [pc, #0x180]
0x008bb4:	movs    	r2, #0
0x008bb6:	str     	r2, [sp, #8]
0x008bb8:	str     	r1, [sp]
0x008bba:	str     	r1, [sp, #4]
0x008bbc:	add     	r0, sb
0x008bbe:	ldr     	r3, [r0, #0x4c]
0x008bc0:	movs    	r0, #0xf1
0x008bc2:	movs    	r1, #0x14
0x008bc4:	movs    	r2, #6
0x008bc6:	lsls    	r0, r0, #9
0x008bc8:	bl      	#0x8694
0x008bcc:	ldrb    	r0, [r4, #0x1a]
0x008bce:	cmp     	r0, #1
0x008bd0:	bne     	#0x8c90
0x008bd2:	movs    	r1, #0
0x008bd4:	str     	r1, [sp]
0x008bd6:	str     	r1, [sp, #4]
0x008bd8:	movs    	r2, #0
0x008bda:	str     	r2, [sp, #8]
0x008bdc:	movs    	r1, #0xcb
0x008bde:	movs    	r3, #1
0x008be0:	movs    	r0, #0xf1
0x008be2:	lsls    	r0, r0, #9
0x008be4:	ldr     	r2, [r4, #4]
0x008be6:	bl      	#0x8694
0x008bea:	cmp     	r0, #0
0x008bec:	bne     	#0x8c3a
0x008bee:	movs    	r1, #0
0x008bf0:	movs    	r2, #0
0x008bf2:	str     	r2, [sp, #8]
0x008bf4:	str     	r1, [sp]
0x008bf6:	str     	r1, [sp, #4]
0x008bf8:	adds    	r3, r7, #0
0x008bfa:	adds    	r2, r4, #0
0x008bfc:	movs    	r1, #0xa9
0x008bfe:	movs    	r0, #0xf1
0x008c00:	lsls    	r0, r0, #9
0x008c02:	bl      	#0x8694
0x008c06:	movs    	r1, #0
0x008c08:	movs    	r2, #0
0x008c0a:	str     	r2, [sp, #8]
0x008c0c:	str     	r1, [sp]
0x008c0e:	str     	r1, [sp, #4]
0x008c10:	movs    	r1, #0x14
0x008c12:	movs    	r2, #6
0x008c14:	adds    	r3, r6, #0
0x008c16:	movs    	r0, #0xf1
0x008c18:	lsls    	r0, r0, #9
0x008c1a:	bl      	#0x8694
0x008c1e:	movs    	r1, #0
0x008c20:	movs    	r2, #0
0x008c22:	str     	r2, [sp, #8]
0x008c24:	str     	r1, [sp]
0x008c26:	str     	r1, [sp, #4]
0x008c28:	adds    	r3, r7, #0
0x008c2a:	adds    	r2, r4, #0
0x008c2c:	movs    	r1, #0x8f
0x008c2e:	movs    	r0, #0xf1
0x008c30:	lsls    	r0, r0, #9
0x008c32:	bl      	#0x8694
0x008c36:	b       	#0x8cd8
0x008c38:	b       	#0x8d1a
0x008c3a:	ldrh    	r1, [r0, #8]

; ===== candidate_008d40 =====
0x008d40:	push    	{r4, r5, r6, lr}
0x008d42:	sub     	sp, #0x10
0x008d44:	movs    	r1, #0
0x008d46:	movs    	r2, #0
0x008d48:	str     	r2, [sp, #8]
0x008d4a:	str     	r1, [sp]
0x008d4c:	str     	r1, [sp, #4]
0x008d4e:	movs    	r5, #0xf1
0x008d50:	movs    	r4, #0
0x008d52:	adds    	r3, r4, #0
0x008d54:	lsls    	r5, r5, #9
0x008d56:	movs    	r1, #0xe1
0x008d58:	movs    	r2, #0x80
0x008d5a:	adds    	r0, r5, #0
0x008d5c:	bl      	#0x8694
0x008d60:	cmp     	r0, #0
0x008d62:	beq     	#0x8da6
0x008d64:	movs    	r1, #0
0x008d66:	movs    	r2, #0
0x008d68:	str     	r2, [sp, #8]
0x008d6a:	str     	r1, [sp]
0x008d6c:	str     	r1, [sp, #4]
0x008d6e:	movs    	r1, #0xe1
0x008d70:	movs    	r2, #0x80
0x008d72:	adds    	r3, r4, #0
0x008d74:	adds    	r0, r5, #0
0x008d76:	bl      	#0x8694
0x008d7a:	movs    	r1, #0
0x008d7c:	movs    	r2, #0
0x008d7e:	str     	r2, [sp, #8]
0x008d80:	str     	r1, [sp]
0x008d82:	str     	r1, [sp, #4]
0x008d84:	movs    	r1, #6
0x008d86:	adds    	r2, r0, #0
0x008d88:	adds    	r3, r4, #0
0x008d8a:	adds    	r0, r5, #0
0x008d8c:	bl      	#0x8694
0x008d90:	movs    	r1, #0
0x008d92:	movs    	r2, #0
0x008d94:	str     	r2, [sp, #8]
0x008d96:	str     	r1, [sp]
0x008d98:	str     	r1, [sp, #4]
0x008d9a:	movs    	r1, #0x14
0x008d9c:	movs    	r2, #0x80
0x008d9e:	adds    	r3, r4, #0
0x008da0:	adds    	r0, r5, #0
0x008da2:	bl      	#0x8694
0x008da6:	movs    	r1, #0
0x008da8:	movs    	r2, #0
0x008daa:	str     	r2, [sp, #8]
0x008dac:	str     	r1, [sp]
0x008dae:	str     	r1, [sp, #4]
0x008db0:	movs    	r1, #0xe1
0x008db2:	movs    	r2, #0x9f
0x008db4:	adds    	r3, r4, #0
0x008db6:	adds    	r0, r5, #0
0x008db8:	bl      	#0x8694
0x008dbc:	cmp     	r0, #0
0x008dbe:	beq     	#0x8e06
0x008dc0:	movs    	r1, #0
0x008dc2:	movs    	r2, #0
0x008dc4:	str     	r2, [sp, #8]
0x008dc6:	str     	r1, [sp]
0x008dc8:	str     	r1, [sp, #4]
0x008dca:	movs    	r1, #0xe1
0x008dcc:	movs    	r2, #0x9f
0x008dce:	adds    	r3, r4, #0
0x008dd0:	adds    	r0, r5, #0
0x008dd2:	bl      	#0x8694
0x008dd6:	movs    	r2, #0
0x008dd8:	movs    	r1, #0
0x008dda:	str     	r2, [sp, #8]
0x008ddc:	adds    	r3, r4, #0
0x008dde:	adds    	r2, r0, #0
0x008de0:	str     	r1, [sp]
0x008de2:	str     	r1, [sp, #4]
0x008de4:	movs    	r1, #6
0x008de6:	movs    	r0, #0xf1
0x008de8:	lsls    	r0, r0, #9
0x008dea:	bl      	#0x8694
0x008dee:	movs    	r1, #0
0x008df0:	movs    	r2, #0
0x008df2:	str     	r2, [sp, #8]
0x008df4:	str     	r1, [sp]
0x008df6:	str     	r1, [sp, #4]
0x008df8:	movs    	r1, #0x14
0x008dfa:	movs    	r2, #0x9f
0x008dfc:	adds    	r3, r4, #0
0x008dfe:	movs    	r0, #0xf1
0x008e00:	lsls    	r0, r0, #9
0x008e02:	bl      	#0x8694
0x008e06:	add     	sp, #0x10
0x008e08:	pop     	{r4, r5, r6, pc}

; ===== candidate_008e0c =====
0x008e0c:	push    	{r4, r5, r6, r7, lr}
0x008e0e:	sub     	sp, #0xc
0x008e10:	movs    	r4, #0
0x008e12:	bl      	#0x8fe4
0x008e16:	movs    	r1, #0
0x008e18:	str     	r1, [sp]
0x008e1a:	str     	r1, [sp, #4]
0x008e1c:	movs    	r2, #0
0x008e1e:	movs    	r6, #0
0x008e20:	adds    	r3, r6, #0
0x008e22:	movs    	r1, #0x2c
0x008e24:	movs    	r0, #0xf1
0x008e26:	lsls    	r0, r0, #9
0x008e28:	str     	r2, [sp, #8]
0x008e2a:	bl      	#0x8694
0x008e2e:	movs    	r1, #0
0x008e30:	movs    	r2, #0
0x008e32:	str     	r2, [sp, #8]
0x008e34:	str     	r1, [sp]
0x008e36:	str     	r1, [sp, #4]
0x008e38:	movs    	r1, #0xe1
0x008e3a:	movs    	r2, #6
0x008e3c:	adds    	r3, r6, #0
0x008e3e:	movs    	r0, #0xf1
0x008e40:	lsls    	r0, r0, #9
0x008e42:	bl      	#0x8694
0x008e46:	movs    	r2, #0
0x008e48:	movs    	r1, #0
0x008e4a:	str     	r2, [sp, #8]
0x008e4c:	adds    	r2, r0, #0
0x008e4e:	str     	r1, [sp]
0x008e50:	str     	r1, [sp, #4]
0x008e52:	movs    	r1, #0x11
0x008e54:	movs    	r0, #0xf1
0x008e56:	movs    	r3, #4
0x008e58:	lsls    	r0, r0, #9
0x008e5a:	bl      	#0x8694
0x008e5e:	adds    	r7, r0, #0
0x008e60:	cmp     	r0, #0
0x008e62:	ble     	#0x8eb6
0x008e64:	movs    	r1, #0
0x008e66:	movs    	r2, #0
0x008e68:	str     	r2, [sp, #8]
0x008e6a:	str     	r1, [sp]
0x008e6c:	str     	r1, [sp, #4]
0x008e6e:	movs    	r1, #0xe1
0x008e70:	movs    	r2, #6
0x008e72:	adds    	r3, r6, #0
0x008e74:	movs    	r0, #0xf1
0x008e76:	lsls    	r0, r0, #9
0x008e78:	bl      	#0x8694
0x008e7c:	lsls    	r1, r4, #2
0x008e7e:	ldr     	r5, [r0, r1]
0x008e80:	movs    	r1, #0
0x008e82:	movs    	r2, #0
0x008e84:	str     	r2, [sp, #8]
0x008e86:	str     	r1, [sp]
0x008e88:	str     	r1, [sp, #4]
0x008e8a:	adds    	r3, r6, #0
0x008e8c:	adds    	r2, r5, #0
0x008e8e:	movs    	r1, #0xf2
0x008e90:	movs    	r0, #0xf1
0x008e92:	lsls    	r0, r0, #9
0x008e94:	bl      	#0x8694
0x008e98:	movs    	r1, #0
0x008e9a:	movs    	r2, #0
0x008e9c:	str     	r2, [sp, #8]
0x008e9e:	str     	r1, [sp]
0x008ea0:	str     	r1, [sp, #4]
0x008ea2:	adds    	r3, r6, #0
0x008ea4:	adds    	r2, r5, #0
0x008ea6:	movs    	r1, #9
0x008ea8:	movs    	r0, #0xf1
0x008eaa:	lsls    	r0, r0, #9
0x008eac:	bl      	#0x8694
0x008eb0:	adds    	r4, #1
0x008eb2:	cmp     	r4, r7
0x008eb4:	blt     	#0x8e64
0x008eb6:	movs    	r1, #0
0x008eb8:	movs    	r2, #0
0x008eba:	str     	r2, [sp, #8]
0x008ebc:	str     	r1, [sp]
0x008ebe:	str     	r1, [sp, #4]
0x008ec0:	movs    	r1, #0xe1
0x008ec2:	movs    	r2, #6
0x008ec4:	adds    	r3, r6, #0
0x008ec6:	movs    	r0, #0xf1
0x008ec8:	lsls    	r0, r0, #9
0x008eca:	bl      	#0x8694
0x008ece:	movs    	r2, #0
0x008ed0:	movs    	r1, #0
0x008ed2:	str     	r2, [sp, #8]
0x008ed4:	adds    	r3, r6, #0
0x008ed6:	adds    	r2, r0, #0
0x008ed8:	str     	r1, [sp]
0x008eda:	str     	r1, [sp, #4]
0x008edc:	movs    	r1, #9
0x008ede:	movs    	r0, #0xf1
0x008ee0:	lsls    	r0, r0, #9
0x008ee2:	bl      	#0x8694
0x008ee6:	movs    	r1, #0
0x008ee8:	movs    	r2, #0
0x008eea:	str     	r2, [sp, #8]
0x008eec:	str     	r1, [sp]
0x008eee:	str     	r1, [sp, #4]
0x008ef0:	movs    	r1, #0xe1
0x008ef2:	movs    	r2, #0xb1
0x008ef4:	adds    	r3, r6, #0
0x008ef6:	movs    	r0, #0xf1
0x008ef8:	lsls    	r0, r0, #9
0x008efa:	bl      	#0x8694
0x008efe:	movs    	r2, #0
0x008f00:	movs    	r1, #0
0x008f02:	str     	r2, [sp, #8]
0x008f04:	adds    	r3, r6, #0
0x008f06:	adds    	r2, r0, #0
0x008f08:	str     	r1, [sp]
0x008f0a:	str     	r1, [sp, #4]
0x008f0c:	movs    	r1, #9
0x008f0e:	movs    	r0, #0xf1
0x008f10:	lsls    	r0, r0, #9
0x008f12:	bl      	#0x8694
0x008f16:	movs    	r1, #0
0x008f18:	movs    	r2, #0
0x008f1a:	str     	r2, [sp, #8]
0x008f1c:	str     	r1, [sp]
0x008f1e:	str     	r1, [sp, #4]
0x008f20:	movs    	r1, #0x14
0x008f22:	movs    	r2, #0xb1
0x008f24:	adds    	r3, r6, #0
0x008f26:	movs    	r0, #0xf1
0x008f28:	lsls    	r0, r0, #9
0x008f2a:	bl      	#0x8694
0x008f2e:	movs    	r1, #0
0x008f30:	movs    	r2, #0
0x008f32:	str     	r2, [sp, #8]
0x008f34:	str     	r1, [sp]
0x008f36:	str     	r1, [sp, #4]
0x008f38:	ldr     	r4, [pc, #0x5c]
0x008f3a:	movs    	r1, #0x14
0x008f3c:	movs    	r2, #6

; ===== candidate_008f9c =====
0x008f9c:	push    	{r4, r5, r6, r7, lr}
0x008f9e:	sub     	sp, #0xc
0x008fa0:	movs    	r1, #0
0x008fa2:	str     	r1, [sp]
0x008fa4:	str     	r1, [sp, #4]
0x008fa6:	movs    	r5, #0xf1
0x008fa8:	movs    	r4, #0
0x008faa:	movs    	r2, #0
0x008fac:	adds    	r3, r4, #0
0x008fae:	lsls    	r5, r5, #9
0x008fb0:	movs    	r1, #0xe6
0x008fb2:	adds    	r0, r5, #0
0x008fb4:	str     	r2, [sp, #8]
0x008fb6:	bl      	#0x8694
0x008fba:	ldr     	r6, [pc, #0x24]
0x008fbc:	add     	r6, sb
0x008fbe:	ldr     	r7, [r6, #0x40]
0x008fc0:	cmp     	r7, #0
0x008fc2:	beq     	#0x8fdc
0x008fc4:	movs    	r1, #0
0x008fc6:	movs    	r2, #0
0x008fc8:	str     	r2, [sp, #8]
0x008fca:	str     	r1, [sp]
0x008fcc:	str     	r1, [sp, #4]
0x008fce:	movs    	r1, #0x5b
0x008fd0:	adds    	r2, r7, #0
0x008fd2:	adds    	r3, r4, #0
0x008fd4:	adds    	r0, r5, #0
0x008fd6:	bl      	#0x8694
0x008fda:	str     	r4, [r6, #0x40]
0x008fdc:	add     	sp, #0xc
0x008fde:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_008fe4 =====
0x008fe4:	push    	{r4, r5, r6, lr}
0x008fe6:	sub     	sp, #0x10
0x008fe8:	movs    	r1, #0
0x008fea:	movs    	r2, #0
0x008fec:	str     	r2, [sp, #8]
0x008fee:	str     	r1, [sp]
0x008ff0:	str     	r1, [sp, #4]
0x008ff2:	movs    	r5, #0xf1
0x008ff4:	movs    	r4, #0
0x008ff6:	adds    	r3, r4, #0
0x008ff8:	lsls    	r5, r5, #9
0x008ffa:	movs    	r1, #0xe1
0x008ffc:	movs    	r2, #0xbc
0x008ffe:	adds    	r0, r5, #0
0x009000:	bl      	#0x8694
0x009004:	cmp     	r0, #0
0x009006:	beq     	#0x904a
0x009008:	movs    	r1, #0
0x00900a:	movs    	r2, #0
0x00900c:	str     	r2, [sp, #8]
0x00900e:	str     	r1, [sp]
0x009010:	str     	r1, [sp, #4]
0x009012:	movs    	r1, #0xe1
0x009014:	movs    	r2, #0xbc
0x009016:	adds    	r3, r4, #0
0x009018:	adds    	r0, r5, #0
0x00901a:	bl      	#0x8694
0x00901e:	movs    	r1, #0
0x009020:	movs    	r2, #0
0x009022:	str     	r2, [sp, #8]
0x009024:	str     	r1, [sp]
0x009026:	str     	r1, [sp, #4]
0x009028:	movs    	r1, #9
0x00902a:	adds    	r2, r0, #0
0x00902c:	adds    	r3, r4, #0
0x00902e:	adds    	r0, r5, #0
0x009030:	bl      	#0x8694
0x009034:	movs    	r1, #0
0x009036:	movs    	r2, #0
0x009038:	str     	r2, [sp, #8]
0x00903a:	str     	r1, [sp]
0x00903c:	str     	r1, [sp, #4]
0x00903e:	movs    	r1, #0x14
0x009040:	movs    	r2, #0xbc
0x009042:	adds    	r3, r4, #0
0x009044:	adds    	r0, r5, #0
0x009046:	bl      	#0x8694
0x00904a:	movs    	r1, #0
0x00904c:	movs    	r2, #0
0x00904e:	str     	r2, [sp, #8]
0x009050:	str     	r1, [sp]
0x009052:	str     	r1, [sp, #4]
0x009054:	movs    	r1, #0x14
0x009056:	movs    	r2, #0xbe
0x009058:	movs    	r3, #1
0x00905a:	adds    	r0, r5, #0
0x00905c:	bl      	#0x8694
0x009060:	movs    	r1, #0
0x009062:	str     	r1, [sp]
0x009064:	str     	r1, [sp, #4]
0x009066:	movs    	r2, #0
0x009068:	movs    	r1, #0xe6
0x00906a:	adds    	r3, r4, #0
0x00906c:	movs    	r0, #0xf1
0x00906e:	lsls    	r0, r0, #9
0x009070:	str     	r2, [sp, #8]
0x009072:	bl      	#0x8694
0x009076:	bl      	#0x90b0
0x00907a:	movs    	r1, #0
0x00907c:	str     	r1, [sp]
0x00907e:	str     	r1, [sp, #4]
0x009080:	movs    	r2, #0
0x009082:	movs    	r1, #0x69
0x009084:	adds    	r3, r4, #0
0x009086:	movs    	r0, #0xf1
0x009088:	lsls    	r0, r0, #9
0x00908a:	str     	r2, [sp, #8]
0x00908c:	bl      	#0x8694
0x009090:	movs    	r2, #0
0x009092:	movs    	r1, #0
0x009094:	str     	r2, [sp, #8]
0x009096:	movs    	r2, #0xff
0x009098:	str     	r1, [sp]
0x00909a:	str     	r1, [sp, #4]
0x00909c:	adds    	r3, r4, #0
0x00909e:	adds    	r2, #0x17
0x0090a0:	movs    	r1, #0x14
0x0090a2:	movs    	r0, #0xf1
0x0090a4:	lsls    	r0, r0, #9
0x0090a6:	bl      	#0x8694
0x0090aa:	add     	sp, #0x10
0x0090ac:	pop     	{r4, r5, r6, pc}

; ===== candidate_0090b0 =====
0x0090b0:	push    	{r4, r5, r6, lr}
0x0090b2:	ldr     	r5, [pc, #0x2c]
0x0090b4:	sub     	sp, #0x10
0x0090b6:	add     	r5, sb
0x0090b8:	ldr     	r6, [r5, #8]
0x0090ba:	cmp     	r6, #0
0x0090bc:	beq     	#0x90da
0x0090be:	movs    	r1, #0
0x0090c0:	movs    	r2, #0
0x0090c2:	movs    	r4, #0
0x0090c4:	adds    	r3, r4, #0
0x0090c6:	str     	r2, [sp, #8]
0x0090c8:	str     	r1, [sp]
0x0090ca:	str     	r1, [sp, #4]
0x0090cc:	movs    	r1, #0x12
0x0090ce:	adds    	r2, r6, #0
0x0090d0:	movs    	r0, #0xf1
0x0090d2:	lsls    	r0, r0, #9
0x0090d4:	bl      	#0x8694
0x0090d8:	str     	r4, [r5, #8]
0x0090da:	add     	sp, #0x10
0x0090dc:	pop     	{r4, r5, r6, pc}

; ===== candidate_0090e6 =====
0x0090e6:	push    	{r4, r5, r6, r7, lr}
0x0090e8:	movs    	r1, #0
0x0090ea:	sub     	sp, #0xc
0x0090ec:	subs    	r0, #2
0x0090ee:	add     	r2, sb
0x0090f0:	strb    	r1, [r2, #2]
0x0090f2:	cmp     	r0, #0x13
0x0090f4:	bhs     	#0x9100
0x0090f6:	adr     	r3, #0xc
0x0090f8:	adds    	r3, r3, r0
0x0090fa:	ldrh    	r3, [r3, r0]
0x0090fc:	lsls    	r3, r3, #1
0x0090fe:	add     	pc, r3
0x009100:	add     	sp, #0xc
0x009102:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00951c =====
0x00951c:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x00951e:	sub     	sp, #0x14
0x009520:	movs    	r1, #0
0x009522:	movs    	r4, #0
0x009524:	movs    	r2, #0
0x009526:	str     	r2, [sp, #8]
0x009528:	adds    	r3, r4, #0
0x00952a:	adds    	r6, r0, #0
0x00952c:	adds    	r2, r0, #0
0x00952e:	str     	r1, [sp]
0x009530:	str     	r1, [sp, #4]
0x009532:	movs    	r1, #0x90
0x009534:	movs    	r0, #0xf1
0x009536:	movs    	r5, #0x1c
0x009538:	lsls    	r0, r0, #9
0x00953a:	bl      	#0x8694
0x00953e:	movs    	r1, #0
0x009540:	movs    	r2, #0
0x009542:	str     	r2, [sp, #8]
0x009544:	str     	r1, [sp]
0x009546:	str     	r1, [sp, #4]
0x009548:	adds    	r3, r4, #0
0x00954a:	adds    	r2, r5, #0
0x00954c:	movs    	r1, #0x17
0x00954e:	movs    	r0, #0xf1
0x009550:	lsls    	r0, r0, #9
0x009552:	bl      	#0x8694
0x009556:	movs    	r1, #0
0x009558:	movs    	r2, #0
0x00955a:	str     	r2, [sp, #8]
0x00955c:	str     	r1, [sp]
0x00955e:	str     	r1, [sp, #4]
0x009560:	movs    	r1, #0xe1
0x009562:	movs    	r2, #0x1d
0x009564:	adds    	r3, r4, #0
0x009566:	movs    	r0, #0xf1
0x009568:	lsls    	r0, r0, #9
0x00956a:	bl      	#0x8694
0x00956e:	movs    	r1, #0
0x009570:	movs    	r2, #0
0x009572:	str     	r2, [sp, #8]
0x009574:	str     	r1, [sp]
0x009576:	str     	r1, [sp, #4]
0x009578:	str     	r0, [sp, #0x10]
0x00957a:	movs    	r0, #0xf1
0x00957c:	movs    	r1, #0xe1
0x00957e:	movs    	r2, #0x18
0x009580:	adds    	r3, r4, #0
0x009582:	lsls    	r0, r0, #9
0x009584:	bl      	#0x8694
0x009588:	ldr     	r7, [r0, #0xc]
0x00958a:	movs    	r1, #0
0x00958c:	movs    	r2, #0
0x00958e:	str     	r2, [sp, #8]
0x009590:	str     	r1, [sp]
0x009592:	str     	r1, [sp, #4]
0x009594:	movs    	r1, #0xe1
0x009596:	movs    	r2, #0x18
0x009598:	movs    	r0, #0xf1
0x00959a:	adds    	r3, r4, #0
0x00959c:	lsls    	r0, r0, #9
0x00959e:	bl      	#0x8694
0x0095a2:	ldr     	r3, [r0, #8]
0x0095a4:	ldr     	r1, [sp, #0x10]
0x0095a6:	movs    	r2, #0
0x0095a8:	str     	r2, [sp, #8]
0x0095aa:	str     	r1, [sp, #4]
0x0095ac:	movs    	r1, #0x52
0x0095ae:	adds    	r2, r5, #0
0x0095b0:	movs    	r0, #0xf1
0x0095b2:	lsls    	r0, r0, #9
0x0095b4:	str     	r7, [sp]
0x0095b6:	bl      	#0x8694
0x0095ba:	movs    	r1, #0
0x0095bc:	movs    	r2, #0
0x0095be:	str     	r2, [sp, #8]
0x0095c0:	str     	r1, [sp]
0x0095c2:	str     	r1, [sp, #4]
0x0095c4:	adds    	r3, r4, #0
0x0095c6:	adds    	r2, r6, #0
0x0095c8:	movs    	r1, #0x19
0x0095ca:	movs    	r0, #0xf1
0x0095cc:	lsls    	r0, r0, #9
0x0095ce:	bl      	#0x8694
0x0095d2:	movs    	r1, #0
0x0095d4:	str     	r1, [sp]
0x0095d6:	str     	r1, [sp, #4]
0x0095d8:	movs    	r2, #0
0x0095da:	movs    	r1, #0x19
0x0095dc:	adds    	r3, r4, #0
0x0095de:	movs    	r0, #0xf1
0x0095e0:	lsls    	r0, r0, #9
0x0095e2:	str     	r2, [sp, #8]
0x0095e4:	bl      	#0x8694
0x0095e8:	movs    	r1, #0
0x0095ea:	movs    	r2, #0
0x0095ec:	str     	r2, [sp, #8]
0x0095ee:	str     	r1, [sp]
0x0095f0:	str     	r1, [sp, #4]
0x0095f2:	movs    	r1, #0x1b
0x0095f4:	movs    	r2, #1
0x0095f6:	adds    	r3, r4, #0
0x0095f8:	movs    	r0, #0xf1
0x0095fa:	lsls    	r0, r0, #9
0x0095fc:	bl      	#0x8694
0x009600:	ldr     	r1, [pc, #8]
0x009602:	ldr     	r0, [sp, #0x18]
0x009604:	add     	r1, sb
0x009606:	str     	r0, [r1, #0x2c]
0x009608:	add     	sp, #0x1c
0x00960a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_009610 =====
0x009610:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x009612:	sub     	sp, #0xc
0x009614:	movs    	r1, #0
0x009616:	movs    	r4, #0
0x009618:	movs    	r2, #0
0x00961a:	str     	r2, [sp, #8]
0x00961c:	adds    	r3, r4, #0
0x00961e:	str     	r1, [sp]
0x009620:	str     	r1, [sp, #4]
0x009622:	movs    	r5, #0x43
0x009624:	adds    	r2, r5, #0
0x009626:	movs    	r1, #0x17
0x009628:	movs    	r0, #0xf1
0x00962a:	lsls    	r0, r0, #9
0x00962c:	bl      	#0x8694
0x009630:	movs    	r1, #0
0x009632:	movs    	r2, #0
0x009634:	str     	r2, [sp, #8]
0x009636:	str     	r1, [sp]
0x009638:	str     	r1, [sp, #4]
0x00963a:	movs    	r1, #0xe1
0x00963c:	movs    	r2, #0x1d
0x00963e:	adds    	r3, r4, #0
0x009640:	movs    	r0, #0xf1
0x009642:	lsls    	r0, r0, #9
0x009644:	bl      	#0x8694
0x009648:	movs    	r1, #0
0x00964a:	adds    	r6, r0, #0
0x00964c:	movs    	r2, #0
0x00964e:	str     	r2, [sp, #8]
0x009650:	str     	r1, [sp]
0x009652:	str     	r1, [sp, #4]
0x009654:	movs    	r1, #0xe1
0x009656:	movs    	r2, #0x18
0x009658:	movs    	r0, #0xf1
0x00965a:	adds    	r3, r4, #0
0x00965c:	lsls    	r0, r0, #9
0x00965e:	bl      	#0x8694
0x009662:	ldr     	r7, [r0, #0xc]
0x009664:	movs    	r1, #0
0x009666:	movs    	r2, #0
0x009668:	str     	r2, [sp, #8]
0x00966a:	str     	r1, [sp]
0x00966c:	str     	r1, [sp, #4]
0x00966e:	movs    	r1, #0xe1
0x009670:	movs    	r2, #0x18
0x009672:	movs    	r0, #0xf1
0x009674:	adds    	r3, r4, #0
0x009676:	lsls    	r0, r0, #9
0x009678:	bl      	#0x8694
0x00967c:	ldr     	r3, [r0, #8]
0x00967e:	movs    	r2, #0
0x009680:	str     	r2, [sp, #8]
0x009682:	adds    	r2, r5, #0
0x009684:	movs    	r0, #0xf1
0x009686:	movs    	r1, #0x52
0x009688:	lsls    	r0, r0, #9
0x00968a:	str     	r7, [sp]
0x00968c:	str     	r6, [sp, #4]
0x00968e:	bl      	#0x8694
0x009692:	movs    	r1, #0
0x009694:	movs    	r2, #0
0x009696:	str     	r1, [sp]
0x009698:	str     	r1, [sp, #4]
0x00969a:	movs    	r1, #0x19
0x00969c:	str     	r2, [sp, #8]
0x00969e:	adds    	r3, r4, #0
0x0096a0:	movs    	r0, #0xf1
0x0096a2:	lsls    	r0, r0, #9
0x0096a4:	ldr     	r2, [sp, #0xc]
0x0096a6:	bl      	#0x8694
0x0096aa:	movs    	r1, #0
0x0096ac:	movs    	r2, #0
0x0096ae:	str     	r1, [sp]
0x0096b0:	str     	r1, [sp, #4]
0x0096b2:	movs    	r1, #0x19
0x0096b4:	str     	r2, [sp, #8]
0x0096b6:	adds    	r3, r4, #0
0x0096b8:	movs    	r0, #0xf1
0x0096ba:	lsls    	r0, r0, #9
0x0096bc:	ldr     	r2, [sp, #0x10]
0x0096be:	bl      	#0x8694
0x0096c2:	movs    	r1, #0
0x0096c4:	movs    	r2, #0
0x0096c6:	str     	r2, [sp, #8]
0x0096c8:	str     	r1, [sp]
0x0096ca:	str     	r1, [sp, #4]
0x0096cc:	movs    	r1, #0x1b
0x0096ce:	movs    	r2, #1
0x0096d0:	adds    	r3, r4, #0
0x0096d2:	movs    	r0, #0xf1
0x0096d4:	lsls    	r0, r0, #9
0x0096d6:	bl      	#0x8694
0x0096da:	add     	sp, #0x14
0x0096dc:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0096e0 =====
0x0096e0:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x0096e2:	sub     	sp, #0xc
0x0096e4:	movs    	r1, #0
0x0096e6:	movs    	r4, #0
0x0096e8:	movs    	r2, #0
0x0096ea:	str     	r2, [sp, #8]
0x0096ec:	adds    	r3, r4, #0
0x0096ee:	str     	r1, [sp]
0x0096f0:	str     	r1, [sp, #4]
0x0096f2:	movs    	r5, #0x8e
0x0096f4:	adds    	r2, r5, #0
0x0096f6:	movs    	r1, #0x17
0x0096f8:	movs    	r0, #0xf1
0x0096fa:	lsls    	r0, r0, #9
0x0096fc:	bl      	#0x8694
0x009700:	movs    	r1, #0
0x009702:	movs    	r2, #0
0x009704:	str     	r2, [sp, #8]
0x009706:	str     	r1, [sp]
0x009708:	str     	r1, [sp, #4]
0x00970a:	movs    	r1, #0xe1
0x00970c:	movs    	r2, #0x1d
0x00970e:	adds    	r3, r4, #0
0x009710:	movs    	r0, #0xf1
0x009712:	lsls    	r0, r0, #9
0x009714:	bl      	#0x8694
0x009718:	movs    	r1, #0
0x00971a:	adds    	r6, r0, #0
0x00971c:	movs    	r2, #0
0x00971e:	str     	r2, [sp, #8]
0x009720:	str     	r1, [sp]
0x009722:	str     	r1, [sp, #4]
0x009724:	movs    	r1, #0xe1
0x009726:	movs    	r2, #0x18
0x009728:	movs    	r0, #0xf1
0x00972a:	adds    	r3, r4, #0
0x00972c:	lsls    	r0, r0, #9
0x00972e:	bl      	#0x8694
0x009732:	ldr     	r7, [r0, #0xc]
0x009734:	movs    	r1, #0
0x009736:	movs    	r2, #0
0x009738:	str     	r2, [sp, #8]
0x00973a:	str     	r1, [sp]
0x00973c:	str     	r1, [sp, #4]
0x00973e:	movs    	r1, #0xe1
0x009740:	movs    	r2, #0x18
0x009742:	movs    	r0, #0xf1
0x009744:	adds    	r3, r4, #0
0x009746:	lsls    	r0, r0, #9
0x009748:	bl      	#0x8694
0x00974c:	ldr     	r3, [r0, #8]
0x00974e:	movs    	r2, #0
0x009750:	str     	r2, [sp, #8]
0x009752:	adds    	r2, r5, #0
0x009754:	movs    	r0, #0xf1
0x009756:	movs    	r1, #0x52
0x009758:	lsls    	r0, r0, #9
0x00975a:	str     	r7, [sp]
0x00975c:	str     	r6, [sp, #4]
0x00975e:	bl      	#0x8694
0x009762:	movs    	r1, #0
0x009764:	movs    	r2, #0
0x009766:	str     	r1, [sp]
0x009768:	str     	r1, [sp, #4]
0x00976a:	movs    	r1, #0x19
0x00976c:	str     	r2, [sp, #8]
0x00976e:	adds    	r3, r4, #0
0x009770:	movs    	r0, #0xf1
0x009772:	lsls    	r0, r0, #9
0x009774:	ldr     	r2, [sp, #0x10]
0x009776:	bl      	#0x8694
0x00977a:	movs    	r1, #0
0x00977c:	movs    	r2, #0
0x00977e:	str     	r1, [sp]
0x009780:	str     	r1, [sp, #4]
0x009782:	movs    	r1, #0x19
0x009784:	str     	r2, [sp, #8]
0x009786:	adds    	r3, r4, #0
0x009788:	movs    	r0, #0xf1
0x00978a:	lsls    	r0, r0, #9
0x00978c:	ldr     	r2, [sp, #0xc]
0x00978e:	bl      	#0x8694
0x009792:	movs    	r1, #0
0x009794:	movs    	r2, #0
0x009796:	str     	r2, [sp, #8]
0x009798:	str     	r1, [sp]
0x00979a:	str     	r1, [sp, #4]
0x00979c:	movs    	r1, #0x1b
0x00979e:	movs    	r2, #1
0x0097a0:	adds    	r3, r4, #0
0x0097a2:	movs    	r0, #0xf1
0x0097a4:	lsls    	r0, r0, #9
0x0097a6:	bl      	#0x8694
0x0097aa:	add     	sp, #0x14
0x0097ac:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0097b0 =====
0x0097b0:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0097b2:	sub     	sp, #0xc
0x0097b4:	movs    	r1, #0
0x0097b6:	movs    	r2, #0
0x0097b8:	movs    	r4, #0
0x0097ba:	adds    	r3, r4, #0
0x0097bc:	str     	r2, [sp, #8]
0x0097be:	str     	r1, [sp]
0x0097c0:	str     	r1, [sp, #4]
0x0097c2:	movs    	r5, #0x41
0x0097c4:	adds    	r2, r5, #0
0x0097c6:	movs    	r1, #0x17
0x0097c8:	movs    	r0, #0xf1
0x0097ca:	lsls    	r0, r0, #9
0x0097cc:	bl      	#0x8694
0x0097d0:	movs    	r1, #0
0x0097d2:	movs    	r2, #0
0x0097d4:	str     	r2, [sp, #8]
0x0097d6:	str     	r1, [sp]
0x0097d8:	str     	r1, [sp, #4]
0x0097da:	movs    	r1, #0xe1
0x0097dc:	movs    	r2, #0x1d
0x0097de:	adds    	r3, r4, #0
0x0097e0:	movs    	r0, #0xf1
0x0097e2:	lsls    	r0, r0, #9
0x0097e4:	bl      	#0x8694
0x0097e8:	movs    	r1, #0
0x0097ea:	adds    	r6, r0, #0
0x0097ec:	movs    	r2, #0
0x0097ee:	str     	r2, [sp, #8]
0x0097f0:	str     	r1, [sp]
0x0097f2:	str     	r1, [sp, #4]
0x0097f4:	movs    	r1, #0xe1
0x0097f6:	movs    	r2, #0x18
0x0097f8:	movs    	r0, #0xf1
0x0097fa:	adds    	r3, r4, #0
0x0097fc:	lsls    	r0, r0, #9
0x0097fe:	bl      	#0x8694
0x009802:	ldr     	r7, [r0, #0xc]
0x009804:	movs    	r1, #0
0x009806:	movs    	r2, #0
0x009808:	str     	r2, [sp, #8]
0x00980a:	str     	r1, [sp]
0x00980c:	str     	r1, [sp, #4]
0x00980e:	movs    	r1, #0xe1
0x009810:	movs    	r2, #0x18
0x009812:	movs    	r0, #0xf1
0x009814:	adds    	r3, r4, #0
0x009816:	lsls    	r0, r0, #9
0x009818:	bl      	#0x8694
0x00981c:	ldr     	r3, [r0, #8]
0x00981e:	movs    	r2, #0
0x009820:	str     	r2, [sp, #8]
0x009822:	adds    	r2, r5, #0
0x009824:	movs    	r0, #0xf1
0x009826:	movs    	r1, #0x52
0x009828:	lsls    	r0, r0, #9
0x00982a:	str     	r7, [sp]
0x00982c:	str     	r6, [sp, #4]
0x00982e:	bl      	#0x8694
0x009832:	movs    	r1, #0
0x009834:	movs    	r2, #0
0x009836:	str     	r1, [sp]
0x009838:	str     	r1, [sp, #4]
0x00983a:	movs    	r1, #0x19
0x00983c:	str     	r2, [sp, #8]
0x00983e:	adds    	r3, r4, #0
0x009840:	movs    	r0, #0xf1
0x009842:	lsls    	r0, r0, #9
0x009844:	ldr     	r2, [sp, #0xc]
0x009846:	bl      	#0x8694
0x00984a:	movs    	r1, #0
0x00984c:	movs    	r2, #0
0x00984e:	str     	r1, [sp]
0x009850:	str     	r1, [sp, #4]
0x009852:	movs    	r1, #0x19
0x009854:	str     	r2, [sp, #8]
0x009856:	adds    	r3, r4, #0
0x009858:	movs    	r0, #0xf1
0x00985a:	lsls    	r0, r0, #9
0x00985c:	ldr     	r2, [sp, #0x10]
0x00985e:	bl      	#0x8694
0x009862:	movs    	r1, #0
0x009864:	movs    	r2, #0
0x009866:	str     	r1, [sp]
0x009868:	str     	r1, [sp, #4]
0x00986a:	movs    	r1, #0x19
0x00986c:	str     	r2, [sp, #8]
0x00986e:	adds    	r3, r4, #0
0x009870:	movs    	r0, #0xf1
0x009872:	lsls    	r0, r0, #9
0x009874:	ldr     	r2, [sp, #0x14]
0x009876:	bl      	#0x8694
0x00987a:	movs    	r1, #0
0x00987c:	movs    	r2, #0
0x00987e:	str     	r1, [sp]
0x009880:	str     	r1, [sp, #4]
0x009882:	movs    	r1, #0x19
0x009884:	str     	r2, [sp, #8]
0x009886:	adds    	r3, r4, #0
0x009888:	movs    	r0, #0xf1
0x00988a:	lsls    	r0, r0, #9
0x00988c:	ldr     	r2, [sp, #0x18]
0x00988e:	bl      	#0x8694
0x009892:	movs    	r1, #0
0x009894:	movs    	r2, #0
0x009896:	str     	r2, [sp, #8]
0x009898:	str     	r1, [sp]
0x00989a:	str     	r1, [sp, #4]
0x00989c:	movs    	r1, #0x1b
0x00989e:	movs    	r2, #1
0x0098a0:	adds    	r3, r4, #0
0x0098a2:	movs    	r0, #0xf1
0x0098a4:	lsls    	r0, r0, #9
0x0098a6:	bl      	#0x8694
0x0098aa:	add     	sp, #0x1c
0x0098ac:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0098b0 =====
0x0098b0:	push    	{r0, r4, r5, r6, r7, lr}
0x0098b2:	sub     	sp, #0x10
0x0098b4:	movs    	r1, #0
0x0098b6:	movs    	r4, #0
0x0098b8:	movs    	r2, #0
0x0098ba:	str     	r2, [sp, #8]
0x0098bc:	adds    	r3, r4, #0
0x0098be:	str     	r1, [sp]
0x0098c0:	str     	r1, [sp, #4]
0x0098c2:	movs    	r5, #0x44
0x0098c4:	adds    	r2, r5, #0
0x0098c6:	movs    	r1, #0x17
0x0098c8:	movs    	r0, #0xf1
0x0098ca:	lsls    	r0, r0, #9
0x0098cc:	bl      	#0x8694
0x0098d0:	movs    	r1, #0
0x0098d2:	movs    	r2, #0
0x0098d4:	str     	r2, [sp, #8]
0x0098d6:	str     	r1, [sp]
0x0098d8:	str     	r1, [sp, #4]
0x0098da:	movs    	r1, #0xe1
0x0098dc:	movs    	r2, #0x1d
0x0098de:	adds    	r3, r4, #0
0x0098e0:	movs    	r0, #0xf1
0x0098e2:	lsls    	r0, r0, #9
0x0098e4:	bl      	#0x8694
0x0098e8:	movs    	r1, #0
0x0098ea:	adds    	r6, r0, #0
0x0098ec:	movs    	r2, #0
0x0098ee:	str     	r2, [sp, #8]
0x0098f0:	str     	r1, [sp]
0x0098f2:	str     	r1, [sp, #4]
0x0098f4:	movs    	r1, #0xe1
0x0098f6:	movs    	r2, #0x18
0x0098f8:	movs    	r0, #0xf1
0x0098fa:	adds    	r3, r4, #0
0x0098fc:	lsls    	r0, r0, #9
0x0098fe:	bl      	#0x8694
0x009902:	ldr     	r7, [r0, #0xc]
0x009904:	movs    	r1, #0
0x009906:	movs    	r2, #0
0x009908:	str     	r2, [sp, #8]
0x00990a:	str     	r1, [sp]
0x00990c:	str     	r1, [sp, #4]
0x00990e:	movs    	r1, #0xe1
0x009910:	movs    	r2, #0x18
0x009912:	movs    	r0, #0xf1
0x009914:	adds    	r3, r4, #0
0x009916:	lsls    	r0, r0, #9
0x009918:	bl      	#0x8694
0x00991c:	ldr     	r3, [r0, #8]
0x00991e:	movs    	r2, #0
0x009920:	str     	r2, [sp, #8]
0x009922:	adds    	r2, r5, #0
0x009924:	movs    	r0, #0xf1
0x009926:	movs    	r1, #0x52
0x009928:	lsls    	r0, r0, #9
0x00992a:	str     	r7, [sp]
0x00992c:	str     	r6, [sp, #4]
0x00992e:	bl      	#0x8694
0x009932:	movs    	r1, #0
0x009934:	movs    	r2, #0
0x009936:	str     	r1, [sp]
0x009938:	str     	r1, [sp, #4]
0x00993a:	movs    	r1, #0x19
0x00993c:	str     	r2, [sp, #8]
0x00993e:	adds    	r3, r4, #0
0x009940:	movs    	r0, #0xf1
0x009942:	lsls    	r0, r0, #9
0x009944:	ldr     	r2, [sp, #0x10]
0x009946:	bl      	#0x8694
0x00994a:	movs    	r1, #0
0x00994c:	movs    	r2, #0
0x00994e:	str     	r2, [sp, #8]
0x009950:	str     	r1, [sp]
0x009952:	str     	r1, [sp, #4]
0x009954:	movs    	r1, #0x1b
0x009956:	movs    	r2, #1
0x009958:	adds    	r3, r4, #0
0x00995a:	movs    	r0, #0xf1
0x00995c:	lsls    	r0, r0, #9
0x00995e:	bl      	#0x8694
0x009962:	add     	sp, #0x14
0x009964:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_009968 =====
0x009968:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x00996a:	sub     	sp, #0xc
0x00996c:	movs    	r1, #0
0x00996e:	movs    	r4, #0
0x009970:	movs    	r2, #0
0x009972:	str     	r2, [sp, #8]
0x009974:	adds    	r3, r4, #0
0x009976:	str     	r1, [sp]
0x009978:	str     	r1, [sp, #4]
0x00997a:	movs    	r5, #0xf8
0x00997c:	adds    	r2, r5, #0
0x00997e:	movs    	r1, #0x17
0x009980:	movs    	r0, #0xf1
0x009982:	lsls    	r0, r0, #9
0x009984:	bl      	#0x8694
0x009988:	movs    	r1, #0
0x00998a:	movs    	r2, #0
0x00998c:	str     	r2, [sp, #8]
0x00998e:	str     	r1, [sp]
0x009990:	str     	r1, [sp, #4]
0x009992:	movs    	r1, #0xe1
0x009994:	movs    	r2, #0x1d
0x009996:	adds    	r3, r4, #0
0x009998:	movs    	r0, #0xf1
0x00999a:	lsls    	r0, r0, #9
0x00999c:	bl      	#0x8694
0x0099a0:	movs    	r1, #0
0x0099a2:	adds    	r6, r0, #0
0x0099a4:	movs    	r2, #0
0x0099a6:	str     	r2, [sp, #8]
0x0099a8:	str     	r1, [sp]
0x0099aa:	str     	r1, [sp, #4]
0x0099ac:	movs    	r1, #0xe1
0x0099ae:	movs    	r2, #0x18
0x0099b0:	movs    	r0, #0xf1
0x0099b2:	adds    	r3, r4, #0
0x0099b4:	lsls    	r0, r0, #9
0x0099b6:	bl      	#0x8694
0x0099ba:	ldr     	r7, [r0, #0xc]
0x0099bc:	movs    	r1, #0
0x0099be:	movs    	r2, #0
0x0099c0:	str     	r2, [sp, #8]
0x0099c2:	str     	r1, [sp]
0x0099c4:	str     	r1, [sp, #4]
0x0099c6:	movs    	r1, #0xe1
0x0099c8:	movs    	r2, #0x18
0x0099ca:	movs    	r0, #0xf1
0x0099cc:	adds    	r3, r4, #0
0x0099ce:	lsls    	r0, r0, #9
0x0099d0:	bl      	#0x8694
0x0099d4:	ldr     	r3, [r0, #8]
0x0099d6:	movs    	r2, #0
0x0099d8:	str     	r2, [sp, #8]
0x0099da:	adds    	r2, r5, #0
0x0099dc:	movs    	r0, #0xf1
0x0099de:	movs    	r1, #0x52
0x0099e0:	lsls    	r0, r0, #9
0x0099e2:	str     	r7, [sp]
0x0099e4:	str     	r6, [sp, #4]
0x0099e6:	bl      	#0x8694
0x0099ea:	movs    	r1, #0
0x0099ec:	movs    	r2, #0
0x0099ee:	str     	r1, [sp]
0x0099f0:	str     	r1, [sp, #4]
0x0099f2:	movs    	r1, #0x19
0x0099f4:	str     	r2, [sp, #8]
0x0099f6:	adds    	r3, r4, #0
0x0099f8:	movs    	r0, #0xf1
0x0099fa:	lsls    	r0, r0, #9
0x0099fc:	ldr     	r2, [sp, #0xc]
0x0099fe:	bl      	#0x8694
0x009a02:	movs    	r1, #0
0x009a04:	movs    	r2, #0
0x009a06:	str     	r1, [sp]
0x009a08:	str     	r1, [sp, #4]
0x009a0a:	movs    	r1, #0x19
0x009a0c:	str     	r2, [sp, #8]
0x009a0e:	adds    	r3, r4, #0
0x009a10:	movs    	r0, #0xf1
0x009a12:	lsls    	r0, r0, #9
0x009a14:	ldr     	r2, [sp, #0x10]
0x009a16:	bl      	#0x8694
0x009a1a:	movs    	r1, #0
0x009a1c:	movs    	r2, #0
0x009a1e:	str     	r2, [sp, #8]
0x009a20:	str     	r1, [sp]
0x009a22:	str     	r1, [sp, #4]
0x009a24:	movs    	r1, #0x1b
0x009a26:	movs    	r2, #1
0x009a28:	adds    	r3, r4, #0
0x009a2a:	movs    	r0, #0xf1
0x009a2c:	lsls    	r0, r0, #9
0x009a2e:	bl      	#0x8694
0x009a32:	add     	sp, #0x14
0x009a34:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_009a38 =====
0x009a38:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x009a3a:	sub     	sp, #0xc
0x009a3c:	movs    	r1, #0
0x009a3e:	movs    	r4, #0
0x009a40:	movs    	r2, #0
0x009a42:	str     	r2, [sp, #8]
0x009a44:	adds    	r3, r4, #0
0x009a46:	str     	r1, [sp]
0x009a48:	str     	r1, [sp, #4]
0x009a4a:	movs    	r5, #0x90
0x009a4c:	adds    	r2, r5, #0
0x009a4e:	movs    	r1, #0x17
0x009a50:	movs    	r0, #0xf1
0x009a52:	lsls    	r0, r0, #9
0x009a54:	bl      	#0x8694
0x009a58:	movs    	r1, #0
0x009a5a:	movs    	r2, #0
0x009a5c:	str     	r2, [sp, #8]
0x009a5e:	str     	r1, [sp]
0x009a60:	str     	r1, [sp, #4]
0x009a62:	movs    	r1, #0xe1
0x009a64:	movs    	r2, #0x1d
0x009a66:	adds    	r3, r4, #0
0x009a68:	movs    	r0, #0xf1
0x009a6a:	lsls    	r0, r0, #9
0x009a6c:	bl      	#0x8694
0x009a70:	movs    	r1, #0
0x009a72:	adds    	r6, r0, #0
0x009a74:	movs    	r2, #0
0x009a76:	str     	r2, [sp, #8]
0x009a78:	str     	r1, [sp]
0x009a7a:	str     	r1, [sp, #4]
0x009a7c:	movs    	r1, #0xe1
0x009a7e:	movs    	r2, #0x18
0x009a80:	movs    	r0, #0xf1
0x009a82:	adds    	r3, r4, #0
0x009a84:	lsls    	r0, r0, #9
0x009a86:	bl      	#0x8694
0x009a8a:	ldr     	r7, [r0, #0xc]
0x009a8c:	movs    	r1, #0
0x009a8e:	movs    	r2, #0
0x009a90:	str     	r2, [sp, #8]
0x009a92:	str     	r1, [sp]
0x009a94:	str     	r1, [sp, #4]
0x009a96:	movs    	r1, #0xe1
0x009a98:	movs    	r2, #0x18
0x009a9a:	movs    	r0, #0xf1
0x009a9c:	adds    	r3, r4, #0
0x009a9e:	lsls    	r0, r0, #9
0x009aa0:	bl      	#0x8694
0x009aa4:	ldr     	r3, [r0, #8]
0x009aa6:	movs    	r2, #0
0x009aa8:	str     	r2, [sp, #8]
0x009aaa:	adds    	r2, r5, #0
0x009aac:	movs    	r0, #0xf1
0x009aae:	movs    	r1, #0x52
0x009ab0:	lsls    	r0, r0, #9
0x009ab2:	str     	r7, [sp]
0x009ab4:	str     	r6, [sp, #4]
0x009ab6:	bl      	#0x8694
0x009aba:	movs    	r1, #0
0x009abc:	movs    	r2, #0
0x009abe:	str     	r1, [sp]
0x009ac0:	str     	r1, [sp, #4]
0x009ac2:	movs    	r1, #0x19
0x009ac4:	str     	r2, [sp, #8]
0x009ac6:	adds    	r3, r4, #0
0x009ac8:	movs    	r0, #0xf1
0x009aca:	lsls    	r0, r0, #9
0x009acc:	ldr     	r2, [sp, #0xc]
0x009ace:	bl      	#0x8694
0x009ad2:	movs    	r1, #0
0x009ad4:	movs    	r2, #0
0x009ad6:	str     	r1, [sp]
0x009ad8:	str     	r1, [sp, #4]
0x009ada:	movs    	r1, #0x1a
0x009adc:	str     	r2, [sp, #8]
0x009ade:	adds    	r3, r4, #0
0x009ae0:	movs    	r0, #0xf1
0x009ae2:	lsls    	r0, r0, #9
0x009ae4:	ldr     	r2, [sp, #0x10]
0x009ae6:	bl      	#0x8694
0x009aea:	movs    	r1, #0
0x009aec:	movs    	r2, #0
0x009aee:	str     	r2, [sp, #8]
0x009af0:	str     	r1, [sp]
0x009af2:	str     	r1, [sp, #4]
0x009af4:	movs    	r1, #0x1b
0x009af6:	movs    	r2, #1
0x009af8:	adds    	r3, r4, #0
0x009afa:	movs    	r0, #0xf1
0x009afc:	lsls    	r0, r0, #9
0x009afe:	bl      	#0x8694
0x009b02:	add     	sp, #0x14
0x009b04:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_009b08 =====
0x009b08:	push    	{r4, r5, r6, lr}
0x009b0a:	ldr     	r6, [pc, #0x48]
0x009b0c:	adds    	r4, r0, #0
0x009b0e:	movs    	r3, #1
0x009b10:	add     	r6, sb
0x009b12:	ldrsb   	r0, [r6, r3]
0x009b14:	movs    	r5, #0xf1
0x009b16:	lsls    	r5, r5, #9
0x009b18:	cmp     	r0, #0
0x009b1a:	sub     	sp, #0x10
0x009b1c:	bne     	#0x9b3c
0x009b1e:	bl      	#0x90b0
0x009b22:	movs    	r1, #0
0x009b24:	movs    	r2, #0
0x009b26:	str     	r2, [sp, #8]
0x009b28:	str     	r1, [sp]
0x009b2a:	str     	r1, [sp, #4]
0x009b2c:	movs    	r1, #0x14
0x009b2e:	movs    	r2, #0x58
0x009b30:	adds    	r3, r4, #0
0x009b32:	adds    	r0, r5, #0
0x009b34:	bl      	#0x8694
0x009b38:	add     	sp, #0x10
0x009b3a:	pop     	{r4, r5, r6, pc}

; ===== candidate_009b58 =====
0x009b58:	push    	{r4, r5, lr}
0x009b5a:	sub     	sp, #0xc
0x009b5c:	movs    	r1, #0
0x009b5e:	adds    	r5, r0, #0
0x009b60:	movs    	r2, #0
0x009b62:	str     	r2, [sp, #8]
0x009b64:	str     	r1, [sp]
0x009b66:	str     	r1, [sp, #4]
0x009b68:	movs    	r4, #0
0x009b6a:	adds    	r3, r4, #0
0x009b6c:	movs    	r1, #0x14
0x009b6e:	movs    	r2, #0x20
0x009b70:	movs    	r0, #0xf1
0x009b72:	lsls    	r0, r0, #9
0x009b74:	bl      	#0x8694
0x009b78:	movs    	r1, #0
0x009b7a:	str     	r1, [sp]
0x009b7c:	str     	r1, [sp, #4]
0x009b7e:	movs    	r2, #0
0x009b80:	movs    	r1, #0x2c
0x009b82:	adds    	r3, r4, #0
0x009b84:	movs    	r0, #0xf1
0x009b86:	lsls    	r0, r0, #9
0x009b88:	str     	r2, [sp, #8]
0x009b8a:	bl      	#0x8694
0x009b8e:	movs    	r1, #0
0x009b90:	str     	r1, [sp]
0x009b92:	str     	r1, [sp, #4]
0x009b94:	movs    	r2, #0
0x009b96:	movs    	r1, #0xe6
0x009b98:	adds    	r3, r4, #0
0x009b9a:	movs    	r0, #0xf1
0x009b9c:	lsls    	r0, r0, #9
0x009b9e:	str     	r2, [sp, #8]
0x009ba0:	bl      	#0x8694
0x009ba4:	movs    	r1, #0
0x009ba6:	movs    	r2, #0
0x009ba8:	str     	r2, [sp, #8]
0x009baa:	str     	r1, [sp]
0x009bac:	str     	r1, [sp, #4]
0x009bae:	adds    	r3, r4, #0
0x009bb0:	adds    	r2, r5, #0
0x009bb2:	movs    	r1, #0x33
0x009bb4:	movs    	r0, #0xf1
0x009bb6:	lsls    	r0, r0, #9
0x009bb8:	bl      	#0x8694
0x009bbc:	add     	sp, #0xc
0x009bbe:	pop     	{r4, r5, pc}

; ===== candidate_009bc0 =====
0x009bc0:	push    	{r4, r5, r6, lr}
0x009bc2:	sub     	sp, #0x10
0x009bc4:	movs    	r1, #0
0x009bc6:	movs    	r2, #0
0x009bc8:	str     	r2, [sp, #8]
0x009bca:	str     	r1, [sp]
0x009bcc:	str     	r1, [sp, #4]
0x009bce:	movs    	r6, #0xf1
0x009bd0:	movs    	r5, #0
0x009bd2:	adds    	r3, r5, #0
0x009bd4:	lsls    	r6, r6, #9
0x009bd6:	movs    	r1, #0xe1
0x009bd8:	movs    	r2, #0x58
0x009bda:	adds    	r0, r6, #0
0x009bdc:	bl      	#0x8694
0x009be0:	ldr     	r4, [pc, #0x34]
0x009be2:	cmp     	r0, #0
0x009be4:	add     	r4, sb
0x009be6:	bne     	#0x9bee
0x009be8:	strb    	r5, [r4, #1]
0x009bea:	add     	sp, #0x10
0x009bec:	pop     	{r4, r5, r6, pc}

; ===== candidate_009c94 =====
0x009c94:	push    	{r0, r1, r5, lr}
0x009c96:	stm     	r7!, {r0, r4, r5, r7}
0x009c98:	ldm     	r6!, {r4, r5, r7}
0x009c9a:	ldm     	r7, {r2, r4, r5, r7}
0x009c9c:	stm     	r7!, {r1, r5, r6, r7}
0x009c9e:	cbnz    	r6, #0x9cce
0x009ca0:	cbz     	r5, #0x9ce2
0x009ca2:	ldm     	r2, {r1, r2, r5, r7}
0x009ca4:	cmp     	r7, #0xaf
0x009ca6:	movs    	r0, #0x26
0x009ca8:	movs    	r6, r4
0x009caa:	movs    	r0, r0
0x009cac:	movs    	r6, #0x2f
0x009cae:	movs    	r6, #0x20
0x009cb0:	movs    	r0, r0
0x009cb2:	movs    	r0, r0
0x009cb4:	movs    	r3, r5
0x009cb6:	movs    	r0, r0
0x009cb8:	cbz     	r5, #0x9ce8
0x009cba:	sub     	sp, #0x11c
0x009cbc:	bl      	#0xff0d4660
0x009cc0:	movs    	r3, #0x3a
0x009cc2:	movs    	r0, r0
0x009cc4:	push    	{r1, r3, r5, lr}
0x009cc6:	stm     	r7!, {r0, r4, r5, r7}
0x009cc8:	cbz     	r0, #0x9cf8
0x009cca:	ldm     	r2, {r1, r2, r5, r7}
0x009ccc:	cmp     	r7, #0xaf
0x009cce:	rsbs    	r0, r3, r7, lsr #15

; ===== candidate_009cc4 =====
0x009cc4:	push    	{r1, r3, r5, lr}
0x009cc6:	stm     	r7!, {r0, r4, r5, r7}
0x009cc8:	cbz     	r0, #0x9cf8
0x009cca:	ldm     	r2, {r1, r2, r5, r7}
0x009ccc:	cmp     	r7, #0xaf
0x009cce:	rsbs    	r0, r3, r7, lsr #15

; ===== candidate_009db8 =====
0x009db8:	push    	{r0, r4, r5, r7}
0x009dba:	cbnz    	r2, #0x9e2a
0x009dbc:	bgt     	#0x9d48

; ===== candidate_009e0e =====
0x009e0e:	push    	{r2, r3, r6, r7, lr}
0x009e10:	cmp     	r7, #0xea
0x009e12:	bl      	#0xac5dc0
0x009e16:	ldm     	r1, {r1, r3, r5}
0x009e18:	cbz     	r4, #0x9e8e
0x009e1a:	cmp     	r7, #0xc7

; ===== candidate_009e5a =====
0x009e5a:	push    	{r2, r3, r6, r7, lr}
0x009e5c:	cmp     	r7, #0xea
0x009e5e:	bl      	#0xac5e0c
0x009e62:	ldm     	r1, {r1, r3, r5}
0x009e64:	cbz     	r4, #0x9eda
0x009e66:	cmp     	r7, #0xc7

; ===== candidate_009f56 =====
0x009f56:	push    	{r0, r1, r2, r3, r4, r5, r7}
0x009f58:	pkhbt   	r8, pc, pc, lsl #0xf
0x009f5c:	movs    	r0, r0
0x009f5e:	movs    	r0, r0
0x009f60:	add     	r2, sp, #0x2d8

; ===== candidate_009f92 =====
0x009f92:	push    	{r1, r2, r3, r6, r7}
0x009f94:	b       	#0xa512
0x009f96:	str.w   	sl, [fp, #0xca3]
0x009f9a:	rsb     	r0, r7, r7, lsl #15

; ===== candidate_009fc2 =====
0x009fc2:	push    	{r1, r2, r3, r6, r7}
0x009fc4:	b       	#0xa542
0x009fc6:	str.w   	sl, [fp, #0xca3]
0x009fca:	rsb     	r0, r7, r7, lsl #15

; ===== candidate_00a114 =====
0x00a114:	push    	{r3, r4, r5, r7}

; ===== candidate_00a1b0 =====
0x00a1b0:	push    	{r3, r5, r7, lr}
0x00a1b2:	bkpt    	#0xc0
0x00a1b4:	cmp     	r7, #0xdf
0x00a1b6:	add     	r4, sp, #0x28c
0x00a1b8:	rsb     	r0, r7, r7, lsl #15

; ===== candidate_00a20a =====
0x00a20a:	push    	{r0, r1, r2, r4, r6, r7}
0x00a20c:	add     	r4, sp, #0x330
0x00a20e:	stm     	r2!, {r0, r1, r2, r3, r6, r7}
0x00a210:	cbnz    	r2, #0xa246
0x00a212:	stm     	r3!, {r0, r1, r4, r6, r7}
0x00a214:	movs    	r0, r0
0x00a216:	movs    	r0, r0
0x00a218:	rsb     	r1, r7, r1, lsr #11
0x00a21c:	b.w     	#0x1def62
0x00a220:	sub     	sp, #0x15c

; ===== candidate_00a24e =====
0x00a24e:	push    	{r0, r1, r2, r3, r5, lr}
0x00a250:	bkpt    	#0xc0
0x00a252:	adr     	r3, #0x37c
0x00a254:	movs    	r3, #0xac
0x00a256:	b       	#0xa5d4

; ===== candidate_00a2e6 =====
0x00a2e6:	push    	{r0, r2, r4, r5, r7, lr}
0x00a2e8:	cmp     	r7, #0xc0
0x00a2ea:	adr     	r2, #0x2dc
0x00a2ec:	bmi     	#0xa292
0x00a2ee:	cbz     	r2, #0xa324
0x00a2f0:	bkpt    	#0xa1
0x00a2f2:	cbnz    	r1, #0xa362
0x00a2f4:	add     	r7, sp, #0x2d8
0x00a2f6:	cbnz    	r2, #0xa32c
0x00a2f8:	stm     	r3!, {r0, r1, r4, r6, r7}
0x00a2fa:	itttt   	ge
0x00a2fc:	addge   	r4, sp, #0x28c
0x00a2fe:	udf     	#0xce
0x00a300:	addge   	r0, sp, #0x2dc
0x00a302:	cbz     	r6, #0xa33a
0x00a304:	blo     	#0xa282
0x00a306:	cbnz    	r2, #0xa33c
0x00a308:	stm     	r3!, {r0, r1, r4, r6, r7}
0x00a30a:	movs    	r0, r0
0x00a30c:	rsb     	r1, r7, r1, lsr #11
0x00a310:	b.w     	#0x1df15a
0x00a314:	pop     	{r0, r3, r6, r7, pc}

; ===== candidate_00a3c0 =====
0x00a3c0:	push    	{r2, r3, r4, r6, r7}
0x00a3c2:	ittt    	al
0x00a3c4:	adr     	r3, #0x2a8
0x00a3c6:	stm     	r4!, {r2, r3, r5, r7}
0x00a3c8:	stm     	r4!, {r0, r1, r5, r6, r7}
0x00a3ca:	stm     	r7!, {r0, r1, r2, r3, r4, r5, r7}
0x00a3cc:	push    	{r4, r5, r7, lr}
0x00a3ce:	pop     	{r3, r6, r7}
0x00a3d0:	uxth    	r6, r6
0x00a3d2:	cbnz    	r3, #0xa404
0x00a3d4:	adr     	r3, #0x2ec
0x00a3d6:	lsls    	r1, r4, #2
0x00a3d8:	push    	{r1, r3, r5}
0x00a3da:	stm     	r0!, {r0, r1, r3, r6, r7}
0x00a3dc:	sub     	sp, #0x1c4
0x00a3de:	cmp     	r7, #0xfc

; ===== candidate_00a3cc =====
0x00a3cc:	push    	{r4, r5, r7, lr}
0x00a3ce:	pop     	{r3, r6, r7}
0x00a3d0:	uxth    	r6, r6
0x00a3d2:	cbnz    	r3, #0xa404
0x00a3d4:	adr     	r3, #0x2ec
0x00a3d6:	lsls    	r1, r4, #2
0x00a3d8:	push    	{r1, r3, r5}
0x00a3da:	stm     	r0!, {r0, r1, r3, r6, r7}
0x00a3dc:	sub     	sp, #0x1c4
0x00a3de:	cmp     	r7, #0xfc

; ===== candidate_00a3d8 =====
0x00a3d8:	push    	{r1, r3, r5}
0x00a3da:	stm     	r0!, {r0, r1, r3, r6, r7}
0x00a3dc:	sub     	sp, #0x1c4
0x00a3de:	cmp     	r7, #0xfc

; ===== candidate_00a3e8 =====
0x00a3e8:	push    	{r0, r1, r5, lr}
0x00a3ea:	pop     	{r3, r6, r7}
0x00a3ec:	lsls    	r6, r6, #2
0x00a3ee:	movs    	r0, r0
0x00a3f0:	stm     	r7!, {r1, r3, r6, r7}
0x00a3f2:	b.w     	#0x5c2386
0x00a3f6:	add     	r0, sp, #0x2d8
0x00a3f8:	bge.w   	#0xfe97a
0x00a3fc:	movs    	r3, #0x20
0x00a3fe:	movs    	r0, r0
0x00a400:	add     	r3, sp, #0x2f4
0x00a402:	b       	#0xa77c
0x00a404:	smlaltt 	ip, r4, pc, sl
0x00a408:	cbnz    	r2, #0xa480

; ===== candidate_00a458 =====
0x00a458:	push    	{r0, r1, r3, r6, r7}
0x00a45a:	revsh   	r3, r1

; ===== candidate_00a48c =====
0x00a48c:	push    	{r5, lr}
0x00a48e:	ldm     	r6, {r2, r6, r7}
0x00a490:	stm     	r6!, {r0, r1, r2, r3, r5, r6, r7}
0x00a492:	ldm     	r1, {r0, r1, r2, r4, r5, r7}
0x00a494:	stm     	r6!, {r2, r3, r6, r7}
0x00a496:	lsls    	r4, r1, #3
0x00a498:	bge     	#0xa406
0x00a49a:	bhs     	#0xa500
0x00a49c:	lsls    	r3, r6, #2
0x00a49e:	movs    	r0, r0
0x00a4a0:	bge     	#0xa40e
0x00a4a2:	movs    	r0, r0
0x00a4a4:	cbz     	r2, #0xa51c
0x00a4a6:	movs    	r0, r0
0x00a4a8:	rsb     	r1, r7, r1, lsr #11
0x00a4ac:	bl      	#0xddf214
0x00a4b0:	b       	#0xaa32
0x00a4b2:	cbz     	r2, #0xa52a
0x00a4b4:	stc2l   	p0, c0, [sl]
0x00a4b8:	rsb     	r1, r7, r1, lsr #11
0x00a4bc:	b.w     	#0x5dec22
0x00a4c0:	ldc2    	p3, c11, [r0], #0x348
0x00a4c4:	stc2l   	p0, c0, [sl]

; ===== candidate_00a4d8 =====
0x00a4d8:	push    	{r1, r2, r3, r6, r7}
0x00a4da:	cbnz    	r2, #0xa510
0x00a4dc:	stm     	r3!, {r0, r1, r4, r6, r7}
0x00a4de:	movs    	r0, r0
0x00a4e0:	cbnz    	r2, #0xa516
0x00a4e2:	stm     	r3!, {r0, r1, r4, r6, r7}
0x00a4e4:	beq     	#0xa494
0x00a4e6:	movs    	r0, r0
0x00a4e8:	cbnz    	r2, #0xa560
0x00a4ea:	cdp2    	p13, #0xb, c15, c6, c8, #6
0x00a4ee:	stm     	r4!, {r0, r1, r3, r6, r7}
0x00a4f0:	b       	#0xa090
0x00a4f2:	vst1.8  	{d16[0]}, [r1], r0
0x00a4f6:	movs    	r0, r0
0x00a4f8:	bne     	#0xa4a0
0x00a4fa:	add     	r5, sp, #0x2f8
0x00a4fc:	add     	r2, sp, #0x2d8

; ===== candidate_00a560 =====
0x00a560:	push    	{r0, r1, r5, r7}
0x00a562:	pop     	{r1, r2, r5, r6, r7}

; ===== candidate_00a588 =====
0x00a588:	push    	{r0, r1, r2, r4, r5, r7, lr}
0x00a58a:	bhi     	#0xa504
0x00a58c:	movs    	r0, r0
0x00a58e:	movs    	r0, r0
0x00a590:	cbnz    	r3, #0xa604
0x00a592:	beq     	#0xa53c
0x00a594:	pop     	{r0, r1, r5}

; ===== candidate_00a598 =====
0x00a598:	push    	{r3, r5, r7, lr}
0x00a59a:	bkpt    	#0xc0
0x00a59c:	cmp     	r7, #0xdf
0x00a59e:	add     	r4, sp, #0x28c
0x00a5a0:	rsb     	r8, r7, pc, lsl #19
