; fallback candidate disassembly from Thumb prologues; true code is ARM entry + Thumb functions.

; ARM entry
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0x10c8
0x000018:	pop     	{r4, pc}
0x00001c:	ldr     	r0, [pc, #8]
0x000020:	ldr     	r1, [pc, #8]
0x000024:	add     	r0, r0, r1
0x000028:	bx      	lr
0x00002c:	andeq   	r0, r0, r4
0x000030:	andeq   	r0, r0, r8, ror #2
0x000034:	mov     	sb, r0
0x000038:	bx      	lr
0x00003c:	stcmi   	p5, c11, [sp], #-0xc0
0x000040:	ldrbtmi 	r2, [ip], #-0x21c
0x000044:	smlatbhs	r0, r0, fp, r6
0x000048:	stmdami 	fp!, {r0, r1, r7, r8, sb, fp, sp, lr}
0x00004c:	strbmi  	fp, [r8], #-0x83
0x000050:	andhs   	r4, r0, #152, #14
0x000054:	andls   	r2, r0, r0
0x000058:	movwhs  	r4, #0x927

; ===== candidate_000008 =====
0x000008:	ands    	r0, r2
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	lsls    	r3, r5, #0x10

; ===== candidate_00000a =====
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	lsls    	r3, r5, #0x10

; ===== candidate_00003c =====
0x00003c:	push    	{r4, r5, lr}
0x00003e:	ldr     	r4, [pc, #0xb4]
0x000040:	movs    	r2, #0x1c
0x000042:	add     	r4, pc
0x000044:	ldr     	r0, [r4, #0x38]
0x000046:	movs    	r1, #0
0x000048:	ldr     	r3, [r0, #0x38]
0x00004a:	ldr     	r0, [pc, #0xac]
0x00004c:	sub     	sp, #0xc
0x00004e:	add     	r0, sb
0x000050:	blx     	r3
0x000052:	movs    	r2, #0
0x000054:	movs    	r0, #0
0x000056:	str     	r0, [sp]
0x000058:	ldr     	r1, [pc, #0x9c]
0x00005a:	movs    	r3, #0
0x00005c:	add     	r1, sb
0x00005e:	str     	r1, [sp, #4]
0x000060:	movs    	r1, #0x64
0x000062:	movs    	r0, #1
0x000064:	str     	r2, [sp, #8]
0x000066:	bl      	#0x1158
0x00006a:	ldr     	r1, [pc, #0x8c]
0x00006c:	movs    	r0, #0
0x00006e:	add     	r1, sb
0x000070:	subs    	r1, #0x7c
0x000072:	str     	r0, [r1, #8]
0x000074:	ldr     	r5, [pc, #0x80]
0x000076:	str     	r0, [r1, #0x10]
0x000078:	str     	r0, [r1, #0xc]
0x00007a:	add     	r5, sb
0x00007c:	subs    	r5, #0xfc
0x00007e:	movs    	r0, #1
0x000080:	str     	r0, [r5, #0x18]
0x000082:	ldr     	r0, [r4, #0x38]
0x000084:	ldr     	r2, [pc, #0x74]
0x000086:	ldr     	r1, [r0, #0x68]
0x000088:	add     	r2, sb
0x00008a:	str     	r1, [r5, #0x2c]
0x00008c:	ldr     	r1, [r0, #0xc]
0x00008e:	ldr     	r4, [pc, #0x70]
0x000090:	str     	r1, [r5, #0x30]
0x000092:	ldr     	r1, [r0, #0x10]
0x000094:	str     	r1, [r5, #0x34]
0x000096:	ldr     	r1, [r0, #0x14]
0x000098:	str     	r1, [r5, #0x38]
0x00009a:	ldr     	r1, [r0, #0x18]
0x00009c:	str     	r1, [r5, #0x3c]
0x00009e:	ldr     	r1, [r0, #0x1c]
0x0000a0:	str     	r1, [r5, #0x40]
0x0000a2:	ldr     	r1, [r0, #0x20]
0x0000a4:	str     	r1, [r5, #0x44]
0x0000a6:	ldr     	r1, [r0, #0x24]
0x0000a8:	str     	r1, [r5, #0x48]
0x0000aa:	ldr     	r1, [r0, #0x28]
0x0000ac:	str     	r1, [r5, #0x4c]
0x0000ae:	ldr     	r1, [r0, #0x2c]
0x0000b0:	str     	r1, [r5, #0x50]
0x0000b2:	ldr     	r1, [r0, #0x30]
0x0000b4:	str     	r1, [r5, #0x54]
0x0000b6:	ldr     	r1, [r0, #0x34]
0x0000b8:	str     	r1, [r5, #0x58]
0x0000ba:	ldr     	r1, [r0, #0x38]
0x0000bc:	str     	r1, [r5, #0x5c]
0x0000be:	ldr     	r1, [r0, #0x3c]
0x0000c0:	str     	r1, [r5, #0x60]
0x0000c2:	ldr     	r1, [r0, #0x40]
0x0000c4:	str     	r1, [r5, #0x64]
0x0000c6:	ldr     	r1, [r0, #0x44]
0x0000c8:	str     	r1, [r5, #0x68]
0x0000ca:	ldr     	r1, [r0, #0x48]
0x0000cc:	str     	r1, [r5, #0x6c]
0x0000ce:	ldr     	r1, [r0, #0x4c]
0x0000d0:	str     	r1, [r5, #0x70]
0x0000d2:	movs    	r1, #0
0x0000d4:	str     	r1, [r2]
0x0000d6:	movs    	r1, #1
0x0000d8:	lsls    	r1, r1, #9
0x0000da:	adds    	r0, r0, r1
0x0000dc:	ldr     	r3, [r0, #8]
0x0000de:	movs    	r1, #7
0x0000e0:	adds    	r2, r4, #0
0x0000e2:	movs    	r0, #0
0x0000e4:	blx     	r3
0x0000e6:	cmp     	r0, r4
0x0000e8:	bne     	#0xee
0x0000ea:	subs    	r0, #2
0x0000ec:	str     	r0, [r5, #0x28]
0x0000ee:	add     	sp, #0xc
0x0000f0:	pop     	{r4, r5, pc}

; ===== candidate_000104 =====
0x000104:	push    	{r4, r5, r6, r7, lr}
0x000106:	sub     	sp, #0xc
0x000108:	bl      	#0xac0
0x00010c:	movs    	r1, #0
0x00010e:	movs    	r2, #0
0x000110:	str     	r2, [sp, #8]
0x000112:	str     	r1, [sp]
0x000114:	str     	r1, [sp, #4]
0x000116:	movs    	r5, #0xf1
0x000118:	lsls    	r5, r5, #9
0x00011a:	movs    	r1, #0x14
0x00011c:	movs    	r2, #0x8f
0x00011e:	adds    	r4, r0, #0
0x000120:	movs    	r3, #1
0x000122:	adds    	r0, r5, #0
0x000124:	bl      	#0x1158
0x000128:	cmp     	r4, #0
0x00012a:	beq     	#0x142
0x00012c:	movs    	r1, #0
0x00012e:	movs    	r2, #0
0x000130:	str     	r2, [sp, #8]
0x000132:	str     	r1, [sp]
0x000134:	str     	r1, [sp, #4]
0x000136:	movs    	r1, #0x14
0x000138:	movs    	r2, #0x70
0x00013a:	adds    	r3, r4, #0
0x00013c:	adds    	r0, r5, #0
0x00013e:	bl      	#0x1158
0x000142:	movs    	r1, #0
0x000144:	movs    	r2, #0
0x000146:	str     	r2, [sp, #8]
0x000148:	str     	r1, [sp]
0x00014a:	str     	r1, [sp, #4]
0x00014c:	movs    	r4, #0
0x00014e:	adds    	r3, r4, #0
0x000150:	movs    	r1, #0xe1
0x000152:	movs    	r2, #0x72
0x000154:	adds    	r0, r5, #0
0x000156:	bl      	#0x1158
0x00015a:	movs    	r1, #0
0x00015c:	adds    	r6, r0, #0
0x00015e:	movs    	r2, #0
0x000160:	str     	r2, [sp, #8]
0x000162:	str     	r1, [sp]
0x000164:	str     	r1, [sp, #4]
0x000166:	movs    	r1, #0xe1
0x000168:	movs    	r2, #0xf3
0x00016a:	movs    	r0, #0xf1
0x00016c:	adds    	r3, r4, #0
0x00016e:	lsls    	r0, r0, #9
0x000170:	bl      	#0x1158
0x000174:	lsls    	r1, r0, #2
0x000176:	ldr     	r6, [r6, r1]
0x000178:	movs    	r1, #0
0x00017a:	movs    	r2, #0
0x00017c:	str     	r2, [sp, #8]
0x00017e:	str     	r1, [sp]
0x000180:	str     	r1, [sp, #4]
0x000182:	movs    	r1, #0xe1
0x000184:	movs    	r2, #0xf4
0x000186:	movs    	r0, #0xf1
0x000188:	adds    	r3, r4, #0
0x00018a:	lsls    	r0, r0, #9
0x00018c:	bl      	#0x1158
0x000190:	lsls    	r0, r0, #2
0x000192:	ldr     	r0, [r6, r0]
0x000194:	adds    	r3, r0, #2
0x000196:	bne     	#0x270
0x000198:	movs    	r1, #0
0x00019a:	movs    	r2, #0
0x00019c:	str     	r2, [sp, #8]
0x00019e:	str     	r1, [sp]
0x0001a0:	str     	r1, [sp, #4]
0x0001a2:	movs    	r1, #0xe1
0x0001a4:	movs    	r2, #0x73
0x0001a6:	adds    	r3, r4, #0
0x0001a8:	adds    	r0, r5, #0
0x0001aa:	bl      	#0x1158
0x0001ae:	movs    	r6, #5
0x0001b0:	adds    	r3, r0, #1
0x0001b2:	bne     	#0x1e6
0x0001b4:	movs    	r1, #0
0x0001b6:	movs    	r2, #0
0x0001b8:	str     	r2, [sp, #8]
0x0001ba:	str     	r1, [sp]
0x0001bc:	str     	r1, [sp, #4]
0x0001be:	movs    	r1, #0x14
0x0001c0:	movs    	r2, #0x4e
0x0001c2:	adds    	r3, r4, #0
0x0001c4:	adds    	r0, r5, #0
0x0001c6:	bl      	#0x1158
0x0001ca:	movs    	r1, #0
0x0001cc:	movs    	r2, #0
0x0001ce:	str     	r2, [sp, #8]
0x0001d0:	str     	r1, [sp]
0x0001d2:	str     	r1, [sp, #4]
0x0001d4:	movs    	r1, #0x14
0x0001d6:	movs    	r2, #0xf7
0x0001d8:	adds    	r3, r6, #0
0x0001da:	movs    	r0, #0xf1
0x0001dc:	lsls    	r0, r0, #9
0x0001de:	bl      	#0x1158
0x0001e2:	add     	sp, #0xc
0x0001e4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000360 =====
0x000360:	push    	{r4, r5, lr}
0x000362:	sub     	sp, #0xc
0x000364:	movs    	r1, #0
0x000366:	str     	r1, [sp]
0x000368:	str     	r1, [sp, #4]
0x00036a:	movs    	r5, #0xf1
0x00036c:	movs    	r4, #0
0x00036e:	movs    	r2, #0
0x000370:	adds    	r3, r4, #0
0x000372:	lsls    	r5, r5, #9
0x000374:	movs    	r1, #0x2c
0x000376:	adds    	r0, r5, #0
0x000378:	str     	r2, [sp, #8]
0x00037a:	bl      	#0x1158
0x00037e:	movs    	r1, #0
0x000380:	movs    	r2, #0
0x000382:	str     	r2, [sp, #8]
0x000384:	str     	r1, [sp]
0x000386:	str     	r1, [sp, #4]
0x000388:	movs    	r1, #0xe1
0x00038a:	movs    	r2, #0x79
0x00038c:	adds    	r3, r4, #0
0x00038e:	adds    	r0, r5, #0
0x000390:	bl      	#0x1158
0x000394:	cmp     	r0, #1
0x000396:	bne     	#0x410
0x000398:	movs    	r1, #0
0x00039a:	str     	r1, [sp]
0x00039c:	str     	r1, [sp, #4]
0x00039e:	movs    	r2, #0
0x0003a0:	movs    	r1, #0x9e
0x0003a2:	adds    	r3, r4, #0
0x0003a4:	adds    	r0, r5, #0
0x0003a6:	str     	r2, [sp, #8]
0x0003a8:	bl      	#0x1158
0x0003ac:	movs    	r1, #0
0x0003ae:	movs    	r2, #0
0x0003b0:	str     	r2, [sp, #8]
0x0003b2:	str     	r1, [sp]
0x0003b4:	str     	r1, [sp, #4]
0x0003b6:	movs    	r1, #0xe1
0x0003b8:	movs    	r2, #0x72
0x0003ba:	adds    	r3, r4, #0
0x0003bc:	adds    	r0, r5, #0
0x0003be:	bl      	#0x1158
0x0003c2:	movs    	r1, #0
0x0003c4:	adds    	r5, r0, #0
0x0003c6:	movs    	r2, #0
0x0003c8:	str     	r2, [sp, #8]
0x0003ca:	str     	r1, [sp]
0x0003cc:	str     	r1, [sp, #4]
0x0003ce:	movs    	r1, #0xe1
0x0003d0:	movs    	r2, #0xf3
0x0003d2:	movs    	r0, #0xf1
0x0003d4:	adds    	r3, r4, #0
0x0003d6:	lsls    	r0, r0, #9
0x0003d8:	bl      	#0x1158
0x0003dc:	lsls    	r1, r0, #2
0x0003de:	ldr     	r5, [r5, r1]
0x0003e0:	movs    	r1, #0
0x0003e2:	movs    	r2, #0
0x0003e4:	str     	r2, [sp, #8]
0x0003e6:	str     	r1, [sp]
0x0003e8:	str     	r1, [sp, #4]
0x0003ea:	movs    	r1, #0xe1
0x0003ec:	movs    	r2, #0xf4
0x0003ee:	movs    	r0, #0xf1
0x0003f0:	adds    	r3, r4, #0
0x0003f2:	lsls    	r0, r0, #9
0x0003f4:	bl      	#0x1158
0x0003f8:	lsls    	r0, r0, #2
0x0003fa:	ldr     	r0, [r5, r0]
0x0003fc:	cmp     	r0, #0
0x0003fe:	blt     	#0x410
0x000400:	ldr     	r0, [pc, #0x10]
0x000402:	movs    	r3, #0
0x000404:	add     	r0, sb
0x000406:	ldrsb   	r0, [r0, r3]
0x000408:	cmp     	r0, #0
0x00040a:	bne     	#0x410
0x00040c:	bl      	#0x104
0x000410:	add     	sp, #0xc
0x000412:	pop     	{r4, r5, pc}

; ===== candidate_000418 =====
0x000418:	push    	{r4, r5, r6, lr}
0x00041a:	sub     	sp, #0x10
0x00041c:	movs    	r1, #0
0x00041e:	str     	r1, [sp]
0x000420:	str     	r1, [sp, #4]
0x000422:	movs    	r5, #0xf1
0x000424:	movs    	r4, #0
0x000426:	movs    	r2, #0
0x000428:	adds    	r3, r4, #0
0x00042a:	lsls    	r5, r5, #9
0x00042c:	movs    	r1, #0x2c
0x00042e:	adds    	r0, r5, #0
0x000430:	str     	r2, [sp, #8]
0x000432:	bl      	#0x1158
0x000436:	movs    	r1, #0
0x000438:	movs    	r2, #0
0x00043a:	str     	r2, [sp, #8]
0x00043c:	str     	r1, [sp]
0x00043e:	str     	r1, [sp, #4]
0x000440:	movs    	r1, #0x14
0x000442:	movs    	r2, #0x74
0x000444:	adds    	r3, r4, #0
0x000446:	adds    	r0, r5, #0
0x000448:	bl      	#0x1158
0x00044c:	movs    	r1, #0
0x00044e:	str     	r1, [sp]
0x000450:	str     	r1, [sp, #4]
0x000452:	movs    	r2, #0
0x000454:	movs    	r1, #0xc2
0x000456:	adds    	r3, r4, #0
0x000458:	adds    	r0, r5, #0
0x00045a:	str     	r2, [sp, #8]
0x00045c:	bl      	#0x1158
0x000460:	movs    	r1, #0
0x000462:	movs    	r2, #0
0x000464:	str     	r2, [sp, #8]
0x000466:	str     	r1, [sp]
0x000468:	str     	r1, [sp, #4]
0x00046a:	movs    	r1, #0xe1
0x00046c:	movs    	r2, #0x74
0x00046e:	adds    	r3, r4, #0
0x000470:	adds    	r0, r5, #0
0x000472:	bl      	#0x1158
0x000476:	cmp     	r0, #0
0x000478:	beq     	#0x4bc
0x00047a:	movs    	r1, #0
0x00047c:	movs    	r2, #0
0x00047e:	str     	r2, [sp, #8]
0x000480:	str     	r1, [sp]
0x000482:	str     	r1, [sp, #4]
0x000484:	movs    	r1, #0xe1
0x000486:	movs    	r2, #0x74
0x000488:	adds    	r3, r4, #0
0x00048a:	adds    	r0, r5, #0
0x00048c:	bl      	#0x1158
0x000490:	movs    	r1, #0
0x000492:	movs    	r2, #0
0x000494:	str     	r2, [sp, #8]
0x000496:	str     	r1, [sp]
0x000498:	str     	r1, [sp, #4]
0x00049a:	movs    	r1, #0xbe
0x00049c:	adds    	r2, r0, #0
0x00049e:	adds    	r3, r4, #0
0x0004a0:	adds    	r0, r5, #0
0x0004a2:	bl      	#0x1158
0x0004a6:	movs    	r1, #0
0x0004a8:	movs    	r2, #0
0x0004aa:	str     	r2, [sp, #8]
0x0004ac:	str     	r1, [sp]
0x0004ae:	str     	r1, [sp, #4]
0x0004b0:	movs    	r1, #0x14
0x0004b2:	movs    	r2, #0x74
0x0004b4:	adds    	r3, r4, #0
0x0004b6:	adds    	r0, r5, #0
0x0004b8:	bl      	#0x1158
0x0004bc:	movs    	r1, #0
0x0004be:	str     	r1, [sp]
0x0004c0:	str     	r1, [sp, #4]
0x0004c2:	movs    	r2, #0
0x0004c4:	movs    	r1, #0xbf
0x0004c6:	adds    	r3, r4, #0
0x0004c8:	adds    	r0, r5, #0
0x0004ca:	str     	r2, [sp, #8]
0x0004cc:	bl      	#0x1158
0x0004d0:	cmp     	r0, #0
0x0004d2:	bne     	#0x4ec
0x0004d4:	movs    	r1, #0
0x0004d6:	movs    	r2, #0
0x0004d8:	str     	r2, [sp, #8]
0x0004da:	str     	r1, [sp]
0x0004dc:	str     	r1, [sp, #4]
0x0004de:	movs    	r3, #0xff
0x0004e0:	adds    	r3, #0x1c
0x0004e2:	movs    	r1, #0x14
0x0004e4:	movs    	r2, #0x17
0x0004e6:	adds    	r0, r5, #0
0x0004e8:	bl      	#0x1158
0x0004ec:	add     	sp, #0x10
0x0004ee:	pop     	{r4, r5, r6, pc}

; ===== candidate_0004f0 =====
0x0004f0:	push    	{r4, r5, r6, r7, lr}
0x0004f2:	sub     	sp, #0x14
0x0004f4:	movs    	r5, #0
0x0004f6:	movs    	r2, #0
0x0004f8:	movs    	r1, #0
0x0004fa:	str     	r2, [sp, #8]
0x0004fc:	adds    	r3, r5, #0
0x0004fe:	adds    	r4, r0, #0
0x000500:	adds    	r2, r0, #0
0x000502:	str     	r1, [sp]
0x000504:	str     	r1, [sp, #4]
0x000506:	movs    	r1, #0x44
0x000508:	movs    	r0, #0xf1
0x00050a:	lsls    	r0, r0, #9
0x00050c:	bl      	#0x1158
0x000510:	movs    	r1, #0
0x000512:	str     	r1, [sp]
0x000514:	str     	r1, [sp, #4]
0x000516:	movs    	r2, #0
0x000518:	str     	r2, [sp, #8]
0x00051a:	movs    	r1, #0x45
0x00051c:	adds    	r3, r5, #0
0x00051e:	movs    	r0, #0xf1
0x000520:	lsls    	r0, r0, #9
0x000522:	ldr     	r2, [r4, #8]
0x000524:	bl      	#0x1158
0x000528:	movs    	r1, #0
0x00052a:	str     	r1, [sp]
0x00052c:	str     	r1, [sp, #4]
0x00052e:	str     	r0, [sp, #0x10]
0x000530:	movs    	r2, #0
0x000532:	str     	r2, [sp, #8]
0x000534:	movs    	r0, #0xf1
0x000536:	movs    	r1, #0x45
0x000538:	adds    	r3, r5, #0
0x00053a:	lsls    	r0, r0, #9
0x00053c:	ldr     	r2, [r4, #8]
0x00053e:	bl      	#0x1158
0x000542:	movs    	r1, #0
0x000544:	str     	r1, [sp]
0x000546:	str     	r1, [sp, #4]
0x000548:	adds    	r6, r0, #0
0x00054a:	movs    	r2, #0
0x00054c:	str     	r2, [sp, #8]
0x00054e:	movs    	r0, #0xf1
0x000550:	adds    	r3, r5, #0
0x000552:	movs    	r1, #0x45
0x000554:	lsls    	r0, r0, #9
0x000556:	ldr     	r2, [r4, #8]
0x000558:	bl      	#0x1158
0x00055c:	movs    	r1, #0
0x00055e:	str     	r1, [sp]
0x000560:	str     	r1, [sp, #4]
0x000562:	adds    	r7, r0, #0
0x000564:	movs    	r2, #0
0x000566:	str     	r2, [sp, #8]
0x000568:	movs    	r0, #0xf1
0x00056a:	adds    	r3, r5, #0
0x00056c:	movs    	r1, #0x45
0x00056e:	lsls    	r0, r0, #9
0x000570:	ldr     	r2, [r4, #8]
0x000572:	bl      	#0x1158
0x000576:	movs    	r1, #0
0x000578:	str     	r1, [sp]
0x00057a:	str     	r1, [sp, #4]
0x00057c:	str     	r0, [sp, #0xc]
0x00057e:	movs    	r2, #0
0x000580:	str     	r2, [sp, #8]
0x000582:	movs    	r0, #0xf1
0x000584:	movs    	r1, #0x45
0x000586:	adds    	r3, r5, #0
0x000588:	lsls    	r0, r0, #9
0x00058a:	ldr     	r2, [r4, #8]
0x00058c:	bl      	#0x1158
0x000590:	adds    	r4, r0, #0
0x000592:	ldr     	r0, [sp, #0x10]
0x000594:	adds    	r3, r0, #1
0x000596:	beq     	#0x5c2
0x000598:	adds    	r3, r6, #1
0x00059a:	beq     	#0x5c2
0x00059c:	adds    	r3, r7, #1
0x00059e:	beq     	#0x5c2
0x0005a0:	movs    	r1, #0
0x0005a2:	movs    	r2, #0
0x0005a4:	str     	r2, [sp, #8]
0x0005a6:	str     	r1, [sp]
0x0005a8:	str     	r1, [sp, #4]
0x0005aa:	movs    	r1, #0xe1
0x0005ac:	movs    	r2, #0x72
0x0005ae:	adds    	r3, r5, #0
0x0005b0:	movs    	r0, #0xf1
0x0005b2:	lsls    	r0, r0, #9
0x0005b4:	bl      	#0x1158
0x0005b8:	ldr     	r1, [sp, #0x10]
0x0005ba:	lsls    	r1, r1, #2
0x0005bc:	ldr     	r0, [r0, r1]
0x0005be:	lsls    	r1, r6, #2
0x0005c0:	str     	r7, [r0, r1]
0x0005c2:	movs    	r1, #0
0x0005c4:	movs    	r2, #0
0x0005c6:	str     	r2, [sp, #8]
0x0005c8:	str     	r1, [sp]
0x0005ca:	str     	r1, [sp, #4]
0x0005cc:	movs    	r1, #0x14
0x0005ce:	movs    	r2, #0xf3
0x0005d0:	movs    	r0, #0xf1
0x0005d2:	lsls    	r0, r0, #9
0x0005d4:	ldr     	r3, [sp, #0xc]
0x0005d6:	bl      	#0x1158
0x0005da:	movs    	r1, #0
0x0005dc:	movs    	r2, #0
0x0005de:	str     	r2, [sp, #8]
0x0005e0:	str     	r1, [sp]
0x0005e2:	str     	r1, [sp, #4]
0x0005e4:	movs    	r1, #0x14
0x0005e6:	movs    	r2, #0xf4
0x0005e8:	adds    	r3, r4, #0
0x0005ea:	movs    	r0, #0xf1
0x0005ec:	lsls    	r0, r0, #9
0x0005ee:	bl      	#0x1158
0x0005f2:	movs    	r1, #0
0x0005f4:	movs    	r2, #0
0x0005f6:	str     	r2, [sp, #8]
0x0005f8:	str     	r1, [sp]
0x0005fa:	str     	r1, [sp, #4]
0x0005fc:	movs    	r1, #0x14
0x0005fe:	movs    	r2, #0xed
0x000600:	movs    	r3, #1
0x000602:	movs    	r0, #0xf1
0x000604:	lsls    	r0, r0, #9
0x000606:	bl      	#0x1158
0x00060a:	add     	sp, #0x14
0x00060c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000610 =====
0x000610:	push    	{r4, r5, r6, r7, lr}
0x000612:	sub     	sp, #0x6c
0x000614:	movs    	r0, #4
0x000616:	str     	r0, [sp, #0x5c]
0x000618:	str     	r0, [sp, #0x58]
0x00061a:	movs    	r1, #0
0x00061c:	movs    	r0, #0x32
0x00061e:	movs    	r2, #0
0x000620:	str     	r2, [sp, #8]
0x000622:	str     	r1, [sp]
0x000624:	str     	r1, [sp, #4]
0x000626:	movs    	r4, #0xf1
0x000628:	movs    	r6, #0
0x00062a:	adds    	r3, r6, #0
0x00062c:	lsls    	r4, r4, #9
0x00062e:	movs    	r1, #0xe1
0x000630:	movs    	r2, #0x72
0x000632:	str     	r0, [sp, #0x54]
0x000634:	str     	r0, [sp, #0x50]
0x000636:	adds    	r0, r4, #0
0x000638:	bl      	#0x1158
0x00063c:	cmp     	r0, #0
0x00063e:	beq     	#0x728
0x000640:	movs    	r1, #0
0x000642:	movs    	r2, #0
0x000644:	str     	r2, [sp, #8]
0x000646:	str     	r1, [sp]
0x000648:	str     	r1, [sp, #4]
0x00064a:	movs    	r1, #0xe1
0x00064c:	movs    	r2, #0xed
0x00064e:	adds    	r3, r6, #0
0x000650:	adds    	r0, r4, #0
0x000652:	bl      	#0x1158
0x000656:	cmp     	r0, #0
0x000658:	ble     	#0x728
0x00065a:	movs    	r1, #0
0x00065c:	str     	r1, [sp]
0x00065e:	str     	r1, [sp, #4]
0x000660:	movs    	r1, #0xff
0x000662:	movs    	r2, #0
0x000664:	adds    	r1, #0x25
0x000666:	adds    	r3, r6, #0
0x000668:	adds    	r0, r4, #0
0x00066a:	str     	r2, [sp, #8]
0x00066c:	bl      	#0x1158
0x000670:	movs    	r1, #0
0x000672:	str     	r1, [sp]
0x000674:	str     	r1, [sp, #4]
0x000676:	movs    	r2, #0
0x000678:	movs    	r1, #0x7d
0x00067a:	adds    	r3, r6, #0
0x00067c:	adds    	r0, r4, #0
0x00067e:	str     	r2, [sp, #8]
0x000680:	bl      	#0x1158
0x000684:	movs    	r1, #0
0x000686:	str     	r1, [sp]
0x000688:	str     	r1, [sp, #4]
0x00068a:	movs    	r2, #0
0x00068c:	movs    	r1, #0x5a
0x00068e:	adds    	r3, r6, #0
0x000690:	adds    	r0, r4, #0
0x000692:	str     	r2, [sp, #8]
0x000694:	bl      	#0x1158
0x000698:	movs    	r1, #0
0x00069a:	str     	r1, [sp]
0x00069c:	str     	r1, [sp, #4]
0x00069e:	movs    	r2, #0
0x0006a0:	movs    	r1, #0x1c
0x0006a2:	adds    	r3, r6, #0
0x0006a4:	adds    	r0, r4, #0
0x0006a6:	str     	r2, [sp, #8]
0x0006a8:	bl      	#0x1158
0x0006ac:	subs    	r0, #0xc8
0x0006ae:	lsrs    	r1, r0, #0x1f
0x0006b0:	adds    	r0, r1, r0
0x0006b2:	asrs    	r1, r0, #1
0x0006b4:	str     	r1, [sp, #0x4c]
0x0006b6:	movs    	r1, #0
0x0006b8:	str     	r1, [sp]
0x0006ba:	str     	r1, [sp, #4]
0x0006bc:	movs    	r2, #0
0x0006be:	movs    	r1, #0x1d
0x0006c0:	adds    	r3, r6, #0
0x0006c2:	adds    	r0, r4, #0
0x0006c4:	str     	r2, [sp, #8]
0x0006c6:	bl      	#0x1158
0x0006ca:	subs    	r0, #0xc8
0x0006cc:	lsrs    	r1, r0, #0x1f
0x0006ce:	adds    	r0, r1, r0
0x0006d0:	asrs    	r1, r0, #1
0x0006d2:	str     	r1, [sp, #0x48]
0x0006d4:	movs    	r5, #0
0x0006d6:	ldr     	r0, [sp, #0x58]
0x0006d8:	movs    	r4, #0
0x0006da:	cmp     	r0, #0
0x0006dc:	ble     	#0x7c2
0x0006de:	lsls    	r1, r5, #2
0x0006e0:	str     	r1, [sp, #0x68]
0x0006e2:	ldr     	r1, [sp, #0x50]
0x0006e4:	adds    	r0, r5, #0
0x0006e6:	muls    	r0, r1, r0
0x0006e8:	ldr     	r1, [sp, #0x48]
0x0006ea:	adds    	r3, r0, r1
0x0006ec:	str     	r3, [sp, #0x64]
0x0006ee:	movs    	r1, #0
0x0006f0:	movs    	r2, #0
0x0006f2:	str     	r2, [sp, #8]
0x0006f4:	str     	r1, [sp]
0x0006f6:	str     	r1, [sp, #4]
0x0006f8:	movs    	r7, #0
0x0006fa:	movs    	r6, #0xf1
0x0006fc:	lsls    	r6, r6, #9
0x0006fe:	adds    	r3, r7, #0
0x000700:	movs    	r1, #0xe1
0x000702:	movs    	r2, #0x72
0x000704:	adds    	r0, r6, #0
0x000706:	bl      	#0x1158
0x00070a:	lsls    	r1, r4, #2
0x00070c:	ldr     	r0, [r0, r1]
0x00070e:	ldr     	r1, [sp, #0x68]
0x000710:	movs    	r2, #0
0x000712:	ldr     	r0, [r0, r1]
0x000714:	ldr     	r1, [sp, #0x50]
0x000716:	str     	r0, [sp, #0x38]
0x000718:	ldr     	r0, [sp, #0x54]
0x00071a:	str     	r1, [sp, #4]
0x00071c:	ldr     	r1, [sp, #0x54]
0x00071e:	str     	r0, [sp]
0x000720:	adds    	r0, r4, #0
0x000722:	muls    	r0, r1, r0
0x000724:	str     	r2, [sp, #8]
0x000726:	b       	#0x72a
0x000728:	b       	#0xaa2
0x00072a:	ldr     	r1, [sp, #0x4c]
0x00072c:	ldr     	r3, [sp, #0x64]
0x00072e:	adds    	r2, r0, r1
0x000730:	movs    	r1, #0x32
0x000732:	adds    	r0, r6, #0
0x000734:	str     	r2, [sp, #0x60]
0x000736:	bl      	#0x1158
0x00073a:	movs    	r1, #0

; ===== candidate_000ac0 =====
0x000ac0:	push    	{r4, r5, r6, r7, lr}
0x000ac2:	sub     	sp, #0xc
0x000ac4:	movs    	r1, #0
0x000ac6:	movs    	r2, #0
0x000ac8:	str     	r2, [sp, #8]
0x000aca:	str     	r1, [sp]
0x000acc:	str     	r1, [sp, #4]
0x000ace:	movs    	r7, #0xf1
0x000ad0:	movs    	r5, #0
0x000ad2:	adds    	r3, r5, #0
0x000ad4:	lsls    	r7, r7, #9
0x000ad6:	movs    	r1, #0xe1
0x000ad8:	movs    	r2, #0x78
0x000ada:	adds    	r0, r7, #0
0x000adc:	bl      	#0x1158
0x000ae0:	movs    	r1, #0
0x000ae2:	movs    	r2, #0
0x000ae4:	str     	r2, [sp, #8]
0x000ae6:	str     	r1, [sp]
0x000ae8:	str     	r1, [sp, #4]
0x000aea:	movs    	r1, #0x11
0x000aec:	adds    	r2, r0, #0
0x000aee:	movs    	r3, #4
0x000af0:	adds    	r0, r7, #0
0x000af2:	bl      	#0x1158
0x000af6:	adds    	r6, r0, #0
0x000af8:	movs    	r4, #0
0x000afa:	cmp     	r0, #0
0x000afc:	ble     	#0xb5a
0x000afe:	movs    	r1, #0
0x000b00:	movs    	r2, #0
0x000b02:	str     	r2, [sp, #8]
0x000b04:	str     	r1, [sp]
0x000b06:	str     	r1, [sp, #4]
0x000b08:	movs    	r1, #0xe1
0x000b0a:	movs    	r2, #0x78
0x000b0c:	movs    	r3, #0
0x000b0e:	adds    	r0, r7, #0
0x000b10:	bl      	#0x1158
0x000b14:	lsls    	r1, r4, #2
0x000b16:	ldr     	r5, [r0, r1]
0x000b18:	movs    	r1, #0
0x000b1a:	movs    	r2, #0
0x000b1c:	str     	r2, [sp, #8]
0x000b1e:	str     	r1, [sp]
0x000b20:	str     	r1, [sp, #4]
0x000b22:	movs    	r1, #0xe1
0x000b24:	movs    	r2, #0x34
0x000b26:	movs    	r0, #0xf1
0x000b28:	movs    	r3, #0
0x000b2a:	lsls    	r0, r0, #9
0x000b2c:	bl      	#0x1158
0x000b30:	cmp     	r0, r5
0x000b32:	beq     	#0xb54
0x000b34:	movs    	r1, #0
0x000b36:	movs    	r2, #0
0x000b38:	str     	r2, [sp, #8]
0x000b3a:	str     	r1, [sp]
0x000b3c:	str     	r1, [sp, #4]
0x000b3e:	movs    	r1, #0xe1
0x000b40:	movs    	r2, #0x71
0x000b42:	movs    	r3, #0
0x000b44:	adds    	r0, r7, #0
0x000b46:	bl      	#0x1158
0x000b4a:	cmp     	r0, r5
0x000b4c:	beq     	#0xb54
0x000b4e:	adds    	r0, r5, #0
0x000b50:	add     	sp, #0xc
0x000b52:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000b60 =====
0x000b60:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x000b62:	sub     	sp, #0xc
0x000b64:	adds    	r4, r1, #0
0x000b66:	movs    	r1, #0
0x000b68:	movs    	r2, #0
0x000b6a:	str     	r2, [sp, #8]
0x000b6c:	str     	r1, [sp]
0x000b6e:	str     	r1, [sp, #4]
0x000b70:	movs    	r5, #0xf1
0x000b72:	lsls    	r5, r5, #9
0x000b74:	movs    	r1, #0xe1
0x000b76:	movs    	r2, #0xc3
0x000b78:	movs    	r3, #0
0x000b7a:	adds    	r0, r5, #0
0x000b7c:	ldr     	r6, [sp, #0x30]
0x000b7e:	ldr     	r7, [sp, #0x34]
0x000b80:	bl      	#0x1158
0x000b84:	cmp     	r0, #0
0x000b86:	bne     	#0xb9e
0x000b88:	movs    	r1, #0
0x000b8a:	movs    	r2, #0
0x000b8c:	str     	r2, [sp, #8]
0x000b8e:	str     	r1, [sp]
0x000b90:	str     	r1, [sp, #4]
0x000b92:	movs    	r1, #0x14
0x000b94:	movs    	r2, #0xc3
0x000b96:	movs    	r3, #1
0x000b98:	adds    	r0, r5, #0
0x000b9a:	bl      	#0x1158
0x000b9e:	ldr     	r0, [sp, #0xc]
0x000ba0:	cmp     	r0, #0xc
0x000ba2:	blo     	#0xba6
0x000ba4:	b       	#0xc80
0x000ba6:	adr     	r3, #8
0x000ba8:	ldrb    	r3, [r3, r0]
0x000baa:	lsls    	r3, r3, #1
0x000bac:	add     	pc, r3
0x000bae:	movs    	r0, r0
0x000bb0:	ldr     	r7, [pc, #0x110]
0x000bb2:	eors    	r2, r3
0x000bb4:	adds    	r6, #0x3b
0x000bb6:	cmp     	r6, #0x32
0x000bb8:	movs    	r5, #0x2a
0x000bba:	lsls    	r3, r1, #0x18
0x000bbc:	bl      	#0x360
0x000bc0:	movs    	r0, #0
0x000bc2:	add     	sp, #0x1c
0x000bc4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000c98 =====
0x000c98:	push    	{r4, r5, lr}
0x000c9a:	sub     	sp, #0xc
0x000c9c:	movs    	r1, #0
0x000c9e:	movs    	r2, #0
0x000ca0:	str     	r2, [sp, #8]
0x000ca2:	str     	r1, [sp]
0x000ca4:	str     	r1, [sp, #4]
0x000ca6:	movs    	r5, #0xf1
0x000ca8:	movs    	r4, #0
0x000caa:	adds    	r3, r4, #0
0x000cac:	lsls    	r5, r5, #9
0x000cae:	movs    	r1, #3
0x000cb0:	movs    	r2, #4
0x000cb2:	adds    	r0, r5, #0
0x000cb4:	bl      	#0x1158
0x000cb8:	cmp     	r0, #0
0x000cba:	bne     	#0xce0
0x000cbc:	movs    	r1, #0
0x000cbe:	movs    	r2, #0
0x000cc0:	str     	r2, [sp, #8]
0x000cc2:	str     	r1, [sp]
0x000cc4:	str     	r1, [sp, #4]
0x000cc6:	movs    	r1, #0xe1
0x000cc8:	movs    	r2, #0xf4
0x000cca:	adds    	r3, r4, #0
0x000ccc:	adds    	r0, r5, #0
0x000cce:	bl      	#0x1158
0x000cd2:	cmp     	r0, #0
0x000cd4:	ble     	#0xd52
0x000cd6:	movs    	r0, #0xc
0x000cd8:	bl      	#0xe60
0x000cdc:	add     	sp, #0xc
0x000cde:	pop     	{r4, r5, pc}

; ===== candidate_000d6c =====
0x000d6c:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x000d6e:	sub     	sp, #0xc
0x000d70:	adds    	r6, r2, #0
0x000d72:	movs    	r1, #0
0x000d74:	adds    	r7, r3, #0
0x000d76:	adds    	r3, r6, #0
0x000d78:	movs    	r2, #0
0x000d7a:	str     	r2, [sp, #8]
0x000d7c:	movs    	r6, #0xf1
0x000d7e:	str     	r1, [sp]
0x000d80:	str     	r1, [sp, #4]
0x000d82:	movs    	r1, #0x14
0x000d84:	lsls    	r6, r6, #9
0x000d86:	movs    	r2, #0xf3
0x000d88:	adds    	r5, r0, #0
0x000d8a:	adds    	r0, r6, #0
0x000d8c:	ldr     	r4, [sp, #0x30]
0x000d8e:	bl      	#0x1158
0x000d92:	movs    	r1, #0
0x000d94:	movs    	r2, #0
0x000d96:	str     	r2, [sp, #8]
0x000d98:	str     	r1, [sp]
0x000d9a:	str     	r1, [sp, #4]
0x000d9c:	movs    	r1, #0x14
0x000d9e:	movs    	r2, #0xf4
0x000da0:	adds    	r3, r7, #0
0x000da2:	adds    	r0, r6, #0
0x000da4:	bl      	#0x1158
0x000da8:	movs    	r1, #0
0x000daa:	movs    	r2, #0
0x000dac:	str     	r2, [sp, #8]
0x000dae:	str     	r1, [sp]
0x000db0:	str     	r1, [sp, #4]
0x000db2:	movs    	r7, #0
0x000db4:	adds    	r3, r7, #0
0x000db6:	movs    	r1, #0x14
0x000db8:	movs    	r2, #0xf7
0x000dba:	adds    	r0, r6, #0
0x000dbc:	bl      	#0x1158
0x000dc0:	ldr     	r0, [pc, #0x98]
0x000dc2:	movs    	r1, #0
0x000dc4:	add     	r0, sb
0x000dc6:	strb    	r4, [r0]
0x000dc8:	str     	r7, [r0, #4]
0x000dca:	movs    	r2, #0
0x000dcc:	str     	r2, [sp, #8]
0x000dce:	str     	r1, [sp]
0x000dd0:	str     	r1, [sp, #4]
0x000dd2:	movs    	r1, #0x14
0x000dd4:	movs    	r2, #0x72
0x000dd6:	adds    	r0, r6, #0
0x000dd8:	ldr     	r3, [sp, #0x10]
0x000dda:	bl      	#0x1158
0x000dde:	cmp     	r5, #0
0x000de0:	bne     	#0xdf8
0x000de2:	movs    	r1, #0
0x000de4:	str     	r1, [sp]
0x000de6:	str     	r1, [sp, #4]
0x000de8:	movs    	r2, #0
0x000dea:	movs    	r1, #0x34
0x000dec:	adds    	r3, r7, #0
0x000dee:	adds    	r0, r6, #0
0x000df0:	str     	r2, [sp, #8]
0x000df2:	bl      	#0x1158
0x000df6:	b       	#0xe0e
0x000df8:	movs    	r1, #0
0x000dfa:	movs    	r2, #0
0x000dfc:	str     	r2, [sp, #8]
0x000dfe:	str     	r1, [sp]
0x000e00:	str     	r1, [sp, #4]
0x000e02:	movs    	r1, #0x14
0x000e04:	movs    	r2, #0x74
0x000e06:	adds    	r3, r5, #0
0x000e08:	adds    	r0, r6, #0
0x000e0a:	bl      	#0x1158
0x000e0e:	movs    	r1, #0
0x000e10:	movs    	r2, #0
0x000e12:	str     	r2, [sp, #8]
0x000e14:	str     	r1, [sp]
0x000e16:	str     	r1, [sp, #4]
0x000e18:	movs    	r3, #0xff
0x000e1a:	adds    	r3, #0x1c
0x000e1c:	movs    	r1, #0x14
0x000e1e:	movs    	r2, #0x17
0x000e20:	adds    	r0, r6, #0
0x000e22:	bl      	#0x1158
0x000e26:	cmp     	r4, #0
0x000e28:	bne     	#0xe58
0x000e2a:	movs    	r1, #0
0x000e2c:	str     	r1, [sp]
0x000e2e:	str     	r1, [sp, #4]
0x000e30:	movs    	r2, #0
0x000e32:	movs    	r1, #0x34
0x000e34:	adds    	r3, r7, #0
0x000e36:	adds    	r0, r6, #0
0x000e38:	str     	r2, [sp, #8]
0x000e3a:	bl      	#0x1158
0x000e3e:	movs    	r2, #0
0x000e40:	movs    	r1, #0
0x000e42:	str     	r2, [sp, #8]
0x000e44:	movs    	r2, #0xff
0x000e46:	str     	r1, [sp]
0x000e48:	str     	r1, [sp, #4]
0x000e4a:	adds    	r3, r7, #0
0x000e4c:	adds    	r2, #0x60
0x000e4e:	movs    	r1, #0x50
0x000e50:	movs    	r0, #0xf1
0x000e52:	lsls    	r0, r0, #9
0x000e54:	bl      	#0x1158
0x000e58:	add     	sp, #0x1c
0x000e5a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000e60 =====
0x000e60:	push    	{r4, r5, r6, lr}
0x000e62:	sub     	sp, #0x10
0x000e64:	movs    	r1, #0
0x000e66:	movs    	r2, #0
0x000e68:	str     	r2, [sp, #8]
0x000e6a:	str     	r1, [sp]
0x000e6c:	str     	r1, [sp, #4]
0x000e6e:	movs    	r5, #0xf1
0x000e70:	movs    	r4, #0
0x000e72:	adds    	r3, r4, #0
0x000e74:	lsls    	r5, r5, #9
0x000e76:	movs    	r1, #0xe1
0x000e78:	movs    	r2, #0xf7
0x000e7a:	adds    	r6, r0, #0
0x000e7c:	adds    	r0, r5, #0
0x000e7e:	bl      	#0x1158
0x000e82:	cmp     	r0, #0
0x000e84:	bne     	#0xf1a
0x000e86:	ldr     	r0, [pc, #0x234]
0x000e88:	add     	r0, sb
0x000e8a:	ldr     	r0, [r0, #4]
0x000e8c:	cmp     	r0, #0
0x000e8e:	bne     	#0xf1a
0x000e90:	movs    	r1, #0
0x000e92:	movs    	r2, #0
0x000e94:	str     	r2, [sp, #8]
0x000e96:	str     	r1, [sp]
0x000e98:	str     	r1, [sp, #4]
0x000e9a:	movs    	r1, #0xe1
0x000e9c:	movs    	r2, #0x79
0x000e9e:	adds    	r3, r4, #0
0x000ea0:	adds    	r0, r5, #0
0x000ea2:	bl      	#0x1158
0x000ea6:	cmp     	r0, #0
0x000ea8:	bne     	#0xeae
0x000eaa:	cmp     	r6, #0x12
0x000eac:	bne     	#0xf1a
0x000eae:	subs    	r6, #2
0x000eb0:	cmp     	r6, #0x11
0x000eb2:	bhs     	#0xf1a
0x000eb4:	adr     	r3, #4
0x000eb6:	ldrb    	r3, [r3, r6]
0x000eb8:	lsls    	r3, r3, #1
0x000eba:	add     	pc, r3
0x000ebc:	cmp     	r6, #0x30
0x000ebe:	cmp     	r6, #0x57
0x000ec0:	cmp     	r6, #0x7e
0x000ec2:	cmp     	r6, #8
0x000ec4:	cmp     	r6, #0x2e
0x000ec6:	lsrs    	r0, r6, #0x20
0x000ec8:	ldrb    	r7, [r2, #0x19]
0x000eca:	cmp     	r6, #0x2e
0x000ecc:	lsls    	r5, r4, #2
0x000ece:	movs    	r1, #0
0x000ed0:	movs    	r2, #0
0x000ed2:	str     	r2, [sp, #8]
0x000ed4:	str     	r1, [sp]
0x000ed6:	str     	r1, [sp, #4]
0x000ed8:	movs    	r1, #0xe1
0x000eda:	movs    	r2, #0xf4
0x000edc:	adds    	r3, r4, #0
0x000ede:	adds    	r0, r5, #0
0x000ee0:	bl      	#0x1158
0x000ee4:	cmp     	r0, #3
0x000ee6:	bge     	#0xf1a
0x000ee8:	movs    	r1, #0
0x000eea:	movs    	r2, #0
0x000eec:	str     	r2, [sp, #8]
0x000eee:	str     	r1, [sp]
0x000ef0:	str     	r1, [sp, #4]
0x000ef2:	movs    	r1, #4
0x000ef4:	movs    	r2, #0xf4
0x000ef6:	adds    	r3, r4, #0
0x000ef8:	adds    	r0, r5, #0
0x000efa:	bl      	#0x1158
0x000efe:	movs    	r2, #0
0x000f00:	movs    	r1, #1
0x000f02:	str     	r1, [sp, #4]
0x000f04:	str     	r2, [sp, #8]
0x000f06:	str     	r0, [sp]
0x000f08:	movs    	r0, #0xf1
0x000f0a:	movs    	r2, #4
0x000f0c:	movs    	r1, #0x29
0x000f0e:	adds    	r3, r4, #0
0x000f10:	lsls    	r0, r0, #9
0x000f12:	bl      	#0x1158
0x000f16:	bl      	#0x104
0x000f1a:	add     	sp, #0x10
0x000f1c:	pop     	{r4, r5, r6, pc}

; ===== candidate_0010c8 =====
0x0010c8:	push    	{r3, r4, r5, lr}
0x0010ca:	ldr     	r4, [pc, #0x74]
0x0010cc:	add     	r4, pc
0x0010ce:	ldr     	r0, [r4, #0x38]
0x0010d0:	movs    	r1, #0x14
0x0010d2:	ldr     	r2, [r0, #0x64]
0x0010d4:	ldr     	r0, [pc, #0x6c]
0x0010d6:	add     	r0, pc
0x0010d8:	blx     	r2
0x0010da:	movs    	r5, #0
0x0010dc:	mvns    	r5, r5
0x0010de:	cmp     	r0, r5
0x0010e0:	bne     	#0x10e6
0x0010e2:	adds    	r0, r5, #0
0x0010e4:	pop     	{r3, r4, r5, pc}

; ===== candidate_001158 =====
0x001158:	push    	{r4, r5, r6, r7, lr}
0x00115a:	adds    	r5, r1, #0
0x00115c:	adds    	r4, r0, #0
0x00115e:	adds    	r6, r2, #0
0x001160:	ldr     	r2, [pc, #0x28]
0x001162:	sub     	sp, #0x14
0x001164:	mov     	ip, r3
0x001166:	add     	r2, pc
0x001168:	ldr     	r0, [sp, #0x2c]
0x00116a:	ldr     	r1, [sp, #0x30]
0x00116c:	ldr     	r7, [sp, #0x28]
0x00116e:	ldr     	r3, [r2, #0x3c]
0x001170:	movs    	r2, #2
0x001172:	str     	r2, [sp, #0xc]
0x001174:	str     	r1, [sp, #8]
0x001176:	str     	r0, [sp, #4]
0x001178:	str     	r7, [sp]
0x00117a:	ldr     	r0, [r3, #0xc]
0x00117c:	adds    	r1, r5, #0
0x00117e:	adds    	r2, r6, #0
0x001180:	ldr     	r7, [r0, #0x28]
0x001182:	adds    	r0, r4, #0
0x001184:	mov     	r3, ip
0x001186:	blx     	r7
0x001188:	add     	sp, #0x14
0x00118a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_001194 =====
0x001194:	push    	{r4, lr}
0x001196:	movs    	r2, #0
0x001198:	add     	r0, pc
0x00119a:	ldr     	r4, [r0, #0x3c]
0x00119c:	sub     	sp, #0x10
0x00119e:	movs    	r1, #0
0x0011a0:	str     	r1, [sp, #4]
0x0011a2:	str     	r1, [sp, #8]
0x0011a4:	str     	r2, [sp, #0xc]
0x0011a6:	str     	r2, [sp]
0x0011a8:	ldr     	r0, [r4, #0xc]
0x0011aa:	ldr     	r2, [r0, #0x24]
0x0011ac:	ldr     	r4, [r0, #0x28]
0x0011ae:	blx     	r4
0x0011b0:	add     	sp, #0x10
0x0011b2:	pop     	{r4, pc}

; ===== candidate_0011b8 =====
0x0011b8:	push    	{r4, lr}
0x0011ba:	ldr     	r0, [pc, #0x24]
0x0011bc:	sub     	sp, #0x10
0x0011be:	add     	r0, pc
0x0011c0:	ldr     	r3, [r0, #0x3c]
0x0011c2:	movs    	r2, #0
0x0011c4:	movs    	r1, #0
0x0011c6:	str     	r1, [sp, #4]
0x0011c8:	str     	r1, [sp, #8]
0x0011ca:	str     	r2, [sp, #0xc]
0x0011cc:	str     	r2, [sp]
0x0011ce:	ldr     	r0, [r3, #0xc]
0x0011d0:	movs    	r3, #0
0x0011d2:	ldr     	r2, [r0, #0x24]
0x0011d4:	ldr     	r4, [r0, #0x28]
0x0011d6:	movs    	r1, #1
0x0011d8:	blx     	r4
0x0011da:	add     	sp, #0x10
0x0011dc:	pop     	{r4, pc}

; ===== candidate_0011f8 =====
0x0011f8:	push    	{r4, lr}
0x0011fa:	sub     	sp, #0x10
0x0011fc:	movs    	r2, #0
0x0011fe:	movs    	r1, #0
0x001200:	str     	r2, [sp, #8]
0x001202:	ldr     	r2, [pc, #0x3c]
0x001204:	str     	r1, [sp]
0x001206:	str     	r1, [sp, #4]
0x001208:	movs    	r3, #0
0x00120a:	add     	r2, pc
0x00120c:	ldr     	r1, [pc, #0x34]
0x00120e:	ldr     	r0, [pc, #0x38]
0x001210:	bl      	#0x1158
0x001214:	ldr     	r3, [pc, #0x38]
0x001216:	ldr     	r4, [pc, #0x34]
0x001218:	add     	r3, sb
0x00121a:	ldr     	r3, [r3]
0x00121c:	movs    	r2, #0x41
0x00121e:	movs    	r1, #0
0x001220:	add     	r4, sb
0x001222:	adds    	r0, r4, #0
0x001224:	blx     	r3
0x001226:	bl      	#0x11e4
0x00122a:	ldr     	r3, [pc, #0x28]
0x00122c:	adds    	r1, r0, #0
0x00122e:	add     	r3, sb
0x001230:	ldr     	r3, [r3]
0x001232:	movs    	r2, #0x41
0x001234:	adds    	r0, r4, #0
0x001236:	blx     	r3
0x001238:	movs    	r0, #0
0x00123a:	add     	sp, #0x10
0x00123c:	pop     	{r4, pc}

; ===== candidate_00125c =====
0x00125c:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00125e:	adds    	r7, r3, #0
0x001260:	adds    	r6, r2, #0
0x001262:	adds    	r5, r0, #0
0x001264:	ldr     	r0, [r0]
0x001266:	sub     	sp, #4
0x001268:	mov     	r1, sb
0x00126a:	str     	r1, [sp]
0x00126c:	movs    	r4, #0
0x00126e:	blx     	#0x34
0x001272:	ldr     	r0, [sp, #8]
0x001274:	cmp     	r0, #0xb
0x001276:	bhs     	#0x12e4
0x001278:	adr     	r3, #4
0x00127a:	ldrb    	r3, [r3, r0]
0x00127c:	lsls    	r3, r3, #1
0x00127e:	add     	pc, r3
0x001280:	lsrs    	r5, r0, #0x1c
0x001282:	subs    	r4, r3, #4
0x001284:	movs    	r4, #0x21
0x001286:	adds    	r1, #0x27
0x001288:	adds    	r1, #0x2b
0x00128a:	movs    	r7, r5
0x00128c:	ldr     	r1, [pc, #0x60]
0x00128e:	ldr     	r0, [r5, #0xc]
0x001290:	add     	r1, sb
0x001292:	str     	r0, [r1, #0x14]
0x001294:	bl      	#0x3c
0x001298:	bl      	#0x11f8
0x00129c:	adds    	r4, r0, #0
0x00129e:	b       	#0x12e4
0x0012a0:	ldr     	r0, [r6]
0x0012a2:	cmp     	r0, #8
0x0012a4:	bne     	#0x12ae
0x0012a6:	bl      	#0x1154
0x0012aa:	adds    	r4, r0, #0
0x0012ac:	b       	#0x12e4
0x0012ae:	ldr     	r1, [r6, #4]
0x0012b0:	ldr     	r2, [r6, #8]
0x0012b2:	bl      	#0x1150
0x0012b6:	adds    	r4, r0, #0
0x0012b8:	b       	#0x12e4
0x0012ba:	bl      	#0x14ec
0x0012be:	b       	#0x12e4
0x0012c0:	str     	r7, [r5, #0xc]
0x0012c2:	b       	#0x12e4
0x0012c4:	bl      	#0x1258
0x0012c8:	b       	#0x12e4
0x0012ca:	bl      	#0x1328
0x0012ce:	b       	#0x12e4
0x0012d0:	ldr     	r0, [pc, #0x1c]
0x0012d2:	add     	r0, sb
0x0012d4:	str     	r7, [r0, #0x1c]
0x0012d6:	b       	#0x12e4
0x0012d8:	ldr     	r0, [pc, #0x14]
0x0012da:	add     	r0, sb
0x0012dc:	str     	r6, [r0, #0x20]
0x0012de:	b       	#0x12e4
0x0012e0:	ldr     	r4, [pc, #0x10]
0x0012e2:	add     	r4, pc
0x0012e4:	ldr     	r1, [sp]
0x0012e6:	add     	sp, #0x14
0x0012e8:	adds    	r0, r4, #0
0x0012ea:	mov     	sb, r1
0x0012ec:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0012f8 =====
0x0012f8:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0012fa:	sub     	sp, #0xc
0x0012fc:	ldr     	r0, [sp, #0x38]
0x0012fe:	ldr     	r4, [sp, #0x3c]
0x001300:	ldr     	r6, [sp, #0x34]
0x001302:	ldr     	r0, [r0]
0x001304:	mov     	r7, sb
0x001306:	movs    	r5, #0
0x001308:	blx     	#0x34
0x00130c:	cmp     	r4, #0
0x00130e:	beq     	#0x131e
0x001310:	ldr     	r1, [sp, #0x30]
0x001312:	str     	r6, [sp, #4]
0x001314:	add     	r3, sp, #0xc
0x001316:	str     	r1, [sp]
0x001318:	ldm     	r3, {r0, r1, r2, r3}
0x00131a:	blx     	r4
0x00131c:	adds    	r5, r0, #0
0x00131e:	mov     	sb, r7
0x001320:	adds    	r0, r5, #0
0x001322:	add     	sp, #0x1c
0x001324:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00138c =====
0x00138c:	push    	{r3, r4, r5, r6, r7, lr}
0x00138e:	adds    	r4, r0, #0
0x001390:	ldr     	r0, [pc, #0x10c]
0x001392:	movs    	r5, #0
0x001394:	mvns    	r5, r5
0x001396:	mov     	ip, r2
0x001398:	add     	r0, pc
0x00139a:	ldr     	r2, [r0, #0x38]
0x00139c:	cmp     	r4, #0
0x00139e:	bne     	#0x13b0
0x0013a0:	ldr     	r0, [pc, #0x100]
0x0013a2:	ldr     	r2, [r2, #0x68]
0x0013a4:	movs    	r1, #0x7d
0x0013a6:	lsls    	r1, r1, #3
0x0013a8:	add     	r0, pc
0x0013aa:	blx     	r2
0x0013ac:	adds    	r0, r5, #0
0x0013ae:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_0014b8 =====
0x0014b8:	push    	{r3, r4, r5, lr}
0x0014ba:	ldr     	r4, [pc, #0x28]
0x0014bc:	adds    	r5, r0, #0
0x0014be:	add     	r4, pc
0x0014c0:	ldr     	r0, [r4, #0x38]
0x0014c2:	adds    	r0, #0x80
0x0014c4:	ldr     	r0, [r0, #4]
0x0014c6:	blx     	r0
0x0014c8:	adds    	r0, r0, r5
0x0014ca:	ldr     	r1, [pc, #0x1c]
0x0014cc:	add     	r1, sb
0x0014ce:	str     	r0, [r1, #0x10]
0x0014d0:	ldr     	r0, [r4, #0x38]
0x0014d2:	adds    	r0, #0x80
0x0014d4:	ldr     	r0, [r0]
0x0014d6:	blx     	r0
0x0014d8:	ldr     	r0, [r4, #0x38]
0x0014da:	ldr     	r1, [r0, #0x7c]
0x0014dc:	lsls    	r0, r5, #0x10
0x0014de:	lsrs    	r0, r0, #0x10
0x0014e0:	blx     	r1
0x0014e2:	pop     	{r3, r4, r5, pc}

; ===== candidate_0014ee =====
0x0014ee:	push    	{r3, r4, r5, r6, r7, lr}
0x0014f0:	add     	r0, pc
0x0014f2:	ldr     	r0, [r0, #0x38]
0x0014f4:	adds    	r0, #0x80
0x0014f6:	ldr     	r0, [r0, #4]
0x0014f8:	blx     	r0
0x0014fa:	movs    	r5, #0
0x0014fc:	ldr     	r6, [pc, #0xc8]
0x0014fe:	add     	r6, sb
0x001500:	ldr     	r1, [r6, #0x10]
0x001502:	str     	r5, [r6, #0x10]
0x001504:	subs    	r1, r0, r1
0x001506:	ldr     	r0, [r6, #8]
0x001508:	adds    	r3, r1, #0
0x00150a:	cmp     	r0, #0
0x00150c:	beq     	#0x15c2
0x00150e:	ldr     	r2, [r0, #8]
0x001510:	cmp     	r2, #0
0x001512:	bne     	#0x1572
0x001514:	mvns    	r7, r2
0x001516:	str     	r7, [r0, #8]
0x001518:	ldr     	r2, [r0, #0x18]
0x00151a:	adds    	r4, r0, #0
0x00151c:	cmp     	r1, #0x32
0x00151e:	str     	r2, [r6, #8]
0x001520:	bge     	#0x1526
0x001522:	movs    	r1, #0x32
0x001524:	b       	#0x1542
0x001526:	movs    	r2, #0x7d
0x001528:	lsls    	r2, r2, #4
0x00152a:	cmp     	r1, r2
0x00152c:	ble     	#0x1542
0x00152e:	adds    	r1, r2, #0
0x001530:	b       	#0x1542
0x001532:	movs    	r7, #0
0x001534:	mvns    	r7, r7
0x001536:	str     	r7, [r2, #8]
0x001538:	ldr     	r2, [r0, #0x18]
0x00153a:	str     	r2, [r0, #0x1c]
0x00153c:	ldr     	r0, [r2, #0x18]
0x00153e:	str     	r0, [r6, #8]
0x001540:	adds    	r0, r2, #0
0x001542:	ldr     	r2, [r0, #0x18]
0x001544:	cmp     	r2, #0
0x001546:	beq     	#0x154e
0x001548:	ldr     	r7, [r2, #8]
0x00154a:	cmp     	r7, r1
0x00154c:	blt     	#0x1532
0x00154e:	str     	r5, [r0, #0x1c]
0x001550:	ldr     	r0, [r6, #8]
0x001552:	cmp     	r0, #0
0x001554:	beq     	#0x15b6
0x001556:	cmp     	r3, #0
0x001558:	bge     	#0x155c
0x00155a:	movs    	r3, #0
0x00155c:	ldr     	r0, [r6, #8]
0x00155e:	ldr     	r1, [r0, #8]
0x001560:	cmp     	r1, #0
0x001562:	bge     	#0x1568
0x001564:	movs    	r1, #0
0x001566:	str     	r5, [r0, #8]
0x001568:	ldr     	r2, [pc, #0x60]
0x00156a:	cmp     	r1, r2
0x00156c:	ble     	#0x1576
0x00156e:	adds    	r1, r2, #0
0x001570:	b       	#0x1576
0x001572:	movs    	r4, #0
0x001574:	b       	#0x1556
0x001576:	ldr     	r2, [r0, #8]
0x001578:	subs    	r2, r2, r1
0x00157a:	str     	r2, [r0, #8]
0x00157c:	ldr     	r0, [r0, #0x18]
0x00157e:	cmp     	r0, #0
0x001580:	bne     	#0x1576
0x001582:	subs    	r0, r1, r3
0x001584:	cmp     	r0, #0
0x001586:	bgt     	#0x158a
0x001588:	movs    	r0, #0xa
0x00158a:	bl      	#0x14b8
0x00158e:	b       	#0x15b6
0x001590:	str     	r5, [r4, #8]
0x001592:	ldr     	r0, [r4, #0x1c]
0x001594:	adds    	r3, r5, #0
0x001596:	str     	r0, [r6, #0xc]
0x001598:	ldr     	r0, [r4, #0x14]
0x00159a:	cmp     	r0, #0
0x00159c:	beq     	#0x15aa
0x00159e:	str     	r0, [sp]
0x0015a0:	movs    	r1, #0
0x0015a2:	adds    	r0, r4, #0
0x0015a4:	ldr     	r2, [r4, #0x10]
0x0015a6:	bl      	#0x138c
0x0015aa:	ldr     	r1, [r4, #0xc]
0x0015ac:	cmp     	r1, #0
0x0015ae:	beq     	#0x15b4
0x0015b0:	ldr     	r0, [r4, #0x10]
0x0015b2:	blx     	r1
0x0015b4:	ldr     	r4, [r6, #0xc]
0x0015b6:	cmp     	r4, #0
0x0015b8:	beq     	#0x15c0
0x0015ba:	ldr     	r0, [r4, #8]
0x0015bc:	cmp     	r0, #0
0x0015be:	blt     	#0x1590
0x0015c0:	str     	r5, [r6, #0xc]
0x0015c2:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_0015d0 =====
0x0015d0:	push    	{r4, r5, lr}
0x0015d2:	sub     	sp, #0xc
0x0015d4:	movs    	r1, #0
0x0015d6:	movs    	r2, #0
0x0015d8:	str     	r2, [sp, #8]
0x0015da:	str     	r1, [sp]
0x0015dc:	str     	r1, [sp, #4]
0x0015de:	movs    	r4, #0
0x0015e0:	adds    	r3, r4, #0
0x0015e2:	movs    	r1, #0xe1
0x0015e4:	movs    	r2, #0x72
0x0015e6:	movs    	r0, #0xf1
0x0015e8:	lsls    	r0, r0, #9
0x0015ea:	bl      	#0x1158
0x0015ee:	movs    	r2, #0
0x0015f0:	movs    	r1, #0
0x0015f2:	str     	r2, [sp, #8]
0x0015f4:	adds    	r3, r4, #0
0x0015f6:	adds    	r2, r0, #0
0x0015f8:	str     	r1, [sp]
0x0015fa:	str     	r1, [sp, #4]
0x0015fc:	movs    	r1, #0x12
0x0015fe:	movs    	r0, #0xf1
0x001600:	lsls    	r0, r0, #9
0x001602:	bl      	#0x1158
0x001606:	movs    	r1, #0
0x001608:	movs    	r2, #0
0x00160a:	str     	r2, [sp, #8]
0x00160c:	str     	r1, [sp]
0x00160e:	str     	r1, [sp, #4]
0x001610:	movs    	r1, #0x14
0x001612:	movs    	r2, #0x72
0x001614:	adds    	r3, r4, #0
0x001616:	movs    	r0, #0xf1
0x001618:	lsls    	r0, r0, #9
0x00161a:	bl      	#0x1158
0x00161e:	movs    	r1, #0
0x001620:	movs    	r2, #0
0x001622:	str     	r2, [sp, #8]
0x001624:	str     	r1, [sp]
0x001626:	str     	r1, [sp, #4]
0x001628:	movs    	r1, #0xe1
0x00162a:	movs    	r2, #0x7a
0x00162c:	adds    	r3, r4, #0
0x00162e:	movs    	r0, #0xf1
0x001630:	lsls    	r0, r0, #9
0x001632:	bl      	#0x1158
0x001636:	movs    	r2, #0
0x001638:	movs    	r1, #0
0x00163a:	str     	r2, [sp, #8]
0x00163c:	adds    	r3, r4, #0
0x00163e:	adds    	r2, r0, #0
0x001640:	str     	r1, [sp]
0x001642:	str     	r1, [sp, #4]
0x001644:	movs    	r1, #9
0x001646:	movs    	r0, #0xf1
0x001648:	lsls    	r0, r0, #9
0x00164a:	bl      	#0x1158
0x00164e:	movs    	r1, #0
0x001650:	movs    	r2, #0
0x001652:	str     	r2, [sp, #8]
0x001654:	str     	r1, [sp]
0x001656:	str     	r1, [sp, #4]
0x001658:	movs    	r1, #0x14
0x00165a:	movs    	r2, #0x7a
0x00165c:	adds    	r3, r4, #0
0x00165e:	movs    	r0, #0xf1
0x001660:	lsls    	r0, r0, #9
0x001662:	bl      	#0x1158
0x001666:	add     	sp, #0xc
0x001668:	pop     	{r4, r5, pc}

; ===== candidate_00166c =====
0x00166c:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00166e:	sub     	sp, #0x14
0x001670:	movs    	r1, #0
0x001672:	adds    	r5, r2, #0
0x001674:	movs    	r2, #0
0x001676:	movs    	r6, #0xff
0x001678:	movs    	r4, #0
0x00167a:	adds    	r3, r4, #0
0x00167c:	adds    	r6, #0xf
0x00167e:	str     	r2, [sp, #8]
0x001680:	str     	r1, [sp]
0x001682:	str     	r1, [sp, #4]
0x001684:	movs    	r1, #0x17
0x001686:	adds    	r2, r6, #0
0x001688:	movs    	r0, #0xf1
0x00168a:	lsls    	r0, r0, #9
0x00168c:	bl      	#0x1158
0x001690:	movs    	r1, #0
0x001692:	movs    	r2, #0
0x001694:	str     	r2, [sp, #8]
0x001696:	str     	r1, [sp]
0x001698:	str     	r1, [sp, #4]
0x00169a:	movs    	r1, #0x14
0x00169c:	movs    	r2, #0x6f
0x00169e:	adds    	r3, r5, #0
0x0016a0:	movs    	r0, #0xf1
0x0016a2:	lsls    	r0, r0, #9
0x0016a4:	bl      	#0x1158
0x0016a8:	movs    	r1, #0
0x0016aa:	movs    	r2, #0
0x0016ac:	str     	r2, [sp, #8]
0x0016ae:	str     	r1, [sp]
0x0016b0:	str     	r1, [sp, #4]
0x0016b2:	adds    	r3, r4, #0
0x0016b4:	adds    	r2, r5, #0
0x0016b6:	movs    	r1, #0xbc
0x0016b8:	movs    	r0, #0xf1
0x0016ba:	lsls    	r0, r0, #9
0x0016bc:	bl      	#0x1158
0x0016c0:	movs    	r1, #0
0x0016c2:	movs    	r2, #0
0x0016c4:	str     	r2, [sp, #8]
0x0016c6:	str     	r1, [sp]
0x0016c8:	str     	r1, [sp, #4]
0x0016ca:	movs    	r1, #0xe1
0x0016cc:	movs    	r2, #0x1d
0x0016ce:	adds    	r3, r4, #0
0x0016d0:	movs    	r0, #0xf1
0x0016d2:	lsls    	r0, r0, #9
0x0016d4:	bl      	#0x1158
0x0016d8:	movs    	r1, #0
0x0016da:	movs    	r2, #0
0x0016dc:	str     	r2, [sp, #8]
0x0016de:	str     	r1, [sp]
0x0016e0:	str     	r1, [sp, #4]
0x0016e2:	str     	r0, [sp, #0x10]
0x0016e4:	movs    	r0, #0xf1
0x0016e6:	movs    	r1, #0xe1
0x0016e8:	movs    	r2, #0x18
0x0016ea:	adds    	r3, r4, #0
0x0016ec:	lsls    	r0, r0, #9
0x0016ee:	bl      	#0x1158
0x0016f2:	ldr     	r7, [r0, #0xc]
0x0016f4:	movs    	r1, #0
0x0016f6:	movs    	r2, #0
0x0016f8:	str     	r2, [sp, #8]
0x0016fa:	str     	r1, [sp]
0x0016fc:	str     	r1, [sp, #4]
0x0016fe:	movs    	r1, #0xe1
0x001700:	movs    	r2, #0x18
0x001702:	movs    	r0, #0xf1
0x001704:	adds    	r3, r4, #0
0x001706:	lsls    	r0, r0, #9
0x001708:	bl      	#0x1158
0x00170c:	ldr     	r3, [r0, #8]
0x00170e:	ldr     	r1, [sp, #0x10]
0x001710:	movs    	r2, #0
0x001712:	str     	r2, [sp, #8]
0x001714:	str     	r1, [sp, #4]
0x001716:	movs    	r1, #0x52
0x001718:	adds    	r2, r6, #0
0x00171a:	movs    	r0, #0xf1
0x00171c:	lsls    	r0, r0, #9
0x00171e:	str     	r7, [sp]
0x001720:	bl      	#0x1158
0x001724:	movs    	r1, #0
0x001726:	movs    	r2, #0
0x001728:	str     	r1, [sp]
0x00172a:	str     	r1, [sp, #4]
0x00172c:	movs    	r1, #0x19
0x00172e:	str     	r2, [sp, #8]
0x001730:	adds    	r3, r4, #0
0x001732:	movs    	r0, #0xf1
0x001734:	lsls    	r0, r0, #9
0x001736:	ldr     	r2, [sp, #0x14]
0x001738:	bl      	#0x1158
0x00173c:	movs    	r1, #0
0x00173e:	movs    	r2, #0
0x001740:	str     	r1, [sp]
0x001742:	str     	r1, [sp, #4]
0x001744:	movs    	r1, #0x19
0x001746:	str     	r2, [sp, #8]
0x001748:	adds    	r3, r4, #0
0x00174a:	movs    	r0, #0xf1
0x00174c:	lsls    	r0, r0, #9
0x00174e:	ldr     	r2, [sp, #0x18]
0x001750:	bl      	#0x1158
0x001754:	movs    	r1, #0
0x001756:	str     	r1, [sp]
0x001758:	str     	r1, [sp, #4]
0x00175a:	movs    	r2, #0
0x00175c:	str     	r2, [sp, #8]
0x00175e:	movs    	r1, #0x19
0x001760:	adds    	r3, r4, #0
0x001762:	movs    	r0, #0xf1
0x001764:	lsls    	r0, r0, #9
0x001766:	ldr     	r2, [r5, #0x28]
0x001768:	bl      	#0x1158
0x00176c:	movs    	r1, #0
0x00176e:	str     	r1, [sp]
0x001770:	movs    	r2, #0
0x001772:	str     	r1, [sp, #4]
0x001774:	movs    	r1, #0x19
0x001776:	str     	r2, [sp, #8]
0x001778:	adds    	r3, r4, #0
0x00177a:	movs    	r0, #0xf1
0x00177c:	lsls    	r0, r0, #9
0x00177e:	ldr     	r2, [sp, #0x20]
0x001780:	bl      	#0x1158
0x001784:	movs    	r1, #0
0x001786:	str     	r1, [sp]
0x001788:	str     	r1, [sp, #4]
0x00178a:	movs    	r2, #0
0x00178c:	str     	r2, [sp, #8]
0x00178e:	movs    	r0, #0x30
0x001790:	ldrsb   	r2, [r0, r5]
0x001792:	movs    	r0, #0xf1
0x001794:	movs    	r1, #0x19
0x001796:	adds    	r3, r4, #0
0x001798:	lsls    	r0, r0, #9
0x00179a:	bl      	#0x1158

; ===== candidate_001820 =====
0x001820:	push    	{r4, r5, r6, lr}
0x001822:	sub     	sp, #0x10
0x001824:	movs    	r1, #0
0x001826:	movs    	r2, #0
0x001828:	str     	r2, [sp, #8]
0x00182a:	str     	r1, [sp]
0x00182c:	str     	r1, [sp, #4]
0x00182e:	movs    	r5, #0xf1
0x001830:	movs    	r4, #0
0x001832:	adds    	r3, r4, #0
0x001834:	lsls    	r5, r5, #9
0x001836:	movs    	r1, #0xe1
0x001838:	movs    	r2, #0x79
0x00183a:	adds    	r0, r5, #0
0x00183c:	bl      	#0x1158
0x001840:	ldr     	r6, [pc, #0x11c]
0x001842:	cmp     	r0, #0
0x001844:	add     	r6, sb
0x001846:	bne     	#0x1864
0x001848:	movs    	r1, #0
0x00184a:	str     	r1, [sp]
0x00184c:	str     	r1, [sp, #4]
0x00184e:	movs    	r1, #0xff
0x001850:	movs    	r2, #0
0x001852:	adds    	r1, #0x2d
0x001854:	adds    	r3, r4, #0
0x001856:	adds    	r0, r5, #0
0x001858:	str     	r2, [sp, #8]
0x00185a:	bl      	#0x1158
0x00185e:	strb    	r4, [r6]
0x001860:	add     	sp, #0x10
0x001862:	pop     	{r4, r5, r6, pc}

; ===== candidate_0019e0 =====
0x0019e0:	push    	{r1, r2, r3, r6, r7}
0x0019e2:	add     	r2, sp, #0x358
0x0019e4:	movs    	r0, r0
0x0019e6:	movs    	r0, r0
0x0019e8:	ldc2l   	p10, c13, [r5, #0x350]
0x0019ec:	ldm     	r0, {r0, r2, r4, r5, r7}
0x0019ee:	ldc2    	p3, c13, [r4, #0x2d8]!
0x0019f2:	adr     	r4, #0x2cc
0x0019f4:	stm     	r6!, {r1, r4, r6, r7}
0x0019f6:	add     	r7, sp, #0x2d8
0x0019f8:	movs    	r0, r0
0x0019fa:	movs    	r0, r0
0x0019fc:	stm     	r7!, {r1, r3, r6, r7}
0x0019fe:	b.w     	#0x5b9992
0x001a02:	add     	r0, sp, #0x2d8
0x001a04:	rsb     	sl, r0, pc, ror #10
0x001a08:	ldm     	r6, {r3, r6, r7}
0x001a0a:	rsb.w   	r0, lr, #0x3f
0x001a0e:	movs    	r0, r0
0x001a10:	pop     	{r0, r1, r2, r4, r6, r7}
