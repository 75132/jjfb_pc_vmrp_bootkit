; fallback candidate disassembly from Thumb prologues; true code is ARM entry + Thumb functions.

; ARM entry
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0x37a8
0x000018:	pop     	{r4, pc}
0x00001c:	andeq   	r4, r0, r8, ror r7
0x000020:	cmp     	r0, #0
0x000024:	bxne    	lr
0x000028:	b       	#0x108
0x00002c:	andeq   	r4, r0, r8, ror r7
0x000030:	ands    	r2, r0, #128, #8
0x000034:	rsbmi   	r0, r0, #0
0x000038:	eors    	r3, r2, r1, asr #32
0x00003c:	rsbhs   	r1, r1, #0
0x000040:	rsbs    	ip, r0, r1, lsr #3
0x000044:	blo     	#0xcc
0x000048:	rsbs    	ip, r0, r1, lsr #8
0x00004c:	blo     	#0x90
0x000050:	lsl     	r0, r0, #8
0x000054:	orr     	r2, r2, #0xff000000
0x000058:	rsbs    	ip, r0, r1, lsr #4
0x00005c:	blo     	#0xc0
0x000060:	rsbs    	ip, r0, r1, lsr #8
0x000064:	blo     	#0x90
0x000068:	lsl     	r0, r0, #8
0x00006c:	orr     	r2, r2, #0xff0000
0x000070:	rsbs    	ip, r0, r1, lsr #8
0x000074:	lslhs   	r0, r0, #8
0x000078:	orrhs   	r2, r2, #0xff00
0x00007c:	rsbs    	ip, r0, r1, lsr #4
0x000080:	blo     	#0xc0
0x000084:	rsbs    	ip, r0, #0
0x000088:	bhs     	#0x108
0x00008c:	lsrhs   	r0, r0, #8
0x000090:	rsbs    	ip, r0, r1, lsr #7
0x000094:	subhs   	r1, r1, r0, lsl #7
0x000098:	adc     	r2, r2, r2
0x00009c:	rsbs    	ip, r0, r1, lsr #6
0x0000a0:	subhs   	r1, r1, r0, lsl #6
0x0000a4:	adc     	r2, r2, r2
0x0000a8:	rsbs    	ip, r0, r1, lsr #5
0x0000ac:	subhs   	r1, r1, r0, lsl #5
0x0000b0:	adc     	r2, r2, r2
0x0000b4:	rsbs    	ip, r0, r1, lsr #4
0x0000b8:	subhs   	r1, r1, r0, lsl #4
0x0000bc:	adc     	r2, r2, r2
0x0000c0:	rsbs    	ip, r0, r1, lsr #3
0x0000c4:	subhs   	r1, r1, r0, lsl #3
0x0000c8:	adc     	r2, r2, r2
0x0000cc:	rsbs    	ip, r0, r1, lsr #2
0x0000d0:	subhs   	r1, r1, r0, lsl #2
0x0000d4:	adc     	r2, r2, r2
0x0000d8:	rsbs    	ip, r0, r1, lsr #1
0x0000dc:	subhs   	r1, r1, r0, lsl #1
0x0000e0:	adc     	r2, r2, r2
0x0000e4:	rsbs    	ip, r0, r1
0x0000e8:	subhs   	r1, r1, r0
0x0000ec:	adcs    	r2, r2, r2
0x0000f0:	bhs     	#0x8c
0x0000f4:	eors    	r0, r2, r3, asr #31
0x0000f8:	add     	r0, r0, r3, lsr #31
0x0000fc:	rsbhs   	r1, r1, #0
0x000100:	bx      	lr
0x000104:	andeq   	r4, r0, r8, ror r7
0x000108:	mov     	r0, #2
0x00010c:	mov     	r1, #2
0x000110:	b       	#0x128
0x000114:	strmi   	r4, [r8, -r0, lsl #14]

; ===== candidate_000008 =====
0x000008:	ands    	r0, r2
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	lsrs    	r3, r4, #0x17

; ===== candidate_00000a =====
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	lsrs    	r3, r4, #0x17

; ===== candidate_00012a =====
0x00012a:	stmdb   	sp!, {r2}

; ===== candidate_000144 =====
0x000144:	push    	{r4, r5, r6, lr}
0x000146:	ldr     	r6, [pc, #0x38]
0x000148:	adds    	r5, r1, #0
0x00014a:	adds    	r1, r0, #0
0x00014c:	adds    	r4, r0, #0
0x00014e:	add     	r6, pc
0x000150:	adds    	r0, r6, #0
0x000152:	bl      	#0x156
0x000156:	adds    	r2, r0, #0
0x000158:	cmp     	r0, r6
0x00015a:	bne     	#0x16a
0x00015c:	adds    	r1, r5, #0
0x00015e:	adds    	r0, r4, #0
0x000160:	bl      	#0x1a4
0x000164:	pop     	{r4, r5, r6}
0x000166:	pop     	{r3}
0x000168:	bx      	r3
0x00016a:	ldr     	r0, [pc, #0x18]
0x00016c:	add     	r0, pc
0x00016e:	cmp     	r2, r0
0x000170:	beq     	#0x17a
0x000172:	adds    	r1, r5, #0
0x000174:	adds    	r0, r4, #0
0x000176:	bl      	#0x118
0x00017a:	movs    	r0, #0
0x00017c:	b       	#0x164
0x00017e:	movs    	r0, r0
0x000180:	mrc2    	p15, #5, apsr_nzcv, c5, c7, #7
0x000184:	mrc2    	p15, #4, apsr_nzcv, c5, c7, #7
0x000188:	bx      	pc

; ===== candidate_0001a4 =====
0x0001a4:	push    	{r3, r4, r5, lr}
0x0001a6:	subs    	r2, r0, #1
0x0001a8:	cmp     	r2, #0xd
0x0001aa:	adr     	r4, #0x90
0x0001ac:	bhs     	#0x1fc
0x0001ae:	movs    	r2, #0x17
0x0001b0:	ldr     	r3, [pc, #0x8c]
0x0001b2:	muls    	r2, r0, r2
0x0001b4:	add     	r3, pc
0x0001b6:	adds    	r5, r2, r3
0x0001b8:	subs    	r5, #0x17
0x0001ba:	cmp     	r0, #2
0x0001bc:	bne     	#0x1e8
0x0001be:	lsls    	r0, r1, #5
0x0001c0:	bpl     	#0x1c6
0x0001c2:	adr     	r4, #0x80
0x0001c4:	b       	#0x1fe
0x0001c6:	ldr     	r0, [pc, #0x90]
0x0001c8:	ands    	r0, r1
0x0001ca:	beq     	#0x1d0
0x0001cc:	adr     	r4, #0x8c
0x0001ce:	b       	#0x1fe
0x0001d0:	lsls    	r0, r1, #3
0x0001d2:	bpl     	#0x1d8
0x0001d4:	adr     	r4, #0x94
0x0001d6:	b       	#0x1fe
0x0001d8:	lsls    	r0, r1, #2
0x0001da:	bpl     	#0x1e0
0x0001dc:	adr     	r4, #0x98
0x0001de:	b       	#0x1fe
0x0001e0:	lsls    	r0, r1, #1
0x0001e2:	bpl     	#0x1fe
0x0001e4:	adr     	r4, #0x9c
0x0001e6:	b       	#0x1fe
0x0001e8:	cmp     	r0, #8
0x0001ea:	bne     	#0x1f0
0x0001ec:	adds    	r4, r1, #0
0x0001ee:	b       	#0x1fe
0x0001f0:	cmp     	r0, #9
0x0001f2:	bne     	#0x1fe
0x0001f4:	cmp     	r1, #1
0x0001f6:	bne     	#0x1fe
0x0001f8:	adr     	r5, #0x98
0x0001fa:	b       	#0x1fe
0x0001fc:	adr     	r5, #0xac
0x0001fe:	movs    	r0, #0xa
0x000200:	bl      	#0x2c4
0x000204:	ldrb    	r0, [r5]
0x000206:	cmp     	r0, #0
0x000208:	beq     	#0x218
0x00020a:	ldrb    	r0, [r5]
0x00020c:	adds    	r5, #1
0x00020e:	bl      	#0x2c4
0x000212:	ldrb    	r0, [r5]
0x000214:	cmp     	r0, #0
0x000216:	bne     	#0x20a
0x000218:	ldrb    	r0, [r4]
0x00021a:	cmp     	r0, #0
0x00021c:	beq     	#0x22c
0x00021e:	ldrb    	r0, [r4]
0x000220:	adds    	r4, #1
0x000222:	bl      	#0x2c4
0x000226:	ldrb    	r0, [r4]
0x000228:	cmp     	r0, #0
0x00022a:	bne     	#0x21e
0x00022c:	movs    	r0, #0xa
0x00022e:	bl      	#0x2c4
0x000232:	pop     	{r3, r4, r5}
0x000234:	pop     	{r3}
0x000236:	movs    	r0, #1
0x000238:	bx      	r3
0x00023a:	movs    	r0, r0
0x00023c:	movs    	r0, r0
0x00023e:	movs    	r0, r0
0x000240:	mov     	r0, r6
0x000242:	movs    	r0, r0
0x000244:	ldr     	r1, [r1, #0x64]
0x000246:	str     	r6, [r6, #0x14]
0x000248:	ldr     	r4, [r5, #0x14]
0x00024a:	movs    	r0, #0x64
0x00024c:	strb    	r7, [r1, #1]
0x00024e:	strb    	r5, [r4, #9]
0x000250:	strb    	r1, [r4, #0x11]
0x000252:	ldr     	r1, [r5, #0x74]
0x000254:	lsls    	r6, r5, #1
0x000256:	movs    	r0, r0
0x000258:	movs    	r2, r0
0x00025a:	lsrs    	r0, r0, #0x20
0x00025c:	ldr     	r4, [r0, #0x14]
0x00025e:	ldr     	r6, [r6, #0x14]
0x000260:	str     	r4, [r4, #0x54]
0x000262:	tst     	r0, r4
0x000264:	movs    	r0, #0x79
0x000266:	str     	r2, [r3, #0x54]
0x000268:	ldr     	r2, [r6, #0x74]
0x00026a:	movs    	r0, r0
0x00026c:	strb    	r7, [r1, #0x19]
0x00026e:	strb    	r5, [r4, #9]
0x000270:	ldr     	r6, [r4, #0x44]
0x000272:	strb    	r7, [r5, #0x1d]
0x000274:	movs    	r0, r0
0x000276:	movs    	r0, r0
0x000278:	ldr     	r5, [r2, #0x64]
0x00027a:	str     	r4, [r4, #0x54]
0x00027c:	str     	r2, [r6, #0x64]
0x00027e:	ldr     	r4, [r5, #0x74]
0x000280:	lsls    	r7, r6, #1
0x000282:	movs    	r0, r0
0x000284:	ldr     	r1, [r1, #0x64]
0x000286:	ldrb    	r5, [r4, #1]
0x000288:	str     	r1, [r4, #0x34]
0x00028a:	movs    	r0, #0x74
0x00028c:	str     	r2, [r2, #0x54]
0x00028e:	strb    	r3, [r6, #0x15]
0x000290:	strb    	r4, [r5, #0x11]
0x000292:	movs    	r0, r0
0x000294:	movs    	r0, #0x3a
0x000296:	str     	r0, [r1, #0x54]
0x000298:	strb    	r1, [r4, #1]
0x00029a:	ldr     	r0, [r4, #0x50]
0x00029c:	ldr     	r5, [r4, #0x54]
0x00029e:	strb    	r7, [r5, #9]
0x0002a0:	movs    	r0, #0x79
0x0002a2:	ldr     	r3, [r4, #0x74]
0x0002a4:	strb    	r2, [r6, #9]
0x0002a6:	strb    	r5, [r6, #1]
0x0002a8:	str     	r4, [r6, #0x54]
0x0002aa:	lsls    	r4, r4, #1
0x0002ac:	ldr     	r5, [r2, #0x64]
0x0002ae:	ldr     	r3, [r5, #0x64]
0x0002b0:	strb    	r7, [r5, #0x1d]
0x0002b2:	movs    	r0, #0x6e
0x0002b4:	ldr     	r3, [r6, #0x14]
0x0002b6:	ldr     	r7, [r4, #0x64]
0x0002b8:	ldr     	r1, [r4, #0x44]
0x0002ba:	movs    	r0, r0
0x0002bc:	bx      	pc

; ===== candidate_0002c4 =====
0x0002c4:	push    	{r3, lr}
0x0002c6:	add     	r3, sp, #0
0x0002c8:	strb    	r0, [r3]
0x0002ca:	movs    	r0, #3
0x0002cc:	mov     	r1, sp
0x0002ce:	svc     	#0xab
0x0002d0:	add     	sp, #4
0x0002d2:	pop     	{r3}
0x0002d4:	bx      	r3
0x0002d6:	movs    	r0, r0
0x0002d8:	movs    	r0, r1
0x0002da:	b       	#0xfffffe1c
0x0002dc:	asrs    	r0, r1, #0x20
0x0002de:	b       	#0xfffffe20
0x0002e0:	movs    	r1, r0
0x0002e2:	b       	#0x3e6
0x0002e4:	vrhadd.u16	d14, d14, d31
0x0002e8:	movs    	r4, r0
0x0002ea:	movs    	r0, r0
0x0002ec:	lsls    	r4, r2, #7
0x0002ee:	movs    	r0, r0
0x0002f0:	str     	r0, [sp]
0x0002f2:	b       	#0x636
0x0002f4:	vrhadd.u16	d14, d14, d31
0x0002f8:	adds    	r0, #0x14
0x0002fa:	b       	#0xfffffe3c
0x0002fc:	cmp     	r7, #0xc0
0x0002fe:	b       	#0x642
0x000300:	stm     	r0!, {r0, r1, r4, r7}
0x000302:	b       	#0x488
0x000304:	adds    	r0, #0x13
0x000306:	b       	#0xaca
0x000308:	asrs    	r1, r0, #7
0x00030a:	b       	#0x3d2
0x00030c:	lsls    	r3, r2, #6
0x00030e:	b       	#0x352
0x000310:	vrhadd.u16	d14, d14, d31
0x000314:	str     	r7, [r4, #0x64]
0x000316:	str     	r6, [r4, #0x64]
0x000318:	adds    	r0, #0x14
0x00031a:	b       	#0xfffffe5c
0x00031c:	cmp     	r7, #0xc0
0x00031e:	b       	#0x662
0x000320:	stm     	r0!, {r0, r1, r4, r7}
0x000322:	b       	#0x4a8
0x000324:	adds    	r0, #2
0x000326:	b       	#0xaea
0x000328:	asrs    	r1, r0, #0x20
0x00032a:	b       	#0x3f2
0x00032c:	lsls    	r3, r2, #6
0x00032e:	b       	#0x372
0x000330:	vrhadd.u16	d14, d14, d31
0x000334:	strb    	r6, [r2, r5]
0x000336:	strb    	r5, [r2, r5]
0x000338:	push    	{r4, r5, lr}
0x00033a:	ldr     	r4, [pc, #0xb4]
0x00033c:	movs    	r2, #0x1c
0x00033e:	add     	r4, pc
0x000340:	ldr     	r0, [r4, #0x38]
0x000342:	movs    	r1, #0
0x000344:	ldr     	r3, [r0, #0x38]
0x000346:	ldr     	r0, [pc, #0xac]
0x000348:	sub     	sp, #0xc
0x00034a:	add     	r0, sb
0x00034c:	blx     	r3
0x00034e:	movs    	r2, #0
0x000350:	movs    	r0, #0
0x000352:	str     	r0, [sp]
0x000354:	ldr     	r1, [pc, #0x9c]
0x000356:	movs    	r3, #0
0x000358:	add     	r1, sb
0x00035a:	str     	r1, [sp, #4]
0x00035c:	movs    	r1, #0x64
0x00035e:	movs    	r0, #1
0x000360:	str     	r2, [sp, #8]
0x000362:	bl      	#0x3838
0x000366:	ldr     	r1, [pc, #0x8c]
0x000368:	movs    	r0, #0
0x00036a:	add     	r1, sb
0x00036c:	subs    	r1, #0x7c
0x00036e:	str     	r0, [r1, #8]
0x000370:	ldr     	r5, [pc, #0x80]
0x000372:	str     	r0, [r1, #0x10]
0x000374:	str     	r0, [r1, #0xc]
0x000376:	add     	r5, sb
0x000378:	subs    	r5, #0xfc
0x00037a:	movs    	r0, #1
0x00037c:	str     	r0, [r5, #0x18]
0x00037e:	ldr     	r0, [r4, #0x38]
0x000380:	ldr     	r2, [pc, #0x74]
0x000382:	ldr     	r1, [r0, #0x68]
0x000384:	add     	r2, sb
0x000386:	str     	r1, [r5, #0x2c]
0x000388:	ldr     	r1, [r0, #0xc]
0x00038a:	ldr     	r4, [pc, #0x70]
0x00038c:	str     	r1, [r5, #0x30]
0x00038e:	ldr     	r1, [r0, #0x10]
0x000390:	str     	r1, [r5, #0x34]
0x000392:	ldr     	r1, [r0, #0x14]
0x000394:	str     	r1, [r5, #0x38]
0x000396:	ldr     	r1, [r0, #0x18]
0x000398:	str     	r1, [r5, #0x3c]
0x00039a:	ldr     	r1, [r0, #0x1c]
0x00039c:	str     	r1, [r5, #0x40]
0x00039e:	ldr     	r1, [r0, #0x20]
0x0003a0:	str     	r1, [r5, #0x44]
0x0003a2:	ldr     	r1, [r0, #0x24]
0x0003a4:	str     	r1, [r5, #0x48]
0x0003a6:	ldr     	r1, [r0, #0x28]
0x0003a8:	str     	r1, [r5, #0x4c]
0x0003aa:	ldr     	r1, [r0, #0x2c]
0x0003ac:	str     	r1, [r5, #0x50]
0x0003ae:	ldr     	r1, [r0, #0x30]
0x0003b0:	str     	r1, [r5, #0x54]
0x0003b2:	ldr     	r1, [r0, #0x34]
0x0003b4:	str     	r1, [r5, #0x58]
0x0003b6:	ldr     	r1, [r0, #0x38]
0x0003b8:	str     	r1, [r5, #0x5c]
0x0003ba:	ldr     	r1, [r0, #0x3c]
0x0003bc:	str     	r1, [r5, #0x60]
0x0003be:	ldr     	r1, [r0, #0x40]
0x0003c0:	str     	r1, [r5, #0x64]
0x0003c2:	ldr     	r1, [r0, #0x44]
0x0003c4:	str     	r1, [r5, #0x68]
0x0003c6:	ldr     	r1, [r0, #0x48]
0x0003c8:	str     	r1, [r5, #0x6c]
0x0003ca:	ldr     	r1, [r0, #0x4c]
0x0003cc:	str     	r1, [r5, #0x70]
0x0003ce:	movs    	r1, #0
0x0003d0:	str     	r1, [r2]
0x0003d2:	movs    	r1, #1
0x0003d4:	lsls    	r1, r1, #9
0x0003d6:	adds    	r0, r0, r1
0x0003d8:	ldr     	r3, [r0, #8]
0x0003da:	movs    	r1, #7
0x0003dc:	adds    	r2, r4, #0
0x0003de:	movs    	r0, #0
0x0003e0:	blx     	r3
0x0003e2:	cmp     	r0, r4
0x0003e4:	bne     	#0x3ea
0x0003e6:	subs    	r0, #2

; ===== candidate_000338 =====
0x000338:	push    	{r4, r5, lr}
0x00033a:	ldr     	r4, [pc, #0xb4]
0x00033c:	movs    	r2, #0x1c
0x00033e:	add     	r4, pc
0x000340:	ldr     	r0, [r4, #0x38]
0x000342:	movs    	r1, #0
0x000344:	ldr     	r3, [r0, #0x38]
0x000346:	ldr     	r0, [pc, #0xac]
0x000348:	sub     	sp, #0xc
0x00034a:	add     	r0, sb
0x00034c:	blx     	r3
0x00034e:	movs    	r2, #0
0x000350:	movs    	r0, #0
0x000352:	str     	r0, [sp]
0x000354:	ldr     	r1, [pc, #0x9c]
0x000356:	movs    	r3, #0
0x000358:	add     	r1, sb
0x00035a:	str     	r1, [sp, #4]
0x00035c:	movs    	r1, #0x64
0x00035e:	movs    	r0, #1
0x000360:	str     	r2, [sp, #8]
0x000362:	bl      	#0x3838
0x000366:	ldr     	r1, [pc, #0x8c]
0x000368:	movs    	r0, #0
0x00036a:	add     	r1, sb
0x00036c:	subs    	r1, #0x7c
0x00036e:	str     	r0, [r1, #8]
0x000370:	ldr     	r5, [pc, #0x80]
0x000372:	str     	r0, [r1, #0x10]
0x000374:	str     	r0, [r1, #0xc]
0x000376:	add     	r5, sb
0x000378:	subs    	r5, #0xfc
0x00037a:	movs    	r0, #1
0x00037c:	str     	r0, [r5, #0x18]
0x00037e:	ldr     	r0, [r4, #0x38]
0x000380:	ldr     	r2, [pc, #0x74]
0x000382:	ldr     	r1, [r0, #0x68]
0x000384:	add     	r2, sb
0x000386:	str     	r1, [r5, #0x2c]
0x000388:	ldr     	r1, [r0, #0xc]
0x00038a:	ldr     	r4, [pc, #0x70]
0x00038c:	str     	r1, [r5, #0x30]
0x00038e:	ldr     	r1, [r0, #0x10]
0x000390:	str     	r1, [r5, #0x34]
0x000392:	ldr     	r1, [r0, #0x14]
0x000394:	str     	r1, [r5, #0x38]
0x000396:	ldr     	r1, [r0, #0x18]
0x000398:	str     	r1, [r5, #0x3c]
0x00039a:	ldr     	r1, [r0, #0x1c]
0x00039c:	str     	r1, [r5, #0x40]
0x00039e:	ldr     	r1, [r0, #0x20]
0x0003a0:	str     	r1, [r5, #0x44]
0x0003a2:	ldr     	r1, [r0, #0x24]
0x0003a4:	str     	r1, [r5, #0x48]
0x0003a6:	ldr     	r1, [r0, #0x28]
0x0003a8:	str     	r1, [r5, #0x4c]
0x0003aa:	ldr     	r1, [r0, #0x2c]
0x0003ac:	str     	r1, [r5, #0x50]
0x0003ae:	ldr     	r1, [r0, #0x30]
0x0003b0:	str     	r1, [r5, #0x54]
0x0003b2:	ldr     	r1, [r0, #0x34]
0x0003b4:	str     	r1, [r5, #0x58]
0x0003b6:	ldr     	r1, [r0, #0x38]
0x0003b8:	str     	r1, [r5, #0x5c]
0x0003ba:	ldr     	r1, [r0, #0x3c]
0x0003bc:	str     	r1, [r5, #0x60]
0x0003be:	ldr     	r1, [r0, #0x40]
0x0003c0:	str     	r1, [r5, #0x64]
0x0003c2:	ldr     	r1, [r0, #0x44]
0x0003c4:	str     	r1, [r5, #0x68]
0x0003c6:	ldr     	r1, [r0, #0x48]
0x0003c8:	str     	r1, [r5, #0x6c]
0x0003ca:	ldr     	r1, [r0, #0x4c]
0x0003cc:	str     	r1, [r5, #0x70]
0x0003ce:	movs    	r1, #0
0x0003d0:	str     	r1, [r2]
0x0003d2:	movs    	r1, #1
0x0003d4:	lsls    	r1, r1, #9
0x0003d6:	adds    	r0, r0, r1
0x0003d8:	ldr     	r3, [r0, #8]
0x0003da:	movs    	r1, #7
0x0003dc:	adds    	r2, r4, #0
0x0003de:	movs    	r0, #0
0x0003e0:	blx     	r3
0x0003e2:	cmp     	r0, r4
0x0003e4:	bne     	#0x3ea
0x0003e6:	subs    	r0, #2
0x0003e8:	str     	r0, [r5, #0x28]
0x0003ea:	add     	sp, #0xc
0x0003ec:	pop     	{r4, r5, pc}

; ===== candidate_000400 =====
0x000400:	push    	{r4, r5, r6, r7, lr}
0x000402:	sub     	sp, #0x14
0x000404:	movs    	r6, #0
0x000406:	movs    	r2, #0
0x000408:	movs    	r1, #0
0x00040a:	str     	r2, [sp, #8]
0x00040c:	adds    	r3, r6, #0
0x00040e:	adds    	r5, r0, #0
0x000410:	adds    	r2, r0, #0
0x000412:	str     	r1, [sp]
0x000414:	str     	r1, [sp, #4]
0x000416:	movs    	r1, #0x44
0x000418:	movs    	r0, #0xf1
0x00041a:	movs    	r4, #0
0x00041c:	lsls    	r0, r0, #9
0x00041e:	bl      	#0x3838
0x000422:	movs    	r1, #0
0x000424:	str     	r1, [sp]
0x000426:	str     	r1, [sp, #4]
0x000428:	movs    	r2, #0
0x00042a:	str     	r2, [sp, #8]
0x00042c:	movs    	r1, #0x45
0x00042e:	adds    	r3, r6, #0
0x000430:	movs    	r0, #0xf1
0x000432:	lsls    	r0, r0, #9
0x000434:	ldr     	r2, [r5, #8]
0x000436:	bl      	#0x3838
0x00043a:	movs    	r1, #0
0x00043c:	str     	r1, [sp]
0x00043e:	str     	r1, [sp, #4]
0x000440:	str     	r0, [sp, #0x10]
0x000442:	movs    	r2, #0
0x000444:	str     	r2, [sp, #8]
0x000446:	movs    	r0, #0xf1
0x000448:	movs    	r1, #0x45
0x00044a:	adds    	r3, r6, #0
0x00044c:	lsls    	r0, r0, #9
0x00044e:	ldr     	r2, [r5, #8]
0x000450:	bl      	#0x3838
0x000454:	movs    	r1, #0
0x000456:	str     	r1, [sp]
0x000458:	str     	r1, [sp, #4]
0x00045a:	str     	r0, [sp, #0xc]
0x00045c:	movs    	r2, #0
0x00045e:	str     	r2, [sp, #8]
0x000460:	movs    	r0, #0xf1
0x000462:	movs    	r1, #0x45
0x000464:	adds    	r3, r6, #0
0x000466:	lsls    	r0, r0, #9
0x000468:	ldr     	r2, [r5, #8]
0x00046a:	bl      	#0x3838
0x00046e:	movs    	r2, #0
0x000470:	movs    	r1, #0
0x000472:	str     	r2, [sp, #8]
0x000474:	adds    	r6, r0, #0
0x000476:	adds    	r2, r0, #0
0x000478:	str     	r1, [sp]
0x00047a:	str     	r1, [sp, #4]
0x00047c:	movs    	r1, #0xa
0x00047e:	movs    	r0, #0xf1
0x000480:	movs    	r3, #4
0x000482:	lsls    	r0, r0, #9
0x000484:	bl      	#0x3838
0x000488:	adds    	r7, r0, #0
0x00048a:	cmp     	r6, #0
0x00048c:	ble     	#0x49e
0x00048e:	adds    	r0, r5, #0
0x000490:	bl      	#0x3cb0
0x000494:	lsls    	r1, r4, #2
0x000496:	adds    	r4, #1
0x000498:	cmp     	r4, r6
0x00049a:	str     	r0, [r7, r1]
0x00049c:	blt     	#0x48e
0x00049e:	movs    	r1, #0
0x0004a0:	str     	r1, [sp]
0x0004a2:	str     	r1, [sp, #4]
0x0004a4:	movs    	r2, #0
0x0004a6:	movs    	r1, #0x2c
0x0004a8:	movs    	r3, #0
0x0004aa:	movs    	r0, #0xf1
0x0004ac:	lsls    	r0, r0, #9
0x0004ae:	str     	r2, [sp, #8]
0x0004b0:	bl      	#0x3838
0x0004b4:	adds    	r0, r7, #0
0x0004b6:	bl      	#0x2e0c
0x0004ba:	ldr     	r1, [pc, #0x10]
0x0004bc:	ldr     	r0, [sp, #0x10]
0x0004be:	add     	r1, sb
0x0004c0:	str     	r0, [r1, #0x68]
0x0004c2:	ldr     	r0, [sp, #0xc]
0x0004c4:	str     	r0, [r1, #0x6c]
0x0004c6:	add     	sp, #0x14
0x0004c8:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0004d0 =====
0x0004d0:	push    	{r4, r5, r6, r7, lr}
0x0004d2:	ldr     	r1, [pc, #0xf0]
0x0004d4:	sub     	sp, #0xc
0x0004d6:	adds    	r4, r0, #0
0x0004d8:	add     	r1, pc
0x0004da:	ldr     	r5, [pc, #0xec]
0x0004dc:	add     	r5, sb
0x0004de:	ldr     	r2, [r5]
0x0004e0:	blx     	r2
0x0004e2:	cmp     	r0, #0
0x0004e4:	bne     	#0x4ee
0x0004e6:	bl      	#0x5d8
0x0004ea:	add     	sp, #0xc
0x0004ec:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0005d8 =====
0x0005d8:	push    	{r4, r5, r6, lr}
0x0005da:	ldr     	r5, [pc, #0x80]
0x0005dc:	movs    	r6, #0xf1
0x0005de:	add     	r5, sb
0x0005e0:	ldr     	r0, [r5, #0xc]
0x0005e2:	lsls    	r6, r6, #9
0x0005e4:	movs    	r4, #0
0x0005e6:	cmp     	r0, #0
0x0005e8:	sub     	sp, #0x10
0x0005ea:	bne     	#0x608
0x0005ec:	movs    	r2, #0
0x0005ee:	movs    	r1, #0
0x0005f0:	str     	r2, [sp, #8]
0x0005f2:	ldr     	r2, [pc, #0x6c]
0x0005f4:	str     	r1, [sp]
0x0005f6:	str     	r1, [sp, #4]
0x0005f8:	adds    	r3, r4, #0
0x0005fa:	add     	r2, pc
0x0005fc:	movs    	r1, #0x33
0x0005fe:	adds    	r0, r6, #0
0x000600:	bl      	#0x3838
0x000604:	add     	sp, #0x10
0x000606:	pop     	{r4, r5, r6, pc}

; ===== candidate_000664 =====
0x000664:	push    	{r4, r5, lr}
0x000666:	sub     	sp, #0xc
0x000668:	movs    	r5, #0
0x00066a:	movs    	r2, #0
0x00066c:	movs    	r1, #0
0x00066e:	str     	r2, [sp, #8]
0x000670:	adds    	r3, r5, #0
0x000672:	adds    	r4, r0, #0
0x000674:	adds    	r2, r0, #0
0x000676:	str     	r1, [sp]
0x000678:	str     	r1, [sp, #4]
0x00067a:	movs    	r1, #0x44
0x00067c:	movs    	r0, #0xf1
0x00067e:	lsls    	r0, r0, #9
0x000680:	bl      	#0x3838
0x000684:	movs    	r1, #0
0x000686:	str     	r1, [sp]
0x000688:	str     	r1, [sp, #4]
0x00068a:	movs    	r2, #0
0x00068c:	str     	r2, [sp, #8]
0x00068e:	movs    	r1, #0x46
0x000690:	adds    	r3, r5, #0
0x000692:	movs    	r0, #0xf1
0x000694:	lsls    	r0, r0, #9
0x000696:	ldr     	r2, [r4, #8]
0x000698:	bl      	#0x3838
0x00069c:	lsls    	r5, r0, #0x18
0x00069e:	movs    	r1, #0
0x0006a0:	ldr     	r0, [pc, #0x24]
0x0006a2:	movs    	r2, #0
0x0006a4:	str     	r2, [sp, #8]
0x0006a6:	str     	r1, [sp]
0x0006a8:	str     	r1, [sp, #4]
0x0006aa:	add     	r0, sb
0x0006ac:	ldr     	r3, [r0, #0x28]
0x0006ae:	movs    	r0, #0xf1
0x0006b0:	movs    	r1, #0x91
0x0006b2:	adds    	r2, r4, #0
0x0006b4:	asrs    	r5, r5, #0x18
0x0006b6:	lsls    	r0, r0, #9
0x0006b8:	bl      	#0x3838
0x0006bc:	adds    	r0, r5, #0
0x0006be:	bl      	#0x6cc
0x0006c2:	add     	sp, #0xc
0x0006c4:	pop     	{r4, r5, pc}

; ===== candidate_0006cc =====
0x0006cc:	push    	{r0, r4, r5, r6, r7, lr}
0x0006ce:	sub     	sp, #0x10
0x0006d0:	movs    	r1, #0
0x0006d2:	movs    	r2, #0
0x0006d4:	str     	r2, [sp, #8]
0x0006d6:	str     	r1, [sp]
0x0006d8:	str     	r1, [sp, #4]
0x0006da:	movs    	r6, #0xf1
0x0006dc:	movs    	r4, #0
0x0006de:	adds    	r3, r4, #0
0x0006e0:	lsls    	r6, r6, #9
0x0006e2:	movs    	r1, #0x14
0x0006e4:	movs    	r2, #0x20
0x0006e6:	adds    	r0, r6, #0
0x0006e8:	bl      	#0x3838
0x0006ec:	movs    	r1, #0
0x0006ee:	ldr     	r5, [pc, #0xdc]
0x0006f0:	movs    	r2, #0
0x0006f2:	str     	r2, [sp, #8]
0x0006f4:	str     	r1, [sp]
0x0006f6:	str     	r1, [sp, #4]
0x0006f8:	add     	r5, sb
0x0006fa:	ldr     	r0, [r5, #0xc]
0x0006fc:	movs    	r1, #0x73
0x0006fe:	movs    	r3, #0
0x000700:	ldr     	r2, [r0, #4]
0x000702:	adds    	r0, r6, #0
0x000704:	bl      	#0x3838
0x000708:	movs    	r1, #0
0x00070a:	movs    	r2, #0
0x00070c:	str     	r2, [sp, #8]
0x00070e:	str     	r1, [sp]
0x000710:	str     	r1, [sp, #4]
0x000712:	adds    	r7, r0, #0
0x000714:	ldr     	r0, [r5, #0xc]
0x000716:	movs    	r1, #0xda
0x000718:	movs    	r3, #0
0x00071a:	ldr     	r2, [r0, #4]
0x00071c:	adds    	r0, r6, #0
0x00071e:	bl      	#0x3838
0x000722:	cmp     	r0, #1
0x000724:	bne     	#0x72c
0x000726:	ldr     	r0, [r5, #0x28]
0x000728:	str     	r4, [r0, #0x34]
0x00072a:	b       	#0x74a
0x00072c:	movs    	r1, #0
0x00072e:	str     	r1, [sp]
0x000730:	str     	r1, [sp, #4]
0x000732:	movs    	r2, #0
0x000734:	str     	r2, [sp, #8]
0x000736:	movs    	r1, #0xe0
0x000738:	adds    	r3, r7, #0
0x00073a:	adds    	r0, r6, #0
0x00073c:	ldr     	r2, [r5, #0x28]
0x00073e:	bl      	#0x3838
0x000742:	ldr     	r1, [r5, #0x28]
0x000744:	lsls    	r0, r0, #2
0x000746:	ldr     	r1, [r1, #0x38]
0x000748:	str     	r4, [r1, r0]
0x00074a:	movs    	r1, #0
0x00074c:	movs    	r2, #0
0x00074e:	str     	r2, [sp, #8]
0x000750:	str     	r1, [sp]
0x000752:	str     	r1, [sp, #4]
0x000754:	ldr     	r0, [r5, #0xc]
0x000756:	movs    	r1, #0x73
0x000758:	adds    	r3, r4, #0
0x00075a:	ldr     	r2, [r0, #4]
0x00075c:	adds    	r0, r6, #0
0x00075e:	bl      	#0x3838
0x000762:	movs    	r2, #0
0x000764:	movs    	r1, #0
0x000766:	str     	r2, [sp, #8]
0x000768:	adds    	r3, r4, #0
0x00076a:	adds    	r2, r0, #0
0x00076c:	str     	r1, [sp]
0x00076e:	str     	r1, [sp, #4]
0x000770:	movs    	r1, #0xd9
0x000772:	movs    	r0, #0xf1
0x000774:	lsls    	r0, r0, #9
0x000776:	bl      	#0x3838
0x00077a:	ldr     	r0, [sp, #0x10]
0x00077c:	cmp     	r0, #1
0x00077e:	bne     	#0x798
0x000780:	movs    	r1, #0
0x000782:	str     	r1, [sp]
0x000784:	str     	r1, [sp, #4]
0x000786:	movs    	r2, #0
0x000788:	str     	r2, [sp, #8]
0x00078a:	movs    	r1, #0xa9
0x00078c:	movs    	r3, #1
0x00078e:	adds    	r0, r6, #0
0x000790:	ldr     	r2, [r5, #0xc]
0x000792:	bl      	#0x3838
0x000796:	b       	#0x7b0
0x000798:	movs    	r1, #0
0x00079a:	str     	r1, [sp]
0x00079c:	str     	r1, [sp, #4]
0x00079e:	movs    	r2, #0
0x0007a0:	str     	r2, [sp, #8]
0x0007a2:	movs    	r1, #0x8e
0x0007a4:	adds    	r3, r4, #0
0x0007a6:	adds    	r0, r6, #0
0x0007a8:	ldr     	r2, [r5, #0xc]
0x0007aa:	bl      	#0x3838
0x0007ae:	str     	r4, [r5, #0xc]
0x0007b0:	movs    	r2, #0
0x0007b2:	movs    	r1, #0
0x0007b4:	str     	r2, [sp, #8]
0x0007b6:	ldr     	r2, [pc, #0x18]
0x0007b8:	str     	r1, [sp]
0x0007ba:	str     	r1, [sp, #4]
0x0007bc:	adds    	r3, r4, #0
0x0007be:	add     	r2, pc
0x0007c0:	movs    	r1, #0x33
0x0007c2:	adds    	r0, r6, #0
0x0007c4:	bl      	#0x3838
0x0007c8:	add     	sp, #0x14
0x0007ca:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0007d4 =====
0x0007d4:	push    	{r4, r5, r6, r7, lr}
0x0007d6:	sub     	sp, #0xc
0x0007d8:	movs    	r7, #0
0x0007da:	movs    	r2, #0
0x0007dc:	movs    	r1, #0
0x0007de:	str     	r2, [sp, #8]
0x0007e0:	adds    	r3, r7, #0
0x0007e2:	adds    	r4, r0, #0
0x0007e4:	adds    	r2, r0, #0
0x0007e6:	str     	r1, [sp]
0x0007e8:	str     	r1, [sp, #4]
0x0007ea:	movs    	r1, #0x44
0x0007ec:	movs    	r0, #0xf1
0x0007ee:	lsls    	r0, r0, #9
0x0007f0:	bl      	#0x3838
0x0007f4:	movs    	r1, #0
0x0007f6:	str     	r1, [sp]
0x0007f8:	str     	r1, [sp, #4]
0x0007fa:	movs    	r2, #0
0x0007fc:	str     	r2, [sp, #8]
0x0007fe:	movs    	r1, #0x45
0x000800:	adds    	r3, r7, #0
0x000802:	movs    	r0, #0xf1
0x000804:	lsls    	r0, r0, #9
0x000806:	ldr     	r2, [r4, #8]
0x000808:	bl      	#0x3838
0x00080c:	ldr     	r5, [pc, #0x1ac]
0x00080e:	movs    	r1, #0
0x000810:	add     	r5, sb
0x000812:	str     	r0, [r5, #0x70]
0x000814:	str     	r1, [sp]
0x000816:	str     	r1, [sp, #4]
0x000818:	movs    	r2, #0
0x00081a:	str     	r2, [sp, #8]
0x00081c:	movs    	r1, #0x47
0x00081e:	movs    	r0, #0xf1
0x000820:	adds    	r3, r7, #0
0x000822:	lsls    	r0, r0, #9
0x000824:	ldr     	r2, [r4, #8]
0x000826:	bl      	#0x3838
0x00082a:	str     	r0, [r5, #0x48]
0x00082c:	movs    	r1, #0
0x00082e:	str     	r1, [sp]
0x000830:	str     	r1, [sp, #4]
0x000832:	movs    	r2, #0
0x000834:	str     	r2, [sp, #8]
0x000836:	movs    	r1, #0x46
0x000838:	movs    	r0, #0xf1
0x00083a:	adds    	r3, r7, #0
0x00083c:	lsls    	r0, r0, #9
0x00083e:	ldr     	r2, [r4, #8]
0x000840:	bl      	#0x3838
0x000844:	strb    	r0, [r5, #1]
0x000846:	movs    	r1, #0
0x000848:	str     	r1, [sp]
0x00084a:	str     	r1, [sp, #4]
0x00084c:	movs    	r2, #0
0x00084e:	str     	r2, [sp, #8]
0x000850:	movs    	r1, #0x47
0x000852:	movs    	r0, #0xf1
0x000854:	adds    	r3, r7, #0
0x000856:	lsls    	r0, r0, #9
0x000858:	ldr     	r2, [r4, #8]
0x00085a:	bl      	#0x3838
0x00085e:	str     	r0, [r5, #0x4c]
0x000860:	movs    	r1, #0
0x000862:	str     	r1, [sp]
0x000864:	str     	r1, [sp, #4]
0x000866:	movs    	r2, #0
0x000868:	str     	r2, [sp, #8]
0x00086a:	movs    	r1, #0x46
0x00086c:	movs    	r0, #0xf1
0x00086e:	adds    	r3, r7, #0
0x000870:	lsls    	r0, r0, #9
0x000872:	ldr     	r2, [r4, #8]
0x000874:	bl      	#0x3838
0x000878:	lsls    	r0, r0, #0x18
0x00087a:	asrs    	r0, r0, #0x18
0x00087c:	cmp     	r0, #1
0x00087e:	bne     	#0x964
0x000880:	movs    	r1, #0
0x000882:	str     	r1, [sp]
0x000884:	str     	r1, [sp, #4]
0x000886:	movs    	r2, #0
0x000888:	str     	r2, [sp, #8]
0x00088a:	movs    	r1, #0x46
0x00088c:	movs    	r5, #0
0x00088e:	adds    	r3, r7, #0
0x000890:	movs    	r0, #0xf1
0x000892:	lsls    	r0, r0, #9
0x000894:	ldr     	r2, [r4, #8]
0x000896:	bl      	#0x3838
0x00089a:	lsls    	r6, r0, #0x18
0x00089c:	movs    	r1, #0
0x00089e:	movs    	r2, #0
0x0008a0:	str     	r2, [sp, #8]
0x0008a2:	str     	r1, [sp]
0x0008a4:	str     	r1, [sp, #4]
0x0008a6:	asrs    	r6, r6, #0x18
0x0008a8:	adds    	r2, r6, #0
0x0008aa:	movs    	r1, #0xa
0x0008ac:	movs    	r0, #0xf1
0x0008ae:	movs    	r3, #1
0x0008b0:	lsls    	r0, r0, #9
0x0008b2:	bl      	#0x3838
0x0008b6:	ldr     	r1, [pc, #0x104]
0x0008b8:	cmp     	r6, #0
0x0008ba:	add     	r1, sb
0x0008bc:	str     	r0, [r1, #0x54]
0x0008be:	ble     	#0x8e6
0x0008c0:	movs    	r1, #0
0x0008c2:	str     	r1, [sp]
0x0008c4:	str     	r1, [sp, #4]
0x0008c6:	movs    	r2, #0
0x0008c8:	str     	r2, [sp, #8]
0x0008ca:	movs    	r1, #0x46
0x0008cc:	adds    	r3, r7, #0
0x0008ce:	movs    	r0, #0xf1
0x0008d0:	lsls    	r0, r0, #9
0x0008d2:	ldr     	r2, [r4, #8]
0x0008d4:	bl      	#0x3838
0x0008d8:	ldr     	r1, [pc, #0xe0]
0x0008da:	add     	r1, sb
0x0008dc:	ldr     	r1, [r1, #0x54]
0x0008de:	strb    	r0, [r1, r5]
0x0008e0:	adds    	r5, #1
0x0008e2:	cmp     	r5, r6
0x0008e4:	blt     	#0x8c0
0x0008e6:	movs    	r1, #0
0x0008e8:	str     	r1, [sp]
0x0008ea:	str     	r1, [sp, #4]
0x0008ec:	movs    	r2, #0
0x0008ee:	movs    	r5, #0xf1
0x0008f0:	lsls    	r5, r5, #9
0x0008f2:	str     	r2, [sp, #8]
0x0008f4:	movs    	r1, #0x46
0x0008f6:	adds    	r3, r7, #0
0x0008f8:	adds    	r0, r5, #0
0x0008fa:	ldr     	r2, [r4, #8]
0x0008fc:	bl      	#0x3838
0x000900:	lsls    	r0, r0, #0x18

; ===== candidate_0009c0 =====
0x0009c0:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0009c2:	sub     	sp, #0x2c
0x0009c4:	ldr     	r1, [sp, #0x38]
0x0009c6:	adds    	r6, r2, #0
0x0009c8:	adds    	r5, r1, #0
0x0009ca:	movs    	r1, #0
0x0009cc:	str     	r1, [sp]
0x0009ce:	str     	r1, [sp, #4]
0x0009d0:	movs    	r2, #0
0x0009d2:	str     	r2, [sp, #8]
0x0009d4:	movs    	r3, #0xc
0x0009d6:	ldrsh   	r2, [r0, r3]
0x0009d8:	adds    	r4, r0, #0
0x0009da:	adds    	r5, #0xa
0x0009dc:	adds    	r6, #0xa
0x0009de:	movs    	r7, #0
0x0009e0:	adds    	r3, r7, #0
0x0009e2:	movs    	r0, #0xf1
0x0009e4:	movs    	r1, #0xdd
0x0009e6:	lsls    	r0, r0, #9
0x0009e8:	bl      	#0x3838
0x0009ec:	movs    	r1, #0
0x0009ee:	str     	r1, [sp]
0x0009f0:	str     	r1, [sp, #4]
0x0009f2:	movs    	r2, #0
0x0009f4:	str     	r2, [sp, #8]
0x0009f6:	movs    	r3, #0xc
0x0009f8:	ldrsh   	r2, [r4, r3]
0x0009fa:	adds    	r3, r4, #0
0x0009fc:	movs    	r1, #0x8b
0x0009fe:	movs    	r0, #0xf1
0x000a00:	lsls    	r0, r0, #9
0x000a02:	bl      	#0x3838
0x000a06:	mov     	ip, r0
0x000a08:	adds    	r0, r6, #0
0x000a0a:	subs    	r0, #0xb
0x000a0c:	str     	r0, [sp]
0x000a0e:	mvns    	r2, r7
0x000a10:	movs    	r3, #0xc
0x000a12:	str     	r2, [sp, #8]
0x000a14:	str     	r5, [sp, #4]
0x000a16:	ldrsh   	r2, [r4, r3]
0x000a18:	movs    	r0, #0xf1
0x000a1a:	movs    	r1, #0xae
0x000a1c:	lsls    	r0, r0, #9
0x000a1e:	mov     	r3, ip
0x000a20:	bl      	#0x3838
0x000a24:	movs    	r1, #0
0x000a26:	movs    	r2, #0
0x000a28:	str     	r2, [sp, #8]
0x000a2a:	str     	r1, [sp]
0x000a2c:	str     	r1, [sp, #4]
0x000a2e:	movs    	r1, #0xe1
0x000a30:	movs    	r2, #0x97
0x000a32:	adds    	r3, r7, #0
0x000a34:	movs    	r0, #0xf1
0x000a36:	lsls    	r0, r0, #9
0x000a38:	bl      	#0x3838
0x000a3c:	movs    	r3, #0xf
0x000a3e:	ldrsb   	r1, [r4, r3]
0x000a40:	movs    	r2, #0
0x000a42:	lsls    	r1, r1, #2
0x000a44:	ldr     	r3, [r0, r1]
0x000a46:	adds    	r1, r5, #0
0x000a48:	str     	r2, [sp, #8]
0x000a4a:	ldr     	r2, [pc, #0x270]
0x000a4c:	adds    	r1, #0x14
0x000a4e:	str     	r1, [sp, #4]
0x000a50:	str     	r6, [sp]
0x000a52:	add     	r2, pc
0x000a54:	movs    	r1, #0x3c
0x000a56:	movs    	r0, #0xf1
0x000a58:	lsls    	r0, r0, #9
0x000a5a:	bl      	#0x3838
0x000a5e:	movs    	r1, #0
0x000a60:	movs    	r2, #0
0x000a62:	str     	r2, [sp, #8]
0x000a64:	str     	r1, [sp]
0x000a66:	str     	r1, [sp, #4]
0x000a68:	str     	r4, [sp, #0x14]
0x000a6a:	ldr     	r0, [r4, #0x7c]
0x000a6c:	movs    	r1, #0x6e
0x000a6e:	ldr     	r2, [r0, #0x1c]
0x000a70:	movs    	r0, #0xf1
0x000a72:	adds    	r3, r7, #0
0x000a74:	lsls    	r0, r0, #9
0x000a76:	bl      	#0x3838
0x000a7a:	str     	r0, [sp, #0x18]
0x000a7c:	movs    	r1, #0
0x000a7e:	movs    	r0, #0x32
0x000a80:	movs    	r2, #0
0x000a82:	str     	r2, [sp, #8]
0x000a84:	str     	r0, [sp, #0x1c]
0x000a86:	str     	r1, [sp]
0x000a88:	str     	r1, [sp, #4]
0x000a8a:	movs    	r1, #0xe1
0x000a8c:	movs    	r0, #0xf1
0x000a8e:	movs    	r2, #0x2e
0x000a90:	adds    	r3, r7, #0
0x000a92:	lsls    	r0, r0, #9
0x000a94:	bl      	#0x3838
0x000a98:	ldr     	r1, [sp, #0x38]
0x000a9a:	ldr     	r2, [sp, #0x50]
0x000a9c:	lsls    	r0, r0, #1
0x000a9e:	adds    	r1, r1, r2
0x000aa0:	subs    	r0, r1, r0
0x000aa2:	adds    	r0, #0xf
0x000aa4:	str     	r0, [sp, #0x20]
0x000aa6:	mvns    	r0, r7
0x000aa8:	str     	r0, [sp, #0x24]
0x000aaa:	movs    	r0, #1
0x000aac:	add     	r3, sp, #0x20
0x000aae:	strb    	r0, [r3, #8]
0x000ab0:	movs    	r1, #0
0x000ab2:	str     	r1, [sp]
0x000ab4:	str     	r1, [sp, #4]
0x000ab6:	movs    	r2, #0
0x000ab8:	movs    	r1, #0xff
0x000aba:	adds    	r3, r7, #0
0x000abc:	adds    	r1, #0x21
0x000abe:	str     	r2, [sp, #8]
0x000ac0:	movs    	r0, #0xf1
0x000ac2:	lsls    	r0, r0, #9
0x000ac4:	add     	r2, sp, #0x14
0x000ac6:	bl      	#0x3838
0x000aca:	movs    	r0, #0xcf
0x000acc:	ldrb    	r0, [r0, r4]
0x000ace:	cmp     	r0, #0x64
0x000ad0:	beq     	#0xb04
0x000ad2:	ldr     	r0, [pc, #0x1ec]
0x000ad4:	add     	r0, pc
0x000ad6:	str     	r0, [sp, #0xc]
0x000ad8:	adds    	r0, r5, #0
0x000ada:	adds    	r0, #0x28
0x000adc:	str     	r0, [sp, #0x14]
0x000ade:	movs    	r0, #0xff
0x000ae0:	str     	r0, [sp, #0x20]
0x000ae2:	movs    	r1, #0
0x000ae4:	str     	r7, [sp, #0x24]
0x000ae6:	movs    	r2, #0
0x000ae8:	str     	r1, [sp, #4]

; ===== candidate_000cc8 =====
0x000cc8:	push    	{r4, r5, r6, r7, lr}
0x000cca:	ldr     	r4, [pc, #0xc4]
0x000ccc:	sub     	sp, #0x2c
0x000cce:	add     	r4, pc
0x000cd0:	movs    	r1, #0
0x000cd2:	str     	r1, [sp]
0x000cd4:	str     	r1, [sp, #4]
0x000cd6:	movs    	r2, #0
0x000cd8:	ldr     	r7, [pc, #0xb8]
0x000cda:	str     	r2, [sp, #8]
0x000cdc:	movs    	r1, #0x11
0x000cde:	movs    	r3, #4
0x000ce0:	movs    	r0, #0xf1
0x000ce2:	add     	r7, sb
0x000ce4:	ldr     	r2, [r7, #0x38]
0x000ce6:	lsls    	r0, r0, #9
0x000ce8:	bl      	#0x3838
0x000cec:	adds    	r5, r0, #0
0x000cee:	movs    	r0, #0
0x000cf0:	add     	r2, sp, #0x24
0x000cf2:	add     	r1, sp, #0x28
0x000cf4:	movs    	r6, #0
0x000cf6:	adds    	r3, r6, #0
0x000cf8:	str     	r1, [sp, #4]
0x000cfa:	str     	r2, [sp, #8]
0x000cfc:	str     	r0, [sp]
0x000cfe:	movs    	r0, #0xf1
0x000d00:	adds    	r2, r4, #0
0x000d02:	movs    	r1, #0x2a
0x000d04:	lsls    	r0, r0, #9
0x000d06:	bl      	#0x3838
0x000d0a:	ldr     	r0, [sp, #0x24]
0x000d0c:	ldr     	r4, [sp, #0x28]
0x000d0e:	muls    	r5, r0, r5
0x000d10:	ldr     	r0, [r7, #0x38]
0x000d12:	movs    	r1, #0
0x000d14:	str     	r1, [sp]
0x000d16:	str     	r1, [sp, #4]
0x000d18:	movs    	r2, #0
0x000d1a:	adds    	r4, #0x32
0x000d1c:	adds    	r5, #0xa
0x000d1e:	str     	r0, [sp, #0xc]
0x000d20:	movs    	r0, #0xf1
0x000d22:	adds    	r3, r6, #0
0x000d24:	movs    	r1, #0x1c
0x000d26:	lsls    	r0, r0, #9
0x000d28:	str     	r2, [sp, #8]
0x000d2a:	bl      	#0x3838
0x000d2e:	subs    	r0, r0, r4
0x000d30:	movs    	r1, #0
0x000d32:	asrs    	r0, r0, #1
0x000d34:	str     	r0, [sp, #0x10]
0x000d36:	str     	r1, [sp]
0x000d38:	str     	r1, [sp, #4]
0x000d3a:	movs    	r2, #0
0x000d3c:	movs    	r1, #0x1d
0x000d3e:	movs    	r0, #0xf1
0x000d40:	adds    	r3, r6, #0
0x000d42:	lsls    	r0, r0, #9
0x000d44:	str     	r2, [sp, #8]
0x000d46:	bl      	#0x3838
0x000d4a:	subs    	r0, r0, r5
0x000d4c:	asrs    	r0, r0, #1
0x000d4e:	str     	r0, [sp, #0x14]
0x000d50:	ldr     	r0, [pc, #0x40]
0x000d52:	movs    	r1, #0
0x000d54:	add     	r0, sb
0x000d56:	adds    	r0, #0x34
0x000d58:	str     	r0, [sp, #0x20]
0x000d5a:	movs    	r2, #0
0x000d5c:	str     	r1, [sp]
0x000d5e:	str     	r1, [sp, #4]
0x000d60:	movs    	r1, #0x2b
0x000d62:	str     	r2, [sp, #8]
0x000d64:	movs    	r0, #0xf1
0x000d66:	adds    	r3, r6, #0
0x000d68:	lsls    	r0, r0, #9
0x000d6a:	add     	r2, sp, #0xc
0x000d6c:	str     	r4, [sp, #0x18]
0x000d6e:	str     	r5, [sp, #0x1c]
0x000d70:	bl      	#0x3838
0x000d74:	movs    	r1, #0
0x000d76:	movs    	r2, #0
0x000d78:	str     	r2, [sp, #8]
0x000d7a:	str     	r1, [sp]
0x000d7c:	str     	r1, [sp, #4]
0x000d7e:	movs    	r1, #0x24
0x000d80:	movs    	r2, #1
0x000d82:	movs    	r3, #1
0x000d84:	movs    	r0, #0xf1
0x000d86:	lsls    	r0, r0, #9
0x000d88:	bl      	#0x3838
0x000d8c:	add     	sp, #0x2c
0x000d8e:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000d98 =====
0x000d98:	push    	{r4, r5, r6, r7, lr}
0x000d9a:	sub     	sp, #0x64
0x000d9c:	movs    	r0, #0x64
0x000d9e:	movs    	r1, #0
0x000da0:	str     	r0, [sp, #0x5c]
0x000da2:	movs    	r0, #0x5a
0x000da4:	str     	r1, [sp]
0x000da6:	str     	r1, [sp, #4]
0x000da8:	movs    	r4, #0xf1
0x000daa:	movs    	r5, #0
0x000dac:	movs    	r2, #0
0x000dae:	adds    	r3, r5, #0
0x000db0:	lsls    	r4, r4, #9
0x000db2:	movs    	r1, #0x40
0x000db4:	str     	r0, [sp, #0x58]
0x000db6:	movs    	r7, #0
0x000db8:	movs    	r6, #0
0x000dba:	adds    	r0, r4, #0
0x000dbc:	str     	r2, [sp, #8]
0x000dbe:	bl      	#0x3838
0x000dc2:	ldr     	r1, [sp, #0x58]
0x000dc4:	movs    	r2, #0
0x000dc6:	ldr     	r0, [sp, #0x5c]
0x000dc8:	str     	r2, [sp, #8]
0x000dca:	str     	r1, [sp, #4]
0x000dcc:	movs    	r1, #0x32
0x000dce:	adds    	r2, r6, #0
0x000dd0:	adds    	r3, r7, #0
0x000dd2:	str     	r0, [sp]
0x000dd4:	adds    	r0, r4, #0
0x000dd6:	bl      	#0x3838
0x000dda:	ldr     	r7, [pc, #0x3e4]
0x000ddc:	movs    	r0, #0x32
0x000dde:	str     	r0, [sp, #0x4c]
0x000de0:	add     	r7, sb
0x000de2:	ldr     	r0, [r7, #0x50]
0x000de4:	movs    	r6, #0x50
0x000de6:	cmp     	r0, #0
0x000de8:	bne     	#0xe02
0x000dea:	movs    	r1, #0
0x000dec:	str     	r1, [sp]
0x000dee:	str     	r1, [sp, #4]
0x000df0:	movs    	r2, #0
0x000df2:	str     	r2, [sp, #8]
0x000df4:	movs    	r1, #0x37
0x000df6:	adds    	r3, r5, #0
0x000df8:	adds    	r0, r4, #0
0x000dfa:	ldr     	r2, [r7, #0x4c]
0x000dfc:	bl      	#0x3838
0x000e00:	str     	r0, [r7, #0x50]
0x000e02:	ldr     	r7, [pc, #0x3bc]
0x000e04:	movs    	r1, #0
0x000e06:	add     	r7, sb
0x000e08:	ldr     	r0, [r7, #0x50]
0x000e0a:	movs    	r2, #0
0x000e0c:	str     	r0, [sp, #0x24]
0x000e0e:	ldr     	r0, [sp, #0x4c]
0x000e10:	str     	r6, [sp, #0x2c]
0x000e12:	movs    	r6, #0
0x000e14:	str     	r0, [sp, #0x28]
0x000e16:	str     	r2, [sp, #8]
0x000e18:	str     	r1, [sp, #4]
0x000e1a:	str     	r1, [sp]
0x000e1c:	movs    	r1, #0xe1
0x000e1e:	movs    	r2, #0x27
0x000e20:	adds    	r3, r6, #0
0x000e22:	adds    	r0, r4, #0
0x000e24:	str     	r6, [sp, #0x30]
0x000e26:	bl      	#0x3838
0x000e2a:	lsrs    	r1, r0, #0x1f
0x000e2c:	adds    	r0, r1, r0
0x000e2e:	movs    	r1, #0
0x000e30:	str     	r1, [sp]
0x000e32:	str     	r1, [sp, #4]
0x000e34:	movs    	r2, #0
0x000e36:	asrs    	r5, r0, #1
0x000e38:	movs    	r0, #0xf1
0x000e3a:	str     	r2, [sp, #8]
0x000e3c:	movs    	r1, #0x38
0x000e3e:	adds    	r3, r6, #0
0x000e40:	lsls    	r0, r0, #9
0x000e42:	ldr     	r2, [r7, #0x50]
0x000e44:	bl      	#0x3838
0x000e48:	adds    	r1, r5, #0
0x000e4a:	blx     	#0x30
0x000e4e:	str     	r1, [sp, #0x34]
0x000e50:	movs    	r1, #0
0x000e52:	movs    	r2, #0
0x000e54:	str     	r1, [sp]
0x000e56:	str     	r1, [sp, #4]
0x000e58:	movs    	r1, #0x39
0x000e5a:	str     	r2, [sp, #8]
0x000e5c:	adds    	r3, r6, #0
0x000e5e:	movs    	r0, #0xf1
0x000e60:	lsls    	r0, r0, #9
0x000e62:	add     	r2, sp, #0x24
0x000e64:	str     	r6, [sp, #0x38]
0x000e66:	bl      	#0x3838
0x000e6a:	movs    	r3, #1
0x000e6c:	ldrsb   	r2, [r7, r3]
0x000e6e:	movs    	r1, #5
0x000e70:	str     	r1, [sp, #4]
0x000e72:	movs    	r5, #0x6e
0x000e74:	str     	r5, [sp]
0x000e76:	str     	r2, [sp, #8]
0x000e78:	ldr     	r2, [r7, #0x70]
0x000e7a:	movs    	r1, #0xae
0x000e7c:	movs    	r0, #0xf1
0x000e7e:	lsls    	r0, r0, #9
0x000e80:	ldr     	r3, [r7, #0x48]
0x000e82:	bl      	#0x3838
0x000e86:	movs    	r6, #0x19
0x000e88:	movs    	r3, #1
0x000e8a:	ldrsb   	r0, [r7, r3]
0x000e8c:	ldr     	r7, [pc, #0x334]
0x000e8e:	add     	r7, pc
0x000e90:	cmp     	r0, #0
0x000e92:	bge     	#0xeac
0x000e94:	movs    	r2, #0
0x000e96:	ldr     	r3, [pc, #0x330]
0x000e98:	str     	r2, [sp, #8]
0x000e9a:	str     	r5, [sp]
0x000e9c:	str     	r6, [sp, #4]
0x000e9e:	add     	r3, pc
0x000ea0:	adds    	r2, r7, #0
0x000ea2:	movs    	r1, #0x3c
0x000ea4:	adds    	r0, r4, #0
0x000ea6:	bl      	#0x3838
0x000eaa:	b       	#0xee2
0x000eac:	movs    	r1, #0
0x000eae:	movs    	r2, #0
0x000eb0:	str     	r2, [sp, #8]
0x000eb2:	str     	r1, [sp]
0x000eb4:	str     	r1, [sp, #4]
0x000eb6:	movs    	r1, #0xe1
0x000eb8:	movs    	r2, #0x97
0x000eba:	movs    	r3, #0
0x000ebc:	adds    	r0, r4, #0
0x000ebe:	bl      	#0x3838
0x000ec2:	ldr     	r1, [pc, #0x2fc]
0x000ec4:	movs    	r3, #1

; ===== candidate_001208 =====
0x001208:	push    	{r4, r5, r6, r7, lr}
0x00120a:	sub     	sp, #0x3c
0x00120c:	movs    	r1, #0
0x00120e:	movs    	r2, #0
0x001210:	str     	r2, [sp, #8]
0x001212:	str     	r1, [sp]
0x001214:	str     	r1, [sp, #4]
0x001216:	movs    	r1, #0xe1
0x001218:	movs    	r2, #0x2e
0x00121a:	movs    	r3, #0
0x00121c:	movs    	r0, #0xf1
0x00121e:	lsls    	r0, r0, #9
0x001220:	bl      	#0x3838
0x001224:	movs    	r1, #0
0x001226:	movs    	r2, #0
0x001228:	str     	r2, [sp, #8]
0x00122a:	str     	r1, [sp]
0x00122c:	str     	r1, [sp, #4]
0x00122e:	adds    	r4, r0, #0
0x001230:	movs    	r0, #0xf1
0x001232:	movs    	r1, #0xe1
0x001234:	movs    	r2, #0x2a
0x001236:	movs    	r3, #0
0x001238:	lsls    	r0, r0, #9
0x00123a:	bl      	#0x3838
0x00123e:	movs    	r1, #0
0x001240:	str     	r1, [sp]
0x001242:	str     	r1, [sp, #4]
0x001244:	adds    	r6, r4, r0
0x001246:	movs    	r2, #0
0x001248:	movs    	r0, #0xf1
0x00124a:	movs    	r1, #0x1c
0x00124c:	movs    	r3, #0
0x00124e:	lsls    	r0, r0, #9
0x001250:	str     	r2, [sp, #8]
0x001252:	bl      	#0x3838
0x001256:	blx     	#0x318
0x00125a:	adds    	r4, r1, #0
0x00125c:	movs    	r1, #0
0x00125e:	movs    	r2, #0
0x001260:	str     	r2, [sp, #8]
0x001262:	str     	r1, [sp]
0x001264:	str     	r1, [sp, #4]
0x001266:	movs    	r1, #0xe1
0x001268:	movs    	r2, #0x2a
0x00126a:	movs    	r3, #0
0x00126c:	movs    	r0, #0xf1
0x00126e:	lsls    	r0, r0, #9
0x001270:	bl      	#0x3838
0x001274:	lsrs    	r1, r0, #0x1f
0x001276:	adds    	r0, r1, r0
0x001278:	movs    	r1, #0
0x00127a:	asrs    	r7, r0, #1
0x00127c:	str     	r1, [sp]
0x00127e:	str     	r1, [sp, #4]
0x001280:	movs    	r2, #0
0x001282:	movs    	r1, #0x1c
0x001284:	adds    	r7, #2
0x001286:	movs    	r0, #0xf1
0x001288:	movs    	r3, #0
0x00128a:	lsls    	r0, r0, #9
0x00128c:	str     	r2, [sp, #8]
0x00128e:	bl      	#0x3838
0x001292:	movs    	r1, #0
0x001294:	str     	r1, [sp]
0x001296:	str     	r1, [sp, #4]
0x001298:	movs    	r1, #0xff
0x00129a:	movs    	r2, #0
0x00129c:	adds    	r1, #0x27
0x00129e:	movs    	r5, #0
0x0012a0:	movs    	r3, #0
0x0012a2:	movs    	r0, #0xf1
0x0012a4:	lsls    	r0, r0, #9
0x0012a6:	str     	r2, [sp, #8]
0x0012a8:	bl      	#0x3838
0x0012ac:	movs    	r1, #0
0x0012ae:	str     	r1, [sp]
0x0012b0:	str     	r1, [sp, #4]
0x0012b2:	movs    	r1, #0xff
0x0012b4:	movs    	r2, #0
0x0012b6:	adds    	r1, #0x26
0x0012b8:	movs    	r3, #0
0x0012ba:	movs    	r0, #0xf1
0x0012bc:	lsls    	r0, r0, #9
0x0012be:	str     	r2, [sp, #8]
0x0012c0:	bl      	#0x3838
0x0012c4:	movs    	r1, #0
0x0012c6:	movs    	r2, #0
0x0012c8:	str     	r2, [sp, #8]
0x0012ca:	str     	r1, [sp]
0x0012cc:	str     	r1, [sp, #4]
0x0012ce:	movs    	r1, #0xe1
0x0012d0:	movs    	r2, #0xed
0x0012d2:	movs    	r3, #0
0x0012d4:	movs    	r0, #0xf1
0x0012d6:	lsls    	r0, r0, #9
0x0012d8:	bl      	#0x3838
0x0012dc:	cmp     	r0, #0
0x0012de:	ble     	#0x13be
0x0012e0:	movs    	r1, #0
0x0012e2:	str     	r1, [sp]
0x0012e4:	str     	r1, [sp, #4]
0x0012e6:	movs    	r1, #0xff
0x0012e8:	movs    	r2, #0
0x0012ea:	adds    	r1, #0x25
0x0012ec:	movs    	r3, #0
0x0012ee:	movs    	r0, #0xf1
0x0012f0:	lsls    	r0, r0, #9
0x0012f2:	str     	r2, [sp, #8]
0x0012f4:	bl      	#0x3838
0x0012f8:	movs    	r1, #0
0x0012fa:	str     	r1, [sp]
0x0012fc:	str     	r1, [sp, #4]
0x0012fe:	movs    	r2, #0
0x001300:	movs    	r1, #0x40
0x001302:	movs    	r3, #0
0x001304:	movs    	r0, #0xf1
0x001306:	lsls    	r0, r0, #9
0x001308:	str     	r2, [sp, #8]
0x00130a:	bl      	#0x3838
0x00130e:	movs    	r1, #0
0x001310:	str     	r1, [sp]
0x001312:	str     	r1, [sp, #4]
0x001314:	movs    	r2, #0
0x001316:	movs    	r1, #0x1c
0x001318:	movs    	r3, #0
0x00131a:	movs    	r0, #0xf1
0x00131c:	lsls    	r0, r0, #9
0x00131e:	str     	r2, [sp, #8]
0x001320:	bl      	#0x3838
0x001324:	movs    	r2, #0
0x001326:	str     	r0, [sp]
0x001328:	movs    	r0, #0xf1
0x00132a:	movs    	r3, #0
0x00132c:	movs    	r1, #0x32
0x00132e:	lsls    	r0, r0, #9
0x001330:	str     	r2, [sp, #8]
0x001332:	str     	r6, [sp, #4]
0x001334:	bl      	#0x3838
0x001338:	movs    	r1, #0
0x00133a:	movs    	r2, #0

; ===== candidate_0017d0 =====
0x0017d0:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0017d2:	sub     	sp, #0x144
0x0017d4:	movs    	r1, #0
0x0017d6:	adds    	r4, r2, #0
0x0017d8:	movs    	r2, #0
0x0017da:	str     	r2, [sp, #8]
0x0017dc:	str     	r1, [sp]
0x0017de:	str     	r1, [sp, #4]
0x0017e0:	movs    	r6, #0xf1
0x0017e2:	movs    	r7, #0
0x0017e4:	adds    	r3, r7, #0
0x0017e6:	lsls    	r6, r6, #9
0x0017e8:	movs    	r1, #0xe1
0x0017ea:	movs    	r2, #0x2e
0x0017ec:	adds    	r0, r6, #0
0x0017ee:	bl      	#0x3838
0x0017f2:	movs    	r1, #0
0x0017f4:	movs    	r2, #0
0x0017f6:	str     	r2, [sp, #8]
0x0017f8:	str     	r1, [sp]
0x0017fa:	str     	r1, [sp, #4]
0x0017fc:	movs    	r1, #0xe1
0x0017fe:	movs    	r2, #0x2a
0x001800:	adds    	r5, r0, #0
0x001802:	adds    	r3, r7, #0
0x001804:	adds    	r0, r6, #0
0x001806:	bl      	#0x3838
0x00180a:	adds    	r0, r5, r0
0x00180c:	str     	r0, [sp, #0x128]
0x00180e:	lsls    	r7, r0, #2
0x001810:	adds    	r7, r7, r0
0x001812:	ldr     	r0, [sp, #0x150]
0x001814:	movs    	r1, #0x28
0x001816:	str     	r1, [sp, #0x11c]
0x001818:	movs    	r1, #0x13
0x00181a:	str     	r1, [sp, #0x110]
0x00181c:	subs    	r7, #0xa
0x00181e:	subs    	r5, r0, r7
0x001820:	movs    	r1, #0
0x001822:	subs    	r5, #0x28
0x001824:	movs    	r2, #0
0x001826:	str     	r2, [sp, #8]
0x001828:	str     	r5, [sp, #0x114]
0x00182a:	str     	r1, [sp]
0x00182c:	str     	r1, [sp, #4]
0x00182e:	movs    	r1, #0x14
0x001830:	movs    	r5, #0
0x001832:	movs    	r2, #0x54
0x001834:	movs    	r3, #0xa
0x001836:	adds    	r0, r6, #0
0x001838:	bl      	#0x3838
0x00183c:	cmp     	r5, #0
0x00183e:	beq     	#0x185e
0x001840:	cmp     	r5, #1
0x001842:	beq     	#0x1874
0x001844:	cmp     	r5, #2
0x001846:	bne     	#0x188a
0x001848:	ldr     	r0, [pc, #0x3b8]
0x00184a:	movs    	r3, #0xe
0x00184c:	add     	r0, sb
0x00184e:	ldr     	r0, [r0, #0x28]
0x001850:	ldrsb   	r0, [r0, r3]
0x001852:	movs    	r3, #0
0x001854:	str     	r3, [sp, #0x48]
0x001856:	str     	r0, [sp, #0x44]
0x001858:	movs    	r0, #0x34
0x00185a:	str     	r0, [sp, #0x4c]
0x00185c:	b       	#0x1900
0x00185e:	ldr     	r0, [pc, #0x3a4]
0x001860:	movs    	r3, #0
0x001862:	add     	r0, sb
0x001864:	ldr     	r0, [r0, #0x28]
0x001866:	adds    	r0, #0x80
0x001868:	ldr     	r0, [r0, #0x1c]
0x00186a:	str     	r3, [sp, #0x30]
0x00186c:	str     	r0, [sp, #0x2c]
0x00186e:	movs    	r0, #0x32
0x001870:	str     	r0, [sp, #0x34]
0x001872:	b       	#0x1900
0x001874:	ldr     	r0, [pc, #0x38c]
0x001876:	movs    	r3, #0
0x001878:	add     	r0, sb
0x00187a:	ldr     	r0, [r0, #0x28]
0x00187c:	adds    	r0, #0x80
0x00187e:	ldr     	r0, [r0, #0x20]
0x001880:	str     	r3, [sp, #0x3c]
0x001882:	str     	r0, [sp, #0x38]
0x001884:	movs    	r0, #0x33
0x001886:	str     	r0, [sp, #0x40]
0x001888:	b       	#0x1900
0x00188a:	movs    	r0, #2
0x00188c:	str     	r0, [sp]
0x00188e:	ldr     	r0, [pc, #0x374]
0x001890:	movs    	r1, #0
0x001892:	str     	r1, [sp, #4]
0x001894:	movs    	r2, #0
0x001896:	str     	r2, [sp, #8]
0x001898:	add     	r0, sb
0x00189a:	ldr     	r2, [r0, #0x28]
0x00189c:	subs    	r3, r5, #1
0x00189e:	adds    	r6, r3, #0
0x0018a0:	movs    	r0, #0xf1
0x0018a2:	movs    	r1, #0x99
0x0018a4:	lsls    	r0, r0, #9
0x0018a6:	bl      	#0x3838
0x0018aa:	lsls    	r1, r5, #1
0x0018ac:	adds    	r1, r1, r5
0x0018ae:	lsls    	r1, r1, #2
0x0018b0:	str     	r1, [sp, #0x140]
0x0018b2:	add     	r2, sp, #0x2c
0x0018b4:	str     	r0, [r2, r1]
0x0018b6:	movs    	r0, #2
0x0018b8:	str     	r0, [sp]
0x0018ba:	ldr     	r0, [pc, #0x348]
0x0018bc:	movs    	r1, #0
0x0018be:	str     	r1, [sp, #4]
0x0018c0:	movs    	r2, #0
0x0018c2:	str     	r2, [sp, #8]
0x0018c4:	add     	r0, sb
0x0018c6:	ldr     	r2, [r0, #0x28]
0x0018c8:	movs    	r0, #0xf1
0x0018ca:	movs    	r1, #0x99
0x0018cc:	adds    	r3, r6, #0
0x0018ce:	lsls    	r0, r0, #9
0x0018d0:	bl      	#0x3838
0x0018d4:	str     	r0, [sp, #0x28]
0x0018d6:	movs    	r1, #0
0x0018d8:	ldr     	r0, [pc, #0x328]
0x0018da:	str     	r1, [sp]
0x0018dc:	str     	r1, [sp, #4]
0x0018de:	movs    	r2, #0
0x0018e0:	str     	r2, [sp, #8]
0x0018e2:	add     	r0, sb
0x0018e4:	ldr     	r2, [r0, #0x28]
0x0018e6:	movs    	r0, #0xf1
0x0018e8:	movs    	r1, #0x99
0x0018ea:	adds    	r3, r6, #0
0x0018ec:	lsls    	r0, r0, #9
0x0018ee:	bl      	#0x3838
0x0018f2:	ldr     	r1, [sp, #0x28]
0x0018f4:	add     	r2, sp, #0x2c

; ===== candidate_001ca4 =====
0x001ca4:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x001ca6:	sub     	sp, #0x64
0x001ca8:	adds    	r5, r1, #0
0x001caa:	movs    	r1, #0x3c
0x001cac:	str     	r1, [sp, #0x34]
0x001cae:	movs    	r1, #0x1e
0x001cb0:	str     	r1, [sp, #0x30]
0x001cb2:	ldr     	r0, [sp, #0x64]
0x001cb4:	movs    	r1, #0
0x001cb6:	subs    	r3, #0x5a
0x001cb8:	str     	r3, [sp, #0x70]
0x001cba:	str     	r1, [sp]
0x001cbc:	str     	r1, [sp, #4]
0x001cbe:	movs    	r2, #0
0x001cc0:	str     	r0, [sp, #0x4c]
0x001cc2:	movs    	r0, #0xf1
0x001cc4:	movs    	r1, #0x1d
0x001cc6:	movs    	r3, #0
0x001cc8:	movs    	r6, #0x19
0x001cca:	lsls    	r0, r0, #9
0x001ccc:	str     	r2, [sp, #8]
0x001cce:	bl      	#0x3838
0x001cd2:	adds    	r3, r0, #0
0x001cd4:	ldr     	r0, [sp, #0x6c]
0x001cd6:	ldr     	r1, [sp, #0x34]
0x001cd8:	movs    	r2, #0
0x001cda:	str     	r0, [sp]
0x001cdc:	str     	r1, [sp, #4]
0x001cde:	movs    	r1, #0x31
0x001ce0:	movs    	r0, #0xf1
0x001ce2:	subs    	r3, #0x3c
0x001ce4:	lsls    	r0, r0, #9
0x001ce6:	str     	r2, [sp, #8]
0x001ce8:	bl      	#0x3838
0x001cec:	movs    	r1, #0
0x001cee:	str     	r1, [sp]
0x001cf0:	str     	r1, [sp, #4]
0x001cf2:	movs    	r2, #0
0x001cf4:	movs    	r1, #0x1d
0x001cf6:	movs    	r3, #0
0x001cf8:	movs    	r0, #0xf1
0x001cfa:	lsls    	r0, r0, #9
0x001cfc:	str     	r2, [sp, #8]
0x001cfe:	bl      	#0x3838
0x001d02:	adds    	r3, r0, #0
0x001d04:	ldr     	r0, [sp, #0x6c]
0x001d06:	ldr     	r1, [sp, #0x30]
0x001d08:	movs    	r2, #0
0x001d0a:	str     	r0, [sp]
0x001d0c:	str     	r1, [sp, #4]
0x001d0e:	movs    	r1, #0x32
0x001d10:	movs    	r0, #0xf1
0x001d12:	subs    	r3, #0x5a
0x001d14:	lsls    	r0, r0, #9
0x001d16:	str     	r2, [sp, #8]
0x001d18:	bl      	#0x3838
0x001d1c:	movs    	r1, #0
0x001d1e:	ldr     	r0, [pc, #0x3e4]
0x001d20:	movs    	r2, #0
0x001d22:	str     	r2, [sp, #8]
0x001d24:	str     	r1, [sp]
0x001d26:	str     	r1, [sp, #4]
0x001d28:	add     	r0, sb
0x001d2a:	ldr     	r0, [r0, #0x28]
0x001d2c:	movs    	r1, #0x11
0x001d2e:	ldr     	r2, [r0, #0x38]
0x001d30:	movs    	r0, #0xf1
0x001d32:	movs    	r3, #4
0x001d34:	lsls    	r0, r0, #9
0x001d36:	bl      	#0x3838
0x001d3a:	movs    	r2, #0
0x001d3c:	str     	r2, [sp, #8]
0x001d3e:	movs    	r1, #0
0x001d40:	adds    	r2, r0, #1
0x001d42:	str     	r1, [sp]
0x001d44:	str     	r1, [sp, #4]
0x001d46:	movs    	r1, #0xa
0x001d48:	adds    	r4, r2, #0
0x001d4a:	movs    	r0, #0xf1
0x001d4c:	movs    	r3, #4
0x001d4e:	lsls    	r0, r0, #9
0x001d50:	bl      	#0x3838
0x001d54:	adds    	r7, r0, #0
0x001d56:	ldr     	r0, [pc, #0x3ac]
0x001d58:	movs    	r1, #0
0x001d5a:	add     	r0, sb
0x001d5c:	ldr     	r0, [r0, #0x28]
0x001d5e:	movs    	r2, #0
0x001d60:	ldr     	r0, [r0, #0x34]
0x001d62:	adds    	r3, r4, #0
0x001d64:	str     	r0, [r7]
0x001d66:	str     	r1, [sp]
0x001d68:	str     	r1, [sp, #4]
0x001d6a:	str     	r2, [sp, #8]
0x001d6c:	movs    	r2, #0x54
0x001d6e:	movs    	r1, #0x14
0x001d70:	movs    	r0, #0xf1
0x001d72:	lsls    	r0, r0, #9
0x001d74:	bl      	#0x3838
0x001d78:	movs    	r0, #1
0x001d7a:	cmp     	r4, #1
0x001d7c:	ble     	#0x1d96
0x001d7e:	ldr     	r3, [pc, #0x384]
0x001d80:	add     	r3, sb
0x001d82:	ldr     	r1, [r3, #0x28]
0x001d84:	ldr     	r2, [r1, #0x38]
0x001d86:	lsls    	r1, r0, #2
0x001d88:	adds    	r2, r2, r1
0x001d8a:	subs    	r2, #0x40
0x001d8c:	ldr     	r2, [r2, #0x3c]
0x001d8e:	adds    	r0, #1
0x001d90:	cmp     	r0, r4
0x001d92:	str     	r2, [r7, r1]
0x001d94:	blt     	#0x1d82
0x001d96:	adds    	r0, r6, #0
0x001d98:	ldr     	r1, [sp, #0x70]
0x001d9a:	blx     	#0x30
0x001d9e:	str     	r0, [sp, #0x48]
0x001da0:	ldr     	r0, [pc, #0x360]
0x001da2:	str     	r4, [sp, #0x40]
0x001da4:	add     	r0, sb
0x001da6:	ldr     	r1, [r0, #0x14]
0x001da8:	ldr     	r0, [sp, #0x48]
0x001daa:	str     	r1, [sp, #0x60]
0x001dac:	blx     	#0x30
0x001db0:	ldr     	r1, [sp, #0x48]
0x001db2:	ldr     	r4, [sp, #0x40]
0x001db4:	muls    	r0, r1, r0
0x001db6:	str     	r0, [sp, #0x3c]
0x001db8:	adds    	r0, r0, r1
0x001dba:	cmp     	r0, r4
0x001dbc:	bge     	#0x1dc0
0x001dbe:	adds    	r4, r0, #0
0x001dc0:	ldr     	r1, [sp, #0x40]
0x001dc2:	ldr     	r0, [sp, #0x70]
0x001dc4:	ldr     	r2, [sp, #0x60]
0x001dc6:	str     	r0, [sp]
0x001dc8:	str     	r1, [sp, #4]
0x001dca:	ldr     	r1, [sp, #0x6c]
0x001dcc:	ldr     	r0, [sp, #0x4c]
0x001dce:	str     	r2, [sp, #8]

; ===== candidate_0021e8 =====
0x0021e8:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0021ea:	sub     	sp, #0x3c
0x0021ec:	movs    	r1, #0
0x0021ee:	movs    	r2, #0
0x0021f0:	adds    	r7, r0, #0
0x0021f2:	movs    	r0, #0x1e
0x0021f4:	str     	r2, [sp, #8]
0x0021f6:	str     	r1, [sp]
0x0021f8:	str     	r1, [sp, #4]
0x0021fa:	movs    	r4, #0xf1
0x0021fc:	movs    	r6, #0
0x0021fe:	adds    	r3, r6, #0
0x002200:	lsls    	r4, r4, #9
0x002202:	movs    	r1, #0xe1
0x002204:	movs    	r2, #0x53
0x002206:	str     	r0, [sp, #0x30]
0x002208:	movs    	r5, #0x6e
0x00220a:	adds    	r0, r4, #0
0x00220c:	bl      	#0x3838
0x002210:	cmp     	r0, #0
0x002212:	bne     	#0x224a
0x002214:	movs    	r1, #0
0x002216:	str     	r1, [sp]
0x002218:	str     	r1, [sp, #4]
0x00221a:	movs    	r2, #0
0x00221c:	movs    	r1, #0x34
0x00221e:	adds    	r3, r6, #0
0x002220:	adds    	r0, r4, #0
0x002222:	str     	r2, [sp, #8]
0x002224:	bl      	#0x3838
0x002228:	movs    	r1, #0
0x00222a:	str     	r1, [sp]
0x00222c:	str     	r1, [sp, #4]
0x00222e:	ldr     	r1, [pc, #0x2d4]
0x002230:	movs    	r2, #0
0x002232:	str     	r2, [sp, #8]
0x002234:	add     	r1, sb
0x002236:	ldr     	r0, [r1, #0x28]
0x002238:	movs    	r1, #0xff
0x00223a:	adds    	r1, #0x2b
0x00223c:	movs    	r2, #0xc6
0x00223e:	ldr     	r3, [r0, #0x10]
0x002240:	adds    	r0, r4, #0
0x002242:	bl      	#0x3838
0x002246:	add     	sp, #0x4c
0x002248:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002510 =====
0x002510:	push    	{r4, r5, r6, r7, lr}
0x002512:	adds    	r7, r1, #0
0x002514:	adds    	r7, #8
0x002516:	adds    	r6, r1, #0
0x002518:	adds    	r5, r0, #0
0x00251a:	adds    	r4, r2, #0
0x00251c:	movs    	r3, #0
0x00251e:	cmp     	r0, #0
0x002520:	sub     	sp, #0x24
0x002522:	bge     	#0x25a4
0x002524:	movs    	r1, #0
0x002526:	movs    	r2, #0
0x002528:	str     	r2, [sp, #8]
0x00252a:	str     	r1, [sp]
0x00252c:	str     	r1, [sp, #4]
0x00252e:	movs    	r1, #0xe1
0x002530:	movs    	r2, #0x94
0x002532:	movs    	r0, #0xf1
0x002534:	lsls    	r0, r0, #9
0x002536:	bl      	#0x3838
0x00253a:	str     	r0, [sp, #0xc]
0x00253c:	movs    	r0, #7
0x00253e:	str     	r0, [sp, #0x18]
0x002540:	movs    	r1, #0
0x002542:	movs    	r0, #9
0x002544:	movs    	r2, #0
0x002546:	str     	r2, [sp, #8]
0x002548:	str     	r0, [sp, #0x1c]
0x00254a:	str     	r1, [sp]
0x00254c:	str     	r1, [sp, #4]
0x00254e:	movs    	r1, #0xe1
0x002550:	movs    	r0, #0xf1
0x002552:	movs    	r2, #0x27
0x002554:	movs    	r3, #0
0x002556:	lsls    	r0, r0, #9
0x002558:	str     	r6, [sp, #0x10]
0x00255a:	str     	r4, [sp, #0x14]
0x00255c:	bl      	#0x3838
0x002560:	blx     	#0x318
0x002564:	lsrs    	r0, r1, #0x1f
0x002566:	adds    	r0, r0, r1
0x002568:	asrs    	r0, r0, #1
0x00256a:	lsls    	r0, r0, #1
0x00256c:	subs    	r0, r1, r0
0x00256e:	str     	r0, [sp, #0x20]
0x002570:	movs    	r1, #0
0x002572:	movs    	r2, #0
0x002574:	str     	r1, [sp]
0x002576:	str     	r1, [sp, #4]
0x002578:	movs    	r1, #0x22
0x00257a:	str     	r2, [sp, #8]
0x00257c:	movs    	r0, #0xf1
0x00257e:	movs    	r3, #0
0x002580:	lsls    	r0, r0, #9
0x002582:	add     	r2, sp, #0xc
0x002584:	bl      	#0x3838
0x002588:	movs    	r2, #0
0x00258a:	str     	r2, [sp, #8]
0x00258c:	movs    	r1, #0
0x00258e:	str     	r1, [sp, #4]
0x002590:	rsbs    	r2, r5, #0
0x002592:	adds    	r3, r7, #0
0x002594:	movs    	r1, #0xd8
0x002596:	movs    	r0, #0xf1
0x002598:	lsls    	r0, r0, #9
0x00259a:	str     	r4, [sp]
0x00259c:	bl      	#0x3838
0x0025a0:	add     	sp, #0x24
0x0025a2:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002628 =====
0x002628:	push    	{r4, r5, r6, r7, lr}
0x00262a:	sub     	sp, #0x4c
0x00262c:	movs    	r1, #0
0x00262e:	str     	r1, [sp]
0x002630:	str     	r1, [sp, #4]
0x002632:	movs    	r4, #0xf1
0x002634:	movs    	r7, #0
0x002636:	movs    	r2, #0
0x002638:	adds    	r3, r7, #0
0x00263a:	lsls    	r4, r4, #9
0x00263c:	movs    	r1, #0x1c
0x00263e:	movs    	r6, #0x19
0x002640:	adds    	r0, r4, #0
0x002642:	str     	r2, [sp, #8]
0x002644:	bl      	#0x3838
0x002648:	subs    	r0, #0xc
0x00264a:	str     	r0, [sp, #0x38]
0x00264c:	movs    	r1, #0
0x00264e:	movs    	r0, #0
0x002650:	str     	r0, [sp, #0x34]
0x002652:	str     	r1, [sp]
0x002654:	str     	r1, [sp, #4]
0x002656:	movs    	r1, #0xff
0x002658:	movs    	r0, #0x3c
0x00265a:	movs    	r2, #0
0x00265c:	str     	r0, [sp, #0x30]
0x00265e:	adds    	r1, #0x26
0x002660:	adds    	r3, r7, #0
0x002662:	adds    	r0, r4, #0
0x002664:	str     	r2, [sp, #8]
0x002666:	bl      	#0x3838
0x00266a:	movs    	r1, #0
0x00266c:	movs    	r2, #0
0x00266e:	str     	r2, [sp, #8]
0x002670:	str     	r1, [sp]
0x002672:	str     	r1, [sp, #4]
0x002674:	movs    	r1, #0xe1
0x002676:	movs    	r2, #0xed
0x002678:	adds    	r3, r7, #0
0x00267a:	adds    	r0, r4, #0
0x00267c:	bl      	#0x3838
0x002680:	cmp     	r0, #0
0x002682:	ble     	#0x2768
0x002684:	movs    	r1, #0
0x002686:	str     	r1, [sp]
0x002688:	str     	r1, [sp, #4]
0x00268a:	movs    	r1, #0xff
0x00268c:	movs    	r2, #0
0x00268e:	adds    	r1, #0x25
0x002690:	adds    	r3, r7, #0
0x002692:	adds    	r0, r4, #0
0x002694:	str     	r2, [sp, #8]
0x002696:	bl      	#0x3838
0x00269a:	movs    	r1, #0
0x00269c:	ldr     	r0, [pc, #0x3e0]
0x00269e:	str     	r1, [sp]
0x0026a0:	str     	r1, [sp, #4]
0x0026a2:	movs    	r2, #0
0x0026a4:	str     	r2, [sp, #8]
0x0026a6:	add     	r0, sb
0x0026a8:	ldr     	r2, [r0, #0x3c]
0x0026aa:	movs    	r1, #0x11
0x0026ac:	movs    	r3, #4
0x0026ae:	adds    	r0, r4, #0
0x0026b0:	bl      	#0x3838
0x0026b4:	movs    	r1, #0
0x0026b6:	str     	r1, [sp]
0x0026b8:	str     	r1, [sp, #4]
0x0026ba:	str     	r0, [sp, #0x48]
0x0026bc:	movs    	r2, #0
0x0026be:	movs    	r1, #0x40
0x0026c0:	adds    	r3, r7, #0
0x0026c2:	adds    	r0, r4, #0
0x0026c4:	str     	r2, [sp, #8]
0x0026c6:	bl      	#0x3838
0x0026ca:	ldr     	r5, [pc, #0x3b8]
0x0026cc:	add     	r5, pc
0x0026ce:	add     	r2, sp, #0x3c
0x0026d0:	add     	r1, sp, #0x40
0x0026d2:	str     	r1, [sp, #4]
0x0026d4:	str     	r2, [sp, #8]
0x0026d6:	movs    	r0, #0
0x0026d8:	str     	r0, [sp]
0x0026da:	adds    	r2, r5, #0
0x0026dc:	movs    	r1, #0x2a
0x0026de:	adds    	r3, r7, #0
0x0026e0:	adds    	r0, r4, #0
0x0026e2:	bl      	#0x3838
0x0026e6:	movs    	r1, #0
0x0026e8:	str     	r1, [sp]
0x0026ea:	str     	r1, [sp, #4]
0x0026ec:	movs    	r2, #0
0x0026ee:	movs    	r1, #0x1c
0x0026f0:	movs    	r4, #0x1a
0x0026f2:	adds    	r3, r7, #0
0x0026f4:	movs    	r0, #0xf1
0x0026f6:	lsls    	r0, r0, #9
0x0026f8:	str     	r2, [sp, #8]
0x0026fa:	bl      	#0x3838
0x0026fe:	movs    	r2, #0
0x002700:	str     	r0, [sp]
0x002702:	movs    	r0, #0xf1
0x002704:	adds    	r3, r7, #0
0x002706:	movs    	r1, #0x32
0x002708:	lsls    	r0, r0, #9
0x00270a:	str     	r2, [sp, #8]
0x00270c:	str     	r4, [sp, #4]
0x00270e:	bl      	#0x3838
0x002712:	movs    	r1, #0
0x002714:	str     	r1, [sp]
0x002716:	str     	r1, [sp, #4]
0x002718:	movs    	r2, #0
0x00271a:	movs    	r1, #0x1c
0x00271c:	adds    	r3, r7, #0
0x00271e:	movs    	r0, #0xf1
0x002720:	lsls    	r0, r0, #9
0x002722:	str     	r2, [sp, #8]
0x002724:	str     	r5, [sp, #0x10]
0x002726:	bl      	#0x3838
0x00272a:	ldr     	r1, [sp, #0x40]
0x00272c:	movs    	r2, #0
0x00272e:	subs    	r0, r0, r1
0x002730:	lsrs    	r1, r0, #0x1f
0x002732:	adds    	r0, r1, r0
0x002734:	asrs    	r0, r0, #1
0x002736:	str     	r0, [sp, #0x14]
0x002738:	movs    	r0, #8
0x00273a:	str     	r0, [sp, #0x18]
0x00273c:	movs    	r0, #0xff
0x00273e:	str     	r0, [sp, #0x20]
0x002740:	str     	r0, [sp, #0x24]
0x002742:	movs    	r1, #0
0x002744:	str     	r1, [sp]
0x002746:	str     	r1, [sp, #4]
0x002748:	str     	r0, [sp, #0x1c]
0x00274a:	str     	r7, [sp, #0x28]
0x00274c:	str     	r2, [sp, #8]
0x00274e:	movs    	r0, #0xf1
0x002750:	movs    	r1, #0x56
0x002752:	adds    	r3, r7, #0
0x002754:	lsls    	r0, r0, #9

; ===== candidate_002ae0 =====
0x002ae0:	push    	{r4, lr}
0x002ae2:	sub     	sp, #0x10
0x002ae4:	movs    	r1, #0
0x002ae6:	movs    	r2, #0
0x002ae8:	str     	r2, [sp, #8]
0x002aea:	str     	r1, [sp]
0x002aec:	str     	r1, [sp, #4]
0x002aee:	movs    	r1, #0xe1
0x002af0:	movs    	r2, #0x15
0x002af2:	movs    	r4, #0x19
0x002af4:	movs    	r3, #0
0x002af6:	movs    	r0, #0xf1
0x002af8:	lsls    	r0, r0, #9
0x002afa:	bl      	#0x3838
0x002afe:	adds    	r1, r0, #0
0x002b00:	subs    	r1, #0x79
0x002b02:	adds    	r0, r4, #0
0x002b04:	blx     	#0x30
0x002b08:	add     	sp, #0x10
0x002b0a:	pop     	{r4, pc}

; ===== candidate_002b0c =====
0x002b0c:	push    	{r4, r5, r6, r7, lr}
0x002b0e:	sub     	sp, #0xc
0x002b10:	movs    	r1, #0
0x002b12:	str     	r1, [sp]
0x002b14:	str     	r1, [sp, #4]
0x002b16:	movs    	r7, #0xf1
0x002b18:	movs    	r5, #0
0x002b1a:	movs    	r2, #0
0x002b1c:	adds    	r3, r5, #0
0x002b1e:	lsls    	r7, r7, #9
0x002b20:	movs    	r1, #0x13
0x002b22:	adds    	r0, r7, #0
0x002b24:	str     	r2, [sp, #8]
0x002b26:	bl      	#0x3838
0x002b2a:	movs    	r1, #0
0x002b2c:	str     	r1, [sp]
0x002b2e:	str     	r1, [sp, #4]
0x002b30:	movs    	r2, #0
0x002b32:	movs    	r1, #0x34
0x002b34:	adds    	r4, r0, #0
0x002b36:	adds    	r3, r5, #0
0x002b38:	adds    	r0, r7, #0
0x002b3a:	str     	r2, [sp, #8]
0x002b3c:	bl      	#0x3838
0x002b40:	ldr     	r0, [pc, #0x13c]
0x002b42:	movs    	r2, #0
0x002b44:	add     	r0, sb
0x002b46:	str     	r5, [r0, #0x34]
0x002b48:	movs    	r1, #0
0x002b4a:	ldr     	r6, [pc, #0x138]
0x002b4c:	str     	r1, [sp]
0x002b4e:	str     	r1, [sp, #4]
0x002b50:	str     	r2, [sp, #8]
0x002b52:	add     	r6, pc
0x002b54:	adds    	r2, r6, #0
0x002b56:	adds    	r2, #0x10
0x002b58:	adds    	r3, r6, #0
0x002b5a:	movs    	r1, #0x35
0x002b5c:	adds    	r0, r7, #0
0x002b5e:	bl      	#0x3838
0x002b62:	movs    	r1, #0
0x002b64:	movs    	r2, #0
0x002b66:	str     	r2, [sp, #8]
0x002b68:	str     	r1, [sp]
0x002b6a:	str     	r1, [sp, #4]
0x002b6c:	movs    	r1, #0x36
0x002b6e:	adds    	r2, r4, #0
0x002b70:	adds    	r3, r0, #0
0x002b72:	adds    	r0, r7, #0
0x002b74:	bl      	#0x3838
0x002b78:	movs    	r1, #0
0x002b7a:	movs    	r2, #0
0x002b7c:	str     	r2, [sp, #8]
0x002b7e:	str     	r1, [sp]
0x002b80:	str     	r1, [sp, #4]
0x002b82:	movs    	r1, #0x35
0x002b84:	adds    	r2, r6, #4
0x002b86:	adds    	r3, r6, #0
0x002b88:	adds    	r0, r7, #0
0x002b8a:	bl      	#0x3838
0x002b8e:	movs    	r1, #0
0x002b90:	movs    	r2, #0
0x002b92:	str     	r2, [sp, #8]
0x002b94:	str     	r1, [sp]
0x002b96:	str     	r1, [sp, #4]
0x002b98:	movs    	r1, #0x36
0x002b9a:	adds    	r2, r4, #0
0x002b9c:	adds    	r3, r0, #0
0x002b9e:	adds    	r0, r7, #0
0x002ba0:	bl      	#0x3838
0x002ba4:	movs    	r2, #0
0x002ba6:	movs    	r1, #0
0x002ba8:	str     	r2, [sp, #8]
0x002baa:	adds    	r2, r6, #0
0x002bac:	str     	r1, [sp]
0x002bae:	str     	r1, [sp, #4]
0x002bb0:	movs    	r1, #0x35
0x002bb2:	subs    	r2, #0xc
0x002bb4:	adds    	r3, r6, #0
0x002bb6:	adds    	r0, r7, #0
0x002bb8:	bl      	#0x3838
0x002bbc:	movs    	r1, #0
0x002bbe:	movs    	r2, #0
0x002bc0:	str     	r2, [sp, #8]
0x002bc2:	str     	r1, [sp]
0x002bc4:	str     	r1, [sp, #4]
0x002bc6:	movs    	r1, #0x36
0x002bc8:	adds    	r2, r4, #0
0x002bca:	adds    	r3, r0, #0
0x002bcc:	adds    	r0, r7, #0
0x002bce:	bl      	#0x3838
0x002bd2:	movs    	r1, #0
0x002bd4:	movs    	r2, #0
0x002bd6:	str     	r2, [sp, #8]
0x002bd8:	str     	r1, [sp]
0x002bda:	str     	r1, [sp, #4]
0x002bdc:	movs    	r1, #0x26
0x002bde:	adds    	r2, r4, #0
0x002be0:	adds    	r3, r5, #0
0x002be2:	adds    	r0, r7, #0
0x002be4:	bl      	#0x3838
0x002be8:	movs    	r1, #0
0x002bea:	movs    	r2, #0
0x002bec:	str     	r2, [sp, #8]
0x002bee:	str     	r1, [sp]
0x002bf0:	str     	r1, [sp, #4]
0x002bf2:	movs    	r1, #0xa
0x002bf4:	adds    	r2, r0, #0
0x002bf6:	adds    	r5, r0, #0
0x002bf8:	movs    	r3, #4
0x002bfa:	adds    	r0, r7, #0
0x002bfc:	bl      	#0x3838
0x002c00:	ldr     	r1, [pc, #0x7c]
0x002c02:	movs    	r6, #0
0x002c04:	add     	r1, sb
0x002c06:	str     	r0, [r1, #0x38]
0x002c08:	cmp     	r5, #0
0x002c0a:	ble     	#0x2c32
0x002c0c:	movs    	r1, #0
0x002c0e:	movs    	r2, #0
0x002c10:	str     	r2, [sp, #8]
0x002c12:	str     	r1, [sp]
0x002c14:	str     	r1, [sp, #4]
0x002c16:	movs    	r1, #0x27
0x002c18:	adds    	r2, r4, #0
0x002c1a:	adds    	r3, r6, #0
0x002c1c:	adds    	r0, r7, #0
0x002c1e:	bl      	#0x3838
0x002c22:	ldr     	r2, [pc, #0x5c]
0x002c24:	lsls    	r1, r6, #2
0x002c26:	add     	r2, sb
0x002c28:	ldr     	r2, [r2, #0x38]
0x002c2a:	adds    	r6, #1
0x002c2c:	cmp     	r6, r5
0x002c2e:	str     	r0, [r2, r1]
0x002c30:	blt     	#0x2c0c
0x002c32:	movs    	r1, #0
0x002c34:	movs    	r2, #0
0x002c36:	str     	r2, [sp, #8]
0x002c38:	str     	r1, [sp]
0x002c3a:	str     	r1, [sp, #4]

; ===== candidate_002c88 =====
0x002c88:	push    	{r4, r5, r6, r7, lr}
0x002c8a:	ldr     	r5, [pc, #0x17c]
0x002c8c:	sub     	sp, #0xc
0x002c8e:	add     	r5, sb
0x002c90:	strb    	r1, [r5]
0x002c92:	movs    	r1, #0
0x002c94:	adds    	r6, r0, #0
0x002c96:	str     	r1, [sp]
0x002c98:	str     	r1, [sp, #4]
0x002c9a:	movs    	r4, #0
0x002c9c:	movs    	r2, #0
0x002c9e:	adds    	r3, r4, #0
0x002ca0:	movs    	r1, #0x68
0x002ca2:	movs    	r0, #0xf1
0x002ca4:	lsls    	r0, r0, #9
0x002ca6:	str     	r2, [sp, #8]
0x002ca8:	bl      	#0x3838
0x002cac:	str     	r4, [r5, #4]
0x002cae:	str     	r4, [r5, #8]
0x002cb0:	str     	r4, [r5, #0xc]
0x002cb2:	str     	r4, [r5, #0x10]
0x002cb4:	str     	r4, [r5, #0x18]
0x002cb6:	str     	r4, [r5, #0x1c]
0x002cb8:	str     	r4, [r5, #0x20]
0x002cba:	str     	r4, [r5, #0x24]
0x002cbc:	str     	r6, [r5, #0x28]
0x002cbe:	movs    	r1, #0
0x002cc0:	str     	r1, [sp]
0x002cc2:	str     	r1, [sp, #4]
0x002cc4:	movs    	r2, #0
0x002cc6:	movs    	r1, #0x34
0x002cc8:	adds    	r3, r4, #0
0x002cca:	movs    	r0, #0xf1
0x002ccc:	lsls    	r0, r0, #9
0x002cce:	str     	r2, [sp, #8]
0x002cd0:	bl      	#0x3838
0x002cd4:	movs    	r1, #0
0x002cd6:	movs    	r2, #0
0x002cd8:	str     	r2, [sp, #8]
0x002cda:	str     	r1, [sp]
0x002cdc:	str     	r1, [sp, #4]
0x002cde:	movs    	r1, #0x14
0x002ce0:	movs    	r2, #0x53
0x002ce2:	adds    	r3, r4, #0
0x002ce4:	movs    	r0, #0xf1
0x002ce6:	lsls    	r0, r0, #9
0x002ce8:	bl      	#0x3838
0x002cec:	str     	r4, [r5, #0x14]
0x002cee:	movs    	r1, #0
0x002cf0:	movs    	r2, #0
0x002cf2:	str     	r2, [sp, #8]
0x002cf4:	str     	r1, [sp]
0x002cf6:	str     	r1, [sp, #4]
0x002cf8:	movs    	r1, #0x14
0x002cfa:	movs    	r2, #0x57
0x002cfc:	adds    	r3, r4, #0
0x002cfe:	movs    	r0, #0xf1
0x002d00:	lsls    	r0, r0, #9
0x002d02:	bl      	#0x3838
0x002d06:	movs    	r1, #0
0x002d08:	movs    	r2, #0
0x002d0a:	str     	r2, [sp, #8]
0x002d0c:	str     	r1, [sp]
0x002d0e:	str     	r1, [sp, #4]
0x002d10:	movs    	r1, #0xe1
0x002d12:	movs    	r2, #0x55
0x002d14:	adds    	r3, r4, #0
0x002d16:	movs    	r0, #0xf1
0x002d18:	lsls    	r0, r0, #9
0x002d1a:	bl      	#0x3838
0x002d1e:	movs    	r1, #0
0x002d20:	adds    	r7, r0, #0
0x002d22:	movs    	r2, #0
0x002d24:	str     	r2, [sp, #8]
0x002d26:	str     	r1, [sp]
0x002d28:	str     	r1, [sp, #4]
0x002d2a:	movs    	r1, #0xe1
0x002d2c:	movs    	r2, #0x56
0x002d2e:	movs    	r0, #0xf1
0x002d30:	adds    	r3, r4, #0
0x002d32:	lsls    	r0, r0, #9
0x002d34:	bl      	#0x3838
0x002d38:	movs    	r2, #0
0x002d3a:	mvns    	r1, r2
0x002d3c:	str     	r2, [sp, #8]
0x002d3e:	adds    	r2, r0, #0
0x002d40:	movs    	r0, #0xf1
0x002d42:	str     	r1, [sp]
0x002d44:	str     	r1, [sp, #4]
0x002d46:	movs    	r1, #5
0x002d48:	lsls    	r0, r0, #9
0x002d4a:	adds    	r3, r7, #0
0x002d4c:	bl      	#0x3838
0x002d50:	movs    	r1, #0
0x002d52:	movs    	r2, #0
0x002d54:	str     	r2, [sp, #8]
0x002d56:	str     	r1, [sp]
0x002d58:	str     	r1, [sp, #4]
0x002d5a:	adds    	r3, r0, #0
0x002d5c:	movs    	r0, #0xf1
0x002d5e:	movs    	r1, #0x14
0x002d60:	movs    	r2, #0x56
0x002d62:	lsls    	r0, r0, #9
0x002d64:	bl      	#0x3838
0x002d68:	movs    	r1, #0
0x002d6a:	movs    	r2, #0
0x002d6c:	str     	r2, [sp, #8]
0x002d6e:	str     	r1, [sp]
0x002d70:	str     	r1, [sp, #4]
0x002d72:	movs    	r1, #0x14
0x002d74:	movs    	r2, #0x17
0x002d76:	movs    	r3, #0x2d
0x002d78:	movs    	r0, #0xf1
0x002d7a:	lsls    	r0, r0, #9
0x002d7c:	bl      	#0x3838
0x002d80:	str     	r4, [r5, #4]
0x002d82:	movs    	r1, #0
0x002d84:	movs    	r2, #0
0x002d86:	str     	r2, [sp, #8]
0x002d88:	str     	r1, [sp]
0x002d8a:	str     	r1, [sp, #4]
0x002d8c:	movs    	r1, #0x14
0x002d8e:	movs    	r2, #0x99
0x002d90:	adds    	r3, r4, #0
0x002d92:	movs    	r0, #0xf1
0x002d94:	lsls    	r0, r0, #9
0x002d96:	bl      	#0x3838
0x002d9a:	movs    	r1, #0
0x002d9c:	movs    	r2, #0
0x002d9e:	str     	r2, [sp, #8]
0x002da0:	str     	r1, [sp]
0x002da2:	str     	r1, [sp, #4]
0x002da4:	movs    	r1, #0x14
0x002da6:	movs    	r2, #0x98
0x002da8:	adds    	r3, r4, #0
0x002daa:	movs    	r0, #0xf1
0x002dac:	lsls    	r0, r0, #9
0x002dae:	bl      	#0x3838
0x002db2:	str     	r4, [r5, #0x64]
0x002db4:	str     	r4, [r5, #0x60]
0x002db6:	str     	r4, [r5, #0x5c]

; ===== candidate_002e0c =====
0x002e0c:	push    	{r4, r5, r6, lr}
0x002e0e:	sub     	sp, #0x10
0x002e10:	adds    	r4, r0, #0
0x002e12:	bl      	#0x3fc8
0x002e16:	ldr     	r6, [pc, #0x70]
0x002e18:	movs    	r1, #0
0x002e1a:	add     	r6, sb
0x002e1c:	str     	r4, [r6, #0x3c]
0x002e1e:	movs    	r2, #0
0x002e20:	str     	r2, [sp, #8]
0x002e22:	str     	r1, [sp]
0x002e24:	str     	r1, [sp, #4]
0x002e26:	movs    	r4, #0
0x002e28:	movs    	r5, #0xf1
0x002e2a:	lsls    	r5, r5, #9
0x002e2c:	adds    	r3, r4, #0
0x002e2e:	movs    	r1, #0xe1
0x002e30:	movs    	r2, #0x17
0x002e32:	adds    	r0, r5, #0
0x002e34:	bl      	#0x3838
0x002e38:	subs    	r0, #0xff
0x002e3a:	subs    	r0, #0x41
0x002e3c:	beq     	#0x2e52
0x002e3e:	movs    	r1, #0
0x002e40:	str     	r1, [sp]
0x002e42:	str     	r1, [sp, #4]
0x002e44:	movs    	r2, #0
0x002e46:	movs    	r1, #0x34
0x002e48:	adds    	r3, r4, #0
0x002e4a:	adds    	r0, r5, #0
0x002e4c:	str     	r2, [sp, #8]
0x002e4e:	bl      	#0x3838
0x002e52:	str     	r4, [r6, #0x40]
0x002e54:	movs    	r1, #0
0x002e56:	movs    	r2, #0
0x002e58:	str     	r2, [sp, #8]
0x002e5a:	str     	r1, [sp]
0x002e5c:	str     	r1, [sp, #4]
0x002e5e:	movs    	r3, #0xff
0x002e60:	adds    	r3, #0x41
0x002e62:	movs    	r1, #0x14
0x002e64:	movs    	r2, #0x17
0x002e66:	adds    	r0, r5, #0
0x002e68:	bl      	#0x3838
0x002e6c:	movs    	r1, #0
0x002e6e:	str     	r1, [sp]
0x002e70:	str     	r1, [sp, #4]
0x002e72:	movs    	r2, #0
0x002e74:	movs    	r1, #0xba
0x002e76:	adds    	r3, r4, #0
0x002e78:	movs    	r0, #0xf1
0x002e7a:	lsls    	r0, r0, #9
0x002e7c:	str     	r2, [sp, #8]
0x002e7e:	bl      	#0x3838
0x002e82:	add     	sp, #0x10
0x002e84:	pop     	{r4, r5, r6, pc}

; ===== candidate_002e8c =====
0x002e8c:	push    	{r4, r5, r6, lr}
0x002e8e:	sub     	sp, #0x10
0x002e90:	movs    	r1, #0
0x002e92:	movs    	r2, #0
0x002e94:	str     	r2, [sp, #8]
0x002e96:	str     	r1, [sp]
0x002e98:	str     	r1, [sp, #4]
0x002e9a:	adds    	r4, r0, #0
0x002e9c:	movs    	r0, #0xf1
0x002e9e:	movs    	r1, #0x14
0x002ea0:	movs    	r2, #0xee
0x002ea2:	movs    	r3, #0
0x002ea4:	lsls    	r0, r0, #9
0x002ea6:	bl      	#0x3838
0x002eaa:	subs    	r4, #2
0x002eac:	cmp     	r4, #0x13
0x002eae:	bhs     	#0x2eba
0x002eb0:	adr     	r3, #0xc
0x002eb2:	adds    	r3, r3, r4
0x002eb4:	ldrh    	r3, [r3, r4]
0x002eb6:	lsls    	r3, r3, #1
0x002eb8:	add     	pc, r3
0x002eba:	add     	sp, #0x10
0x002ebc:	pop     	{r4, r5, r6, pc}

; ===== candidate_00338c =====
0x00338c:	push    	{r4, r5, r6, lr}
0x00338e:	subs    	r0, #2
0x003390:	cmp     	r0, #0x13
0x003392:	sub     	sp, #0x10
0x003394:	bhs     	#0x33a0
0x003396:	adr     	r3, #0xc
0x003398:	adds    	r3, r3, r0
0x00339a:	ldrh    	r3, [r3, r0]
0x00339c:	lsls    	r3, r3, #1
0x00339e:	add     	pc, r3
0x0033a0:	add     	sp, #0x10
0x0033a2:	pop     	{r4, r5, r6, pc}

; ===== candidate_003594 =====
0x003594:	push    	{r4, r5, r6, r7, lr}
0x003596:	sub     	sp, #0xc
0x003598:	movs    	r1, #0
0x00359a:	str     	r1, [sp]
0x00359c:	str     	r1, [sp, #4]
0x00359e:	ldr     	r6, [pc, #0xb8]
0x0035a0:	movs    	r2, #0
0x0035a2:	movs    	r4, #0xf1
0x0035a4:	lsls    	r4, r4, #9
0x0035a6:	str     	r2, [sp, #8]
0x0035a8:	movs    	r1, #0x11
0x0035aa:	adds    	r5, r0, #0
0x0035ac:	movs    	r3, #4
0x0035ae:	add     	r6, sb
0x0035b0:	ldr     	r2, [r6, #0x38]
0x0035b2:	adds    	r0, r4, #0
0x0035b4:	bl      	#0x3838
0x0035b8:	adds    	r7, r0, #0
0x0035ba:	ldr     	r0, [pc, #0x9c]
0x0035bc:	adds    	r1, r5, #0
0x0035be:	add     	r0, sb
0x0035c0:	adds    	r0, #0x34
0x0035c2:	movs    	r5, #0
0x0035c4:	cmp     	r1, #0xd
0x0035c6:	beq     	#0x363e
0x0035c8:	bgt     	#0x35f4
0x0035ca:	cmp     	r1, #2
0x0035cc:	beq     	#0x35da
0x0035ce:	cmp     	r1, #5
0x0035d0:	beq     	#0x3600
0x0035d2:	cmp     	r1, #8
0x0035d4:	beq     	#0x363e
0x0035d6:	cmp     	r1, #0xc
0x0035d8:	bne     	#0x35f0
0x0035da:	movs    	r2, #0
0x0035dc:	movs    	r1, #0
0x0035de:	str     	r1, [sp, #4]
0x0035e0:	str     	r2, [sp, #8]
0x0035e2:	adds    	r2, r7, #0
0x0035e4:	movs    	r1, #0x29
0x0035e6:	str     	r0, [sp]
0x0035e8:	adds    	r3, r5, #0
0x0035ea:	adds    	r0, r4, #0
0x0035ec:	bl      	#0x3838
0x0035f0:	add     	sp, #0xc
0x0035f2:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00365c =====
0x00365c:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00365e:	sub     	sp, #0xc
0x003660:	adds    	r4, r1, #0
0x003662:	movs    	r1, #0
0x003664:	adds    	r5, r2, #0
0x003666:	movs    	r2, #0
0x003668:	str     	r2, [sp, #8]
0x00366a:	str     	r1, [sp]
0x00366c:	str     	r1, [sp, #4]
0x00366e:	movs    	r6, #0xf1
0x003670:	adds    	r7, r3, #0
0x003672:	movs    	r3, #0
0x003674:	lsls    	r6, r6, #9
0x003676:	movs    	r1, #0xe1
0x003678:	movs    	r2, #0xc6
0x00367a:	adds    	r0, r6, #0
0x00367c:	bl      	#0x3838
0x003680:	cmp     	r0, #0
0x003682:	bne     	#0x369a
0x003684:	movs    	r1, #0
0x003686:	movs    	r2, #0
0x003688:	str     	r2, [sp, #8]
0x00368a:	str     	r1, [sp]
0x00368c:	str     	r1, [sp, #4]
0x00368e:	movs    	r1, #0x14
0x003690:	movs    	r2, #0xc6
0x003692:	movs    	r3, #1
0x003694:	adds    	r0, r6, #0
0x003696:	bl      	#0x3838
0x00369a:	ldr     	r0, [sp, #0xc]
0x00369c:	cmp     	r0, #0x11
0x00369e:	blo     	#0x36a2
0x0036a0:	b       	#0x3794
0x0036a2:	adr     	r3, #8
0x0036a4:	ldrb    	r3, [r3, r0]
0x0036a6:	lsls    	r3, r3, #1
0x0036a8:	add     	pc, r3
0x0036aa:	movs    	r0, r0
0x0036ac:	ldr     	r6, [r3, #0x14]
0x0036ae:	strh    	r1, [r3, r1]
0x0036b0:	ldr     	r2, [pc, #0x138]
0x0036b2:	adcs    	r5, r0
0x0036b4:	adds    	r4, #0x3c
0x0036b6:	cmp     	r3, #0x2f
0x0036b8:	movs    	r3, #0x26
0x0036ba:	subs    	r6, r3, r0
0x0036bc:	movs    	r1, r1
0x0036be:	cmp     	r4, #0x12
0x0036c0:	bne     	#0x36da
0x0036c2:	bl      	#0x3d98
0x0036c6:	movs    	r1, #0
0x0036c8:	str     	r1, [sp]
0x0036ca:	str     	r1, [sp, #4]
0x0036cc:	movs    	r2, #0
0x0036ce:	movs    	r1, #0x2c
0x0036d0:	movs    	r3, #0
0x0036d2:	adds    	r0, r6, #0
0x0036d4:	str     	r2, [sp, #8]
0x0036d6:	bl      	#0x3838
0x0036da:	movs    	r0, #0
0x0036dc:	add     	sp, #0x1c
0x0036de:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0037a8 =====
0x0037a8:	push    	{r3, r4, r5, lr}
0x0037aa:	ldr     	r4, [pc, #0x74]
0x0037ac:	add     	r4, pc
0x0037ae:	ldr     	r0, [r4, #0x38]
0x0037b0:	movs    	r1, #0x14
0x0037b2:	ldr     	r2, [r0, #0x64]
0x0037b4:	ldr     	r0, [pc, #0x6c]
0x0037b6:	add     	r0, pc
0x0037b8:	blx     	r2
0x0037ba:	movs    	r5, #0
0x0037bc:	mvns    	r5, r5
0x0037be:	cmp     	r0, r5
0x0037c0:	bne     	#0x37c6
0x0037c2:	adds    	r0, r5, #0
0x0037c4:	pop     	{r3, r4, r5, pc}

; ===== candidate_003838 =====
0x003838:	push    	{r4, r5, r6, r7, lr}
0x00383a:	adds    	r5, r1, #0
0x00383c:	adds    	r4, r0, #0
0x00383e:	adds    	r6, r2, #0
0x003840:	ldr     	r2, [pc, #0x28]
0x003842:	sub     	sp, #0x14
0x003844:	mov     	ip, r3
0x003846:	add     	r2, pc
0x003848:	ldr     	r0, [sp, #0x2c]
0x00384a:	ldr     	r1, [sp, #0x30]
0x00384c:	ldr     	r7, [sp, #0x28]
0x00384e:	ldr     	r3, [r2, #0x3c]
0x003850:	movs    	r2, #2
0x003852:	str     	r2, [sp, #0xc]
0x003854:	str     	r1, [sp, #8]
0x003856:	str     	r0, [sp, #4]
0x003858:	str     	r7, [sp]
0x00385a:	ldr     	r0, [r3, #0xc]
0x00385c:	adds    	r1, r5, #0
0x00385e:	adds    	r2, r6, #0
0x003860:	ldr     	r7, [r0, #0x28]
0x003862:	adds    	r0, r4, #0
0x003864:	mov     	r3, ip
0x003866:	blx     	r7
0x003868:	add     	sp, #0x14
0x00386a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003874 =====
0x003874:	push    	{r4, lr}
0x003876:	movs    	r2, #0
0x003878:	add     	r0, pc
0x00387a:	ldr     	r4, [r0, #0x3c]
0x00387c:	sub     	sp, #0x10
0x00387e:	movs    	r1, #0
0x003880:	str     	r1, [sp, #4]
0x003882:	str     	r1, [sp, #8]
0x003884:	str     	r2, [sp, #0xc]
0x003886:	str     	r2, [sp]
0x003888:	ldr     	r0, [r4, #0xc]
0x00388a:	ldr     	r2, [r0, #0x24]
0x00388c:	ldr     	r4, [r0, #0x28]
0x00388e:	blx     	r4
0x003890:	add     	sp, #0x10
0x003892:	pop     	{r4, pc}

; ===== candidate_003898 =====
0x003898:	push    	{r4, lr}
0x00389a:	ldr     	r0, [pc, #0x24]
0x00389c:	sub     	sp, #0x10
0x00389e:	add     	r0, pc
0x0038a0:	ldr     	r3, [r0, #0x3c]
0x0038a2:	movs    	r2, #0
0x0038a4:	movs    	r1, #0
0x0038a6:	str     	r1, [sp, #4]
0x0038a8:	str     	r1, [sp, #8]
0x0038aa:	str     	r2, [sp, #0xc]
0x0038ac:	str     	r2, [sp]
0x0038ae:	ldr     	r0, [r3, #0xc]
0x0038b0:	movs    	r3, #0
0x0038b2:	ldr     	r2, [r0, #0x24]
0x0038b4:	ldr     	r4, [r0, #0x28]
0x0038b6:	movs    	r1, #1
0x0038b8:	blx     	r4
0x0038ba:	add     	sp, #0x10
0x0038bc:	pop     	{r4, pc}

; ===== candidate_0038d8 =====
0x0038d8:	push    	{r4, lr}
0x0038da:	sub     	sp, #0x10
0x0038dc:	movs    	r2, #0
0x0038de:	movs    	r1, #0
0x0038e0:	str     	r2, [sp, #8]
0x0038e2:	ldr     	r2, [pc, #0x3c]
0x0038e4:	str     	r1, [sp]
0x0038e6:	str     	r1, [sp, #4]
0x0038e8:	movs    	r3, #0
0x0038ea:	add     	r2, pc
0x0038ec:	ldr     	r1, [pc, #0x34]
0x0038ee:	ldr     	r0, [pc, #0x38]
0x0038f0:	bl      	#0x3838
0x0038f4:	ldr     	r3, [pc, #0x38]
0x0038f6:	ldr     	r4, [pc, #0x34]
0x0038f8:	add     	r3, sb
0x0038fa:	ldr     	r3, [r3]
0x0038fc:	movs    	r2, #0x41
0x0038fe:	movs    	r1, #0
0x003900:	add     	r4, sb
0x003902:	adds    	r0, r4, #0
0x003904:	blx     	r3
0x003906:	bl      	#0x38c4
0x00390a:	ldr     	r3, [pc, #0x28]
0x00390c:	adds    	r1, r0, #0
0x00390e:	add     	r3, sb
0x003910:	ldr     	r3, [r3]
0x003912:	movs    	r2, #0x41
0x003914:	adds    	r0, r4, #0
0x003916:	blx     	r3
0x003918:	movs    	r0, #0
0x00391a:	add     	sp, #0x10
0x00391c:	pop     	{r4, pc}

; ===== candidate_00393c =====
0x00393c:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00393e:	adds    	r7, r3, #0
0x003940:	adds    	r6, r2, #0
0x003942:	adds    	r5, r0, #0
0x003944:	ldr     	r0, [r0]
0x003946:	sub     	sp, #4
0x003948:	mov     	r1, sb
0x00394a:	str     	r1, [sp]
0x00394c:	movs    	r4, #0
0x00394e:	blx     	#0x2f0
0x003952:	ldr     	r0, [sp, #8]
0x003954:	cmp     	r0, #0xb
0x003956:	bhs     	#0x39c4
0x003958:	adr     	r3, #4
0x00395a:	ldrb    	r3, [r3, r0]
0x00395c:	lsls    	r3, r3, #1
0x00395e:	add     	pc, r3
0x003960:	lsrs    	r5, r0, #0x1c
0x003962:	subs    	r4, r3, #4
0x003964:	movs    	r4, #0x21
0x003966:	adds    	r1, #0x27
0x003968:	adds    	r1, #0x2b
0x00396a:	movs    	r7, r5
0x00396c:	ldr     	r1, [pc, #0x60]
0x00396e:	ldr     	r0, [r5, #0xc]
0x003970:	add     	r1, sb
0x003972:	str     	r0, [r1, #0x14]
0x003974:	bl      	#0x338
0x003978:	bl      	#0x38d8
0x00397c:	adds    	r4, r0, #0
0x00397e:	b       	#0x39c4
0x003980:	ldr     	r0, [r6]
0x003982:	cmp     	r0, #8
0x003984:	bne     	#0x398e
0x003986:	bl      	#0x3834
0x00398a:	adds    	r4, r0, #0
0x00398c:	b       	#0x39c4
0x00398e:	ldr     	r1, [r6, #4]
0x003990:	ldr     	r2, [r6, #8]
0x003992:	bl      	#0x3830
0x003996:	adds    	r4, r0, #0
0x003998:	b       	#0x39c4
0x00399a:	bl      	#0x3bcc
0x00399e:	b       	#0x39c4
0x0039a0:	str     	r7, [r5, #0xc]
0x0039a2:	b       	#0x39c4
0x0039a4:	bl      	#0x3938
0x0039a8:	b       	#0x39c4
0x0039aa:	bl      	#0x3a08
0x0039ae:	b       	#0x39c4
0x0039b0:	ldr     	r0, [pc, #0x1c]
0x0039b2:	add     	r0, sb
0x0039b4:	str     	r7, [r0, #0x1c]
0x0039b6:	b       	#0x39c4
0x0039b8:	ldr     	r0, [pc, #0x14]
0x0039ba:	add     	r0, sb
0x0039bc:	str     	r6, [r0, #0x20]
0x0039be:	b       	#0x39c4
0x0039c0:	ldr     	r4, [pc, #0x10]
0x0039c2:	add     	r4, pc
0x0039c4:	ldr     	r1, [sp]
0x0039c6:	add     	sp, #0x14
0x0039c8:	adds    	r0, r4, #0
0x0039ca:	mov     	sb, r1
0x0039cc:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0039d8 =====
0x0039d8:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0039da:	sub     	sp, #0xc
0x0039dc:	ldr     	r0, [sp, #0x38]
0x0039de:	ldr     	r4, [sp, #0x3c]
0x0039e0:	ldr     	r6, [sp, #0x34]
0x0039e2:	ldr     	r0, [r0]
0x0039e4:	mov     	r7, sb
0x0039e6:	movs    	r5, #0
0x0039e8:	blx     	#0x2f0
0x0039ec:	cmp     	r4, #0
0x0039ee:	beq     	#0x39fe
0x0039f0:	ldr     	r1, [sp, #0x30]
0x0039f2:	str     	r6, [sp, #4]
0x0039f4:	add     	r3, sp, #0xc
0x0039f6:	str     	r1, [sp]
0x0039f8:	ldm     	r3, {r0, r1, r2, r3}
0x0039fa:	blx     	r4
0x0039fc:	adds    	r5, r0, #0
0x0039fe:	mov     	sb, r7
0x003a00:	adds    	r0, r5, #0
0x003a02:	add     	sp, #0x1c
0x003a04:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003a6c =====
0x003a6c:	push    	{r3, r4, r5, r6, r7, lr}
0x003a6e:	adds    	r4, r0, #0
0x003a70:	ldr     	r0, [pc, #0x10c]
0x003a72:	movs    	r5, #0
0x003a74:	mvns    	r5, r5
0x003a76:	mov     	ip, r2
0x003a78:	add     	r0, pc
0x003a7a:	ldr     	r2, [r0, #0x38]
0x003a7c:	cmp     	r4, #0
0x003a7e:	bne     	#0x3a90
0x003a80:	ldr     	r0, [pc, #0x100]
0x003a82:	ldr     	r2, [r2, #0x68]
0x003a84:	movs    	r1, #0x7d
0x003a86:	lsls    	r1, r1, #3
0x003a88:	add     	r0, pc
0x003a8a:	blx     	r2
0x003a8c:	adds    	r0, r5, #0
0x003a8e:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_003b98 =====
0x003b98:	push    	{r3, r4, r5, lr}
0x003b9a:	ldr     	r4, [pc, #0x28]
0x003b9c:	adds    	r5, r0, #0
0x003b9e:	add     	r4, pc
0x003ba0:	ldr     	r0, [r4, #0x38]
0x003ba2:	adds    	r0, #0x80
0x003ba4:	ldr     	r0, [r0, #4]
0x003ba6:	blx     	r0
0x003ba8:	adds    	r0, r0, r5
0x003baa:	ldr     	r1, [pc, #0x1c]
0x003bac:	add     	r1, sb
0x003bae:	str     	r0, [r1, #0x10]
0x003bb0:	ldr     	r0, [r4, #0x38]
0x003bb2:	adds    	r0, #0x80
0x003bb4:	ldr     	r0, [r0]
0x003bb6:	blx     	r0
0x003bb8:	ldr     	r0, [r4, #0x38]
0x003bba:	ldr     	r1, [r0, #0x7c]
0x003bbc:	lsls    	r0, r5, #0x10
0x003bbe:	lsrs    	r0, r0, #0x10
0x003bc0:	blx     	r1
0x003bc2:	pop     	{r3, r4, r5, pc}

; ===== candidate_003bce =====
0x003bce:	push    	{r3, r4, r5, r6, r7, lr}
0x003bd0:	add     	r0, pc
0x003bd2:	ldr     	r0, [r0, #0x38]
0x003bd4:	adds    	r0, #0x80
0x003bd6:	ldr     	r0, [r0, #4]
0x003bd8:	blx     	r0
0x003bda:	movs    	r5, #0
0x003bdc:	ldr     	r6, [pc, #0xc8]
0x003bde:	add     	r6, sb
0x003be0:	ldr     	r1, [r6, #0x10]
0x003be2:	str     	r5, [r6, #0x10]
0x003be4:	subs    	r1, r0, r1
0x003be6:	ldr     	r0, [r6, #8]
0x003be8:	adds    	r3, r1, #0
0x003bea:	cmp     	r0, #0
0x003bec:	beq     	#0x3ca2
0x003bee:	ldr     	r2, [r0, #8]
0x003bf0:	cmp     	r2, #0
0x003bf2:	bne     	#0x3c52
0x003bf4:	mvns    	r7, r2
0x003bf6:	str     	r7, [r0, #8]
0x003bf8:	ldr     	r2, [r0, #0x18]
0x003bfa:	adds    	r4, r0, #0
0x003bfc:	cmp     	r1, #0x32
0x003bfe:	str     	r2, [r6, #8]
0x003c00:	bge     	#0x3c06
0x003c02:	movs    	r1, #0x32
0x003c04:	b       	#0x3c22
0x003c06:	movs    	r2, #0x7d
0x003c08:	lsls    	r2, r2, #4
0x003c0a:	cmp     	r1, r2
0x003c0c:	ble     	#0x3c22
0x003c0e:	adds    	r1, r2, #0
0x003c10:	b       	#0x3c22
0x003c12:	movs    	r7, #0
0x003c14:	mvns    	r7, r7
0x003c16:	str     	r7, [r2, #8]
0x003c18:	ldr     	r2, [r0, #0x18]
0x003c1a:	str     	r2, [r0, #0x1c]
0x003c1c:	ldr     	r0, [r2, #0x18]
0x003c1e:	str     	r0, [r6, #8]
0x003c20:	adds    	r0, r2, #0
0x003c22:	ldr     	r2, [r0, #0x18]
0x003c24:	cmp     	r2, #0
0x003c26:	beq     	#0x3c2e
0x003c28:	ldr     	r7, [r2, #8]
0x003c2a:	cmp     	r7, r1
0x003c2c:	blt     	#0x3c12
0x003c2e:	str     	r5, [r0, #0x1c]
0x003c30:	ldr     	r0, [r6, #8]
0x003c32:	cmp     	r0, #0
0x003c34:	beq     	#0x3c96
0x003c36:	cmp     	r3, #0
0x003c38:	bge     	#0x3c3c
0x003c3a:	movs    	r3, #0
0x003c3c:	ldr     	r0, [r6, #8]
0x003c3e:	ldr     	r1, [r0, #8]
0x003c40:	cmp     	r1, #0
0x003c42:	bge     	#0x3c48
0x003c44:	movs    	r1, #0
0x003c46:	str     	r5, [r0, #8]
0x003c48:	ldr     	r2, [pc, #0x60]
0x003c4a:	cmp     	r1, r2
0x003c4c:	ble     	#0x3c56
0x003c4e:	adds    	r1, r2, #0
0x003c50:	b       	#0x3c56
0x003c52:	movs    	r4, #0
0x003c54:	b       	#0x3c36
0x003c56:	ldr     	r2, [r0, #8]
0x003c58:	subs    	r2, r2, r1
0x003c5a:	str     	r2, [r0, #8]
0x003c5c:	ldr     	r0, [r0, #0x18]
0x003c5e:	cmp     	r0, #0
0x003c60:	bne     	#0x3c56
0x003c62:	subs    	r0, r1, r3
0x003c64:	cmp     	r0, #0
0x003c66:	bgt     	#0x3c6a
0x003c68:	movs    	r0, #0xa
0x003c6a:	bl      	#0x3b98
0x003c6e:	b       	#0x3c96
0x003c70:	str     	r5, [r4, #8]
0x003c72:	ldr     	r0, [r4, #0x1c]
0x003c74:	adds    	r3, r5, #0
0x003c76:	str     	r0, [r6, #0xc]
0x003c78:	ldr     	r0, [r4, #0x14]
0x003c7a:	cmp     	r0, #0
0x003c7c:	beq     	#0x3c8a
0x003c7e:	str     	r0, [sp]
0x003c80:	movs    	r1, #0
0x003c82:	adds    	r0, r4, #0
0x003c84:	ldr     	r2, [r4, #0x10]
0x003c86:	bl      	#0x3a6c
0x003c8a:	ldr     	r1, [r4, #0xc]
0x003c8c:	cmp     	r1, #0
0x003c8e:	beq     	#0x3c94
0x003c90:	ldr     	r0, [r4, #0x10]
0x003c92:	blx     	r1
0x003c94:	ldr     	r4, [r6, #0xc]
0x003c96:	cmp     	r4, #0
0x003c98:	beq     	#0x3ca0
0x003c9a:	ldr     	r0, [r4, #8]
0x003c9c:	cmp     	r0, #0
0x003c9e:	blt     	#0x3c70
0x003ca0:	str     	r5, [r6, #0xc]
0x003ca2:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_003cb0 =====
0x003cb0:	push    	{r4, r5, r6, r7, lr}
0x003cb2:	sub     	sp, #0x1c
0x003cb4:	movs    	r1, #0
0x003cb6:	str     	r1, [sp]
0x003cb8:	str     	r1, [sp, #4]
0x003cba:	movs    	r2, #0
0x003cbc:	str     	r2, [sp, #8]
0x003cbe:	movs    	r5, #0xf1
0x003cc0:	movs    	r7, #0
0x003cc2:	adds    	r3, r7, #0
0x003cc4:	lsls    	r5, r5, #9
0x003cc6:	ldr     	r2, [r0, #8]
0x003cc8:	movs    	r1, #0x46
0x003cca:	adds    	r4, r0, #0
0x003ccc:	adds    	r0, r5, #0
0x003cce:	bl      	#0x3838
0x003cd2:	lsls    	r0, r0, #0x18
0x003cd4:	asrs    	r0, r0, #0x18
0x003cd6:	beq     	#0x3d92
0x003cd8:	movs    	r1, #0
0x003cda:	movs    	r2, #0
0x003cdc:	str     	r2, [sp, #8]
0x003cde:	str     	r1, [sp]
0x003ce0:	str     	r1, [sp, #4]
0x003ce2:	movs    	r1, #0xf
0x003ce4:	movs    	r2, #0x10
0x003ce6:	adds    	r3, r7, #0
0x003ce8:	adds    	r0, r5, #0
0x003cea:	bl      	#0x3838
0x003cee:	movs    	r1, #0
0x003cf0:	str     	r1, [sp]
0x003cf2:	str     	r1, [sp, #4]
0x003cf4:	adds    	r5, r0, #0
0x003cf6:	movs    	r2, #0
0x003cf8:	str     	r2, [sp, #8]
0x003cfa:	movs    	r0, #0xf1
0x003cfc:	adds    	r3, r7, #0
0x003cfe:	movs    	r1, #0x45
0x003d00:	lsls    	r0, r0, #9
0x003d02:	ldr     	r2, [r4, #8]
0x003d04:	bl      	#0x3838
0x003d08:	movs    	r1, #0
0x003d0a:	str     	r1, [sp]
0x003d0c:	str     	r1, [sp, #4]
0x003d0e:	str     	r0, [sp, #0x18]
0x003d10:	movs    	r2, #0
0x003d12:	str     	r2, [sp, #8]
0x003d14:	movs    	r0, #0xf1
0x003d16:	movs    	r1, #0x47
0x003d18:	adds    	r3, r7, #0
0x003d1a:	lsls    	r0, r0, #9
0x003d1c:	ldr     	r2, [r4, #8]
0x003d1e:	bl      	#0x3838
0x003d22:	movs    	r1, #0
0x003d24:	str     	r1, [sp]
0x003d26:	str     	r1, [sp, #4]
0x003d28:	str     	r0, [sp, #0x14]
0x003d2a:	movs    	r2, #0
0x003d2c:	str     	r2, [sp, #8]
0x003d2e:	movs    	r0, #0xf1
0x003d30:	movs    	r1, #0x46
0x003d32:	adds    	r3, r7, #0
0x003d34:	lsls    	r0, r0, #9
0x003d36:	ldr     	r2, [r4, #8]
0x003d38:	bl      	#0x3838
0x003d3c:	lsls    	r0, r0, #0x18
0x003d3e:	movs    	r1, #0
0x003d40:	asrs    	r0, r0, #0x18
0x003d42:	str     	r0, [sp, #0x10]
0x003d44:	str     	r1, [sp]
0x003d46:	str     	r1, [sp, #4]
0x003d48:	movs    	r2, #0
0x003d4a:	str     	r2, [sp, #8]
0x003d4c:	movs    	r1, #0x46
0x003d4e:	movs    	r0, #0xf1
0x003d50:	movs    	r6, #0
0x003d52:	adds    	r3, r7, #0
0x003d54:	lsls    	r0, r0, #9
0x003d56:	ldr     	r2, [r4, #8]
0x003d58:	bl      	#0x3838
0x003d5c:	lsls    	r0, r0, #0x18
0x003d5e:	asrs    	r0, r0, #0x18
0x003d60:	cmp     	r0, #1
0x003d62:	bne     	#0x3d7e
0x003d64:	movs    	r1, #0
0x003d66:	str     	r1, [sp]
0x003d68:	str     	r1, [sp, #4]
0x003d6a:	movs    	r2, #0
0x003d6c:	str     	r2, [sp, #8]
0x003d6e:	movs    	r1, #0x47
0x003d70:	adds    	r3, r7, #0
0x003d72:	movs    	r0, #0xf1
0x003d74:	lsls    	r0, r0, #9
0x003d76:	ldr     	r2, [r4, #8]
0x003d78:	bl      	#0x3838
0x003d7c:	adds    	r6, r0, #0
0x003d7e:	ldr     	r0, [sp, #0x18]
0x003d80:	str     	r0, [r5]
0x003d82:	ldr     	r0, [sp, #0x14]
0x003d84:	str     	r0, [r5, #4]
0x003d86:	ldr     	r0, [sp, #0x10]
0x003d88:	strb    	r0, [r5, #8]
0x003d8a:	str     	r6, [r5, #0xc]
0x003d8c:	adds    	r0, r5, #0
0x003d8e:	add     	sp, #0x1c
0x003d90:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003d98 =====
0x003d98:	push    	{r4, r5, r6, r7, lr}
0x003d9a:	ldr     	r6, [pc, #0xa4]
0x003d9c:	movs    	r4, #0xf1
0x003d9e:	add     	r6, sb
0x003da0:	ldr     	r7, [r6, #0x48]
0x003da2:	lsls    	r4, r4, #9
0x003da4:	movs    	r5, #0
0x003da6:	cmp     	r7, #0
0x003da8:	sub     	sp, #0xc
0x003daa:	beq     	#0x3dc2
0x003dac:	movs    	r1, #0
0x003dae:	movs    	r2, #0
0x003db0:	str     	r2, [sp, #8]
0x003db2:	str     	r1, [sp]
0x003db4:	str     	r1, [sp, #4]
0x003db6:	movs    	r1, #9
0x003db8:	adds    	r2, r7, #0
0x003dba:	adds    	r3, r5, #0
0x003dbc:	adds    	r0, r4, #0
0x003dbe:	bl      	#0x3838
0x003dc2:	str     	r5, [r6, #0x48]
0x003dc4:	ldr     	r7, [r6, #0x4c]
0x003dc6:	cmp     	r7, #0
0x003dc8:	beq     	#0x3de0
0x003dca:	movs    	r1, #0
0x003dcc:	movs    	r2, #0
0x003dce:	str     	r2, [sp, #8]
0x003dd0:	str     	r1, [sp]
0x003dd2:	str     	r1, [sp, #4]
0x003dd4:	movs    	r1, #9
0x003dd6:	adds    	r2, r7, #0
0x003dd8:	adds    	r3, r5, #0
0x003dda:	adds    	r0, r4, #0
0x003ddc:	bl      	#0x3838
0x003de0:	str     	r5, [r6, #0x4c]
0x003de2:	ldr     	r7, [r6, #0x54]
0x003de4:	cmp     	r7, #0
0x003de6:	beq     	#0x3dfe
0x003de8:	movs    	r1, #0
0x003dea:	movs    	r2, #0
0x003dec:	str     	r2, [sp, #8]
0x003dee:	str     	r1, [sp]
0x003df0:	str     	r1, [sp, #4]
0x003df2:	movs    	r1, #9
0x003df4:	adds    	r2, r7, #0
0x003df6:	adds    	r3, r5, #0
0x003df8:	adds    	r0, r4, #0
0x003dfa:	bl      	#0x3838
0x003dfe:	str     	r5, [r6, #0x54]
0x003e00:	ldr     	r7, [r6, #0x50]
0x003e02:	cmp     	r7, #0
0x003e04:	beq     	#0x3e1c
0x003e06:	movs    	r1, #0
0x003e08:	movs    	r2, #0
0x003e0a:	str     	r2, [sp, #8]
0x003e0c:	str     	r1, [sp]
0x003e0e:	str     	r1, [sp, #4]
0x003e10:	movs    	r1, #0x4c
0x003e12:	adds    	r2, r7, #0
0x003e14:	adds    	r3, r5, #0
0x003e16:	adds    	r0, r4, #0
0x003e18:	bl      	#0x3838
0x003e1c:	str     	r5, [r6, #0x50]
0x003e1e:	ldr     	r7, [r6, #0x58]
0x003e20:	cmp     	r7, #0
0x003e22:	beq     	#0x3e3a
0x003e24:	movs    	r1, #0
0x003e26:	movs    	r2, #0
0x003e28:	str     	r2, [sp, #8]
0x003e2a:	str     	r1, [sp]
0x003e2c:	str     	r1, [sp, #4]
0x003e2e:	movs    	r1, #9
0x003e30:	adds    	r2, r7, #0
0x003e32:	adds    	r3, r5, #0
0x003e34:	adds    	r0, r4, #0
0x003e36:	bl      	#0x3838
0x003e3a:	str     	r5, [r6, #0x58]
0x003e3c:	add     	sp, #0xc
0x003e3e:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003e44 =====
0x003e44:	push    	{r4, r5, r6, lr}
0x003e46:	ldr     	r6, [pc, #0x17c]
0x003e48:	movs    	r4, #0
0x003e4a:	sub     	sp, #0x10
0x003e4c:	add     	r6, sb
0x003e4e:	str     	r4, [r6, #8]
0x003e50:	movs    	r1, #0
0x003e52:	str     	r1, [sp]
0x003e54:	str     	r1, [sp, #4]
0x003e56:	movs    	r5, #0xf1
0x003e58:	movs    	r2, #0
0x003e5a:	lsls    	r5, r5, #9
0x003e5c:	movs    	r1, #0x7c
0x003e5e:	adds    	r3, r4, #0
0x003e60:	adds    	r0, r5, #0
0x003e62:	str     	r2, [sp, #8]
0x003e64:	bl      	#0x3838
0x003e68:	str     	r4, [r6, #0x28]
0x003e6a:	movs    	r1, #0
0x003e6c:	str     	r1, [sp]
0x003e6e:	str     	r1, [sp, #4]
0x003e70:	movs    	r2, #0
0x003e72:	movs    	r1, #0x69
0x003e74:	adds    	r3, r4, #0
0x003e76:	adds    	r0, r5, #0
0x003e78:	str     	r2, [sp, #8]
0x003e7a:	bl      	#0x3838
0x003e7e:	movs    	r1, #0
0x003e80:	str     	r1, [sp]
0x003e82:	str     	r1, [sp, #4]
0x003e84:	movs    	r2, #0
0x003e86:	movs    	r1, #0x7a
0x003e88:	adds    	r3, r4, #0
0x003e8a:	adds    	r0, r5, #0
0x003e8c:	str     	r2, [sp, #8]
0x003e8e:	bl      	#0x3838
0x003e92:	movs    	r1, #0
0x003e94:	movs    	r2, #0
0x003e96:	str     	r2, [sp, #8]
0x003e98:	str     	r1, [sp]
0x003e9a:	str     	r1, [sp, #4]
0x003e9c:	movs    	r1, #0x14
0x003e9e:	movs    	r2, #0x98
0x003ea0:	adds    	r3, r4, #0
0x003ea2:	adds    	r0, r5, #0
0x003ea4:	bl      	#0x3838
0x003ea8:	movs    	r1, #0
0x003eaa:	movs    	r2, #0
0x003eac:	str     	r2, [sp, #8]
0x003eae:	str     	r1, [sp]
0x003eb0:	str     	r1, [sp, #4]
0x003eb2:	movs    	r1, #0xe1
0x003eb4:	movs    	r2, #0x6e
0x003eb6:	adds    	r3, r4, #0
0x003eb8:	adds    	r0, r5, #0
0x003eba:	bl      	#0x3838
0x003ebe:	cmp     	r0, #0
0x003ec0:	beq     	#0x3f04
0x003ec2:	movs    	r1, #0
0x003ec4:	movs    	r2, #0
0x003ec6:	str     	r2, [sp, #8]
0x003ec8:	str     	r1, [sp]
0x003eca:	str     	r1, [sp, #4]
0x003ecc:	movs    	r1, #0xe1
0x003ece:	movs    	r2, #0x6e
0x003ed0:	adds    	r3, r4, #0
0x003ed2:	adds    	r0, r5, #0
0x003ed4:	bl      	#0x3838
0x003ed8:	movs    	r1, #0
0x003eda:	movs    	r2, #0
0x003edc:	str     	r2, [sp, #8]
0x003ede:	str     	r1, [sp]
0x003ee0:	str     	r1, [sp, #4]
0x003ee2:	movs    	r1, #0x8c
0x003ee4:	adds    	r2, r0, #0
0x003ee6:	adds    	r3, r4, #0
0x003ee8:	adds    	r0, r5, #0
0x003eea:	bl      	#0x3838
0x003eee:	movs    	r1, #0
0x003ef0:	movs    	r2, #0
0x003ef2:	str     	r2, [sp, #8]
0x003ef4:	str     	r1, [sp]
0x003ef6:	str     	r1, [sp, #4]
0x003ef8:	movs    	r1, #0x14
0x003efa:	movs    	r2, #0x6e
0x003efc:	adds    	r3, r4, #0
0x003efe:	adds    	r0, r5, #0
0x003f00:	bl      	#0x3838
0x003f04:	movs    	r1, #0
0x003f06:	movs    	r2, #0
0x003f08:	str     	r2, [sp, #8]
0x003f0a:	str     	r1, [sp]
0x003f0c:	str     	r1, [sp, #4]
0x003f0e:	movs    	r1, #0xe1
0x003f10:	movs    	r2, #0x56
0x003f12:	adds    	r3, r4, #0
0x003f14:	adds    	r0, r5, #0
0x003f16:	bl      	#0x3838
0x003f1a:	cmp     	r0, #0
0x003f1c:	beq     	#0x3f64
0x003f1e:	movs    	r1, #0
0x003f20:	movs    	r2, #0
0x003f22:	str     	r2, [sp, #8]
0x003f24:	str     	r1, [sp]
0x003f26:	str     	r1, [sp, #4]
0x003f28:	movs    	r1, #0xe1
0x003f2a:	movs    	r2, #0x56
0x003f2c:	adds    	r3, r4, #0
0x003f2e:	adds    	r0, r5, #0
0x003f30:	bl      	#0x3838
0x003f34:	movs    	r2, #0
0x003f36:	movs    	r1, #0
0x003f38:	str     	r2, [sp, #8]
0x003f3a:	adds    	r3, r4, #0
0x003f3c:	adds    	r2, r0, #0
0x003f3e:	str     	r1, [sp]
0x003f40:	str     	r1, [sp, #4]
0x003f42:	movs    	r1, #6
0x003f44:	movs    	r0, #0xf1
0x003f46:	lsls    	r0, r0, #9
0x003f48:	bl      	#0x3838
0x003f4c:	movs    	r1, #0
0x003f4e:	movs    	r2, #0
0x003f50:	str     	r2, [sp, #8]
0x003f52:	str     	r1, [sp]
0x003f54:	str     	r1, [sp, #4]
0x003f56:	movs    	r1, #0x14
0x003f58:	movs    	r2, #0x56
0x003f5a:	adds    	r3, r4, #0
0x003f5c:	movs    	r0, #0xf1
0x003f5e:	lsls    	r0, r0, #9
0x003f60:	bl      	#0x3838
0x003f64:	movs    	r1, #0
0x003f66:	str     	r1, [sp]
0x003f68:	str     	r1, [sp, #4]
0x003f6a:	movs    	r2, #0
0x003f6c:	movs    	r1, #0xe6
0x003f6e:	adds    	r3, r4, #0
0x003f70:	adds    	r0, r5, #0
0x003f72:	str     	r2, [sp, #8]
0x003f74:	bl      	#0x3838

; ===== candidate_003fc8 =====
0x003fc8:	push    	{r4, r5, r6, r7, lr}
0x003fca:	ldr     	r5, [pc, #0xd0]
0x003fcc:	movs    	r7, #0xf1
0x003fce:	add     	r5, sb
0x003fd0:	ldr     	r4, [r5, #0x3c]
0x003fd2:	lsls    	r7, r7, #9
0x003fd4:	cmp     	r4, #0
0x003fd6:	sub     	sp, #0xc
0x003fd8:	beq     	#0x4074
0x003fda:	movs    	r1, #0
0x003fdc:	movs    	r2, #0
0x003fde:	str     	r2, [sp, #8]
0x003fe0:	str     	r1, [sp]
0x003fe2:	str     	r1, [sp, #4]
0x003fe4:	movs    	r1, #0x11
0x003fe6:	adds    	r2, r4, #0
0x003fe8:	movs    	r3, #4
0x003fea:	adds    	r0, r7, #0
0x003fec:	bl      	#0x3838
0x003ff0:	adds    	r6, r0, #0
0x003ff2:	movs    	r5, #0
0x003ff4:	cmp     	r0, #0
0x003ff6:	ble     	#0x4056
0x003ff8:	ldr     	r1, [pc, #0xa0]
0x003ffa:	lsls    	r0, r5, #2
0x003ffc:	add     	r1, sb
0x003ffe:	ldr     	r1, [r1, #0x3c]
0x004000:	ldr     	r4, [r1, r0]
0x004002:	cmp     	r4, #0
0x004004:	beq     	#0x4050
0x004006:	movs    	r1, #0
0x004008:	str     	r1, [sp]
0x00400a:	str     	r1, [sp, #4]
0x00400c:	movs    	r2, #0
0x00400e:	str     	r2, [sp, #8]
0x004010:	movs    	r1, #9
0x004012:	movs    	r3, #0
0x004014:	adds    	r0, r7, #0
0x004016:	ldr     	r2, [r4, #4]
0x004018:	bl      	#0x3838
0x00401c:	movs    	r1, #0
0x00401e:	movs    	r2, #0
0x004020:	str     	r2, [sp, #8]
0x004022:	str     	r1, [sp]
0x004024:	str     	r1, [sp, #4]
0x004026:	movs    	r1, #9
0x004028:	adds    	r2, r4, #0
0x00402a:	movs    	r3, #0
0x00402c:	movs    	r0, #0xf1
0x00402e:	lsls    	r0, r0, #9
0x004030:	bl      	#0x3838
0x004034:	ldr     	r3, [r4, #0xc]
0x004036:	cmp     	r3, #0
0x004038:	beq     	#0x4050
0x00403a:	movs    	r2, #0
0x00403c:	movs    	r1, #0
0x00403e:	str     	r2, [sp, #8]
0x004040:	adds    	r2, r3, #0
0x004042:	str     	r1, [sp]
0x004044:	str     	r1, [sp, #4]
0x004046:	movs    	r1, #9
0x004048:	movs    	r3, #0
0x00404a:	adds    	r0, r7, #0
0x00404c:	bl      	#0x3838
0x004050:	adds    	r5, #1
0x004052:	cmp     	r5, r6
0x004054:	blt     	#0x3ff8
0x004056:	movs    	r1, #0
0x004058:	str     	r1, [sp]
0x00405a:	str     	r1, [sp, #4]
0x00405c:	movs    	r2, #0
0x00405e:	ldr     	r5, [pc, #0x3c]
0x004060:	movs    	r4, #0
0x004062:	adds    	r3, r4, #0
0x004064:	str     	r2, [sp, #8]
0x004066:	movs    	r1, #9
0x004068:	add     	r5, sb
0x00406a:	ldr     	r2, [r5, #0x3c]
0x00406c:	adds    	r0, r7, #0
0x00406e:	bl      	#0x3838
0x004072:	str     	r4, [r5, #0x3c]
0x004074:	ldr     	r5, [pc, #0x24]
0x004076:	add     	r5, sb
0x004078:	ldr     	r6, [r5, #0x44]
0x00407a:	cmp     	r6, #0
0x00407c:	beq     	#0x4098
0x00407e:	movs    	r1, #0
0x004080:	movs    	r2, #0
0x004082:	str     	r2, [sp, #8]
0x004084:	str     	r1, [sp]
0x004086:	str     	r1, [sp, #4]
0x004088:	movs    	r4, #0
0x00408a:	adds    	r3, r4, #0
0x00408c:	movs    	r1, #0x12
0x00408e:	adds    	r2, r6, #0
0x004090:	adds    	r0, r7, #0
0x004092:	bl      	#0x3838
0x004096:	str     	r4, [r5, #0x44]
0x004098:	add     	sp, #0xc
0x00409a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0040a0 =====
0x0040a0:	push    	{r4, r5, r6, r7, lr}
0x0040a2:	sub     	sp, #0x14
0x0040a4:	movs    	r1, #0
0x0040a6:	movs    	r6, #0xff
0x0040a8:	movs    	r2, #0
0x0040aa:	str     	r2, [sp, #8]
0x0040ac:	adds    	r6, #0xa4
0x0040ae:	str     	r1, [sp]
0x0040b0:	str     	r1, [sp, #4]
0x0040b2:	movs    	r5, #0xf1
0x0040b4:	movs    	r4, #0
0x0040b6:	adds    	r3, r4, #0
0x0040b8:	lsls    	r5, r5, #9
0x0040ba:	movs    	r1, #0x17
0x0040bc:	adds    	r2, r6, #0
0x0040be:	adds    	r0, r5, #0
0x0040c0:	bl      	#0x3838
0x0040c4:	movs    	r1, #0
0x0040c6:	movs    	r2, #0
0x0040c8:	str     	r2, [sp, #8]
0x0040ca:	str     	r1, [sp]
0x0040cc:	str     	r1, [sp, #4]
0x0040ce:	movs    	r1, #0xe1
0x0040d0:	movs    	r2, #0x1d
0x0040d2:	movs    	r3, #0
0x0040d4:	adds    	r0, r5, #0
0x0040d6:	bl      	#0x3838
0x0040da:	movs    	r1, #0
0x0040dc:	movs    	r2, #0
0x0040de:	str     	r2, [sp, #8]
0x0040e0:	str     	r1, [sp]
0x0040e2:	str     	r1, [sp, #4]
0x0040e4:	movs    	r1, #0xe1
0x0040e6:	movs    	r2, #0x18
0x0040e8:	str     	r0, [sp, #0x10]
0x0040ea:	movs    	r3, #0
0x0040ec:	adds    	r0, r5, #0
0x0040ee:	bl      	#0x3838
0x0040f2:	ldr     	r7, [r0, #0xc]
0x0040f4:	movs    	r1, #0
0x0040f6:	movs    	r2, #0
0x0040f8:	str     	r2, [sp, #8]
0x0040fa:	str     	r1, [sp]
0x0040fc:	str     	r1, [sp, #4]
0x0040fe:	movs    	r1, #0xe1
0x004100:	movs    	r2, #0x18
0x004102:	movs    	r3, #0
0x004104:	adds    	r0, r5, #0
0x004106:	bl      	#0x3838
0x00410a:	ldr     	r3, [r0, #8]
0x00410c:	ldr     	r1, [sp, #0x10]
0x00410e:	movs    	r2, #0
0x004110:	str     	r2, [sp, #8]
0x004112:	str     	r1, [sp, #4]
0x004114:	movs    	r1, #0x52
0x004116:	adds    	r2, r6, #0
0x004118:	adds    	r0, r5, #0
0x00411a:	str     	r7, [sp]
0x00411c:	bl      	#0x3838
0x004120:	movs    	r1, #0
0x004122:	ldr     	r6, [pc, #0xd0]
0x004124:	movs    	r2, #0
0x004126:	str     	r2, [sp, #8]
0x004128:	str     	r1, [sp]
0x00412a:	str     	r1, [sp, #4]
0x00412c:	add     	r6, sb
0x00412e:	ldr     	r0, [r6, #0x28]
0x004130:	movs    	r1, #0x19
0x004132:	movs    	r3, #0
0x004134:	ldr     	r2, [r0]
0x004136:	adds    	r0, r5, #0
0x004138:	bl      	#0x3838
0x00413c:	ldr     	r0, [r6, #0x30]
0x00413e:	adds    	r3, r0, #1
0x004140:	bne     	#0x415a
0x004142:	movs    	r1, #0
0x004144:	movs    	r2, #0
0x004146:	str     	r2, [sp, #8]
0x004148:	str     	r1, [sp]
0x00414a:	str     	r1, [sp, #4]
0x00414c:	movs    	r1, #0x1a
0x00414e:	movs    	r2, #1
0x004150:	adds    	r3, r4, #0
0x004152:	adds    	r0, r5, #0
0x004154:	bl      	#0x3838
0x004158:	b       	#0x4170
0x00415a:	movs    	r1, #0
0x00415c:	movs    	r2, #0
0x00415e:	str     	r2, [sp, #8]
0x004160:	str     	r1, [sp]
0x004162:	str     	r1, [sp, #4]
0x004164:	movs    	r1, #0x1a
0x004166:	movs    	r2, #2
0x004168:	adds    	r3, r4, #0
0x00416a:	adds    	r0, r5, #0
0x00416c:	bl      	#0x3838
0x004170:	ldr     	r7, [r6, #0x2c]
0x004172:	adds    	r3, r7, #1
0x004174:	beq     	#0x41a4
0x004176:	movs    	r1, #0
0x004178:	movs    	r2, #0
0x00417a:	str     	r2, [sp, #8]
0x00417c:	str     	r1, [sp]
0x00417e:	str     	r1, [sp, #4]
0x004180:	movs    	r1, #0xed
0x004182:	adds    	r2, r7, #0
0x004184:	adds    	r3, r4, #0
0x004186:	adds    	r0, r5, #0
0x004188:	bl      	#0x3838
0x00418c:	movs    	r2, #0
0x00418e:	movs    	r1, #0
0x004190:	str     	r2, [sp, #8]
0x004192:	adds    	r3, r4, #0
0x004194:	adds    	r2, r0, #0
0x004196:	str     	r1, [sp]
0x004198:	str     	r1, [sp, #4]
0x00419a:	movs    	r1, #0x49
0x00419c:	movs    	r0, #0xf1
0x00419e:	lsls    	r0, r0, #9
0x0041a0:	bl      	#0x3838
0x0041a4:	ldr     	r6, [r6, #0x30]
0x0041a6:	adds    	r3, r6, #1
0x0041a8:	beq     	#0x41d8
0x0041aa:	movs    	r1, #0
0x0041ac:	movs    	r2, #0
0x0041ae:	str     	r2, [sp, #8]
0x0041b0:	str     	r1, [sp]
0x0041b2:	str     	r1, [sp, #4]
0x0041b4:	movs    	r1, #0xed
0x0041b6:	adds    	r2, r6, #0
0x0041b8:	adds    	r3, r4, #0
0x0041ba:	adds    	r0, r5, #0
0x0041bc:	bl      	#0x3838
0x0041c0:	movs    	r2, #0
0x0041c2:	movs    	r1, #0
0x0041c4:	str     	r2, [sp, #8]
0x0041c6:	adds    	r3, r4, #0
0x0041c8:	adds    	r2, r0, #0
0x0041ca:	str     	r1, [sp]
0x0041cc:	str     	r1, [sp, #4]
0x0041ce:	movs    	r1, #0x49

; ===== candidate_0041f8 =====
0x0041f8:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x0041fa:	sub     	sp, #0xc
0x0041fc:	movs    	r1, #0
0x0041fe:	movs    	r4, #0
0x004200:	movs    	r2, #0
0x004202:	str     	r2, [sp, #8]
0x004204:	adds    	r3, r4, #0
0x004206:	str     	r1, [sp]
0x004208:	str     	r1, [sp, #4]
0x00420a:	movs    	r5, #0x27
0x00420c:	adds    	r2, r5, #0
0x00420e:	movs    	r1, #0x17
0x004210:	movs    	r0, #0xf1
0x004212:	lsls    	r0, r0, #9
0x004214:	bl      	#0x3838
0x004218:	movs    	r1, #0
0x00421a:	movs    	r2, #0
0x00421c:	str     	r2, [sp, #8]
0x00421e:	str     	r1, [sp]
0x004220:	str     	r1, [sp, #4]
0x004222:	movs    	r1, #0xe1
0x004224:	movs    	r2, #0x1d
0x004226:	adds    	r3, r4, #0
0x004228:	movs    	r0, #0xf1
0x00422a:	lsls    	r0, r0, #9
0x00422c:	bl      	#0x3838
0x004230:	movs    	r1, #0
0x004232:	adds    	r6, r0, #0
0x004234:	movs    	r2, #0
0x004236:	str     	r2, [sp, #8]
0x004238:	str     	r1, [sp]
0x00423a:	str     	r1, [sp, #4]
0x00423c:	movs    	r1, #0xe1
0x00423e:	movs    	r2, #0x18
0x004240:	movs    	r0, #0xf1
0x004242:	adds    	r3, r4, #0
0x004244:	lsls    	r0, r0, #9
0x004246:	bl      	#0x3838
0x00424a:	ldr     	r7, [r0, #0xc]
0x00424c:	movs    	r1, #0
0x00424e:	movs    	r2, #0
0x004250:	str     	r2, [sp, #8]
0x004252:	str     	r1, [sp]
0x004254:	str     	r1, [sp, #4]
0x004256:	movs    	r1, #0xe1
0x004258:	movs    	r2, #0x18
0x00425a:	movs    	r0, #0xf1
0x00425c:	adds    	r3, r4, #0
0x00425e:	lsls    	r0, r0, #9
0x004260:	bl      	#0x3838
0x004264:	ldr     	r3, [r0, #8]
0x004266:	movs    	r2, #0
0x004268:	str     	r2, [sp, #8]
0x00426a:	adds    	r2, r5, #0
0x00426c:	movs    	r0, #0xf1
0x00426e:	movs    	r1, #0x52
0x004270:	lsls    	r0, r0, #9
0x004272:	str     	r7, [sp]
0x004274:	str     	r6, [sp, #4]
0x004276:	bl      	#0x3838
0x00427a:	movs    	r1, #0
0x00427c:	movs    	r2, #0
0x00427e:	str     	r1, [sp]
0x004280:	str     	r1, [sp, #4]
0x004282:	movs    	r1, #0x19
0x004284:	str     	r2, [sp, #8]
0x004286:	adds    	r3, r4, #0
0x004288:	movs    	r0, #0xf1
0x00428a:	lsls    	r0, r0, #9
0x00428c:	ldr     	r2, [sp, #0xc]
0x00428e:	bl      	#0x3838
0x004292:	movs    	r1, #0
0x004294:	movs    	r2, #0
0x004296:	str     	r1, [sp]
0x004298:	str     	r1, [sp, #4]
0x00429a:	movs    	r1, #0x19
0x00429c:	str     	r2, [sp, #8]
0x00429e:	adds    	r3, r4, #0
0x0042a0:	movs    	r0, #0xf1
0x0042a2:	lsls    	r0, r0, #9
0x0042a4:	ldr     	r2, [sp, #0x10]
0x0042a6:	bl      	#0x3838
0x0042aa:	movs    	r1, #0
0x0042ac:	movs    	r2, #0
0x0042ae:	str     	r2, [sp, #8]
0x0042b0:	str     	r1, [sp]
0x0042b2:	str     	r1, [sp, #4]
0x0042b4:	movs    	r1, #0x1b
0x0042b6:	movs    	r2, #1
0x0042b8:	adds    	r3, r4, #0
0x0042ba:	movs    	r0, #0xf1
0x0042bc:	lsls    	r0, r0, #9
0x0042be:	bl      	#0x3838
0x0042c2:	add     	sp, #0x14
0x0042c4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0042c8 =====
0x0042c8:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x0042ca:	movs    	r6, #0xf1
0x0042cc:	ldr     	r3, [r0, #0x10]
0x0042ce:	lsls    	r6, r6, #9
0x0042d0:	adds    	r7, r2, #0
0x0042d2:	movs    	r5, #0
0x0042d4:	adds    	r4, r0, #0
0x0042d6:	cmp     	r3, #0
0x0042d8:	sub     	sp, #0x10
0x0042da:	beq     	#0x42f2
0x0042dc:	movs    	r2, #0
0x0042de:	movs    	r1, #0
0x0042e0:	str     	r2, [sp, #8]
0x0042e2:	adds    	r2, r3, #0
0x0042e4:	str     	r1, [sp]
0x0042e6:	str     	r1, [sp, #4]
0x0042e8:	movs    	r1, #0x12
0x0042ea:	adds    	r3, r5, #0
0x0042ec:	adds    	r0, r6, #0
0x0042ee:	bl      	#0x3838
0x0042f2:	adds    	r1, r7, #0
0x0042f4:	ldr     	r7, [pc, #0x98]
0x0042f6:	ldr     	r0, [sp, #0x14]
0x0042f8:	add     	r7, sb
0x0042fa:	str     	r0, [r4, #0x10]
0x0042fc:	bne     	#0x4374
0x0042fe:	ldr     	r1, [r7, #0x14]
0x004300:	movs    	r2, #0
0x004302:	lsls    	r1, r1, #2
0x004304:	ldr     	r0, [r0, r1]
0x004306:	movs    	r1, #0
0x004308:	ldr     	r4, [r0]
0x00430a:	str     	r1, [sp]
0x00430c:	str     	r1, [sp, #4]
0x00430e:	str     	r2, [sp, #8]
0x004310:	movs    	r2, #0x53
0x004312:	movs    	r1, #0xe1
0x004314:	adds    	r3, r5, #0
0x004316:	adds    	r0, r6, #0
0x004318:	bl      	#0x3838
0x00431c:	lsls    	r4, r4, #2
0x00431e:	ldr     	r0, [r0, r4]
0x004320:	ldr     	r0, [r0, #0x18]
0x004322:	cmp     	r0, #0
0x004324:	beq     	#0x4374
0x004326:	movs    	r1, #0
0x004328:	movs    	r2, #0
0x00432a:	str     	r2, [sp, #8]
0x00432c:	str     	r1, [sp]
0x00432e:	str     	r1, [sp, #4]
0x004330:	movs    	r1, #0xe1
0x004332:	movs    	r2, #0x53
0x004334:	adds    	r3, r5, #0
0x004336:	adds    	r0, r6, #0
0x004338:	bl      	#0x3838
0x00433c:	ldr     	r0, [r0, r4]
0x00433e:	movs    	r1, #0
0x004340:	ldr     	r3, [r0, #0x18]
0x004342:	movs    	r2, #0
0x004344:	str     	r2, [sp, #8]
0x004346:	str     	r1, [sp]
0x004348:	str     	r1, [sp, #4]
0x00434a:	movs    	r0, #0xf1
0x00434c:	lsls    	r0, r0, #9
0x00434e:	movs    	r1, #9
0x004350:	adds    	r2, r3, #0
0x004352:	adds    	r3, r5, #0
0x004354:	bl      	#0x3838
0x004358:	movs    	r1, #0
0x00435a:	movs    	r2, #0
0x00435c:	str     	r2, [sp, #8]
0x00435e:	str     	r1, [sp]
0x004360:	str     	r1, [sp, #4]
0x004362:	movs    	r1, #0xe1
0x004364:	movs    	r2, #0x53
0x004366:	adds    	r3, r5, #0
0x004368:	movs    	r0, #0xf1
0x00436a:	lsls    	r0, r0, #9
0x00436c:	bl      	#0x3838
0x004370:	ldr     	r0, [r0, r4]
0x004372:	str     	r5, [r0, #0x18]
0x004374:	str     	r5, [r7, #0x14]
0x004376:	movs    	r1, #0
0x004378:	str     	r1, [sp]
0x00437a:	str     	r1, [sp, #4]
0x00437c:	movs    	r2, #0
0x00437e:	movs    	r1, #0xe6
0x004380:	adds    	r3, r5, #0
0x004382:	adds    	r0, r6, #0
0x004384:	str     	r2, [sp, #8]
0x004386:	bl      	#0x3838
0x00438a:	add     	sp, #0x1c
0x00438c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_004394 =====
0x004394:	push    	{r4, r5, r6, lr}
0x004396:	sub     	sp, #0x10
0x004398:	movs    	r1, #0
0x00439a:	movs    	r2, #0
0x00439c:	str     	r2, [sp, #8]
0x00439e:	str     	r1, [sp]
0x0043a0:	str     	r1, [sp, #4]
0x0043a2:	movs    	r5, #0
0x0043a4:	adds    	r3, r5, #0
0x0043a6:	movs    	r1, #0xe1
0x0043a8:	movs    	r2, #0x27
0x0043aa:	movs    	r0, #0xf1
0x0043ac:	lsls    	r0, r0, #9
0x0043ae:	bl      	#0x3838
0x0043b2:	asrs    	r1, r0, #0x1f
0x0043b4:	lsrs    	r1, r1, #0x1e
0x0043b6:	adds    	r0, r1, r0
0x0043b8:	movs    	r1, #0
0x0043ba:	str     	r1, [sp]
0x0043bc:	str     	r1, [sp, #4]
0x0043be:	movs    	r2, #0
0x0043c0:	ldr     	r6, [pc, #0x24]
0x0043c2:	asrs    	r4, r0, #2
0x0043c4:	movs    	r0, #0xf1
0x0043c6:	str     	r2, [sp, #8]
0x0043c8:	movs    	r1, #0x38
0x0043ca:	adds    	r3, r5, #0
0x0043cc:	add     	r6, sb
0x0043ce:	ldr     	r2, [r6, #8]
0x0043d0:	lsls    	r0, r0, #9
0x0043d2:	bl      	#0x3838
0x0043d6:	adds    	r1, r4, #0
0x0043d8:	blx     	#0x30
0x0043dc:	ldr     	r0, [r6, #0x28]
0x0043de:	adds    	r0, #0x40
0x0043e0:	strh    	r1, [r0, #0xa]
0x0043e2:	add     	sp, #0x10
0x0043e4:	pop     	{r4, r5, r6, pc}

; ===== candidate_004426 =====
0x004426:	push    	{r1, r4, r6, r7, lr}
0x004428:	movs    	r0, r0
0x00442a:	movs    	r0, r0
0x00442c:	bkpt    	#0xa1
0x00442e:	sub     	sp, #0x148

; ===== candidate_00444e =====
0x00444e:	push    	{r4, r6, r7}
0x004450:	cbnz    	r3, #0x44c6
0x004452:	pop     	{r1, r3, r4, r5, r6, r7}
0x004454:	lsls    	r7, r2, #3
0x004456:	movs    	r0, r0
0x004458:	pop     	{r2, r4, r6, r7}
0x00445a:	beq     	#0x4404
0x00445c:	movs    	r0, r4
0x00445e:	movs    	r0, r0

; ===== candidate_004488 =====
0x004488:	push    	{r0, r1, r4, r6, r7, lr}
0x00448a:	beq     	#0x4434
0x00448c:	push    	{r1, r4, r5}
0x00448e:	pop     	{r1, r2, r3, r6, r7, pc}
0x004490:	cbnz    	r0, #0x4512
0x004492:	stm     	r4!, {r0, r1, r2, r3, r5, r7}
0x004494:	stm     	r1!, {r2, r3, r4, r6, r7}
0x004496:	lsls    	r6, r4, #2

; ===== candidate_00448c =====
0x00448c:	push    	{r1, r4, r5}
0x00448e:	pop     	{r1, r2, r3, r6, r7, pc}
0x004490:	cbnz    	r0, #0x4512
0x004492:	stm     	r4!, {r0, r1, r2, r3, r5, r7}
0x004494:	stm     	r1!, {r2, r3, r4, r6, r7}
0x004496:	lsls    	r6, r4, #2

; ===== candidate_0044ee =====
0x0044ee:	push    	{r0, r1, r2, r3, r4, r5, r7}
0x0044f0:	pkhbt   	r8, pc, pc, lsl #0xf
0x0044f4:	movs    	r0, r0
0x0044f6:	movs    	r0, r0
0x0044f8:	cbnz    	r2, #0x4570
0x0044fa:	cdp2    	p13, #0xb, c15, c6, c8, #6
0x0044fe:	stm     	r4!, {r0, r1, r3, r6, r7}
0x004500:	b       	#0x40a0
0x004502:	movs    	r0, r0

; ===== candidate_004514 =====
0x004514:	push    	{r1, r2, r3, r6, r7}
0x004516:	add     	r2, sp, #0x358

; ===== candidate_004540 =====
0x004540:	push    	{r1, r2, r3, r6, r7}
0x004542:	add     	r2, sp, #0x358
0x004544:	movs    	r0, r0
0x004546:	movs    	r0, r0
0x004548:	bl      	#0xff2d8cc4
0x00454c:	movs    	r0, r0
0x00454e:	movs    	r0, r0
0x004550:	strh    	r5, [r1, r1]
0x004552:	bx      	sl
0x004554:	movs    	r4, r0
0x004556:	movs    	r0, r0
0x004558:	movs    	r0, r0
0x00455a:	movs    	r0, r0
0x00455c:	movs    	r4, r0
0x00455e:	movs    	r0, r0
0x004560:	str     	r1, [r4, #0x24]
0x004562:	lsls    	r3, r4, #1
0x004564:	movs    	r0, r0
0x004566:	movs    	r0, r0
0x004568:	str     	r6, [r2, #0x14]
0x00456a:	subs    	r2, #0x6c
0x00456c:	ldrb    	r0, [r6]
0x00456e:	ldrb    	r5, [r4]
0x004570:	movs    	r0, r0
0x004572:	movs    	r0, r0
0x004574:	ldr     	r4, [r6, #0x14]
0x004576:	str     	r5, [r5, #0x54]
0x004578:	movs    	r0, #0x72
0x00457a:	strb    	r5, [r4, #9]
0x00457c:	subs    	r2, #0x72
0x00457e:	str     	r5, [r4, #0x40]
0x004580:	movs    	r0, r0
0x004582:	movs    	r0, r0
0x004584:	str     	r4, [r4, #0x54]
0x004586:	ldr     	r1, [r4, #0x44]
0x004588:	ldr     	r4, [r6, #0x14]
0x00458a:	str     	r5, [r5, #0x54]
0x00458c:	lsls    	r2, r6, #1
0x00458e:	movs    	r0, r0
0x004590:	ldr     	r4, [r6, #0x14]
0x004592:	str     	r5, [r5, #0x54]
0x004594:	muls    	r2, r6, r2
0x004596:	str     	r2, [r6, #0x54]
0x004598:	strb    	r1, [r4, #0x11]
0x00459a:	movs    	r0, #0x65
0x00459c:	strb    	r5, [r4, #9]
0x00459e:	movs    	r0, #0x72
0x0045a0:	adds    	r1, #0x30
0x0045a2:	movs    	r0, r0
0x0045a4:	ldrb    	r5, [r4, #1]
0x0045a6:	movs    	r0, #0x74
0x0045a8:	strb    	r5, [r4, #9]
0x0045aa:	subs    	r2, #0x72
0x0045ac:	str     	r5, [r4, #0x40]
0x0045ae:	movs    	r0, r0
0x0045b0:	strb    	r5, [r5, #9]
0x0045b2:	ldrsh   	r3, [r4, r5]
0x0045b4:	ldrb    	r5, [r4, #1]
0x0045b6:	ldr     	r5, [pc, #0x1d0]
0x0045b8:	strb    	r0, [r6, #0xd]
0x0045ba:	strb    	r6, [r0, #1]
0x0045bc:	str     	r3, [r0, #0x14]
0x0045be:	ldr     	r4, [r5, #0x44]
0x0045c0:	str     	r2, [r7, #0x50]
0x0045c2:	strb    	r2, [r6, #9]
0x0045c4:	movs    	r0, r0
0x0045c6:	movs    	r0, r0
0x0045c8:	adds    	r2, #0x63
0x0045ca:	subs    	r2, #0x75
0x0045cc:	strb    	r5, [r4, #9]
0x0045ce:	movs    	r0, #0x72
0x0045d0:	movs    	r0, #0x20
0x0045d2:	movs    	r1, r6
0x0045d4:	adds    	r2, #0x63
0x0045d6:	subs    	r2, #0x75
0x0045d8:	strb    	r5, [r4, #9]
0x0045da:	movs    	r0, #0x72
0x0045dc:	movs    	r0, #0x20
0x0045de:	movs    	r2, r6
0x0045e0:	str     	r2, [r6, #0x54]
0x0045e2:	strb    	r3, [r6, #0x11]
0x0045e4:	strb    	r1, [r4, #9]
0x0045e6:	lsls    	r4, r6, #1
0x0045e8:	strb    	r5, [r4, #9]
0x0045ea:	subs    	r2, #0x72
0x0045ec:	str     	r5, [r4, #0x40]
0x0045ee:	movs    	r0, r0
0x0045f0:	str     	r2, [r6, #0x54]
0x0045f2:	str     	r1, [r4, #0x44]
0x0045f4:	movs    	r2, #0x20
0x0045f6:	strb    	r5, [r4, #0xc]
0x0045f8:	movs    	r0, #0x22
0x0045fa:	strb    	r6, [r4, #9]
0x0045fc:	ldr     	r7, [r5, #0x54]
0x0045fe:	ldr     	r0, [r4, #0x50]
0x004600:	strb    	r2, [r6, #1]
0x004602:	str     	r0, [r4, #0x50]
0x004604:	strb    	r2, [r6, #9]
0x004606:	str     	r4, [r5, #0x30]
0x004608:	str     	r7, [r5, #0x44]
0x00460a:	subs    	r5, #0x65
0x00460c:	str     	r5, [r4, #0x40]
0x00460e:	movs    	r0, r0
0x004610:	strb    	r3, [r4, #9]
0x004612:	movs    	r0, #0x63
0x004614:	strb    	r5, [r4, #9]
0x004616:	movs    	r1, #0x72
0x004618:	movs    	r0, r0
0x00461a:	movs    	r0, r0
0x00461c:	str     	r4, [r5, #0x54]
0x00461e:	str     	r6, [r5, #0x74]
0x004620:	ldr     	r4, [r6, #4]
0x004622:	str     	r0, [r4, #0x50]
0x004624:	strb    	r2, [r6, #9]
0x004626:	movs    	r1, r4
0x004628:	ldrh    	r7, [r3, #0x18]
0x00462a:	movs    	r0, r0
0x00462c:	ldr     	r6, [sp, #0x7c]
0x00462e:	movs    	r0, r0
0x004630:	movs    	r4, r4
0x004632:	movs    	r0, r0
0x004634:	str     	r1, [r4, #0x24]
0x004636:	lsls    	r3, r4, #1
0x004638:	ldr     	r4, [r2, #0x14]
0x00463a:	str     	r5, [r5, #0x54]
0x00463c:	strh    	r2, [r6, r5]
0x00463e:	str     	r4, [r6, #0x14]
0x004640:	str     	r4, [r6, #0x54]
0x004642:	subs    	r5, #0x20
0x004644:	movs    	r5, #0x20
0x004646:	lsls    	r4, r4, #1
0x004648:	rsbs    	r3, r0, #0
0x00464a:	strb    	r0, [r4, #0x1c]
0x00464c:	str     	r0, [r5, #0x54]
0x00464e:	movs    	r0, #0x6e
0x004650:	str     	r0, [r6, #0x14]
0x004652:	strb    	r5, [r6, #0xd]
0x004654:	movs    	r1, #0x65
0x004656:	movs    	r0, r0
0x004658:	str     	r3, [r4, #0x14]
0x00465a:	ldr     	r3, [r4, #4]
