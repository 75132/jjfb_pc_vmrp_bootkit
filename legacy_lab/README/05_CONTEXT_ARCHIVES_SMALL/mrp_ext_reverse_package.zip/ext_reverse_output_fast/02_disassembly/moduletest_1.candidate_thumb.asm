; fallback candidate disassembly from Thumb prologues; true code is ARM entry + Thumb functions.

; ARM entry
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0x2950
0x000018:	pop     	{r4, pc}
0x00001c:	ldr     	r0, [pc, #8]
0x000020:	ldr     	r1, [pc, #8]
0x000024:	add     	r0, r0, r1
0x000028:	bx      	lr
0x00002c:	andeq   	r0, r0, r4
0x000030:	andeq   	r0, r0, r0, ror #2
0x000034:	mov     	sb, r0
0x000038:	bx      	lr
0x00003c:	stcmi   	p5, c11, [sp], #-0xc0
0x000040:	ldrbtmi 	r2, [ip], #-0x21c
0x000044:	smlatbhs	r0, r0, fp, r6
0x000048:	stmdami 	fp!, {r0, r1, r7, r8, sb, fp, sp, lr}
0x00004c:	strbmi  	fp, [r8], #-0x83
0x000050:	andhs   	r4, r0, #152, #14
0x000054:	andls   	r2, r0, r0
0x000058:	movwhs  	r4, #0x927

; ===== candidate_000008 =====
0x000008:	ands    	r0, r2
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	lsrs    	r5, r1, #9

; ===== candidate_00000a =====
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	lsrs    	r5, r1, #9

; ===== candidate_00003c =====
0x00003c:	push    	{r4, r5, lr}
0x00003e:	ldr     	r4, [pc, #0xb4]
0x000040:	movs    	r2, #0x1c
0x000042:	add     	r4, pc
0x000044:	ldr     	r0, [r4, #0x38]
0x000046:	movs    	r1, #0
0x000048:	ldr     	r3, [r0, #0x38]
0x00004a:	ldr     	r0, [pc, #0xac]
0x00004c:	sub     	sp, #0xc
0x00004e:	add     	r0, sb
0x000050:	blx     	r3
0x000052:	movs    	r2, #0
0x000054:	movs    	r0, #0
0x000056:	str     	r0, [sp]
0x000058:	ldr     	r1, [pc, #0x9c]
0x00005a:	movs    	r3, #0
0x00005c:	add     	r1, sb
0x00005e:	str     	r1, [sp, #4]
0x000060:	movs    	r1, #0x64
0x000062:	movs    	r0, #1
0x000064:	str     	r2, [sp, #8]
0x000066:	bl      	#0x29e0
0x00006a:	ldr     	r1, [pc, #0x8c]
0x00006c:	movs    	r0, #0
0x00006e:	add     	r1, sb
0x000070:	subs    	r1, #0x7c
0x000072:	str     	r0, [r1, #8]
0x000074:	ldr     	r5, [pc, #0x80]
0x000076:	str     	r0, [r1, #0x10]
0x000078:	str     	r0, [r1, #0xc]
0x00007a:	add     	r5, sb
0x00007c:	subs    	r5, #0xfc
0x00007e:	movs    	r0, #1
0x000080:	str     	r0, [r5, #0x18]
0x000082:	ldr     	r0, [r4, #0x38]
0x000084:	ldr     	r2, [pc, #0x74]
0x000086:	ldr     	r1, [r0, #0x68]
0x000088:	add     	r2, sb
0x00008a:	str     	r1, [r5, #0x2c]
0x00008c:	ldr     	r1, [r0, #0xc]
0x00008e:	ldr     	r4, [pc, #0x70]
0x000090:	str     	r1, [r5, #0x30]
0x000092:	ldr     	r1, [r0, #0x10]
0x000094:	str     	r1, [r5, #0x34]
0x000096:	ldr     	r1, [r0, #0x14]
0x000098:	str     	r1, [r5, #0x38]
0x00009a:	ldr     	r1, [r0, #0x18]
0x00009c:	str     	r1, [r5, #0x3c]
0x00009e:	ldr     	r1, [r0, #0x1c]
0x0000a0:	str     	r1, [r5, #0x40]
0x0000a2:	ldr     	r1, [r0, #0x20]
0x0000a4:	str     	r1, [r5, #0x44]
0x0000a6:	ldr     	r1, [r0, #0x24]
0x0000a8:	str     	r1, [r5, #0x48]
0x0000aa:	ldr     	r1, [r0, #0x28]
0x0000ac:	str     	r1, [r5, #0x4c]
0x0000ae:	ldr     	r1, [r0, #0x2c]
0x0000b0:	str     	r1, [r5, #0x50]
0x0000b2:	ldr     	r1, [r0, #0x30]
0x0000b4:	str     	r1, [r5, #0x54]
0x0000b6:	ldr     	r1, [r0, #0x34]
0x0000b8:	str     	r1, [r5, #0x58]
0x0000ba:	ldr     	r1, [r0, #0x38]
0x0000bc:	str     	r1, [r5, #0x5c]
0x0000be:	ldr     	r1, [r0, #0x3c]
0x0000c0:	str     	r1, [r5, #0x60]
0x0000c2:	ldr     	r1, [r0, #0x40]
0x0000c4:	str     	r1, [r5, #0x64]
0x0000c6:	ldr     	r1, [r0, #0x44]
0x0000c8:	str     	r1, [r5, #0x68]
0x0000ca:	ldr     	r1, [r0, #0x48]
0x0000cc:	str     	r1, [r5, #0x6c]
0x0000ce:	ldr     	r1, [r0, #0x4c]
0x0000d0:	str     	r1, [r5, #0x70]
0x0000d2:	movs    	r1, #0
0x0000d4:	str     	r1, [r2]
0x0000d6:	movs    	r1, #1
0x0000d8:	lsls    	r1, r1, #9
0x0000da:	adds    	r0, r0, r1
0x0000dc:	ldr     	r3, [r0, #8]
0x0000de:	movs    	r1, #7
0x0000e0:	adds    	r2, r4, #0
0x0000e2:	movs    	r0, #0
0x0000e4:	blx     	r3
0x0000e6:	cmp     	r0, r4
0x0000e8:	bne     	#0xee
0x0000ea:	subs    	r0, #2
0x0000ec:	str     	r0, [r5, #0x28]
0x0000ee:	add     	sp, #0xc
0x0000f0:	pop     	{r4, r5, pc}

; ===== candidate_000104 =====
0x000104:	push    	{r4, r5, r6, r7, lr}
0x000106:	movs    	r2, #0
0x000108:	sub     	sp, #0x74
0x00010a:	movs    	r4, #0
0x00010c:	mvns    	r1, r2
0x00010e:	ldr     	r3, [pc, #0x3e4]
0x000110:	str     	r1, [sp]
0x000112:	str     	r1, [sp, #4]
0x000114:	str     	r2, [sp, #8]
0x000116:	add     	r3, pc
0x000118:	adds    	r2, r4, #0
0x00011a:	movs    	r1, #5
0x00011c:	movs    	r0, #0xf1
0x00011e:	lsls    	r0, r0, #9
0x000120:	bl      	#0x29e0
0x000124:	str     	r0, [sp, #0x64]
0x000126:	ldr     	r4, [r0, #4]
0x000128:	movs    	r0, #0
0x00012a:	str     	r0, [sp, #0x70]
0x00012c:	str     	r0, [sp, #0x6c]
0x00012e:	ldr     	r0, [pc, #0x3c8]
0x000130:	movs    	r7, #0
0x000132:	add     	r0, pc
0x000134:	str     	r0, [sp, #0x4c]
0x000136:	subs    	r0, #4
0x000138:	str     	r0, [sp, #0x50]
0x00013a:	subs    	r0, #4
0x00013c:	str     	r0, [sp, #0x54]
0x00013e:	add     	r0, sp, #0x70
0x000140:	str     	r0, [sp, #0x5c]
0x000142:	add     	r0, sp, #0x6c
0x000144:	str     	r0, [sp, #0x60]
0x000146:	movs    	r1, #0
0x000148:	movs    	r2, #0
0x00014a:	str     	r4, [sp, #0x48]
0x00014c:	str     	r2, [sp, #8]
0x00014e:	str     	r1, [sp]
0x000150:	str     	r1, [sp, #4]
0x000152:	adds    	r3, r7, #0
0x000154:	add     	r5, sp, #0x48
0x000156:	adds    	r2, r5, #0
0x000158:	movs    	r1, #7
0x00015a:	movs    	r0, #0xf1
0x00015c:	lsls    	r0, r0, #9
0x00015e:	str     	r7, [sp, #0x58]
0x000160:	bl      	#0x29e0
0x000164:	movs    	r2, #0
0x000166:	movs    	r1, #0
0x000168:	str     	r2, [sp, #8]
0x00016a:	adds    	r6, r0, #0
0x00016c:	adds    	r3, r7, #0
0x00016e:	adds    	r2, r0, #0
0x000170:	str     	r1, [sp]
0x000172:	str     	r1, [sp, #4]
0x000174:	movs    	r1, #8
0x000176:	movs    	r0, #0xf1
0x000178:	lsls    	r0, r0, #9
0x00017a:	bl      	#0x29e0
0x00017e:	str     	r0, [sp, #0x68]
0x000180:	movs    	r1, #0
0x000182:	movs    	r2, #0
0x000184:	str     	r2, [sp, #8]
0x000186:	str     	r1, [sp]
0x000188:	str     	r1, [sp, #4]
0x00018a:	adds    	r3, r7, #0
0x00018c:	adds    	r2, r6, #0
0x00018e:	movs    	r1, #9
0x000190:	movs    	r0, #0xf1
0x000192:	lsls    	r0, r0, #9
0x000194:	bl      	#0x29e0
0x000198:	movs    	r1, #0
0x00019a:	movs    	r2, #0
0x00019c:	str     	r1, [sp]
0x00019e:	str     	r1, [sp, #4]
0x0001a0:	movs    	r1, #0xa
0x0001a2:	str     	r2, [sp, #8]
0x0001a4:	movs    	r3, #4
0x0001a6:	movs    	r0, #0xf1
0x0001a8:	lsls    	r0, r0, #9
0x0001aa:	ldr     	r2, [sp, #0x68]
0x0001ac:	bl      	#0x29e0
0x0001b0:	str     	r0, [sp, #0x44]
0x0001b2:	ldr     	r0, [sp, #0x68]
0x0001b4:	movs    	r6, #0
0x0001b6:	cmp     	r0, #0
0x0001b8:	ble     	#0x29e
0x0001ba:	movs    	r5, #0
0x0001bc:	movs    	r2, #0
0x0001be:	ldr     	r0, [sp, #0x6c]
0x0001c0:	movs    	r1, #0
0x0001c2:	ldr     	r3, [pc, #0x338]
0x0001c4:	str     	r1, [sp, #4]
0x0001c6:	str     	r2, [sp, #8]
0x0001c8:	str     	r0, [sp]
0x0001ca:	add     	r3, pc
0x0001cc:	adds    	r2, r4, #0
0x0001ce:	movs    	r1, #0xb
0x0001d0:	movs    	r0, #0xf1
0x0001d2:	lsls    	r0, r0, #9
0x0001d4:	bl      	#0x29e0
0x0001d8:	str     	r0, [sp, #0x70]
0x0001da:	ldr     	r1, [pc, #0x324]
0x0001dc:	str     	r0, [sp, #0x58]
0x0001de:	add     	r1, pc
0x0001e0:	str     	r1, [sp, #0x4c]
0x0001e2:	subs    	r1, #0x4c
0x0001e4:	str     	r1, [sp, #0x50]
0x0001e6:	adds    	r1, #0x40
0x0001e8:	add     	r0, sp, #0x70
0x0001ea:	str     	r0, [sp, #0x5c]
0x0001ec:	add     	r0, sp, #0x6c
0x0001ee:	str     	r1, [sp, #0x54]
0x0001f0:	movs    	r1, #0
0x0001f2:	str     	r0, [sp, #0x60]
0x0001f4:	str     	r4, [sp, #0x48]
0x0001f6:	movs    	r2, #0
0x0001f8:	str     	r2, [sp, #8]
0x0001fa:	str     	r1, [sp]
0x0001fc:	str     	r1, [sp, #4]
0x0001fe:	adds    	r3, r5, #0
0x000200:	add     	r7, sp, #0x48
0x000202:	adds    	r2, r7, #0
0x000204:	movs    	r1, #7
0x000206:	movs    	r0, #0xf1
0x000208:	lsls    	r0, r0, #9
0x00020a:	bl      	#0x29e0
0x00020e:	str     	r0, [sp, #0x40]
0x000210:	movs    	r2, #0
0x000212:	movs    	r1, #0
0x000214:	str     	r2, [sp, #8]
0x000216:	adds    	r3, r5, #0
0x000218:	adds    	r2, r0, #0
0x00021a:	str     	r1, [sp]
0x00021c:	str     	r1, [sp, #4]
0x00021e:	movs    	r1, #8
0x000220:	movs    	r0, #0xf1
0x000222:	lsls    	r0, r0, #9
0x000224:	bl      	#0x29e0
0x000228:	movs    	r1, #0
0x00022a:	str     	r1, [sp]
0x00022c:	movs    	r2, #0

; ===== candidate_000848 =====
0x000848:	push    	{r0, r4, r5, r6, r7, lr}
0x00084a:	sub     	sp, #0x50
0x00084c:	ldr     	r0, [sp, #0x50]
0x00084e:	movs    	r4, #0
0x000850:	movs    	r3, #0
0x000852:	cmp     	r0, #1
0x000854:	beq     	#0x920
0x000856:	cmp     	r0, #2
0x000858:	beq     	#0x914
0x00085a:	cmp     	r0, #3
0x00085c:	beq     	#0x91a
0x00085e:	cmp     	r0, #4
0x000860:	bne     	#0x866
0x000862:	ldr     	r3, [pc, #0x3a0]
0x000864:	add     	r3, pc
0x000866:	movs    	r2, #0
0x000868:	mvns    	r1, r2
0x00086a:	str     	r1, [sp]
0x00086c:	str     	r1, [sp, #4]
0x00086e:	str     	r2, [sp, #8]
0x000870:	adds    	r2, r4, #0
0x000872:	movs    	r1, #5
0x000874:	movs    	r0, #0xf1
0x000876:	lsls    	r0, r0, #9
0x000878:	bl      	#0x29e0
0x00087c:	str     	r0, [sp, #0x3c]
0x00087e:	ldr     	r4, [r0, #4]
0x000880:	movs    	r0, #0
0x000882:	str     	r0, [sp, #0x4c]
0x000884:	str     	r0, [sp, #0x48]
0x000886:	ldr     	r0, [pc, #0x380]
0x000888:	movs    	r7, #0
0x00088a:	add     	r0, pc
0x00088c:	str     	r0, [sp, #0x24]
0x00088e:	subs    	r0, #4
0x000890:	str     	r0, [sp, #0x28]
0x000892:	subs    	r0, #4
0x000894:	str     	r0, [sp, #0x2c]
0x000896:	add     	r0, sp, #0x4c
0x000898:	str     	r0, [sp, #0x34]
0x00089a:	movs    	r1, #0
0x00089c:	add     	r0, sp, #0x48
0x00089e:	movs    	r2, #0
0x0008a0:	str     	r4, [sp, #0x20]
0x0008a2:	str     	r1, [sp]
0x0008a4:	str     	r2, [sp, #8]
0x0008a6:	str     	r0, [sp, #0x38]
0x0008a8:	str     	r1, [sp, #4]
0x0008aa:	adds    	r3, r7, #0
0x0008ac:	add     	r6, sp, #0x20
0x0008ae:	adds    	r2, r6, #0
0x0008b0:	movs    	r1, #7
0x0008b2:	movs    	r0, #0xf1
0x0008b4:	lsls    	r0, r0, #9
0x0008b6:	str     	r7, [sp, #0x30]
0x0008b8:	bl      	#0x29e0
0x0008bc:	movs    	r2, #0
0x0008be:	movs    	r1, #0
0x0008c0:	str     	r2, [sp, #8]
0x0008c2:	adds    	r5, r0, #0
0x0008c4:	adds    	r3, r7, #0
0x0008c6:	adds    	r2, r0, #0
0x0008c8:	str     	r1, [sp]
0x0008ca:	str     	r1, [sp, #4]
0x0008cc:	movs    	r1, #8
0x0008ce:	movs    	r0, #0xf1
0x0008d0:	lsls    	r0, r0, #9
0x0008d2:	bl      	#0x29e0
0x0008d6:	str     	r0, [sp, #0x40]
0x0008d8:	movs    	r1, #0
0x0008da:	movs    	r2, #0
0x0008dc:	str     	r2, [sp, #8]
0x0008de:	str     	r1, [sp]
0x0008e0:	str     	r1, [sp, #4]
0x0008e2:	adds    	r3, r7, #0
0x0008e4:	adds    	r2, r5, #0
0x0008e6:	movs    	r1, #9
0x0008e8:	movs    	r0, #0xf1
0x0008ea:	lsls    	r0, r0, #9
0x0008ec:	bl      	#0x29e0
0x0008f0:	movs    	r1, #0
0x0008f2:	str     	r1, [sp]
0x0008f4:	movs    	r2, #0
0x0008f6:	str     	r1, [sp, #4]
0x0008f8:	movs    	r1, #0xa
0x0008fa:	str     	r2, [sp, #8]
0x0008fc:	movs    	r3, #4
0x0008fe:	movs    	r0, #0xf1
0x000900:	lsls    	r0, r0, #9
0x000902:	ldr     	r2, [sp, #0x40]
0x000904:	bl      	#0x29e0
0x000908:	adds    	r5, r0, #0
0x00090a:	ldr     	r0, [sp, #0x40]
0x00090c:	cmp     	r0, #0
0x00090e:	ble     	#0x9f6
0x000910:	movs    	r6, #0
0x000912:	b       	#0x928
0x000914:	ldr     	r3, [pc, #0x2f4]
0x000916:	add     	r3, pc
0x000918:	b       	#0x866
0x00091a:	ldr     	r3, [pc, #0x2f4]
0x00091c:	add     	r3, pc
0x00091e:	b       	#0x866
0x000920:	b       	#0x922
0x000922:	ldr     	r3, [pc, #0x2f0]
0x000924:	add     	r3, pc
0x000926:	b       	#0x866
0x000928:	ldr     	r0, [sp, #0x50]
0x00092a:	cmp     	r0, #1
0x00092c:	beq     	#0x9f8
0x00092e:	cmp     	r0, #2
0x000930:	beq     	#0xa16
0x000932:	cmp     	r0, #3
0x000934:	beq     	#0xa18
0x000936:	cmp     	r0, #4
0x000938:	bne     	#0x958
0x00093a:	movs    	r2, #0
0x00093c:	ldr     	r0, [sp, #0x4c]
0x00093e:	movs    	r1, #0
0x000940:	ldr     	r3, [pc, #0x2d4]
0x000942:	str     	r1, [sp, #4]
0x000944:	str     	r2, [sp, #8]
0x000946:	str     	r0, [sp]
0x000948:	add     	r3, pc
0x00094a:	adds    	r2, r4, #0
0x00094c:	movs    	r1, #0xb
0x00094e:	movs    	r0, #0xf1
0x000950:	lsls    	r0, r0, #9
0x000952:	bl      	#0x29e0
0x000956:	str     	r0, [sp, #0x4c]
0x000958:	ldr     	r0, [pc, #0x2c0]
0x00095a:	movs    	r1, #0
0x00095c:	add     	r0, pc
0x00095e:	str     	r0, [sp, #0x24]
0x000960:	subs    	r0, #0x4c
0x000962:	str     	r0, [sp, #0x28]
0x000964:	adds    	r0, #0x40
0x000966:	str     	r0, [sp, #0x2c]
0x000968:	ldr     	r0, [sp, #0x4c]
0x00096a:	str     	r4, [sp, #0x20]
0x00096c:	str     	r0, [sp, #0x30]

; ===== candidate_000c38 =====
0x000c38:	push    	{r4, r5, r6, r7, lr}
0x000c3a:	movs    	r2, #0
0x000c3c:	sub     	sp, #0x34
0x000c3e:	movs    	r4, #0
0x000c40:	mvns    	r1, r2
0x000c42:	ldr     	r3, [pc, #0x11c]
0x000c44:	str     	r1, [sp]
0x000c46:	str     	r1, [sp, #4]
0x000c48:	str     	r2, [sp, #8]
0x000c4a:	add     	r3, pc
0x000c4c:	adds    	r2, r4, #0
0x000c4e:	movs    	r1, #5
0x000c50:	movs    	r0, #0xf1
0x000c52:	lsls    	r0, r0, #9
0x000c54:	bl      	#0x29e0
0x000c58:	str     	r0, [sp, #0x28]
0x000c5a:	ldr     	r7, [r0, #4]
0x000c5c:	movs    	r0, #0
0x000c5e:	str     	r0, [sp, #0x30]
0x000c60:	str     	r0, [sp, #0x2c]
0x000c62:	ldr     	r0, [pc, #0x100]
0x000c64:	movs    	r1, #0
0x000c66:	add     	r0, pc
0x000c68:	str     	r0, [sp, #0x10]
0x000c6a:	subs    	r0, #4
0x000c6c:	str     	r0, [sp, #0x14]
0x000c6e:	subs    	r0, #4
0x000c70:	str     	r0, [sp, #0x18]
0x000c72:	add     	r0, sp, #0x30
0x000c74:	str     	r0, [sp, #0x20]
0x000c76:	add     	r0, sp, #0x2c
0x000c78:	str     	r0, [sp, #0x24]
0x000c7a:	movs    	r6, #0
0x000c7c:	movs    	r2, #0
0x000c7e:	str     	r1, [sp, #4]
0x000c80:	str     	r1, [sp]
0x000c82:	movs    	r1, #7
0x000c84:	str     	r2, [sp, #8]
0x000c86:	adds    	r3, r6, #0
0x000c88:	movs    	r0, #0xf1
0x000c8a:	lsls    	r0, r0, #9
0x000c8c:	add     	r2, sp, #0xc
0x000c8e:	str     	r6, [sp, #0x1c]
0x000c90:	str     	r7, [sp, #0xc]
0x000c92:	bl      	#0x29e0
0x000c96:	movs    	r2, #0
0x000c98:	movs    	r1, #0
0x000c9a:	str     	r2, [sp, #8]
0x000c9c:	adds    	r4, r0, #0
0x000c9e:	adds    	r3, r6, #0
0x000ca0:	adds    	r2, r0, #0
0x000ca2:	str     	r1, [sp]
0x000ca4:	str     	r1, [sp, #4]
0x000ca6:	movs    	r1, #8
0x000ca8:	movs    	r0, #0xf1
0x000caa:	lsls    	r0, r0, #9
0x000cac:	bl      	#0x29e0
0x000cb0:	movs    	r1, #0
0x000cb2:	adds    	r5, r0, #0
0x000cb4:	movs    	r2, #0
0x000cb6:	str     	r2, [sp, #8]
0x000cb8:	str     	r1, [sp]
0x000cba:	str     	r1, [sp, #4]
0x000cbc:	adds    	r3, r6, #0
0x000cbe:	adds    	r2, r4, #0
0x000cc0:	movs    	r1, #9
0x000cc2:	movs    	r0, #0xf1
0x000cc4:	lsls    	r0, r0, #9
0x000cc6:	bl      	#0x29e0
0x000cca:	movs    	r1, #0
0x000ccc:	movs    	r2, #0
0x000cce:	str     	r2, [sp, #8]
0x000cd0:	str     	r1, [sp]
0x000cd2:	str     	r1, [sp, #4]
0x000cd4:	movs    	r1, #0xa
0x000cd6:	adds    	r2, r5, #0
0x000cd8:	movs    	r3, #4
0x000cda:	movs    	r0, #0xf1
0x000cdc:	lsls    	r0, r0, #9
0x000cde:	bl      	#0x29e0
0x000ce2:	adds    	r6, r0, #0
0x000ce4:	movs    	r4, #0
0x000ce6:	cmp     	r5, #0
0x000ce8:	ble     	#0xd2a
0x000cea:	ldr     	r0, [pc, #0x7c]
0x000cec:	str     	r7, [sp, #0xc]
0x000cee:	add     	r0, pc
0x000cf0:	str     	r0, [sp, #0x10]
0x000cf2:	ldr     	r0, [pc, #0x78]
0x000cf4:	add     	r0, pc
0x000cf6:	str     	r0, [sp, #0x14]
0x000cf8:	subs    	r0, #4
0x000cfa:	str     	r0, [sp, #0x18]
0x000cfc:	ldr     	r0, [sp, #0x30]
0x000cfe:	movs    	r1, #0
0x000d00:	str     	r0, [sp, #0x1c]
0x000d02:	add     	r0, sp, #0x30
0x000d04:	str     	r0, [sp, #0x20]
0x000d06:	add     	r0, sp, #0x2c
0x000d08:	str     	r0, [sp, #0x24]
0x000d0a:	movs    	r2, #0
0x000d0c:	str     	r1, [sp, #4]
0x000d0e:	str     	r1, [sp]
0x000d10:	movs    	r1, #7
0x000d12:	str     	r2, [sp, #8]
0x000d14:	movs    	r0, #0xf1
0x000d16:	movs    	r3, #0
0x000d18:	lsls    	r0, r0, #9
0x000d1a:	add     	r2, sp, #0xc
0x000d1c:	bl      	#0x29e0
0x000d20:	lsls    	r1, r4, #2
0x000d22:	adds    	r4, #1
0x000d24:	cmp     	r4, r5
0x000d26:	str     	r0, [r6, r1]
0x000d28:	blt     	#0xcea
0x000d2a:	movs    	r1, #0
0x000d2c:	movs    	r2, #0
0x000d2e:	str     	r1, [sp]
0x000d30:	str     	r1, [sp, #4]
0x000d32:	movs    	r1, #6
0x000d34:	str     	r2, [sp, #8]
0x000d36:	movs    	r3, #0
0x000d38:	movs    	r0, #0xf1
0x000d3a:	lsls    	r0, r0, #9
0x000d3c:	ldr     	r2, [sp, #0x28]
0x000d3e:	bl      	#0x29e0
0x000d42:	movs    	r1, #0
0x000d44:	movs    	r2, #0
0x000d46:	str     	r2, [sp, #8]
0x000d48:	str     	r1, [sp]
0x000d4a:	str     	r1, [sp, #4]
0x000d4c:	movs    	r1, #0x14
0x000d4e:	movs    	r2, #2
0x000d50:	adds    	r3, r6, #0
0x000d52:	movs    	r0, #0xf1
0x000d54:	lsls    	r0, r0, #9
0x000d56:	bl      	#0x29e0
0x000d5a:	add     	sp, #0x34
0x000d5c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000d70 =====
0x000d70:	push    	{r4, r5, r6, r7, lr}
0x000d72:	adds    	r5, r0, #0
0x000d74:	sub     	sp, #0xa4
0x000d76:	adds    	r4, r1, #0
0x000d78:	movs    	r1, #0
0x000d7a:	movs    	r0, #0
0x000d7c:	str     	r1, [sp, #0x9c]
0x000d7e:	str     	r1, [sp, #0x94]
0x000d80:	mvns    	r1, r0
0x000d82:	movs    	r2, #0
0x000d84:	str     	r1, [sp, #0x8c]
0x000d86:	str     	r1, [sp, #0x7c]
0x000d88:	str     	r1, [sp, #0x78]
0x000d8a:	str     	r1, [sp, #0x74]
0x000d8c:	str     	r1, [sp, #0x70]
0x000d8e:	movs    	r1, #0
0x000d90:	str     	r2, [sp, #0x88]
0x000d92:	str     	r2, [sp, #0x84]
0x000d94:	str     	r1, [sp, #0x64]
0x000d96:	str     	r1, [sp, #0x68]
0x000d98:	str     	r1, [sp, #0x6c]
0x000d9a:	movs    	r1, #0xff
0x000d9c:	str     	r0, [sp, #0xa0]
0x000d9e:	str     	r2, [sp, #0x80]
0x000da0:	str     	r1, [sp, #0x60]
0x000da2:	str     	r1, [sp, #0x5c]
0x000da4:	str     	r1, [sp, #0x58]
0x000da6:	movs    	r1, #0
0x000da8:	str     	r1, [sp, #0x54]
0x000daa:	str     	r1, [sp, #0x48]
0x000dac:	str     	r1, [sp, #0x44]
0x000dae:	movs    	r1, #1
0x000db0:	str     	r1, [sp, #0x40]
0x000db2:	str     	r1, [sp, #0x3c]
0x000db4:	movs    	r6, #0
0x000db6:	movs    	r1, #0
0x000db8:	str     	r1, [sp, #0x38]
0x000dba:	str     	r1, [sp, #0x18]
0x000dbc:	ldr     	r1, [pc, #0x3a8]
0x000dbe:	str     	r4, [sp, #0x1c]
0x000dc0:	add     	r1, pc
0x000dc2:	str     	r1, [sp, #0x20]
0x000dc4:	subs    	r1, #0x4c
0x000dc6:	str     	r1, [sp, #0x24]
0x000dc8:	adds    	r1, #0x40
0x000dca:	str     	r1, [sp, #0x28]
0x000dcc:	str     	r0, [sp, #0x2c]
0x000dce:	add     	r0, sp, #0xa0
0x000dd0:	str     	r0, [sp, #0x30]
0x000dd2:	movs    	r1, #0
0x000dd4:	add     	r0, sp, #0x9c
0x000dd6:	str     	r0, [sp, #0x34]
0x000dd8:	str     	r1, [sp]
0x000dda:	str     	r1, [sp, #4]
0x000ddc:	movs    	r1, #7
0x000dde:	movs    	r0, #0xf1
0x000de0:	str     	r2, [sp, #8]
0x000de2:	movs    	r3, #0
0x000de4:	lsls    	r0, r0, #9
0x000de6:	add     	r2, sp, #0x1c
0x000de8:	bl      	#0x29e0
0x000dec:	adds    	r7, r0, #0
0x000dee:	beq     	#0xe22
0x000df0:	movs    	r1, #0
0x000df2:	movs    	r2, #0
0x000df4:	str     	r2, [sp, #8]
0x000df6:	str     	r1, [sp]
0x000df8:	str     	r1, [sp, #4]
0x000dfa:	movs    	r1, #8
0x000dfc:	adds    	r2, r7, #0
0x000dfe:	movs    	r3, #0
0x000e00:	movs    	r0, #0xf1
0x000e02:	lsls    	r0, r0, #9
0x000e04:	bl      	#0x29e0
0x000e08:	movs    	r1, #0
0x000e0a:	movs    	r2, #0
0x000e0c:	str     	r2, [sp, #8]
0x000e0e:	str     	r1, [sp]
0x000e10:	str     	r1, [sp, #4]
0x000e12:	str     	r0, [sp, #0x94]
0x000e14:	movs    	r0, #0xf1
0x000e16:	movs    	r1, #9
0x000e18:	adds    	r2, r7, #0
0x000e1a:	movs    	r3, #0
0x000e1c:	lsls    	r0, r0, #9
0x000e1e:	bl      	#0x29e0
0x000e22:	ldr     	r0, [pc, #0x348]
0x000e24:	movs    	r1, #0
0x000e26:	add     	r0, pc
0x000e28:	str     	r0, [sp, #0x20]
0x000e2a:	subs    	r0, #0x54
0x000e2c:	str     	r0, [sp, #0x24]
0x000e2e:	adds    	r0, #0x40
0x000e30:	str     	r0, [sp, #0x28]
0x000e32:	ldr     	r0, [sp, #0xa0]
0x000e34:	movs    	r2, #0
0x000e36:	str     	r0, [sp, #0x2c]
0x000e38:	add     	r0, sp, #0xa0
0x000e3a:	str     	r0, [sp, #0x30]
0x000e3c:	add     	r0, sp, #0x9c
0x000e3e:	str     	r0, [sp, #0x34]
0x000e40:	str     	r1, [sp]
0x000e42:	str     	r1, [sp, #4]
0x000e44:	movs    	r1, #7
0x000e46:	movs    	r0, #0xf1
0x000e48:	str     	r2, [sp, #8]
0x000e4a:	movs    	r3, #0
0x000e4c:	lsls    	r0, r0, #9
0x000e4e:	add     	r2, sp, #0x1c
0x000e50:	str     	r4, [sp, #0x1c]
0x000e52:	bl      	#0x29e0
0x000e56:	adds    	r7, r0, #0
0x000e58:	movs    	r0, #1
0x000e5a:	str     	r0, [sp, #0x90]
0x000e5c:	cmp     	r7, #0
0x000e5e:	beq     	#0xe9e
0x000e60:	ldr     	r1, [pc, #0x30c]
0x000e62:	add     	r1, pc
0x000e64:	ldr     	r2, [pc, #0x30c]
0x000e66:	adds    	r0, r7, #0
0x000e68:	add     	r2, sb
0x000e6a:	ldr     	r2, [r2]
0x000e6c:	blx     	r2
0x000e6e:	cmp     	r0, #0
0x000e70:	beq     	#0xe86
0x000e72:	ldr     	r1, [pc, #0x304]
0x000e74:	add     	r1, pc
0x000e76:	ldr     	r2, [pc, #0x2fc]
0x000e78:	adds    	r0, r7, #0
0x000e7a:	add     	r2, sb
0x000e7c:	ldr     	r2, [r2]
0x000e7e:	blx     	r2
0x000e80:	cmp     	r0, #0
0x000e82:	bne     	#0xe86
0x000e84:	str     	r0, [sp, #0x90]
0x000e86:	movs    	r1, #0
0x000e88:	movs    	r2, #0
0x000e8a:	str     	r2, [sp, #8]
0x000e8c:	str     	r1, [sp]
0x000e8e:	str     	r1, [sp, #4]
0x000e90:	movs    	r1, #9

; ===== candidate_001954 =====
0x001954:	push    	{r4, r5, r6, r7, lr}
0x001956:	movs    	r2, #0
0x001958:	sub     	sp, #0x7c
0x00195a:	movs    	r4, #0
0x00195c:	mvns    	r1, r2
0x00195e:	ldr     	r3, [pc, #0x3e4]
0x001960:	str     	r1, [sp]
0x001962:	str     	r1, [sp, #4]
0x001964:	str     	r2, [sp, #8]
0x001966:	add     	r3, pc
0x001968:	adds    	r2, r4, #0
0x00196a:	movs    	r1, #5
0x00196c:	movs    	r0, #0xf1
0x00196e:	lsls    	r0, r0, #9
0x001970:	bl      	#0x29e0
0x001974:	str     	r0, [sp, #0x44]
0x001976:	ldr     	r4, [r0, #4]
0x001978:	movs    	r0, #0
0x00197a:	str     	r0, [sp, #0x70]
0x00197c:	str     	r0, [sp, #0x6c]
0x00197e:	ldr     	r0, [pc, #0x3c8]
0x001980:	movs    	r1, #0
0x001982:	add     	r0, pc
0x001984:	str     	r0, [sp, #0x4c]
0x001986:	subs    	r0, #4
0x001988:	str     	r0, [sp, #0x50]
0x00198a:	subs    	r0, #4
0x00198c:	str     	r0, [sp, #0x54]
0x00198e:	add     	r0, sp, #0x70
0x001990:	str     	r0, [sp, #0x5c]
0x001992:	add     	r0, sp, #0x6c
0x001994:	str     	r0, [sp, #0x60]
0x001996:	movs    	r6, #0
0x001998:	movs    	r2, #0
0x00199a:	str     	r1, [sp]
0x00199c:	str     	r1, [sp, #4]
0x00199e:	str     	r4, [sp, #0x48]
0x0019a0:	str     	r2, [sp, #8]
0x0019a2:	movs    	r1, #7
0x0019a4:	adds    	r3, r6, #0
0x0019a6:	movs    	r0, #0xf1
0x0019a8:	lsls    	r0, r0, #9
0x0019aa:	add     	r2, sp, #0x48
0x0019ac:	str     	r6, [sp, #0x58]
0x0019ae:	bl      	#0x29e0
0x0019b2:	movs    	r2, #0
0x0019b4:	movs    	r1, #0
0x0019b6:	str     	r2, [sp, #8]
0x0019b8:	adds    	r5, r0, #0
0x0019ba:	adds    	r3, r6, #0
0x0019bc:	adds    	r2, r0, #0
0x0019be:	str     	r1, [sp]
0x0019c0:	str     	r1, [sp, #4]
0x0019c2:	movs    	r1, #8
0x0019c4:	movs    	r0, #0xf1
0x0019c6:	lsls    	r0, r0, #9
0x0019c8:	bl      	#0x29e0
0x0019cc:	str     	r0, [sp, #0x68]
0x0019ce:	movs    	r1, #0
0x0019d0:	movs    	r2, #0
0x0019d2:	str     	r2, [sp, #8]
0x0019d4:	str     	r1, [sp]
0x0019d6:	str     	r1, [sp, #4]
0x0019d8:	adds    	r3, r6, #0
0x0019da:	adds    	r2, r5, #0
0x0019dc:	movs    	r1, #9
0x0019de:	movs    	r0, #0xf1
0x0019e0:	lsls    	r0, r0, #9
0x0019e2:	bl      	#0x29e0
0x0019e6:	movs    	r1, #0
0x0019e8:	movs    	r2, #0
0x0019ea:	str     	r1, [sp]
0x0019ec:	str     	r1, [sp, #4]
0x0019ee:	movs    	r7, #4
0x0019f0:	adds    	r3, r7, #0
0x0019f2:	movs    	r1, #0xa
0x0019f4:	str     	r2, [sp, #8]
0x0019f6:	movs    	r0, #0xf1
0x0019f8:	lsls    	r0, r0, #9
0x0019fa:	ldr     	r2, [sp, #0x68]
0x0019fc:	bl      	#0x29e0
0x001a00:	movs    	r1, #0
0x001a02:	adds    	r5, r0, #0
0x001a04:	movs    	r2, #0
0x001a06:	str     	r1, [sp]
0x001a08:	str     	r1, [sp, #4]
0x001a0a:	movs    	r1, #0xa
0x001a0c:	str     	r2, [sp, #8]
0x001a0e:	movs    	r0, #0xf1
0x001a10:	adds    	r3, r7, #0
0x001a12:	lsls    	r0, r0, #9
0x001a14:	ldr     	r2, [sp, #0x68]
0x001a16:	bl      	#0x29e0
0x001a1a:	str     	r0, [sp, #0x40]
0x001a1c:	ldr     	r0, [sp, #0x68]
0x001a1e:	movs    	r7, #0
0x001a20:	cmp     	r0, #0
0x001a22:	ble     	#0x1a48
0x001a24:	movs    	r1, #0
0x001a26:	str     	r1, [sp]
0x001a28:	str     	r1, [sp, #4]
0x001a2a:	movs    	r2, #0
0x001a2c:	movs    	r1, #0x13
0x001a2e:	adds    	r3, r6, #0
0x001a30:	movs    	r0, #0xf1
0x001a32:	lsls    	r0, r0, #9
0x001a34:	str     	r2, [sp, #8]
0x001a36:	bl      	#0x29e0
0x001a3a:	ldr     	r2, [sp, #0x40]
0x001a3c:	lsls    	r1, r7, #2
0x001a3e:	str     	r0, [r2, r1]
0x001a40:	ldr     	r0, [sp, #0x68]
0x001a42:	adds    	r7, #1
0x001a44:	cmp     	r7, r0
0x001a46:	blt     	#0x1a24
0x001a48:	ldr     	r0, [pc, #0x300]
0x001a4a:	ldr     	r7, [pc, #0x304]
0x001a4c:	add     	r0, pc
0x001a4e:	str     	r0, [sp, #0x4c]
0x001a50:	str     	r4, [sp, #0x48]
0x001a52:	add     	r7, pc
0x001a54:	subs    	r0, r7, #4
0x001a56:	str     	r0, [sp, #0x54]
0x001a58:	str     	r7, [sp, #0x50]
0x001a5a:	ldr     	r0, [sp, #0x70]
0x001a5c:	movs    	r1, #0
0x001a5e:	str     	r0, [sp, #0x58]
0x001a60:	add     	r0, sp, #0x70
0x001a62:	str     	r0, [sp, #0x5c]
0x001a64:	add     	r0, sp, #0x6c
0x001a66:	str     	r0, [sp, #0x60]
0x001a68:	movs    	r2, #0
0x001a6a:	str     	r1, [sp]
0x001a6c:	str     	r1, [sp, #4]
0x001a6e:	movs    	r6, #0
0x001a70:	adds    	r3, r6, #0
0x001a72:	movs    	r1, #7
0x001a74:	str     	r2, [sp, #8]
0x001a76:	movs    	r0, #0xf1
0x001a78:	lsls    	r0, r0, #9
0x001a7a:	add     	r2, sp, #0x48

; ===== candidate_002128 =====
0x002128:	push    	{r4, r5, r6, r7, lr}
0x00212a:	movs    	r2, #0
0x00212c:	sub     	sp, #0x64
0x00212e:	movs    	r4, #0
0x002130:	mvns    	r1, r2
0x002132:	ldr     	r3, [pc, #0x36c]
0x002134:	str     	r1, [sp]
0x002136:	str     	r1, [sp, #4]
0x002138:	str     	r2, [sp, #8]
0x00213a:	add     	r3, pc
0x00213c:	adds    	r2, r4, #0
0x00213e:	movs    	r1, #5
0x002140:	movs    	r0, #0xf1
0x002142:	lsls    	r0, r0, #9
0x002144:	bl      	#0x29e0
0x002148:	str     	r0, [sp, #0x5c]
0x00214a:	ldr     	r1, [r0, #4]
0x00214c:	movs    	r0, #0
0x00214e:	str     	r1, [sp, #0x50]
0x002150:	movs    	r1, #0
0x002152:	str     	r1, [sp, #0x54]
0x002154:	ldr     	r1, [sp, #0x50]
0x002156:	str     	r0, [sp, #0x58]
0x002158:	str     	r1, [sp, #0x24]
0x00215a:	ldr     	r1, [pc, #0x348]
0x00215c:	add     	r1, pc
0x00215e:	str     	r1, [sp, #0x28]
0x002160:	ldr     	r1, [pc, #0x344]
0x002162:	add     	r1, pc
0x002164:	str     	r1, [sp, #0x2c]
0x002166:	subs    	r1, #4
0x002168:	str     	r1, [sp, #0x30]
0x00216a:	movs    	r1, #0
0x00216c:	str     	r0, [sp, #0x34]
0x00216e:	add     	r0, sp, #0x54
0x002170:	movs    	r2, #0
0x002172:	movs    	r7, #0
0x002174:	adds    	r3, r7, #0
0x002176:	str     	r2, [sp, #8]
0x002178:	str     	r0, [sp, #0x3c]
0x00217a:	str     	r1, [sp]
0x00217c:	str     	r1, [sp, #4]
0x00217e:	add     	r5, sp, #0x24
0x002180:	adds    	r2, r5, #0
0x002182:	movs    	r1, #7
0x002184:	movs    	r0, #0xf1
0x002186:	add     	r4, sp, #0x58
0x002188:	str     	r4, [sp, #0x38]
0x00218a:	lsls    	r0, r0, #9
0x00218c:	bl      	#0x29e0
0x002190:	movs    	r2, #0
0x002192:	movs    	r1, #0
0x002194:	str     	r2, [sp, #8]
0x002196:	adds    	r6, r0, #0
0x002198:	adds    	r3, r7, #0
0x00219a:	adds    	r2, r0, #0
0x00219c:	str     	r1, [sp]
0x00219e:	str     	r1, [sp, #4]
0x0021a0:	movs    	r1, #8
0x0021a2:	movs    	r0, #0xf1
0x0021a4:	lsls    	r0, r0, #9
0x0021a6:	bl      	#0x29e0
0x0021aa:	movs    	r1, #0
0x0021ac:	movs    	r2, #0
0x0021ae:	str     	r2, [sp, #8]
0x0021b0:	str     	r1, [sp]
0x0021b2:	str     	r1, [sp, #4]
0x0021b4:	str     	r0, [sp, #0x4c]
0x0021b6:	adds    	r3, r7, #0
0x0021b8:	adds    	r2, r6, #0
0x0021ba:	movs    	r0, #0xf1
0x0021bc:	movs    	r1, #9
0x0021be:	lsls    	r0, r0, #9
0x0021c0:	bl      	#0x29e0
0x0021c4:	movs    	r1, #0
0x0021c6:	movs    	r2, #0
0x0021c8:	str     	r1, [sp]
0x0021ca:	str     	r1, [sp, #4]
0x0021cc:	movs    	r6, #4
0x0021ce:	adds    	r3, r6, #0
0x0021d0:	movs    	r1, #0xa
0x0021d2:	str     	r2, [sp, #8]
0x0021d4:	movs    	r0, #0xf1
0x0021d6:	lsls    	r0, r0, #9
0x0021d8:	ldr     	r2, [sp, #0x4c]
0x0021da:	bl      	#0x29e0
0x0021de:	str     	r0, [sp, #0x48]
0x0021e0:	movs    	r1, #0
0x0021e2:	movs    	r2, #0
0x0021e4:	str     	r1, [sp]
0x0021e6:	str     	r1, [sp, #4]
0x0021e8:	movs    	r1, #0xa
0x0021ea:	str     	r2, [sp, #8]
0x0021ec:	movs    	r0, #0xf1
0x0021ee:	adds    	r3, r6, #0
0x0021f0:	lsls    	r0, r0, #9
0x0021f2:	ldr     	r2, [sp, #0x4c]
0x0021f4:	bl      	#0x29e0
0x0021f8:	str     	r0, [sp, #0x44]
0x0021fa:	ldr     	r0, [sp, #0x4c]
0x0021fc:	movs    	r1, #0
0x0021fe:	str     	r1, [sp, #0x40]
0x002200:	cmp     	r0, #0
0x002202:	ble     	#0x22e8
0x002204:	ldr     	r0, [sp, #0x50]
0x002206:	movs    	r3, #0
0x002208:	str     	r0, [sp, #0x24]
0x00220a:	ldr     	r0, [pc, #0x2a0]
0x00220c:	str     	r3, [sp, #0x1c]
0x00220e:	add     	r0, pc
0x002210:	str     	r0, [sp, #0x28]
0x002212:	ldr     	r0, [pc, #0x29c]
0x002214:	add     	r0, pc
0x002216:	str     	r0, [sp, #0x2c]
0x002218:	subs    	r0, #4
0x00221a:	str     	r0, [sp, #0x30]
0x00221c:	ldr     	r0, [sp, #0x54]
0x00221e:	movs    	r1, #0
0x002220:	str     	r0, [sp, #0x34]
0x002222:	add     	r0, sp, #0x54
0x002224:	movs    	r2, #0
0x002226:	movs    	r7, #0
0x002228:	adds    	r3, r7, #0
0x00222a:	str     	r2, [sp, #8]
0x00222c:	str     	r0, [sp, #0x3c]
0x00222e:	str     	r1, [sp]
0x002230:	str     	r1, [sp, #4]
0x002232:	add     	r5, sp, #0x24
0x002234:	adds    	r2, r5, #0
0x002236:	movs    	r1, #7
0x002238:	movs    	r0, #0xf1
0x00223a:	add     	r4, sp, #0x58
0x00223c:	str     	r4, [sp, #0x38]
0x00223e:	lsls    	r0, r0, #9
0x002240:	bl      	#0x29e0
0x002244:	ldr     	r1, [sp, #0x40]
0x002246:	lsls    	r6, r1, #2
0x002248:	ldr     	r1, [sp, #0x48]
0x00224a:	str     	r6, [sp, #0x60]
0x00224c:	str     	r0, [r1, r6]
0x00224e:	ldr     	r0, [sp, #0x50]

; ===== candidate_0024cc =====
0x0024cc:	push    	{r4, r5, r6, r7, lr}
0x0024ce:	movs    	r2, #0
0x0024d0:	sub     	sp, #0x4c
0x0024d2:	movs    	r4, #0
0x0024d4:	mvns    	r1, r2
0x0024d6:	ldr     	r3, [pc, #0x354]
0x0024d8:	str     	r1, [sp]
0x0024da:	str     	r1, [sp, #4]
0x0024dc:	str     	r2, [sp, #8]
0x0024de:	add     	r3, pc
0x0024e0:	adds    	r2, r4, #0
0x0024e2:	movs    	r1, #5
0x0024e4:	movs    	r0, #0xf1
0x0024e6:	lsls    	r0, r0, #9
0x0024e8:	bl      	#0x29e0
0x0024ec:	str     	r0, [sp, #0x1c]
0x0024ee:	ldr     	r6, [r0, #4]
0x0024f0:	movs    	r0, #0
0x0024f2:	str     	r0, [sp, #0x48]
0x0024f4:	str     	r0, [sp, #0x44]
0x0024f6:	ldr     	r0, [pc, #0x338]
0x0024f8:	movs    	r7, #0
0x0024fa:	add     	r0, pc
0x0024fc:	str     	r0, [sp, #0x24]
0x0024fe:	subs    	r0, #4
0x002500:	str     	r0, [sp, #0x28]
0x002502:	subs    	r0, #4
0x002504:	str     	r0, [sp, #0x2c]
0x002506:	add     	r0, sp, #0x48
0x002508:	str     	r0, [sp, #0x34]
0x00250a:	movs    	r1, #0
0x00250c:	add     	r0, sp, #0x44
0x00250e:	movs    	r2, #0
0x002510:	str     	r6, [sp, #0x20]
0x002512:	str     	r1, [sp]
0x002514:	str     	r2, [sp, #8]
0x002516:	str     	r0, [sp, #0x38]
0x002518:	str     	r1, [sp, #4]
0x00251a:	adds    	r3, r7, #0
0x00251c:	add     	r4, sp, #0x20
0x00251e:	adds    	r2, r4, #0
0x002520:	movs    	r1, #7
0x002522:	movs    	r0, #0xf1
0x002524:	lsls    	r0, r0, #9
0x002526:	str     	r7, [sp, #0x30]
0x002528:	bl      	#0x29e0
0x00252c:	movs    	r2, #0
0x00252e:	movs    	r1, #0
0x002530:	str     	r2, [sp, #8]
0x002532:	adds    	r5, r0, #0
0x002534:	adds    	r3, r7, #0
0x002536:	adds    	r2, r0, #0
0x002538:	str     	r1, [sp]
0x00253a:	str     	r1, [sp, #4]
0x00253c:	movs    	r1, #8
0x00253e:	movs    	r0, #0xf1
0x002540:	lsls    	r0, r0, #9
0x002542:	bl      	#0x29e0
0x002546:	movs    	r1, #0
0x002548:	movs    	r2, #0
0x00254a:	str     	r2, [sp, #8]
0x00254c:	str     	r1, [sp]
0x00254e:	str     	r1, [sp, #4]
0x002550:	str     	r0, [sp, #0x3c]
0x002552:	adds    	r3, r7, #0
0x002554:	adds    	r2, r5, #0
0x002556:	movs    	r0, #0xf1
0x002558:	movs    	r1, #9
0x00255a:	lsls    	r0, r0, #9
0x00255c:	bl      	#0x29e0
0x002560:	movs    	r1, #0
0x002562:	movs    	r2, #0
0x002564:	str     	r1, [sp]
0x002566:	str     	r1, [sp, #4]
0x002568:	movs    	r1, #0xa
0x00256a:	str     	r2, [sp, #8]
0x00256c:	movs    	r3, #4
0x00256e:	movs    	r0, #0xf1
0x002570:	lsls    	r0, r0, #9
0x002572:	ldr     	r2, [sp, #0x3c]
0x002574:	bl      	#0x29e0
0x002578:	adds    	r5, r0, #0
0x00257a:	ldr     	r0, [sp, #0x3c]
0x00257c:	cmp     	r0, #0
0x00257e:	ble     	#0x2664
0x002580:	movs    	r4, #0
0x002582:	movs    	r2, #0
0x002584:	ldr     	r0, [sp, #0x44]
0x002586:	movs    	r1, #0
0x002588:	ldr     	r3, [pc, #0x2a8]
0x00258a:	str     	r1, [sp, #4]
0x00258c:	str     	r2, [sp, #8]
0x00258e:	str     	r0, [sp]
0x002590:	add     	r3, pc
0x002592:	adds    	r2, r6, #0
0x002594:	movs    	r1, #0xb
0x002596:	movs    	r0, #0xf1
0x002598:	lsls    	r0, r0, #9
0x00259a:	bl      	#0x29e0
0x00259e:	str     	r0, [sp, #0x48]
0x0025a0:	ldr     	r1, [pc, #0x294]
0x0025a2:	str     	r0, [sp, #0x30]
0x0025a4:	add     	r1, pc
0x0025a6:	str     	r1, [sp, #0x24]
0x0025a8:	subs    	r1, #0xff
0x0025aa:	subs    	r1, #0xb1
0x0025ac:	str     	r1, [sp, #0x28]
0x0025ae:	adds    	r1, #0x40
0x0025b0:	str     	r1, [sp, #0x2c]
0x0025b2:	add     	r0, sp, #0x48
0x0025b4:	str     	r0, [sp, #0x34]
0x0025b6:	movs    	r1, #0
0x0025b8:	add     	r0, sp, #0x44
0x0025ba:	str     	r6, [sp, #0x20]
0x0025bc:	movs    	r2, #0
0x0025be:	str     	r1, [sp]
0x0025c0:	str     	r0, [sp, #0x38]
0x0025c2:	str     	r1, [sp, #4]
0x0025c4:	movs    	r1, #7
0x0025c6:	movs    	r0, #0xf1
0x0025c8:	str     	r2, [sp, #8]
0x0025ca:	adds    	r3, r4, #0
0x0025cc:	lsls    	r0, r0, #9
0x0025ce:	add     	r2, sp, #0x20
0x0025d0:	bl      	#0x29e0
0x0025d4:	str     	r0, [sp, #0x40]
0x0025d6:	movs    	r2, #0
0x0025d8:	movs    	r1, #0
0x0025da:	str     	r2, [sp, #8]
0x0025dc:	adds    	r3, r4, #0
0x0025de:	adds    	r2, r0, #0
0x0025e0:	str     	r1, [sp]
0x0025e2:	str     	r1, [sp, #4]
0x0025e4:	movs    	r1, #8
0x0025e6:	movs    	r0, #0xf1
0x0025e8:	lsls    	r0, r0, #9
0x0025ea:	bl      	#0x29e0
0x0025ee:	movs    	r1, #0
0x0025f0:	str     	r1, [sp]
0x0025f2:	movs    	r2, #0
0x0025f4:	str     	r1, [sp, #4]

; ===== candidate_00285c =====
0x00285c:	push    	{r4, r5, r6, r7, lr}
0x00285e:	sub     	sp, #0xc
0x002860:	adds    	r4, r1, #0
0x002862:	movs    	r1, #0
0x002864:	adds    	r7, r2, #0
0x002866:	movs    	r2, #0
0x002868:	str     	r2, [sp, #8]
0x00286a:	str     	r1, [sp]
0x00286c:	str     	r1, [sp, #4]
0x00286e:	movs    	r5, #0xf1
0x002870:	lsls    	r5, r5, #9
0x002872:	movs    	r1, #0xe1
0x002874:	movs    	r2, #0xc1
0x002876:	adds    	r6, r0, #0
0x002878:	movs    	r3, #0
0x00287a:	adds    	r0, r5, #0
0x00287c:	bl      	#0x29e0
0x002880:	cmp     	r0, #0
0x002882:	bne     	#0x289a
0x002884:	movs    	r1, #0
0x002886:	movs    	r2, #0
0x002888:	str     	r2, [sp, #8]
0x00288a:	str     	r1, [sp]
0x00288c:	str     	r1, [sp, #4]
0x00288e:	movs    	r1, #0x14
0x002890:	movs    	r2, #0xc1
0x002892:	movs    	r3, #1
0x002894:	adds    	r0, r5, #0
0x002896:	bl      	#0x29e0
0x00289a:	cmp     	r6, #0xb
0x00289c:	bhs     	#0x293c
0x00289e:	adr     	r3, #8
0x0028a0:	ldrb    	r3, [r3, r6]
0x0028a2:	lsls    	r3, r3, #1
0x0028a4:	add     	pc, r3
0x0028a6:	movs    	r0, r0
0x0028a8:	movs    	r0, #0x15
0x0028aa:	cmp     	r3, #0x4a
0x0028ac:	adds    	r3, #0x2f
0x0028ae:	subs    	r3, #0x37
0x0028b0:	cmp     	r1, r8
0x0028b2:	movs    	r6, r0
0x0028b4:	bl      	#0x32ec
0x0028b8:	bl      	#0x3240
0x0028bc:	bl      	#0x2fdc
0x0028c0:	bl      	#0x2e58
0x0028c4:	bl      	#0x3100
0x0028c8:	bl      	#0x2ef0
0x0028cc:	movs    	r0, #0
0x0028ce:	add     	sp, #0xc
0x0028d0:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002950 =====
0x002950:	push    	{r3, r4, r5, lr}
0x002952:	ldr     	r4, [pc, #0x74]
0x002954:	add     	r4, pc
0x002956:	ldr     	r0, [r4, #0x38]
0x002958:	movs    	r1, #0x14
0x00295a:	ldr     	r2, [r0, #0x64]
0x00295c:	ldr     	r0, [pc, #0x6c]
0x00295e:	add     	r0, pc
0x002960:	blx     	r2
0x002962:	movs    	r5, #0
0x002964:	mvns    	r5, r5
0x002966:	cmp     	r0, r5
0x002968:	bne     	#0x296e
0x00296a:	adds    	r0, r5, #0
0x00296c:	pop     	{r3, r4, r5, pc}

; ===== candidate_0029e0 =====
0x0029e0:	push    	{r4, r5, r6, r7, lr}
0x0029e2:	adds    	r5, r1, #0
0x0029e4:	adds    	r4, r0, #0
0x0029e6:	adds    	r6, r2, #0
0x0029e8:	ldr     	r2, [pc, #0x28]
0x0029ea:	sub     	sp, #0x14
0x0029ec:	mov     	ip, r3
0x0029ee:	add     	r2, pc
0x0029f0:	ldr     	r0, [sp, #0x2c]
0x0029f2:	ldr     	r1, [sp, #0x30]
0x0029f4:	ldr     	r7, [sp, #0x28]
0x0029f6:	ldr     	r3, [r2, #0x3c]
0x0029f8:	movs    	r2, #2
0x0029fa:	str     	r2, [sp, #0xc]
0x0029fc:	str     	r1, [sp, #8]
0x0029fe:	str     	r0, [sp, #4]
0x002a00:	str     	r7, [sp]
0x002a02:	ldr     	r0, [r3, #0xc]
0x002a04:	adds    	r1, r5, #0
0x002a06:	adds    	r2, r6, #0
0x002a08:	ldr     	r7, [r0, #0x28]
0x002a0a:	adds    	r0, r4, #0
0x002a0c:	mov     	r3, ip
0x002a0e:	blx     	r7
0x002a10:	add     	sp, #0x14
0x002a12:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002a1c =====
0x002a1c:	push    	{r4, lr}
0x002a1e:	movs    	r2, #0
0x002a20:	add     	r0, pc
0x002a22:	ldr     	r4, [r0, #0x3c]
0x002a24:	sub     	sp, #0x10
0x002a26:	movs    	r1, #0
0x002a28:	str     	r1, [sp, #4]
0x002a2a:	str     	r1, [sp, #8]
0x002a2c:	str     	r2, [sp, #0xc]
0x002a2e:	str     	r2, [sp]
0x002a30:	ldr     	r0, [r4, #0xc]
0x002a32:	ldr     	r2, [r0, #0x24]
0x002a34:	ldr     	r4, [r0, #0x28]
0x002a36:	blx     	r4
0x002a38:	add     	sp, #0x10
0x002a3a:	pop     	{r4, pc}

; ===== candidate_002a40 =====
0x002a40:	push    	{r4, lr}
0x002a42:	ldr     	r0, [pc, #0x24]
0x002a44:	sub     	sp, #0x10
0x002a46:	add     	r0, pc
0x002a48:	ldr     	r3, [r0, #0x3c]
0x002a4a:	movs    	r2, #0
0x002a4c:	movs    	r1, #0
0x002a4e:	str     	r1, [sp, #4]
0x002a50:	str     	r1, [sp, #8]
0x002a52:	str     	r2, [sp, #0xc]
0x002a54:	str     	r2, [sp]
0x002a56:	ldr     	r0, [r3, #0xc]
0x002a58:	movs    	r3, #0
0x002a5a:	ldr     	r2, [r0, #0x24]
0x002a5c:	ldr     	r4, [r0, #0x28]
0x002a5e:	movs    	r1, #1
0x002a60:	blx     	r4
0x002a62:	add     	sp, #0x10
0x002a64:	pop     	{r4, pc}

; ===== candidate_002a80 =====
0x002a80:	push    	{r4, lr}
0x002a82:	sub     	sp, #0x10
0x002a84:	movs    	r2, #0
0x002a86:	movs    	r1, #0
0x002a88:	str     	r2, [sp, #8]
0x002a8a:	ldr     	r2, [pc, #0x3c]
0x002a8c:	str     	r1, [sp]
0x002a8e:	str     	r1, [sp, #4]
0x002a90:	movs    	r3, #0
0x002a92:	add     	r2, pc
0x002a94:	ldr     	r1, [pc, #0x34]
0x002a96:	ldr     	r0, [pc, #0x38]
0x002a98:	bl      	#0x29e0
0x002a9c:	ldr     	r3, [pc, #0x38]
0x002a9e:	ldr     	r4, [pc, #0x34]
0x002aa0:	add     	r3, sb
0x002aa2:	ldr     	r3, [r3]
0x002aa4:	movs    	r2, #0x41
0x002aa6:	movs    	r1, #0
0x002aa8:	add     	r4, sb
0x002aaa:	adds    	r0, r4, #0
0x002aac:	blx     	r3
0x002aae:	bl      	#0x2a6c
0x002ab2:	ldr     	r3, [pc, #0x28]
0x002ab4:	adds    	r1, r0, #0
0x002ab6:	add     	r3, sb
0x002ab8:	ldr     	r3, [r3]
0x002aba:	movs    	r2, #0x41
0x002abc:	adds    	r0, r4, #0
0x002abe:	blx     	r3
0x002ac0:	movs    	r0, #0
0x002ac2:	add     	sp, #0x10
0x002ac4:	pop     	{r4, pc}

; ===== candidate_002ae4 =====
0x002ae4:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x002ae6:	adds    	r7, r3, #0
0x002ae8:	adds    	r6, r2, #0
0x002aea:	adds    	r5, r0, #0
0x002aec:	ldr     	r0, [r0]
0x002aee:	sub     	sp, #4
0x002af0:	mov     	r1, sb
0x002af2:	str     	r1, [sp]
0x002af4:	movs    	r4, #0
0x002af6:	blx     	#0x34
0x002afa:	ldr     	r0, [sp, #8]
0x002afc:	cmp     	r0, #0xb
0x002afe:	bhs     	#0x2b6c
0x002b00:	adr     	r3, #4
0x002b02:	ldrb    	r3, [r3, r0]
0x002b04:	lsls    	r3, r3, #1
0x002b06:	add     	pc, r3
0x002b08:	lsrs    	r5, r0, #0x1c
0x002b0a:	subs    	r4, r3, #4
0x002b0c:	movs    	r4, #0x21
0x002b0e:	adds    	r1, #0x27
0x002b10:	adds    	r1, #0x2b
0x002b12:	movs    	r7, r5
0x002b14:	ldr     	r1, [pc, #0x60]
0x002b16:	ldr     	r0, [r5, #0xc]
0x002b18:	add     	r1, sb
0x002b1a:	str     	r0, [r1, #0x14]
0x002b1c:	bl      	#0x3c
0x002b20:	bl      	#0x2a80
0x002b24:	adds    	r4, r0, #0
0x002b26:	b       	#0x2b6c
0x002b28:	ldr     	r0, [r6]
0x002b2a:	cmp     	r0, #8
0x002b2c:	bne     	#0x2b36
0x002b2e:	bl      	#0x29dc
0x002b32:	adds    	r4, r0, #0
0x002b34:	b       	#0x2b6c
0x002b36:	ldr     	r1, [r6, #4]
0x002b38:	ldr     	r2, [r6, #8]
0x002b3a:	bl      	#0x29d8
0x002b3e:	adds    	r4, r0, #0
0x002b40:	b       	#0x2b6c
0x002b42:	bl      	#0x2d74
0x002b46:	b       	#0x2b6c
0x002b48:	str     	r7, [r5, #0xc]
0x002b4a:	b       	#0x2b6c
0x002b4c:	bl      	#0x2ae0
0x002b50:	b       	#0x2b6c
0x002b52:	bl      	#0x2bb0
0x002b56:	b       	#0x2b6c
0x002b58:	ldr     	r0, [pc, #0x1c]
0x002b5a:	add     	r0, sb
0x002b5c:	str     	r7, [r0, #0x1c]
0x002b5e:	b       	#0x2b6c
0x002b60:	ldr     	r0, [pc, #0x14]
0x002b62:	add     	r0, sb
0x002b64:	str     	r6, [r0, #0x20]
0x002b66:	b       	#0x2b6c
0x002b68:	ldr     	r4, [pc, #0x10]
0x002b6a:	add     	r4, pc
0x002b6c:	ldr     	r1, [sp]
0x002b6e:	add     	sp, #0x14
0x002b70:	adds    	r0, r4, #0
0x002b72:	mov     	sb, r1
0x002b74:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002b80 =====
0x002b80:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x002b82:	sub     	sp, #0xc
0x002b84:	ldr     	r0, [sp, #0x38]
0x002b86:	ldr     	r4, [sp, #0x3c]
0x002b88:	ldr     	r6, [sp, #0x34]
0x002b8a:	ldr     	r0, [r0]
0x002b8c:	mov     	r7, sb
0x002b8e:	movs    	r5, #0
0x002b90:	blx     	#0x34
0x002b94:	cmp     	r4, #0
0x002b96:	beq     	#0x2ba6
0x002b98:	ldr     	r1, [sp, #0x30]
0x002b9a:	str     	r6, [sp, #4]
0x002b9c:	add     	r3, sp, #0xc
0x002b9e:	str     	r1, [sp]
0x002ba0:	ldm     	r3, {r0, r1, r2, r3}
0x002ba2:	blx     	r4
0x002ba4:	adds    	r5, r0, #0
0x002ba6:	mov     	sb, r7
0x002ba8:	adds    	r0, r5, #0
0x002baa:	add     	sp, #0x1c
0x002bac:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002c14 =====
0x002c14:	push    	{r3, r4, r5, r6, r7, lr}
0x002c16:	adds    	r4, r0, #0
0x002c18:	ldr     	r0, [pc, #0x10c]
0x002c1a:	movs    	r5, #0
0x002c1c:	mvns    	r5, r5
0x002c1e:	mov     	ip, r2
0x002c20:	add     	r0, pc
0x002c22:	ldr     	r2, [r0, #0x38]
0x002c24:	cmp     	r4, #0
0x002c26:	bne     	#0x2c38
0x002c28:	ldr     	r0, [pc, #0x100]
0x002c2a:	ldr     	r2, [r2, #0x68]
0x002c2c:	movs    	r1, #0x7d
0x002c2e:	lsls    	r1, r1, #3
0x002c30:	add     	r0, pc
0x002c32:	blx     	r2
0x002c34:	adds    	r0, r5, #0
0x002c36:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_002d40 =====
0x002d40:	push    	{r3, r4, r5, lr}
0x002d42:	ldr     	r4, [pc, #0x28]
0x002d44:	adds    	r5, r0, #0
0x002d46:	add     	r4, pc
0x002d48:	ldr     	r0, [r4, #0x38]
0x002d4a:	adds    	r0, #0x80
0x002d4c:	ldr     	r0, [r0, #4]
0x002d4e:	blx     	r0
0x002d50:	adds    	r0, r0, r5
0x002d52:	ldr     	r1, [pc, #0x1c]
0x002d54:	add     	r1, sb
0x002d56:	str     	r0, [r1, #0x10]
0x002d58:	ldr     	r0, [r4, #0x38]
0x002d5a:	adds    	r0, #0x80
0x002d5c:	ldr     	r0, [r0]
0x002d5e:	blx     	r0
0x002d60:	ldr     	r0, [r4, #0x38]
0x002d62:	ldr     	r1, [r0, #0x7c]
0x002d64:	lsls    	r0, r5, #0x10
0x002d66:	lsrs    	r0, r0, #0x10
0x002d68:	blx     	r1
0x002d6a:	pop     	{r3, r4, r5, pc}

; ===== candidate_002d76 =====
0x002d76:	push    	{r3, r4, r5, r6, r7, lr}
0x002d78:	add     	r0, pc
0x002d7a:	ldr     	r0, [r0, #0x38]
0x002d7c:	adds    	r0, #0x80
0x002d7e:	ldr     	r0, [r0, #4]
0x002d80:	blx     	r0
0x002d82:	movs    	r5, #0
0x002d84:	ldr     	r6, [pc, #0xc8]
0x002d86:	add     	r6, sb
0x002d88:	ldr     	r1, [r6, #0x10]
0x002d8a:	str     	r5, [r6, #0x10]
0x002d8c:	subs    	r1, r0, r1
0x002d8e:	ldr     	r0, [r6, #8]
0x002d90:	adds    	r3, r1, #0
0x002d92:	cmp     	r0, #0
0x002d94:	beq     	#0x2e4a
0x002d96:	ldr     	r2, [r0, #8]
0x002d98:	cmp     	r2, #0
0x002d9a:	bne     	#0x2dfa
0x002d9c:	mvns    	r7, r2
0x002d9e:	str     	r7, [r0, #8]
0x002da0:	ldr     	r2, [r0, #0x18]
0x002da2:	adds    	r4, r0, #0
0x002da4:	cmp     	r1, #0x32
0x002da6:	str     	r2, [r6, #8]
0x002da8:	bge     	#0x2dae
0x002daa:	movs    	r1, #0x32
0x002dac:	b       	#0x2dca
0x002dae:	movs    	r2, #0x7d
0x002db0:	lsls    	r2, r2, #4
0x002db2:	cmp     	r1, r2
0x002db4:	ble     	#0x2dca
0x002db6:	adds    	r1, r2, #0
0x002db8:	b       	#0x2dca
0x002dba:	movs    	r7, #0
0x002dbc:	mvns    	r7, r7
0x002dbe:	str     	r7, [r2, #8]
0x002dc0:	ldr     	r2, [r0, #0x18]
0x002dc2:	str     	r2, [r0, #0x1c]
0x002dc4:	ldr     	r0, [r2, #0x18]
0x002dc6:	str     	r0, [r6, #8]
0x002dc8:	adds    	r0, r2, #0
0x002dca:	ldr     	r2, [r0, #0x18]
0x002dcc:	cmp     	r2, #0
0x002dce:	beq     	#0x2dd6
0x002dd0:	ldr     	r7, [r2, #8]
0x002dd2:	cmp     	r7, r1
0x002dd4:	blt     	#0x2dba
0x002dd6:	str     	r5, [r0, #0x1c]
0x002dd8:	ldr     	r0, [r6, #8]
0x002dda:	cmp     	r0, #0
0x002ddc:	beq     	#0x2e3e
0x002dde:	cmp     	r3, #0
0x002de0:	bge     	#0x2de4
0x002de2:	movs    	r3, #0
0x002de4:	ldr     	r0, [r6, #8]
0x002de6:	ldr     	r1, [r0, #8]
0x002de8:	cmp     	r1, #0
0x002dea:	bge     	#0x2df0
0x002dec:	movs    	r1, #0
0x002dee:	str     	r5, [r0, #8]
0x002df0:	ldr     	r2, [pc, #0x60]
0x002df2:	cmp     	r1, r2
0x002df4:	ble     	#0x2dfe
0x002df6:	adds    	r1, r2, #0
0x002df8:	b       	#0x2dfe
0x002dfa:	movs    	r4, #0
0x002dfc:	b       	#0x2dde
0x002dfe:	ldr     	r2, [r0, #8]
0x002e00:	subs    	r2, r2, r1
0x002e02:	str     	r2, [r0, #8]
0x002e04:	ldr     	r0, [r0, #0x18]
0x002e06:	cmp     	r0, #0
0x002e08:	bne     	#0x2dfe
0x002e0a:	subs    	r0, r1, r3
0x002e0c:	cmp     	r0, #0
0x002e0e:	bgt     	#0x2e12
0x002e10:	movs    	r0, #0xa
0x002e12:	bl      	#0x2d40
0x002e16:	b       	#0x2e3e
0x002e18:	str     	r5, [r4, #8]
0x002e1a:	ldr     	r0, [r4, #0x1c]
0x002e1c:	adds    	r3, r5, #0
0x002e1e:	str     	r0, [r6, #0xc]
0x002e20:	ldr     	r0, [r4, #0x14]
0x002e22:	cmp     	r0, #0
0x002e24:	beq     	#0x2e32
0x002e26:	str     	r0, [sp]
0x002e28:	movs    	r1, #0
0x002e2a:	adds    	r0, r4, #0
0x002e2c:	ldr     	r2, [r4, #0x10]
0x002e2e:	bl      	#0x2c14
0x002e32:	ldr     	r1, [r4, #0xc]
0x002e34:	cmp     	r1, #0
0x002e36:	beq     	#0x2e3c
0x002e38:	ldr     	r0, [r4, #0x10]
0x002e3a:	blx     	r1
0x002e3c:	ldr     	r4, [r6, #0xc]
0x002e3e:	cmp     	r4, #0
0x002e40:	beq     	#0x2e48
0x002e42:	ldr     	r0, [r4, #8]
0x002e44:	cmp     	r0, #0
0x002e46:	blt     	#0x2e18
0x002e48:	str     	r5, [r6, #0xc]
0x002e4a:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_002e58 =====
0x002e58:	push    	{r4, r5, r6, r7, lr}
0x002e5a:	sub     	sp, #0xc
0x002e5c:	movs    	r1, #0
0x002e5e:	movs    	r2, #0
0x002e60:	str     	r2, [sp, #8]
0x002e62:	str     	r1, [sp]
0x002e64:	str     	r1, [sp, #4]
0x002e66:	movs    	r1, #0xe1
0x002e68:	movs    	r2, #4
0x002e6a:	movs    	r3, #0
0x002e6c:	movs    	r0, #0xf1
0x002e6e:	lsls    	r0, r0, #9
0x002e70:	bl      	#0x29e0
0x002e74:	movs    	r2, #0
0x002e76:	movs    	r1, #0
0x002e78:	str     	r2, [sp, #8]
0x002e7a:	adds    	r5, r0, #0
0x002e7c:	adds    	r2, r0, #0
0x002e7e:	str     	r1, [sp]
0x002e80:	str     	r1, [sp, #4]
0x002e82:	movs    	r1, #0x11
0x002e84:	movs    	r0, #0xf1
0x002e86:	movs    	r3, #4
0x002e88:	lsls    	r0, r0, #9
0x002e8a:	bl      	#0x29e0
0x002e8e:	adds    	r6, r0, #0
0x002e90:	movs    	r4, #0
0x002e92:	cmp     	r0, #0
0x002e94:	ble     	#0x2eb8
0x002e96:	lsls    	r0, r4, #2
0x002e98:	ldr     	r7, [r5, r0]
0x002e9a:	movs    	r1, #0
0x002e9c:	movs    	r2, #0
0x002e9e:	str     	r2, [sp, #8]
0x002ea0:	str     	r1, [sp]
0x002ea2:	str     	r1, [sp, #4]
0x002ea4:	movs    	r1, #9
0x002ea6:	adds    	r2, r7, #0
0x002ea8:	movs    	r0, #0xf1
0x002eaa:	movs    	r3, #0
0x002eac:	lsls    	r0, r0, #9
0x002eae:	bl      	#0x29e0
0x002eb2:	adds    	r4, #1
0x002eb4:	cmp     	r4, r6
0x002eb6:	blt     	#0x2e96
0x002eb8:	movs    	r1, #0
0x002eba:	movs    	r2, #0
0x002ebc:	movs    	r4, #0
0x002ebe:	adds    	r3, r4, #0
0x002ec0:	str     	r2, [sp, #8]
0x002ec2:	str     	r1, [sp]
0x002ec4:	str     	r1, [sp, #4]
0x002ec6:	movs    	r1, #9
0x002ec8:	adds    	r2, r5, #0
0x002eca:	movs    	r0, #0xf1
0x002ecc:	lsls    	r0, r0, #9
0x002ece:	bl      	#0x29e0
0x002ed2:	movs    	r1, #0
0x002ed4:	movs    	r2, #0
0x002ed6:	str     	r2, [sp, #8]
0x002ed8:	str     	r1, [sp]
0x002eda:	str     	r1, [sp, #4]
0x002edc:	movs    	r1, #0x14
0x002ede:	movs    	r2, #4
0x002ee0:	adds    	r3, r4, #0
0x002ee2:	movs    	r0, #0xf1
0x002ee4:	lsls    	r0, r0, #9
0x002ee6:	bl      	#0x29e0
0x002eea:	add     	sp, #0xc
0x002eec:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002ef0 =====
0x002ef0:	push    	{r4, r5, r6, r7, lr}
0x002ef2:	sub     	sp, #0x14
0x002ef4:	movs    	r1, #0
0x002ef6:	movs    	r2, #0
0x002ef8:	str     	r2, [sp, #8]
0x002efa:	str     	r1, [sp]
0x002efc:	str     	r1, [sp, #4]
0x002efe:	movs    	r4, #0
0x002f00:	adds    	r3, r4, #0
0x002f02:	movs    	r1, #0xe1
0x002f04:	movs    	r2, #9
0x002f06:	movs    	r0, #0xf1
0x002f08:	lsls    	r0, r0, #9
0x002f0a:	bl      	#0x29e0
0x002f0e:	movs    	r1, #0
0x002f10:	movs    	r2, #0
0x002f12:	str     	r2, [sp, #8]
0x002f14:	str     	r1, [sp]
0x002f16:	str     	r1, [sp, #4]
0x002f18:	str     	r0, [sp, #0x10]
0x002f1a:	movs    	r0, #0xf1
0x002f1c:	movs    	r1, #0xe1
0x002f1e:	movs    	r2, #0xa
0x002f20:	adds    	r3, r4, #0
0x002f22:	lsls    	r0, r0, #9
0x002f24:	bl      	#0x29e0
0x002f28:	movs    	r1, #0
0x002f2a:	adds    	r5, r0, #0
0x002f2c:	movs    	r2, #0
0x002f2e:	str     	r2, [sp, #8]
0x002f30:	str     	r1, [sp]
0x002f32:	str     	r1, [sp, #4]
0x002f34:	movs    	r1, #0xe1
0x002f36:	movs    	r2, #0xb
0x002f38:	movs    	r0, #0xf1
0x002f3a:	adds    	r3, r4, #0
0x002f3c:	lsls    	r0, r0, #9
0x002f3e:	bl      	#0x29e0
0x002f42:	movs    	r1, #0
0x002f44:	adds    	r6, r0, #0
0x002f46:	movs    	r2, #0
0x002f48:	str     	r2, [sp, #8]
0x002f4a:	str     	r1, [sp]
0x002f4c:	str     	r1, [sp, #4]
0x002f4e:	movs    	r1, #0xe1
0x002f50:	movs    	r2, #0xc
0x002f52:	movs    	r0, #0xf1
0x002f54:	adds    	r3, r4, #0
0x002f56:	lsls    	r0, r0, #9
0x002f58:	bl      	#0x29e0
0x002f5c:	adds    	r7, r0, #0
0x002f5e:	ldr     	r0, [sp, #0x10]
0x002f60:	bl      	#0x3064
0x002f64:	adds    	r0, r5, #0
0x002f66:	bl      	#0x3064
0x002f6a:	adds    	r0, r6, #0
0x002f6c:	bl      	#0x3064
0x002f70:	adds    	r0, r7, #0
0x002f72:	bl      	#0x3064
0x002f76:	movs    	r1, #0
0x002f78:	movs    	r2, #0
0x002f7a:	str     	r2, [sp, #8]
0x002f7c:	str     	r1, [sp]
0x002f7e:	str     	r1, [sp, #4]
0x002f80:	movs    	r1, #0x14
0x002f82:	movs    	r2, #9
0x002f84:	adds    	r3, r4, #0
0x002f86:	movs    	r0, #0xf1
0x002f88:	lsls    	r0, r0, #9
0x002f8a:	bl      	#0x29e0
0x002f8e:	movs    	r1, #0
0x002f90:	movs    	r2, #0
0x002f92:	str     	r2, [sp, #8]
0x002f94:	str     	r1, [sp]
0x002f96:	str     	r1, [sp, #4]
0x002f98:	movs    	r1, #0x14
0x002f9a:	movs    	r2, #0xa
0x002f9c:	adds    	r3, r4, #0
0x002f9e:	movs    	r0, #0xf1
0x002fa0:	lsls    	r0, r0, #9
0x002fa2:	bl      	#0x29e0
0x002fa6:	movs    	r1, #0
0x002fa8:	movs    	r2, #0
0x002faa:	str     	r2, [sp, #8]
0x002fac:	str     	r1, [sp]
0x002fae:	str     	r1, [sp, #4]
0x002fb0:	movs    	r1, #0x14
0x002fb2:	movs    	r2, #0xb
0x002fb4:	adds    	r3, r4, #0
0x002fb6:	movs    	r0, #0xf1
0x002fb8:	lsls    	r0, r0, #9
0x002fba:	bl      	#0x29e0
0x002fbe:	movs    	r1, #0
0x002fc0:	movs    	r2, #0
0x002fc2:	str     	r2, [sp, #8]
0x002fc4:	str     	r1, [sp]
0x002fc6:	str     	r1, [sp, #4]
0x002fc8:	movs    	r1, #0x14
0x002fca:	movs    	r2, #0xc
0x002fcc:	adds    	r3, r4, #0
0x002fce:	movs    	r0, #0xf1
0x002fd0:	lsls    	r0, r0, #9
0x002fd2:	bl      	#0x29e0
0x002fd6:	add     	sp, #0x14
0x002fd8:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_002fdc =====
0x002fdc:	push    	{r4, r5, r6, r7, lr}
0x002fde:	sub     	sp, #0xc
0x002fe0:	movs    	r1, #0
0x002fe2:	movs    	r2, #0
0x002fe4:	str     	r2, [sp, #8]
0x002fe6:	str     	r1, [sp]
0x002fe8:	str     	r1, [sp, #4]
0x002fea:	movs    	r1, #0xe1
0x002fec:	movs    	r2, #3
0x002fee:	movs    	r3, #0
0x002ff0:	movs    	r0, #0xf1
0x002ff2:	lsls    	r0, r0, #9
0x002ff4:	bl      	#0x29e0
0x002ff8:	movs    	r2, #0
0x002ffa:	movs    	r1, #0
0x002ffc:	str     	r2, [sp, #8]
0x002ffe:	adds    	r5, r0, #0
0x003000:	adds    	r2, r0, #0
0x003002:	str     	r1, [sp]
0x003004:	str     	r1, [sp, #4]
0x003006:	movs    	r1, #0x11
0x003008:	movs    	r0, #0xf1
0x00300a:	movs    	r3, #4
0x00300c:	lsls    	r0, r0, #9
0x00300e:	bl      	#0x29e0
0x003012:	adds    	r6, r0, #0
0x003014:	movs    	r4, #0
0x003016:	cmp     	r0, #0
0x003018:	ble     	#0x302c
0x00301a:	lsls    	r7, r4, #2
0x00301c:	ldr     	r0, [r5, r7]
0x00301e:	bl      	#0x3294
0x003022:	movs    	r0, #0
0x003024:	adds    	r4, #1
0x003026:	cmp     	r4, r6
0x003028:	str     	r0, [r5, r7]
0x00302a:	blt     	#0x301a
0x00302c:	movs    	r1, #0
0x00302e:	movs    	r2, #0
0x003030:	movs    	r4, #0
0x003032:	adds    	r3, r4, #0
0x003034:	str     	r2, [sp, #8]
0x003036:	str     	r1, [sp]
0x003038:	str     	r1, [sp, #4]
0x00303a:	movs    	r1, #9
0x00303c:	adds    	r2, r5, #0
0x00303e:	movs    	r0, #0xf1
0x003040:	lsls    	r0, r0, #9
0x003042:	bl      	#0x29e0
0x003046:	movs    	r1, #0
0x003048:	movs    	r2, #0
0x00304a:	str     	r2, [sp, #8]
0x00304c:	str     	r1, [sp]
0x00304e:	str     	r1, [sp, #4]
0x003050:	movs    	r1, #0x14
0x003052:	movs    	r2, #3
0x003054:	adds    	r3, r4, #0
0x003056:	movs    	r0, #0xf1
0x003058:	lsls    	r0, r0, #9
0x00305a:	bl      	#0x29e0
0x00305e:	add     	sp, #0xc
0x003060:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003064 =====
0x003064:	push    	{r4, r5, r6, r7, lr}
0x003066:	sub     	sp, #0x14
0x003068:	movs    	r1, #0
0x00306a:	movs    	r2, #0
0x00306c:	str     	r2, [sp, #8]
0x00306e:	str     	r1, [sp]
0x003070:	str     	r1, [sp, #4]
0x003072:	movs    	r7, #0xf1
0x003074:	lsls    	r7, r7, #9
0x003076:	movs    	r1, #0x11
0x003078:	adds    	r2, r0, #0
0x00307a:	adds    	r6, r0, #0
0x00307c:	movs    	r3, #4
0x00307e:	adds    	r0, r7, #0
0x003080:	bl      	#0x29e0
0x003084:	movs    	r5, #0
0x003086:	cmp     	r0, #0
0x003088:	str     	r0, [sp, #0x10]
0x00308a:	ble     	#0x30e4
0x00308c:	lsls    	r0, r5, #2
0x00308e:	ldr     	r4, [r6, r0]
0x003090:	movs    	r1, #0
0x003092:	str     	r1, [sp]
0x003094:	str     	r1, [sp, #4]
0x003096:	movs    	r2, #0
0x003098:	str     	r2, [sp, #8]
0x00309a:	movs    	r1, #9
0x00309c:	movs    	r3, #0
0x00309e:	adds    	r0, r7, #0
0x0030a0:	ldr     	r2, [r4]
0x0030a2:	bl      	#0x29e0
0x0030a6:	ldr     	r3, [r4, #8]
0x0030a8:	cmp     	r3, #0
0x0030aa:	beq     	#0x30c6
0x0030ac:	movs    	r2, #0
0x0030ae:	movs    	r1, #0
0x0030b0:	str     	r2, [sp, #8]
0x0030b2:	adds    	r2, r3, #0
0x0030b4:	str     	r1, [sp]
0x0030b6:	str     	r1, [sp, #4]
0x0030b8:	movs    	r1, #6
0x0030ba:	movs    	r3, #0
0x0030bc:	adds    	r0, r7, #0
0x0030be:	bl      	#0x29e0
0x0030c2:	movs    	r3, #0
0x0030c4:	str     	r3, [r4, #8]
0x0030c6:	movs    	r1, #0
0x0030c8:	movs    	r2, #0
0x0030ca:	str     	r2, [sp, #8]
0x0030cc:	str     	r1, [sp]
0x0030ce:	str     	r1, [sp, #4]
0x0030d0:	movs    	r1, #9
0x0030d2:	adds    	r2, r4, #0
0x0030d4:	movs    	r3, #0
0x0030d6:	adds    	r0, r7, #0
0x0030d8:	bl      	#0x29e0
0x0030dc:	ldr     	r0, [sp, #0x10]
0x0030de:	adds    	r5, #1
0x0030e0:	cmp     	r5, r0
0x0030e2:	blt     	#0x308c
0x0030e4:	movs    	r1, #0
0x0030e6:	movs    	r2, #0
0x0030e8:	str     	r2, [sp, #8]
0x0030ea:	str     	r1, [sp]
0x0030ec:	str     	r1, [sp, #4]
0x0030ee:	movs    	r1, #9
0x0030f0:	adds    	r2, r6, #0
0x0030f2:	movs    	r3, #0
0x0030f4:	adds    	r0, r7, #0
0x0030f6:	bl      	#0x29e0
0x0030fa:	add     	sp, #0x14
0x0030fc:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003100 =====
0x003100:	push    	{r4, r5, r6, r7, lr}
0x003102:	sub     	sp, #0xc
0x003104:	movs    	r1, #0
0x003106:	movs    	r2, #0
0x003108:	str     	r2, [sp, #8]
0x00310a:	str     	r1, [sp]
0x00310c:	str     	r1, [sp, #4]
0x00310e:	movs    	r1, #0xe1
0x003110:	movs    	r2, #5
0x003112:	movs    	r3, #0
0x003114:	movs    	r0, #0xf1
0x003116:	lsls    	r0, r0, #9
0x003118:	bl      	#0x29e0
0x00311c:	movs    	r2, #0
0x00311e:	movs    	r1, #0
0x003120:	movs    	r7, #4
0x003122:	adds    	r3, r7, #0
0x003124:	str     	r2, [sp, #8]
0x003126:	adds    	r5, r0, #0
0x003128:	adds    	r2, r0, #0
0x00312a:	str     	r1, [sp]
0x00312c:	str     	r1, [sp, #4]
0x00312e:	movs    	r1, #0x11
0x003130:	movs    	r0, #0xf1
0x003132:	lsls    	r0, r0, #9
0x003134:	bl      	#0x29e0
0x003138:	adds    	r6, r0, #0
0x00313a:	movs    	r4, #0
0x00313c:	cmp     	r0, #0
0x00313e:	ble     	#0x314e
0x003140:	lsls    	r0, r4, #2
0x003142:	ldr     	r0, [r5, r0]
0x003144:	bl      	#0x3400
0x003148:	adds    	r4, #1
0x00314a:	cmp     	r4, r6
0x00314c:	blt     	#0x3140
0x00314e:	movs    	r1, #0
0x003150:	movs    	r2, #0
0x003152:	movs    	r4, #0
0x003154:	adds    	r3, r4, #0
0x003156:	str     	r2, [sp, #8]
0x003158:	str     	r1, [sp]
0x00315a:	str     	r1, [sp, #4]
0x00315c:	movs    	r1, #9
0x00315e:	adds    	r2, r5, #0
0x003160:	movs    	r0, #0xf1
0x003162:	lsls    	r0, r0, #9
0x003164:	bl      	#0x29e0
0x003168:	movs    	r1, #0
0x00316a:	movs    	r2, #0
0x00316c:	str     	r2, [sp, #8]
0x00316e:	str     	r1, [sp]
0x003170:	str     	r1, [sp, #4]
0x003172:	movs    	r1, #0x14
0x003174:	movs    	r2, #5
0x003176:	adds    	r3, r4, #0
0x003178:	movs    	r0, #0xf1
0x00317a:	lsls    	r0, r0, #9
0x00317c:	bl      	#0x29e0
0x003180:	movs    	r1, #0
0x003182:	movs    	r2, #0
0x003184:	str     	r2, [sp, #8]
0x003186:	str     	r1, [sp]
0x003188:	str     	r1, [sp, #4]
0x00318a:	movs    	r1, #0xe1
0x00318c:	movs    	r2, #7
0x00318e:	adds    	r3, r4, #0
0x003190:	movs    	r0, #0xf1
0x003192:	lsls    	r0, r0, #9
0x003194:	bl      	#0x29e0
0x003198:	movs    	r2, #0
0x00319a:	movs    	r1, #0
0x00319c:	str     	r2, [sp, #8]
0x00319e:	adds    	r3, r4, #0
0x0031a0:	adds    	r2, r0, #0
0x0031a2:	str     	r1, [sp]
0x0031a4:	str     	r1, [sp, #4]
0x0031a6:	movs    	r1, #9
0x0031a8:	movs    	r0, #0xf1
0x0031aa:	lsls    	r0, r0, #9
0x0031ac:	bl      	#0x29e0
0x0031b0:	movs    	r1, #0
0x0031b2:	movs    	r2, #0
0x0031b4:	str     	r2, [sp, #8]
0x0031b6:	str     	r1, [sp]
0x0031b8:	str     	r1, [sp, #4]
0x0031ba:	movs    	r1, #0x14
0x0031bc:	movs    	r2, #7
0x0031be:	adds    	r3, r4, #0
0x0031c0:	movs    	r0, #0xf1
0x0031c2:	lsls    	r0, r0, #9
0x0031c4:	bl      	#0x29e0
0x0031c8:	movs    	r1, #0
0x0031ca:	movs    	r2, #0
0x0031cc:	str     	r2, [sp, #8]
0x0031ce:	str     	r1, [sp]
0x0031d0:	str     	r1, [sp, #4]
0x0031d2:	movs    	r1, #0xe1
0x0031d4:	movs    	r2, #6
0x0031d6:	adds    	r3, r4, #0
0x0031d8:	movs    	r0, #0xf1
0x0031da:	lsls    	r0, r0, #9
0x0031dc:	bl      	#0x29e0
0x0031e0:	movs    	r2, #0
0x0031e2:	movs    	r1, #0
0x0031e4:	str     	r2, [sp, #8]
0x0031e6:	adds    	r4, r0, #0
0x0031e8:	adds    	r3, r7, #0
0x0031ea:	adds    	r2, r0, #0
0x0031ec:	str     	r1, [sp]
0x0031ee:	str     	r1, [sp, #4]
0x0031f0:	movs    	r1, #0x11
0x0031f2:	movs    	r0, #0xf1
0x0031f4:	lsls    	r0, r0, #9
0x0031f6:	bl      	#0x29e0
0x0031fa:	adds    	r6, r0, #0
0x0031fc:	movs    	r5, #0
0x0031fe:	cmp     	r0, #0
0x003200:	ble     	#0x3224
0x003202:	lsls    	r0, r5, #2
0x003204:	ldr     	r7, [r4, r0]
0x003206:	movs    	r1, #0
0x003208:	movs    	r2, #0
0x00320a:	str     	r2, [sp, #8]
0x00320c:	str     	r1, [sp]
0x00320e:	str     	r1, [sp, #4]
0x003210:	movs    	r1, #9
0x003212:	adds    	r2, r7, #0
0x003214:	movs    	r0, #0xf1
0x003216:	movs    	r3, #0
0x003218:	lsls    	r0, r0, #9
0x00321a:	bl      	#0x29e0
0x00321e:	adds    	r5, #1
0x003220:	cmp     	r5, r6
0x003222:	blt     	#0x3202
0x003224:	movs    	r1, #0
0x003226:	movs    	r2, #0
0x003228:	str     	r2, [sp, #8]
0x00322a:	str     	r1, [sp]
0x00322c:	str     	r1, [sp, #4]
0x00322e:	movs    	r1, #9

; ===== candidate_003240 =====
0x003240:	push    	{r4, r5, lr}
0x003242:	sub     	sp, #0xc
0x003244:	movs    	r1, #0
0x003246:	movs    	r2, #0
0x003248:	str     	r2, [sp, #8]
0x00324a:	str     	r1, [sp]
0x00324c:	str     	r1, [sp, #4]
0x00324e:	movs    	r4, #0
0x003250:	adds    	r3, r4, #0
0x003252:	movs    	r1, #0xe1
0x003254:	movs    	r2, #2
0x003256:	movs    	r0, #0xf1
0x003258:	lsls    	r0, r0, #9
0x00325a:	bl      	#0x29e0
0x00325e:	movs    	r2, #0
0x003260:	movs    	r1, #0
0x003262:	str     	r2, [sp, #8]
0x003264:	adds    	r3, r4, #0
0x003266:	adds    	r2, r0, #0
0x003268:	str     	r1, [sp]
0x00326a:	str     	r1, [sp, #4]
0x00326c:	movs    	r1, #0x12
0x00326e:	movs    	r0, #0xf1
0x003270:	lsls    	r0, r0, #9
0x003272:	bl      	#0x29e0
0x003276:	movs    	r1, #0
0x003278:	movs    	r2, #0
0x00327a:	str     	r2, [sp, #8]
0x00327c:	str     	r1, [sp]
0x00327e:	str     	r1, [sp, #4]
0x003280:	movs    	r1, #0x14
0x003282:	movs    	r2, #2
0x003284:	adds    	r3, r4, #0
0x003286:	movs    	r0, #0xf1
0x003288:	lsls    	r0, r0, #9
0x00328a:	bl      	#0x29e0
0x00328e:	add     	sp, #0xc
0x003290:	pop     	{r4, r5, pc}

; ===== candidate_003294 =====
0x003294:	push    	{r4, r5, lr}
0x003296:	sub     	sp, #0xc
0x003298:	adds    	r4, r0, #0
0x00329a:	beq     	#0x32e6
0x00329c:	movs    	r1, #0
0x00329e:	str     	r1, [sp]
0x0032a0:	str     	r1, [sp, #4]
0x0032a2:	movs    	r2, #0
0x0032a4:	movs    	r5, #0
0x0032a6:	adds    	r3, r5, #0
0x0032a8:	str     	r2, [sp, #8]
0x0032aa:	movs    	r1, #9
0x0032ac:	movs    	r0, #0xf1
0x0032ae:	lsls    	r0, r0, #9
0x0032b0:	ldr     	r2, [r4, #4]
0x0032b2:	bl      	#0x29e0
0x0032b6:	movs    	r1, #0
0x0032b8:	str     	r1, [sp]
0x0032ba:	str     	r1, [sp, #4]
0x0032bc:	movs    	r2, #0
0x0032be:	str     	r2, [sp, #8]
0x0032c0:	movs    	r1, #9
0x0032c2:	adds    	r3, r5, #0
0x0032c4:	movs    	r0, #0xf1
0x0032c6:	lsls    	r0, r0, #9
0x0032c8:	ldr     	r2, [r4, #0x20]
0x0032ca:	bl      	#0x29e0
0x0032ce:	movs    	r1, #0
0x0032d0:	movs    	r2, #0
0x0032d2:	str     	r2, [sp, #8]
0x0032d4:	str     	r1, [sp]
0x0032d6:	str     	r1, [sp, #4]
0x0032d8:	adds    	r3, r5, #0
0x0032da:	adds    	r2, r4, #0
0x0032dc:	movs    	r1, #9
0x0032de:	movs    	r0, #0xf1
0x0032e0:	lsls    	r0, r0, #9
0x0032e2:	bl      	#0x29e0
0x0032e6:	add     	sp, #0xc
0x0032e8:	pop     	{r4, r5, pc}

; ===== candidate_0032ec =====
0x0032ec:	push    	{r4, r5, r6, lr}
0x0032ee:	sub     	sp, #0x10
0x0032f0:	movs    	r1, #0
0x0032f2:	str     	r1, [sp]
0x0032f4:	str     	r1, [sp, #4]
0x0032f6:	movs    	r4, #0
0x0032f8:	movs    	r2, #0
0x0032fa:	adds    	r3, r4, #0
0x0032fc:	movs    	r1, #0xe1
0x0032fe:	movs    	r0, #0xf1
0x003300:	lsls    	r0, r0, #9
0x003302:	str     	r2, [sp, #8]
0x003304:	bl      	#0x29e0
0x003308:	movs    	r1, #0
0x00330a:	adds    	r5, r0, #0
0x00330c:	movs    	r2, #0
0x00330e:	str     	r2, [sp, #8]
0x003310:	str     	r1, [sp]
0x003312:	str     	r1, [sp, #4]
0x003314:	movs    	r1, #0xe1
0x003316:	movs    	r2, #1
0x003318:	movs    	r0, #0xf1
0x00331a:	adds    	r3, r4, #0
0x00331c:	lsls    	r0, r0, #9
0x00331e:	bl      	#0x29e0
0x003322:	movs    	r1, #0
0x003324:	adds    	r6, r0, #0
0x003326:	movs    	r2, #0
0x003328:	str     	r2, [sp, #8]
0x00332a:	str     	r1, [sp]
0x00332c:	str     	r1, [sp, #4]
0x00332e:	adds    	r3, r4, #0
0x003330:	adds    	r2, r5, #0
0x003332:	movs    	r1, #0x12
0x003334:	movs    	r0, #0xf1
0x003336:	lsls    	r0, r0, #9
0x003338:	bl      	#0x29e0
0x00333c:	movs    	r1, #0
0x00333e:	movs    	r2, #0
0x003340:	str     	r2, [sp, #8]
0x003342:	str     	r1, [sp]
0x003344:	str     	r1, [sp, #4]
0x003346:	adds    	r3, r4, #0
0x003348:	adds    	r2, r6, #0
0x00334a:	movs    	r1, #0x12
0x00334c:	movs    	r0, #0xf1
0x00334e:	lsls    	r0, r0, #9
0x003350:	bl      	#0x29e0
0x003354:	movs    	r1, #0
0x003356:	str     	r1, [sp]
0x003358:	str     	r1, [sp, #4]
0x00335a:	movs    	r2, #0
0x00335c:	movs    	r1, #0x14
0x00335e:	adds    	r3, r4, #0
0x003360:	movs    	r0, #0xf1
0x003362:	lsls    	r0, r0, #9
0x003364:	str     	r2, [sp, #8]
0x003366:	bl      	#0x29e0
0x00336a:	movs    	r1, #0
0x00336c:	movs    	r2, #0
0x00336e:	str     	r2, [sp, #8]
0x003370:	str     	r1, [sp]
0x003372:	str     	r1, [sp, #4]
0x003374:	movs    	r1, #0x14
0x003376:	movs    	r2, #1
0x003378:	adds    	r3, r4, #0
0x00337a:	movs    	r0, #0xf1
0x00337c:	lsls    	r0, r0, #9
0x00337e:	bl      	#0x29e0
0x003382:	add     	sp, #0x10
0x003384:	pop     	{r4, r5, r6, pc}

; ===== candidate_003388 =====
0x003388:	push    	{r4, r5, r6, lr}
0x00338a:	movs    	r6, #0xf1
0x00338c:	ldr     	r3, [r0, #0x2c]
0x00338e:	lsls    	r6, r6, #9
0x003390:	movs    	r5, #0
0x003392:	adds    	r4, r0, #0
0x003394:	cmp     	r3, #0
0x003396:	sub     	sp, #0x10
0x003398:	beq     	#0x33b0
0x00339a:	movs    	r2, #0
0x00339c:	movs    	r1, #0
0x00339e:	str     	r2, [sp, #8]
0x0033a0:	adds    	r2, r3, #0
0x0033a2:	str     	r1, [sp]
0x0033a4:	str     	r1, [sp, #4]
0x0033a6:	movs    	r1, #9
0x0033a8:	adds    	r3, r5, #0
0x0033aa:	adds    	r0, r6, #0
0x0033ac:	bl      	#0x29e0
0x0033b0:	ldr     	r3, [r4, #8]
0x0033b2:	cmp     	r3, #0
0x0033b4:	beq     	#0x33cc
0x0033b6:	movs    	r2, #0
0x0033b8:	movs    	r1, #0
0x0033ba:	str     	r2, [sp, #8]
0x0033bc:	adds    	r2, r3, #0
0x0033be:	str     	r1, [sp]
0x0033c0:	str     	r1, [sp, #4]
0x0033c2:	movs    	r1, #9
0x0033c4:	adds    	r3, r5, #0
0x0033c6:	adds    	r0, r6, #0
0x0033c8:	bl      	#0x29e0
0x0033cc:	movs    	r1, #0
0x0033ce:	str     	r1, [sp]
0x0033d0:	str     	r1, [sp, #4]
0x0033d2:	movs    	r2, #0
0x0033d4:	str     	r2, [sp, #8]
0x0033d6:	movs    	r1, #9
0x0033d8:	adds    	r3, r5, #0
0x0033da:	adds    	r0, r6, #0
0x0033dc:	ldr     	r2, [r4, #4]
0x0033de:	bl      	#0x29e0
0x0033e2:	movs    	r1, #0
0x0033e4:	movs    	r2, #0
0x0033e6:	str     	r2, [sp, #8]
0x0033e8:	str     	r1, [sp]
0x0033ea:	str     	r1, [sp, #4]
0x0033ec:	adds    	r3, r5, #0
0x0033ee:	adds    	r2, r4, #0
0x0033f0:	movs    	r1, #9
0x0033f2:	movs    	r0, #0xf1
0x0033f4:	lsls    	r0, r0, #9
0x0033f6:	bl      	#0x29e0
0x0033fa:	add     	sp, #0x10
0x0033fc:	pop     	{r4, r5, r6, pc}

; ===== candidate_003400 =====
0x003400:	push    	{r4, r5, r6, r7, lr}
0x003402:	ldr     	r3, [r0, #4]
0x003404:	movs    	r7, #0
0x003406:	adds    	r4, r0, #0
0x003408:	cmp     	r3, #0
0x00340a:	sub     	sp, #0xc
0x00340c:	beq     	#0x3426
0x00340e:	movs    	r2, #0
0x003410:	movs    	r1, #0
0x003412:	str     	r2, [sp, #8]
0x003414:	adds    	r2, r3, #0
0x003416:	str     	r1, [sp]
0x003418:	str     	r1, [sp, #4]
0x00341a:	movs    	r1, #9
0x00341c:	adds    	r3, r7, #0
0x00341e:	movs    	r0, #0xf1
0x003420:	lsls    	r0, r0, #9
0x003422:	bl      	#0x29e0
0x003426:	ldr     	r3, [r4, #0x14]
0x003428:	cmp     	r3, #0
0x00342a:	beq     	#0x3444
0x00342c:	movs    	r2, #0
0x00342e:	movs    	r1, #0
0x003430:	str     	r2, [sp, #8]
0x003432:	adds    	r2, r3, #0
0x003434:	str     	r1, [sp]
0x003436:	str     	r1, [sp, #4]
0x003438:	movs    	r1, #9
0x00343a:	adds    	r3, r7, #0
0x00343c:	movs    	r0, #0xf1
0x00343e:	lsls    	r0, r0, #9
0x003440:	bl      	#0x29e0
0x003444:	ldr     	r3, [r4, #0x18]
0x003446:	cmp     	r3, #0
0x003448:	beq     	#0x3462
0x00344a:	movs    	r2, #0
0x00344c:	movs    	r1, #0
0x00344e:	str     	r2, [sp, #8]
0x003450:	adds    	r2, r3, #0
0x003452:	str     	r1, [sp]
0x003454:	str     	r1, [sp, #4]
0x003456:	movs    	r1, #6
0x003458:	adds    	r3, r7, #0
0x00345a:	movs    	r0, #0xf1
0x00345c:	lsls    	r0, r0, #9
0x00345e:	bl      	#0x29e0
0x003462:	ldr     	r3, [r4, #0xc]
0x003464:	cmp     	r3, #0
0x003466:	beq     	#0x34b2
0x003468:	movs    	r2, #0
0x00346a:	movs    	r1, #0
0x00346c:	str     	r2, [sp, #8]
0x00346e:	adds    	r2, r3, #0
0x003470:	str     	r1, [sp]
0x003472:	str     	r1, [sp, #4]
0x003474:	movs    	r1, #0x11
0x003476:	movs    	r3, #4
0x003478:	movs    	r0, #0xf1
0x00347a:	lsls    	r0, r0, #9
0x00347c:	bl      	#0x29e0
0x003480:	adds    	r6, r0, #0
0x003482:	movs    	r5, #0
0x003484:	cmp     	r0, #0
0x003486:	ble     	#0x3498
0x003488:	ldr     	r0, [r4, #0xc]
0x00348a:	lsls    	r1, r5, #2
0x00348c:	ldr     	r0, [r0, r1]
0x00348e:	bl      	#0x3388
0x003492:	adds    	r5, #1
0x003494:	cmp     	r5, r6
0x003496:	blt     	#0x3488
0x003498:	movs    	r1, #0
0x00349a:	str     	r1, [sp]
0x00349c:	str     	r1, [sp, #4]
0x00349e:	movs    	r2, #0
0x0034a0:	str     	r2, [sp, #8]
0x0034a2:	movs    	r1, #9
0x0034a4:	adds    	r3, r7, #0
0x0034a6:	movs    	r0, #0xf1
0x0034a8:	lsls    	r0, r0, #9
0x0034aa:	ldr     	r2, [r4, #0xc]
0x0034ac:	bl      	#0x29e0
0x0034b0:	str     	r7, [r4, #0xc]
0x0034b2:	movs    	r1, #0
0x0034b4:	movs    	r2, #0
0x0034b6:	str     	r2, [sp, #8]
0x0034b8:	str     	r1, [sp]
0x0034ba:	str     	r1, [sp, #4]
0x0034bc:	adds    	r3, r7, #0
0x0034be:	adds    	r2, r4, #0
0x0034c0:	movs    	r1, #9
0x0034c2:	movs    	r0, #0xf1
0x0034c4:	lsls    	r0, r0, #9
0x0034c6:	bl      	#0x29e0
0x0034ca:	add     	sp, #0xc
0x0034cc:	pop     	{r4, r5, r6, r7, pc}
