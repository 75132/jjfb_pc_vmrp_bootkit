; fallback candidate disassembly from Thumb prologues; true code is ARM entry + Thumb functions.

; ARM entry
0x000008:	push    	{r4, lr}
0x00000c:	mov     	r4, r0
0x000010:	mov     	r0, r4
0x000014:	blx     	#0x4330
0x000018:	pop     	{r4, pc}
0x00001c:	andeq   	r4, r0, r8, ror r7
0x000020:	ands    	r2, r0, #128, #8
0x000024:	rsbmi   	r0, r0, #0
0x000028:	eors    	r3, r2, r1, asr #32
0x00002c:	rsbhs   	r1, r1, #0
0x000030:	rsbs    	ip, r0, r1, lsr #3
0x000034:	blo     	#0xbc
0x000038:	rsbs    	ip, r0, r1, lsr #8
0x00003c:	blo     	#0x80
0x000040:	lsl     	r0, r0, #8
0x000044:	orr     	r2, r2, #0xff000000
0x000048:	rsbs    	ip, r0, r1, lsr #4
0x00004c:	blo     	#0xb0
0x000050:	rsbs    	ip, r0, r1, lsr #8
0x000054:	blo     	#0x80
0x000058:	lsl     	r0, r0, #8
0x00005c:	orr     	r2, r2, #0xff0000
0x000060:	rsbs    	ip, r0, r1, lsr #8
0x000064:	lslhs   	r0, r0, #8
0x000068:	orrhs   	r2, r2, #0xff00
0x00006c:	rsbs    	ip, r0, r1, lsr #4
0x000070:	blo     	#0xb0
0x000074:	rsbs    	ip, r0, #0
0x000078:	bhs     	#0xf8
0x00007c:	lsrhs   	r0, r0, #8
0x000080:	rsbs    	ip, r0, r1, lsr #7
0x000084:	subhs   	r1, r1, r0, lsl #7
0x000088:	adc     	r2, r2, r2
0x00008c:	rsbs    	ip, r0, r1, lsr #6
0x000090:	subhs   	r1, r1, r0, lsl #6
0x000094:	adc     	r2, r2, r2
0x000098:	rsbs    	ip, r0, r1, lsr #5
0x00009c:	subhs   	r1, r1, r0, lsl #5
0x0000a0:	adc     	r2, r2, r2
0x0000a4:	rsbs    	ip, r0, r1, lsr #4
0x0000a8:	subhs   	r1, r1, r0, lsl #4
0x0000ac:	adc     	r2, r2, r2
0x0000b0:	rsbs    	ip, r0, r1, lsr #3
0x0000b4:	subhs   	r1, r1, r0, lsl #3
0x0000b8:	adc     	r2, r2, r2
0x0000bc:	rsbs    	ip, r0, r1, lsr #2
0x0000c0:	subhs   	r1, r1, r0, lsl #2
0x0000c4:	adc     	r2, r2, r2
0x0000c8:	rsbs    	ip, r0, r1, lsr #1
0x0000cc:	subhs   	r1, r1, r0, lsl #1
0x0000d0:	adc     	r2, r2, r2
0x0000d4:	rsbs    	ip, r0, r1
0x0000d8:	subhs   	r1, r1, r0
0x0000dc:	adcs    	r2, r2, r2
0x0000e0:	bhs     	#0x7c
0x0000e4:	eors    	r0, r2, r3, asr #31
0x0000e8:	add     	r0, r0, r3, lsr #31
0x0000ec:	rsbhs   	r1, r1, #0
0x0000f0:	bx      	lr
0x0000f4:	andeq   	r4, r0, r8, ror r7
0x0000f8:	mov     	r0, #2
0x0000fc:	mov     	r1, #2
0x000100:	b       	#0x118
0x000104:	strmi   	r4, [r8, -r0, lsl #14]

; ===== candidate_000008 =====
0x000008:	ands    	r0, r2
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	asrs    	r5, r0, #3

; ===== candidate_00000a =====
0x00000a:	stmdb   	sp!, {lr}
0x00000e:	b       	#0x352
0x000010:	movs    	r4, r0
0x000012:	b       	#0x356
0x000014:	asrs    	r5, r0, #3

; ===== candidate_00011a =====
0x00011a:	stmdb   	sp!, {r2}

; ===== candidate_000134 =====
0x000134:	push    	{r4, r5, r6, lr}
0x000136:	ldr     	r6, [pc, #0x38]
0x000138:	adds    	r5, r1, #0
0x00013a:	adds    	r1, r0, #0
0x00013c:	adds    	r4, r0, #0
0x00013e:	add     	r6, pc
0x000140:	adds    	r0, r6, #0
0x000142:	bl      	#0x146
0x000146:	adds    	r2, r0, #0
0x000148:	cmp     	r0, r6
0x00014a:	bne     	#0x15a
0x00014c:	adds    	r1, r5, #0
0x00014e:	adds    	r0, r4, #0
0x000150:	bl      	#0x194
0x000154:	pop     	{r4, r5, r6}
0x000156:	pop     	{r3}
0x000158:	bx      	r3
0x00015a:	ldr     	r0, [pc, #0x18]
0x00015c:	add     	r0, pc
0x00015e:	cmp     	r2, r0
0x000160:	beq     	#0x16a
0x000162:	adds    	r1, r5, #0
0x000164:	adds    	r0, r4, #0
0x000166:	bl      	#0x108
0x00016a:	movs    	r0, #0
0x00016c:	b       	#0x154
0x00016e:	movs    	r0, r0
0x000170:	mcr2    	p15, #6, pc, c5, c7, #7
0x000174:	mcr2    	p15, #5, pc, c5, c7, #7
0x000178:	bx      	pc

; ===== candidate_000194 =====
0x000194:	push    	{r3, r4, r5, lr}
0x000196:	subs    	r2, r0, #1
0x000198:	cmp     	r2, #0xd
0x00019a:	adr     	r4, #0x90
0x00019c:	bhs     	#0x1ec
0x00019e:	movs    	r2, #0x17
0x0001a0:	ldr     	r3, [pc, #0x8c]
0x0001a2:	muls    	r2, r0, r2
0x0001a4:	add     	r3, pc
0x0001a6:	adds    	r5, r2, r3
0x0001a8:	subs    	r5, #0x17
0x0001aa:	cmp     	r0, #2
0x0001ac:	bne     	#0x1d8
0x0001ae:	lsls    	r0, r1, #5
0x0001b0:	bpl     	#0x1b6
0x0001b2:	adr     	r4, #0x80
0x0001b4:	b       	#0x1ee
0x0001b6:	ldr     	r0, [pc, #0x90]
0x0001b8:	ands    	r0, r1
0x0001ba:	beq     	#0x1c0
0x0001bc:	adr     	r4, #0x8c
0x0001be:	b       	#0x1ee
0x0001c0:	lsls    	r0, r1, #3
0x0001c2:	bpl     	#0x1c8
0x0001c4:	adr     	r4, #0x94
0x0001c6:	b       	#0x1ee
0x0001c8:	lsls    	r0, r1, #2
0x0001ca:	bpl     	#0x1d0
0x0001cc:	adr     	r4, #0x98
0x0001ce:	b       	#0x1ee
0x0001d0:	lsls    	r0, r1, #1
0x0001d2:	bpl     	#0x1ee
0x0001d4:	adr     	r4, #0x9c
0x0001d6:	b       	#0x1ee
0x0001d8:	cmp     	r0, #8
0x0001da:	bne     	#0x1e0
0x0001dc:	adds    	r4, r1, #0
0x0001de:	b       	#0x1ee
0x0001e0:	cmp     	r0, #9
0x0001e2:	bne     	#0x1ee
0x0001e4:	cmp     	r1, #1
0x0001e6:	bne     	#0x1ee
0x0001e8:	adr     	r5, #0x98
0x0001ea:	b       	#0x1ee
0x0001ec:	adr     	r5, #0xac
0x0001ee:	movs    	r0, #0xa
0x0001f0:	bl      	#0x2b4
0x0001f4:	ldrb    	r0, [r5]
0x0001f6:	cmp     	r0, #0
0x0001f8:	beq     	#0x208
0x0001fa:	ldrb    	r0, [r5]
0x0001fc:	adds    	r5, #1
0x0001fe:	bl      	#0x2b4
0x000202:	ldrb    	r0, [r5]
0x000204:	cmp     	r0, #0
0x000206:	bne     	#0x1fa
0x000208:	ldrb    	r0, [r4]
0x00020a:	cmp     	r0, #0
0x00020c:	beq     	#0x21c
0x00020e:	ldrb    	r0, [r4]
0x000210:	adds    	r4, #1
0x000212:	bl      	#0x2b4
0x000216:	ldrb    	r0, [r4]
0x000218:	cmp     	r0, #0
0x00021a:	bne     	#0x20e
0x00021c:	movs    	r0, #0xa
0x00021e:	bl      	#0x2b4
0x000222:	pop     	{r3, r4, r5}
0x000224:	pop     	{r3}
0x000226:	movs    	r0, #1
0x000228:	bx      	r3
0x00022a:	movs    	r0, r0
0x00022c:	movs    	r0, r0
0x00022e:	movs    	r0, r0
0x000230:	str     	r4, [r3, r0]
0x000232:	movs    	r0, r0
0x000234:	ldr     	r1, [r1, #0x64]
0x000236:	str     	r6, [r6, #0x14]
0x000238:	ldr     	r4, [r5, #0x14]
0x00023a:	movs    	r0, #0x64
0x00023c:	strb    	r7, [r1, #1]
0x00023e:	strb    	r5, [r4, #9]
0x000240:	strb    	r1, [r4, #0x11]
0x000242:	ldr     	r1, [r5, #0x74]
0x000244:	lsls    	r6, r5, #1
0x000246:	movs    	r0, r0
0x000248:	movs    	r2, r0
0x00024a:	lsrs    	r0, r0, #0x20
0x00024c:	ldr     	r4, [r0, #0x14]
0x00024e:	ldr     	r6, [r6, #0x14]
0x000250:	str     	r4, [r4, #0x54]
0x000252:	tst     	r0, r4
0x000254:	movs    	r0, #0x79
0x000256:	str     	r2, [r3, #0x54]
0x000258:	ldr     	r2, [r6, #0x74]
0x00025a:	movs    	r0, r0
0x00025c:	strb    	r7, [r1, #0x19]
0x00025e:	strb    	r5, [r4, #9]
0x000260:	ldr     	r6, [r4, #0x44]
0x000262:	strb    	r7, [r5, #0x1d]
0x000264:	movs    	r0, r0
0x000266:	movs    	r0, r0
0x000268:	ldr     	r5, [r2, #0x64]
0x00026a:	str     	r4, [r4, #0x54]
0x00026c:	str     	r2, [r6, #0x64]
0x00026e:	ldr     	r4, [r5, #0x74]
0x000270:	lsls    	r7, r6, #1
0x000272:	movs    	r0, r0
0x000274:	ldr     	r1, [r1, #0x64]
0x000276:	ldrb    	r5, [r4, #1]
0x000278:	str     	r1, [r4, #0x34]
0x00027a:	movs    	r0, #0x74
0x00027c:	str     	r2, [r2, #0x54]
0x00027e:	strb    	r3, [r6, #0x15]
0x000280:	strb    	r4, [r5, #0x11]
0x000282:	movs    	r0, r0
0x000284:	movs    	r0, #0x3a
0x000286:	str     	r0, [r1, #0x54]
0x000288:	strb    	r1, [r4, #1]
0x00028a:	ldr     	r0, [r4, #0x50]
0x00028c:	ldr     	r5, [r4, #0x54]
0x00028e:	strb    	r7, [r5, #9]
0x000290:	movs    	r0, #0x79
0x000292:	ldr     	r3, [r4, #0x74]
0x000294:	strb    	r2, [r6, #9]
0x000296:	strb    	r5, [r6, #1]
0x000298:	str     	r4, [r6, #0x54]
0x00029a:	lsls    	r4, r4, #1
0x00029c:	ldr     	r5, [r2, #0x64]
0x00029e:	ldr     	r3, [r5, #0x64]
0x0002a0:	strb    	r7, [r5, #0x1d]
0x0002a2:	movs    	r0, #0x6e
0x0002a4:	ldr     	r3, [r6, #0x14]
0x0002a6:	ldr     	r7, [r4, #0x64]
0x0002a8:	ldr     	r1, [r4, #0x44]
0x0002aa:	movs    	r0, r0
0x0002ac:	bx      	pc

; ===== candidate_0002b4 =====
0x0002b4:	push    	{r3, lr}
0x0002b6:	add     	r3, sp, #0
0x0002b8:	strb    	r0, [r3]
0x0002ba:	movs    	r0, #3
0x0002bc:	mov     	r1, sp
0x0002be:	svc     	#0xab
0x0002c0:	add     	sp, #4
0x0002c2:	pop     	{r3}
0x0002c4:	bx      	r3
0x0002c6:	movs    	r0, r0
0x0002c8:	movs    	r0, r1
0x0002ca:	b       	#0xfffffe0c
0x0002cc:	asrs    	r0, r1, #0x20
0x0002ce:	b       	#0xfffffe10
0x0002d0:	movs    	r1, r0
0x0002d2:	b       	#0x3d6
0x0002d4:	vrhadd.u16	d14, d14, d31
0x0002d8:	movs    	r0, r2
0x0002da:	movs    	r0, r0
0x0002dc:	lsls    	r0, r4, #6
0x0002de:	movs    	r0, r0
0x0002e0:	str     	r0, [sp]
0x0002e2:	b       	#0x626
0x0002e4:	vrhadd.u16	d14, d14, d31
0x0002e8:	adds    	r0, #0x14
0x0002ea:	b       	#0xfffffe2c
0x0002ec:	cmp     	r7, #0xc0
0x0002ee:	b       	#0x632
0x0002f0:	stm     	r0!, {r0, r1, r4, r7}
0x0002f2:	b       	#0x478
0x0002f4:	adds    	r0, #2
0x0002f6:	b       	#0xaba
0x0002f8:	asrs    	r1, r0, #0x20
0x0002fa:	b       	#0x3c2
0x0002fc:	lsls    	r3, r2, #6
0x0002fe:	b       	#0x342
0x000300:	vrhadd.u16	d14, d14, d31
0x000304:	strb    	r6, [r2, r5]
0x000306:	strb    	r5, [r2, r5]
0x000308:	push    	{r4, r5, lr}
0x00030a:	ldr     	r4, [pc, #0xb4]
0x00030c:	movs    	r2, #0x1c
0x00030e:	add     	r4, pc
0x000310:	ldr     	r0, [r4, #0x38]
0x000312:	movs    	r1, #0
0x000314:	ldr     	r3, [r0, #0x38]
0x000316:	ldr     	r0, [pc, #0xac]
0x000318:	sub     	sp, #0xc
0x00031a:	add     	r0, sb
0x00031c:	blx     	r3
0x00031e:	movs    	r2, #0
0x000320:	movs    	r0, #0
0x000322:	str     	r0, [sp]
0x000324:	ldr     	r1, [pc, #0x9c]
0x000326:	movs    	r3, #0
0x000328:	add     	r1, sb
0x00032a:	str     	r1, [sp, #4]
0x00032c:	movs    	r1, #0x64
0x00032e:	movs    	r0, #1
0x000330:	str     	r2, [sp, #8]
0x000332:	bl      	#0x4408
0x000336:	ldr     	r1, [pc, #0x8c]
0x000338:	movs    	r0, #0
0x00033a:	add     	r1, sb
0x00033c:	subs    	r1, #0x7c
0x00033e:	str     	r0, [r1, #8]
0x000340:	ldr     	r5, [pc, #0x80]
0x000342:	str     	r0, [r1, #0x10]
0x000344:	str     	r0, [r1, #0xc]
0x000346:	add     	r5, sb
0x000348:	subs    	r5, #0xfc
0x00034a:	movs    	r0, #1
0x00034c:	str     	r0, [r5, #0x18]
0x00034e:	ldr     	r0, [r4, #0x38]
0x000350:	ldr     	r2, [pc, #0x74]
0x000352:	ldr     	r1, [r0, #0x68]
0x000354:	add     	r2, sb
0x000356:	str     	r1, [r5, #0x2c]
0x000358:	ldr     	r1, [r0, #0xc]
0x00035a:	ldr     	r4, [pc, #0x70]
0x00035c:	str     	r1, [r5, #0x30]
0x00035e:	ldr     	r1, [r0, #0x10]
0x000360:	str     	r1, [r5, #0x34]
0x000362:	ldr     	r1, [r0, #0x14]
0x000364:	str     	r1, [r5, #0x38]
0x000366:	ldr     	r1, [r0, #0x18]
0x000368:	str     	r1, [r5, #0x3c]
0x00036a:	ldr     	r1, [r0, #0x1c]
0x00036c:	str     	r1, [r5, #0x40]
0x00036e:	ldr     	r1, [r0, #0x20]
0x000370:	str     	r1, [r5, #0x44]
0x000372:	ldr     	r1, [r0, #0x24]
0x000374:	str     	r1, [r5, #0x48]
0x000376:	ldr     	r1, [r0, #0x28]
0x000378:	str     	r1, [r5, #0x4c]
0x00037a:	ldr     	r1, [r0, #0x2c]
0x00037c:	str     	r1, [r5, #0x50]
0x00037e:	ldr     	r1, [r0, #0x30]
0x000380:	str     	r1, [r5, #0x54]
0x000382:	ldr     	r1, [r0, #0x34]
0x000384:	str     	r1, [r5, #0x58]
0x000386:	ldr     	r1, [r0, #0x38]
0x000388:	str     	r1, [r5, #0x5c]
0x00038a:	ldr     	r1, [r0, #0x3c]
0x00038c:	str     	r1, [r5, #0x60]
0x00038e:	ldr     	r1, [r0, #0x40]
0x000390:	str     	r1, [r5, #0x64]
0x000392:	ldr     	r1, [r0, #0x44]
0x000394:	str     	r1, [r5, #0x68]
0x000396:	ldr     	r1, [r0, #0x48]
0x000398:	str     	r1, [r5, #0x6c]
0x00039a:	ldr     	r1, [r0, #0x4c]
0x00039c:	str     	r1, [r5, #0x70]
0x00039e:	movs    	r1, #0
0x0003a0:	str     	r1, [r2]
0x0003a2:	movs    	r1, #1
0x0003a4:	lsls    	r1, r1, #9
0x0003a6:	adds    	r0, r0, r1
0x0003a8:	ldr     	r3, [r0, #8]
0x0003aa:	movs    	r1, #7
0x0003ac:	adds    	r2, r4, #0
0x0003ae:	movs    	r0, #0
0x0003b0:	blx     	r3
0x0003b2:	cmp     	r0, r4
0x0003b4:	bne     	#0x3ba
0x0003b6:	subs    	r0, #2
0x0003b8:	str     	r0, [r5, #0x28]
0x0003ba:	add     	sp, #0xc
0x0003bc:	pop     	{r4, r5, pc}

; ===== candidate_000308 =====
0x000308:	push    	{r4, r5, lr}
0x00030a:	ldr     	r4, [pc, #0xb4]
0x00030c:	movs    	r2, #0x1c
0x00030e:	add     	r4, pc
0x000310:	ldr     	r0, [r4, #0x38]
0x000312:	movs    	r1, #0
0x000314:	ldr     	r3, [r0, #0x38]
0x000316:	ldr     	r0, [pc, #0xac]
0x000318:	sub     	sp, #0xc
0x00031a:	add     	r0, sb
0x00031c:	blx     	r3
0x00031e:	movs    	r2, #0
0x000320:	movs    	r0, #0
0x000322:	str     	r0, [sp]
0x000324:	ldr     	r1, [pc, #0x9c]
0x000326:	movs    	r3, #0
0x000328:	add     	r1, sb
0x00032a:	str     	r1, [sp, #4]
0x00032c:	movs    	r1, #0x64
0x00032e:	movs    	r0, #1
0x000330:	str     	r2, [sp, #8]
0x000332:	bl      	#0x4408
0x000336:	ldr     	r1, [pc, #0x8c]
0x000338:	movs    	r0, #0
0x00033a:	add     	r1, sb
0x00033c:	subs    	r1, #0x7c
0x00033e:	str     	r0, [r1, #8]
0x000340:	ldr     	r5, [pc, #0x80]
0x000342:	str     	r0, [r1, #0x10]
0x000344:	str     	r0, [r1, #0xc]
0x000346:	add     	r5, sb
0x000348:	subs    	r5, #0xfc
0x00034a:	movs    	r0, #1
0x00034c:	str     	r0, [r5, #0x18]
0x00034e:	ldr     	r0, [r4, #0x38]
0x000350:	ldr     	r2, [pc, #0x74]
0x000352:	ldr     	r1, [r0, #0x68]
0x000354:	add     	r2, sb
0x000356:	str     	r1, [r5, #0x2c]
0x000358:	ldr     	r1, [r0, #0xc]
0x00035a:	ldr     	r4, [pc, #0x70]
0x00035c:	str     	r1, [r5, #0x30]
0x00035e:	ldr     	r1, [r0, #0x10]
0x000360:	str     	r1, [r5, #0x34]
0x000362:	ldr     	r1, [r0, #0x14]
0x000364:	str     	r1, [r5, #0x38]
0x000366:	ldr     	r1, [r0, #0x18]
0x000368:	str     	r1, [r5, #0x3c]
0x00036a:	ldr     	r1, [r0, #0x1c]
0x00036c:	str     	r1, [r5, #0x40]
0x00036e:	ldr     	r1, [r0, #0x20]
0x000370:	str     	r1, [r5, #0x44]
0x000372:	ldr     	r1, [r0, #0x24]
0x000374:	str     	r1, [r5, #0x48]
0x000376:	ldr     	r1, [r0, #0x28]
0x000378:	str     	r1, [r5, #0x4c]
0x00037a:	ldr     	r1, [r0, #0x2c]
0x00037c:	str     	r1, [r5, #0x50]
0x00037e:	ldr     	r1, [r0, #0x30]
0x000380:	str     	r1, [r5, #0x54]
0x000382:	ldr     	r1, [r0, #0x34]
0x000384:	str     	r1, [r5, #0x58]
0x000386:	ldr     	r1, [r0, #0x38]
0x000388:	str     	r1, [r5, #0x5c]
0x00038a:	ldr     	r1, [r0, #0x3c]
0x00038c:	str     	r1, [r5, #0x60]
0x00038e:	ldr     	r1, [r0, #0x40]
0x000390:	str     	r1, [r5, #0x64]
0x000392:	ldr     	r1, [r0, #0x44]
0x000394:	str     	r1, [r5, #0x68]
0x000396:	ldr     	r1, [r0, #0x48]
0x000398:	str     	r1, [r5, #0x6c]
0x00039a:	ldr     	r1, [r0, #0x4c]
0x00039c:	str     	r1, [r5, #0x70]
0x00039e:	movs    	r1, #0
0x0003a0:	str     	r1, [r2]
0x0003a2:	movs    	r1, #1
0x0003a4:	lsls    	r1, r1, #9
0x0003a6:	adds    	r0, r0, r1
0x0003a8:	ldr     	r3, [r0, #8]
0x0003aa:	movs    	r1, #7
0x0003ac:	adds    	r2, r4, #0
0x0003ae:	movs    	r0, #0
0x0003b0:	blx     	r3
0x0003b2:	cmp     	r0, r4
0x0003b4:	bne     	#0x3ba
0x0003b6:	subs    	r0, #2
0x0003b8:	str     	r0, [r5, #0x28]
0x0003ba:	add     	sp, #0xc
0x0003bc:	pop     	{r4, r5, pc}

; ===== candidate_0003d0 =====
0x0003d0:	push    	{r4, r5, r6, r7, lr}
0x0003d2:	sub     	sp, #0xc
0x0003d4:	movs    	r1, #0
0x0003d6:	movs    	r2, #0
0x0003d8:	str     	r2, [sp, #8]
0x0003da:	str     	r1, [sp]
0x0003dc:	str     	r1, [sp, #4]
0x0003de:	movs    	r6, #0xf1
0x0003e0:	movs    	r5, #0
0x0003e2:	adds    	r3, r5, #0
0x0003e4:	lsls    	r6, r6, #9
0x0003e6:	movs    	r1, #0x44
0x0003e8:	adds    	r2, r0, #0
0x0003ea:	adds    	r4, r0, #0
0x0003ec:	adds    	r0, r6, #0
0x0003ee:	bl      	#0x4408
0x0003f2:	movs    	r1, #0
0x0003f4:	str     	r1, [sp]
0x0003f6:	str     	r1, [sp, #4]
0x0003f8:	movs    	r2, #0
0x0003fa:	str     	r2, [sp, #8]
0x0003fc:	movs    	r1, #0x45
0x0003fe:	adds    	r3, r5, #0
0x000400:	adds    	r0, r6, #0
0x000402:	ldr     	r2, [r4, #8]
0x000404:	bl      	#0x4408
0x000408:	movs    	r1, #0
0x00040a:	movs    	r2, #0
0x00040c:	str     	r2, [sp, #8]
0x00040e:	str     	r1, [sp]
0x000410:	str     	r1, [sp, #4]
0x000412:	movs    	r1, #0x14
0x000414:	movs    	r2, #0xcb
0x000416:	adds    	r3, r0, #0
0x000418:	adds    	r0, r6, #0
0x00041a:	bl      	#0x4408
0x00041e:	movs    	r1, #0
0x000420:	str     	r1, [sp]
0x000422:	str     	r1, [sp, #4]
0x000424:	movs    	r2, #0
0x000426:	str     	r2, [sp, #8]
0x000428:	movs    	r1, #0x45
0x00042a:	adds    	r3, r5, #0
0x00042c:	adds    	r0, r6, #0
0x00042e:	ldr     	r2, [r4, #8]
0x000430:	bl      	#0x4408
0x000434:	movs    	r1, #0
0x000436:	movs    	r2, #0
0x000438:	str     	r2, [sp, #8]
0x00043a:	str     	r1, [sp]
0x00043c:	str     	r1, [sp, #4]
0x00043e:	movs    	r1, #0x14
0x000440:	movs    	r2, #0xcc
0x000442:	adds    	r3, r0, #0
0x000444:	adds    	r0, r6, #0
0x000446:	bl      	#0x4408
0x00044a:	ldr     	r4, [pc, #0x144]
0x00044c:	add     	r4, pc
0x00044e:	movs    	r1, #0
0x000450:	movs    	r2, #0
0x000452:	str     	r2, [sp, #8]
0x000454:	str     	r1, [sp]
0x000456:	str     	r1, [sp, #4]
0x000458:	movs    	r1, #0xe1
0x00045a:	movs    	r2, #0x74
0x00045c:	adds    	r3, r5, #0
0x00045e:	adds    	r0, r6, #0
0x000460:	bl      	#0x4408
0x000464:	ldr     	r7, [pc, #0x12c]
0x000466:	add     	r7, pc
0x000468:	cmp     	r0, #0
0x00046a:	bne     	#0x4c6
0x00046c:	movs    	r1, #0
0x00046e:	str     	r1, [sp]
0x000470:	str     	r1, [sp, #4]
0x000472:	movs    	r2, #0
0x000474:	movs    	r1, #0x2c
0x000476:	adds    	r3, r5, #0
0x000478:	adds    	r0, r6, #0
0x00047a:	str     	r2, [sp, #8]
0x00047c:	bl      	#0x4408
0x000480:	movs    	r1, #0
0x000482:	movs    	r2, #0
0x000484:	str     	r2, [sp, #8]
0x000486:	str     	r1, [sp]
0x000488:	str     	r1, [sp, #4]
0x00048a:	movs    	r1, #0x67
0x00048c:	movs    	r2, #0x14
0x00048e:	adds    	r3, r5, #0
0x000490:	adds    	r0, r6, #0
0x000492:	bl      	#0x4408
0x000496:	movs    	r1, #0
0x000498:	movs    	r2, #0
0x00049a:	str     	r2, [sp, #8]
0x00049c:	str     	r1, [sp]
0x00049e:	str     	r1, [sp, #4]
0x0004a0:	movs    	r1, #0x35
0x0004a2:	adds    	r2, r4, #0
0x0004a4:	adds    	r3, r7, #0
0x0004a6:	adds    	r0, r6, #0
0x0004a8:	bl      	#0x4408
0x0004ac:	movs    	r1, #0
0x0004ae:	movs    	r2, #0
0x0004b0:	str     	r2, [sp, #8]
0x0004b2:	str     	r1, [sp]
0x0004b4:	str     	r1, [sp, #4]
0x0004b6:	movs    	r1, #0x14
0x0004b8:	movs    	r2, #0xcd
0x0004ba:	adds    	r3, r0, #0
0x0004bc:	adds    	r0, r6, #0
0x0004be:	bl      	#0x4408
0x0004c2:	add     	sp, #0xc
0x0004c4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000598 =====
0x000598:	push    	{r4, r5, r6, r7, lr}
0x00059a:	sub     	sp, #0xc
0x00059c:	movs    	r1, #0
0x00059e:	movs    	r2, #0
0x0005a0:	str     	r2, [sp, #8]
0x0005a2:	str     	r1, [sp]
0x0005a4:	str     	r1, [sp, #4]
0x0005a6:	movs    	r5, #0xf1
0x0005a8:	movs    	r4, #0
0x0005aa:	adds    	r3, r4, #0
0x0005ac:	lsls    	r5, r5, #9
0x0005ae:	movs    	r1, #0xe1
0x0005b0:	movs    	r2, #0x20
0x0005b2:	adds    	r0, r5, #0
0x0005b4:	bl      	#0x4408
0x0005b8:	ldr     	r6, [pc, #0x1f0]
0x0005ba:	cmp     	r0, #0
0x0005bc:	add     	r6, sb
0x0005be:	bne     	#0x6a4
0x0005c0:	movs    	r1, #0
0x0005c2:	movs    	r2, #0
0x0005c4:	str     	r2, [sp, #8]
0x0005c6:	str     	r1, [sp]
0x0005c8:	str     	r1, [sp, #4]
0x0005ca:	movs    	r1, #0xe1
0x0005cc:	movs    	r2, #0x52
0x0005ce:	adds    	r3, r4, #0
0x0005d0:	adds    	r0, r5, #0
0x0005d2:	bl      	#0x4408
0x0005d6:	movs    	r1, #0
0x0005d8:	movs    	r2, #0
0x0005da:	str     	r2, [sp, #8]
0x0005dc:	str     	r1, [sp]
0x0005de:	str     	r1, [sp, #4]
0x0005e0:	movs    	r1, #0x26
0x0005e2:	adds    	r2, r0, #0
0x0005e4:	adds    	r3, r4, #0
0x0005e6:	adds    	r0, r5, #0
0x0005e8:	bl      	#0x4408
0x0005ec:	movs    	r1, #0
0x0005ee:	movs    	r2, #0
0x0005f0:	str     	r2, [sp, #8]
0x0005f2:	str     	r1, [sp]
0x0005f4:	str     	r1, [sp, #4]
0x0005f6:	movs    	r1, #0xe1
0x0005f8:	movs    	r2, #0x18
0x0005fa:	adds    	r3, r4, #0
0x0005fc:	adds    	r0, r5, #0
0x0005fe:	bl      	#0x4408
0x000602:	ldr     	r0, [r0, #0xc]
0x000604:	bl      	#0x3a04
0x000608:	cmp     	r0, #1
0x00060a:	bne     	#0x642
0x00060c:	bl      	#0x4880
0x000610:	movs    	r1, #0
0x000612:	movs    	r2, #0
0x000614:	str     	r2, [sp, #8]
0x000616:	str     	r1, [sp]
0x000618:	str     	r1, [sp, #4]
0x00061a:	movs    	r1, #0x9c
0x00061c:	movs    	r2, #0x12
0x00061e:	adds    	r3, r4, #0
0x000620:	adds    	r0, r5, #0
0x000622:	bl      	#0x4408
0x000626:	movs    	r2, #0
0x000628:	movs    	r1, #0
0x00062a:	str     	r2, [sp, #8]
0x00062c:	ldr     	r2, [pc, #0x180]
0x00062e:	str     	r1, [sp]
0x000630:	str     	r1, [sp, #4]
0x000632:	adds    	r3, r4, #0
0x000634:	add     	r2, pc
0x000636:	movs    	r1, #0x33
0x000638:	adds    	r0, r5, #0
0x00063a:	bl      	#0x4408
0x00063e:	add     	sp, #0xc
0x000640:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0007c4 =====
0x0007c4:	push    	{r4, r5, lr}
0x0007c6:	sub     	sp, #0xc
0x0007c8:	movs    	r1, #0
0x0007ca:	movs    	r2, #0
0x0007cc:	str     	r2, [sp, #8]
0x0007ce:	str     	r1, [sp]
0x0007d0:	str     	r1, [sp, #4]
0x0007d2:	movs    	r5, #0xf1
0x0007d4:	movs    	r4, #0
0x0007d6:	adds    	r3, r4, #0
0x0007d8:	lsls    	r5, r5, #9
0x0007da:	movs    	r1, #0xe1
0x0007dc:	movs    	r2, #0x20
0x0007de:	adds    	r0, r5, #0
0x0007e0:	bl      	#0x4408
0x0007e4:	cmp     	r0, #0
0x0007e6:	bne     	#0x82a
0x0007e8:	ldr     	r0, [pc, #0x9c]
0x0007ea:	movs    	r3, #0
0x0007ec:	add     	r0, sb
0x0007ee:	ldrsb   	r0, [r0, r3]
0x0007f0:	cmp     	r0, #2
0x0007f2:	beq     	#0x810
0x0007f4:	movs    	r2, #0
0x0007f6:	movs    	r1, #0
0x0007f8:	str     	r2, [sp, #8]
0x0007fa:	ldr     	r2, [pc, #0x90]
0x0007fc:	str     	r1, [sp]
0x0007fe:	str     	r1, [sp, #4]
0x000800:	adds    	r3, r4, #0
0x000802:	add     	r2, pc
0x000804:	movs    	r1, #0x51
0x000806:	adds    	r0, r5, #0
0x000808:	bl      	#0x4408
0x00080c:	add     	sp, #0xc
0x00080e:	pop     	{r4, r5, pc}

; ===== candidate_000894 =====
0x000894:	push    	{r4, r5, r6, r7, lr}
0x000896:	sub     	sp, #0xc
0x000898:	movs    	r1, #0
0x00089a:	movs    	r2, #0
0x00089c:	str     	r2, [sp, #8]
0x00089e:	str     	r1, [sp]
0x0008a0:	str     	r1, [sp, #4]
0x0008a2:	movs    	r5, #0xf1
0x0008a4:	movs    	r4, #0
0x0008a6:	adds    	r3, r4, #0
0x0008a8:	lsls    	r5, r5, #9
0x0008aa:	movs    	r1, #0xe1
0x0008ac:	movs    	r2, #0x20
0x0008ae:	adds    	r0, r5, #0
0x0008b0:	bl      	#0x4408
0x0008b4:	ldr     	r6, [pc, #0x25c]
0x0008b6:	cmp     	r0, #0
0x0008b8:	add     	r6, sb
0x0008ba:	bne     	#0x9a2
0x0008bc:	movs    	r1, #0
0x0008be:	movs    	r2, #0
0x0008c0:	str     	r2, [sp, #8]
0x0008c2:	str     	r1, [sp]
0x0008c4:	str     	r1, [sp, #4]
0x0008c6:	movs    	r1, #0xe1
0x0008c8:	movs    	r2, #0x52
0x0008ca:	adds    	r3, r4, #0
0x0008cc:	adds    	r0, r5, #0
0x0008ce:	bl      	#0x4408
0x0008d2:	movs    	r1, #0
0x0008d4:	movs    	r2, #0
0x0008d6:	str     	r2, [sp, #8]
0x0008d8:	str     	r1, [sp]
0x0008da:	str     	r1, [sp, #4]
0x0008dc:	movs    	r1, #0x26
0x0008de:	adds    	r2, r0, #0
0x0008e0:	adds    	r3, r4, #0
0x0008e2:	adds    	r0, r5, #0
0x0008e4:	bl      	#0x4408
0x0008e8:	cmp     	r0, #0
0x0008ea:	bgt     	#0x922
0x0008ec:	bl      	#0x4880
0x0008f0:	movs    	r1, #0
0x0008f2:	movs    	r2, #0
0x0008f4:	str     	r2, [sp, #8]
0x0008f6:	str     	r1, [sp]
0x0008f8:	str     	r1, [sp, #4]
0x0008fa:	movs    	r1, #0x9c
0x0008fc:	movs    	r2, #0x12
0x0008fe:	adds    	r3, r4, #0
0x000900:	adds    	r0, r5, #0
0x000902:	bl      	#0x4408
0x000906:	movs    	r2, #0
0x000908:	movs    	r1, #0
0x00090a:	str     	r2, [sp, #8]
0x00090c:	ldr     	r2, [pc, #0x208]
0x00090e:	str     	r1, [sp]
0x000910:	str     	r1, [sp, #4]
0x000912:	adds    	r3, r4, #0
0x000914:	add     	r2, pc
0x000916:	movs    	r1, #0x33
0x000918:	adds    	r0, r5, #0
0x00091a:	bl      	#0x4408
0x00091e:	add     	sp, #0xc
0x000920:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_000b34 =====
0x000b34:	push    	{r4, r5, r6, r7, lr}
0x000b36:	sub     	sp, #0x34
0x000b38:	movs    	r7, #0
0x000b3a:	movs    	r6, #0
0x000b3c:	movs    	r1, #0
0x000b3e:	str     	r6, [sp, #0x24]
0x000b40:	adds    	r4, r0, #0
0x000b42:	movs    	r2, #0
0x000b44:	str     	r2, [sp, #8]
0x000b46:	str     	r1, [sp, #4]
0x000b48:	str     	r1, [sp]
0x000b4a:	adds    	r5, r7, #0
0x000b4c:	adds    	r3, r7, #0
0x000b4e:	adds    	r2, r4, #0
0x000b50:	movs    	r1, #0x44
0x000b52:	movs    	r0, #0xf1
0x000b54:	lsls    	r0, r0, #9
0x000b56:	bl      	#0x4408
0x000b5a:	movs    	r1, #0
0x000b5c:	str     	r1, [sp]
0x000b5e:	str     	r1, [sp, #4]
0x000b60:	movs    	r2, #0
0x000b62:	str     	r2, [sp, #8]
0x000b64:	movs    	r1, #0x46
0x000b66:	adds    	r3, r5, #0
0x000b68:	movs    	r0, #0xf1
0x000b6a:	lsls    	r0, r0, #9
0x000b6c:	ldr     	r2, [r4, #8]
0x000b6e:	bl      	#0x4408
0x000b72:	lsls    	r0, r0, #0x18
0x000b74:	asrs    	r0, r0, #0x18
0x000b76:	movs    	r1, #0
0x000b78:	str     	r0, [sp, #0x28]
0x000b7a:	str     	r1, [sp]
0x000b7c:	str     	r1, [sp, #4]
0x000b7e:	movs    	r2, #0
0x000b80:	str     	r2, [sp, #8]
0x000b82:	movs    	r1, #0x45
0x000b84:	movs    	r0, #0xf1
0x000b86:	adds    	r3, r5, #0
0x000b88:	lsls    	r0, r0, #9
0x000b8a:	ldr     	r2, [r4, #8]
0x000b8c:	bl      	#0x4408
0x000b90:	str     	r0, [sp, #0x2c]
0x000b92:	cmp     	r0, #0
0x000b94:	ble     	#0xc7a
0x000b96:	movs    	r1, #0
0x000b98:	movs    	r2, #0
0x000b9a:	str     	r1, [sp]
0x000b9c:	str     	r1, [sp, #4]
0x000b9e:	movs    	r5, #0xf1
0x000ba0:	lsls    	r5, r5, #9
0x000ba2:	movs    	r1, #0xa
0x000ba4:	str     	r2, [sp, #8]
0x000ba6:	movs    	r3, #4
0x000ba8:	adds    	r0, r5, #0
0x000baa:	ldr     	r2, [sp, #0x2c]
0x000bac:	bl      	#0x4408
0x000bb0:	str     	r0, [sp, #0x24]
0x000bb2:	movs    	r1, #0
0x000bb4:	str     	r1, [sp]
0x000bb6:	str     	r1, [sp, #4]
0x000bb8:	movs    	r2, #0
0x000bba:	movs    	r1, #0xad
0x000bbc:	adds    	r3, r7, #0
0x000bbe:	movs    	r0, #0xf1
0x000bc0:	lsls    	r0, r0, #9
0x000bc2:	str     	r2, [sp, #8]
0x000bc4:	bl      	#0x4408
0x000bc8:	movs    	r1, #0
0x000bca:	str     	r1, [sp]
0x000bcc:	str     	r1, [sp, #4]
0x000bce:	adds    	r5, r0, #0
0x000bd0:	movs    	r2, #0
0x000bd2:	str     	r2, [sp, #8]
0x000bd4:	movs    	r0, #0xf1
0x000bd6:	adds    	r3, r7, #0
0x000bd8:	movs    	r1, #0x45
0x000bda:	lsls    	r0, r0, #9
0x000bdc:	ldr     	r2, [r4, #8]
0x000bde:	bl      	#0x4408
0x000be2:	str     	r0, [sp, #0x20]
0x000be4:	movs    	r1, #0
0x000be6:	str     	r1, [sp]
0x000be8:	str     	r1, [sp, #4]
0x000bea:	movs    	r2, #0
0x000bec:	str     	r2, [sp, #8]
0x000bee:	movs    	r1, #0x45
0x000bf0:	movs    	r0, #0xf1
0x000bf2:	adds    	r3, r7, #0
0x000bf4:	lsls    	r0, r0, #9
0x000bf6:	ldr     	r2, [r4, #8]
0x000bf8:	bl      	#0x4408
0x000bfc:	movs    	r1, #0
0x000bfe:	str     	r1, [sp]
0x000c00:	str     	r1, [sp, #4]
0x000c02:	str     	r0, [sp, #0x1c]
0x000c04:	movs    	r2, #0
0x000c06:	str     	r2, [sp, #8]
0x000c08:	movs    	r0, #0xf1
0x000c0a:	movs    	r1, #0x47
0x000c0c:	adds    	r3, r7, #0
0x000c0e:	lsls    	r0, r0, #9
0x000c10:	ldr     	r2, [r4, #8]
0x000c12:	bl      	#0x4408
0x000c16:	movs    	r1, #0
0x000c18:	str     	r1, [sp]
0x000c1a:	str     	r1, [sp, #4]
0x000c1c:	str     	r0, [sp, #0x18]
0x000c1e:	movs    	r2, #0
0x000c20:	str     	r2, [sp, #8]
0x000c22:	movs    	r0, #0xf1
0x000c24:	movs    	r1, #0x45
0x000c26:	adds    	r3, r7, #0
0x000c28:	lsls    	r0, r0, #9
0x000c2a:	ldr     	r2, [r4, #8]
0x000c2c:	bl      	#0x4408
0x000c30:	movs    	r1, #0
0x000c32:	str     	r1, [sp]
0x000c34:	str     	r1, [sp, #4]
0x000c36:	str     	r0, [sp, #0x14]
0x000c38:	movs    	r2, #0
0x000c3a:	str     	r2, [sp, #8]
0x000c3c:	movs    	r0, #0xf1
0x000c3e:	movs    	r1, #0x45
0x000c40:	adds    	r3, r7, #0
0x000c42:	lsls    	r0, r0, #9
0x000c44:	ldr     	r2, [r4, #8]
0x000c46:	bl      	#0x4408
0x000c4a:	movs    	r1, #0
0x000c4c:	str     	r1, [sp]
0x000c4e:	str     	r1, [sp, #4]
0x000c50:	str     	r0, [sp, #0x10]
0x000c52:	movs    	r2, #0
0x000c54:	str     	r2, [sp, #8]
0x000c56:	movs    	r0, #0xf1
0x000c58:	movs    	r1, #0x46
0x000c5a:	adds    	r3, r7, #0
0x000c5c:	lsls    	r0, r0, #9
0x000c5e:	ldr     	r2, [r4, #8]
0x000c60:	bl      	#0x4408

; ===== candidate_000d98 =====
0x000d98:	push    	{r4, r5, r6, r7, lr}
0x000d9a:	sub     	sp, #0x14
0x000d9c:	movs    	r0, #0
0x000d9e:	str     	r0, [sp, #0x10]
0x000da0:	ldr     	r0, [pc, #0x1cc]
0x000da2:	add     	r3, sp, #0
0x000da4:	ldr     	r7, [pc, #0x1cc]
0x000da6:	movs    	r6, #0
0x000da8:	strb    	r6, [r3, #0xc]
0x000daa:	add     	r0, pc
0x000dac:	mov     	ip, r0
0x000dae:	movs    	r3, #0
0x000db0:	add     	r7, sb
0x000db2:	ldrsb   	r0, [r7, r3]
0x000db4:	movs    	r5, #0xf1
0x000db6:	lsls    	r5, r5, #9
0x000db8:	movs    	r4, #0
0x000dba:	cmp     	r0, #0
0x000dbc:	bne     	#0xdda
0x000dbe:	movs    	r2, #0
0x000dc0:	movs    	r1, #0
0x000dc2:	ldr     	r3, [pc, #0x1ac]
0x000dc4:	str     	r1, [sp]
0x000dc6:	str     	r1, [sp, #4]
0x000dc8:	str     	r2, [sp, #8]
0x000dca:	add     	r3, pc
0x000dcc:	movs    	r1, #0x2d
0x000dce:	adds    	r0, r5, #0
0x000dd0:	mov     	r2, ip
0x000dd2:	bl      	#0x4408
0x000dd6:	adds    	r3, r0, #0
0x000dd8:	b       	#0xe14
0x000dda:	cmp     	r0, #1
0x000ddc:	bne     	#0xdfa
0x000dde:	movs    	r2, #0
0x000de0:	movs    	r1, #0
0x000de2:	ldr     	r3, [pc, #0x194]
0x000de4:	str     	r1, [sp]
0x000de6:	str     	r1, [sp, #4]
0x000de8:	str     	r2, [sp, #8]
0x000dea:	add     	r3, pc
0x000dec:	movs    	r1, #0x2d
0x000dee:	adds    	r0, r5, #0
0x000df0:	mov     	r2, ip
0x000df2:	bl      	#0x4408
0x000df6:	adds    	r3, r0, #0
0x000df8:	b       	#0xe14
0x000dfa:	movs    	r2, #0
0x000dfc:	movs    	r1, #0
0x000dfe:	ldr     	r3, [pc, #0x17c]
0x000e00:	str     	r1, [sp]
0x000e02:	str     	r1, [sp, #4]
0x000e04:	str     	r2, [sp, #8]
0x000e06:	add     	r3, pc
0x000e08:	movs    	r1, #0x2d
0x000e0a:	adds    	r0, r5, #0
0x000e0c:	mov     	r2, ip
0x000e0e:	bl      	#0x4408
0x000e12:	adds    	r3, r0, #0
0x000e14:	movs    	r1, #0
0x000e16:	movs    	r2, #0
0x000e18:	str     	r2, [sp, #8]
0x000e1a:	str     	r1, [sp]
0x000e1c:	str     	r1, [sp, #4]
0x000e1e:	ldr     	r7, [r7, #0x14]
0x000e20:	movs    	r0, #0xf1
0x000e22:	lsls    	r0, r0, #9
0x000e24:	movs    	r1, #0x2d
0x000e26:	adds    	r2, r3, #0
0x000e28:	adds    	r3, r7, #0
0x000e2a:	bl      	#0x4408
0x000e2e:	movs    	r2, #0
0x000e30:	movs    	r1, #0
0x000e32:	ldr     	r3, [pc, #0x14c]
0x000e34:	str     	r1, [sp]
0x000e36:	str     	r1, [sp, #4]
0x000e38:	str     	r2, [sp, #8]
0x000e3a:	add     	r3, pc
0x000e3c:	adds    	r2, r0, #0
0x000e3e:	movs    	r0, #0xf1
0x000e40:	movs    	r1, #0x2d
0x000e42:	lsls    	r0, r0, #9
0x000e44:	bl      	#0x4408
0x000e48:	movs    	r2, #0
0x000e4a:	movs    	r1, #0
0x000e4c:	ldr     	r3, [pc, #0x134]
0x000e4e:	str     	r1, [sp]
0x000e50:	str     	r1, [sp, #4]
0x000e52:	str     	r2, [sp, #8]
0x000e54:	add     	r3, pc
0x000e56:	adds    	r2, r0, #0
0x000e58:	movs    	r0, #0xf1
0x000e5a:	movs    	r1, #0x35
0x000e5c:	lsls    	r0, r0, #9
0x000e5e:	bl      	#0x4408
0x000e62:	movs    	r1, #0
0x000e64:	adds    	r5, r0, #0
0x000e66:	movs    	r2, #0
0x000e68:	str     	r2, [sp, #8]
0x000e6a:	str     	r1, [sp]
0x000e6c:	str     	r1, [sp, #4]
0x000e6e:	movs    	r1, #0x9c
0x000e70:	movs    	r2, #0x12
0x000e72:	movs    	r0, #0xf1
0x000e74:	adds    	r3, r6, #0
0x000e76:	lsls    	r0, r0, #9
0x000e78:	bl      	#0x4408
0x000e7c:	movs    	r1, #0
0x000e7e:	movs    	r2, #0
0x000e80:	str     	r2, [sp, #8]
0x000e82:	str     	r1, [sp]
0x000e84:	str     	r1, [sp, #4]
0x000e86:	ldr     	r7, [pc, #0x100]
0x000e88:	movs    	r1, #8
0x000e8a:	movs    	r2, #3
0x000e8c:	movs    	r3, #1
0x000e8e:	adds    	r0, r7, #0
0x000e90:	bl      	#0x4408
0x000e94:	movs    	r1, #0
0x000e96:	movs    	r2, #0
0x000e98:	str     	r1, [sp]
0x000e9a:	str     	r1, [sp, #4]
0x000e9c:	movs    	r1, #0xd
0x000e9e:	str     	r2, [sp, #8]
0x000ea0:	add     	r2, sp, #0x10
0x000ea2:	adds    	r0, r7, #0
0x000ea4:	add     	r3, sp, #0xc
0x000ea6:	bl      	#0x4408
0x000eaa:	lsls    	r0, r0, #0x18
0x000eac:	asrs    	r0, r0, #0x18
0x000eae:	bne     	#0xecc
0x000eb0:	movs    	r1, #0
0x000eb2:	movs    	r2, #0
0x000eb4:	str     	r2, [sp, #8]
0x000eb6:	str     	r1, [sp]
0x000eb8:	str     	r1, [sp, #4]
0x000eba:	adds    	r3, r6, #0
0x000ebc:	adds    	r2, r5, #0
0x000ebe:	movs    	r1, #9
0x000ec0:	movs    	r0, #0xf1
0x000ec2:	lsls    	r0, r0, #9

; ===== candidate_000f8c =====
0x000f8c:	push    	{r4, r5, r6, r7, lr}
0x000f8e:	sub     	sp, #0x4c
0x000f90:	movs    	r5, #0
0x000f92:	movs    	r2, #0
0x000f94:	movs    	r1, #0
0x000f96:	str     	r2, [sp, #8]
0x000f98:	adds    	r3, r5, #0
0x000f9a:	adds    	r4, r0, #0
0x000f9c:	adds    	r2, r0, #0
0x000f9e:	str     	r1, [sp]
0x000fa0:	str     	r1, [sp, #4]
0x000fa2:	movs    	r1, #0x44
0x000fa4:	movs    	r0, #0xf1
0x000fa6:	movs    	r6, #0
0x000fa8:	lsls    	r0, r0, #9
0x000faa:	bl      	#0x4408
0x000fae:	movs    	r1, #0
0x000fb0:	str     	r1, [sp]
0x000fb2:	str     	r1, [sp, #4]
0x000fb4:	movs    	r2, #0
0x000fb6:	str     	r2, [sp, #8]
0x000fb8:	movs    	r1, #0x46
0x000fba:	adds    	r3, r5, #0
0x000fbc:	movs    	r0, #0xf1
0x000fbe:	lsls    	r0, r0, #9
0x000fc0:	ldr     	r2, [r4, #8]
0x000fc2:	bl      	#0x4408
0x000fc6:	ldr     	r7, [pc, #0x360]
0x000fc8:	lsls    	r0, r0, #0x18
0x000fca:	asrs    	r0, r0, #0x18
0x000fcc:	add     	r7, sb
0x000fce:	str     	r0, [r7, #4]
0x000fd0:	movs    	r1, #0
0x000fd2:	str     	r1, [sp]
0x000fd4:	str     	r1, [sp, #4]
0x000fd6:	movs    	r2, #0
0x000fd8:	str     	r2, [sp, #8]
0x000fda:	movs    	r1, #0x46
0x000fdc:	movs    	r0, #0xf1
0x000fde:	adds    	r3, r5, #0
0x000fe0:	lsls    	r0, r0, #9
0x000fe2:	ldr     	r2, [r4, #8]
0x000fe4:	bl      	#0x4408
0x000fe8:	lsls    	r0, r0, #0x18
0x000fea:	asrs    	r0, r0, #0x18
0x000fec:	str     	r0, [sp, #0x40]
0x000fee:	movs    	r1, #0
0x000ff0:	str     	r1, [sp]
0x000ff2:	str     	r1, [sp, #4]
0x000ff4:	movs    	r2, #0
0x000ff6:	str     	r2, [sp, #8]
0x000ff8:	movs    	r1, #0x46
0x000ffa:	movs    	r0, #0xf1
0x000ffc:	adds    	r3, r5, #0
0x000ffe:	lsls    	r0, r0, #9
0x001000:	ldr     	r2, [r4, #8]
0x001002:	bl      	#0x4408
0x001006:	lsls    	r0, r0, #0x18
0x001008:	asrs    	r0, r0, #0x18
0x00100a:	str     	r0, [sp, #0x44]
0x00100c:	movs    	r1, #0
0x00100e:	str     	r1, [sp]
0x001010:	str     	r1, [sp, #4]
0x001012:	movs    	r2, #0
0x001014:	str     	r2, [sp, #8]
0x001016:	movs    	r1, #0x45
0x001018:	movs    	r0, #0xf1
0x00101a:	adds    	r3, r5, #0
0x00101c:	lsls    	r0, r0, #9
0x00101e:	ldr     	r2, [r4, #8]
0x001020:	bl      	#0x4408
0x001024:	str     	r0, [r7, #8]
0x001026:	movs    	r1, #0
0x001028:	str     	r1, [sp]
0x00102a:	str     	r1, [sp, #4]
0x00102c:	movs    	r2, #0
0x00102e:	str     	r2, [sp, #8]
0x001030:	movs    	r1, #0x45
0x001032:	movs    	r0, #0xf1
0x001034:	adds    	r3, r5, #0
0x001036:	lsls    	r0, r0, #9
0x001038:	ldr     	r2, [r4, #8]
0x00103a:	bl      	#0x4408
0x00103e:	str     	r0, [r7, #0xc]
0x001040:	movs    	r1, #0
0x001042:	str     	r1, [sp]
0x001044:	str     	r1, [sp, #4]
0x001046:	movs    	r2, #0
0x001048:	str     	r2, [sp, #8]
0x00104a:	movs    	r1, #0x45
0x00104c:	movs    	r0, #0xf1
0x00104e:	adds    	r3, r5, #0
0x001050:	lsls    	r0, r0, #9
0x001052:	ldr     	r2, [r4, #8]
0x001054:	bl      	#0x4408
0x001058:	str     	r0, [r7, #0x10]
0x00105a:	movs    	r1, #0
0x00105c:	str     	r1, [sp]
0x00105e:	str     	r1, [sp, #4]
0x001060:	movs    	r2, #0
0x001062:	str     	r2, [sp, #8]
0x001064:	movs    	r1, #0x45
0x001066:	movs    	r0, #0xf1
0x001068:	adds    	r3, r5, #0
0x00106a:	lsls    	r0, r0, #9
0x00106c:	ldr     	r2, [r4, #8]
0x00106e:	bl      	#0x4408
0x001072:	str     	r0, [r7, #0x18]
0x001074:	ldr     	r7, [r7, #0x14]
0x001076:	cmp     	r7, #0
0x001078:	beq     	#0x1092
0x00107a:	movs    	r1, #0
0x00107c:	movs    	r2, #0
0x00107e:	str     	r2, [sp, #8]
0x001080:	str     	r1, [sp]
0x001082:	str     	r1, [sp, #4]
0x001084:	adds    	r3, r5, #0
0x001086:	adds    	r2, r7, #0
0x001088:	movs    	r1, #9
0x00108a:	movs    	r0, #0xf1
0x00108c:	lsls    	r0, r0, #9
0x00108e:	bl      	#0x4408
0x001092:	movs    	r1, #0
0x001094:	str     	r1, [sp]
0x001096:	str     	r1, [sp, #4]
0x001098:	movs    	r2, #0
0x00109a:	str     	r2, [sp, #8]
0x00109c:	movs    	r1, #0x47
0x00109e:	adds    	r3, r5, #0
0x0010a0:	movs    	r0, #0xf1
0x0010a2:	lsls    	r0, r0, #9
0x0010a4:	ldr     	r2, [r4, #8]
0x0010a6:	bl      	#0x4408
0x0010aa:	ldr     	r1, [pc, #0x27c]
0x0010ac:	movs    	r2, #0
0x0010ae:	add     	r1, sb
0x0010b0:	str     	r0, [r1, #0x14]
0x0010b2:	movs    	r1, #0
0x0010b4:	str     	r1, [sp]
0x0010b6:	str     	r1, [sp, #4]
0x0010b8:	movs    	r1, #0x45

; ===== candidate_00132c =====
0x00132c:	push    	{r4, r5, lr}
0x00132e:	ldr     	r4, [pc, #0x70]
0x001330:	sub     	sp, #0xc
0x001332:	add     	r4, sb
0x001334:	ldr     	r0, [r4, #8]
0x001336:	adds    	r3, r0, #1
0x001338:	beq     	#0x139a
0x00133a:	movs    	r1, #0
0x00133c:	movs    	r2, #0
0x00133e:	str     	r2, [sp, #8]
0x001340:	str     	r1, [sp]
0x001342:	str     	r1, [sp, #4]
0x001344:	movs    	r5, #0
0x001346:	adds    	r3, r5, #0
0x001348:	movs    	r1, #0x9c
0x00134a:	movs    	r2, #0x12
0x00134c:	movs    	r0, #0xf1
0x00134e:	lsls    	r0, r0, #9
0x001350:	bl      	#0x4408
0x001354:	movs    	r1, #0
0x001356:	str     	r1, [sp]
0x001358:	str     	r1, [sp, #4]
0x00135a:	movs    	r2, #0
0x00135c:	movs    	r1, #0x34
0x00135e:	adds    	r3, r5, #0
0x001360:	movs    	r0, #0xf1
0x001362:	lsls    	r0, r0, #9
0x001364:	str     	r2, [sp, #8]
0x001366:	bl      	#0x4408
0x00136a:	movs    	r2, #0
0x00136c:	movs    	r1, #0
0x00136e:	str     	r2, [sp, #8]
0x001370:	movs    	r2, #0xff
0x001372:	str     	r1, [sp]
0x001374:	str     	r1, [sp, #4]
0x001376:	movs    	r1, #0x14
0x001378:	adds    	r2, #0x19
0x00137a:	movs    	r3, #4
0x00137c:	movs    	r0, #0xf1
0x00137e:	lsls    	r0, r0, #9
0x001380:	bl      	#0x4408
0x001384:	movs    	r1, #0
0x001386:	movs    	r2, #0
0x001388:	str     	r1, [sp]
0x00138a:	str     	r1, [sp, #4]
0x00138c:	str     	r2, [sp, #8]
0x00138e:	ldr     	r2, [r4, #4]
0x001390:	ldr     	r3, [r4, #8]
0x001392:	movs    	r1, #2
0x001394:	ldr     	r0, [pc, #0xc]
0x001396:	bl      	#0x4408
0x00139a:	add     	sp, #0xc
0x00139c:	pop     	{r4, r5, pc}

; ===== candidate_0013a8 =====
0x0013a8:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0013aa:	sub     	sp, #0x3c
0x0013ac:	movs    	r1, #0
0x0013ae:	adds    	r6, r2, #0
0x0013b0:	movs    	r2, #0
0x0013b2:	str     	r1, [sp]
0x0013b4:	str     	r1, [sp, #4]
0x0013b6:	movs    	r7, #0xf1
0x0013b8:	movs    	r5, #0
0x0013ba:	adds    	r3, r5, #0
0x0013bc:	lsls    	r7, r7, #9
0x0013be:	movs    	r1, #0x1c
0x0013c0:	adds    	r4, r0, #0
0x0013c2:	adds    	r0, r7, #0
0x0013c4:	str     	r2, [sp, #8]
0x0013c6:	bl      	#0x4408
0x0013ca:	ldr     	r1, [sp, #0x48]
0x0013cc:	movs    	r2, #0
0x0013ce:	str     	r0, [sp]
0x0013d0:	str     	r1, [sp, #4]
0x0013d2:	movs    	r1, #0x2e
0x0013d4:	str     	r2, [sp, #8]
0x0013d6:	adds    	r3, r6, #0
0x0013d8:	adds    	r0, r7, #0
0x0013da:	ldr     	r2, [sp, #0x40]
0x0013dc:	bl      	#0x4408
0x0013e0:	cmp     	r4, #0
0x0013e2:	beq     	#0x14b6
0x0013e4:	movs    	r1, #0
0x0013e6:	movs    	r2, #0
0x0013e8:	str     	r2, [sp, #8]
0x0013ea:	str     	r1, [sp]
0x0013ec:	str     	r1, [sp, #4]
0x0013ee:	movs    	r1, #0xe1
0x0013f0:	movs    	r2, #0x2d
0x0013f2:	movs    	r3, #0
0x0013f4:	adds    	r0, r7, #0
0x0013f6:	bl      	#0x4408
0x0013fa:	movs    	r1, #0
0x0013fc:	movs    	r2, #0
0x0013fe:	str     	r2, [sp, #8]
0x001400:	str     	r1, [sp]
0x001402:	str     	r1, [sp, #4]
0x001404:	movs    	r1, #0xe1
0x001406:	movs    	r2, #0x2e
0x001408:	str     	r0, [sp, #0x38]
0x00140a:	movs    	r3, #0
0x00140c:	adds    	r0, r7, #0
0x00140e:	bl      	#0x4408
0x001412:	str     	r0, [sp, #0x34]
0x001414:	movs    	r0, #0x58
0x001416:	ldrb    	r0, [r0, r4]
0x001418:	movs    	r5, #0xf
0x00141a:	adds    	r6, #0xa
0x00141c:	cmp     	r0, #0
0x00141e:	beq     	#0x14ba
0x001420:	ldr     	r0, [pc, #0x2a0]
0x001422:	add     	r0, pc
0x001424:	str     	r0, [sp, #0x30]
0x001426:	str     	r5, [sp, #0x10]
0x001428:	movs    	r5, #0
0x00142a:	str     	r0, [sp, #0xc]
0x00142c:	movs    	r0, #0xff
0x00142e:	movs    	r1, #0
0x001430:	str     	r0, [sp, #0x20]
0x001432:	str     	r5, [sp, #0x24]
0x001434:	movs    	r2, #0
0x001436:	str     	r1, [sp, #4]
0x001438:	str     	r1, [sp]
0x00143a:	str     	r5, [sp, #0x28]
0x00143c:	str     	r2, [sp, #8]
0x00143e:	movs    	r1, #0x56
0x001440:	str     	r0, [sp, #0x18]
0x001442:	str     	r0, [sp, #0x1c]
0x001444:	adds    	r3, r5, #0
0x001446:	adds    	r0, r7, #0
0x001448:	add     	r2, sp, #0xc
0x00144a:	str     	r6, [sp, #0x14]
0x00144c:	bl      	#0x4408
0x001450:	add     	r1, sp, #0x38
0x001452:	str     	r1, [sp, #4]
0x001454:	add     	r2, sp, #0x34
0x001456:	movs    	r0, #0
0x001458:	str     	r0, [sp]
0x00145a:	str     	r2, [sp, #8]
0x00145c:	movs    	r1, #0x2a
0x00145e:	adds    	r3, r5, #0
0x001460:	adds    	r0, r7, #0
0x001462:	ldr     	r2, [sp, #0x30]
0x001464:	bl      	#0x4408
0x001468:	movs    	r1, #0
0x00146a:	ldr     	r7, [sp, #0x38]
0x00146c:	str     	r1, [sp]
0x00146e:	str     	r1, [sp, #4]
0x001470:	movs    	r2, #0
0x001472:	adds    	r7, #0x19
0x001474:	adds    	r3, r5, #0
0x001476:	str     	r2, [sp, #8]
0x001478:	movs    	r1, #0x3f
0x00147a:	movs    	r0, #0xf1
0x00147c:	lsls    	r0, r0, #9
0x00147e:	ldr     	r2, [r4, #0x5c]
0x001480:	bl      	#0x4408
0x001484:	adds    	r4, r0, #0
0x001486:	movs    	r2, #0
0x001488:	ldr     	r3, [pc, #0x23c]
0x00148a:	str     	r2, [sp, #8]
0x00148c:	str     	r7, [sp]
0x00148e:	str     	r6, [sp, #4]
0x001490:	add     	r3, pc
0x001492:	adds    	r2, r0, #0
0x001494:	movs    	r0, #0xf1
0x001496:	movs    	r1, #0x3c
0x001498:	lsls    	r0, r0, #9
0x00149a:	bl      	#0x4408
0x00149e:	movs    	r1, #0
0x0014a0:	movs    	r2, #0
0x0014a2:	str     	r2, [sp, #8]
0x0014a4:	str     	r1, [sp]
0x0014a6:	str     	r1, [sp, #4]
0x0014a8:	adds    	r3, r5, #0
0x0014aa:	adds    	r2, r4, #0
0x0014ac:	movs    	r1, #9
0x0014ae:	movs    	r0, #0xf1
0x0014b0:	lsls    	r0, r0, #9
0x0014b2:	bl      	#0x4408
0x0014b6:	add     	sp, #0x4c
0x0014b8:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0016e4 =====
0x0016e4:	push    	{r4, r5, r6, r7, lr}
0x0016e6:	sub     	sp, #0x2c
0x0016e8:	movs    	r1, #0
0x0016ea:	str     	r1, [sp]
0x0016ec:	str     	r1, [sp, #4]
0x0016ee:	ldr     	r1, [pc, #0xd4]
0x0016f0:	movs    	r2, #0
0x0016f2:	str     	r2, [sp, #8]
0x0016f4:	add     	r1, sb
0x0016f6:	ldr     	r2, [r1, #0x1c]
0x0016f8:	movs    	r1, #0x11
0x0016fa:	movs    	r3, #4
0x0016fc:	movs    	r0, #0xf1
0x0016fe:	lsls    	r0, r0, #9
0x001700:	bl      	#0x4408
0x001704:	movs    	r1, #0
0x001706:	adds    	r5, r0, #0
0x001708:	str     	r1, [sp]
0x00170a:	str     	r1, [sp, #4]
0x00170c:	movs    	r2, #0
0x00170e:	movs    	r6, #0
0x001710:	adds    	r3, r6, #0
0x001712:	movs    	r1, #0x5a
0x001714:	movs    	r0, #0xf1
0x001716:	lsls    	r0, r0, #9
0x001718:	str     	r2, [sp, #8]
0x00171a:	bl      	#0x4408
0x00171e:	add     	r2, sp, #0x24
0x001720:	str     	r2, [sp, #8]
0x001722:	movs    	r0, #0
0x001724:	ldr     	r2, [pc, #0xa0]
0x001726:	add     	r1, sp, #0x28
0x001728:	str     	r1, [sp, #4]
0x00172a:	str     	r0, [sp]
0x00172c:	adds    	r3, r6, #0
0x00172e:	add     	r2, pc
0x001730:	movs    	r1, #0x2a
0x001732:	movs    	r0, #0xf1
0x001734:	lsls    	r0, r0, #9
0x001736:	bl      	#0x4408
0x00173a:	ldr     	r0, [sp, #0x28]
0x00173c:	movs    	r1, #0
0x00173e:	lsls    	r4, r0, #1
0x001740:	ldr     	r0, [sp, #0x24]
0x001742:	str     	r1, [sp, #4]
0x001744:	muls    	r5, r0, r5
0x001746:	str     	r1, [sp]
0x001748:	movs    	r2, #0
0x00174a:	adds    	r5, #0xa
0x00174c:	adds    	r3, r6, #0
0x00174e:	movs    	r1, #0x1c
0x001750:	movs    	r0, #0xf1
0x001752:	lsls    	r0, r0, #9
0x001754:	str     	r2, [sp, #8]
0x001756:	bl      	#0x4408
0x00175a:	subs    	r0, r0, r4
0x00175c:	movs    	r1, #0
0x00175e:	str     	r1, [sp]
0x001760:	str     	r1, [sp, #4]
0x001762:	asrs    	r7, r0, #1
0x001764:	movs    	r2, #0
0x001766:	movs    	r0, #0xf1
0x001768:	movs    	r1, #0x1d
0x00176a:	adds    	r3, r6, #0
0x00176c:	lsls    	r0, r0, #9
0x00176e:	str     	r2, [sp, #8]
0x001770:	bl      	#0x4408
0x001774:	ldr     	r1, [pc, #0x4c]
0x001776:	subs    	r0, r0, r5
0x001778:	add     	r1, sb
0x00177a:	ldr     	r1, [r1, #0x1c]
0x00177c:	asrs    	r0, r0, #1
0x00177e:	str     	r0, [sp, #0x14]
0x001780:	ldr     	r0, [pc, #0x40]
0x001782:	str     	r1, [sp, #0xc]
0x001784:	add     	r0, sb
0x001786:	adds    	r0, #0x20
0x001788:	str     	r0, [sp, #0x20]
0x00178a:	movs    	r1, #0
0x00178c:	movs    	r2, #0
0x00178e:	str     	r1, [sp]
0x001790:	str     	r1, [sp, #4]
0x001792:	movs    	r1, #0x2b
0x001794:	str     	r2, [sp, #8]
0x001796:	movs    	r0, #0xf1
0x001798:	adds    	r3, r6, #0
0x00179a:	lsls    	r0, r0, #9
0x00179c:	add     	r2, sp, #0xc
0x00179e:	str     	r7, [sp, #0x10]
0x0017a0:	str     	r4, [sp, #0x18]
0x0017a2:	str     	r5, [sp, #0x1c]
0x0017a4:	bl      	#0x4408
0x0017a8:	movs    	r1, #0
0x0017aa:	movs    	r2, #0
0x0017ac:	str     	r2, [sp, #8]
0x0017ae:	str     	r1, [sp]
0x0017b0:	str     	r1, [sp, #4]
0x0017b2:	movs    	r1, #0x24
0x0017b4:	movs    	r2, #1
0x0017b6:	movs    	r3, #1
0x0017b8:	movs    	r0, #0xf1
0x0017ba:	lsls    	r0, r0, #9
0x0017bc:	bl      	#0x4408
0x0017c0:	add     	sp, #0x2c
0x0017c2:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0017cc =====
0x0017cc:	push    	{r4, r5, r6, r7, lr}
0x0017ce:	adds    	r6, r1, #0
0x0017d0:	sub     	sp, #0x1c
0x0017d2:	adds    	r4, r2, #0
0x0017d4:	movs    	r1, #0
0x0017d6:	adds    	r5, r0, #0
0x0017d8:	adds    	r7, r3, #0
0x0017da:	str     	r1, [sp]
0x0017dc:	str     	r1, [sp, #4]
0x0017de:	movs    	r2, #0
0x0017e0:	movs    	r1, #0x1c
0x0017e2:	movs    	r3, #0
0x0017e4:	movs    	r0, #0xf1
0x0017e6:	lsls    	r0, r0, #9
0x0017e8:	str     	r2, [sp, #8]
0x0017ea:	bl      	#0x4408
0x0017ee:	movs    	r2, #0
0x0017f0:	str     	r2, [sp, #8]
0x0017f2:	str     	r0, [sp]
0x0017f4:	adds    	r3, r4, #0
0x0017f6:	adds    	r2, r6, #0
0x0017f8:	movs    	r0, #0xf1
0x0017fa:	movs    	r1, #0x32
0x0017fc:	lsls    	r0, r0, #9
0x0017fe:	str     	r7, [sp, #4]
0x001800:	bl      	#0x4408
0x001804:	adds    	r4, #0xa
0x001806:	cmp     	r5, #0
0x001808:	bne     	#0x18ee
0x00180a:	ldr     	r7, [pc, #0x36c]
0x00180c:	movs    	r3, #0
0x00180e:	add     	r7, sb
0x001810:	ldrsb   	r0, [r7, r3]
0x001812:	cmp     	r0, #2
0x001814:	beq     	#0x18f0
0x001816:	adds    	r5, r6, #0
0x001818:	movs    	r0, #0
0x00181a:	movs    	r6, #0
0x00181c:	movs    	r1, #0
0x00181e:	str     	r1, [sp, #4]
0x001820:	adds    	r3, r6, #0
0x001822:	str     	r0, [sp, #0x14]
0x001824:	str     	r0, [sp]
0x001826:	adds    	r5, #0xa
0x001828:	movs    	r2, #0
0x00182a:	str     	r2, [sp, #8]
0x00182c:	adds    	r0, r7, #0
0x00182e:	ldr     	r2, [r0, #8]
0x001830:	movs    	r0, #0xf1
0x001832:	movs    	r1, #0x3f
0x001834:	lsls    	r0, r0, #9
0x001836:	bl      	#0x4408
0x00183a:	movs    	r2, #0
0x00183c:	str     	r2, [sp, #8]
0x00183e:	ldr     	r2, [pc, #0x33c]
0x001840:	adds    	r7, r0, #0
0x001842:	adds    	r3, r0, #0
0x001844:	str     	r5, [sp]
0x001846:	str     	r4, [sp, #4]
0x001848:	add     	r2, pc
0x00184a:	movs    	r1, #0x3c
0x00184c:	movs    	r0, #0xf1
0x00184e:	lsls    	r0, r0, #9
0x001850:	bl      	#0x4408
0x001854:	ldr     	r1, [sp, #0x14]
0x001856:	movs    	r2, #0
0x001858:	adds    	r0, r0, r1
0x00185a:	movs    	r1, #0
0x00185c:	str     	r1, [sp]
0x00185e:	str     	r1, [sp, #4]
0x001860:	str     	r0, [sp, #0x14]
0x001862:	str     	r2, [sp, #8]
0x001864:	adds    	r3, r6, #0
0x001866:	adds    	r2, r7, #0
0x001868:	movs    	r0, #0xf1
0x00186a:	movs    	r1, #9
0x00186c:	lsls    	r0, r0, #9
0x00186e:	bl      	#0x4408
0x001872:	ldr     	r0, [sp, #0x14]
0x001874:	movs    	r1, #0
0x001876:	adds    	r0, #0xa
0x001878:	str     	r0, [sp, #0x14]
0x00187a:	ldr     	r0, [pc, #0x2fc]
0x00187c:	str     	r1, [sp]
0x00187e:	str     	r1, [sp, #4]
0x001880:	movs    	r2, #0
0x001882:	str     	r2, [sp, #8]
0x001884:	add     	r0, sb
0x001886:	ldr     	r2, [r0, #0xc]
0x001888:	movs    	r0, #0xf1
0x00188a:	movs    	r1, #0x3f
0x00188c:	adds    	r3, r6, #0
0x00188e:	lsls    	r0, r0, #9
0x001890:	bl      	#0x4408
0x001894:	adds    	r7, r0, #0
0x001896:	ldr     	r0, [sp, #0x14]
0x001898:	movs    	r2, #0
0x00189a:	str     	r2, [sp, #8]
0x00189c:	adds    	r0, r5, r0
0x00189e:	ldr     	r2, [pc, #0x2e0]
0x0018a0:	str     	r0, [sp]
0x0018a2:	adds    	r3, r7, #0
0x0018a4:	str     	r4, [sp, #4]
0x0018a6:	add     	r2, pc
0x0018a8:	movs    	r1, #0x3c
0x0018aa:	movs    	r0, #0xf1
0x0018ac:	lsls    	r0, r0, #9
0x0018ae:	bl      	#0x4408
0x0018b2:	movs    	r1, #0
0x0018b4:	movs    	r2, #0
0x0018b6:	str     	r2, [sp, #8]
0x0018b8:	str     	r1, [sp]
0x0018ba:	str     	r1, [sp, #4]
0x0018bc:	str     	r0, [sp, #0x14]
0x0018be:	adds    	r3, r6, #0
0x0018c0:	adds    	r2, r7, #0
0x0018c2:	movs    	r0, #0xf1
0x0018c4:	movs    	r1, #9
0x0018c6:	lsls    	r0, r0, #9
0x0018c8:	bl      	#0x4408
0x0018cc:	movs    	r1, #0
0x0018ce:	ldr     	r0, [pc, #0x2a8]
0x0018d0:	str     	r1, [sp]
0x0018d2:	str     	r1, [sp, #4]
0x0018d4:	movs    	r2, #0
0x0018d6:	str     	r2, [sp, #8]
0x0018d8:	add     	r0, sb
0x0018da:	ldr     	r2, [r0, #0x18]
0x0018dc:	adds    	r4, #0x14
0x0018de:	adds    	r5, #0xf
0x0018e0:	adds    	r3, r6, #0
0x0018e2:	movs    	r0, #0xf1
0x0018e4:	movs    	r1, #0x3f
0x0018e6:	lsls    	r0, r0, #9
0x0018e8:	bl      	#0x4408
0x0018ec:	b       	#0x18f2
0x0018ee:	b       	#0x192a
0x0018f0:	b       	#0x1926
0x0018f2:	movs    	r2, #0
0x0018f4:	str     	r2, [sp, #8]
0x0018f6:	ldr     	r2, [pc, #0x28c]

; ===== candidate_001ba4 =====
0x001ba4:	push    	{r4, r5, r6, r7, lr}
0x001ba6:	movs    	r3, #0x32
0x001ba8:	sub     	sp, #0x74
0x001baa:	movs    	r0, #0
0x001bac:	ldr     	r4, [pc, #0x3e0]
0x001bae:	str     	r0, [sp, #0x60]
0x001bb0:	str     	r3, [sp, #0x64]
0x001bb2:	add     	r4, pc
0x001bb4:	movs    	r1, #0x1e
0x001bb6:	movs    	r3, #0x1a
0x001bb8:	str     	r3, [sp, #0x48]
0x001bba:	str     	r1, [sp, #0x4c]
0x001bbc:	movs    	r1, #0
0x001bbe:	movs    	r2, #0
0x001bc0:	str     	r2, [sp, #8]
0x001bc2:	str     	r1, [sp, #4]
0x001bc4:	movs    	r6, #0
0x001bc6:	movs    	r5, #0xf1
0x001bc8:	lsls    	r5, r5, #9
0x001bca:	adds    	r3, r6, #0
0x001bcc:	movs    	r1, #0xe1
0x001bce:	movs    	r2, #0xed
0x001bd0:	movs    	r7, #0x19
0x001bd2:	str     	r0, [sp]
0x001bd4:	adds    	r0, r5, #0
0x001bd6:	bl      	#0x4408
0x001bda:	cmp     	r0, #0
0x001bdc:	ble     	#0x1cc2
0x001bde:	movs    	r1, #0
0x001be0:	str     	r1, [sp]
0x001be2:	str     	r1, [sp, #4]
0x001be4:	movs    	r1, #0xff
0x001be6:	movs    	r2, #0
0x001be8:	adds    	r1, #0x25
0x001bea:	adds    	r3, r6, #0
0x001bec:	adds    	r0, r5, #0
0x001bee:	str     	r2, [sp, #8]
0x001bf0:	bl      	#0x4408
0x001bf4:	add     	r2, sp, #0x54
0x001bf6:	add     	r1, sp, #0x58
0x001bf8:	str     	r1, [sp, #4]
0x001bfa:	str     	r2, [sp, #8]
0x001bfc:	movs    	r0, #0
0x001bfe:	str     	r0, [sp]
0x001c00:	adds    	r2, r4, #0
0x001c02:	movs    	r1, #0x2a
0x001c04:	adds    	r3, r6, #0
0x001c06:	adds    	r0, r5, #0
0x001c08:	bl      	#0x4408
0x001c0c:	movs    	r2, #0
0x001c0e:	movs    	r1, #0
0x001c10:	movs    	r0, #0
0x001c12:	bl      	#0x43b8
0x001c16:	movs    	r1, #1
0x001c18:	movs    	r2, #1
0x001c1a:	str     	r2, [sp, #8]
0x001c1c:	str     	r1, [sp]
0x001c1e:	str     	r1, [sp, #4]
0x001c20:	movs    	r1, #0x55
0x001c22:	movs    	r2, #0
0x001c24:	adds    	r3, r6, #0
0x001c26:	adds    	r0, r5, #0
0x001c28:	bl      	#0x4408
0x001c2c:	ldr     	r0, [pc, #0x364]
0x001c2e:	add     	r0, sb
0x001c30:	ldr     	r0, [r0, #0x38]
0x001c32:	bl      	#0x3030
0x001c36:	adds    	r4, r0, #0
0x001c38:	add     	r2, sp, #0x40
0x001c3a:	add     	r1, sp, #0x44
0x001c3c:	str     	r1, [sp, #4]
0x001c3e:	str     	r2, [sp, #8]
0x001c40:	movs    	r0, #0
0x001c42:	str     	r0, [sp]
0x001c44:	adds    	r2, r4, #0
0x001c46:	movs    	r1, #0x2a
0x001c48:	adds    	r3, r6, #0
0x001c4a:	adds    	r0, r5, #0
0x001c4c:	bl      	#0x4408
0x001c50:	movs    	r1, #0
0x001c52:	str     	r1, [sp]
0x001c54:	str     	r1, [sp, #4]
0x001c56:	movs    	r0, #0x19
0x001c58:	movs    	r2, #0
0x001c5a:	str     	r0, [sp, #0x5c]
0x001c5c:	movs    	r1, #0x1c
0x001c5e:	adds    	r3, r6, #0
0x001c60:	adds    	r0, r5, #0
0x001c62:	str     	r2, [sp, #8]
0x001c64:	bl      	#0x4408
0x001c68:	ldr     	r1, [sp, #0x5c]
0x001c6a:	movs    	r2, #0
0x001c6c:	str     	r1, [sp, #4]
0x001c6e:	movs    	r1, #0x32
0x001c70:	str     	r2, [sp, #8]
0x001c72:	str     	r0, [sp]
0x001c74:	adds    	r0, r5, #0
0x001c76:	ldr     	r3, [sp, #0x48]
0x001c78:	bl      	#0x4408
0x001c7c:	movs    	r1, #0
0x001c7e:	str     	r1, [sp]
0x001c80:	str     	r1, [sp, #4]
0x001c82:	movs    	r2, #0
0x001c84:	movs    	r1, #0x1c
0x001c86:	adds    	r3, r6, #0
0x001c88:	adds    	r0, r5, #0
0x001c8a:	str     	r2, [sp, #8]
0x001c8c:	str     	r4, [sp, #0x18]
0x001c8e:	bl      	#0x4408
0x001c92:	ldr     	r1, [sp, #0x44]
0x001c94:	str     	r6, [sp, #0x24]
0x001c96:	subs    	r0, r0, r1
0x001c98:	lsrs    	r1, r0, #0x1f
0x001c9a:	adds    	r0, r1, r0
0x001c9c:	asrs    	r0, r0, #1
0x001c9e:	str     	r0, [sp, #0x1c]
0x001ca0:	movs    	r0, #0x21
0x001ca2:	str     	r0, [sp, #0x20]
0x001ca4:	movs    	r0, #0xff
0x001ca6:	str     	r0, [sp, #0x2c]
0x001ca8:	str     	r0, [sp, #0x30]
0x001caa:	str     	r0, [sp, #0x34]
0x001cac:	movs    	r0, #1
0x001cae:	add     	r1, sp, #0x38
0x001cb0:	str     	r6, [sp, #0x28]
0x001cb2:	strb    	r0, [r1]
0x001cb4:	movs    	r2, #0
0x001cb6:	movs    	r1, #0
0x001cb8:	str     	r1, [sp]
0x001cba:	str     	r1, [sp, #4]
0x001cbc:	str     	r2, [sp, #8]
0x001cbe:	str     	r0, [sp, #0x3c]
0x001cc0:	b       	#0x1cc4
0x001cc2:	b       	#0x242c
0x001cc4:	adds    	r3, r6, #0
0x001cc6:	movs    	r1, #0x25
0x001cc8:	adds    	r0, r5, #0
0x001cca:	add     	r2, sp, #0x18
0x001ccc:	bl      	#0x4408
0x001cd0:	movs    	r1, #0
0x001cd2:	movs    	r2, #0

; ===== candidate_002564 =====
0x002564:	push    	{r4, r5, r6, r7, lr}
0x002566:	movs    	r3, #0x32
0x002568:	sub     	sp, #0x7c
0x00256a:	movs    	r0, #0
0x00256c:	ldr     	r6, [pc, #0x3e0]
0x00256e:	str     	r0, [sp, #0x5c]
0x002570:	str     	r3, [sp, #0x60]
0x002572:	add     	r6, pc
0x002574:	movs    	r3, #0x1a
0x002576:	str     	r3, [sp, #0x48]
0x002578:	movs    	r2, #0
0x00257a:	movs    	r1, #0
0x00257c:	str     	r1, [sp, #4]
0x00257e:	str     	r2, [sp, #8]
0x002580:	movs    	r5, #0
0x002582:	movs    	r4, #0xf1
0x002584:	lsls    	r4, r4, #9
0x002586:	adds    	r3, r5, #0
0x002588:	movs    	r2, #0xc5
0x00258a:	movs    	r1, #0xe1
0x00258c:	movs    	r7, #0x19
0x00258e:	str     	r0, [sp]
0x002590:	adds    	r0, r4, #0
0x002592:	bl      	#0x4408
0x002596:	cmp     	r0, #1
0x002598:	bne     	#0x25c4
0x00259a:	movs    	r1, #0
0x00259c:	movs    	r2, #0
0x00259e:	str     	r2, [sp, #8]
0x0025a0:	str     	r1, [sp]
0x0025a2:	str     	r1, [sp, #4]
0x0025a4:	movs    	r1, #0x14
0x0025a6:	movs    	r2, #0xc5
0x0025a8:	adds    	r3, r5, #0
0x0025aa:	adds    	r0, r4, #0
0x0025ac:	bl      	#0x4408
0x0025b0:	movs    	r1, #0
0x0025b2:	movs    	r2, #0
0x0025b4:	str     	r1, [sp]
0x0025b6:	str     	r1, [sp, #4]
0x0025b8:	ldr     	r1, [pc, #0x398]
0x0025ba:	str     	r2, [sp, #8]
0x0025bc:	adds    	r3, r5, #0
0x0025be:	ldr     	r0, [pc, #0x398]
0x0025c0:	bl      	#0x4408
0x0025c4:	movs    	r1, #0
0x0025c6:	movs    	r2, #0
0x0025c8:	str     	r2, [sp, #8]
0x0025ca:	str     	r1, [sp]
0x0025cc:	str     	r1, [sp, #4]
0x0025ce:	movs    	r1, #0xe1
0x0025d0:	movs    	r2, #0xed
0x0025d2:	adds    	r3, r5, #0
0x0025d4:	adds    	r0, r4, #0
0x0025d6:	bl      	#0x4408
0x0025da:	cmp     	r0, #0
0x0025dc:	ble     	#0x26c2
0x0025de:	movs    	r1, #0
0x0025e0:	str     	r1, [sp]
0x0025e2:	str     	r1, [sp, #4]
0x0025e4:	movs    	r1, #0xff
0x0025e6:	movs    	r2, #0
0x0025e8:	adds    	r3, r5, #0
0x0025ea:	adds    	r1, #0x25
0x0025ec:	movs    	r0, #0xf1
0x0025ee:	lsls    	r0, r0, #9
0x0025f0:	str     	r2, [sp, #8]
0x0025f2:	bl      	#0x4408
0x0025f6:	ldr     	r0, [pc, #0x364]
0x0025f8:	movs    	r3, #0
0x0025fa:	add     	r0, sb
0x0025fc:	ldrsb   	r0, [r0, r3]
0x0025fe:	cmp     	r0, #0
0x002600:	bne     	#0x2608
0x002602:	ldr     	r4, [pc, #0x35c]
0x002604:	add     	r4, pc
0x002606:	b       	#0x2616
0x002608:	cmp     	r0, #1
0x00260a:	bne     	#0x2612
0x00260c:	ldr     	r4, [pc, #0x354]
0x00260e:	add     	r4, pc
0x002610:	b       	#0x2616
0x002612:	ldr     	r4, [pc, #0x354]
0x002614:	add     	r4, pc
0x002616:	add     	r2, sp, #0x50
0x002618:	add     	r1, sp, #0x54
0x00261a:	movs    	r0, #0
0x00261c:	str     	r0, [sp]
0x00261e:	str     	r1, [sp, #4]
0x002620:	str     	r2, [sp, #8]
0x002622:	adds    	r3, r5, #0
0x002624:	adds    	r2, r6, #0
0x002626:	movs    	r1, #0x2a
0x002628:	movs    	r0, #0xf1
0x00262a:	lsls    	r0, r0, #9
0x00262c:	bl      	#0x4408
0x002630:	movs    	r2, #0
0x002632:	movs    	r1, #0
0x002634:	movs    	r0, #0
0x002636:	bl      	#0x43b8
0x00263a:	movs    	r1, #1
0x00263c:	movs    	r2, #1
0x00263e:	str     	r2, [sp, #8]
0x002640:	str     	r1, [sp]
0x002642:	str     	r1, [sp, #4]
0x002644:	movs    	r1, #0x55
0x002646:	movs    	r2, #0
0x002648:	adds    	r3, r5, #0
0x00264a:	movs    	r0, #0xf1
0x00264c:	lsls    	r0, r0, #9
0x00264e:	bl      	#0x4408
0x002652:	ldr     	r0, [pc, #0x308]
0x002654:	add     	r2, sp, #0x40
0x002656:	add     	r0, sb
0x002658:	ldr     	r6, [r0, #0x14]
0x00265a:	movs    	r0, #0
0x00265c:	add     	r1, sp, #0x44
0x00265e:	str     	r1, [sp, #4]
0x002660:	str     	r0, [sp]
0x002662:	str     	r2, [sp, #8]
0x002664:	adds    	r3, r5, #0
0x002666:	adds    	r2, r6, #0
0x002668:	movs    	r0, #0xf1
0x00266a:	movs    	r1, #0x2a
0x00266c:	lsls    	r0, r0, #9
0x00266e:	bl      	#0x4408
0x002672:	movs    	r1, #0
0x002674:	movs    	r0, #0x2a
0x002676:	str     	r0, [sp, #0x58]
0x002678:	str     	r1, [sp]
0x00267a:	str     	r1, [sp, #4]
0x00267c:	movs    	r2, #0
0x00267e:	movs    	r1, #0x1c
0x002680:	movs    	r0, #0xf1
0x002682:	adds    	r3, r5, #0
0x002684:	lsls    	r0, r0, #9
0x002686:	str     	r2, [sp, #8]
0x002688:	bl      	#0x4408
0x00268c:	ldr     	r1, [sp, #0x58]
0x00268e:	movs    	r2, #0
0x002690:	str     	r0, [sp]

; ===== candidate_002f2c =====
0x002f2c:	push    	{r4, r5, r6, lr}
0x002f2e:	sub     	sp, #0x10
0x002f30:	movs    	r1, #0
0x002f32:	movs    	r2, #0
0x002f34:	str     	r2, [sp, #8]
0x002f36:	str     	r1, [sp]
0x002f38:	str     	r1, [sp, #4]
0x002f3a:	movs    	r5, #0xf1
0x002f3c:	movs    	r4, #0
0x002f3e:	adds    	r3, r4, #0
0x002f40:	lsls    	r5, r5, #9
0x002f42:	movs    	r1, #0xe1
0x002f44:	movs    	r2, #0x74
0x002f46:	adds    	r0, r5, #0
0x002f48:	bl      	#0x4408
0x002f4c:	cmp     	r0, #0
0x002f4e:	bne     	#0x2f66
0x002f50:	movs    	r1, #0
0x002f52:	str     	r1, [sp]
0x002f54:	str     	r1, [sp, #4]
0x002f56:	movs    	r2, #0
0x002f58:	movs    	r1, #0x2c
0x002f5a:	adds    	r3, r4, #0
0x002f5c:	adds    	r0, r5, #0
0x002f5e:	str     	r2, [sp, #8]
0x002f60:	bl      	#0x4408
0x002f64:	b       	#0x2fc2
0x002f66:	movs    	r1, #0
0x002f68:	movs    	r2, #0
0x002f6a:	str     	r2, [sp, #8]
0x002f6c:	str     	r1, [sp]
0x002f6e:	str     	r1, [sp, #4]
0x002f70:	movs    	r1, #0xe1
0x002f72:	movs    	r2, #0x74
0x002f74:	adds    	r3, r4, #0
0x002f76:	adds    	r0, r5, #0
0x002f78:	bl      	#0x4408
0x002f7c:	movs    	r2, #0
0x002f7e:	movs    	r1, #0
0x002f80:	str     	r2, [sp, #8]
0x002f82:	adds    	r3, r4, #0
0x002f84:	adds    	r2, r0, #0
0x002f86:	str     	r1, [sp]
0x002f88:	str     	r1, [sp, #4]
0x002f8a:	movs    	r1, #0xbe
0x002f8c:	movs    	r0, #0xf1
0x002f8e:	lsls    	r0, r0, #9
0x002f90:	bl      	#0x4408
0x002f94:	movs    	r1, #0
0x002f96:	movs    	r2, #0
0x002f98:	str     	r2, [sp, #8]
0x002f9a:	str     	r1, [sp]
0x002f9c:	str     	r1, [sp, #4]
0x002f9e:	movs    	r1, #0x14
0x002fa0:	movs    	r2, #0x74
0x002fa2:	adds    	r3, r4, #0
0x002fa4:	movs    	r0, #0xf1
0x002fa6:	lsls    	r0, r0, #9
0x002fa8:	bl      	#0x4408
0x002fac:	movs    	r1, #0
0x002fae:	str     	r1, [sp]
0x002fb0:	str     	r1, [sp, #4]
0x002fb2:	movs    	r2, #0
0x002fb4:	movs    	r1, #0xbf
0x002fb6:	adds    	r3, r4, #0
0x002fb8:	movs    	r0, #0xf1
0x002fba:	lsls    	r0, r0, #9
0x002fbc:	str     	r2, [sp, #8]
0x002fbe:	bl      	#0x4408
0x002fc2:	movs    	r1, #0
0x002fc4:	str     	r1, [sp]
0x002fc6:	str     	r1, [sp, #4]
0x002fc8:	movs    	r2, #0
0x002fca:	ldr     	r6, [pc, #0x58]
0x002fcc:	str     	r2, [sp, #8]
0x002fce:	movs    	r1, #0x12
0x002fd0:	adds    	r3, r4, #0
0x002fd2:	add     	r6, sb
0x002fd4:	ldr     	r2, [r6, #0x1c]
0x002fd6:	adds    	r0, r5, #0
0x002fd8:	bl      	#0x4408
0x002fdc:	str     	r4, [r6, #0x1c]
0x002fde:	movs    	r1, #0
0x002fe0:	str     	r1, [sp]
0x002fe2:	str     	r1, [sp, #4]
0x002fe4:	movs    	r2, #0
0x002fe6:	movs    	r1, #0x7d
0x002fe8:	adds    	r3, r4, #0
0x002fea:	movs    	r0, #0xf1
0x002fec:	lsls    	r0, r0, #9
0x002fee:	str     	r2, [sp, #8]
0x002ff0:	bl      	#0x4408
0x002ff4:	movs    	r1, #0
0x002ff6:	movs    	r2, #0
0x002ff8:	str     	r2, [sp, #8]
0x002ffa:	str     	r1, [sp]
0x002ffc:	str     	r1, [sp, #4]
0x002ffe:	movs    	r1, #0x14
0x003000:	movs    	r2, #0xca
0x003002:	adds    	r3, r4, #0
0x003004:	movs    	r0, #0xf1
0x003006:	lsls    	r0, r0, #9
0x003008:	bl      	#0x4408
0x00300c:	movs    	r1, #0
0x00300e:	movs    	r2, #0
0x003010:	str     	r1, [sp]
0x003012:	str     	r1, [sp, #4]
0x003014:	ldr     	r1, [pc, #0x10]
0x003016:	str     	r2, [sp, #8]
0x003018:	adds    	r3, r4, #0
0x00301a:	ldr     	r0, [pc, #0x10]
0x00301c:	bl      	#0x4408
0x003020:	add     	sp, #0x10
0x003022:	pop     	{r4, r5, r6, pc}

; ===== candidate_003030 =====
0x003030:	push    	{r4, r5, r6, r7, lr}
0x003032:	lsls    	r4, r0, #2
0x003034:	adds    	r4, r4, r0
0x003036:	sub     	sp, #0xc
0x003038:	lsls    	r4, r4, #1
0x00303a:	movs    	r1, #0
0x00303c:	adds    	r6, r4, #0
0x00303e:	movs    	r5, #0
0x003040:	movs    	r2, #0
0x003042:	str     	r2, [sp, #8]
0x003044:	adds    	r3, r5, #0
0x003046:	adds    	r6, #9
0x003048:	str     	r1, [sp]
0x00304a:	str     	r1, [sp, #4]
0x00304c:	movs    	r1, #0x3f
0x00304e:	adds    	r2, r4, #0
0x003050:	movs    	r0, #0xf1
0x003052:	lsls    	r0, r0, #9
0x003054:	bl      	#0x4408
0x003058:	movs    	r2, #0
0x00305a:	adds    	r4, r0, #0
0x00305c:	movs    	r1, #0
0x00305e:	ldr     	r3, [pc, #0x9c]
0x003060:	str     	r1, [sp]
0x003062:	str     	r1, [sp, #4]
0x003064:	str     	r2, [sp, #8]
0x003066:	add     	r3, pc
0x003068:	adds    	r2, r0, #0
0x00306a:	movs    	r0, #0xf1
0x00306c:	movs    	r1, #0x2d
0x00306e:	lsls    	r0, r0, #9
0x003070:	bl      	#0x4408
0x003074:	movs    	r1, #0
0x003076:	adds    	r7, r0, #0
0x003078:	movs    	r2, #0
0x00307a:	str     	r2, [sp, #8]
0x00307c:	str     	r1, [sp]
0x00307e:	str     	r1, [sp, #4]
0x003080:	adds    	r3, r5, #0
0x003082:	adds    	r2, r4, #0
0x003084:	movs    	r1, #9
0x003086:	movs    	r0, #0xf1
0x003088:	lsls    	r0, r0, #9
0x00308a:	bl      	#0x4408
0x00308e:	movs    	r1, #0
0x003090:	movs    	r2, #0
0x003092:	str     	r2, [sp, #8]
0x003094:	str     	r1, [sp]
0x003096:	str     	r1, [sp, #4]
0x003098:	adds    	r3, r5, #0
0x00309a:	adds    	r2, r6, #0
0x00309c:	movs    	r1, #0x3f
0x00309e:	movs    	r0, #0xf1
0x0030a0:	lsls    	r0, r0, #9
0x0030a2:	bl      	#0x4408
0x0030a6:	movs    	r1, #0
0x0030a8:	adds    	r4, r0, #0
0x0030aa:	movs    	r2, #0
0x0030ac:	adds    	r3, r0, #0
0x0030ae:	str     	r2, [sp, #8]
0x0030b0:	str     	r1, [sp]
0x0030b2:	str     	r1, [sp, #4]
0x0030b4:	movs    	r1, #0x2d
0x0030b6:	adds    	r2, r7, #0
0x0030b8:	movs    	r0, #0xf1
0x0030ba:	lsls    	r0, r0, #9
0x0030bc:	bl      	#0x4408
0x0030c0:	movs    	r2, #0
0x0030c2:	movs    	r1, #0
0x0030c4:	ldr     	r3, [pc, #0x38]
0x0030c6:	str     	r1, [sp]
0x0030c8:	str     	r1, [sp, #4]
0x0030ca:	str     	r2, [sp, #8]
0x0030cc:	add     	r3, pc
0x0030ce:	adds    	r2, r0, #0
0x0030d0:	movs    	r0, #0xf1
0x0030d2:	movs    	r1, #0x2d
0x0030d4:	lsls    	r0, r0, #9
0x0030d6:	bl      	#0x4408
0x0030da:	movs    	r1, #0
0x0030dc:	adds    	r6, r0, #0
0x0030de:	movs    	r2, #0
0x0030e0:	str     	r2, [sp, #8]
0x0030e2:	str     	r1, [sp]
0x0030e4:	str     	r1, [sp, #4]
0x0030e6:	adds    	r3, r5, #0
0x0030e8:	adds    	r2, r4, #0
0x0030ea:	movs    	r1, #9
0x0030ec:	movs    	r0, #0xf1
0x0030ee:	lsls    	r0, r0, #9
0x0030f0:	bl      	#0x4408
0x0030f4:	adds    	r0, r6, #0
0x0030f6:	add     	sp, #0xc
0x0030f8:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00317c =====
0x00317c:	push    	{r4, r5, r6, r7, lr}
0x00317e:	movs    	r2, #0
0x003180:	sub     	sp, #0xc
0x003182:	movs    	r1, #0
0x003184:	ldr     	r3, [pc, #0x13c]
0x003186:	str     	r1, [sp]
0x003188:	str     	r1, [sp, #4]
0x00318a:	str     	r2, [sp, #8]
0x00318c:	add     	r3, pc
0x00318e:	movs    	r6, #0xf1
0x003190:	lsls    	r6, r6, #9
0x003192:	adds    	r2, r0, #0
0x003194:	movs    	r1, #0x2d
0x003196:	adds    	r0, r6, #0
0x003198:	bl      	#0x4408
0x00319c:	adds    	r4, r0, #0
0x00319e:	ldr     	r0, [pc, #0x128]
0x0031a0:	movs    	r7, #0
0x0031a2:	add     	r0, sb
0x0031a4:	ldr     	r5, [r0, #8]
0x0031a6:	cmp     	r5, #0
0x0031a8:	beq     	#0x3220
0x0031aa:	movs    	r1, #0
0x0031ac:	movs    	r2, #0
0x0031ae:	str     	r2, [sp, #8]
0x0031b0:	str     	r1, [sp]
0x0031b2:	str     	r1, [sp, #4]
0x0031b4:	movs    	r1, #0x3f
0x0031b6:	adds    	r2, r5, #0
0x0031b8:	adds    	r3, r7, #0
0x0031ba:	adds    	r0, r6, #0
0x0031bc:	bl      	#0x4408
0x0031c0:	movs    	r2, #0
0x0031c2:	adds    	r5, r0, #0
0x0031c4:	movs    	r1, #0
0x0031c6:	ldr     	r3, [pc, #0x104]
0x0031c8:	str     	r1, [sp]
0x0031ca:	str     	r1, [sp, #4]
0x0031cc:	str     	r2, [sp, #8]
0x0031ce:	add     	r3, pc
0x0031d0:	adds    	r2, r4, #0
0x0031d2:	movs    	r1, #0x2d
0x0031d4:	adds    	r0, r6, #0
0x0031d6:	bl      	#0x4408
0x0031da:	movs    	r1, #0
0x0031dc:	movs    	r2, #0
0x0031de:	str     	r2, [sp, #8]
0x0031e0:	str     	r1, [sp]
0x0031e2:	str     	r1, [sp, #4]
0x0031e4:	movs    	r1, #0x2d
0x0031e6:	adds    	r2, r0, #0
0x0031e8:	adds    	r3, r5, #0
0x0031ea:	adds    	r0, r6, #0
0x0031ec:	bl      	#0x4408
0x0031f0:	movs    	r2, #0
0x0031f2:	movs    	r1, #0
0x0031f4:	ldr     	r3, [pc, #0xd8]
0x0031f6:	str     	r1, [sp]
0x0031f8:	str     	r1, [sp, #4]
0x0031fa:	str     	r2, [sp, #8]
0x0031fc:	add     	r3, pc
0x0031fe:	adds    	r2, r0, #0
0x003200:	movs    	r1, #0x2d
0x003202:	adds    	r0, r6, #0
0x003204:	bl      	#0x4408
0x003208:	movs    	r1, #0
0x00320a:	movs    	r2, #0
0x00320c:	str     	r2, [sp, #8]
0x00320e:	str     	r1, [sp]
0x003210:	str     	r1, [sp, #4]
0x003212:	movs    	r1, #9
0x003214:	adds    	r2, r5, #0
0x003216:	adds    	r4, r0, #0
0x003218:	adds    	r3, r7, #0
0x00321a:	adds    	r0, r6, #0
0x00321c:	bl      	#0x4408
0x003220:	ldr     	r0, [pc, #0xa4]
0x003222:	add     	r0, sb
0x003224:	ldr     	r5, [r0, #0xc]
0x003226:	cmp     	r5, #0
0x003228:	beq     	#0x32a8
0x00322a:	movs    	r1, #0
0x00322c:	movs    	r2, #0
0x00322e:	str     	r2, [sp, #8]
0x003230:	str     	r1, [sp]
0x003232:	str     	r1, [sp, #4]
0x003234:	movs    	r1, #0x3f
0x003236:	adds    	r2, r5, #0
0x003238:	adds    	r3, r7, #0
0x00323a:	adds    	r0, r6, #0
0x00323c:	bl      	#0x4408
0x003240:	movs    	r2, #0
0x003242:	adds    	r5, r0, #0
0x003244:	movs    	r1, #0
0x003246:	ldr     	r3, [pc, #0x8c]
0x003248:	str     	r1, [sp]
0x00324a:	str     	r1, [sp, #4]
0x00324c:	str     	r2, [sp, #8]
0x00324e:	add     	r3, pc
0x003250:	adds    	r2, r4, #0
0x003252:	movs    	r1, #0x2d
0x003254:	movs    	r0, #0xf1
0x003256:	lsls    	r0, r0, #9
0x003258:	bl      	#0x4408
0x00325c:	movs    	r2, #0
0x00325e:	movs    	r1, #0
0x003260:	str     	r2, [sp, #8]
0x003262:	adds    	r3, r5, #0
0x003264:	adds    	r2, r0, #0
0x003266:	str     	r1, [sp]
0x003268:	str     	r1, [sp, #4]
0x00326a:	movs    	r1, #0x2d
0x00326c:	movs    	r0, #0xf1
0x00326e:	lsls    	r0, r0, #9
0x003270:	bl      	#0x4408
0x003274:	movs    	r2, #0
0x003276:	movs    	r1, #0
0x003278:	ldr     	r3, [pc, #0x5c]
0x00327a:	str     	r1, [sp]
0x00327c:	str     	r1, [sp, #4]
0x00327e:	str     	r2, [sp, #8]
0x003280:	add     	r3, pc
0x003282:	adds    	r2, r0, #0
0x003284:	movs    	r0, #0xf1
0x003286:	movs    	r1, #0x2d
0x003288:	lsls    	r0, r0, #9
0x00328a:	bl      	#0x4408
0x00328e:	movs    	r1, #0
0x003290:	adds    	r4, r0, #0
0x003292:	movs    	r2, #0
0x003294:	str     	r2, [sp, #8]
0x003296:	str     	r1, [sp]
0x003298:	str     	r1, [sp, #4]
0x00329a:	adds    	r3, r7, #0
0x00329c:	adds    	r2, r5, #0
0x00329e:	movs    	r1, #9
0x0032a0:	movs    	r0, #0xf1
0x0032a2:	lsls    	r0, r0, #9
0x0032a4:	bl      	#0x4408
0x0032a8:	movs    	r2, #0
0x0032aa:	movs    	r1, #0

; ===== candidate_0032e0 =====
0x0032e0:	push    	{r4, r5, lr}
0x0032e2:	ldr     	r5, [pc, #0x64]
0x0032e4:	sub     	sp, #0xc
0x0032e6:	movs    	r0, #2
0x0032e8:	add     	r5, sb
0x0032ea:	strb    	r0, [r5]
0x0032ec:	movs    	r1, #0
0x0032ee:	str     	r1, [sp]
0x0032f0:	str     	r1, [sp, #4]
0x0032f2:	movs    	r4, #0
0x0032f4:	movs    	r2, #0
0x0032f6:	adds    	r3, r4, #0
0x0032f8:	movs    	r1, #0xa4
0x0032fa:	movs    	r0, #0xf1
0x0032fc:	lsls    	r0, r0, #9
0x0032fe:	str     	r2, [sp, #8]
0x003300:	bl      	#0x4408
0x003304:	movs    	r1, #0
0x003306:	str     	r1, [sp]
0x003308:	str     	r1, [sp, #4]
0x00330a:	movs    	r2, #0
0x00330c:	movs    	r1, #0x34
0x00330e:	adds    	r3, r4, #0
0x003310:	movs    	r0, #0xf1
0x003312:	lsls    	r0, r0, #9
0x003314:	str     	r2, [sp, #8]
0x003316:	bl      	#0x4408
0x00331a:	ldr     	r1, [pc, #0x30]
0x00331c:	movs    	r0, #1
0x00331e:	add     	r1, sb
0x003320:	strb    	r0, [r1]
0x003322:	movs    	r1, #0
0x003324:	movs    	r2, #0
0x003326:	str     	r2, [sp, #8]
0x003328:	str     	r1, [sp]
0x00332a:	str     	r1, [sp, #4]
0x00332c:	movs    	r1, #0x14
0x00332e:	movs    	r2, #0xf9
0x003330:	movs    	r0, #0xf1
0x003332:	adds    	r3, r4, #0
0x003334:	lsls    	r0, r0, #9
0x003336:	bl      	#0x4408
0x00333a:	movs    	r3, #0
0x00333c:	ldrsb   	r1, [r5, r3]
0x00333e:	mvns    	r0, r3
0x003340:	bl      	#0x4a70
0x003344:	add     	sp, #0xc
0x003346:	pop     	{r4, r5, pc}

; ===== candidate_003350 =====
0x003350:	push    	{r4, r5, r6, r7, lr}
0x003352:	sub     	sp, #0xc
0x003354:	movs    	r1, #0
0x003356:	movs    	r2, #0
0x003358:	str     	r2, [sp, #8]
0x00335a:	str     	r1, [sp]
0x00335c:	str     	r1, [sp, #4]
0x00335e:	movs    	r6, #0
0x003360:	adds    	r3, r6, #0
0x003362:	movs    	r1, #0x14
0x003364:	movs    	r2, #0xf9
0x003366:	movs    	r4, #0
0x003368:	movs    	r0, #0xf1
0x00336a:	lsls    	r0, r0, #9
0x00336c:	bl      	#0x4408
0x003370:	ldr     	r1, [pc, #0x1c8]
0x003372:	movs    	r2, #0
0x003374:	add     	r1, sb
0x003376:	str     	r6, [r1, #0x20]
0x003378:	str     	r6, [r1, #0x14]
0x00337a:	movs    	r1, #0
0x00337c:	str     	r1, [sp]
0x00337e:	str     	r1, [sp, #4]
0x003380:	str     	r2, [sp, #8]
0x003382:	movs    	r2, #0x74
0x003384:	movs    	r1, #0x14
0x003386:	adds    	r3, r6, #0
0x003388:	movs    	r0, #0xf1
0x00338a:	lsls    	r0, r0, #9
0x00338c:	bl      	#0x4408
0x003390:	movs    	r1, #0
0x003392:	movs    	r2, #0
0x003394:	str     	r2, [sp, #8]
0x003396:	str     	r1, [sp]
0x003398:	str     	r1, [sp, #4]
0x00339a:	movs    	r1, #0x14
0x00339c:	movs    	r2, #0xfc
0x00339e:	adds    	r3, r6, #0
0x0033a0:	movs    	r0, #0xf1
0x0033a2:	lsls    	r0, r0, #9
0x0033a4:	bl      	#0x4408
0x0033a8:	movs    	r1, #0
0x0033aa:	str     	r1, [sp]
0x0033ac:	str     	r1, [sp, #4]
0x0033ae:	movs    	r2, #0
0x0033b0:	movs    	r1, #0xa4
0x0033b2:	adds    	r3, r6, #0
0x0033b4:	movs    	r0, #0xf1
0x0033b6:	lsls    	r0, r0, #9
0x0033b8:	str     	r2, [sp, #8]
0x0033ba:	bl      	#0x4408
0x0033be:	movs    	r1, #0
0x0033c0:	str     	r1, [sp]
0x0033c2:	str     	r1, [sp, #4]
0x0033c4:	movs    	r2, #0
0x0033c6:	movs    	r1, #0x34
0x0033c8:	adds    	r3, r6, #0
0x0033ca:	movs    	r0, #0xf1
0x0033cc:	lsls    	r0, r0, #9
0x0033ce:	str     	r2, [sp, #8]
0x0033d0:	bl      	#0x4408
0x0033d4:	movs    	r1, #0
0x0033d6:	str     	r1, [sp]
0x0033d8:	str     	r1, [sp, #4]
0x0033da:	movs    	r2, #0
0x0033dc:	movs    	r1, #0x13
0x0033de:	adds    	r3, r6, #0
0x0033e0:	movs    	r0, #0xf1
0x0033e2:	lsls    	r0, r0, #9
0x0033e4:	str     	r2, [sp, #8]
0x0033e6:	bl      	#0x4408
0x0033ea:	movs    	r2, #0
0x0033ec:	adds    	r5, r0, #0
0x0033ee:	movs    	r1, #0
0x0033f0:	ldr     	r7, [pc, #0x14c]
0x0033f2:	str     	r1, [sp]
0x0033f4:	str     	r1, [sp, #4]
0x0033f6:	str     	r2, [sp, #8]
0x0033f8:	add     	r7, pc
0x0033fa:	adds    	r3, r7, #0
0x0033fc:	adds    	r2, r7, #0
0x0033fe:	adds    	r2, #0x10
0x003400:	movs    	r1, #0x35
0x003402:	movs    	r0, #0xf1
0x003404:	lsls    	r0, r0, #9
0x003406:	bl      	#0x4408
0x00340a:	movs    	r1, #0
0x00340c:	adds    	r3, r0, #0
0x00340e:	movs    	r2, #0
0x003410:	str     	r2, [sp, #8]
0x003412:	str     	r1, [sp]
0x003414:	str     	r1, [sp, #4]
0x003416:	movs    	r1, #0x36
0x003418:	adds    	r2, r5, #0
0x00341a:	movs    	r0, #0xf1
0x00341c:	lsls    	r0, r0, #9
0x00341e:	bl      	#0x4408
0x003422:	movs    	r1, #0
0x003424:	movs    	r2, #0
0x003426:	str     	r2, [sp, #8]
0x003428:	str     	r1, [sp]
0x00342a:	str     	r1, [sp, #4]
0x00342c:	adds    	r3, r7, #0
0x00342e:	adds    	r2, r7, #4
0x003430:	movs    	r1, #0x35
0x003432:	movs    	r0, #0xf1
0x003434:	lsls    	r0, r0, #9
0x003436:	bl      	#0x4408
0x00343a:	movs    	r1, #0
0x00343c:	adds    	r3, r0, #0
0x00343e:	movs    	r2, #0
0x003440:	str     	r2, [sp, #8]
0x003442:	str     	r1, [sp]
0x003444:	str     	r1, [sp, #4]
0x003446:	movs    	r1, #0x36
0x003448:	adds    	r2, r5, #0
0x00344a:	movs    	r0, #0xf1
0x00344c:	lsls    	r0, r0, #9
0x00344e:	bl      	#0x4408
0x003452:	movs    	r2, #0
0x003454:	movs    	r1, #0
0x003456:	str     	r2, [sp, #8]
0x003458:	adds    	r2, r7, #0
0x00345a:	str     	r1, [sp]
0x00345c:	str     	r1, [sp, #4]
0x00345e:	adds    	r3, r7, #0
0x003460:	subs    	r2, #8
0x003462:	movs    	r1, #0x35
0x003464:	movs    	r0, #0xf1
0x003466:	lsls    	r0, r0, #9
0x003468:	bl      	#0x4408
0x00346c:	movs    	r1, #0
0x00346e:	adds    	r3, r0, #0
0x003470:	movs    	r2, #0
0x003472:	str     	r2, [sp, #8]
0x003474:	str     	r1, [sp]
0x003476:	str     	r1, [sp, #4]
0x003478:	movs    	r1, #0x36
0x00347a:	adds    	r2, r5, #0
0x00347c:	movs    	r0, #0xf1
0x00347e:	lsls    	r0, r0, #9

; ===== candidate_003544 =====
0x003544:	push    	{r4, r5, r6, r7, lr}
0x003546:	sub     	sp, #0xc
0x003548:	adds    	r6, r1, #0
0x00354a:	movs    	r1, #0
0x00354c:	movs    	r2, #0
0x00354e:	str     	r2, [sp, #8]
0x003550:	str     	r1, [sp]
0x003552:	str     	r1, [sp, #4]
0x003554:	movs    	r5, #0xf1
0x003556:	movs    	r4, #0
0x003558:	adds    	r3, r4, #0
0x00355a:	lsls    	r5, r5, #9
0x00355c:	movs    	r1, #0xe1
0x00355e:	movs    	r2, #0x17
0x003560:	adds    	r7, r0, #0
0x003562:	adds    	r0, r5, #0
0x003564:	bl      	#0x4408
0x003568:	subs    	r0, #0xff
0x00356a:	subs    	r0, #0x1a
0x00356c:	beq     	#0x359e
0x00356e:	movs    	r1, #0
0x003570:	movs    	r2, #0
0x003572:	str     	r2, [sp, #8]
0x003574:	str     	r1, [sp]
0x003576:	str     	r1, [sp, #4]
0x003578:	movs    	r1, #0xe1
0x00357a:	movs    	r2, #0x74
0x00357c:	adds    	r3, r4, #0
0x00357e:	adds    	r0, r5, #0
0x003580:	bl      	#0x4408
0x003584:	cmp     	r0, #0
0x003586:	bne     	#0x35a2
0x003588:	movs    	r1, #0
0x00358a:	str     	r1, [sp]
0x00358c:	str     	r1, [sp, #4]
0x00358e:	movs    	r2, #0
0x003590:	movs    	r1, #0x34
0x003592:	adds    	r3, r4, #0
0x003594:	adds    	r0, r5, #0
0x003596:	str     	r2, [sp, #8]
0x003598:	bl      	#0x4408
0x00359c:	b       	#0x35a2
0x00359e:	bl      	#0x48b4
0x0035a2:	ldr     	r0, [pc, #0x44]
0x0035a4:	cmp     	r6, #0
0x0035a6:	add     	r0, sb
0x0035a8:	str     	r6, [r0, #0x38]
0x0035aa:	str     	r7, [r0, #0x34]
0x0035ac:	bne     	#0x35b2
0x0035ae:	movs    	r1, #1
0x0035b0:	str     	r1, [r0, #0x38]
0x0035b2:	str     	r4, [r0, #0x3c]
0x0035b4:	movs    	r1, #0
0x0035b6:	str     	r1, [sp]
0x0035b8:	str     	r1, [sp, #4]
0x0035ba:	movs    	r2, #0
0x0035bc:	movs    	r1, #0xba
0x0035be:	adds    	r3, r4, #0
0x0035c0:	adds    	r0, r5, #0
0x0035c2:	str     	r2, [sp, #8]
0x0035c4:	bl      	#0x4408
0x0035c8:	movs    	r1, #0
0x0035ca:	movs    	r2, #0
0x0035cc:	str     	r2, [sp, #8]
0x0035ce:	str     	r1, [sp]
0x0035d0:	str     	r1, [sp, #4]
0x0035d2:	movs    	r3, #0xff
0x0035d4:	adds    	r3, #0x1a
0x0035d6:	movs    	r1, #0x14
0x0035d8:	movs    	r2, #0x17
0x0035da:	movs    	r0, #0xf1
0x0035dc:	lsls    	r0, r0, #9
0x0035de:	bl      	#0x4408
0x0035e2:	add     	sp, #0xc
0x0035e4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0035ec =====
0x0035ec:	push    	{r4, r5, r6, r7, lr}
0x0035ee:	sub     	sp, #0xc
0x0035f0:	movs    	r1, #0
0x0035f2:	str     	r1, [sp]
0x0035f4:	str     	r1, [sp, #4]
0x0035f6:	adds    	r5, r0, #0
0x0035f8:	movs    	r2, #0
0x0035fa:	movs    	r0, #0xf1
0x0035fc:	movs    	r1, #0x13
0x0035fe:	movs    	r3, #0
0x003600:	lsls    	r0, r0, #9
0x003602:	str     	r2, [sp, #8]
0x003604:	bl      	#0x4408
0x003608:	ldr     	r6, [pc, #0x284]
0x00360a:	adds    	r4, r0, #0
0x00360c:	add     	r6, sb
0x00360e:	adds    	r1, r6, #0
0x003610:	str     	r5, [r6, #0x24]
0x003612:	movs    	r0, #0
0x003614:	str     	r0, [r1, #0x2c]
0x003616:	movs    	r1, #0
0x003618:	str     	r1, [sp, #4]
0x00361a:	str     	r0, [sp]
0x00361c:	movs    	r2, #0
0x00361e:	movs    	r0, #0xf1
0x003620:	movs    	r1, #0x34
0x003622:	movs    	r3, #0
0x003624:	lsls    	r0, r0, #9
0x003626:	str     	r2, [sp, #8]
0x003628:	bl      	#0x4408
0x00362c:	adds    	r0, r6, #0
0x00362e:	ldr     	r0, [r0, #0x24]
0x003630:	ldr     	r5, [pc, #0x260]
0x003632:	add     	r5, pc
0x003634:	cmp     	r0, #0
0x003636:	beq     	#0x36ea
0x003638:	movs    	r1, #0
0x00363a:	movs    	r2, #0
0x00363c:	str     	r2, [sp, #8]
0x00363e:	str     	r1, [sp]
0x003640:	str     	r1, [sp, #4]
0x003642:	movs    	r7, #0xf1
0x003644:	lsls    	r7, r7, #9
0x003646:	movs    	r1, #0xe1
0x003648:	movs    	r2, #0x18
0x00364a:	movs    	r3, #0
0x00364c:	adds    	r0, r7, #0
0x00364e:	bl      	#0x4408
0x003652:	ldr     	r1, [r6, #0x24]
0x003654:	ldr     	r0, [r0, #0xc]
0x003656:	ldr     	r1, [r1, #8]
0x003658:	cmp     	r0, r1
0x00365a:	beq     	#0x36e8
0x00365c:	movs    	r1, #0
0x00365e:	movs    	r2, #0
0x003660:	str     	r2, [sp, #8]
0x003662:	str     	r1, [sp]
0x003664:	str     	r1, [sp, #4]
0x003666:	movs    	r1, #0xe1
0x003668:	movs    	r2, #0x18
0x00366a:	movs    	r3, #0
0x00366c:	adds    	r0, r7, #0
0x00366e:	bl      	#0x4408
0x003672:	ldr     	r0, [r0, #0xc]
0x003674:	bl      	#0x3a04
0x003678:	cmp     	r0, #0
0x00367a:	bne     	#0x36aa
0x00367c:	movs    	r2, #0
0x00367e:	movs    	r1, #0
0x003680:	str     	r2, [sp, #8]
0x003682:	adds    	r2, r5, #0
0x003684:	str     	r1, [sp]
0x003686:	str     	r1, [sp, #4]
0x003688:	movs    	r1, #0x35
0x00368a:	adds    	r2, #0xf4
0x00368c:	adds    	r3, r5, #0
0x00368e:	adds    	r0, r7, #0
0x003690:	bl      	#0x4408
0x003694:	movs    	r1, #0
0x003696:	movs    	r2, #0
0x003698:	str     	r2, [sp, #8]
0x00369a:	str     	r1, [sp]
0x00369c:	str     	r1, [sp, #4]
0x00369e:	movs    	r1, #0x36
0x0036a0:	adds    	r2, r4, #0
0x0036a2:	adds    	r3, r0, #0
0x0036a4:	adds    	r0, r7, #0
0x0036a6:	bl      	#0x4408
0x0036aa:	ldr     	r0, [r6, #0x24]
0x0036ac:	ldr     	r2, [pc, #0x1e8]
0x0036ae:	ldr     	r1, [r0, #8]
0x0036b0:	add     	r2, sb
0x0036b2:	str     	r1, [r2, #8]
0x0036b4:	ldr     	r0, [r0, #4]
0x0036b6:	movs    	r1, #0
0x0036b8:	str     	r0, [r2, #4]
0x0036ba:	movs    	r2, #0
0x0036bc:	str     	r2, [sp, #8]
0x0036be:	ldr     	r2, [pc, #0x1dc]
0x0036c0:	adds    	r3, r5, #0
0x0036c2:	str     	r1, [sp]
0x0036c4:	str     	r1, [sp, #4]
0x0036c6:	add     	r2, pc
0x0036c8:	movs    	r1, #0x35
0x0036ca:	adds    	r0, r7, #0
0x0036cc:	bl      	#0x4408
0x0036d0:	movs    	r1, #0
0x0036d2:	adds    	r3, r0, #0
0x0036d4:	movs    	r2, #0
0x0036d6:	str     	r2, [sp, #8]
0x0036d8:	str     	r1, [sp]
0x0036da:	str     	r1, [sp, #4]
0x0036dc:	movs    	r1, #0x36
0x0036de:	adds    	r2, r4, #0
0x0036e0:	movs    	r0, #0xf1
0x0036e2:	lsls    	r0, r0, #9
0x0036e4:	bl      	#0x4408
0x0036e8:	b       	#0x36f6
0x0036ea:	ldr     	r2, [pc, #0x1ac]
0x0036ec:	movs    	r0, #0
0x0036ee:	mvns    	r0, r0
0x0036f0:	add     	r2, sb
0x0036f2:	str     	r0, [r2, #4]
0x0036f4:	str     	r0, [r2, #8]
0x0036f6:	bl      	#0x399c
0x0036fa:	cmp     	r0, #1
0x0036fc:	bne     	#0x3730
0x0036fe:	movs    	r2, #0
0x003700:	movs    	r1, #0
0x003702:	str     	r2, [sp, #8]
0x003704:	ldr     	r2, [pc, #0x198]
0x003706:	str     	r1, [sp]
0x003708:	str     	r1, [sp, #4]
0x00370a:	adds    	r3, r5, #0
0x00370c:	add     	r2, pc
0x00370e:	movs    	r1, #0x35
0x003710:	movs    	r0, #0xf1
0x003712:	lsls    	r0, r0, #9
0x003714:	bl      	#0x4408
0x003718:	movs    	r1, #0
0x00371a:	adds    	r3, r0, #0

; ===== candidate_0038b0 =====
0x0038b0:	push    	{r0, r1, r2, r4, r5, r6, r7, lr}
0x0038b2:	sub     	sp, #0x10
0x0038b4:	movs    	r1, #0
0x0038b6:	adds    	r7, r2, #0
0x0038b8:	movs    	r2, #0
0x0038ba:	str     	r1, [sp]
0x0038bc:	str     	r1, [sp, #4]
0x0038be:	movs    	r5, #0xf1
0x0038c0:	movs    	r4, #0
0x0038c2:	adds    	r3, r4, #0
0x0038c4:	lsls    	r5, r5, #9
0x0038c6:	movs    	r1, #0xba
0x0038c8:	adds    	r0, r5, #0
0x0038ca:	str     	r2, [sp, #8]
0x0038cc:	bl      	#0x4408
0x0038d0:	movs    	r1, #0
0x0038d2:	movs    	r2, #0
0x0038d4:	str     	r2, [sp, #8]
0x0038d6:	str     	r1, [sp]
0x0038d8:	str     	r1, [sp, #4]
0x0038da:	movs    	r1, #0x14
0x0038dc:	movs    	r2, #0x74
0x0038de:	adds    	r3, r4, #0
0x0038e0:	adds    	r0, r5, #0
0x0038e2:	bl      	#0x4408
0x0038e6:	movs    	r1, #0
0x0038e8:	movs    	r2, #0
0x0038ea:	str     	r2, [sp, #8]
0x0038ec:	str     	r1, [sp]
0x0038ee:	str     	r1, [sp, #4]
0x0038f0:	movs    	r1, #0x14
0x0038f2:	movs    	r2, #0xfc
0x0038f4:	adds    	r3, r4, #0
0x0038f6:	adds    	r0, r5, #0
0x0038f8:	bl      	#0x4408
0x0038fc:	ldr     	r6, [pc, #0x98]
0x0038fe:	add     	r6, sb
0x003900:	ldr     	r3, [r6, #0x30]
0x003902:	cmp     	r3, #0
0x003904:	beq     	#0x391e
0x003906:	movs    	r1, #0
0x003908:	str     	r1, [sp]
0x00390a:	str     	r1, [sp, #4]
0x00390c:	movs    	r2, #0
0x00390e:	str     	r2, [sp, #8]
0x003910:	movs    	r1, #0xff
0x003912:	adds    	r1, #0xb
0x003914:	adds    	r2, r3, #0
0x003916:	adds    	r0, r5, #0
0x003918:	adds    	r3, r4, #0
0x00391a:	bl      	#0x4408
0x00391e:	movs    	r1, #0
0x003920:	movs    	r2, #0
0x003922:	str     	r2, [sp, #8]
0x003924:	str     	r1, [sp]
0x003926:	str     	r1, [sp, #4]
0x003928:	movs    	r1, #0x14
0x00392a:	movs    	r2, #0xed
0x00392c:	movs    	r3, #1
0x00392e:	adds    	r0, r5, #0
0x003930:	bl      	#0x4408
0x003934:	ldr     	r0, [sp, #0x10]
0x003936:	movs    	r1, #0
0x003938:	str     	r0, [r6, #0x30]
0x00393a:	movs    	r2, #0
0x00393c:	str     	r2, [sp, #8]
0x00393e:	str     	r1, [sp]
0x003940:	str     	r1, [sp, #4]
0x003942:	movs    	r1, #0x14
0x003944:	movs    	r2, #0xfb
0x003946:	movs    	r0, #0xf1
0x003948:	lsls    	r0, r0, #9
0x00394a:	ldr     	r3, [sp, #0x14]
0x00394c:	bl      	#0x4408
0x003950:	cmp     	r7, #1
0x003952:	bne     	#0x3994
0x003954:	movs    	r1, #0
0x003956:	movs    	r2, #0
0x003958:	str     	r2, [sp, #8]
0x00395a:	str     	r1, [sp]
0x00395c:	str     	r1, [sp, #4]
0x00395e:	movs    	r1, #0xe1
0x003960:	movs    	r2, #0x17
0x003962:	adds    	r3, r4, #0
0x003964:	adds    	r0, r5, #0
0x003966:	bl      	#0x4408
0x00396a:	movs    	r1, #0
0x00396c:	str     	r1, [sp]
0x00396e:	str     	r1, [sp, #4]
0x003970:	movs    	r2, #0
0x003972:	movs    	r1, #0x34
0x003974:	adds    	r3, r4, #0
0x003976:	adds    	r0, r5, #0
0x003978:	str     	r2, [sp, #8]
0x00397a:	bl      	#0x4408
0x00397e:	movs    	r1, #0
0x003980:	movs    	r2, #0
0x003982:	str     	r2, [sp, #8]
0x003984:	str     	r1, [sp]
0x003986:	str     	r1, [sp, #4]
0x003988:	movs    	r1, #0x14
0x00398a:	movs    	r2, #0x17
0x00398c:	movs    	r3, #0xf1
0x00398e:	lsls    	r0, r3, #9
0x003990:	bl      	#0x4408
0x003994:	add     	sp, #0x1c
0x003996:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00399c =====
0x00399c:	push    	{r4, r5, lr}
0x00399e:	sub     	sp, #0xc
0x0039a0:	movs    	r1, #0
0x0039a2:	movs    	r2, #0
0x0039a4:	str     	r2, [sp, #8]
0x0039a6:	str     	r1, [sp]
0x0039a8:	str     	r1, [sp, #4]
0x0039aa:	movs    	r5, #0xf1
0x0039ac:	movs    	r4, #0
0x0039ae:	adds    	r3, r4, #0
0x0039b0:	lsls    	r5, r5, #9
0x0039b2:	movs    	r1, #0xe1
0x0039b4:	movs    	r2, #0xfa
0x0039b6:	adds    	r0, r5, #0
0x0039b8:	bl      	#0x4408
0x0039bc:	lsls    	r1, r0, #2
0x0039be:	ldr     	r0, [pc, #0x40]
0x0039c0:	add     	r0, sb
0x0039c2:	ldr     	r0, [r0, #0x30]
0x0039c4:	ldr     	r1, [r0, r1]
0x0039c6:	cmp     	r1, #0
0x0039c8:	beq     	#0x39d0
0x0039ca:	movs    	r0, #0
0x0039cc:	add     	sp, #0xc
0x0039ce:	pop     	{r4, r5, pc}

; ===== candidate_003a04 =====
0x003a04:	push    	{r4, r5, r6, r7, lr}
0x003a06:	sub     	sp, #0xc
0x003a08:	movs    	r1, #0
0x003a0a:	str     	r1, [sp]
0x003a0c:	str     	r1, [sp, #4]
0x003a0e:	ldr     	r7, [pc, #0x60]
0x003a10:	movs    	r2, #0
0x003a12:	movs    	r5, #0xf1
0x003a14:	lsls    	r5, r5, #9
0x003a16:	str     	r2, [sp, #8]
0x003a18:	movs    	r1, #0x11
0x003a1a:	movs    	r3, #4
0x003a1c:	add     	r7, sb
0x003a1e:	ldr     	r2, [r7, #0x30]
0x003a20:	adds    	r0, r5, #0
0x003a22:	bl      	#0x4408
0x003a26:	adds    	r6, r0, #0
0x003a28:	movs    	r4, #0
0x003a2a:	cmp     	r0, #0
0x003a2c:	ble     	#0x3a6a
0x003a2e:	movs    	r7, #0
0x003a30:	ldr     	r1, [pc, #0x3c]
0x003a32:	lsls    	r0, r4, #2
0x003a34:	add     	r1, sb
0x003a36:	ldr     	r1, [r1, #0x30]
0x003a38:	ldr     	r5, [r1, r0]
0x003a3a:	cmp     	r5, #0
0x003a3c:	beq     	#0x3a64
0x003a3e:	movs    	r1, #0
0x003a40:	movs    	r2, #0
0x003a42:	str     	r2, [sp, #8]
0x003a44:	str     	r1, [sp]
0x003a46:	str     	r1, [sp, #4]
0x003a48:	movs    	r1, #0xe1
0x003a4a:	movs    	r2, #0x18
0x003a4c:	adds    	r3, r7, #0
0x003a4e:	movs    	r0, #0xf1
0x003a50:	lsls    	r0, r0, #9
0x003a52:	bl      	#0x4408
0x003a56:	ldr     	r0, [r0, #0xc]
0x003a58:	ldr     	r1, [r5, #8]
0x003a5a:	cmp     	r0, r1
0x003a5c:	bne     	#0x3a64
0x003a5e:	movs    	r0, #1
0x003a60:	add     	sp, #0xc
0x003a62:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003a74 =====
0x003a74:	push    	{r4, r5, r6, lr}
0x003a76:	ldr     	r5, [pc, #0x2ec]
0x003a78:	sub     	sp, #0x10
0x003a7a:	add     	r5, sb
0x003a7c:	ldr     	r4, [r5, #4]
0x003a7e:	movs    	r1, #0
0x003a80:	str     	r1, [sp]
0x003a82:	str     	r1, [sp, #4]
0x003a84:	movs    	r2, #0
0x003a86:	adds    	r6, r0, #0
0x003a88:	movs    	r0, #0xf1
0x003a8a:	str     	r2, [sp, #8]
0x003a8c:	movs    	r1, #0x11
0x003a8e:	movs    	r3, #4
0x003a90:	lsls    	r0, r0, #9
0x003a92:	ldr     	r2, [r5, #0x30]
0x003a94:	bl      	#0x4408
0x003a98:	adds    	r5, r0, #0
0x003a9a:	subs    	r6, #2
0x003a9c:	cmp     	r6, #0x13
0x003a9e:	bhs     	#0x3aaa
0x003aa0:	adr     	r3, #0xc
0x003aa2:	adds    	r3, r3, r6
0x003aa4:	ldrh    	r3, [r3, r6]
0x003aa6:	lsls    	r3, r3, #1
0x003aa8:	add     	pc, r3
0x003aaa:	add     	sp, #0x10
0x003aac:	pop     	{r4, r5, r6, pc}

; ===== candidate_003d6c =====
0x003d6c:	push    	{r4, r5, r6, r7, lr}
0x003d6e:	sub     	sp, #0xc
0x003d70:	movs    	r1, #0
0x003d72:	str     	r1, [sp]
0x003d74:	str     	r1, [sp, #4]
0x003d76:	ldr     	r5, [pc, #0xd4]
0x003d78:	movs    	r2, #0
0x003d7a:	movs    	r4, #0xf1
0x003d7c:	lsls    	r4, r4, #9
0x003d7e:	str     	r2, [sp, #8]
0x003d80:	movs    	r1, #0x11
0x003d82:	adds    	r6, r0, #0
0x003d84:	movs    	r3, #4
0x003d86:	add     	r5, sb
0x003d88:	ldr     	r2, [r5, #0x1c]
0x003d8a:	adds    	r0, r4, #0
0x003d8c:	bl      	#0x4408
0x003d90:	adds    	r7, r0, #0
0x003d92:	ldr     	r0, [pc, #0xb8]
0x003d94:	adds    	r1, r6, #0
0x003d96:	add     	r0, sb
0x003d98:	adds    	r0, #0x20
0x003d9a:	movs    	r6, #0
0x003d9c:	cmp     	r1, #0xd
0x003d9e:	beq     	#0x3df2
0x003da0:	bgt     	#0x3dcc
0x003da2:	cmp     	r1, #2
0x003da4:	beq     	#0x3db2
0x003da6:	cmp     	r1, #5
0x003da8:	beq     	#0x3dd8
0x003daa:	cmp     	r1, #8
0x003dac:	beq     	#0x3df2
0x003dae:	cmp     	r1, #0xc
0x003db0:	bne     	#0x3dc8
0x003db2:	movs    	r2, #0
0x003db4:	movs    	r1, #0
0x003db6:	str     	r1, [sp, #4]
0x003db8:	str     	r2, [sp, #8]
0x003dba:	adds    	r2, r7, #0
0x003dbc:	movs    	r1, #0x29
0x003dbe:	str     	r0, [sp]
0x003dc0:	adds    	r3, r6, #0
0x003dc2:	adds    	r0, r4, #0
0x003dc4:	bl      	#0x4408
0x003dc8:	add     	sp, #0xc
0x003dca:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_003e54 =====
0x003e54:	push    	{r4, r5, r6, r7, lr}
0x003e56:	ldr     	r5, [pc, #0x2c0]
0x003e58:	movs    	r4, #0xf1
0x003e5a:	add     	r5, sb
0x003e5c:	ldr     	r3, [r5, #0x34]
0x003e5e:	lsls    	r4, r4, #9
0x003e60:	movs    	r7, #0
0x003e62:	adds    	r6, r0, #0
0x003e64:	cmp     	r3, #0
0x003e66:	sub     	sp, #0xc
0x003e68:	beq     	#0x3e84
0x003e6a:	movs    	r1, #0
0x003e6c:	movs    	r2, #0
0x003e6e:	str     	r2, [sp, #8]
0x003e70:	str     	r1, [sp]
0x003e72:	str     	r1, [sp, #4]
0x003e74:	movs    	r1, #0x11
0x003e76:	adds    	r2, r3, #0
0x003e78:	movs    	r7, #4
0x003e7a:	adds    	r0, r4, #0
0x003e7c:	adds    	r3, r7, #0
0x003e7e:	bl      	#0x4408
0x003e82:	adds    	r7, r0, #0
0x003e84:	subs    	r6, #2
0x003e86:	cmp     	r6, #0x13
0x003e88:	bhs     	#0x3e94
0x003e8a:	adr     	r3, #0xc
0x003e8c:	adds    	r3, r3, r6
0x003e8e:	ldrh    	r3, [r3, r6]
0x003e90:	lsls    	r3, r3, #1
0x003e92:	add     	pc, r3
0x003e94:	add     	sp, #0xc
0x003e96:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_004134 =====
0x004134:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x004136:	sub     	sp, #0xc
0x004138:	adds    	r4, r1, #0
0x00413a:	movs    	r1, #0
0x00413c:	adds    	r5, r2, #0
0x00413e:	movs    	r2, #0
0x004140:	str     	r2, [sp, #8]
0x004142:	str     	r1, [sp]
0x004144:	str     	r1, [sp, #4]
0x004146:	movs    	r6, #0xf1
0x004148:	lsls    	r6, r6, #9
0x00414a:	movs    	r1, #0xe1
0x00414c:	movs    	r2, #0xca
0x00414e:	movs    	r3, #0
0x004150:	adds    	r0, r6, #0
0x004152:	bl      	#0x4408
0x004156:	movs    	r7, #1
0x004158:	cmp     	r0, #0
0x00415a:	bne     	#0x4172
0x00415c:	movs    	r1, #0
0x00415e:	movs    	r2, #0
0x004160:	str     	r2, [sp, #8]
0x004162:	str     	r1, [sp]
0x004164:	str     	r1, [sp, #4]
0x004166:	movs    	r1, #0x14
0x004168:	movs    	r2, #0xca
0x00416a:	adds    	r3, r7, #0
0x00416c:	adds    	r0, r6, #0
0x00416e:	bl      	#0x4408
0x004172:	ldr     	r0, [sp, #0xc]
0x004174:	cmp     	r0, #0x19
0x004176:	bhs     	#0x4182
0x004178:	adr     	r3, #8
0x00417a:	adds    	r3, r3, r0
0x00417c:	ldrh    	r3, [r3, r0]
0x00417e:	lsls    	r3, r3, #1
0x004180:	add     	pc, r3
0x004182:	b       	#0x431c
0x004184:	lsls    	r6, r6, #2
0x004186:	lsls    	r1, r0, #3
0x004188:	lsls    	r4, r4, #2
0x00418a:	lsls    	r6, r1, #2
0x00418c:	lsls    	r1, r1, #2
0x00418e:	lsls    	r2, r0, #2
0x004190:	lsls    	r5, r7, #1
0x004192:	lsls    	r4, r4, #1
0x004194:	lsls    	r7, r3, #1
0x004196:	lsls    	r3, r3, #1
0x004198:	lsls    	r7, r2, #1
0x00419a:	lsls    	r3, r2, #1
0x00419c:	lsls    	r6, r1, #1
0x00419e:	lsls    	r1, r1, #1
0x0041a0:	lsls    	r5, r0, #1
0x0041a2:	lsls    	r0, r0, #1
0x0041a4:	movs    	r3, r7
0x0041a6:	movs    	r7, r6
0x0041a8:	movs    	r2, r6
0x0041aa:	movs    	r6, r5
0x0041ac:	movs    	r2, r5
0x0041ae:	movs    	r6, r4
0x0041b0:	movs    	r2, r4
0x0041b2:	movs    	r6, r3
0x0041b4:	movs    	r1, r3
0x0041b6:	bl      	#0x32e0
0x0041ba:	movs    	r0, #0
0x0041bc:	add     	sp, #0x1c
0x0041be:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_004330 =====
0x004330:	push    	{r3, r4, r5, lr}
0x004332:	ldr     	r4, [pc, #0x74]
0x004334:	add     	r4, pc
0x004336:	ldr     	r0, [r4, #0x38]
0x004338:	movs    	r1, #0x14
0x00433a:	ldr     	r2, [r0, #0x64]
0x00433c:	ldr     	r0, [pc, #0x6c]
0x00433e:	add     	r0, pc
0x004340:	blx     	r2
0x004342:	movs    	r5, #0
0x004344:	mvns    	r5, r5
0x004346:	cmp     	r0, r5
0x004348:	bne     	#0x434e
0x00434a:	adds    	r0, r5, #0
0x00434c:	pop     	{r3, r4, r5, pc}

; ===== candidate_0043b8 =====
0x0043b8:	push    	{r4, lr}
0x0043ba:	sub     	sp, #0x10
0x0043bc:	lsls    	r0, r0, #0x18
0x0043be:	lsrs    	r0, r0, #0x18
0x0043c0:	str     	r0, [sp]
0x0043c2:	ldr     	r0, [pc, #0x38]
0x0043c4:	lsls    	r2, r2, #0x18
0x0043c6:	lsls    	r1, r1, #0x18
0x0043c8:	lsrs    	r1, r1, #0x18
0x0043ca:	lsrs    	r2, r2, #0x18
0x0043cc:	str     	r2, [sp, #8]
0x0043ce:	str     	r1, [sp, #4]
0x0043d0:	add     	r0, pc
0x0043d2:	ldr     	r0, [r0, #0x38]
0x0043d4:	adds    	r1, r0, #0
0x0043d6:	adds    	r1, #0xff
0x0043d8:	adds    	r1, #0x41
0x0043da:	ldr     	r2, [r1, #0x34]
0x0043dc:	ldr     	r1, [r1, #0x30]
0x0043de:	ldr     	r2, [r2]
0x0043e0:	ldr     	r1, [r1]
0x0043e2:	lsls    	r3, r2, #0x10
0x0043e4:	lsls    	r2, r1, #0x10
0x0043e6:	asrs    	r2, r2, #0x10
0x0043e8:	asrs    	r3, r3, #0x10
0x0043ea:	adds    	r0, #0xff
0x0043ec:	adds    	r0, #0xc1
0x0043ee:	ldr     	r4, [r0, #0x28]
0x0043f0:	movs    	r1, #0
0x0043f2:	movs    	r0, #0
0x0043f4:	blx     	r4
0x0043f6:	add     	sp, #0x10
0x0043f8:	pop     	{r4, pc}

; ===== candidate_004408 =====
0x004408:	push    	{r4, r5, r6, r7, lr}
0x00440a:	adds    	r5, r1, #0
0x00440c:	adds    	r4, r0, #0
0x00440e:	adds    	r6, r2, #0
0x004410:	ldr     	r2, [pc, #0x28]
0x004412:	sub     	sp, #0x14
0x004414:	mov     	ip, r3
0x004416:	add     	r2, pc
0x004418:	ldr     	r0, [sp, #0x2c]
0x00441a:	ldr     	r1, [sp, #0x30]
0x00441c:	ldr     	r7, [sp, #0x28]
0x00441e:	ldr     	r3, [r2, #0x3c]
0x004420:	movs    	r2, #2
0x004422:	str     	r2, [sp, #0xc]
0x004424:	str     	r1, [sp, #8]
0x004426:	str     	r0, [sp, #4]
0x004428:	str     	r7, [sp]
0x00442a:	ldr     	r0, [r3, #0xc]
0x00442c:	adds    	r1, r5, #0
0x00442e:	adds    	r2, r6, #0
0x004430:	ldr     	r7, [r0, #0x28]
0x004432:	adds    	r0, r4, #0
0x004434:	mov     	r3, ip
0x004436:	blx     	r7
0x004438:	add     	sp, #0x14
0x00443a:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_004444 =====
0x004444:	push    	{r4, lr}
0x004446:	movs    	r2, #0
0x004448:	add     	r0, pc
0x00444a:	ldr     	r4, [r0, #0x3c]
0x00444c:	sub     	sp, #0x10
0x00444e:	movs    	r1, #0
0x004450:	str     	r1, [sp, #4]
0x004452:	str     	r1, [sp, #8]
0x004454:	str     	r2, [sp, #0xc]
0x004456:	str     	r2, [sp]
0x004458:	ldr     	r0, [r4, #0xc]
0x00445a:	ldr     	r2, [r0, #0x24]
0x00445c:	ldr     	r4, [r0, #0x28]
0x00445e:	blx     	r4
0x004460:	add     	sp, #0x10
0x004462:	pop     	{r4, pc}

; ===== candidate_004468 =====
0x004468:	push    	{r4, lr}
0x00446a:	ldr     	r0, [pc, #0x24]
0x00446c:	sub     	sp, #0x10
0x00446e:	add     	r0, pc
0x004470:	ldr     	r3, [r0, #0x3c]
0x004472:	movs    	r2, #0
0x004474:	movs    	r1, #0
0x004476:	str     	r1, [sp, #4]
0x004478:	str     	r1, [sp, #8]
0x00447a:	str     	r2, [sp, #0xc]
0x00447c:	str     	r2, [sp]
0x00447e:	ldr     	r0, [r3, #0xc]
0x004480:	movs    	r3, #0
0x004482:	ldr     	r2, [r0, #0x24]
0x004484:	ldr     	r4, [r0, #0x28]
0x004486:	movs    	r1, #1
0x004488:	blx     	r4
0x00448a:	add     	sp, #0x10
0x00448c:	pop     	{r4, pc}

; ===== candidate_0044a8 =====
0x0044a8:	push    	{r4, lr}
0x0044aa:	sub     	sp, #0x10
0x0044ac:	movs    	r2, #0
0x0044ae:	movs    	r1, #0
0x0044b0:	str     	r2, [sp, #8]
0x0044b2:	ldr     	r2, [pc, #0x3c]
0x0044b4:	str     	r1, [sp]
0x0044b6:	str     	r1, [sp, #4]
0x0044b8:	movs    	r3, #0
0x0044ba:	add     	r2, pc
0x0044bc:	ldr     	r1, [pc, #0x34]
0x0044be:	ldr     	r0, [pc, #0x38]
0x0044c0:	bl      	#0x4408
0x0044c4:	ldr     	r3, [pc, #0x38]
0x0044c6:	ldr     	r4, [pc, #0x34]
0x0044c8:	add     	r3, sb
0x0044ca:	ldr     	r3, [r3]
0x0044cc:	movs    	r2, #0x41
0x0044ce:	movs    	r1, #0
0x0044d0:	add     	r4, sb
0x0044d2:	adds    	r0, r4, #0
0x0044d4:	blx     	r3
0x0044d6:	bl      	#0x4494
0x0044da:	ldr     	r3, [pc, #0x28]
0x0044dc:	adds    	r1, r0, #0
0x0044de:	add     	r3, sb
0x0044e0:	ldr     	r3, [r3]
0x0044e2:	movs    	r2, #0x41
0x0044e4:	adds    	r0, r4, #0
0x0044e6:	blx     	r3
0x0044e8:	movs    	r0, #0
0x0044ea:	add     	sp, #0x10
0x0044ec:	pop     	{r4, pc}

; ===== candidate_00450c =====
0x00450c:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x00450e:	adds    	r7, r3, #0
0x004510:	adds    	r6, r2, #0
0x004512:	adds    	r5, r0, #0
0x004514:	ldr     	r0, [r0]
0x004516:	sub     	sp, #4
0x004518:	mov     	r1, sb
0x00451a:	str     	r1, [sp]
0x00451c:	movs    	r4, #0
0x00451e:	blx     	#0x2e0
0x004522:	ldr     	r0, [sp, #8]
0x004524:	cmp     	r0, #0xb
0x004526:	bhs     	#0x4594
0x004528:	adr     	r3, #4
0x00452a:	ldrb    	r3, [r3, r0]
0x00452c:	lsls    	r3, r3, #1
0x00452e:	add     	pc, r3
0x004530:	lsrs    	r5, r0, #0x1c
0x004532:	subs    	r4, r3, #4
0x004534:	movs    	r4, #0x21
0x004536:	adds    	r1, #0x27
0x004538:	adds    	r1, #0x2b
0x00453a:	movs    	r7, r5
0x00453c:	ldr     	r1, [pc, #0x60]
0x00453e:	ldr     	r0, [r5, #0xc]
0x004540:	add     	r1, sb
0x004542:	str     	r0, [r1, #0x14]
0x004544:	bl      	#0x308
0x004548:	bl      	#0x44a8
0x00454c:	adds    	r4, r0, #0
0x00454e:	b       	#0x4594
0x004550:	ldr     	r0, [r6]
0x004552:	cmp     	r0, #8
0x004554:	bne     	#0x455e
0x004556:	bl      	#0x4404
0x00455a:	adds    	r4, r0, #0
0x00455c:	b       	#0x4594
0x00455e:	ldr     	r1, [r6, #4]
0x004560:	ldr     	r2, [r6, #8]
0x004562:	bl      	#0x4400
0x004566:	adds    	r4, r0, #0
0x004568:	b       	#0x4594
0x00456a:	bl      	#0x479c
0x00456e:	b       	#0x4594
0x004570:	str     	r7, [r5, #0xc]
0x004572:	b       	#0x4594
0x004574:	bl      	#0x4508
0x004578:	b       	#0x4594
0x00457a:	bl      	#0x45d8
0x00457e:	b       	#0x4594
0x004580:	ldr     	r0, [pc, #0x1c]
0x004582:	add     	r0, sb
0x004584:	str     	r7, [r0, #0x1c]
0x004586:	b       	#0x4594
0x004588:	ldr     	r0, [pc, #0x14]
0x00458a:	add     	r0, sb
0x00458c:	str     	r6, [r0, #0x20]
0x00458e:	b       	#0x4594
0x004590:	ldr     	r4, [pc, #0x10]
0x004592:	add     	r4, pc
0x004594:	ldr     	r1, [sp]
0x004596:	add     	sp, #0x14
0x004598:	adds    	r0, r4, #0
0x00459a:	mov     	sb, r1
0x00459c:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_0045a8 =====
0x0045a8:	push    	{r0, r1, r2, r3, r4, r5, r6, r7, lr}
0x0045aa:	sub     	sp, #0xc
0x0045ac:	ldr     	r0, [sp, #0x38]
0x0045ae:	ldr     	r4, [sp, #0x3c]
0x0045b0:	ldr     	r6, [sp, #0x34]
0x0045b2:	ldr     	r0, [r0]
0x0045b4:	mov     	r7, sb
0x0045b6:	movs    	r5, #0
0x0045b8:	blx     	#0x2e0
0x0045bc:	cmp     	r4, #0
0x0045be:	beq     	#0x45ce
0x0045c0:	ldr     	r1, [sp, #0x30]
0x0045c2:	str     	r6, [sp, #4]
0x0045c4:	add     	r3, sp, #0xc
0x0045c6:	str     	r1, [sp]
0x0045c8:	ldm     	r3, {r0, r1, r2, r3}
0x0045ca:	blx     	r4
0x0045cc:	adds    	r5, r0, #0
0x0045ce:	mov     	sb, r7
0x0045d0:	adds    	r0, r5, #0
0x0045d2:	add     	sp, #0x1c
0x0045d4:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_00463c =====
0x00463c:	push    	{r3, r4, r5, r6, r7, lr}
0x00463e:	adds    	r4, r0, #0
0x004640:	ldr     	r0, [pc, #0x10c]
0x004642:	movs    	r5, #0
0x004644:	mvns    	r5, r5
0x004646:	mov     	ip, r2
0x004648:	add     	r0, pc
0x00464a:	ldr     	r2, [r0, #0x38]
0x00464c:	cmp     	r4, #0
0x00464e:	bne     	#0x4660
0x004650:	ldr     	r0, [pc, #0x100]
0x004652:	ldr     	r2, [r2, #0x68]
0x004654:	movs    	r1, #0x7d
0x004656:	lsls    	r1, r1, #3
0x004658:	add     	r0, pc
0x00465a:	blx     	r2
0x00465c:	adds    	r0, r5, #0
0x00465e:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_004768 =====
0x004768:	push    	{r3, r4, r5, lr}
0x00476a:	ldr     	r4, [pc, #0x28]
0x00476c:	adds    	r5, r0, #0
0x00476e:	add     	r4, pc
0x004770:	ldr     	r0, [r4, #0x38]
0x004772:	adds    	r0, #0x80
0x004774:	ldr     	r0, [r0, #4]
0x004776:	blx     	r0
0x004778:	adds    	r0, r0, r5
0x00477a:	ldr     	r1, [pc, #0x1c]
0x00477c:	add     	r1, sb
0x00477e:	str     	r0, [r1, #0x10]
0x004780:	ldr     	r0, [r4, #0x38]
0x004782:	adds    	r0, #0x80
0x004784:	ldr     	r0, [r0]
0x004786:	blx     	r0
0x004788:	ldr     	r0, [r4, #0x38]
0x00478a:	ldr     	r1, [r0, #0x7c]
0x00478c:	lsls    	r0, r5, #0x10
0x00478e:	lsrs    	r0, r0, #0x10
0x004790:	blx     	r1
0x004792:	pop     	{r3, r4, r5, pc}

; ===== candidate_00479e =====
0x00479e:	push    	{r3, r4, r5, r6, r7, lr}
0x0047a0:	add     	r0, pc
0x0047a2:	ldr     	r0, [r0, #0x38]
0x0047a4:	adds    	r0, #0x80
0x0047a6:	ldr     	r0, [r0, #4]
0x0047a8:	blx     	r0
0x0047aa:	movs    	r5, #0
0x0047ac:	ldr     	r6, [pc, #0xc8]
0x0047ae:	add     	r6, sb
0x0047b0:	ldr     	r1, [r6, #0x10]
0x0047b2:	str     	r5, [r6, #0x10]
0x0047b4:	subs    	r1, r0, r1
0x0047b6:	ldr     	r0, [r6, #8]
0x0047b8:	adds    	r3, r1, #0
0x0047ba:	cmp     	r0, #0
0x0047bc:	beq     	#0x4872
0x0047be:	ldr     	r2, [r0, #8]
0x0047c0:	cmp     	r2, #0
0x0047c2:	bne     	#0x4822
0x0047c4:	mvns    	r7, r2
0x0047c6:	str     	r7, [r0, #8]
0x0047c8:	ldr     	r2, [r0, #0x18]
0x0047ca:	adds    	r4, r0, #0
0x0047cc:	cmp     	r1, #0x32
0x0047ce:	str     	r2, [r6, #8]
0x0047d0:	bge     	#0x47d6
0x0047d2:	movs    	r1, #0x32
0x0047d4:	b       	#0x47f2
0x0047d6:	movs    	r2, #0x7d
0x0047d8:	lsls    	r2, r2, #4
0x0047da:	cmp     	r1, r2
0x0047dc:	ble     	#0x47f2
0x0047de:	adds    	r1, r2, #0
0x0047e0:	b       	#0x47f2
0x0047e2:	movs    	r7, #0
0x0047e4:	mvns    	r7, r7
0x0047e6:	str     	r7, [r2, #8]
0x0047e8:	ldr     	r2, [r0, #0x18]
0x0047ea:	str     	r2, [r0, #0x1c]
0x0047ec:	ldr     	r0, [r2, #0x18]
0x0047ee:	str     	r0, [r6, #8]
0x0047f0:	adds    	r0, r2, #0
0x0047f2:	ldr     	r2, [r0, #0x18]
0x0047f4:	cmp     	r2, #0
0x0047f6:	beq     	#0x47fe
0x0047f8:	ldr     	r7, [r2, #8]
0x0047fa:	cmp     	r7, r1
0x0047fc:	blt     	#0x47e2
0x0047fe:	str     	r5, [r0, #0x1c]
0x004800:	ldr     	r0, [r6, #8]
0x004802:	cmp     	r0, #0
0x004804:	beq     	#0x4866
0x004806:	cmp     	r3, #0
0x004808:	bge     	#0x480c
0x00480a:	movs    	r3, #0
0x00480c:	ldr     	r0, [r6, #8]
0x00480e:	ldr     	r1, [r0, #8]
0x004810:	cmp     	r1, #0
0x004812:	bge     	#0x4818
0x004814:	movs    	r1, #0
0x004816:	str     	r5, [r0, #8]
0x004818:	ldr     	r2, [pc, #0x60]
0x00481a:	cmp     	r1, r2
0x00481c:	ble     	#0x4826
0x00481e:	adds    	r1, r2, #0
0x004820:	b       	#0x4826
0x004822:	movs    	r4, #0
0x004824:	b       	#0x4806
0x004826:	ldr     	r2, [r0, #8]
0x004828:	subs    	r2, r2, r1
0x00482a:	str     	r2, [r0, #8]
0x00482c:	ldr     	r0, [r0, #0x18]
0x00482e:	cmp     	r0, #0
0x004830:	bne     	#0x4826
0x004832:	subs    	r0, r1, r3
0x004834:	cmp     	r0, #0
0x004836:	bgt     	#0x483a
0x004838:	movs    	r0, #0xa
0x00483a:	bl      	#0x4768
0x00483e:	b       	#0x4866
0x004840:	str     	r5, [r4, #8]
0x004842:	ldr     	r0, [r4, #0x1c]
0x004844:	adds    	r3, r5, #0
0x004846:	str     	r0, [r6, #0xc]
0x004848:	ldr     	r0, [r4, #0x14]
0x00484a:	cmp     	r0, #0
0x00484c:	beq     	#0x485a
0x00484e:	str     	r0, [sp]
0x004850:	movs    	r1, #0
0x004852:	adds    	r0, r4, #0
0x004854:	ldr     	r2, [r4, #0x10]
0x004856:	bl      	#0x463c
0x00485a:	ldr     	r1, [r4, #0xc]
0x00485c:	cmp     	r1, #0
0x00485e:	beq     	#0x4864
0x004860:	ldr     	r0, [r4, #0x10]
0x004862:	blx     	r1
0x004864:	ldr     	r4, [r6, #0xc]
0x004866:	cmp     	r4, #0
0x004868:	beq     	#0x4870
0x00486a:	ldr     	r0, [r4, #8]
0x00486c:	cmp     	r0, #0
0x00486e:	blt     	#0x4840
0x004870:	str     	r5, [r6, #0xc]
0x004872:	pop     	{r3, r4, r5, r6, r7, pc}

; ===== candidate_004880 =====
0x004880:	push    	{r4, r5, r6, lr}
0x004882:	ldr     	r5, [pc, #0x2c]
0x004884:	sub     	sp, #0x10
0x004886:	add     	r5, sb
0x004888:	ldr     	r6, [r5, #0x28]
0x00488a:	cmp     	r6, #0
0x00488c:	beq     	#0x48aa
0x00488e:	movs    	r1, #0
0x004890:	movs    	r2, #0
0x004892:	movs    	r4, #0
0x004894:	adds    	r3, r4, #0
0x004896:	str     	r2, [sp, #8]
0x004898:	str     	r1, [sp]
0x00489a:	str     	r1, [sp, #4]
0x00489c:	movs    	r1, #0x12
0x00489e:	adds    	r2, r6, #0
0x0048a0:	movs    	r0, #0xf1
0x0048a2:	lsls    	r0, r0, #9
0x0048a4:	bl      	#0x4408
0x0048a8:	str     	r4, [r5, #0x28]
0x0048aa:	add     	sp, #0x10
0x0048ac:	pop     	{r4, r5, r6, pc}

; ===== candidate_0048b6 =====
0x0048b6:	push    	{r4, r5, r6, r7, lr}
0x0048b8:	add     	r0, sb
0x0048ba:	ldr     	r4, [r0, #0x34]
0x0048bc:	movs    	r6, #0
0x0048be:	cmp     	r4, #0
0x0048c0:	sub     	sp, #0xc
0x0048c2:	beq     	#0x4926
0x0048c4:	movs    	r1, #0
0x0048c6:	movs    	r2, #0
0x0048c8:	str     	r2, [sp, #8]
0x0048ca:	str     	r1, [sp]
0x0048cc:	str     	r1, [sp, #4]
0x0048ce:	movs    	r7, #0xf1
0x0048d0:	lsls    	r7, r7, #9
0x0048d2:	movs    	r1, #0x11
0x0048d4:	adds    	r2, r4, #0
0x0048d6:	movs    	r3, #4
0x0048d8:	adds    	r0, r7, #0
0x0048da:	bl      	#0x4408
0x0048de:	adds    	r5, r0, #0
0x0048e0:	movs    	r4, #0
0x0048e2:	cmp     	r0, #0
0x0048e4:	ble     	#0x490c
0x0048e6:	movs    	r1, #0
0x0048e8:	str     	r1, [sp]
0x0048ea:	str     	r1, [sp, #4]
0x0048ec:	ldr     	r1, [pc, #0x40]
0x0048ee:	movs    	r2, #0
0x0048f0:	str     	r2, [sp, #8]
0x0048f2:	add     	r1, sb
0x0048f4:	ldr     	r1, [r1, #0x34]
0x0048f6:	lsls    	r0, r4, #2
0x0048f8:	ldr     	r2, [r1, r0]
0x0048fa:	movs    	r1, #0xff
0x0048fc:	adds    	r1, #0xc
0x0048fe:	adds    	r3, r6, #0
0x004900:	adds    	r0, r7, #0
0x004902:	bl      	#0x4408
0x004906:	adds    	r4, #1
0x004908:	cmp     	r4, r5
0x00490a:	blt     	#0x48e6
0x00490c:	movs    	r1, #0
0x00490e:	ldr     	r0, [pc, #0x20]
0x004910:	str     	r1, [sp]
0x004912:	str     	r1, [sp, #4]
0x004914:	movs    	r2, #0
0x004916:	str     	r2, [sp, #8]
0x004918:	add     	r0, sb
0x00491a:	ldr     	r2, [r0, #0x34]
0x00491c:	movs    	r1, #9
0x00491e:	adds    	r3, r6, #0
0x004920:	adds    	r0, r7, #0
0x004922:	bl      	#0x4408
0x004926:	ldr     	r0, [pc, #8]
0x004928:	add     	r0, sb
0x00492a:	str     	r6, [r0, #0x34]
0x00492c:	add     	sp, #0xc
0x00492e:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_004934 =====
0x004934:	push    	{r4, r5, r6, r7, lr}
0x004936:	sub     	sp, #0xc
0x004938:	movs    	r1, #0
0x00493a:	movs    	r4, #0
0x00493c:	movs    	r2, #0
0x00493e:	str     	r2, [sp, #8]
0x004940:	adds    	r3, r4, #0
0x004942:	str     	r1, [sp]
0x004944:	str     	r1, [sp, #4]
0x004946:	movs    	r5, #0xcd
0x004948:	adds    	r2, r5, #0
0x00494a:	movs    	r1, #0x17
0x00494c:	movs    	r0, #0xf1
0x00494e:	lsls    	r0, r0, #9
0x004950:	bl      	#0x4408
0x004954:	movs    	r1, #0
0x004956:	movs    	r2, #0
0x004958:	str     	r2, [sp, #8]
0x00495a:	str     	r1, [sp]
0x00495c:	str     	r1, [sp, #4]
0x00495e:	movs    	r1, #0xe1
0x004960:	movs    	r2, #0x1d
0x004962:	adds    	r3, r4, #0
0x004964:	movs    	r0, #0xf1
0x004966:	lsls    	r0, r0, #9
0x004968:	bl      	#0x4408
0x00496c:	movs    	r1, #0
0x00496e:	adds    	r6, r0, #0
0x004970:	movs    	r2, #0
0x004972:	str     	r2, [sp, #8]
0x004974:	str     	r1, [sp]
0x004976:	str     	r1, [sp, #4]
0x004978:	movs    	r1, #0xe1
0x00497a:	movs    	r2, #0x18
0x00497c:	movs    	r0, #0xf1
0x00497e:	adds    	r3, r4, #0
0x004980:	lsls    	r0, r0, #9
0x004982:	bl      	#0x4408
0x004986:	ldr     	r7, [r0, #0xc]
0x004988:	movs    	r1, #0
0x00498a:	movs    	r2, #0
0x00498c:	str     	r2, [sp, #8]
0x00498e:	str     	r1, [sp]
0x004990:	str     	r1, [sp, #4]
0x004992:	movs    	r1, #0xe1
0x004994:	movs    	r2, #0x18
0x004996:	movs    	r0, #0xf1
0x004998:	adds    	r3, r4, #0
0x00499a:	lsls    	r0, r0, #9
0x00499c:	bl      	#0x4408
0x0049a0:	ldr     	r3, [r0, #8]
0x0049a2:	movs    	r2, #0
0x0049a4:	str     	r2, [sp, #8]
0x0049a6:	adds    	r2, r5, #0
0x0049a8:	movs    	r0, #0xf1
0x0049aa:	movs    	r1, #0x52
0x0049ac:	lsls    	r0, r0, #9
0x0049ae:	str     	r7, [sp]
0x0049b0:	str     	r6, [sp, #4]
0x0049b2:	bl      	#0x4408
0x0049b6:	movs    	r1, #0
0x0049b8:	movs    	r2, #0
0x0049ba:	str     	r2, [sp, #8]
0x0049bc:	str     	r1, [sp]
0x0049be:	str     	r1, [sp, #4]
0x0049c0:	movs    	r1, #0xe1
0x0049c2:	movs    	r2, #0xfb
0x0049c4:	adds    	r3, r4, #0
0x0049c6:	movs    	r0, #0xf1
0x0049c8:	lsls    	r0, r0, #9
0x0049ca:	bl      	#0x4408
0x0049ce:	movs    	r2, #0
0x0049d0:	movs    	r1, #0
0x0049d2:	str     	r2, [sp, #8]
0x0049d4:	adds    	r3, r4, #0
0x0049d6:	adds    	r2, r0, #0
0x0049d8:	str     	r1, [sp]
0x0049da:	str     	r1, [sp, #4]
0x0049dc:	movs    	r1, #0x19
0x0049de:	movs    	r0, #0xf1
0x0049e0:	lsls    	r0, r0, #9
0x0049e2:	bl      	#0x4408
0x0049e6:	movs    	r1, #0
0x0049e8:	movs    	r2, #0
0x0049ea:	str     	r2, [sp, #8]
0x0049ec:	str     	r1, [sp]
0x0049ee:	str     	r1, [sp, #4]
0x0049f0:	movs    	r1, #0xe1
0x0049f2:	movs    	r2, #0xfa
0x0049f4:	adds    	r3, r4, #0
0x0049f6:	movs    	r0, #0xf1
0x0049f8:	lsls    	r0, r0, #9
0x0049fa:	bl      	#0x4408
0x0049fe:	movs    	r2, #0
0x004a00:	movs    	r1, #0
0x004a02:	str     	r2, [sp, #8]
0x004a04:	adds    	r3, r4, #0
0x004a06:	adds    	r2, r0, #0
0x004a08:	str     	r1, [sp]
0x004a0a:	str     	r1, [sp, #4]
0x004a0c:	movs    	r1, #0x19
0x004a0e:	movs    	r0, #0xf1
0x004a10:	lsls    	r0, r0, #9
0x004a12:	bl      	#0x4408
0x004a16:	movs    	r1, #0
0x004a18:	str     	r1, [sp]
0x004a1a:	str     	r1, [sp, #4]
0x004a1c:	movs    	r2, #0
0x004a1e:	ldr     	r5, [pc, #0x48]
0x004a20:	str     	r2, [sp, #8]
0x004a22:	movs    	r1, #0x19
0x004a24:	adds    	r3, r4, #0
0x004a26:	movs    	r0, #0xf1
0x004a28:	add     	r5, sb
0x004a2a:	ldr     	r2, [r5, #8]
0x004a2c:	lsls    	r0, r0, #9
0x004a2e:	bl      	#0x4408
0x004a32:	movs    	r1, #0
0x004a34:	str     	r1, [sp]
0x004a36:	str     	r1, [sp, #4]
0x004a38:	movs    	r2, #0
0x004a3a:	str     	r2, [sp, #8]
0x004a3c:	movs    	r1, #0x19
0x004a3e:	adds    	r3, r4, #0
0x004a40:	movs    	r0, #0xf1
0x004a42:	lsls    	r0, r0, #9
0x004a44:	ldr     	r2, [r5, #0xc]
0x004a46:	bl      	#0x4408
0x004a4a:	movs    	r2, #0
0x004a4c:	movs    	r1, #0
0x004a4e:	ldr     	r3, [pc, #0x1c]
0x004a50:	str     	r1, [sp]
0x004a52:	str     	r1, [sp, #4]
0x004a54:	str     	r2, [sp, #8]
0x004a56:	add     	r3, pc
0x004a58:	movs    	r2, #1
0x004a5a:	movs    	r1, #0x1b
0x004a5c:	movs    	r0, #0xf1
0x004a5e:	lsls    	r0, r0, #9
0x004a60:	bl      	#0x4408
0x004a64:	add     	sp, #0xc

; ===== candidate_004a70 =====
0x004a70:	push    	{r0, r1, r4, r5, r6, r7, lr}
0x004a72:	sub     	sp, #0xc
0x004a74:	movs    	r1, #0
0x004a76:	movs    	r4, #0
0x004a78:	movs    	r2, #0
0x004a7a:	str     	r2, [sp, #8]
0x004a7c:	adds    	r3, r4, #0
0x004a7e:	str     	r1, [sp]
0x004a80:	str     	r1, [sp, #4]
0x004a82:	movs    	r5, #0x79
0x004a84:	adds    	r2, r5, #0
0x004a86:	movs    	r1, #0x17
0x004a88:	movs    	r0, #0xf1
0x004a8a:	lsls    	r0, r0, #9
0x004a8c:	bl      	#0x4408
0x004a90:	movs    	r1, #0
0x004a92:	movs    	r2, #0
0x004a94:	str     	r2, [sp, #8]
0x004a96:	str     	r1, [sp]
0x004a98:	str     	r1, [sp, #4]
0x004a9a:	movs    	r1, #0xe1
0x004a9c:	movs    	r2, #0x1d
0x004a9e:	adds    	r3, r4, #0
0x004aa0:	movs    	r0, #0xf1
0x004aa2:	lsls    	r0, r0, #9
0x004aa4:	bl      	#0x4408
0x004aa8:	movs    	r1, #0
0x004aaa:	adds    	r6, r0, #0
0x004aac:	movs    	r2, #0
0x004aae:	str     	r2, [sp, #8]
0x004ab0:	str     	r1, [sp]
0x004ab2:	str     	r1, [sp, #4]
0x004ab4:	movs    	r1, #0xe1
0x004ab6:	movs    	r2, #0x18
0x004ab8:	movs    	r0, #0xf1
0x004aba:	adds    	r3, r4, #0
0x004abc:	lsls    	r0, r0, #9
0x004abe:	bl      	#0x4408
0x004ac2:	ldr     	r7, [r0, #0xc]
0x004ac4:	movs    	r1, #0
0x004ac6:	movs    	r2, #0
0x004ac8:	str     	r2, [sp, #8]
0x004aca:	str     	r1, [sp]
0x004acc:	str     	r1, [sp, #4]
0x004ace:	movs    	r1, #0xe1
0x004ad0:	movs    	r2, #0x18
0x004ad2:	movs    	r0, #0xf1
0x004ad4:	adds    	r3, r4, #0
0x004ad6:	lsls    	r0, r0, #9
0x004ad8:	bl      	#0x4408
0x004adc:	ldr     	r3, [r0, #8]
0x004ade:	movs    	r2, #0
0x004ae0:	str     	r2, [sp, #8]
0x004ae2:	adds    	r2, r5, #0
0x004ae4:	movs    	r0, #0xf1
0x004ae6:	movs    	r1, #0x52
0x004ae8:	lsls    	r0, r0, #9
0x004aea:	str     	r7, [sp]
0x004aec:	str     	r6, [sp, #4]
0x004aee:	bl      	#0x4408
0x004af2:	movs    	r1, #0
0x004af4:	movs    	r2, #0
0x004af6:	str     	r1, [sp]
0x004af8:	str     	r1, [sp, #4]
0x004afa:	movs    	r1, #0x1a
0x004afc:	str     	r2, [sp, #8]
0x004afe:	adds    	r3, r4, #0
0x004b00:	movs    	r0, #0xf1
0x004b02:	lsls    	r0, r0, #9
0x004b04:	ldr     	r2, [sp, #0xc]
0x004b06:	bl      	#0x4408
0x004b0a:	movs    	r1, #0
0x004b0c:	movs    	r2, #0
0x004b0e:	str     	r1, [sp]
0x004b10:	str     	r1, [sp, #4]
0x004b12:	movs    	r1, #0x1a
0x004b14:	str     	r2, [sp, #8]
0x004b16:	adds    	r3, r4, #0
0x004b18:	movs    	r0, #0xf1
0x004b1a:	lsls    	r0, r0, #9
0x004b1c:	ldr     	r2, [sp, #0x10]
0x004b1e:	bl      	#0x4408
0x004b22:	ldr     	r1, [pc, #0x24]
0x004b24:	movs    	r0, #1
0x004b26:	add     	r1, sb
0x004b28:	strb    	r0, [r1]
0x004b2a:	movs    	r1, #0
0x004b2c:	movs    	r2, #0
0x004b2e:	str     	r2, [sp, #8]
0x004b30:	str     	r1, [sp]
0x004b32:	str     	r1, [sp, #4]
0x004b34:	movs    	r1, #0x1b
0x004b36:	movs    	r2, #1
0x004b38:	movs    	r0, #0xf1
0x004b3a:	adds    	r3, r4, #0
0x004b3c:	lsls    	r0, r0, #9
0x004b3e:	bl      	#0x4408
0x004b42:	add     	sp, #0x14
0x004b44:	pop     	{r4, r5, r6, r7, pc}

; ===== candidate_004b4c =====
0x004b4c:	push    	{r0, r1, r2, r4, r5, r7, lr}
0x004b4e:	bhi     	#0x4ac8
0x004b50:	movs    	r0, r0
0x004b52:	movs    	r0, r0
0x004b54:	movs    	r0, r0
0x004b56:	movs    	r0, r0
0x004b58:	b       	#0x4cc8
0x004b5a:	ldm     	r3, {r3, r6, r7}
0x004b5c:	udf     	#0xc0
0x004b5e:	add     	r0, sp, #0x330
0x004b60:	movs    	r0, r0
0x004b62:	movs    	r0, r0
0x004b64:	adr     	r5, #0x2d4
0x004b66:	ldm     	r3, {r3, r6, r7}
0x004b68:	udf     	#0xc0
0x004b6a:	add     	r0, sp, #0x330
0x004b6c:	movs    	r0, r0
0x004b6e:	movs    	r0, r0
0x004b70:	udf     	#0xc0
0x004b72:	blx     	#0xfffdb8e0
0x004b76:	b       	#0x5114

; ===== candidate_004c52 =====
0x004c52:	push    	{r0, r1, r2, r3, r4, r5, r7}
0x004c54:	udf     	#0xc0

; ===== candidate_004d26 =====
0x004d26:	push    	{r0, r1, r2, r3, r4, r5, r7}
0x004d28:	ldm     	r5, {r0, r3, r4, r5, r7}

; ===== candidate_004d62 =====
0x004d62:	push    	{r3, r4, r5, r7}
0x004d64:	b       	#0x4b02
0x004d66:	bhs     	#0x4ce2
0x004d68:	rsb     	r3, r7, r7, lsl #31
0x004d6c:	movs    	r1, r4
0x004d6e:	movs    	r0, r0
0x004d70:	beq     	#0x4dcc
0x004d72:	bhs     	#0x4d46
0x004d74:	lsls    	r2, r5, #2
0x004d76:	movs    	r0, r0
0x004d78:	movs    	r4, r5
0x004d7a:	movs    	r0, r0
0x004d7c:	adr     	r1, #0x8c
0x004d7e:	pop     	{r1, r2, r3, r4, r5, r7, pc}

; ===== candidate_004db8 =====
0x004db8:	push    	{r3, r4, r5, r7}

; ===== candidate_004ede =====
0x004ede:	push    	{r1, r2, r4, r6, r7, lr}
0x004ee0:	movs    	r1, r4
0x004ee2:	movs    	r0, r0
0x004ee4:	pop     	{r1, r2, r4, r5, r7}
0x004ee6:	stm     	r7!, {r1, r3, r6, r7}
0x004ee8:	add     	r0, sp, #0x2d4
0x004eea:	adr     	r1, #0x340
0x004eec:	stm     	r4!, {r0, r2, r4, r5, r7}
0x004eee:	bhs     	#0x4e6a

; ===== candidate_004efc =====
0x004efc:	push    	{r6, r7}
0x004efe:	bkpt    	#0xa1
0x004f00:	movs    	r0, r0
0x004f02:	movs    	r0, r0
0x004f04:	adr     	r5, #0x2d4
0x004f06:	ldm     	r3, {r3, r6, r7}
0x004f08:	str.w   	r0, [r7, #0x2d]
0x004f0c:	ldrd    	sp, r3, [r7, #0x2d8]
0x004f10:	str.w   	r0, [r7, #0x2d]
0x004f14:	revsh   	r1, r2
