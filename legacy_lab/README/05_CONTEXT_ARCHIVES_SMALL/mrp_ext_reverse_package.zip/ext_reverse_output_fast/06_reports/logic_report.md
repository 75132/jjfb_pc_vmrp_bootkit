# EXT 运行逻辑恢复报告

## 1. 格式结论

这批文件大多是 GZIP 压缩的 MRP EXT；解压后固定以 `MRPGCMAP` 开头。`cfunction(1).ext` 本身未 gzip，但同样是 `MRPGCMAP`。

典型入口：

```asm
0x08  push {r4, lr}          ; ARM entry stub
0x0c  mov  r4, r0
0x10  mov  r0, r4
0x14  blx  #thumb_init       ; 跳入 Thumb 初始化/业务入口
0x18  pop  {r4, pc}
```

所以它不是“解包后直接读文本”的数据文件，而是 ARM/Thumb 混合裸二进制。

## 2. 模块逻辑分工

- `robotol`：主模块，负责游戏主循环、事件、地图、存档/全局状态和功能模块调度。
- `gameattackmodule_1`：战斗核心，优先看这里恢复伤害、命中、状态、回合流程。
- `monstermodule_1`：怪物实例和怪物属性读取。
- `monsterstatemodule_1`：怪物状态、BUFF/DEBUFF、状态生效/结束。
- `itemhechengmodule`：道具合成，重点看材料判断、扣除、生成物品、失败分支。
- `shopmodule` / `itembagshopmodule_1`：商品购买、出售、金币/背包容量判断。
- `betmodule_2`：下注/赌博/概率奖励逻辑。
- `lianmengmodule` / `leitaimodule_1`：联盟、擂台玩法。
- `mailmodule_1` / `chatmodule_1`：邮件和聊天逻辑。
- `cfunction_1`：大型公共 C 函数/桥接库，更多像运行库和宿主接口包装层。

## 3. 关键 API 调用模型

在已恢复的伪 C 和反汇编中，常见一种多参数分发调用：

```c
engine_call(0x1e200, opcode, arg1, arg2, arg3, arg4, arg5);
```

在 angr 伪 C 中它通常表现为 `sub_2abd(0x1e200, opcode, ...)` 或类似地址名。这个函数很可能是 MRP 宿主/游戏引擎 API 分发器。下一步要把 opcode 命名：

- 物品/怪物字段读取
- 物品/怪物字段写入
- UI 绘制/文字显示
- 背包/金币读写
- 存档变量读写
- 网络/邮件/聊天接口

## 4. 到源码的现实边界

这些 EXT 是 stripped 裸二进制，不包含作者原始变量名、结构体名、注释和源码路径。能恢复的是“等价伪 C + 精确汇编”，不能 100% 还原作者原始 C 文件。

本包已提供：

- 解压二进制；
- 函数/候选函数表；
- ARM/Thumb 反汇编；
- 字符串候选；
- 部分模块的 CFG 函数边界。

要继续推进，建议优先对 `gameattackmodule_1.functions.asm` 和 `gameattackmodule_1.functions.md` 中大函数逐个命名，再反推 opcode 表。
