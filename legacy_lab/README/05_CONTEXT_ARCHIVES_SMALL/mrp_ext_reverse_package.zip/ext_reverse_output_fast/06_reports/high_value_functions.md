# 高价值函数索引

优先从大函数/高复杂度函数开始命名。低位为 1 的地址是 Thumb 入口，实际偏移为 addr & ~1。


## betmodule_2

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x1a2d` | `0x1a2c` | `sub_1a2d` | 1986 | 74 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0xf95` | `0xf94` | `sub_f95` | 1700 | 65 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x4b9` | `0x4b8` | `sub_4b9` | 1030 | 50 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0xaed` | `0xaec` | `sub_aed` | 804 | 33 | 分支多，可能是状态机/菜单/结算 |
| `0x1685` | `0x1684` | `sub_1685` | 728 | 31 | 分支多，可能是状态机/菜单/结算 |
| `0x8f9` | `0x8f8` | `sub_8f9` | 470 | 28 | 分支多，可能是状态机/菜单/结算 |
| `0x2371` | `0x2370` | `sub_2371` | 534 | 22 | 分支多，可能是状态机/菜单/结算 |
| `0x2cf1` | `0x2cf0` | `sub_2cf1` | 276 | 24 | 分支多，可能是状态机/菜单/结算 |
| `0x2f35` | `0x2f34` | `sub_2f35` | 342 | 20 | 分支多，可能是状态机/菜单/结算 |
| `0x28bd` | `0x28bc` | `sub_28bd` | 290 | 21 | 分支多，可能是状态机/菜单/结算 |
| `0x3a1` | `0x3a0` | `sub_3a1` | 250 | 18 |  |
| `0x2655` | `0x2654` | `sub_2655` | 200 | 19 |  |
| `0x2e51` | `0x2e50` | `sub_2e51` | 216 | 18 |  |
| `0x2721` | `0x2720` | `sub_2721` | 212 | 17 |  |
| `0x195` | `0x194` | `sub_195` | 150 | 18 |  |
| `0x280d` | `0x280c` | `sub_280d` | 170 | 15 |  |
| `0x20` | `0x20` | `sub_20` | 284 | 7 |  |
| `0x30c5` | `0x30c4` | `sub_30c5` | 232 | 9 |  |
| `0xeb5` | `0xeb4` | `sub_eb5` | 220 | 9 |  |
| `0x2bc1` | `0x2bc0` | `sub_2bc1` | 134 | 12 |  |
| `0x2591` | `0x2590` | `sub_2591` | 188 | 8 |  |
| `0x2c91` | `0x2c90` | `sub_2c91` | 90 | 10 |  |
| `0x1975` | `0x1974` | `sub_1975` | 174 | 5 |  |
| `0xe19` | `0xe18` | `sub_e19` | 150 | 6 |  |
| `0x2e9` | `0x2e8` | `sub_2e9` | 182 | 3 |  |
| `0x2299` | `0x2298` | `sub_2299` | 116 | 4 |  |
| `0x2311` | `0x2310` | `sub_2311` | 92 | 4 |  |
| `0x31ad` | `0x31ac` | `sub_31ad` | 104 | 3 |  |
| `0x231` | `0x230` | `sub_231` | 130 | 1 |  |
| `0x2a1b` | `0x2a1a` | `sub_2a1b` | 64 | 4 |  |

## gameattackmodule_1

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x6781` | `0x6780` | `sub_6781` | 1888 | 91 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x4815` | `0x4814` | `sub_4815` | 1782 | 71 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x592d` | `0x592c` | `sub_592d` | 1594 | 80 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x1971` | `0x1970` | `sub_1971` | 1286 | 74 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x3aa5` | `0x3aa4` | `sub_3aa5` | 1376 | 46 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x6f2d` | `0x6f2c` | `sub_6f2d` | 1164 | 51 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x3129` | `0x3128` | `sub_3129` | 1118 | 51 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x8ba5` | `0x8ba4` | `sub_8ba5` | 1096 | 51 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x21f9` | `0x21f8` | `sub_21f9` | 1076 | 49 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x95c5` | `0x95c4` | `sub_95c5` | 750 | 45 | 分支多，可能是状态机/菜单/结算 |
| `0x3fd` | `0x3fc` | `sub_3fd` | 764 | 40 | 分支多，可能是状态机/菜单/结算 |
| `0x8d5` | `0x8d4` | `sub_8d5` | 670 | 39 | 分支多，可能是状态机/菜单/结算 |
| `0x4011` | `0x4010` | `sub_4011` | 688 | 31 | 分支多，可能是状态机/菜单/结算 |
| `0x9175` | `0x9174` | `sub_9175` | 590 | 34 | 分支多，可能是状态机/菜单/结算 |
| `0xa305` | `0xa304` | `sub_a305` | 496 | 34 | 分支多，可能是状态机/菜单/结算 |
| `0x2e89` | `0x2e88` | `sub_2e89` | 662 | 25 | 分支多，可能是状态机/菜单/结算 |
| `0x54dd` | `0x54dc` | `sub_54dd` | 650 | 25 | 分支多，可能是状态机/菜单/结算 |
| `0x3879` | `0x3878` | `sub_3879` | 550 | 28 | 分支多，可能是状态机/菜单/结算 |
| `0x2c0d` | `0x2c0c` | `sub_2c0d` | 628 | 20 | 分支多，可能是状态机/菜单/结算 |
| `0x52a1` | `0x52a0` | `sub_52a1` | 562 | 20 | 分支多，可能是状态机/菜单/结算 |
| `0x7b91` | `0x7b90` | `sub_7b91` | 474 | 24 | 分支多，可能是状态机/菜单/结算 |
| `0x2009` | `0x2008` | `sub_2009` | 470 | 23 | 分支多，可能是状态机/菜单/结算 |
| `0x35a1` | `0x35a0` | `sub_35a1` | 504 | 17 |  |
| `0x721` | `0x720` | `sub_721` | 402 | 22 | 分支多，可能是状态机/菜单/结算 |
| `0x14ad` | `0x14ac` | `sub_14ad` | 434 | 19 |  |
| `0x262d` | `0x262c` | `sub_262d` | 462 | 15 |  |
| `0x80c5` | `0x80c4` | `sub_80c5` | 276 | 24 | 分支多，可能是状态机/菜单/结算 |
| `0x4381` | `0x4380` | `sub_4381` | 252 | 24 | 分支多，可能是状态机/菜单/结算 |
| `0x50f9` | `0x50f8` | `sub_50f9` | 416 | 15 |  |
| `0x46cd` | `0x46cc` | `sub_46cd` | 316 | 19 |  |

## itembagshopmodule_1

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x725` | `0x724` | `sub_725` | 4642 | 230 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x6ad5` | `0x6ad4` | `sub_6ad5` | 2940 | 161 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x49d5` | `0x49d4` | `sub_49d5` | 2544 | 98 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x5d05` | `0x5d04` | `sub_5d05` | 1898 | 102 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x19e7` | `0x19e6` | `sub_19e7` | 1924 | 80 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x3cb1` | `0x3cb0` | `sub_3cb1` | 1576 | 68 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x43e9` | `0x43e8` | `sub_43e9` | 1468 | 59 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x368d` | `0x368c` | `sub_368d` | 1018 | 42 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x7661` | `0x7660` | `sub_7661` | 826 | 40 | 分支多，可能是状态机/菜单/结算 |
| `0x5a15` | `0x5a14` | `sub_5a15` | 710 | 34 | 分支多，可能是状态机/菜单/结算 |
| `0x83d9` | `0x83d8` | `sub_83d9` | 474 | 33 | 分支多，可能是状态机/菜单/结算 |
| `0x26fd` | `0x26fc` | `sub_26fd` | 588 | 26 | 分支多，可能是状态机/菜单/结算 |
| `0x7bf1` | `0x7bf0` | `sub_7bf1` | 486 | 29 | 分支多，可能是状态机/菜单/结算 |
| `0x67b5` | `0x67b4` | `sub_67b5` | 560 | 25 | 分支多，可能是状态机/菜单/结算 |
| `0x6585` | `0x6584` | `sub_6585` | 550 | 24 | 分支多，可能是状态机/菜单/结算 |
| `0x5449` | `0x5448` | `sub_5449` | 494 | 26 | 分支多，可能是状态机/菜单/结算 |
| `0x2e77` | `0x2e76` | `sub_2e77` | 496 | 23 | 分支多，可能是状态机/菜单/结算 |
| `0x3abd` | `0x3abc` | `sub_3abd` | 496 | 21 | 分支多，可能是状态机/菜单/结算 |
| `0x9323` | `0x9322` | `sub_9323` | 472 | 21 | 分支多，可能是状态机/菜单/结算 |
| `0x343d` | `0x343c` | `sub_343d` | 492 | 19 |  |
| `0x7fb9` | `0x7fb8` | `sub_7fb9` | 356 | 20 | 分支多，可能是状态机/菜单/结算 |
| `0x88c9` | `0x88c8` | `sub_88c9` | 276 | 24 | 分支多，可能是状态机/菜单/结算 |
| `0x8e0d` | `0x8e0c` | `sub_8e0d` | 396 | 17 |  |
| `0x8bb3` | `0x8bb2` | `sub_8bb3` | 390 | 17 |  |
| `0x4ad` | `0x4ac` | `sub_4ad` | 316 | 15 |  |
| `0x2201` | `0x2200` | `sub_2201` | 296 | 14 |  |
| `0x8a29` | `0x8a28` | `sub_8a29` | 216 | 18 |  |
| `0x29e1` | `0x29e0` | `sub_29e1` | 298 | 13 |  |
| `0x3361` | `0x3360` | `sub_3361` | 252 | 14 |  |
| `0x195` | `0x194` | `sub_195` | 150 | 18 |  |

## itemhechengmodule

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x28b1` | `0x28b0` | `sub_28b1` | 3380 | 137 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x1955` | `0x1954` | `sub_1955` | 1924 | 71 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x1281` | `0x1280` | `sub_1281` | 1704 | 58 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x4755` | `0x4754` | `sub_4755` | 984 | 56 | 分支多，可能是状态机/菜单/结算 |
| `0x20fd` | `0x20fc` | `sub_20fd` | 1008 | 39 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0xea1` | `0xea0` | `sub_ea1` | 986 | 39 | 分支多，可能是状态机/菜单/结算 |
| `0x24f5` | `0x24f4` | `sub_24f5` | 948 | 37 | 分支多，可能是状态机/菜单/结算 |
| `0x3eb9` | `0x3eb8` | `sub_3eb9` | 706 | 41 | 分支多，可能是状态机/菜单/结算 |
| `0xbb5` | `0xbb4` | `sub_bb5` | 738 | 29 | 分支多，可能是状态机/菜单/结算 |
| `0x41ad` | `0x41ac` | `sub_41ad` | 622 | 34 | 分支多，可能是状态机/菜单/结算 |
| `0x965` | `0x964` | `sub_965` | 586 | 27 | 分支多，可能是状态机/菜单/结算 |
| `0x36dd` | `0x36dc` | `sub_36dd` | 440 | 18 |  |
| `0x4e61` | `0x4e60` | `sub_4e61` | 276 | 24 | 分支多，可能是状态机/菜单/结算 |
| `0x20` | `0x20` | `sub_20` | 424 | 14 |  |
| `0x4fc1` | `0x4fc0` | `sub_4fc1` | 216 | 18 |  |
| `0x685` | `0x684` | `sub_685` | 302 | 12 |  |
| `0x195` | `0x194` | `sub_195` | 150 | 18 |  |
| `0x7b9` | `0x7b8` | `sub_7b9` | 266 | 12 |  |
| `0x3f1` | `0x3f0` | `sub_3f1` | 280 | 11 |  |
| `0x5575` | `0x5574` | `sub_5575` | 238 | 13 |  |
| `0x5491` | `0x5490` | `sub_5491` | 222 | 13 |  |
| `0x50d` | `0x50c` | `sub_50d` | 256 | 10 |  |
| `0x57cd` | `0x57cc` | `sub_57cd` | 256 | 10 |  |
| `0x4677` | `0x4676` | `sub_4677` | 220 | 10 |  |
| `0x52a5` | `0x52a4` | `sub_52a5` | 234 | 9 |  |
| `0x5395` | `0x5394` | `sub_5395` | 250 | 8 |  |
| `0x51ad` | `0x51ac` | `sub_51ad` | 248 | 8 |  |
| `0x58cd` | `0x58cc` | `sub_58cd` | 208 | 8 |  |
| `0x4d31` | `0x4d30` | `sub_4d31` | 126 | 11 |  |
| `0x3655` | `0x3654` | `sub_3655` | 118 | 11 |  |

## monstermodule_1

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x391` | `0x390` | `sub_391` | 3888 | 187 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x1f31` | `0x1f30` | `sub_1f31` | 2136 | 84 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x331d` | `0x331c` | `sub_331d` | 926 | 54 | 分支多，可能是状态机/菜单/结算 |
| `0x2965` | `0x2964` | `sub_2965` | 1024 | 45 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x2e41` | `0x2e40` | `sub_2e41` | 634 | 28 | 分支多，可能是状态机/菜单/结算 |
| `0x1879` | `0x1878` | `sub_1879` | 504 | 22 | 分支多，可能是状态机/菜单/结算 |
| `0x3199` | `0x3198` | `sub_3199` | 388 | 25 | 分支多，可能是状态机/菜单/结算 |
| `0x1dd` | `0x1dc` | `sub_1dd` | 432 | 21 | 分支多，可能是状态机/菜单/结算 |
| `0x1bb9` | `0x1bb8` | `sub_1bb9` | 418 | 21 | 分支多，可能是状态机/菜单/结算 |
| `0x1d6d` | `0x1d6c` | `sub_1d6d` | 450 | 16 |  |
| `0x279d` | `0x279c` | `sub_279d` | 384 | 19 |  |
| `0x3bdd` | `0x3bdc` | `sub_3bdd` | 276 | 24 | 分支多，可能是状态机/菜单/结算 |
| `0x1349` | `0x1348` | `sub_1349` | 398 | 17 |  |
| `0x1a89` | `0x1a88` | `sub_1a89` | 300 | 14 |  |
| `0x3d3d` | `0x3d3c` | `sub_3d3d` | 216 | 18 |  |
| `0x14f1` | `0x14f0` | `sub_14f1` | 300 | 13 |  |
| `0x16eb` | `0x16ea` | `sub_16eb` | 266 | 12 |  |
| `0x437d` | `0x437c` | `sub_437d` | 268 | 10 |  |
| `0x41c5` | `0x41c4` | `sub_41c5` | 230 | 9 |  |
| `0x105` | `0x104` | `sub_105` | 212 | 9 |  |
| `0x3e21` | `0x3e20` | `sub_3e21` | 210 | 8 |  |
| `0x42ad` | `0x42ac` | `sub_42ad` | 208 | 8 |  |
| `0x403d` | `0x403c` | `sub_403d` | 206 | 8 |  |
| `0x3aad` | `0x3aac` | `sub_3aad` | 118 | 11 |  |
| `0x2d95` | `0x2d94` | `sub_2d95` | 172 | 8 |  |
| `0x3f85` | `0x3f84` | `sub_3f85` | 182 | 7 |  |
| `0x410d` | `0x410c` | `sub_410d` | 182 | 7 |  |
| `0x1621` | `0x1620` | `sub_1621` | 152 | 7 |  |
| `0x3b7d` | `0x3b7c` | `sub_3b7d` | 90 | 10 |  |
| `0x3a91` | `0x3a90` | `sub_3a91` | 138 | 6 |  |

## robotol

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x800d` | `0x800c` | `sub_800d` | 5214 | 389 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x6e49` | `0x6e48` | `sub_6e49` | 3776 | 347 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x1a201` | `0x1a200` | `sub_1a201` | 3414 | 160 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x292d5` | `0x292d4` | `sub_292d5` | 2576 | 195 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0xd06d` | `0xd06c` | `sub_d06d` | 2198 | 143 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x2bdfd` | `0x2bdfc` | `sub_2bdfd` | 1772 | 156 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x29e90` | `0x29e90` | `sub_29e90` | 2984 | 91 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x1c615` | `0x1c614` | `sub_1c615` | 1348 | 125 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x320dd` | `0x320dc` | `sub_320dd` | 1318 | 121 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0xc95d` | `0xc95c` | `sub_c95d` | 1576 | 99 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x11c21` | `0x11c20` | `sub_11c21` | 1680 | 91 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x1585d` | `0x1585c` | `sub_1585d` | 1792 | 83 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x13259` | `0x13258` | `sub_13259` | 1520 | 83 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x2b021` | `0x2b020` | `sub_2b021` | 1248 | 91 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x18b6d` | `0x18b6c` | `sub_18b6d` | 1504 | 71 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x2f4c5` | `0x2f4c4` | `sub_2f4c5` | 1154 | 82 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x2d519` | `0x2d518` | `sub_2d519` | 1192 | 76 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x1fbe9` | `0x1fbe8` | `sub_1fbe9` | 924 | 81 | 分支多，可能是状态机/菜单/结算 |
| `0x16a81` | `0x16a80` | `sub_16a81` | 1174 | 61 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x24fb9` | `0x24fb8` | `sub_24fb9` | 946 | 67 | 分支多，可能是状态机/菜单/结算 |
| `0xb995` | `0xb994` | `sub_b995` | 938 | 67 | 分支多，可能是状态机/菜单/结算 |
| `0x39ed9` | `0x39ed8` | `sub_39ed9` | 908 | 67 | 分支多，可能是状态机/菜单/结算 |
| `0x1d01d` | `0x1d01c` | `sub_1d01d` | 1028 | 59 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x1b6a9` | `0x1b6a8` | `sub_1b6a9` | 1364 | 40 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x38a9d` | `0x38a9c` | `sub_38a9d` | 860 | 65 | 分支多，可能是状态机/菜单/结算 |
| `0x13bcd` | `0x13bcc` | `sub_13bcd` | 1114 | 49 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x30795` | `0x30794` | `sub_30795` | 954 | 57 | 分支多，可能是状态机/菜单/结算 |
| `0x20bdd` | `0x20bdc` | `sub_20bdd` | 728 | 68 | 分支多，可能是状态机/菜单/结算 |
| `0x24241` | `0x24240` | `sub_24241` | 698 | 68 | 分支多，可能是状态机/菜单/结算 |
| `0x33dc9` | `0x33dc8` | `sub_33dc9` | 1282 | 36 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |

## shopmodule

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x1011a7` | `0x1011a6` | `sub_1011a7` | 28250 | 1 | 大函数，可能是核心流程 |
| `0x2299` | `0x2298` | `sub_2299` | 1138 | 54 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x9b1` | `0x9b0` | `sub_9b1` | 1004 | 48 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x14dd` | `0x14dc` | `sub_14dd` | 1070 | 43 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x10e5` | `0x10e4` | `sub_10e5` | 1010 | 40 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x1d31` | `0x1d30` | `sub_1d31` | 878 | 45 | 分支多，可能是状态机/菜单/结算 |
| `0xdad` | `0xdac` | `sub_dad` | 652 | 26 | 分支多，可能是状态机/菜单/结算 |
| `0x2fd5` | `0x2fd4` | `sub_2fd5` | 514 | 27 | 分支多，可能是状态机/菜单/结算 |
| `0x3591` | `0x3590` | `sub_3591` | 738 | 1 |  |
| `0x2c8d` | `0x2c8c` | `sub_2c8d` | 276 | 24 | 分支多，可能是状态机/菜单/结算 |
| `0x711` | `0x710` | `sub_711` | 394 | 16 |  |
| `0x32dd` | `0x32dc` | `sub_32dd` | 274 | 20 | 分支多，可能是状态机/菜单/结算 |
| `0x288d` | `0x288c` | `sub_288d` | 234 | 18 |  |
| `0x1991` | `0x1990` | `sub_1991` | 292 | 15 |  |
| `0x2de5` | `0x2de4` | `sub_2de5` | 216 | 18 |  |
| `0x2ed1` | `0x2ed0` | `sub_2ed1` | 256 | 15 |  |
| `0x50d` | `0x50c` | `sub_50d` | 312 | 12 |  |
| `0x20` | `0x20` | `sub_20` | 290 | 11 |  |
| `0x1a5` | `0x1a4` | `sub_1a5` | 150 | 18 |  |
| `0x1c17` | `0x1c16` | `sub_1c17` | 232 | 12 |  |
| `0x31dd` | `0x31dc` | `sub_31dd` | 254 | 10 |  |
| `0x2745` | `0x2744` | `sub_2745` | 230 | 9 |  |
| `0x649` | `0x648` | `sub_649` | 194 | 8 |  |
| `0x30` | `0x30` | `sub_30` | 212 | 7 |  |
| `0x2b5d` | `0x2b5c` | `sub_2b5d` | 126 | 11 |  |
| `0x2159` | `0x2158` | `sub_2159` | 162 | 9 |  |
| `0x401` | `0x400` | `sub_401` | 170 | 8 |  |
| `0x2c2d` | `0x2c2c` | `sub_2c2d` | 90 | 10 |  |
| `0x103d` | `0x103c` | `sub_103d` | 162 | 6 |  |
| `0x20d5` | `0x20d4` | `sub_20d5` | 132 | 6 |  |

## cfunction_1

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x8` | `0x8` | `candidate_000008` | None | None | 候选函数，需人工确认 |
| `0xb` | `0xa` | `candidate_00000a` | None | None | 候选函数，需人工确认 |
| `0x2157` | `0x2156` | `candidate_002156` | None | None | 候选函数，需人工确认 |
| `0x265f` | `0x265e` | `candidate_00265e` | None | None | 候选函数，需人工确认 |
| `0x26ab` | `0x26aa` | `candidate_0026aa` | None | None | 候选函数，需人工确认 |
| `0x26cb` | `0x26ca` | `candidate_0026ca` | None | None | 候选函数，需人工确认 |
| `0x26ff` | `0x26fe` | `candidate_0026fe` | None | None | 候选函数，需人工确认 |
| `0x2719` | `0x2718` | `candidate_002718` | None | None | 候选函数，需人工确认 |
| `0x275d` | `0x275c` | `candidate_00275c` | None | None | 候选函数，需人工确认 |
| `0x275f` | `0x275e` | `candidate_00275e` | None | None | 候选函数，需人工确认 |
| `0x27cd` | `0x27cc` | `candidate_0027cc` | None | None | 候选函数，需人工确认 |
| `0x28ed` | `0x28ec` | `candidate_0028ec` | None | None | 候选函数，需人工确认 |
| `0x293b` | `0x293a` | `candidate_00293a` | None | None | 候选函数，需人工确认 |
| `0x2acb` | `0x2aca` | `candidate_002aca` | None | None | 候选函数，需人工确认 |
| `0x2aff` | `0x2afe` | `candidate_002afe` | None | None | 候选函数，需人工确认 |
| `0x2b33` | `0x2b32` | `candidate_002b32` | None | None | 候选函数，需人工确认 |
| `0x2ba7` | `0x2ba6` | `candidate_002ba6` | None | None | 候选函数，需人工确认 |
| `0x2c33` | `0x2c32` | `candidate_002c32` | None | None | 候选函数，需人工确认 |
| `0x2c73` | `0x2c72` | `candidate_002c72` | None | None | 候选函数，需人工确认 |
| `0x2ddb` | `0x2dda` | `candidate_002dda` | None | None | 候选函数，需人工确认 |
| `0x2dfb` | `0x2dfa` | `candidate_002dfa` | None | None | 候选函数，需人工确认 |
| `0x2ee3` | `0x2ee2` | `candidate_002ee2` | None | None | 候选函数，需人工确认 |
| `0x30ab` | `0x30aa` | `candidate_0030aa` | None | None | 候选函数，需人工确认 |
| `0x3123` | `0x3122` | `candidate_003122` | None | None | 候选函数，需人工确认 |
| `0x31af` | `0x31ae` | `candidate_0031ae` | None | None | 候选函数，需人工确认 |
| `0x31fb` | `0x31fa` | `candidate_0031fa` | None | None | 候选函数，需人工确认 |
| `0x323b` | `0x323a` | `candidate_00323a` | None | None | 候选函数，需人工确认 |
| `0x33db` | `0x33da` | `candidate_0033da` | None | None | 候选函数，需人工确认 |
| `0x33fb` | `0x33fa` | `candidate_0033fa` | None | None | 候选函数，需人工确认 |
| `0x3463` | `0x3462` | `candidate_003462` | None | None | 候选函数，需人工确认 |

## chatmodule_1

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x8` | `0x8` | `candidate_000008` | None | None | 候选函数，需人工确认 |
| `0xb` | `0xa` | `candidate_00000a` | None | None | 候选函数，需人工确认 |
| `0x53` | `0x52` | `candidate_000052` | None | None | 候选函数，需人工确认 |
| `0x6d` | `0x6c` | `candidate_00006c` | None | None | 候选函数，需人工确认 |
| `0xcd` | `0xcc` | `candidate_0000cc` | None | None | 候选函数，需人工确认 |
| `0x1ed` | `0x1ec` | `candidate_0001ec` | None | None | 候选函数，需人工确认 |
| `0x265` | `0x264` | `candidate_000264` | None | None | 候选函数，需人工确认 |
| `0x32d` | `0x32c` | `candidate_00032c` | None | None | 候选函数，需人工确认 |
| `0x485` | `0x484` | `candidate_000484` | None | None | 候选函数，需人工确认 |
| `0x609` | `0x608` | `candidate_000608` | None | None | 候选函数，需人工确认 |
| `0x821` | `0x820` | `candidate_000820` | None | None | 候选函数，需人工确认 |
| `0x1335` | `0x1334` | `candidate_001334` | None | None | 候选函数，需人工确认 |
| `0x19f1` | `0x19f0` | `candidate_0019f0` | None | None | 候选函数，需人工确认 |
| `0x1d05` | `0x1d04` | `candidate_001d04` | None | None | 候选函数，需人工确认 |
| `0x1d31` | `0x1d30` | `candidate_001d30` | None | None | 候选函数，需人工确认 |
| `0x1d8d` | `0x1d8c` | `candidate_001d8c` | None | None | 候选函数，需人工确认 |
| `0x1ed1` | `0x1ed0` | `candidate_001ed0` | None | None | 候选函数，需人工确认 |
| `0x2035` | `0x2034` | `candidate_002034` | None | None | 候选函数，需人工确认 |
| `0x25a5` | `0x25a4` | `candidate_0025a4` | None | None | 候选函数，需人工确认 |
| `0x29d5` | `0x29d4` | `candidate_0029d4` | None | None | 候选函数，需人工确认 |
| `0x2cb9` | `0x2cb8` | `candidate_002cb8` | None | None | 候选函数，需人工确认 |
| `0x2d41` | `0x2d40` | `candidate_002d40` | None | None | 候选函数，需人工确认 |
| `0x2d91` | `0x2d90` | `candidate_002d90` | None | None | 候选函数，需人工确认 |
| `0x2dcd` | `0x2dcc` | `candidate_002dcc` | None | None | 候选函数，需人工确认 |
| `0x2df1` | `0x2df0` | `candidate_002df0` | None | None | 候选函数，需人工确认 |
| `0x2e33` | `0x2e32` | `candidate_002e32` | None | None | 候选函数，需人工确认 |
| `0x2e45` | `0x2e44` | `candidate_002e44` | None | None | 候选函数，需人工确认 |
| `0x2ea9` | `0x2ea8` | `candidate_002ea8` | None | None | 候选函数，需人工确认 |
| `0x2f45` | `0x2f44` | `candidate_002f44` | None | None | 候选函数，需人工确认 |
| `0x2fd9` | `0x2fd8` | `candidate_002fd8` | None | None | 候选函数，需人工确认 |

## gezimodule_1

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x8` | `0x8` | `candidate_000008` | None | None | 候选函数，需人工确认 |
| `0xb` | `0xa` | `candidate_00000a` | None | None | 候选函数，需人工确认 |
| `0x3d` | `0x3c` | `candidate_00003c` | None | None | 候选函数，需人工确认 |
| `0x105` | `0x104` | `candidate_000104` | None | None | 候选函数，需人工确认 |
| `0x361` | `0x360` | `candidate_000360` | None | None | 候选函数，需人工确认 |
| `0x419` | `0x418` | `candidate_000418` | None | None | 候选函数，需人工确认 |
| `0x4f1` | `0x4f0` | `candidate_0004f0` | None | None | 候选函数，需人工确认 |
| `0x611` | `0x610` | `candidate_000610` | None | None | 候选函数，需人工确认 |
| `0xac1` | `0xac0` | `candidate_000ac0` | None | None | 候选函数，需人工确认 |
| `0xb61` | `0xb60` | `candidate_000b60` | None | None | 候选函数，需人工确认 |
| `0xc99` | `0xc98` | `candidate_000c98` | None | None | 候选函数，需人工确认 |
| `0xd6d` | `0xd6c` | `candidate_000d6c` | None | None | 候选函数，需人工确认 |
| `0xe61` | `0xe60` | `candidate_000e60` | None | None | 候选函数，需人工确认 |
| `0x10c9` | `0x10c8` | `candidate_0010c8` | None | None | 候选函数，需人工确认 |
| `0x1159` | `0x1158` | `candidate_001158` | None | None | 候选函数，需人工确认 |
| `0x1195` | `0x1194` | `candidate_001194` | None | None | 候选函数，需人工确认 |
| `0x11b9` | `0x11b8` | `candidate_0011b8` | None | None | 候选函数，需人工确认 |
| `0x11f9` | `0x11f8` | `candidate_0011f8` | None | None | 候选函数，需人工确认 |
| `0x125d` | `0x125c` | `candidate_00125c` | None | None | 候选函数，需人工确认 |
| `0x12f9` | `0x12f8` | `candidate_0012f8` | None | None | 候选函数，需人工确认 |
| `0x138d` | `0x138c` | `candidate_00138c` | None | None | 候选函数，需人工确认 |
| `0x14b9` | `0x14b8` | `candidate_0014b8` | None | None | 候选函数，需人工确认 |
| `0x14ef` | `0x14ee` | `candidate_0014ee` | None | None | 候选函数，需人工确认 |
| `0x15d1` | `0x15d0` | `candidate_0015d0` | None | None | 候选函数，需人工确认 |
| `0x166d` | `0x166c` | `candidate_00166c` | None | None | 候选函数，需人工确认 |
| `0x1821` | `0x1820` | `candidate_001820` | None | None | 候选函数，需人工确认 |
| `0x19e1` | `0x19e0` | `candidate_0019e0` | None | None | 候选函数，需人工确认 |

## leitaimodule_1

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x8` | `0x8` | `candidate_000008` | None | None | 候选函数，需人工确认 |
| `0xb` | `0xa` | `candidate_00000a` | None | None | 候选函数，需人工确认 |
| `0x11b` | `0x11a` | `candidate_00011a` | None | None | 候选函数，需人工确认 |
| `0x135` | `0x134` | `candidate_000134` | None | None | 候选函数，需人工确认 |
| `0x195` | `0x194` | `candidate_000194` | None | None | 候选函数，需人工确认 |
| `0x2b5` | `0x2b4` | `candidate_0002b4` | None | None | 候选函数，需人工确认 |
| `0x309` | `0x308` | `candidate_000308` | None | None | 候选函数，需人工确认 |
| `0x3d1` | `0x3d0` | `candidate_0003d0` | None | None | 候选函数，需人工确认 |
| `0x599` | `0x598` | `candidate_000598` | None | None | 候选函数，需人工确认 |
| `0x7c5` | `0x7c4` | `candidate_0007c4` | None | None | 候选函数，需人工确认 |
| `0x895` | `0x894` | `candidate_000894` | None | None | 候选函数，需人工确认 |
| `0xb35` | `0xb34` | `candidate_000b34` | None | None | 候选函数，需人工确认 |
| `0xd99` | `0xd98` | `candidate_000d98` | None | None | 候选函数，需人工确认 |
| `0xf8d` | `0xf8c` | `candidate_000f8c` | None | None | 候选函数，需人工确认 |
| `0x132d` | `0x132c` | `candidate_00132c` | None | None | 候选函数，需人工确认 |
| `0x13a9` | `0x13a8` | `candidate_0013a8` | None | None | 候选函数，需人工确认 |
| `0x16e5` | `0x16e4` | `candidate_0016e4` | None | None | 候选函数，需人工确认 |
| `0x17cd` | `0x17cc` | `candidate_0017cc` | None | None | 候选函数，需人工确认 |
| `0x1ba5` | `0x1ba4` | `candidate_001ba4` | None | None | 候选函数，需人工确认 |
| `0x2565` | `0x2564` | `candidate_002564` | None | None | 候选函数，需人工确认 |
| `0x2f2d` | `0x2f2c` | `candidate_002f2c` | None | None | 候选函数，需人工确认 |
| `0x3031` | `0x3030` | `candidate_003030` | None | None | 候选函数，需人工确认 |
| `0x317d` | `0x317c` | `candidate_00317c` | None | None | 候选函数，需人工确认 |
| `0x32e1` | `0x32e0` | `candidate_0032e0` | None | None | 候选函数，需人工确认 |
| `0x3351` | `0x3350` | `candidate_003350` | None | None | 候选函数，需人工确认 |
| `0x3545` | `0x3544` | `candidate_003544` | None | None | 候选函数，需人工确认 |
| `0x35ed` | `0x35ec` | `candidate_0035ec` | None | None | 候选函数，需人工确认 |
| `0x38b1` | `0x38b0` | `candidate_0038b0` | None | None | 候选函数，需人工确认 |
| `0x399d` | `0x399c` | `candidate_00399c` | None | None | 候选函数，需人工确认 |
| `0x3a05` | `0x3a04` | `candidate_003a04` | None | None | 候选函数，需人工确认 |

## lianmengmodule

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x8` | `0x8` | `candidate_000008` | None | None | 候选函数，需人工确认 |
| `0xb` | `0xa` | `candidate_00000a` | None | None | 候选函数，需人工确认 |
| `0x11b` | `0x11a` | `candidate_00011a` | None | None | 候选函数，需人工确认 |
| `0x135` | `0x134` | `candidate_000134` | None | None | 候选函数，需人工确认 |
| `0x195` | `0x194` | `candidate_000194` | None | None | 候选函数，需人工确认 |
| `0x2b5` | `0x2b4` | `candidate_0002b4` | None | None | 候选函数，需人工确认 |
| `0x329` | `0x328` | `candidate_000328` | None | None | 候选函数，需人工确认 |
| `0x3f1` | `0x3f0` | `candidate_0003f0` | None | None | 候选函数，需人工确认 |
| `0x449` | `0x448` | `candidate_000448` | None | None | 候选函数，需人工确认 |
| `0x519` | `0x518` | `candidate_000518` | None | None | 候选函数，需人工确认 |
| `0x6a9` | `0x6a8` | `candidate_0006a8` | None | None | 候选函数，需人工确认 |
| `0x771` | `0x770` | `candidate_000770` | None | None | 候选函数，需人工确认 |
| `0x8e1` | `0x8e0` | `candidate_0008e0` | None | None | 候选函数，需人工确认 |
| `0x9c9` | `0x9c8` | `candidate_0009c8` | None | None | 候选函数，需人工确认 |
| `0xa95` | `0xa94` | `candidate_000a94` | None | None | 候选函数，需人工确认 |
| `0x14d9` | `0x14d8` | `candidate_0014d8` | None | None | 候选函数，需人工确认 |
| `0x1545` | `0x1544` | `candidate_001544` | None | None | 候选函数，需人工确认 |
| `0x165d` | `0x165c` | `candidate_00165c` | None | None | 候选函数，需人工确认 |
| `0x188d` | `0x188c` | `candidate_00188c` | None | None | 候选函数，需人工确认 |
| `0x18f9` | `0x18f8` | `candidate_0018f8` | None | None | 候选函数，需人工确认 |
| `0x1995` | `0x1994` | `candidate_001994` | None | None | 候选函数，需人工确认 |
| `0x19f9` | `0x19f8` | `candidate_0019f8` | None | None | 候选函数，需人工确认 |
| `0x1ffd` | `0x1ffc` | `candidate_001ffc` | None | None | 候选函数，需人工确认 |
| `0x2c19` | `0x2c18` | `candidate_002c18` | None | None | 候选函数，需人工确认 |
| `0x2c95` | `0x2c94` | `candidate_002c94` | None | None | 候选函数，需人工确认 |
| `0x2cf5` | `0x2cf4` | `candidate_002cf4` | None | None | 候选函数，需人工确认 |
| `0x31e1` | `0x31e0` | `candidate_0031e0` | None | None | 候选函数，需人工确认 |
| `0x32b1` | `0x32b0` | `candidate_0032b0` | None | None | 候选函数，需人工确认 |
| `0x3345` | `0x3344` | `candidate_003344` | None | None | 候选函数，需人工确认 |
| `0x351d` | `0x351c` | `candidate_00351c` | None | None | 候选函数，需人工确认 |

## mailmodule_1

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x8` | `0x8` | `candidate_000008` | None | None | 候选函数，需人工确认 |
| `0xb` | `0xa` | `candidate_00000a` | None | None | 候选函数，需人工确认 |
| `0x11b` | `0x11a` | `candidate_00011a` | None | None | 候选函数，需人工确认 |
| `0x135` | `0x134` | `candidate_000134` | None | None | 候选函数，需人工确认 |
| `0x195` | `0x194` | `candidate_000194` | None | None | 候选函数，需人工确认 |
| `0x2b5` | `0x2b4` | `candidate_0002b4` | None | None | 候选函数，需人工确认 |
| `0x329` | `0x328` | `candidate_000328` | None | None | 候选函数，需人工确认 |
| `0x3f1` | `0x3f0` | `candidate_0003f0` | None | None | 候选函数，需人工确认 |
| `0x49d` | `0x49c` | `candidate_00049c` | None | None | 候选函数，需人工确认 |
| `0x6c5` | `0x6c4` | `candidate_0006c4` | None | None | 候选函数，需人工确认 |
| `0x93d` | `0x93c` | `candidate_00093c` | None | None | 候选函数，需人工确认 |
| `0xa15` | `0xa14` | `candidate_000a14` | None | None | 候选函数，需人工确认 |
| `0xbed` | `0xbec` | `candidate_000bec` | None | None | 候选函数，需人工确认 |
| `0xdb5` | `0xdb4` | `candidate_000db4` | None | None | 候选函数，需人工确认 |
| `0x1009` | `0x1008` | `candidate_001008` | None | None | 候选函数，需人工确认 |
| `0x11f5` | `0x11f4` | `candidate_0011f4` | None | None | 候选函数，需人工确认 |
| `0x179d` | `0x179c` | `candidate_00179c` | None | None | 候选函数，需人工确认 |
| `0x19a9` | `0x19a8` | `candidate_0019a8` | None | None | 候选函数，需人工确认 |
| `0x1d5d` | `0x1d5c` | `candidate_001d5c` | None | None | 候选函数，需人工确认 |
| `0x24a9` | `0x24a8` | `candidate_0024a8` | None | None | 候选函数，需人工确认 |
| `0x3b1d` | `0x3b1c` | `candidate_003b1c` | None | None | 候选函数，需人工确认 |
| `0x3be1` | `0x3be0` | `candidate_003be0` | None | None | 候选函数，需人工确认 |
| `0x3d81` | `0x3d80` | `candidate_003d80` | None | None | 候选函数，需人工确认 |
| `0x3dad` | `0x3dac` | `candidate_003dac` | None | None | 候选函数，需人工确认 |
| `0x3e39` | `0x3e38` | `candidate_003e38` | None | None | 候选函数，需人工确认 |
| `0x3ef5` | `0x3ef4` | `candidate_003ef4` | None | None | 候选函数，需人工确认 |
| `0x3f55` | `0x3f54` | `candidate_003f54` | None | None | 候选函数，需人工确认 |
| `0x43d5` | `0x43d4` | `candidate_0043d4` | None | None | 候选函数，需人工确认 |
| `0x44c9` | `0x44c8` | `candidate_0044c8` | None | None | 候选函数，需人工确认 |
| `0x47a1` | `0x47a0` | `candidate_0047a0` | None | None | 候选函数，需人工确认 |

## mainmenumodule_1

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x1239` | `0x1238` | `sub_1239` | 3450 | 123 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x2ea5` | `0x2ea4` | `sub_2ea5` | 2228 | 82 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x3795` | `0x3794` | `sub_3795` | 2144 | 85 | 大函数，可能是核心流程；分支多，可能是状态机/菜单/结算 |
| `0x24cd` | `0x24cc` | `sub_24cd` | 922 | 19 |  |
| `0xc1d` | `0xc1c` | `sub_c1d` | 720 | 26 | 分支多，可能是状态机/菜单/结算 |
| `0xeed` | `0xeec` | `sub_eed` | 578 | 23 | 分支多，可能是状态机/菜单/结算 |
| `0x2b59` | `0x2b58` | `sub_2b59` | 570 | 18 |  |
| `0x43b5` | `0x43b4` | `sub_43b5` | 490 | 20 | 分支多，可能是状态机/菜单/结算 |
| `0x45a9` | `0x45a8` | `sub_45a9` | 464 | 21 | 分支多，可能是状态机/菜单/结算 |
| `0x2869` | `0x2868` | `sub_2869` | 516 | 17 |  |
| `0x6415` | `0x6414` | `sub_6415` | 362 | 23 | 分支多，可能是状态机/菜单/结算 |
| `0xa01` | `0xa00` | `sub_a01` | 386 | 21 | 分支多，可能是状态机/菜单/结算 |
| `0x4821` | `0x4820` | `sub_4821` | 396 | 19 |  |
| `0x899` | `0x898` | `sub_899` | 340 | 21 | 分支多，可能是状态机/菜单/结算 |
| `0x5d2d` | `0x5d2c` | `sub_5d2d` | 344 | 18 |  |
| `0x5ebd` | `0x5ebc` | `sub_5ebd` | 322 | 19 |  |
| `0x5a89` | `0x5a88` | `sub_5a89` | 310 | 18 |  |
| `0x4c41` | `0x4c40` | `sub_4c41` | 272 | 19 |  |
| `0x4a9d` | `0x4a9c` | `sub_4a9d` | 370 | 14 |  |
| `0x5c0d` | `0x5c0c` | `sub_5c0d` | 284 | 17 |  |
| `0x538d` | `0x538c` | `sub_538d` | 240 | 19 |  |
| `0x6699` | `0x6698` | `sub_6699` | 296 | 16 |  |
| `0x54ed` | `0x54ec` | `sub_54ed` | 216 | 18 |  |
| `0x6591` | `0x6590` | `sub_6591` | 258 | 14 |  |
| `0x1135` | `0x1134` | `sub_1135` | 254 | 14 |  |
| `0x195` | `0x194` | `sub_195` | 150 | 18 |  |
| `0x56b1` | `0x56b0` | `sub_56b1` | 326 | 9 |  |
| `0x6039` | `0x6038` | `sub_6039` | 264 | 10 |  |
| `0x629` | `0x628` | `sub_629` | 230 | 11 |  |
| `0x41e9` | `0x41e8` | `sub_41e9` | 262 | 9 |  |

## moduletest_1

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x8` | `0x8` | `candidate_000008` | None | None | 候选函数，需人工确认 |
| `0xb` | `0xa` | `candidate_00000a` | None | None | 候选函数，需人工确认 |
| `0x3d` | `0x3c` | `candidate_00003c` | None | None | 候选函数，需人工确认 |
| `0x105` | `0x104` | `candidate_000104` | None | None | 候选函数，需人工确认 |
| `0x849` | `0x848` | `candidate_000848` | None | None | 候选函数，需人工确认 |
| `0xc39` | `0xc38` | `candidate_000c38` | None | None | 候选函数，需人工确认 |
| `0xd71` | `0xd70` | `candidate_000d70` | None | None | 候选函数，需人工确认 |
| `0x1955` | `0x1954` | `candidate_001954` | None | None | 候选函数，需人工确认 |
| `0x2129` | `0x2128` | `candidate_002128` | None | None | 候选函数，需人工确认 |
| `0x24cd` | `0x24cc` | `candidate_0024cc` | None | None | 候选函数，需人工确认 |
| `0x285d` | `0x285c` | `candidate_00285c` | None | None | 候选函数，需人工确认 |
| `0x2951` | `0x2950` | `candidate_002950` | None | None | 候选函数，需人工确认 |
| `0x29e1` | `0x29e0` | `candidate_0029e0` | None | None | 候选函数，需人工确认 |
| `0x2a1d` | `0x2a1c` | `candidate_002a1c` | None | None | 候选函数，需人工确认 |
| `0x2a41` | `0x2a40` | `candidate_002a40` | None | None | 候选函数，需人工确认 |
| `0x2a81` | `0x2a80` | `candidate_002a80` | None | None | 候选函数，需人工确认 |
| `0x2ae5` | `0x2ae4` | `candidate_002ae4` | None | None | 候选函数，需人工确认 |
| `0x2b81` | `0x2b80` | `candidate_002b80` | None | None | 候选函数，需人工确认 |
| `0x2c15` | `0x2c14` | `candidate_002c14` | None | None | 候选函数，需人工确认 |
| `0x2d41` | `0x2d40` | `candidate_002d40` | None | None | 候选函数，需人工确认 |
| `0x2d77` | `0x2d76` | `candidate_002d76` | None | None | 候选函数，需人工确认 |
| `0x2e59` | `0x2e58` | `candidate_002e58` | None | None | 候选函数，需人工确认 |
| `0x2ef1` | `0x2ef0` | `candidate_002ef0` | None | None | 候选函数，需人工确认 |
| `0x2fdd` | `0x2fdc` | `candidate_002fdc` | None | None | 候选函数，需人工确认 |
| `0x3065` | `0x3064` | `candidate_003064` | None | None | 候选函数，需人工确认 |
| `0x3101` | `0x3100` | `candidate_003100` | None | None | 候选函数，需人工确认 |
| `0x3241` | `0x3240` | `candidate_003240` | None | None | 候选函数，需人工确认 |
| `0x3295` | `0x3294` | `candidate_003294` | None | None | 候选函数，需人工确认 |
| `0x32ed` | `0x32ec` | `candidate_0032ec` | None | None | 候选函数，需人工确认 |
| `0x3389` | `0x3388` | `candidate_003388` | None | None | 候选函数，需人工确认 |

## monsterstatemodule_1

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x8` | `0x8` | `candidate_000008` | None | None | 候选函数，需人工确认 |
| `0xb` | `0xa` | `candidate_00000a` | None | None | 候选函数，需人工确认 |
| `0x12b` | `0x12a` | `candidate_00012a` | None | None | 候选函数，需人工确认 |
| `0x145` | `0x144` | `candidate_000144` | None | None | 候选函数，需人工确认 |
| `0x1a5` | `0x1a4` | `candidate_0001a4` | None | None | 候选函数，需人工确认 |
| `0x2c5` | `0x2c4` | `candidate_0002c4` | None | None | 候选函数，需人工确认 |
| `0x339` | `0x338` | `candidate_000338` | None | None | 候选函数，需人工确认 |
| `0x401` | `0x400` | `candidate_000400` | None | None | 候选函数，需人工确认 |
| `0x4d1` | `0x4d0` | `candidate_0004d0` | None | None | 候选函数，需人工确认 |
| `0x5d9` | `0x5d8` | `candidate_0005d8` | None | None | 候选函数，需人工确认 |
| `0x665` | `0x664` | `candidate_000664` | None | None | 候选函数，需人工确认 |
| `0x6cd` | `0x6cc` | `candidate_0006cc` | None | None | 候选函数，需人工确认 |
| `0x7d5` | `0x7d4` | `candidate_0007d4` | None | None | 候选函数，需人工确认 |
| `0x9c1` | `0x9c0` | `candidate_0009c0` | None | None | 候选函数，需人工确认 |
| `0xcc9` | `0xcc8` | `candidate_000cc8` | None | None | 候选函数，需人工确认 |
| `0xd99` | `0xd98` | `candidate_000d98` | None | None | 候选函数，需人工确认 |
| `0x1209` | `0x1208` | `candidate_001208` | None | None | 候选函数，需人工确认 |
| `0x17d1` | `0x17d0` | `candidate_0017d0` | None | None | 候选函数，需人工确认 |
| `0x1ca5` | `0x1ca4` | `candidate_001ca4` | None | None | 候选函数，需人工确认 |
| `0x21e9` | `0x21e8` | `candidate_0021e8` | None | None | 候选函数，需人工确认 |
| `0x2511` | `0x2510` | `candidate_002510` | None | None | 候选函数，需人工确认 |
| `0x2629` | `0x2628` | `candidate_002628` | None | None | 候选函数，需人工确认 |
| `0x2ae1` | `0x2ae0` | `candidate_002ae0` | None | None | 候选函数，需人工确认 |
| `0x2b0d` | `0x2b0c` | `candidate_002b0c` | None | None | 候选函数，需人工确认 |
| `0x2c89` | `0x2c88` | `candidate_002c88` | None | None | 候选函数，需人工确认 |
| `0x2e0d` | `0x2e0c` | `candidate_002e0c` | None | None | 候选函数，需人工确认 |
| `0x2e8d` | `0x2e8c` | `candidate_002e8c` | None | None | 候选函数，需人工确认 |
| `0x338d` | `0x338c` | `candidate_00338c` | None | None | 候选函数，需人工确认 |
| `0x3595` | `0x3594` | `candidate_003594` | None | None | 候选函数，需人工确认 |
| `0x365d` | `0x365c` | `candidate_00365c` | None | None | 候选函数，需人工确认 |

## othermodule

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x8` | `0x8` | `candidate_000008` | None | None | 候选函数，需人工确认 |
| `0xb` | `0xa` | `candidate_00000a` | None | None | 候选函数，需人工确认 |
| `0x11b` | `0x11a` | `candidate_00011a` | None | None | 候选函数，需人工确认 |
| `0x135` | `0x134` | `candidate_000134` | None | None | 候选函数，需人工确认 |
| `0x195` | `0x194` | `candidate_000194` | None | None | 候选函数，需人工确认 |
| `0x2b5` | `0x2b4` | `candidate_0002b4` | None | None | 候选函数，需人工确认 |
| `0x329` | `0x328` | `candidate_000328` | None | None | 候选函数，需人工确认 |
| `0x3f1` | `0x3f0` | `candidate_0003f0` | None | None | 候选函数，需人工确认 |
| `0x445` | `0x444` | `candidate_000444` | None | None | 候选函数，需人工确认 |
| `0x4fd` | `0x4fc` | `candidate_0004fc` | None | None | 候选函数，需人工确认 |
| `0x5cd` | `0x5cc` | `candidate_0005cc` | None | None | 候选函数，需人工确认 |
| `0x6c5` | `0x6c4` | `candidate_0006c4` | None | None | 候选函数，需人工确认 |
| `0x725` | `0x724` | `candidate_000724` | None | None | 候选函数，需人工确认 |
| `0x87d` | `0x87c` | `candidate_00087c` | None | None | 候选函数，需人工确认 |
| `0x9b5` | `0x9b4` | `candidate_0009b4` | None | None | 候选函数，需人工确认 |
| `0xb55` | `0xb54` | `candidate_000b54` | None | None | 候选函数，需人工确认 |
| `0xca9` | `0xca8` | `candidate_000ca8` | None | None | 候选函数，需人工确认 |
| `0xf15` | `0xf14` | `candidate_000f14` | None | None | 候选函数，需人工确认 |
| `0xff5` | `0xff4` | `candidate_000ff4` | None | None | 候选函数，需人工确认 |
| `0x1085` | `0x1084` | `candidate_001084` | None | None | 候选函数，需人工确认 |
| `0x11f9` | `0x11f8` | `candidate_0011f8` | None | None | 候选函数，需人工确认 |
| `0x12e1` | `0x12e0` | `candidate_0012e0` | None | None | 候选函数，需人工确认 |
| `0x15d1` | `0x15d0` | `candidate_0015d0` | None | None | 候选函数，需人工确认 |
| `0x169d` | `0x169c` | `candidate_00169c` | None | None | 候选函数，需人工确认 |
| `0x17cd` | `0x17cc` | `candidate_0017cc` | None | None | 候选函数，需人工确认 |
| `0x1899` | `0x1898` | `candidate_001898` | None | None | 候选函数，需人工确认 |
| `0x2291` | `0x2290` | `candidate_002290` | None | None | 候选函数，需人工确认 |
| `0x23f1` | `0x23f0` | `candidate_0023f0` | None | None | 候选函数，需人工确认 |
| `0x24e5` | `0x24e4` | `candidate_0024e4` | None | None | 候选函数，需人工确认 |
| `0x2855` | `0x2854` | `candidate_002854` | None | None | 候选函数，需人工确认 |

## reg_1

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x8` | `0x8` | `candidate_000008` | None | None | 候选函数，需人工确认 |
| `0xb` | `0xa` | `candidate_00000a` | None | None | 候选函数，需人工确认 |
| `0x3d` | `0x3c` | `candidate_00003c` | None | None | 候选函数，需人工确认 |
| `0xc9` | `0xc8` | `candidate_0000c8` | None | None | 候选函数，需人工确认 |
| `0x11d` | `0x11c` | `candidate_00011c` | None | None | 候选函数，需人工确认 |
| `0x169` | `0x168` | `candidate_000168` | None | None | 候选函数，需人工确认 |
| `0x7a9` | `0x7a8` | `candidate_0007a8` | None | None | 候选函数，需人工确认 |
| `0x7c9` | `0x7c8` | `candidate_0007c8` | None | None | 候选函数，需人工确认 |
| `0x7f9` | `0x7f8` | `candidate_0007f8` | None | None | 候选函数，需人工确认 |

## taobaomodule_1

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x8` | `0x8` | `candidate_000008` | None | None | 候选函数，需人工确认 |
| `0xb` | `0xa` | `candidate_00000a` | None | None | 候选函数，需人工确认 |
| `0x11b` | `0x11a` | `candidate_00011a` | None | None | 候选函数，需人工确认 |
| `0x135` | `0x134` | `candidate_000134` | None | None | 候选函数，需人工确认 |
| `0x195` | `0x194` | `candidate_000194` | None | None | 候选函数，需人工确认 |
| `0x2b5` | `0x2b4` | `candidate_0002b4` | None | None | 候选函数，需人工确认 |
| `0x309` | `0x308` | `candidate_000308` | None | None | 候选函数，需人工确认 |
| `0x3d1` | `0x3d0` | `candidate_0003d0` | None | None | 候选函数，需人工确认 |
| `0x5e1` | `0x5e0` | `candidate_0005e0` | None | None | 候选函数，需人工确认 |
| `0x7e1` | `0x7e0` | `candidate_0007e0` | None | None | 候选函数，需人工确认 |
| `0x865` | `0x864` | `candidate_000864` | None | None | 候选函数，需人工确认 |
| `0xeb9` | `0xeb8` | `candidate_000eb8` | None | None | 候选函数，需人工确认 |
| `0x1665` | `0x1664` | `candidate_001664` | None | None | 候选函数，需人工确认 |
| `0x17c5` | `0x17c4` | `candidate_0017c4` | None | None | 候选函数，需人工确认 |
| `0x18d1` | `0x18d0` | `candidate_0018d0` | None | None | 候选函数，需人工确认 |
| `0x1dc9` | `0x1dc8` | `candidate_001dc8` | None | None | 候选函数，需人工确认 |
| `0x1efd` | `0x1efc` | `candidate_001efc` | None | None | 候选函数，需人工确认 |
| `0x1f25` | `0x1f24` | `candidate_001f24` | None | None | 候选函数，需人工确认 |
| `0x1fd5` | `0x1fd4` | `candidate_001fd4` | None | None | 候选函数，需人工确认 |
| `0x2059` | `0x2058` | `candidate_002058` | None | None | 候选函数，需人工确认 |
| `0x2109` | `0x2108` | `candidate_002108` | None | None | 候选函数，需人工确认 |
| `0x2481` | `0x2480` | `candidate_002480` | None | None | 候选函数，需人工确认 |
| `0x25ed` | `0x25ec` | `candidate_0025ec` | None | None | 候选函数，需人工确认 |
| `0x2689` | `0x2688` | `candidate_002688` | None | None | 候选函数，需人工确认 |
| `0x2941` | `0x2940` | `candidate_002940` | None | None | 候选函数，需人工确认 |
| `0x2c05` | `0x2c04` | `candidate_002c04` | None | None | 候选函数，需人工确认 |
| `0x2c8d` | `0x2c8c` | `candidate_002c8c` | None | None | 候选函数，需人工确认 |
| `0x2cdd` | `0x2cdc` | `candidate_002cdc` | None | None | 候选函数，需人工确认 |
| `0x2d19` | `0x2d18` | `candidate_002d18` | None | None | 候选函数，需人工确认 |
| `0x2d3d` | `0x2d3c` | `candidate_002d3c` | None | None | 候选函数，需人工确认 |

## viewmanmodule_1

| addr | offset | name | size | cc | reason |
|---:|---:|---|---:|---:|---|
| `0x8` | `0x8` | `candidate_000008` | None | None | 候选函数，需人工确认 |
| `0xb` | `0xa` | `candidate_00000a` | None | None | 候选函数，需人工确认 |
| `0x11b` | `0x11a` | `candidate_00011a` | None | None | 候选函数，需人工确认 |
| `0x135` | `0x134` | `candidate_000134` | None | None | 候选函数，需人工确认 |
| `0x195` | `0x194` | `candidate_000194` | None | None | 候选函数，需人工确认 |
| `0x2b5` | `0x2b4` | `candidate_0002b4` | None | None | 候选函数，需人工确认 |
| `0x309` | `0x308` | `candidate_000308` | None | None | 候选函数，需人工确认 |
| `0x3d1` | `0x3d0` | `candidate_0003d0` | None | None | 候选函数，需人工确认 |
| `0x425` | `0x424` | `candidate_000424` | None | None | 候选函数，需人工确认 |
| `0x4f9` | `0x4f8` | `candidate_0004f8` | None | None | 候选函数，需人工确认 |
| `0x8ad` | `0x8ac` | `candidate_0008ac` | None | None | 候选函数，需人工确认 |
| `0x1a2d` | `0x1a2c` | `candidate_001a2c` | None | None | 候选函数，需人工确认 |
| `0x1e41` | `0x1e40` | `candidate_001e40` | None | None | 候选函数，需人工确认 |
| `0x219d` | `0x219c` | `candidate_00219c` | None | None | 候选函数，需人工确认 |
| `0x2325` | `0x2324` | `candidate_002324` | None | None | 候选函数，需人工确认 |
| `0x28d5` | `0x28d4` | `candidate_0028d4` | None | None | 候选函数，需人工确认 |
| `0x2965` | `0x2964` | `candidate_002964` | None | None | 候选函数，需人工确认 |
| `0x2c39` | `0x2c38` | `candidate_002c38` | None | None | 候选函数，需人工确认 |
| `0x2cb1` | `0x2cb0` | `candidate_002cb0` | None | None | 候选函数，需人工确认 |
| `0x31dd` | `0x31dc` | `candidate_0031dc` | None | None | 候选函数，需人工确认 |
| `0x326d` | `0x326c` | `candidate_00326c` | None | None | 候选函数，需人工确认 |
| `0x32a9` | `0x32a8` | `candidate_0032a8` | None | None | 候选函数，需人工确认 |
| `0x32cd` | `0x32cc` | `candidate_0032cc` | None | None | 候选函数，需人工确认 |
| `0x330d` | `0x330c` | `candidate_00330c` | None | None | 候选函数，需人工确认 |
| `0x3371` | `0x3370` | `candidate_003370` | None | None | 候选函数，需人工确认 |
| `0x340d` | `0x340c` | `candidate_00340c` | None | None | 候选函数，需人工确认 |
| `0x34a1` | `0x34a0` | `candidate_0034a0` | None | None | 候选函数，需人工确认 |
| `0x35cd` | `0x35cc` | `candidate_0035cc` | None | None | 候选函数，需人工确认 |
| `0x3603` | `0x3602` | `candidate_003602` | None | None | 候选函数，需人工确认 |
| `0x36e5` | `0x36e4` | `candidate_0036e4` | None | None | 候选函数，需人工确认 |