# moduletest_1 function/candidate map

| addr | offset | mode | name | size | blocks | cc | returning |
|---:|---:|---|---|---:|---:|---:|---|
| `0x8` | `0x8` | ARM | `candidate_000008` | None | None | None | None |
| `0xb` | `0xa` | Thumb | `candidate_00000a` | None | None | None | None |
| `0x3d` | `0x3c` | Thumb | `candidate_00003c` | None | None | None | None |
| `0x105` | `0x104` | Thumb | `candidate_000104` | None | None | None | None |
| `0x849` | `0x848` | Thumb | `candidate_000848` | None | None | None | None |
| `0xc39` | `0xc38` | Thumb | `candidate_000c38` | None | None | None | None |
| `0xd71` | `0xd70` | Thumb | `candidate_000d70` | None | None | None | None |
| `0x1955` | `0x1954` | Thumb | `candidate_001954` | None | None | None | None |
| `0x2129` | `0x2128` | Thumb | `candidate_002128` | None | None | None | None |
| `0x24cd` | `0x24cc` | Thumb | `candidate_0024cc` | None | None | None | None |
| `0x285d` | `0x285c` | Thumb | `candidate_00285c` | None | None | None | None |
| `0x2951` | `0x2950` | Thumb | `candidate_002950` | None | None | None | None |
| `0x29e1` | `0x29e0` | Thumb | `candidate_0029e0` | None | None | None | None |
| `0x2a1d` | `0x2a1c` | Thumb | `candidate_002a1c` | None | None | None | None |
| `0x2a41` | `0x2a40` | Thumb | `candidate_002a40` | None | None | None | None |
| `0x2a81` | `0x2a80` | Thumb | `candidate_002a80` | None | None | None | None |
| `0x2ae5` | `0x2ae4` | Thumb | `candidate_002ae4` | None | None | None | None |
| `0x2b81` | `0x2b80` | Thumb | `candidate_002b80` | None | None | None | None |
| `0x2c15` | `0x2c14` | Thumb | `candidate_002c14` | None | None | None | None |
| `0x2d41` | `0x2d40` | Thumb | `candidate_002d40` | None | None | None | None |
| `0x2d77` | `0x2d76` | Thumb | `candidate_002d76` | None | None | None | None |
| `0x2e59` | `0x2e58` | Thumb | `candidate_002e58` | None | None | None | None |
| `0x2ef1` | `0x2ef0` | Thumb | `candidate_002ef0` | None | None | None | None |
| `0x2fdd` | `0x2fdc` | Thumb | `candidate_002fdc` | None | None | None | None |
| `0x3065` | `0x3064` | Thumb | `candidate_003064` | None | None | None | None |
| `0x3101` | `0x3100` | Thumb | `candidate_003100` | None | None | None | None |
| `0x3241` | `0x3240` | Thumb | `candidate_003240` | None | None | None | None |
| `0x3295` | `0x3294` | Thumb | `candidate_003294` | None | None | None | None |
| `0x32ed` | `0x32ec` | Thumb | `candidate_0032ec` | None | None | None | None |
| `0x3389` | `0x3388` | Thumb | `candidate_003388` | None | None | None | None |
| `0x3401` | `0x3400` | Thumb | `candidate_003400` | None | None | None | None |
