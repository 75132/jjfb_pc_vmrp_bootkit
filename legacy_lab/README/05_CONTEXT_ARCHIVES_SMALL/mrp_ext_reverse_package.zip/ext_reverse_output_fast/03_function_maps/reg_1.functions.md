# reg_1 function/candidate map

| addr | offset | mode | name | size | blocks | cc | returning |
|---:|---:|---|---|---:|---:|---:|---|
| `0x8` | `0x8` | ARM | `candidate_000008` | None | None | None | None |
| `0xb` | `0xa` | Thumb | `candidate_00000a` | None | None | None | None |
| `0x3d` | `0x3c` | Thumb | `candidate_00003c` | None | None | None | None |
| `0xc9` | `0xc8` | Thumb | `candidate_0000c8` | None | None | None | None |
| `0x11d` | `0x11c` | Thumb | `candidate_00011c` | None | None | None | None |
| `0x169` | `0x168` | Thumb | `candidate_000168` | None | None | None | None |
| `0x7a9` | `0x7a8` | Thumb | `candidate_0007a8` | None | None | None | None |
| `0x7c9` | `0x7c8` | Thumb | `candidate_0007c8` | None | None | None | None |
| `0x7f9` | `0x7f8` | Thumb | `candidate_0007f8` | None | None | None | None |
