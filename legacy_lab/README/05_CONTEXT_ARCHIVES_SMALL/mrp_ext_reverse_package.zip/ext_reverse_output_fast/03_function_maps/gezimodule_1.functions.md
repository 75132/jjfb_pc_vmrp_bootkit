# gezimodule_1 function/candidate map

| addr | offset | mode | name | size | blocks | cc | returning |
|---:|---:|---|---|---:|---:|---:|---|
| `0x8` | `0x8` | ARM | `candidate_000008` | None | None | None | None |
| `0xb` | `0xa` | Thumb | `candidate_00000a` | None | None | None | None |
| `0x3d` | `0x3c` | Thumb | `candidate_00003c` | None | None | None | None |
| `0x105` | `0x104` | Thumb | `candidate_000104` | None | None | None | None |
| `0x361` | `0x360` | Thumb | `candidate_000360` | None | None | None | None |
| `0x419` | `0x418` | Thumb | `candidate_000418` | None | None | None | None |
| `0x4f1` | `0x4f0` | Thumb | `candidate_0004f0` | None | None | None | None |
| `0x611` | `0x610` | Thumb | `candidate_000610` | None | None | None | None |
| `0xac1` | `0xac0` | Thumb | `candidate_000ac0` | None | None | None | None |
| `0xb61` | `0xb60` | Thumb | `candidate_000b60` | None | None | None | None |
| `0xc99` | `0xc98` | Thumb | `candidate_000c98` | None | None | None | None |
| `0xd6d` | `0xd6c` | Thumb | `candidate_000d6c` | None | None | None | None |
| `0xe61` | `0xe60` | Thumb | `candidate_000e60` | None | None | None | None |
| `0x10c9` | `0x10c8` | Thumb | `candidate_0010c8` | None | None | None | None |
| `0x1159` | `0x1158` | Thumb | `candidate_001158` | None | None | None | None |
| `0x1195` | `0x1194` | Thumb | `candidate_001194` | None | None | None | None |
| `0x11b9` | `0x11b8` | Thumb | `candidate_0011b8` | None | None | None | None |
| `0x11f9` | `0x11f8` | Thumb | `candidate_0011f8` | None | None | None | None |
| `0x125d` | `0x125c` | Thumb | `candidate_00125c` | None | None | None | None |
| `0x12f9` | `0x12f8` | Thumb | `candidate_0012f8` | None | None | None | None |
| `0x138d` | `0x138c` | Thumb | `candidate_00138c` | None | None | None | None |
| `0x14b9` | `0x14b8` | Thumb | `candidate_0014b8` | None | None | None | None |
| `0x14ef` | `0x14ee` | Thumb | `candidate_0014ee` | None | None | None | None |
| `0x15d1` | `0x15d0` | Thumb | `candidate_0015d0` | None | None | None | None |
| `0x166d` | `0x166c` | Thumb | `candidate_00166c` | None | None | None | None |
| `0x1821` | `0x1820` | Thumb | `candidate_001820` | None | None | None | None |
| `0x19e1` | `0x19e0` | Thumb | `candidate_0019e0` | None | None | None | None |
