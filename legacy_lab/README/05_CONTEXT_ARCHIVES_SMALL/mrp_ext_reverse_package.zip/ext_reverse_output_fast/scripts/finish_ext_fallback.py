#!/usr/bin/env python3
import os,gzip,re,json,pathlib,shutil
from capstone import *
ROOT=pathlib.Path('/mnt/data/ext_reverse_output_fast')
for d in ['01_uncompressed_ext','02_disassembly','03_function_maps','04_strings','05_pseudocode','06_reports','scripts']:(ROOT/d).mkdir(parents=True,exist_ok=True)
INPUTS=['/mnt/data/mainmenumodule(1).ext','/mnt/data/cfunction(1).ext','/mnt/data/itemhechengmodule.ext','/mnt/data/shopmodule.ext','/mnt/data/robotol.ext','/mnt/data/othermodule.ext','/mnt/data/lianmengmodule.ext','/mnt/data/reg(1).ext','/mnt/data/leitaimodule(1).ext','/mnt/data/monstermodule(1).ext','/mnt/data/betmodule(2).ext','/mnt/data/viewmanmodule(1).ext','/mnt/data/itembagshopmodule(1).ext','/mnt/data/monsterstatemodule(1).ext','/mnt/data/gameattackmodule(1).ext','/mnt/data/taobaomodule(1).ext','/mnt/data/gezimodule(1).ext','/mnt/data/chatmodule(1).ext','/mnt/data/moduletest(1).ext','/mnt/data/mailmodule(1).ext']
def safe(p): return pathlib.Path(p).name.replace('.ext','').replace('(','_').replace(')','').replace(' ','_')
def decomp(p):
 b=pathlib.Path(p).read_bytes(); gz=b[:2]==b'\x1f\x8b'; return b,(gzip.decompress(b) if gz else b),gz
def strings_ascii(d): return [{'off':m.start(),'len':len(m.group()),'text':m.group().decode('ascii','replace')} for m in re.finditer(rb'[\x20-\x7e]{4,}',d)]
def strings_c(d):
 out=[]; start=0
 for i,b in enumerate(d+b'\0'):
  if b==0:
   seg=d[start:i]
   if len(seg)>=4:
    try:
     s=seg.decode('gb18030')
     if len(s)<300 and (any('\u4e00'<=ch<='\u9fff' for ch in s) or any(x in s for x in ['Invalid','Divide','Overflow','Heap','signal'])): out.append({'off':start,'len':len(seg),'text':s})
    except: pass
   start=i+1
 return out

def starts(d):
 res=set([8])
 for off in range(8,len(d)-4,2):
  if d[off+1] in (0xb5,0xb4) or (d[off]==0x2d and d[off+1]==0xe9): res.add(off|1)
 return sorted(res,key=lambda x:x&~1)
mdt=Cs(CS_ARCH_ARM,CS_MODE_THUMB|CS_MODE_LITTLE_ENDIAN); mda=Cs(CS_ARCH_ARM,CS_MODE_ARM|CS_MODE_LITTLE_ENDIAN)
def write_asm(name,d,ss):
 with open(ROOT/'02_disassembly'/f'{name}.candidate_thumb.asm','w',encoding='utf-8') as f:
  f.write('; fallback candidate disassembly from Thumb prologues; true code is ARM entry + Thumb functions.\n')
  f.write('\n; ARM entry\n')
  for ins in mda.disasm(d[8:min(len(d),0x200)],8): f.write(f'{ins.address:#08x}:\t{ins.mnemonic:<8}\t{ins.op_str}\n')
  for s in ss[:3000]:
   off=s&~1; f.write(f'\n; ===== candidate_{off:06x} =====\n')
   n=0
   for ins in mdt.disasm(d[off:min(len(d),off+480)],off):
    f.write(f'{ins.address:#08x}:\t{ins.mnemonic:<8}\t{ins.op_str}\n'); n+=1
    if n>4 and ins.mnemonic in ('pop','bx') and ('pc' in ins.op_str or ins.op_str.strip()=='lr'): break
    if n>140: break
mods=[]
# Load existing manifest pieces if exist
for inp in INPUTS:
 if not pathlib.Path(inp).exists(): continue
 name=safe(inp); raw,d,gz=decomp(inp); (ROOT/'01_uncompressed_ext'/f'{name}.bin').write_bytes(d)
 # ensure strings
 a=strings_ascii(d); c=strings_c(d)
 (ROOT/'04_strings'/f'{name}.ascii_strings.json').write_text(json.dumps(a,ensure_ascii=False,indent=2),encoding='utf-8')
 (ROOT/'04_strings'/f'{name}.gb18030_cstrings.json').write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding='utf-8')
 fjson=ROOT/'03_function_maps'/f'{name}.functions.json'
 if fjson.exists():
  rows=json.loads(fjson.read_text(encoding='utf-8'))
 else:
  ss=starts(d); rows=[{'addr':hex(s),'offset':hex(s&~1),'mode':'Thumb' if s&1 else 'ARM','name':f'candidate_{s&~1:06x}','size':None,'blocks':None,'complexity':None,'returning':None} for s in ss]
  fjson.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
  with open(ROOT/'03_function_maps'/f'{name}.functions.md','w',encoding='utf-8') as f:
   f.write(f'# {name} function/candidate map\n\n| addr | offset | mode | name | size | blocks | cc | returning |\n|---:|---:|---|---|---:|---:|---:|---|\n')
   for r in rows: f.write(f"| `{r['addr']}` | `{r['offset']}` | {r['mode']} | `{r['name']}` | {r.get('size')} | {r.get('blocks')} | {r.get('complexity')} | {r.get('returning')} |\n")
  write_asm(name,d,ss)
 mods.append({'name':name,'raw_size':len(raw),'unpacked_size':len(d),'gzip':gz,'header':d[:8].decode('latin1','replace'),'functions':len(rows),'ascii_strings':len(a),'gb18030_cstrings':len(c),'analysis':'angr-cfg' if 'size' in rows[0] and rows[0].get('size') is not None else 'prologue-scan'})
 print(name,len(rows),mods[-1]['analysis'])
(ROOT/'manifest.json').write_text(json.dumps(mods,ensure_ascii=False,indent=2),encoding='utf-8')
lines=['# MRP EXT reverse package summary','', '这些 `.ext` 解包后都是 `MRPGCMAP` ARM/Thumb 裸二进制，不是普通数据表。多数模块是 ARM 入口壳 + Thumb 业务代码。','', '| module | unpacked | gzip | funcs/candidates | analysis | ascii | gb18030-cstr |','|---|---:|---|---:|---|---:|---:|']
for m in mods: lines.append(f"| `{m['name']}` | {m['unpacked_size']} | {m['gzip']} | {m['functions']} | {m['analysis']} | {m['ascii_strings']} | {m['gb18030_cstrings']} |")
lines.append('''\n## 目录\n- `01_uncompressed_ext/`：解压后的 MRPGCMAP 二进制。\n- `02_disassembly/`：函数块或候选函数反汇编。`addr` 低位为 1 表示 Thumb 函数，真实文件偏移是 `addr & ~1`。\n- `03_function_maps/`：函数/候选函数表。\n- `04_strings/`：字符串候选。\n- `05_pseudocode/`：精选函数伪 C。\n- `06_reports/`：运行逻辑报告。\n\n说明：`analysis=angr-cfg` 的模块函数边界更可靠；`prologue-scan` 是按 Thumb 函数序言扫描，适合快速覆盖全量模块，但需要结合反汇编人工确认。\n''')
(ROOT/'README.md').write_text('\n'.join(lines),encoding='utf-8')
logic='''# EXT 运行逻辑恢复报告\n\n## 1. 格式结论\n\n这批文件大多是 GZIP 压缩的 MRP EXT；解压后固定以 `MRPGCMAP` 开头。`cfunction(1).ext` 本身未 gzip，但同样是 `MRPGCMAP`。\n\n典型入口：\n\n```asm\n0x08  push {r4, lr}          ; ARM entry stub\n0x0c  mov  r4, r0\n0x10  mov  r0, r4\n0x14  blx  #thumb_init       ; 跳入 Thumb 初始化/业务入口\n0x18  pop  {r4, pc}\n```\n\n所以它不是“解包后直接读文本”的数据文件，而是 ARM/Thumb 混合裸二进制。\n\n## 2. 模块逻辑分工\n\n- `robotol`：主模块，负责游戏主循环、事件、地图、存档/全局状态和功能模块调度。\n- `gameattackmodule_1`：战斗核心，优先看这里恢复伤害、命中、状态、回合流程。\n- `monstermodule_1`：怪物实例和怪物属性读取。\n- `monsterstatemodule_1`：怪物状态、BUFF/DEBUFF、状态生效/结束。\n- `itemhechengmodule`：道具合成，重点看材料判断、扣除、生成物品、失败分支。\n- `shopmodule` / `itembagshopmodule_1`：商品购买、出售、金币/背包容量判断。\n- `betmodule_2`：下注/赌博/概率奖励逻辑。\n- `lianmengmodule` / `leitaimodule_1`：联盟、擂台玩法。\n- `mailmodule_1` / `chatmodule_1`：邮件和聊天逻辑。\n- `cfunction_1`：大型公共 C 函数/桥接库，更多像运行库和宿主接口包装层。\n\n## 3. 关键 API 调用模型\n\n在已恢复的伪 C 和反汇编中，常见一种多参数分发调用：\n\n```c\nengine_call(0x1e200, opcode, arg1, arg2, arg3, arg4, arg5);\n```\n\n在 angr 伪 C 中它通常表现为 `sub_2abd(0x1e200, opcode, ...)` 或类似地址名。这个函数很可能是 MRP 宿主/游戏引擎 API 分发器。下一步要把 opcode 命名：\n\n- 物品/怪物字段读取\n- 物品/怪物字段写入\n- UI 绘制/文字显示\n- 背包/金币读写\n- 存档变量读写\n- 网络/邮件/聊天接口\n\n## 4. 到源码的现实边界\n\n这些 EXT 是 stripped 裸二进制，不包含作者原始变量名、结构体名、注释和源码路径。能恢复的是“等价伪 C + 精确汇编”，不能 100% 还原作者原始 C 文件。\n\n本包已提供：\n\n- 解压二进制；\n- 函数/候选函数表；\n- ARM/Thumb 反汇编；\n- 字符串候选；\n- 部分模块的 CFG 函数边界。\n\n要继续推进，建议优先对 `gameattackmodule_1.functions.asm` 和 `gameattackmodule_1.functions.md` 中大函数逐个命名，再反推 opcode 表。\n'''
(ROOT/'06_reports'/'logic_report.md').write_text(logic,encoding='utf-8')
shutil.copy2(__file__, ROOT/'scripts'/'finish_ext_fallback.py')
print('DONE')
