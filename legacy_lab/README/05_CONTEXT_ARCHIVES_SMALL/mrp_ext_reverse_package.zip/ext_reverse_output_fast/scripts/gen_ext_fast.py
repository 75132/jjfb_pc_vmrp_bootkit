#!/usr/bin/env python3
import os, gzip, re, json, pathlib, traceback, shutil
from capstone import *
from capstone.arm import *
ROOT=pathlib.Path('/mnt/data/ext_reverse_output_fast')
for d in ['01_uncompressed_ext','02_disassembly','03_function_maps','04_strings','05_pseudocode','06_reports','scripts']:
    (ROOT/d).mkdir(parents=True,exist_ok=True)
INPUTS=['/mnt/data/mainmenumodule(1).ext','/mnt/data/cfunction(1).ext','/mnt/data/itemhechengmodule.ext','/mnt/data/shopmodule.ext','/mnt/data/robotol.ext','/mnt/data/othermodule.ext','/mnt/data/lianmengmodule.ext','/mnt/data/reg(1).ext','/mnt/data/leitaimodule(1).ext','/mnt/data/monstermodule(1).ext','/mnt/data/betmodule(2).ext','/mnt/data/viewmanmodule(1).ext','/mnt/data/itembagshopmodule(1).ext','/mnt/data/monsterstatemodule(1).ext','/mnt/data/gameattackmodule(1).ext','/mnt/data/taobaomodule(1).ext','/mnt/data/gezimodule(1).ext','/mnt/data/chatmodule(1).ext','/mnt/data/moduletest(1).ext','/mnt/data/mailmodule(1).ext']

def safe(p): return pathlib.Path(p).name.replace('.ext','').replace('(','_').replace(')','').replace(' ','_')

def decomp(p):
    b=pathlib.Path(p).read_bytes(); gz=b[:2]==b'\x1f\x8b'; d=gzip.decompress(b) if gz else b; return b,d,gz

def strings_ascii(d):
    return [{'off':m.start(),'len':len(m.group()),'text':m.group().decode('ascii','replace')} for m in re.finditer(rb'[\x20-\x7e]{4,}',d)]

def strings_c(d):
    out=[]; start=0
    for i,b in enumerate(d+b'\0'):
        if b==0:
            seg=d[start:i]
            if len(seg)>=4:
                try:
                    s=seg.decode('gb18030')
                    if len(s)<300 and (any('\u4e00'<=ch<='\u9fff' for ch in s) or any(x in s for x in ['Invalid','Divide','Overflow','Heap','signal'])):
                        out.append({'off':start,'len':len(seg),'text':s})
                except: pass
            start=i+1
    return out

def quick_starts(d):
    starts=set([8])
    for off in range(8,len(d)-4,2):
        if d[off+1] in (0xb5,0xb4) or (d[off]==0x2d and d[off+1]==0xe9): starts.add(off|1)
    return sorted(starts,key=lambda x:x&~1)
mdt=Cs(CS_ARCH_ARM,CS_MODE_THUMB|CS_MODE_LITTLE_ENDIAN); mdt.detail=False
mda=Cs(CS_ARCH_ARM,CS_MODE_ARM|CS_MODE_LITTLE_ENDIAN); mda.detail=False

def fallback_asm(name,d,starts):
    with open(ROOT/'02_disassembly'/f'{name}.candidate_thumb.asm','w',encoding='utf-8') as f:
        f.write('; candidate Thumb disassembly. Low bit in address means Thumb entry.\n')
        # ARM entry first
        f.write('\n; ARM entry\n')
        for ins in mda.disasm(d[8:min(len(d),0x80)],8): f.write(f'{ins.address:#08x}:\t{ins.mnemonic:<8}\t{ins.op_str}\n')
        for s in starts[:5000]:
            off=s&~1; f.write(f'\n; function_candidate_{off:06x}\n')
            n=0
            for ins in mdt.disasm(d[off:min(len(d),off+512)],off):
                f.write(f'{ins.address:#08x}:\t{ins.mnemonic:<8}\t{ins.op_str}\n'); n+=1
                if n>4 and ins.mnemonic in ('pop','bx') and ('pc' in ins.op_str or ins.op_str.strip()=='lr'): break
                if n>160: break

def angr_cfg_file(binpath,name,d):
    import angr, logging
    logging.getLogger('angr').setLevel(logging.CRITICAL)
    p=angr.Project(str(binpath), main_opts={'backend':'blob','arch':'ARMEL','base_addr':0,'entry_point':8}, auto_load_libs=False)
    cfg=p.analyses.CFGFast(normalize=True, data_references=False, force_complete_scan=False, function_starts=[8])
    funcs=sorted(cfg.kb.functions.values(), key=lambda f:f.addr)
    rows=[]
    with open(ROOT/'02_disassembly'/f'{name}.functions.asm','w',encoding='utf-8') as f:
        f.write('; function-oriented angr/capstone disassembly\n')
        for fn in funcs:
            rows.append({'addr':hex(fn.addr),'offset':hex(fn.addr&~1),'mode':'Thumb' if fn.addr&1 else 'ARM','name':fn.name,'size':getattr(fn,'size',None),'blocks':len(fn.block_addrs_set),'complexity':getattr(fn,'cyclomatic_complexity',None),'returning':getattr(fn,'returning',None)})
            f.write(f"\n; ===== {fn.name} @ {fn.addr:#x} offset={fn.addr&~1:#x} size={getattr(fn,'size',0)} blocks={len(fn.block_addrs_set)} cc={getattr(fn,'cyclomatic_complexity',None)} =====\n")
            for baddr in sorted(fn.block_addrs_set):
                try:
                    block=p.factory.block(baddr)
                    f.write(f'; block {baddr:#x}\n')
                    for ci in block.capstone.insns:
                        ins=ci.insn; f.write(f'{ins.address:#08x}:\t{ins.mnemonic:<8}\t{ins.op_str}\n')
                except Exception as e:
                    f.write(f'; block disasm failed {baddr:#x}: {e!r}\n')
    return rows

mods=[]
for inp in INPUTS:
    if not pathlib.Path(inp).exists(): continue
    name=safe(inp); raw,d,gz=decomp(inp); binpath=ROOT/'01_uncompressed_ext'/f'{name}.bin'; binpath.write_bytes(d)
    a=strings_ascii(d); c=strings_c(d)
    (ROOT/'04_strings'/f'{name}.ascii_strings.json').write_text(json.dumps(a,ensure_ascii=False,indent=2),encoding='utf-8')
    (ROOT/'04_strings'/f'{name}.gb18030_cstrings.json').write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding='utf-8')
    starts=quick_starts(d); err=None
    if name!='cfunction_1':
        try: rows=angr_cfg_file(binpath,name,d)
        except Exception: err=traceback.format_exc(); rows=[]; fallback_asm(name,d,starts)
    else:
        rows=[]; fallback_asm(name,d,starts)
    if not rows:
        rows=[{'addr':hex(s),'offset':hex(s&~1),'mode':'Thumb' if s&1 else 'ARM','name':f'candidate_{s&~1:06x}','size':None,'blocks':None,'complexity':None,'returning':None} for s in starts]
    (ROOT/'03_function_maps'/f'{name}.functions.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    with open(ROOT/'03_function_maps'/f'{name}.functions.md','w',encoding='utf-8') as f:
        f.write(f'# {name} function map\n\n| addr | offset | mode | name | size | blocks | cc | returning |\n|---:|---:|---|---|---:|---:|---:|---|\n')
        for r in rows: f.write(f"| `{r['addr']}` | `{r['offset']}` | {r['mode']} | `{r['name']}` | {r.get('size')} | {r.get('blocks')} | {r.get('complexity')} | {r.get('returning')} |\n")
    mods.append({'name':name,'raw_size':len(raw),'unpacked_size':len(d),'gzip':gz,'header':d[:8].decode('latin1','replace'),'functions':len(rows),'ascii_strings':len(a),'gb18030_cstrings':len(c),'cfg_error':err})
    print(name, len(rows))
(ROOT/'manifest.json').write_text(json.dumps(mods,ensure_ascii=False,indent=2),encoding='utf-8')
# Reports
lines=['# MRP EXT reverse package summary','', '这些 `.ext` 解包后都是 `MRPGCMAP` ARM/Thumb 裸二进制，不是普通数据表。多数模块是 ARM 入口壳 + Thumb 业务代码。','', '| module | unpacked | gzip | funcs/candidates | ascii | gb18030-cstr |','|---|---:|---|---:|---:|---:|']
for m in mods: lines.append(f"| `{m['name']}` | {m['unpacked_size']} | {m['gzip']} | {m['functions']} | {m['ascii_strings']} | {m['gb18030_cstrings']} |")
lines.append('''\n## 目录\n- `01_uncompressed_ext/`：解压后的 MRPGCMAP 二进制。\n- `02_disassembly/`：函数块反汇编。`addr` 低位为 1 表示 Thumb 函数，真实文件偏移是 `addr & ~1`。\n- `03_function_maps/`：函数/候选函数表。\n- `04_strings/`：字符串候选。\n- `05_pseudocode/`：后续精选函数伪 C。\n- `06_reports/`：运行逻辑报告。\n''')
(ROOT/'README.md').write_text('\n'.join(lines),encoding='utf-8')
logic='''# 运行逻辑恢复说明\n\n## 文件形态\n\n所有功能模块基本结构为：\n\n```asm\n0x08  push {r4, lr}          ; ARM entry stub\n0x0c  mov  r4, r0\n0x10  mov  r0, r4\n0x14  blx  #thumb_init       ; 跳入 Thumb 初始化/业务入口\n0x18  pop  {r4, pc}\n```\n\n所以分析时必须 ARM + Thumb 混合模式。只用 ARM 模式会把 Thumb 业务逻辑读成乱码。\n\n## 模块作用\n\n- `robotol`：主控、地图、事件、全局状态、模块调度。\n- `gameattackmodule_1`：战斗结算、伤害/状态/回合流程。\n- `monstermodule_1`：怪物属性和怪物实例逻辑。\n- `monsterstatemodule_1`：怪物状态、BUFF/DEBUFF。\n- `itemhechengmodule`：道具合成。\n- `shopmodule` / `itembagshopmodule_1`：商店/背包购买出售。\n- `betmodule_2`：赌博/下注/概率玩法。\n- `cfunction_1`：大型公共 C 函数/桥接运行库。\n\n## 关键逆向线索\n\n伪 C 和反汇编中反复出现类似：\n\n```c\nsub_xxxx(0x1e200, opcode, arg1, arg2, arg3, arg4, arg5);\n```\n\n这通常是游戏引擎/宿主 API 调用分发器。真正恢复源码时，应继续把 `opcode` 命名成语义函数，例如 `GET_FIELD`、`SET_FIELD`、`DRAW_TEXT`、`GET_ITEM`、`SET_MONEY` 等。\n\n## 数据边界\n\n这些 EXT 内部几乎没有完整中文业务文本；完整怪物、道具、地图表仍来自外部 `.mrp` 数据。EXT 保存的是运行逻辑，例如如何计算、判断、扣除、写入。\n'''
(ROOT/'06_reports'/'logic_report.md').write_text(logic,encoding='utf-8')
shutil.copy2(__file__, ROOT/'scripts'/'gen_ext_fast.py')
print('DONE', ROOT)
