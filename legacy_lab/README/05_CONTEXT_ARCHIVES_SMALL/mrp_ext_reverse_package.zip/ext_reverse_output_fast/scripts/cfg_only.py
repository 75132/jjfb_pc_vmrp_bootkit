import sys, pathlib, json, os, logging
import angr
logging.getLogger('angr').setLevel(logging.CRITICAL)
ROOT=pathlib.Path('/mnt/data/ext_reverse_output_fast')
name=sys.argv[1]
binpath=ROOT/'01_uncompressed_ext'/f'{name}.bin'
p=angr.Project(str(binpath), main_opts={'backend':'blob','arch':'ARMEL','base_addr':0,'entry_point':8}, auto_load_libs=False)
cfg=p.analyses.CFGFast(normalize=True, data_references=False, force_complete_scan=False, function_starts=[8])
rows=[]
for f in sorted(cfg.kb.functions.values(), key=lambda f:f.addr):
 rows.append({'addr':hex(f.addr),'offset':hex(f.addr&~1),'mode':'Thumb' if f.addr&1 else 'ARM','name':f.name,'size':getattr(f,'size',None),'blocks':len(f.block_addrs_set),'complexity':getattr(f,'cyclomatic_complexity',None),'returning':getattr(f,'returning',None)})
(ROOT/'03_function_maps'/f'{name}.functions.angr.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
with open(ROOT/'03_function_maps'/f'{name}.functions.angr.md','w',encoding='utf-8') as fp:
 fp.write(f'# {name} angr function map\n\n| addr | offset | mode | name | size | blocks | cc | returning |\n|---:|---:|---|---|---:|---:|---:|---|\n')
 for r in rows: fp.write(f"| `{r['addr']}` | `{r['offset']}` | {r['mode']} | `{r['name']}` | {r.get('size')} | {r.get('blocks')} | {r.get('complexity')} | {r.get('returning')} |\n")
print(json.dumps({'name':name,'funcs':len(rows)},ensure_ascii=False), flush=True)
os._exit(0)
