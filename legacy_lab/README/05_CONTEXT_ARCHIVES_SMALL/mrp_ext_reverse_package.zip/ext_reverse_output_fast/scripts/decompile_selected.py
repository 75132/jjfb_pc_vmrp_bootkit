#!/usr/bin/env python3
import sys, pathlib, json, signal, traceback, os, logging
import angr
logging.getLogger('angr').setLevel(logging.CRITICAL)
ROOT=pathlib.Path('/mnt/data/ext_reverse_output_fast')

def timeout_handler(signum, frame):
    raise TimeoutError('decompile timeout')
signal.signal(signal.SIGALRM, timeout_handler)

def run(name, quota=30, per_func=12, update_map=True):
    binpath=ROOT/'01_uncompressed_ext'/f'{name}.bin'
    proj=angr.Project(str(binpath), main_opts={'backend':'blob','arch':'ARMEL','base_addr':0,'entry_point':8}, auto_load_libs=False)
    cfg=proj.analyses.CFGFast(normalize=True, data_references=False, force_complete_scan=False, function_starts=[8])
    funcs=sorted(cfg.kb.functions.values(), key=lambda f:f.addr)
    if update_map:
        rows=[]
        for f in funcs:
            rows.append({'addr':hex(f.addr),'offset':hex(f.addr&~1),'mode':'Thumb' if f.addr&1 else 'ARM','name':f.name,'size':getattr(f,'size',None),'blocks':len(f.block_addrs_set),'complexity':getattr(f,'cyclomatic_complexity',None),'returning':getattr(f,'returning',None)})
        (ROOT/'03_function_maps'/f'{name}.functions.angr.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
        with open(ROOT/'03_function_maps'/f'{name}.functions.angr.md','w',encoding='utf-8') as f:
            f.write(f'# {name} angr function map\n\n| addr | offset | mode | name | size | blocks | cc | returning |\n|---:|---:|---|---|---:|---:|---:|---|\n')
            for r in rows:
                f.write(f"| `{r['addr']}` | `{r['offset']}` | {r['mode']} | `{r['name']}` | {r.get('size')} | {r.get('blocks')} | {r.get('complexity')} | {r.get('returning')} |\n")
    # selected: entry + largest business funcs + high complexity
    selected=[]; seen=set()
    for f in funcs:
        if f.addr==8:
            selected.append(f); seen.add(f.addr); break
    for f in sorted(funcs,key=lambda x:(getattr(x,'size',0) or 0),reverse=True):
        if (f.addr&~1)>=0x300 and f.addr not in seen:
            selected.append(f); seen.add(f.addr)
        if len(selected)>=quota//2: break
    for f in sorted(funcs,key=lambda x:(getattr(x,'cyclomatic_complexity',0) or 0),reverse=True):
        if (f.addr&~1)>=0x300 and f.addr not in seen:
            selected.append(f); seen.add(f.addr)
        if len(selected)>=quota: break
    records=[]
    with open(ROOT/'05_pseudocode'/f'{name}.selected_pseudo.c','w',encoding='utf-8') as out:
        out.write(f'/* Selected recovered pseudo-C for {name}. Not original source. */\n\n')
        for f in selected:
            rec={'addr':hex(f.addr),'name':f.name,'size':getattr(f,'size',None),'cc':getattr(f,'cyclomatic_complexity',None),'ok':False}
            out.write(f"\n/* ===== {f.name} @ {f.addr:#x}, size={getattr(f,'size',None)}, cc={getattr(f,'cyclomatic_complexity',None)} ===== */\n")
            try:
                signal.alarm(per_func)
                dec=proj.analyses.Decompiler(f, cfg=cfg.model)
                signal.alarm(0)
                text=str(dec.codegen.text)
                out.write(text+'\n')
                rec['ok']=True; rec['chars']=len(text)
            except Exception as e:
                signal.alarm(0)
                rec['error']=repr(e)
                out.write(f'/* decompile failed: {e!r}; see disassembly/function map. */\n')
            records.append(rec)
    (ROOT/'05_pseudocode'/f'{name}.selected_pseudo.index.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'name':name,'funcs':len(funcs),'selected':len(selected),'ok':sum(r['ok'] for r in records)},ensure_ascii=False))

if __name__=='__main__':
    run(sys.argv[1], int(sys.argv[2]) if len(sys.argv)>2 else 30, int(sys.argv[3]) if len(sys.argv)>3 else 12)
