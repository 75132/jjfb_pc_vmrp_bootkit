/* Skeleton recovered from function map for othermodule. Fill bodies from 02_disassembly. */
typedef int i32;

// addr=0x8, offset=0x8, mode=ARM, size=None, cc=None
i32 candidate_000008(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb, offset=0xa, mode=Thumb, size=None, cc=None
i32 candidate_00000a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11b, offset=0x11a, mode=Thumb, size=None, cc=None
i32 candidate_00011a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x135, offset=0x134, mode=Thumb, size=None, cc=None
i32 candidate_000134(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x195, offset=0x194, mode=Thumb, size=None, cc=None
i32 candidate_000194(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b5, offset=0x2b4, mode=Thumb, size=None, cc=None
i32 candidate_0002b4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x329, offset=0x328, mode=Thumb, size=None, cc=None
i32 candidate_000328(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3f1, offset=0x3f0, mode=Thumb, size=None, cc=None
i32 candidate_0003f0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x445, offset=0x444, mode=Thumb, size=None, cc=None
i32 candidate_000444(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4fd, offset=0x4fc, mode=Thumb, size=None, cc=None
i32 candidate_0004fc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5cd, offset=0x5cc, mode=Thumb, size=None, cc=None
i32 candidate_0005cc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6c5, offset=0x6c4, mode=Thumb, size=None, cc=None
i32 candidate_0006c4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x725, offset=0x724, mode=Thumb, size=None, cc=None
i32 candidate_000724(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x87d, offset=0x87c, mode=Thumb, size=None, cc=None
i32 candidate_00087c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9b5, offset=0x9b4, mode=Thumb, size=None, cc=None
i32 candidate_0009b4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb55, offset=0xb54, mode=Thumb, size=None, cc=None
i32 candidate_000b54(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xca9, offset=0xca8, mode=Thumb, size=None, cc=None
i32 candidate_000ca8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf15, offset=0xf14, mode=Thumb, size=None, cc=None
i32 candidate_000f14(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xff5, offset=0xff4, mode=Thumb, size=None, cc=None
i32 candidate_000ff4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1085, offset=0x1084, mode=Thumb, size=None, cc=None
i32 candidate_001084(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11f9, offset=0x11f8, mode=Thumb, size=None, cc=None
i32 candidate_0011f8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x12e1, offset=0x12e0, mode=Thumb, size=None, cc=None
i32 candidate_0012e0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15d1, offset=0x15d0, mode=Thumb, size=None, cc=None
i32 candidate_0015d0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x169d, offset=0x169c, mode=Thumb, size=None, cc=None
i32 candidate_00169c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17cd, offset=0x17cc, mode=Thumb, size=None, cc=None
i32 candidate_0017cc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1899, offset=0x1898, mode=Thumb, size=None, cc=None
i32 candidate_001898(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2291, offset=0x2290, mode=Thumb, size=None, cc=None
i32 candidate_002290(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23f1, offset=0x23f0, mode=Thumb, size=None, cc=None
i32 candidate_0023f0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24e5, offset=0x24e4, mode=Thumb, size=None, cc=None
i32 candidate_0024e4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2855, offset=0x2854, mode=Thumb, size=None, cc=None
i32 candidate_002854(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c89, offset=0x2c88, mode=Thumb, size=None, cc=None
i32 candidate_002c88(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2eed, offset=0x2eec, mode=Thumb, size=None, cc=None
i32 candidate_002eec(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fa9, offset=0x2fa8, mode=Thumb, size=None, cc=None
i32 candidate_002fa8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3691, offset=0x3690, mode=Thumb, size=None, cc=None
i32 candidate_003690(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x402d, offset=0x402c, mode=Thumb, size=None, cc=None
i32 candidate_00402c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4481, offset=0x4480, mode=Thumb, size=None, cc=None
i32 candidate_004480(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x46b9, offset=0x46b8, mode=Thumb, size=None, cc=None
i32 candidate_0046b8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47a5, offset=0x47a4, mode=Thumb, size=None, cc=None
i32 candidate_0047a4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5041, offset=0x5040, mode=Thumb, size=None, cc=None
i32 candidate_005040(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5335, offset=0x5334, mode=Thumb, size=None, cc=None
i32 candidate_005334(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x55cd, offset=0x55cc, mode=Thumb, size=None, cc=None
i32 candidate_0055cc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x56ed, offset=0x56ec, mode=Thumb, size=None, cc=None
i32 candidate_0056ec(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5b21, offset=0x5b20, mode=Thumb, size=None, cc=None
i32 candidate_005b20(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x65ad, offset=0x65ac, mode=Thumb, size=None, cc=None
i32 candidate_0065ac(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6625, offset=0x6624, mode=Thumb, size=None, cc=None
i32 candidate_006624(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6811, offset=0x6810, mode=Thumb, size=None, cc=None
i32 candidate_006810(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6a61, offset=0x6a60, mode=Thumb, size=None, cc=None
i32 candidate_006a60(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6ae5, offset=0x6ae4, mode=Thumb, size=None, cc=None
i32 candidate_006ae4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6e69, offset=0x6e68, mode=Thumb, size=None, cc=None
i32 candidate_006e68(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6ec9, offset=0x6ec8, mode=Thumb, size=None, cc=None
i32 candidate_006ec8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7105, offset=0x7104, mode=Thumb, size=None, cc=None
i32 candidate_007104(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7175, offset=0x7174, mode=Thumb, size=None, cc=None
i32 candidate_007174(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x71d5, offset=0x71d4, mode=Thumb, size=None, cc=None
i32 candidate_0071d4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7355, offset=0x7354, mode=Thumb, size=None, cc=None
i32 candidate_007354(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x73e5, offset=0x73e4, mode=Thumb, size=None, cc=None
i32 candidate_0073e4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7463, offset=0x7462, mode=Thumb, size=None, cc=None
i32 candidate_007462(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x74b1, offset=0x74b0, mode=Thumb, size=None, cc=None
i32 candidate_0074b0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7525, offset=0x7524, mode=Thumb, size=None, cc=None
i32 candidate_007524(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x756f, offset=0x756e, mode=Thumb, size=None, cc=None
i32 candidate_00756e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x75ad, offset=0x75ac, mode=Thumb, size=None, cc=None
i32 candidate_0075ac(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x760d, offset=0x760c, mode=Thumb, size=None, cc=None
i32 candidate_00760c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x76c5, offset=0x76c4, mode=Thumb, size=None, cc=None
i32 candidate_0076c4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7b95, offset=0x7b94, mode=Thumb, size=None, cc=None
i32 candidate_007b94(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7c8d, offset=0x7c8c, mode=Thumb, size=None, cc=None
i32 candidate_007c8c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7d25, offset=0x7d24, mode=Thumb, size=None, cc=None
i32 candidate_007d24(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7de5, offset=0x7de4, mode=Thumb, size=None, cc=None
i32 candidate_007de4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7f79, offset=0x7f78, mode=Thumb, size=None, cc=None
i32 candidate_007f78(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8095, offset=0x8094, mode=Thumb, size=None, cc=None
i32 candidate_008094(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8145, offset=0x8144, mode=Thumb, size=None, cc=None
i32 candidate_008144(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8309, offset=0x8308, mode=Thumb, size=None, cc=None
i32 candidate_008308(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8529, offset=0x8528, mode=Thumb, size=None, cc=None
i32 candidate_008528(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x868d, offset=0x868c, mode=Thumb, size=None, cc=None
i32 candidate_00868c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8781, offset=0x8780, mode=Thumb, size=None, cc=None
i32 candidate_008780(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x88d5, offset=0x88d4, mode=Thumb, size=None, cc=None
i32 candidate_0088d4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8bdd, offset=0x8bdc, mode=Thumb, size=None, cc=None
i32 candidate_008bdc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x904d, offset=0x904c, mode=Thumb, size=None, cc=None
i32 candidate_00904c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x90d5, offset=0x90d4, mode=Thumb, size=None, cc=None
i32 candidate_0090d4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9125, offset=0x9124, mode=Thumb, size=None, cc=None
i32 candidate_009124(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9161, offset=0x9160, mode=Thumb, size=None, cc=None
i32 candidate_009160(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9185, offset=0x9184, mode=Thumb, size=None, cc=None
i32 candidate_009184(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x91c5, offset=0x91c4, mode=Thumb, size=None, cc=None
i32 candidate_0091c4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9229, offset=0x9228, mode=Thumb, size=None, cc=None
i32 candidate_009228(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x92c5, offset=0x92c4, mode=Thumb, size=None, cc=None
i32 candidate_0092c4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9359, offset=0x9358, mode=Thumb, size=None, cc=None
i32 candidate_009358(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9485, offset=0x9484, mode=Thumb, size=None, cc=None
i32 candidate_009484(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x94bb, offset=0x94ba, mode=Thumb, size=None, cc=None
i32 candidate_0094ba(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x959d, offset=0x959c, mode=Thumb, size=None, cc=None
i32 candidate_00959c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9995, offset=0x9994, mode=Thumb, size=None, cc=None
i32 candidate_009994(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9b2d, offset=0x9b2c, mode=Thumb, size=None, cc=None
i32 candidate_009b2c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c85, offset=0x9c84, mode=Thumb, size=None, cc=None
i32 candidate_009c84(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d75, offset=0x9d74, mode=Thumb, size=None, cc=None
i32 candidate_009d74(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9ddd, offset=0x9ddc, mode=Thumb, size=None, cc=None
i32 candidate_009ddc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9e89, offset=0x9e88, mode=Thumb, size=None, cc=None
i32 candidate_009e88(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9f25, offset=0x9f24, mode=Thumb, size=None, cc=None
i32 candidate_009f24(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9fe9, offset=0x9fe8, mode=Thumb, size=None, cc=None
i32 candidate_009fe8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa031, offset=0xa030, mode=Thumb, size=None, cc=None
i32 candidate_00a030(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa131, offset=0xa130, mode=Thumb, size=None, cc=None
i32 candidate_00a130(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa1c9, offset=0xa1c8, mode=Thumb, size=None, cc=None
i32 candidate_00a1c8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa2e9, offset=0xa2e8, mode=Thumb, size=None, cc=None
i32 candidate_00a2e8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa329, offset=0xa328, mode=Thumb, size=None, cc=None
i32 candidate_00a328(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa3e9, offset=0xa3e8, mode=Thumb, size=None, cc=None
i32 candidate_00a3e8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa45d, offset=0xa45c, mode=Thumb, size=None, cc=None
i32 candidate_00a45c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa531, offset=0xa530, mode=Thumb, size=None, cc=None
i32 candidate_00a530(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa5e9, offset=0xa5e8, mode=Thumb, size=None, cc=None
i32 candidate_00a5e8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa6b9, offset=0xa6b8, mode=Thumb, size=None, cc=None
i32 candidate_00a6b8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa7a1, offset=0xa7a0, mode=Thumb, size=None, cc=None
i32 candidate_00a7a0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa8e1, offset=0xa8e0, mode=Thumb, size=None, cc=None
i32 candidate_00a8e0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa919, offset=0xa918, mode=Thumb, size=None, cc=None
i32 candidate_00a918(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xad3b, offset=0xad3a, mode=Thumb, size=None, cc=None
i32 candidate_00ad3a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xada7, offset=0xada6, mode=Thumb, size=None, cc=None
i32 candidate_00ada6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xadbf, offset=0xadbe, mode=Thumb, size=None, cc=None
i32 candidate_00adbe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xadcb, offset=0xadca, mode=Thumb, size=None, cc=None
i32 candidate_00adca(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xadd3, offset=0xadd2, mode=Thumb, size=None, cc=None
i32 candidate_00add2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xadf3, offset=0xadf2, mode=Thumb, size=None, cc=None
i32 candidate_00adf2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xadfb, offset=0xadfa, mode=Thumb, size=None, cc=None
i32 candidate_00adfa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xadff, offset=0xadfe, mode=Thumb, size=None, cc=None
i32 candidate_00adfe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae1f, offset=0xae1e, mode=Thumb, size=None, cc=None
i32 candidate_00ae1e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae29, offset=0xae28, mode=Thumb, size=None, cc=None
i32 candidate_00ae28(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae33, offset=0xae32, mode=Thumb, size=None, cc=None
i32 candidate_00ae32(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae45, offset=0xae44, mode=Thumb, size=None, cc=None
i32 candidate_00ae44(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae51, offset=0xae50, mode=Thumb, size=None, cc=None
i32 candidate_00ae50(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae55, offset=0xae54, mode=Thumb, size=None, cc=None
i32 candidate_00ae54(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae57, offset=0xae56, mode=Thumb, size=None, cc=None
i32 candidate_00ae56(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae5b, offset=0xae5a, mode=Thumb, size=None, cc=None
i32 candidate_00ae5a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae5d, offset=0xae5c, mode=Thumb, size=None, cc=None
i32 candidate_00ae5c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae6b, offset=0xae6a, mode=Thumb, size=None, cc=None
i32 candidate_00ae6a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae85, offset=0xae84, mode=Thumb, size=None, cc=None
i32 candidate_00ae84(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae89, offset=0xae88, mode=Thumb, size=None, cc=None
i32 candidate_00ae88(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae8b, offset=0xae8a, mode=Thumb, size=None, cc=None
i32 candidate_00ae8a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae9d, offset=0xae9c, mode=Thumb, size=None, cc=None
i32 candidate_00ae9c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae9f, offset=0xae9e, mode=Thumb, size=None, cc=None
i32 candidate_00ae9e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaea5, offset=0xaea4, mode=Thumb, size=None, cc=None
i32 candidate_00aea4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaecb, offset=0xaeca, mode=Thumb, size=None, cc=None
i32 candidate_00aeca(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaed5, offset=0xaed4, mode=Thumb, size=None, cc=None
i32 candidate_00aed4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaef1, offset=0xaef0, mode=Thumb, size=None, cc=None
i32 candidate_00aef0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaf41, offset=0xaf40, mode=Thumb, size=None, cc=None
i32 candidate_00af40(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb0cf, offset=0xb0ce, mode=Thumb, size=None, cc=None
i32 candidate_00b0ce(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb1cf, offset=0xb1ce, mode=Thumb, size=None, cc=None
i32 candidate_00b1ce(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb1df, offset=0xb1de, mode=Thumb, size=None, cc=None
i32 candidate_00b1de(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb1ef, offset=0xb1ee, mode=Thumb, size=None, cc=None
i32 candidate_00b1ee(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb1fb, offset=0xb1fa, mode=Thumb, size=None, cc=None
i32 candidate_00b1fa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb21b, offset=0xb21a, mode=Thumb, size=None, cc=None
i32 candidate_00b21a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb239, offset=0xb238, mode=Thumb, size=None, cc=None
i32 candidate_00b238(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb243, offset=0xb242, mode=Thumb, size=None, cc=None
i32 candidate_00b242(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb253, offset=0xb252, mode=Thumb, size=None, cc=None
i32 candidate_00b252(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb25b, offset=0xb25a, mode=Thumb, size=None, cc=None
i32 candidate_00b25a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb291, offset=0xb290, mode=Thumb, size=None, cc=None
i32 candidate_00b290(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

