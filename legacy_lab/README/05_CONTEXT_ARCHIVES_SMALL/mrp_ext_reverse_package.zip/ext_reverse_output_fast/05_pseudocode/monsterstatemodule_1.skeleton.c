/* Skeleton recovered from function map for monsterstatemodule_1. Fill bodies from 02_disassembly. */
typedef int i32;

// addr=0x8, offset=0x8, mode=ARM, size=None, cc=None
i32 candidate_000008(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb, offset=0xa, mode=Thumb, size=None, cc=None
i32 candidate_00000a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x12b, offset=0x12a, mode=Thumb, size=None, cc=None
i32 candidate_00012a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x145, offset=0x144, mode=Thumb, size=None, cc=None
i32 candidate_000144(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a5, offset=0x1a4, mode=Thumb, size=None, cc=None
i32 candidate_0001a4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c5, offset=0x2c4, mode=Thumb, size=None, cc=None
i32 candidate_0002c4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x339, offset=0x338, mode=Thumb, size=None, cc=None
i32 candidate_000338(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x401, offset=0x400, mode=Thumb, size=None, cc=None
i32 candidate_000400(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4d1, offset=0x4d0, mode=Thumb, size=None, cc=None
i32 candidate_0004d0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5d9, offset=0x5d8, mode=Thumb, size=None, cc=None
i32 candidate_0005d8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x665, offset=0x664, mode=Thumb, size=None, cc=None
i32 candidate_000664(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6cd, offset=0x6cc, mode=Thumb, size=None, cc=None
i32 candidate_0006cc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7d5, offset=0x7d4, mode=Thumb, size=None, cc=None
i32 candidate_0007d4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c1, offset=0x9c0, mode=Thumb, size=None, cc=None
i32 candidate_0009c0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xcc9, offset=0xcc8, mode=Thumb, size=None, cc=None
i32 candidate_000cc8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xd99, offset=0xd98, mode=Thumb, size=None, cc=None
i32 candidate_000d98(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1209, offset=0x1208, mode=Thumb, size=None, cc=None
i32 candidate_001208(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17d1, offset=0x17d0, mode=Thumb, size=None, cc=None
i32 candidate_0017d0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ca5, offset=0x1ca4, mode=Thumb, size=None, cc=None
i32 candidate_001ca4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21e9, offset=0x21e8, mode=Thumb, size=None, cc=None
i32 candidate_0021e8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2511, offset=0x2510, mode=Thumb, size=None, cc=None
i32 candidate_002510(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2629, offset=0x2628, mode=Thumb, size=None, cc=None
i32 candidate_002628(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ae1, offset=0x2ae0, mode=Thumb, size=None, cc=None
i32 candidate_002ae0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b0d, offset=0x2b0c, mode=Thumb, size=None, cc=None
i32 candidate_002b0c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c89, offset=0x2c88, mode=Thumb, size=None, cc=None
i32 candidate_002c88(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e0d, offset=0x2e0c, mode=Thumb, size=None, cc=None
i32 candidate_002e0c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e8d, offset=0x2e8c, mode=Thumb, size=None, cc=None
i32 candidate_002e8c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x338d, offset=0x338c, mode=Thumb, size=None, cc=None
i32 candidate_00338c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3595, offset=0x3594, mode=Thumb, size=None, cc=None
i32 candidate_003594(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x365d, offset=0x365c, mode=Thumb, size=None, cc=None
i32 candidate_00365c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37a9, offset=0x37a8, mode=Thumb, size=None, cc=None
i32 candidate_0037a8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3839, offset=0x3838, mode=Thumb, size=None, cc=None
i32 candidate_003838(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3875, offset=0x3874, mode=Thumb, size=None, cc=None
i32 candidate_003874(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3899, offset=0x3898, mode=Thumb, size=None, cc=None
i32 candidate_003898(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38d9, offset=0x38d8, mode=Thumb, size=None, cc=None
i32 candidate_0038d8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x393d, offset=0x393c, mode=Thumb, size=None, cc=None
i32 candidate_00393c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39d9, offset=0x39d8, mode=Thumb, size=None, cc=None
i32 candidate_0039d8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a6d, offset=0x3a6c, mode=Thumb, size=None, cc=None
i32 candidate_003a6c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3b99, offset=0x3b98, mode=Thumb, size=None, cc=None
i32 candidate_003b98(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3bcf, offset=0x3bce, mode=Thumb, size=None, cc=None
i32 candidate_003bce(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3cb1, offset=0x3cb0, mode=Thumb, size=None, cc=None
i32 candidate_003cb0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3d99, offset=0x3d98, mode=Thumb, size=None, cc=None
i32 candidate_003d98(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e45, offset=0x3e44, mode=Thumb, size=None, cc=None
i32 candidate_003e44(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3fc9, offset=0x3fc8, mode=Thumb, size=None, cc=None
i32 candidate_003fc8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x40a1, offset=0x40a0, mode=Thumb, size=None, cc=None
i32 candidate_0040a0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x41f9, offset=0x41f8, mode=Thumb, size=None, cc=None
i32 candidate_0041f8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x42c9, offset=0x42c8, mode=Thumb, size=None, cc=None
i32 candidate_0042c8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4395, offset=0x4394, mode=Thumb, size=None, cc=None
i32 candidate_004394(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4427, offset=0x4426, mode=Thumb, size=None, cc=None
i32 candidate_004426(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x444f, offset=0x444e, mode=Thumb, size=None, cc=None
i32 candidate_00444e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4489, offset=0x4488, mode=Thumb, size=None, cc=None
i32 candidate_004488(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x448d, offset=0x448c, mode=Thumb, size=None, cc=None
i32 candidate_00448c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44ef, offset=0x44ee, mode=Thumb, size=None, cc=None
i32 candidate_0044ee(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4515, offset=0x4514, mode=Thumb, size=None, cc=None
i32 candidate_004514(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4541, offset=0x4540, mode=Thumb, size=None, cc=None
i32 candidate_004540(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

