/* Selected recovered pseudo-C for gameattackmodule_1. Not original source. */


/* ===== _start @ 0x8, size=20, cc=1 ===== */
int _start(int a0)
{
    return sub_7db9(a0);
}


/* ===== sub_6781 @ 0x6781, size=1888, cc=91 ===== */
typedef struct struct_1 {
    char padding_0[52];
    struct struct_0 *field_34;
} struct_1;

typedef struct struct_2 {
    char padding_0[12];
    unsigned int field_c;
} struct_2;

typedef struct struct_0 {
    char padding_0[4];
    int field_4;
} struct_0;

extern unsigned int g_1;
extern int g_12;
extern int g_128;
extern int g_12d;
extern int g_13;
extern int g_14;
extern char g_16;
extern int g_2;
extern char g_24;
extern int g_26;
extern int g_27;
extern int g_28;
extern char g_2c;
extern int g_3;
extern char g_30;
extern int g_33;
extern char g_34;
extern int g_35;
extern int g_36;
extern char g_38;
extern char g_3c;
extern int g_4;
extern char g_44;
extern char g_48;
extern int g_4c;
extern int g_4f;
extern int g_50;
extern char g_58;
extern char g_6;
extern int g_73;
extern char g_8c;
extern int g_9;
extern int g_9e;
extern int g_a;
extern int g_b0c8;
extern int g_b124;
extern char g_b13c;
extern int g_b144;
extern int g_b14c;
extern int g_b154;
extern int g_b170;
extern int g_b180;
extern int g_b18c;
extern int g_b198;
extern int g_b1a4;
extern int g_b1ac;
extern int g_b1b8;
extern int g_b1c0;
extern int g_b1d0;
extern int g_b1dc;
extern char g_c;
extern int g_e1;
extern char g_f;
extern int g_f0;
extern char g_ff;

unsigned int sub_6781(struct_1 *a0)
{
    unsigned int i;  // r5
    unsigned int v2;  // r9
    unsigned int v3;  // r0
    unsigned int v25;  // r6
    struct_2 *idx;  // r7
    unsigned int index;  // r5
    unsigned int v28;  // r0
    unsigned int v29;  // r5
    unsigned int v30;  // r0
    unsigned int v31;  // r0
    int v5;  // r1
    int v6;  // r2
    int v7;  // r3
    int v8;  // r4
    unsigned int v9;  // r0
    unsigned int v0;  // [bp-0x18]

    i = sub_0;
    v0 = sub_7e91(0x1e200, 301, a0, "M", "M", "M", "M") & 0xff;
    *((void* *)(12 + v2 + 36)) = sub_0;
    sub_7e91(0x1e200, 20, 76, a0, "M", "M", "M");
    sub_7e91(0x1e200, 296, "M", "M", "M", "M", "M");
    v3 = *((char *)(12 + v2 + 18));
    if (v3 != 1 && (sub_7b41(4) != 1 || !a0->padding_0[22] || !((v3 = sub_7b41(3), !v3))))
    {
        sub_7799(sub_7e91(0x1e200, 225, 76, "M", "M", "M", "M"), v5, v6, v7, "M", "M", "M");
        *((char *)(12 + v2 + 2)) = 1;
        if (*((int *)(12 + v2 + 140)))
            sub_7e91(0x1e200, 18, *((int *)(12 + v2 + 140)), "M", "M", "M", "M");
        *((void* *)(12 + v2 + 140)) = sub_0;
        sub_a115(1);
        sub_7e91(0x1e200, 158, "M", "M", "M", "M", "M");
        v8 = sub_7e91(0x1e200, 19, "M", "M", "M", "M", "M");
        if (v0 == 1)
        {
            if (a0->padding_0[22] && !sub_7b41(3))
            {
                if (!sub_7b41(2))
                {
                    v9 = 12 + v2;
                    if (*((int *)(v9 + 44)) && *((int *)(v9 + 52)) == a0)
                        sub_7e91(0x1e200, 54, v8, sub_7e91(0x1e200, 53, *((int *)(v9 + 44)), 0xb0c8, "M", "M", "M"), "M", "M", "M");
                }
                if (sub_7b41(1))
                {
LABEL_69ff:
                }
                else if (a0->padding_0[15] == 1 || a0->field_34 && sub_7e91(0x1e200, 115, a0->field_34->field_4, "M", "M", "M", "M") == 6)
                {
                    sub_7e91(0x1e200, 54, v8, sub_7e91(0x1e200, 53, 0xb144, 0xb0c8, "M", "M", "M"), "M", "M", "M");
                    *((unsigned int *)(32 + sub_7e91(0x1e200, 225, 240, "M", "M", "M", "M"))) = 45380;
                    sub_7e91(0x1e200, 54, v8, sub_7e91(0x1e200, 53, 0xb13c, 0xb0c8, "M", "M", "M"), "M", "M", "M");
                    *((unsigned int *)(28 + sub_7e91(0x1e200, 225, 240, "M", "M", "M", "M"))) = 45372;
                    goto LABEL_69ff;
                }
                else
                {
                    sub_7e91(0x1e200, 54, v8, sub_7e91(0x1e200, 53, 0xb13c, 0xb0c8, "M", "M", "M"), "M", "M", "M");
                    *((unsigned int *)(28 + sub_7e91(0x1e200, 225, 240, "M", "M", "M", "M"))) = 45372;
                    sub_7e91(0x1e200, 54, v8, sub_7e91(0x1e200, 53, 0xb144, 0xb0c8, "M", "M", "M"), "M", "M", "M");
                    *((unsigned int *)(32 + sub_7e91(0x1e200, 225, 240, "M", "M", "M", "M"))) = 45380;
                }
                if (!sub_7b41(2))
                {
                    sub_7e91(0x1e200, 54, v8, sub_7e91(0x1e200, 53, 0xb14c, 0xb0c8, "M", "M", "M"), "M", "M", "M");
                    *((unsigned int *)(sub_7e91(0x1e200, 225, 240, "M", "M", "M", "M") + 36)) = 45388;
                }
                else
                {
                    sub_7e91(0x1e200, 0x33, 0xb154, "M", "M", "M", "M");
                    sub_7e91(0x1e200, 20, 79, _start, "M", "M", "M");
                }
            }
            else
            {
                sub_7e91(0x1e200, 0x33, 0xb170, "M", "M", "M", "M");
                sub_7e91(0x1e200, 20, 79, _start, "M", "M", "M");
            }
        }
        sub_7e91(0x1e200, 54, v8, sub_7e91(0x1e200, 53, 0xb1a4, 0xb0c8, "M", "M", "M"), "M", "M", "M");
        *((unsigned int *)(sub_7e91(0x1e200, 225, 240, "M", "M", "M", "M") + 40)) = 45476;
        sub_7e91(0x1e200, 54, v8, sub_7e91(0x1e200, 53, 0xb198, 0xb0c8, "M", "M", "M"), "M", "M", "M");
        *((unsigned int *)(sub_7e91(0x1e200, 225, 240, "M", "M", "M", "M") + 44)) = 45464;
        sub_7e91(0x1e200, 54, v8, sub_7e91(0x1e200, 53, 0xb18c, 0xb0c8, "M", "M", "M"), "M", "M", "M");
        *((unsigned int *)(sub_7e91(0x1e200, 225, 240, "M", "M", "M", "M") + 48)) = 45452;
        sub_7e91(0x1e200, 54, v8, sub_7e91(0x1e200, 53, 0xb180, 0xb0c8, "M", "M", "M"), "M", "M", "M");
        *((unsigned int *)(sub_7e91(0x1e200, 225, 240, "M", "M", "M", "M") + 52)) = 45440;
        if (!sub_7e91(0x1e200, 225, 80, "M", "M", "M", "M"))
        {
            sub_7e91(0x1e200, 54, v8, sub_7e91(0x1e200, 53, 0xb1ac, 0xb0c8, "M", "M", "M"), "M", "M", "M");
            *((unsigned int *)(sub_7e91(0x1e200, 225, 240, "M", "M", "M", "M") + 56)) = 45484;
        }
        if (sub_7e91(0x1e200, 225, 80, "M", "M", "M", "M") != 3)
        {
            sub_7e91(0x1e200, 54, v8, sub_7e91(0x1e200, 53, 0xb1b8, 0xb0c8, "M", "M", "M"), "M", "M", "M");
            *((unsigned int *)(sub_7e91(0x1e200, 225, 240, "M", "M", "M", "M") + 60)) = 45496;
        }
        sub_7e91(0x1e200, 54, v8, sub_7e91(0x1e200, 53, 0xb1dc, 0xb0c8, "M", "M", "M"), "M", "M", "M");
        *((unsigned int *)(sub_7e91(0x1e200, 225, 240, "M", "M", "M", "M") + 0x44)) = 45532;
        sub_7e91(0x1e200, 54, v8, sub_7e91(0x1e200, 53, 0xb1d0, 0xb0c8, "M", "M", "M"), "M", "M", "M");
        *((unsigned int *)(sub_7e91(0x1e200, 225, 240, "M", "M", "M", "M") + 72)) = 45520;
        sub_7e91(0x1e200, 54, v8, sub_7e91(0x1e200, 53, 0xb1c0, 0xb0c8, "M", "M", "M"), "M", "M", "M");
        v25 = sub_7e91(0x1e200, 38, v8, "M", "M", "M", "M");
        idx = 140 + v2;
        idx->field_c = sub_7e91(0x1e200, 10, v25, 4, "M", "M", "M");
        if (v25 > sub_0)
        {
            do
            {
                index = i;
                v28 = sub_7e91(0x1e200, 39, v8, index, "M", "M", "M");
                v29 = index + 1;
                *((unsigned int *)(idx->field_c + index * 4)) = v28;
                i = v29;
            } while (i < v25);
        }
        sub_7e91(0x1e200, 40, v8, "M", "M", "M", "M");
        v30 = sub_7e91(0x1e200, 9, v8, "M", "M", "M", "M");
        *((void* *)&idx[5].padding_0[8]) = sub_0;
        return v30;
    }
    sub_6565(v3);
    v31 = sub_7b41(4);
    if (v31 != 1)
        return v31;
    sub_7e91(0x1e200, 0x33, 0xb124, "M", "M", "M", "M");
    return sub_7e91(0x1e200, 20, 79, _start, "M", "M", "M");
}


/* ===== sub_4815 @ 0x4815, size=1782, cc=71 ===== */
typedef struct struct_1 {
    char padding_0[48];
    unsigned short field_30;
    char padding_32[22];
    unsigned short field_48;
    unsigned short field_4a;
    char padding_4c[56];
    struct struct_2 *field_84;
    char padding_88[72];
    char field_d0;
} struct_1;

typedef struct struct_4 {
    char padding_0[204];
    struct struct_5 *field_cc;
} struct_4;

typedef struct struct_6 {
    char padding_0[4];
    unsigned int field_4;
} struct_6;

typedef struct struct_2 {
    char padding_0[88];
    struct struct_3 *field_58;
} struct_2;

typedef struct struct_5 {
    char padding_0[8];
    unsigned short field_8;
    unsigned short field_a;
} struct_5;

typedef struct struct_3 {
    struct struct_0 *field_0;
} struct_3;

typedef struct struct_0 {
    char padding_0[4];
    struct struct_1 *field_4;
} struct_0;

extern unsigned int g_1;
extern struct_1 g_11;
extern int g_120;
extern struct_1 g_14;
extern char g_2;
extern int g_3;
extern int g_30;
extern int g_37;
extern int g_38;
extern int g_39;
extern char g_4;
extern char g_40;
extern int g_48;
extern char g_4c;
extern int g_5;
extern char g_50;
extern char g_58;
extern unsigned int g_6;
extern char g_70;
extern int g_72;
extern int g_74;
extern int g_76;
extern char g_80;
extern unsigned int g_9;
extern char g_a;
extern int g_b080;
extern int g_b094;
extern unsigned int g_c;
extern char g_c0;
extern char g_d0;
extern unsigned int g_e;
extern int g_e1;
extern char g_f;
extern char g_ff;

struct_1 * sub_4815(struct_1 *a0, int a1, unsigned int a2, unsigned int a3)
{
    struct_1 *v21;  // r0
    unsigned int v22;  // r9
    struct_1 *v31;  // r5
    unsigned int v32;  // r0
    unsigned int v33;  // r1
    struct_4 *idx;  // r5
    int v35;  // r0
    int v36;  // r2
    unsigned int v37;  // r1
    int v39;  // r1, Other Possible Types: unsigned int
    int v40;  // r0
    struct_1 *index;  // r4
    unsigned int v44;  // r0
    struct_6 *v45;  // r0
    unsigned int v46;  // r0
    struct_1 *v24;  // r0
    unsigned int v25;  // r5
    struct_1 *v26;  // r5
    struct_1 *v29;  // r0
    struct_1 *v30;  // r5
    struct_1 *v0;  // [bp-0x70], Other Possible Types: unsigned int
    struct_1 *v1;  // [bp-0x6c]
    struct_1 *v2;  // [bp-0x68]
    unsigned short v3[6];  // [bp-0x64]
    struct_1 *v4;  // [bp-0x58]
    unsigned int v5;  // [bp-0x54], Other Possible Types: int
    unsigned int v6;  // [bp-0x50]
    struct_1 *v7;  // [bp-0x4c], Other Possible Types: unsigned int
    int v8;  // [bp-0x48], Other Possible Types: unsigned int
    struct_1 *v9;  // [bp-0x44], Other Possible Types: unsigned int
    struct_1 *v10;  // [bp-0x40], Other Possible Types: int, unsigned int
    int v11;  // [bp-0x3c], Other Possible Types: unsigned int
    unsigned int v12;  // [bp-0x38]
    struct_1 *v13;  // [bp-0x34], Other Possible Types: unsigned int
    struct_1 *v14;  // [bp-0x30]
    unsigned int v15;  // [bp-0x2c]
    struct_1 *idx1;  // [bp-0x28]
    struct_1 *v17;  // [bp-0x24]
    unsigned int v18;  // [bp-0x1c]
    unsigned int v19;  // [bp-0x18]
    int v20;  // [bp+0x0]

    v17 = a0;
    v18 = a2;
    v19 = a3;
    v21 = sub_0;
    if (*((char *)(12 + v22 + 0x11)) == 1)
    {
        v13 = (sub_7e91(0x1e200, 3, 2, "M", "M", "M", "M") ? ~(sub_0) : 1);
        v21 = sub_7e91(0x1e200, 3, 3, "M", "M", "M", "M") * v13;
    }
    v14 = v21;
    v24 = sub_0;
    if (*((char *)(12 + v22 + 0x11)) == 1)
    {
        v25 = (sub_7e91(0x1e200, 3, 2, "M", "M", "M", "M") ? ~(sub_0) : 1);
        v24 = sub_7e91(0x1e200, 3, 3, "M", "M", "M", "M") * v25;
    }
    v13 = v24;
    if (*((char *)(12 + v22 + 0x11)) == 1)
    {
        v10 = a3;
        v8 = a1;
        v11 = v20;
        v7 = a0;
        v9 = a2;
        v12 = 1;
        return sub_7e91(0x1e200, 288, &v7, "M", "M", "M", "M");
    }
    idx1 = &a0->padding_4c[52];
    v26 = &a0->padding_32[14];
    v15 = v20 * 10;
    if (*((int *)&idx1->padding_0[4]))
    {
        v12 = (sub_7e91(0x1e200, 3, 2, "M", "M", "M", "M") ? ~(3) : 4) + a2 - 10;
        v10 = a3 - *((int *)(sub_7e91(0x1e200, 116, a1, *((short *)(v26 + _start)), *((short *)&v26->padding_0[10]), "M", "M") + 4));
        v11 = v10 + (sub_7e91(0x1e200, 3, 2, "M", "M", "M", "M") ? ~(3) : 4) - 10;
        v10 = *((int *)&idx1->padding_0[4]);
        v29 = *((int *)*((int *)&idx1->padding_0[4]));
        if (v29 == 0x11 || v29 == 20)
        {
            switch (v29)
            {
            case 17:
                v30 = *((int *)&v10->padding_4c[4]);
                break;
            case 20:
                if (*((int *)&v10->padding_4c[12]) && (v31 = a0 + 208, v31->padding_0[0] != 255))
                {
                    v32 = sub_7e91(0x1e200, 0x11, *((int *)&v10->padding_4c[12]), 4, "M", "M", "M");
                    v33 = v31->padding_0[0];
                    v30 = (v33 < v32 ? *((int *)(*((int *)(*((int *)&v10->padding_4c[12]) + v33 * 4)) + 4)) : *((int *)(*((int *)*((int *)&v10->padding_4c[12])) + 4)));
                    if (v30 > sub_0)
                    {
                        if (!*((int *)(12 + v22 + 192)))
                            *((unsigned int *)(12 + v22 + 192)) = sub_7e91(0x1e200, 5, *((int *)(12 + v22 + 192)), 0xb080, ~(sub_0), ~(sub_0), "M");
                        v5 = a1;
                        v4 = a0;
                        v6 = &v14->padding_0[a2 + v15];
                        v7 = &v13->padding_0[a3];
                        v8 = v20;
                        v9 = 1;
                        sub_7e91(0x1e200, 288, &v4, "M", "M", "M", "M");
                        v4 = v30;
                        v5 = v12;
                        v6 = v11;
                        v0 = sub_0;
                        v7 = *((int *)(12 + v22 + 192));
                        v8 = 12;
                        v2 = sub_0;
                        v9 = 14;
                        v1 = sub_0;
                        return sub_7e91(0x1e200, 118);
                    }
                }
                break;
            default:
                idx = 12 + v22 + 128;
                *((unsigned int *)&idx->padding_0[76]) = sub_7e91(0x1e200, 5, *((int *)&idx->padding_0[76]), 0xb094, ~(sub_0), ~(sub_0), "M");
                v4 = a0;
                v5 = a1;
                v8 = v20;
                v6 = a2;
                v7 = a3;
                v9 = 1;
                sub_7e91(0x1e200, 288, &v4, "M", "M", "M", "M");
                v3 = *((int *)&idx->padding_0[76]);
                return sub_7e91(0x1e200, sub_20, &v3, "M", "M", "M", "M", v3, v12, v11, "M", "M", *((short *)(v3 + _start)), v3[5], "M", "M");
            }
        }
    }
    v7 = a0;
    v8 = a1;
    v9 = &v14->padding_0[a2 + v15];
    v10 = &v13->padding_0[a3];
    v11 = v20;
    v12 = 1;
    sub_7e91(0x1e200, 288, &v7, "M", "M", "M", "M");
    if (!*((int *)(12 + v22 + 112)))
        *((unsigned int *)(12 + v22 + 112)) = sub_7e91(0x1e200, 55, "beattack@attack.ani", "M", "M", "M", "M");
    if (v20 == -1)
    {
        if (10 > a0->field_30)
        {
            v35 = sub_7e91(0x1e200, 56, *((int *)(12 + v22 + 112)), "M", "M", "M", "M");
            sub_20(v35, a0->field_30, v36, 48, "M", "M", "M");
            v11 = sub_7e91(0x1e200, 3, 10, "M", "M", "M", "M");
            if (!sub_7e91(0x1e200, 3, 2, "M", "M", "M", "M"))
                v37 = 1;
            else
                v37 = ~(sub_0);
            v12 = v11 * v37 + a2;
            v11 = sub_7e91(0x1e200, 3, 10, "M", "M", "M", "M");
            v11 = v11 * (sub_7e91(0x1e200, 3, 2, "M", "M", "M", "M") ? ~(sub_0) : 1) + a3;
            v2 = sub_0;
            v1 = sub_0;
            v0 = *((short *)&v26->padding_0[10]);
            v10 = *((int *)(sub_7e91(0x1e200) + 4));
            v8 = v11 - (v10 - *((int *)(sub_7e91(0x1e200, 116, *((int *)(12 + v22 + 112)), "M", v39, "M", "M") + 4)));
            v6 = *((int *)(12 + v22 + 112));
            v7 = v12;
            v9 = sub_0;
            v10 = v39;
            v11 = sub_7e91(0x1e200, 114, 1, "M", "M", "M", "M");
            sub_7e91(0x1e200, 57, &v6, "M", "M", "M", "M");
        }
LABEL_4de9:
    }
    else
    {
        if (10 <= a0->field_30)
            goto LABEL_4de9;
        v40 = sub_7e91(0x1e200, 56, *((int *)(12 + v22 + 112)), "M", "M", "M", "M");
        sub_20(v40, a0->field_30, v36, 48, "M", "M", "M");
        v11 = sub_7e91(0x1e200, 3, 5, "M", "M", "M", "M");
        v12 = v11 * (sub_7e91(0x1e200, 3, 2, "M", "M", "M", "M") ? ~(sub_0) : 1) + a2;
        v11 = sub_7e91(0x1e200, 3, 5, "M", "M", "M", "M");
        v11 = v11 * (sub_7e91(0x1e200, 3, 2, "M", "M", "M", "M") ? ~(sub_0) : 1) + a3;
        v1 = sub_0;
        v2 = sub_0;
        v0 = v39;
        v10 = *((int *)(sub_7e91(0x1e200, 116, a1, *((short *)(v26 + _start)), *((short *)&v26->padding_0[10]), "M", "M") + 4));
        v8 = v11 - (v10 - *((int *)(sub_7e91(0x1e200, 116, *((int *)(12 + v22 + 112))) + 4)));
        v6 = *((int *)(12 + v22 + 112));
        v10 = v39;
        v7 = v12;
        v9 = sub_0;
        v11 = sub_7e91(0x1e200, 114, -(v20), "M", "M", "M", "M");
        sub_7e91(0x1e200, 57, &v6, "M", "M", "M", "M");
    }
    index = *((int *)&idx1->padding_0[4]);
    if (index)
    {
        idx1 = *((int *)&index->padding_0[0]);
        if (idx1 == 0x11)
        {
            idx1 = *((int *)&index->padding_4c[4]);
            if (sub_0 > idx1)
            {
                v44 = (sub_7e91(0x1e200, 3, 2, "M", "M", "M", "M") ? ~(1) : 2);
                v45 = sub_7e91(0x1e200, 116, a1, *((short *)(v26 + _start)), *((short *)&v26->padding_0[10]), "M", "M");
                v46 = (sub_7e91(0x1e200, 3, 2, "M", "M", "M", "M") ? ~(1) : 2);
                v7 = *((int *)&index->padding_4c[4]);
                v8 = v44 + a2 - 15;
                v9 = a3 - v45->field_4 + v46 - 10;
                v10 = sub_7e91(0x1e200, 225, 72, "M", "M", "M", "M");
                v11 = 6;
                v12 = 9;
                return sub_7e91(0x1e200, 118, &v7, "M", "M", "M", "M");
            }
        }
    }
    return idx1;
}


/* ===== sub_592d @ 0x592d, size=1594, cc=80 ===== */
extern int g_1;
extern int g_100;
extern int g_114;
extern int g_115;
extern int g_12;
extern int g_14;
extern int g_143;
extern int g_14b;
extern int g_17;
extern int g_2;
extern char g_24;
extern int g_26;
extern int g_27;
extern char g_28;
extern char g_2c;
extern char g_3;
extern char g_30;
extern int g_32;
extern int g_3a;
extern int g_43;
extern int g_4c;
extern int g_4d;
extern int g_4e;
extern char g_5;
extern char g_50;
extern int g_51;
extern int g_52;
extern int g_53;
extern char g_54;
extern int g_5c;
extern int g_5d;
extern int g_5e;
extern int g_6;
extern int g_62;
extern int g_63;
extern int g_64;
extern int g_65;
extern int g_66;
extern char g_68;
extern int g_69;
extern int g_6a;
extern int g_6b;
extern int g_6c;
extern char g_7;
extern char g_76;
extern int g_77;
extern int g_78;
extern int g_7a;
extern int g_7b;
extern int g_7c;
extern int g_7d;
extern int g_7f;
extern char g_80;
extern char g_8c;
extern int g_9;
extern int g_99;
extern int g_a0;
extern char g_b;
extern char g_c;
extern int g_e1;

int sub_592d(void)
{
    int v3;  // r0
    unsigned int v4;  // r9
    int v13;  // r0
    int v14;  // r5
    int v15;  // r4
    int v16;  // r0
    int index[54];  // r5
    int idx[28];  // r7
    int v19;  // r0
    unsigned int idx1;  // r7
    int v23;  // r0
    int v24;  // r0
    int v25;  // r5
    int v26;  // r0
    int v27;  // r0
    int v9;  // r1
    int v10;  // r2
    int v11;  // r3
    int v0;  // [bp-0x20]
    int v1;  // [bp-0x1c]
    int v2;  // [bp-0x18]

    v3 = sub_7e91(0x1e200, 225, 94, "M", "M", "M", "M");
    if (v3)
    {
        sub_7e91(0x1e200, 331, "M", "M", "M", "M", "M");
        sub_7e91(0x1e200, 20, 276, "M", "M", "M", "M");
        idx1 = 12 + v4;
        *((void* *)(idx1 + 11)) = sub_0;
        if (*((int *)(idx1 + 44)))
            sub_7e91(0x1e200, 9, *((int *)(idx1 + 44)), "M", "M", "M", "M");
        *((void* *)(idx1 + 44)) = sub_0;
        sub_7e91(0x1e200, 20, 94, "M", "M", "M", "M");
        sub_7e91(0x1e200, 20, 98, "M", "M", "M", "M");
        sub_7e91(0x1e200, 20, 78, "M", "M", "M", "M");
        if (*((int *)(idx1 + 40)))
            sub_7e91(0x1e200, 9, *((int *)(idx1 + 40)), "M", "M", "M", "M");
        *((void* *)(12 + v4 + 40)) = sub_0;
        sub_7e91(0x1e200, 20, 99, "M", "M", "M", "M");
        if (sub_7e91(0x1e200, 225, 100, "M", "M", "M", "M"))
        {
            sub_7e91(0x1e200, 9, sub_7e91(0x1e200, 225, 100, "M", "M", "M", "M"), "M", "M", "M", "M");
            sub_7e91(0x1e200, 20, 100, "M", "M", "M", "M");
        }
        sub_7e91(0x1e200, 160, sub_7e91(0x1e200, 225, 83, "M", "M", "M", "M"), "M", "M", "M", "M");
        sub_7e91(0x1e200, 20, 83, "M", "M", "M", "M");
        sub_5899(sub_7e91(0x1e200, 127, "M", "M", "M", "M", "M"), v9, v10, v11, "M", "M", "M");
        sub_7e91(0x1e200, 124, 1, "M", "M", "M", "M");
        if (sub_7e91(0x1e200, 225, 93, "M", "M", "M", "M"))
            sub_7e91(0x1e200, 0x77, sub_7e91(0x1e200, 225, 93, "M", "M", "M", "M"), "M", "M", "M", "M");
        if (*((int *)(12 + v4 + 140)))
            sub_7e91(0x1e200, 18, *((int *)(12 + v4 + 140)), "M", "M", "M", "M");
        *((void* *)(12 + v4 + 140)) = sub_0;
        v13 = sub_7e91(0x1e200, 38, sub_7e91(0x1e200, 225, 82, "M", "M", "M", "M"), "M", "M", "M", "M");
        v14 = sub_0;
        if (v13 > sub_0)
        {
            do
            {
                v15 = sub_7e91(0x1e200, 39, sub_7e91(0x1e200, 225, 82, "M", "M", "M", "M"), v14, "M", "M", "M");
                if (v15)
                {
                    sub_7e91(0x1e200, 0x99, v15, "M", 2, "M", "M");
                    v16 = v15 + 48;
                    if (!*((char *)(v16 + 3)))
                        *((char *)(v16 + 3)) = 1;
                    if (!sub_7e91(0x1e200, 0x99, v15, "M", 2, "M", "M"))
                        sub_7e91(0x1e200, 123, v15, "M", 2, 1, "M");
                }
            } while ((v14 += 1, v14 < v13));
        }
        index = 12 + v4 + 128;
        index[3] = sub_0;
        sub_7e91(0x1e200, 122, "M", "M", "M", "M", "M");
        sub_7e91(0x1e200, 120, "M", "M", "M", "M", "M");
        idx = 12 + v4;
        sub_7e91(0x1e200, 6, idx[25], "M", "M", "M", "M");
        idx[25] = sub_0;
        sub_7e91(0x1e200, 6, *((int *)(index + _start)), "M", "M", "M", "M");
        *((void* *)(index + _start)) = sub_0;
        v19 = sub_7e91(0x1e200, 6, idx[26], "M", "M", "M", "M");
        idx[26] = sub_0;
        sub_94f5(sub_98b5(sub_9571(v19, v9, v10, v11, "M", "M", "M"), v9, v10, v11), v9, v10, v11);
        sub_9921(sub_7e91(0x1e200, 105, "M", "M", "M", "M", "M"), v9, v10, v11, "M", "M", "M");
        sub_7e91(0x1e200, 108, "M", "M", "M", "M", "M");
        sub_7e91(0x1e200, 6, idx[27], "M", "M", "M", "M");
        idx[27] = sub_0;
        sub_7e91(0x1e200, 20, 76, "M", "M", "M", "M");
        sub_7e91(0x1e200, 20, 77, "M", "M", "M", "M");
        v3 = sub_7e91(0x1e200, 225, 101, "M", "M", "M", "M");
        if (v3 != 1)
        {
            if (sub_7e91(0x1e200, 225, 81, "M", "M", "M", "M") == 1)
            {
                sub_7e91(0x1e200, 20, 92, sub_7e91(0x1e200, 225, 23, "M", "M", "M", "M"), "M", "M", "M");
            }
            else if (!sub_7e91(0x1e200, 225, 0x66, "M", "M", "M", "M"))
            {
                sub_7e91(0x1e200, 20, 23, 20, "M", "M", "M");
            }
            else
            {
                sub_7e91(0x1e200, 20, 23, 0x100, "M", "M", "M");
            }
            *((void* *)((char *)&idx[1] + 1)) = sub_0;
            v23 = sub_7e91(0x1e200, 20, 81, "M", "M", "M", "M");
            *((void* *)((char *)&idx[1] + 3)) = sub_0;
            sub_9421(v23, v9, v10, v11, "M", "M", "M");
            sub_95c5(index[20]);
            index[20] = sub_0;
            sub_7e91(0x1e200, 20, 106, "M", "M", "M", "M");
            sub_95c5(index[21]);
            index[21] = sub_0;
            v0 = sub_0;
            v1 = sub_0;
            v2 = sub_0;
            sub_7e91(0x1e200, 20, 107, "M");
            sub_7e91(0x1e200, 125, "M", "M", "M", "M", "M");
            if (sub_7e91(0x1e200, 225, 50, "M", "M", "M", "M"))
            {
                v24 = sub_7e91(0x1e200, 38, sub_7e91(0x1e200, 225, 50, "M", "M", "M", "M"), "M", "M", "M", "M");
                v25 = sub_0;
                if (v24 > sub_0)
                {
                    do
                    {
                        v26 = sub_7e91(0x1e200, 39, sub_7e91(0x1e200, 225, 50, "M", "M", "M", "M"), v25, "M", "M", "M");
                        if (v26 && *((int *)(v26 + 36)))
                            *((void* *)(*((int *)(v26 + 36)) + 118)) = sub_0;
                    } while ((v25 += 1, v25 < v24));
                }
            }
            sub_7e91(0x1e200, 323, "M", "M", "M", "M", "M");
            sub_7e91(0x1e200, 20, 277, 1, "M", "M", "M");
            v27 = sub_7e91(0x1e200, 225, 67, "M", "M", "M", "M");
            if (v27 != 1)
                return v27;
            return sub_7e91(0x1e200, 20, 23, 58, "M", "M", "M");
        }
    }
    return v3;
}


/* ===== sub_3aa5 @ 0x3aa5, size=1376, cc=46 ===== */
extern int g_1;
extern char g_14;
extern char g_19;
extern int g_1d;
extern char g_1f;
extern int g_2;
extern int g_25;
extern int g_27;
extern int g_2a;
extern char g_3;
extern char g_30;
extern int g_32;
extern int g_38;
extern int g_39;
extern char g_3c;
extern char g_4;
extern char g_4c;
extern char g_4f;
extern char g_5;
extern int g_56;
extern int g_70;
extern char g_8c;
extern unsigned int g_a;
extern char g_b;
extern char g_b064;
extern int g_e1;
extern int g_ff;

int sub_3aa5(unsigned int *idx, unsigned int a1)
{
    int v20;  // r5
    unsigned int v21;  // r0
    int v28;  // r2
    int v29;  // r3
    unsigned int v30;  // r1
    unsigned int v31;  // r3
    unsigned int v32;  // r0
    int v33;  // r6
    unsigned int v22;  // r6
    unsigned int v34;  // r0
    int v35;  // r5
    unsigned int v36;  // r6
    unsigned int v37;  // r7
    unsigned int v38;  // r0
    unsigned int v39;  // r9
    unsigned int v23;  // r7
    int v24;  // r0
    int v26;  // r0
    unsigned int v0;  // [bp-0x60]
    unsigned int v1;  // [bp-0x5c]
    unsigned int v2;  // [bp-0x58]
    unsigned int v3;  // [bp-0x54]
    int v4;  // [bp-0x50], Other Possible Types: unsigned int
    int v5;  // [bp-0x4c], Other Possible Types: unsigned int
    int v6;  // [bp-0x48], Other Possible Types: unsigned int
    unsigned int v7;  // [bp-0x44], Other Possible Types: int
    unsigned int v8;  // [bp-0x40], Other Possible Types: int
    int v9;  // [bp-0x3c], Other Possible Types: unsigned int
    int v10;  // [bp-0x38], Other Possible Types: unsigned int
    unsigned int v11;  // [bp-0x34], Other Possible Types: int
    unsigned int v12;  // [bp-0x30], Other Possible Types: int
    unsigned int v13;  // [bp-0x2c]
    int v14;  // [bp-0x28], Other Possible Types: unsigned int
    char v15;  // [bp-0x24]
    char v16;  // [bp-0x20], Other Possible Types: unsigned int
    int v17;  // [bp-0x1c]
    int v18;  // [bp-0x18]
    int v19;  // [bp+0x0]

    v20 = v19;
    v21 = *((int *)(idx + _start));
    v22 = a1 * 4;
    if (!*((int *)(v21 + v22)))
        return v21;
    v23 = sub_7e91(0x1e200, 112, *((int *)(*((int *)(v21 + v22)) + 112)), 1, "M", "M", "M");
    sub_7e91(0x1e200, 42, *((int *)*((int *)(*((int *)(idx + _start)) + v22))), "M", "M", &v16, &v15);
    if (*((char *)(*((int *)(*((int *)(idx + _start)) + v22)) + 76)) <= sub_0)
    {
        if (idx[12] == 4294967295)
        {
            v9 = v23;
            v10 = 10;
            v14 = 1;
            v12 = sub_0;
            v13 = sub_0;
            v11 = v20;
            sub_7e91(0x1e200, 57, &v9, "M", "M", "M", "M");
            v7 = v20;
            v5 = *((int *)*((int *)(*((int *)(idx + _start)) + v22)));
            v6 = 2;
            v10 = 0xff;
            v11 = 0xff;
            v12 = 0xff;
            v8 = sub_0;
            v9 = sub_0;
            *((char *)&v13) = 1;
            v14 = sub_0;
            sub_7e91(0x1e200, 37, &v5, "M", "M", "M", "M");
        }
        else
        {
            v9 = v23;
            v10 = sub_7e91(0x1e200, sub_1c, "M", "M", "M", "M", "M") - 10;
            v11 = v20;
            v12 = sub_0;
            v13 = sub_0;
            v14 = sub_0;
            sub_7e91(0x1e200, 57, &v9, "M", "M", "M", "M");
            v5 = *((int *)*((int *)(*((int *)(idx + _start)) + v22)));
            v8 = sub_0;
            v6 = sub_7e91(0x1e200, sub_1c, "M", "M", "M", "M", "M") - v16 - 3;
            v10 = 0xff;
            v11 = 0xff;
            v12 = 0xff;
            v7 = v20;
            v9 = sub_0;
            *((char *)&v13) = 1;
            v14 = sub_0;
            sub_7e91(0x1e200, 37, &v5, "M", "M", "M", "M");
        }
        if (*((char *)(*((int *)(*((int *)(idx + _start)) + v22)) + 79)) == 1)
        {
            sub_7e91(0x1e200, 42, 0xb064, "M", "M", &v14, &v13);
            v18 = v20 - 25;
            v31 = idx[12] + 1;
            if (idx[12] == 4294967295)
            {
                v4 = 2;
                v8 = 0xff;
                v3 = 45156;
                v5 = v18;
                v10 = v31;
                v6 = v31;
                v7 = v31;
                v9 = v31;
                v11 = 1;
                v2 = sub_0;
                v0 = sub_0;
                v1 = sub_0;
                v12 = v31;
                sub_7e91(0x1e200, 37, &v3);
            }
            else
            {
                v3 = 45156;
                v6 = sub_0;
                v4 = sub_7e91(0x1e200, sub_1c, "M", "M", "M", "M", "M", 0xb064) - v14 - 3;
                v8 = 0xff;
                v5 = v18;
                v10 = sub_0;
                v7 = sub_0;
                v9 = sub_0;
                v11 = 1;
                v12 = sub_0;
                sub_7e91(0x1e200, 37, &v3, "M", "M", "M", "M");
            }
        }
    }
    else if (idx[12] == 4294967295)
    {
        v10 = 10;
        v9 = v23;
        v12 = 2;
        v11 = v20;
        v24 = sub_7e91(0x1e200, 225, 39, "M", "M", "M", "M");
        v8 = v24;
        sub_20(sub_7e91(0x1e200, 56, v23, 2, "M", "M", "M"), v24, v28, v29, "M", "M", "M");
        v13 = v30;
        v14 = sub_0;
        sub_7e91(0x1e200, 57, &v9, "M", "M", "M", "M");
        v6 = 2;
        v5 = *((int *)*((int *)(*((int *)(idx + _start)) + v22)));
        v10 = 0xff;
        v11 = 0xff;
        v12 = 0xff;
        v8 = sub_0;
        v9 = sub_0;
        v7 = v20;
        *((char *)&v13) = 1;
        v14 = sub_0;
        sub_7e91(0x1e200, 37, &v5, "M", "M", "M", "M");
    }
    else
    {
        v9 = v23;
        v10 = sub_7e91(0x1e200, sub_1c, "M", "M", "M", "M", "M") - 10;
        v12 = 2;
        v11 = v20;
        v26 = sub_7e91(0x1e200, 225, 39, "M", "M", "M", "M");
        v8 = v26;
        sub_20(sub_7e91(0x1e200, 56, v23, 2, "M", "M", "M"), v26, v28, v29, "M", "M", "M");
        v13 = v30;
        v14 = 1;
        sub_7e91(0x1e200, 57, &v9, "M", "M", "M", "M");
        v5 = *((int *)*((int *)(*((int *)(idx + _start)) + v22)));
        v6 = sub_7e91(0x1e200, sub_1c, "M", "M", "M", "M", "M") - v16 - 3;
        v10 = 0xff;
        v11 = 0xff;
        v12 = 0xff;
        v8 = sub_0;
        v9 = sub_0;
        v7 = v20;
        *((char *)&v13) = 1;
        v14 = sub_0;
        sub_7e91(0x1e200, 37, &v5, "M", "M", "M", "M");
    }
    if (*((char *)(*((int *)(*((int *)(idx + _start)) + v22)) + 76)) > sub_0)
    {
        sub_7e91(0x1e200, 42, sub_b070, "M", "M", &v14, &v13);
        v32 = sub_7e91(0x1e200, sub_1c, "M", "M", "M", "M", "M");
        v33 = (v32 - (v14 + 10) >> 31) + v32 - (v14 + 10) >> 1;
        v34 = sub_7e91(0x1e200, 29, "M", "M", "M", "M", "M");
        v35 = (v34 >> 31) + v34 >> 1;
        sub_7e91(0x1e200, 50, v33, v35, v14 + 10, v13 + 10, "M");
        v8 = 0xff;
        v9 = 0xff;
        v10 = 0xff;
        v7 = v35 + 5;
        v6 = v33 + 5;
        v5 = sub_b070;
        v11 = sub_0;
        v12 = sub_0;
        return sub_7e91(0x1e200, 86, &v5, "M", "M", "M", "M");
    }
    v36 = *((int *)(*((int *)(idx + sub_20)) + v22));
    if (!v36)
        return *((int *)(idx + sub_20));
    v37 = sub_0;
    v11 = *((int *)(v36 + 4));
    if (*((int *)(v36 + 4)))
    {
        sub_7e91(0x1e200, 42, v11, "M", "M", &v14, &v13);
    }
    else
    {
        v14 = sub_0;
        v13 = sub_0;
    }
    v17 = v20 - 60;
    if (idx[12] == 4294967295)
    {
        v12 = v17;
    }
    else
    {
        v37 = sub_7e91(0x1e200, sub_1c, "M", "M", "M", "M", "M") - v14 - 20;
        v12 = v17;
    }
    v38 = *((char *)(v36 + 1));
    if (v38 != *((int *)(140 + v39 + 48)))
        return v38;
    sub_a261(v36);
    v0 = *((char *)(v36 + 11));
    sub_581d(v36);
    if (v11)
    {
        sub_7e91(0x1e200, 50, v37, v12, v14 + 10, sub_7e91(0x1e200, 225, 42, "M", "M", "M", "M") + v13, "M");
        v3 = v11;
        return sub_7e91(0x1e200, 86, &v3, "M", "M", "M", "M", v3, v37 + 5, v12 + _start, 0xff, 0xff, 0xff, "M", "M");
    }
    return v11;
}


/* ===== sub_1971 @ 0x1971, size=1286, cc=74 ===== */
typedef struct struct_0 {
    int field_0;
    char padding_4[10];
    char field_e;
    char field_f;
    char field_10;
    char padding_11[27];
    int field_2c;
    int field_30;
} struct_0;

extern int g_1;
extern char g_10;
extern char g_12;
extern int g_121;
extern int g_1388;
extern int g_1389;
extern int g_138a;
extern int g_138b;
extern int g_14;
extern char g_180;
extern int g_2;
extern char g_2c;
extern int g_3;
extern char g_30;
extern int g_32;
extern int g_33;
extern int g_34;
extern char g_4;
extern int g_4c;
extern int g_50;
extern int g_51;
extern int g_59;
extern int g_5a;
extern char g_6;
extern int g_7;
extern int g_73;
extern char g_80;
extern int g_82;
extern int g_83;
extern int g_84;
extern int g_a;
extern int g_b;
extern int g_b1c0;
extern int g_b328;
extern int g_b330;
extern int g_b338;
extern int g_b340;
extern int g_b34c;
extern int g_b358;
extern int g_b364;
extern int g_b3c8;
extern int g_b3d0;
extern int g_b3d8;
extern int g_b3f0;
extern char g_b4;
extern int g_b400;
extern int g_b40c;
extern int g_b414;
extern int g_b438;
extern int g_b444;
extern int g_b470;
extern char g_b8;
extern char g_c;
extern char g_d0;
extern int g_d4;
extern char g_e;
extern int g_e1;
extern char g_f;

unsigned int sub_1971(int a0)
{
    unsigned int v0;  // r9
    struct_0 *idx;  // r6
    unsigned int v10;  // r0
    int v11;  // r4
    unsigned int v12;  // r6
    unsigned int v13;  // r0
    unsigned int v14;  // r0
    int v2;  // r0
    int v3;  // r0
    unsigned int v4;  // r1
    int v6;  // r0
    int v7;  // r1
    int v8;  // r2
    int v9;  // r3

    idx = 12 + v0;
    if (idx->field_2c && !(*((int *)(384 + v0)))(idx->field_2c, a0, *((int *)(384 + v0))))
        return sub_27b1(idx->field_2c, idx->field_30, idx->field_e, idx->field_10, idx->field_f, *((int *)(12 + v0 + 184)), 1);
    if (sub_7e91(0x1e200, 11, a0, 0xb328, "M", "M", "M") != 4294967295)
    {
        return sub_6651("M", "M", "M");
    }
    else if (sub_7e91(0x1e200, 11, a0, 0xb330, "M", "M", "M") != 4294967295)
    {
        return sub_77ad();
    }
    else if (sub_7e91(0x1e200, 11, a0, 0xb338, "M", "M", "M") != 4294967295)
    {
        if (sub_7e91(0x1e200, 225, 50, "M", "M", "M", "M"))
        {
            v2 = sub_7e91(0x1e200, 289, "M", "M", "M", "M", "M");
            if (v2 == 1)
                return sub_7e91(123423, 10, 2, "M", "M", "M", "M");
            return v2;
        }
        else
        {
            v3 = sub_7e91(0x1e200, 289, "M", "M", "M", "M", "M");
            if (v3 == 1)
                return sub_7e91(123423, 10, 3, "M", "M", "M", "M");
            return v3;
        }
    }
    else
    {
        if (sub_7e91(0x1e200, 11, a0, 0xb340, "M", "M", "M") != 4294967295)
        {
            sub_94ad();
            return sub_7e91(0x1e200, 132, -0x4, "M", "M", "M", "M");
        }
        else if (sub_7e91(0x1e200, 11, a0, 0xb34c, "M", "M", "M") != 4294967295)
        {
            v4 = 12 + v0 + 128;
            *((int *)(12 + v0 + 180)) = *((int *)(*((int *)(12 + v0 + 208)) + 16));
            return sub_a115(2, 12 + v0 + 128);
        }
        else if (sub_7e91(0x1e200, 11, a0, 0xb358, "M", "M", "M") != 4294967295)
        {
            return (sub_7e91(0x1e200, 225, 212, "M", "M", "M", "M") != 1 ? sub_73d1() : sub_7e91(0x1e200, 0x33, 0xb364, "M", "M", "M", "M"));
        }
        else if (sub_7e91(0x1e200, 11, a0, 0xb3c8, "M", "M", "M") != 4294967295)
        {
            sub_5899();
            sub_7e91(0x1e200, 52, "M", "M", "M", "M", "M");
            return sub_9d8d(1);
        }
        else if (sub_7e91(0x1e200, 11, a0, 0xb3d0, "M", "M", "M") != 4294967294)
        {
            if (sub_7e91(0x1e200, 225, 80, "M", "M", "M", "M"))
            {
                return sub_7e91(0x1e200, 0x33, 0xb3d8, "M", "M", "M", "M");
            }
            else if (!sub_7e91(0x1e200, 225, sub_20, "M", "M", "M", "M"))
            {
                return sub_7e91(0x1e200, 81, 0xb3f0, "M", "M", "M", "M");
            }
            else
            {
                v6 = sub_7e91(0x1e200, 20, sub_20, "M", "M", "M", "M");
                idx->padding_4[7] = 1;
                sub_5899(v6, v7, v8, v9, "M", "M", "M");
                sub_7e91(0x1e200, 52, "M", "M", "M", "M", "M");
                *((char *)&idx->field_0) = 1;
                return sub_9d8d(7);
            }
        }
        else
        {
            if (sub_7e91(0x1e200, 11, a0, 0xb1c0, "M", "M", "M") != 4294967295)
            {
                v10 = sub_6565();
                idx->padding_4[2] = 1;
                return v10;
            }
            else if (sub_7e91(0x1e200, 11, a0, 0xb400, "M", "M", "M") != 4294967295)
            {
                idx->padding_11[1] = 1;
                return sub_6565();
            }
            else
            {
                if (sub_7e91(0x1e200, 11, a0, 0xb40c, "M", "M", "M") != 4294967295)
                {
                    v11 = *((int *)(sub_7e91(0x1e200, 225, 76, "M", "M", "M", "M") + 52));
                    if (v11 && sub_7e91(0x1e200, 115, *((int *)(v11 + 4)), "M", "M", "M", "M") == 6)
                    {
                        v12 = sub_7e91(0x1e200, 225, 89, "M", "M", "M", "M");
                        v13 = sub_7e91(0x1e200, 115, *((int *)(v11 + 4)), "M", "M", "M", "M");
                        sub_7e91(0x1e200, 131, *((int *)(v12 + v13 * 4)), *((int *)(v11 + 4)), "M", "M", "M");
                        return sub_6651(3, "M", "M");
                    }
                    v14 = sub_7e91(0x1e200, 0x33, 0xb414, "M", "M", "M", "M");
                }
                else
                {
                    v14 = sub_7e91(0x1e200, 11, a0, 0xb438, "M", "M", "M");
                    if (v14 != 4294967295)
                    {
                        if (!sub_7e91(0x1e200, 130, 0x1388, 1, "M", "M", "M") && !sub_7e91(0x1e200, 130, 0x1389, 1, "M", "M", "M") && !sub_7e91(0x1e200, 130, 0x138a, 1, "M", "M", "M") && !sub_7e91(0x1e200, 130, 0x138b, 1, "M", "M", "M"))
                            return sub_7e91(0x1e200, 0x33, 0xb444, "M", "M", "M", "M");
                        if (!sub_7e91(0x1e200, 225, 80, "M", "M", "M", "M"))
                        {
                            sub_94ad();
                            sub_7e91(0x1e200, 20, 90, "M", "M", "M", "M");
                            return sub_6651(1, "M", "M");
                        }
                        return sub_7e91(0x1e200, 0x33, 0xb470, "M", "M", "M", "M");
                    }
                }
                return v14;
            }
        }
    }
}


/* ===== sub_6f2d @ 0x6f2d, size=1164, cc=51 ===== */
typedef struct struct_0 {
    char padding_0[8];
    int field_8;
    char padding_c[68];
    struct struct_1 *field_50;
    int field_54;
} struct_0;

typedef struct struct_1 {
    int field_0;
} struct_1;

extern int g_1;
extern int g_11;
extern int g_114;
extern char g_12;
extern int g_12c;
extern int g_13;
extern int g_14;
extern int g_143;
extern int g_15;
extern char g_16;
extern int g_17;
extern char g_18;
extern char g_1a;
extern char g_1e;
extern int g_2;
extern char g_24;
extern int g_27;
extern char g_28;
extern char g_2c;
extern int g_2e;
extern char g_3;
extern char g_30;
extern char g_32;
extern int g_4;
extern char g_44;
extern int g_4c;
extern int g_4d;
extern int g_5;
extern char g_50;
extern int g_53;
extern char g_54;
extern int g_5c;
extern int g_5d;
extern int g_5e;
extern int g_5f;
extern char g_6;
extern int g_60;
extern int g_61;
extern char g_64;
extern int g_68;
extern int g_6a;
extern int g_6b;
extern int g_6c;
extern char g_7;
extern int g_7e;
extern int g_7f;
extern int g_80;
extern char g_8c;
extern int g_a;
extern int g_a0;
extern char g_b;
extern char g_c;
extern int g_e1;
extern int g_f1;

int sub_6f2d(void)
{
    unsigned int v6;  // r9
    struct_0 *v7;  // r7
    int v16;  // r1
    int v17;  // r2
    int v18;  // r3
    int v19;  // r0
    int v20;  // r0
    void* idx;  // r5
    int v11;  // r0
    void* index;  // r4
    unsigned int v13;  // r5
    unsigned int i;  // r4
    unsigned int j;  // r4
    unsigned int v0;  // [bp-0x2c]
    unsigned int v1;  // [bp-0x28]
    unsigned int v2;  // [bp-0x24]
    unsigned int v3;  // [bp-0x20]
    unsigned int v4;  // [bp-0x1c]
    unsigned int v5;  // [bp-0x18]

    v5 = sub_0;
    v4 = sub_0;
    v3 = sub_0;
    v2 = sub_0;
    v1 = sub_0;
    v0 = sub_0;
    sub_7e91(65848, &v5, &v4, &v3, &v2, &v1, &v0, "M", "M", "M", v3, v4, v5);
    v7 = 140 + v6;
    idx = 140 + v6 - 128;
    *((void* *)&v7->padding_c[24]) = sub_0;
    *((void* *)&idx[48]) = ~(sub_0);
    *((void* *)&idx[44]) = sub_0;
    *((void* *)idx) = sub_0;
    *((void* *)&idx[40]) = sub_0;
    if (sub_7e91(0x1e200, 225, 83, "M", "M", "M", "M"))
    {
        sub_7e91(0x1e200, 160, sub_7e91(0x1e200, 225, 83, "M", "M", "M", "M"), "M", "M", "M", "M");
        sub_7e91(0x1e200, 20, 83, "M", "M", "M", "M");
    }
    *((void* *)&idx[1]) = sub_0;
    sub_7e91(0x1e200, 20, 241, "M", "M", "M", "M");
    *((void* *)&idx[11]) = sub_0;
    sub_7e91(0x1e200, 20, 92, "M", "M", "M", "M");
    if (!sub_7e91(0x1e200, 225, 93, "M", "M", "M", "M"))
        sub_7e91(0x1e200, 20, 93, sub_7e91(0x1e200, 19, "M", "M", "M", "M", "M"), "M", "M", "M");
    sub_7e91(0x1e200, 20, 94, 1, "M", "M", "M");
    *((void* *)&idx[7]) = sub_0;
    *((void* *)&idx[5]) = sub_0;
    *((void* *)&idx[11]) = sub_0;
    *((void* *)(4 + v6 + 4)) = ~(sub_0);
    sub_7e91(0x1e200, 20, 39, "M", "M", "M", "M");
    sub_7e91(0x1e200, 20, sub_20, "M", "M", "M", "M");
    sub_7e91(0x1e200, 20, 76, "M", "M", "M", "M");
    sub_7e91(0x1e200, 20, 77, "M", "M", "M", "M");
    *((char *)&idx[4]) = 1;
    *((void* *)&idx[3]) = sub_0;
    sub_7e91(0x1e200, 128, "M", "M", "M", "M", "M");
    v11 = sub_7e91(0x1e200, 225, 95, "M", "M", "M", "M");
    *((unsigned int *)(148 + v6)) = sub_7e91(0x1e200, 5, *((int *)(v7 + _start)), v11, ~(sub_0), ~(sub_0), "M");
    *((void* *)&idx[0x44]) = sub_0;
    *((void* *)&idx[20]) = sub_0;
    sub_7e91(0x1e200, 21, 10, "M", "M", "M", "M");
    sub_7e91(0x1e200, 127, "M", "M", "M", "M", "M");
    sub_7e91(0x1e200, 108, "M", "M", "M", "M", "M");
    if (sub_7e91(0x1e200, 225, 300, "M", "M", "M", "M") == 2)
        sub_7e91(0x1e200, 126, 1, "M", "M", "M", "M");
    else
        sub_7e91(0x1e200, 126, "M", "M", "M", "M", "M");
    sub_7e91(0x1e200, 104, "M", "M", "M", "M", "M");
    sub_7e91(0x1e200, 107, "M", "M", "M", "M", "M");
    sub_7e91(0x1e200, 106, "M", "M", "M", "M", "M");
    index = 140 + v6 - 128;
    *((void* *)&index[30]) = sub_0;
    *((void* *)&index[22]) = sub_0;
    *((void* *)&index[24]) = sub_0;
    *((void* *)(index + sub_1c)) = sub_0;
    sub_7e91(0x1e200, 20, 96, 2, "M", "M", "M");
    *((void* *)&index[26]) = sub_0;
    *((void* *)&index[2]) = sub_0;
    *((unsigned int *)&index[100]) = sub_7e91(0x1e200, 5, (int)index[100], "shandow!49!17@attack.bmp", ~(sub_0), ~(sub_0), "M");
    sub_7e91(0x1e200, 21, 10, "M", "M", "M", "M");
    sub_7e91(0x1e200, sub_1c, "M", "M", "M", "M", "M");
    *((unsigned short *)(index + sub_20)) = 50;
    sub_7e91(0x1e200, 21, 10, "M", "M", "M", "M");
    sub_7e91(0x1e200, 21, 10, "M", "M", "M", "M");
    sub_7e91(0x1e200, 21, 10, "M", "M", "M", "M");
    sub_7e91(0x1e200, 21, 10, "M", "M", "M", "M");
    sub_7e91(0x1e200, 21, 10, 1, "M", "M", "M");
    *((char *)&index[18]) = sub_7e91(0x1e200, 225, 97, "M", "M", "M", "M");
    v13 = sub_7e91(0x1e200, 0x11, v7->field_50->field_0, 4, "M", "M", "M");
    i = sub_0;
    if (v13 > sub_0)
    {
        do
        {
            sub_a12d(v7->field_50, i);
            i += 1;
        } while (i < v13);
    }
    j = sub_0;
    if (v13 > sub_0)
    {
        do
        {
            sub_a12d(v7->field_54, j);
            j += 1;
        } while (j < v13);
    }
    sub_7989(v7->field_50);
    sub_7989(v7->field_54);
    sub_7e91(0x1e200, 20, 23, 46, "M", "M", "M");
    *((void* *)&v7->padding_0[0]) = sub_0;
    *((void* *)(12 + v6 + 6)) = sub_0;
    v19 = sub_7ac9(sub_7e91(0x1e200, 323, "M", "M", "M", "M", "M"), v16, v17, v18, "M", "M", "M");
    v20 = sub_78a9(sub_7a45(v19, v16, v17, v18), v16, v17, v18);
    sub_78a9(v20, v16, v17, v18);
    return sub_7e91(0x1e200, 20, 276, 1, "M", "M", "M");
}


/* ===== sub_3129 @ 0x3129, size=1118, cc=51 ===== */
typedef struct struct_0 {
    char padding_0[32];
    unsigned short field_20;
} struct_0;

extern char g_1;
extern int g_11;
extern char g_12;
extern int g_124;
extern int g_131;
extern int g_14;
extern int g_1d;
extern int g_1e;
extern int g_1f;
extern char g_2;
extern int g_21;
extern int g_2a;
extern int g_2d;
extern char g_3;
extern int g_32;
extern unsigned int g_3c;
extern int g_3f;
extern char g_4;
extern char g_40;
extern int g_41;
extern int g_4b;
extern char g_5;
extern char g_50;
extern char g_54;
extern int g_56;
extern char g_5f;
extern char g_6;
extern int g_64;
extern int g_65;
extern int g_6a;
extern int g_6b;
extern int g_7;
extern int g_7d;
extern char g_80;
extern int g_9;
extern int g_9f;
extern int g_a3;
extern int g_a4;
extern int g_b100;
extern char g_b108;
extern char g_b118;
extern char g_c;
extern char g_d0;
extern char g_d4;
extern char g_e;
extern int g_e1;
extern int g_ed;
extern unsigned int g_ff;

int sub_3129(void)
{
    int v15;  // r4
    unsigned int v16;  // r9
    int v25;  // r0
    int v26;  // r0
    unsigned int v27;  // r4
    char *v29;  // r6
    unsigned int v30;  // r0
    unsigned int v31;  // r0
    struct_0 *v17;  // r6
    int v18;  // r5
    unsigned int v19;  // r0
    int v20;  // r6
    unsigned int v22;  // r0
    unsigned int v23;  // r1
    unsigned int v24;  // r0
    int v0;  // [bp-0x50], Other Possible Types: unsigned int
    unsigned int v1;  // [bp-0x4c]
    unsigned int v2;  // [bp-0x48]
    unsigned int v3;  // [bp-0x44]
    unsigned int v4;  // [bp-0x3c]
    unsigned int v5;  // [bp-0x38]
    int v6;  // [bp-0x34], Other Possible Types: unsigned int
    unsigned int v7;  // [bp-0x30]
    int v8;  // [bp-0x2c], Other Possible Types: unsigned int
    int v9;  // [bp-0x28], Other Possible Types: unsigned int
    int v10;  // [bp-0x24], Other Possible Types: unsigned int
    int v11;  // [bp-0x20], Other Possible Types: unsigned int, char
    char v12;  // [bp-0x1f]
    int v13;  // [bp-0x1c]
    unsigned int v14;  // [bp-0x18]

    v15 = 50;
    sub_7e91(0x1e200, sub_1c, "M", "M", "M", "M", "M");
    v17 = 12 + v16;
    v14 = *((short *)(v17 + sub_20));
    v18 = 30;
    v19 = sub_7e91(0x1e200, sub_1c, "M", "M", "M", "M", "M");
    v20 = 30;
    v13 = v19 - *((short *)(v17 + sub_20));
    sub_7e91(0x1e200, 125, "M", "M", "M", "M", "M");
    if (sub_7e91(0x1e200, 225, 305, "M", "M", "M", "M"))
    {
        v18 = 0x11;
        v20 = 0x11;
        v15 = 33;
    }
    if (*((int *)(12 + v16 + 128)) == 1 || *((int *)(12 + v16 + 128)) == 2 || *((int *)(12 + v16 + 128)) == 3)
    {
        v22 = sub_7e91(0x1e200, 225, 237, "M", "M", "M", "M");
        if (v22 <= sub_0)
            return v22;
        sub_7e91(0x1e200, 292, "M", "M", "M", "M", "M");
    }
    else
    {
        sub_7e91(0x1e200, 20, 237, 1, "M", "M", "M");
    }
    if (sub_7e91(0x1e200, 225, 75, "M", "M", "M", "M"))
    {
        sub_7e91(0x1e200, 159, "M", "M", "M", "M", "M");
        sub_7e91(0x1e200, 163, "M", "M", "M", "M", "M");
        sub_7e91(0x1e200, 101, "M", "M", "M", "M", "M");
    }
    else
    {
        v5 = sub_0;
        v6 = sub_0;
        v7 = sub_7e91(0x1e200, sub_1c, "M", "M", "M", "M", "M");
        v8 = 50;
        v9 = 60;
        v10 = 60;
        v11 = 60;
        sub_7e91(0x1e200, 31, &v5, "M", "M", "M", "M");
        v0 = sub_0;
        v1 = sub_0;
        v2 = sub_0;
        v6 = 50;
        v5 = sub_0;
        v7 = sub_7e91(0x1e200, sub_1c);
        v8 = sub_7e91(0x1e200, 29, "M", "M", "M", "M", "M") - 50;
        v9 = 100;
        v10 = 100;
        v11 = 100;
        sub_7e91(0x1e200, 31, &v5, "M", "M", "M", "M");
    }
    v23 = 12 + v16 + 128;
    if (!*((int *)(v23 + 80)) && !*((int *)(v23 + 84)))
    {
        sub_7e91(0x1e200, 20, 107, "M", "M", "M", "M");
        sub_7e91(0x1e200, 20, 106, "M", "M", "M", "M");
        return sub_7e91(0x1e200, 164, "M", "M", "M", "M", "M");
    }
    if (!*((int *)(12 + v16 + 164)) || *((int *)(*((int *)(12 + v16 + 164)) + 4)) == 4294967295)
    {
        v1 = sub_0;
        v0 = v15;
        sub_3879();
        sub_3879(*((int *)(12 + v16 + 208)), ~(sub_0), v14, v18, v15, 1);
    }
    else
    {
        sub_3879(*((int *)(v23 + 80)), ~(sub_0), v14, v18, v15, 1);
        sub_3879(*((int *)(12 + v16 + 212)), 1, v13, v20, v15, "M");
    }
    v24 = *((int *)(12 + v16 + 128));
    if (v24 == 1)
    {
        sub_2979(1);
        v25 = sub_7e91(0x1e200, 63, *((int *)(12 + v16 + 64)), "M", "M", "M", "M");
        v26 = sub_7e91(0x1e200, 45, 0xb100, v25, "M", "M", "M");
        sub_7e91(0x1e200, 9, v25, "M", "M", "M", "M");
        v27 = sub_7e91(0x1e200, 45, v26, sub_b0f8, "M", "M", "M");
        sub_7e91(0x1e200, 42, v27, "M", "M", &v11, &v10);
        sub_7e91(0x1e200, 50, "M", sub_7e91(0x1e200, 29, "M", "M", "M", "M", "M") - 100, v11 + 14, 20, "M");
        v3 = v27;
        v7 = 0xff;
        v8 = sub_0;
        v4 = sub_7e91(0x1e200, 29, "M", "M", "M", "M", "M", v27, 7) - 95;
        v9 = sub_0;
        v5 = 0xff;
        v6 = 0xff;
        sub_7e91(0x1e200, 86, &v3, "M", "M", "M", "M");
    }
    else if (v24 == 2)
    {
        sub_2e89();
    }
    else if (v24 == 3)
    {
        sub_2c0d();
    }
    v29 = 12 + v16;
    if (v29[18] == 1)
    {
        v7 = 45320;
        v8 = 0xff;
        v9 = 0xff;
        v10 = 0xff;
        v11 = (char)sub_0;
        v12 = 1;
        sub_7e91(0x1e200, 65, &v7, "M", "M", "M", "M");
    }
    v30 = 12 + v16 + 128;
    if (*((int *)v30) == 4 || (v31 = v30, *((int *)v31) == 5))
    {
        v31 = v30;
        if (!v29[6])
        {
            v31 = *((int *)(v30 + 20));
            if (*((int *)(v30 + 20)))
            {
                v31 = *(v29);
                if (!v31)
                {
                    v7 = 45336;
                    v8 = 0xff;
                    v9 = 0xff;
                    v10 = 0xff;
                    v11 = 1;
                    v12 = 1;
                    return sub_7e91(0x1e200, 65, &v7, "M", "M", "M", "M");
                }
            }
        }
    }
    return v31;
}


/* ===== sub_8ba5 @ 0x8ba5, size=1096, cc=51 ===== */
typedef struct struct_0 {
    unsigned int field_0;
    unsigned int field_4;
    unsigned int field_8;
    char field_c;
    char padding_d[3];
    int field_10;
    unsigned int field_14;
    unsigned int field_18;
    unsigned int field_1c;
    unsigned int field_20;
    unsigned int field_24;
    unsigned int field_28;
    unsigned int field_2c;
    int field_30;
} struct_0;

typedef struct struct_1 {
    char padding_0[8];
    int field_8;
} struct_1;

extern int g_1;
extern char g_10;
extern int g_13;
extern char g_14;
extern char g_16;
extern char g_18;
extern int g_2;
extern char g_24;
extern char g_28;
extern char g_2c;
extern char g_3;
extern char g_30;
extern int g_34;
extern int g_36;
extern int g_4;
extern int g_45;
extern int g_46;
extern int g_47;
extern int g_48;
extern int g_52;
extern char g_70;
extern int g_7b;
extern int g_92;
extern int g_94;
extern int g_95;
extern int g_a;
extern int g_ad;
extern char g_c;
extern int g_e1;
extern int g_f;
extern char g_ff;

struct_0 * sub_8ba5(struct_1 *a0)
{
    int idx;  // r5
    struct_0 *v10;  // r0
    int idx1;  // r5
    unsigned int v20;  // r0
    int v21;  // r0
    unsigned int v22;  // r0
    int idx2;  // r0
    int v24;  // r0
    struct_0 *v11;  // r4
    int v13;  // r7
    unsigned int index[29];  // r0
    unsigned int v15;  // r0
    int v16;  // r0
    int v17;  // r5
    int v18;  // r0
    unsigned int v0;  // [bp-0x38]
    unsigned int v1;  // [bp-0x34]
    int j;  // [bp-0x30], Other Possible Types: unsigned int
    int v3;  // [bp-0x2c], Other Possible Types: unsigned int
    int v4;  // [bp-0x28]
    int v5;  // [bp-0x24]
    int v6;  // [bp-0x20]
    unsigned int v7;  // [bp-0x1c]
    unsigned int v8;  // [bp-0x18]

    v5 = sub_0;
    idx = sub_0;
    v10 = sub_7e91(0x1e200, 15, 52, "M", "M", "M", "M");
    memset(v10, "M", 12);
    v11 = v10;
    v6 = sub_7e91(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") & 0xff;
    v11->field_c = v6;
    if (v6 == 1)
    {
        v5 = sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
        v11->field_10 = v5;
    }
    v13 = sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
    v11->field_0 = sub_7e91(0x1e200, 10, v13, 4, "M", "M", "M");
    v11->field_4 = sub_7e91(0x1e200, 10, v13, 4, "M", "M", "M");
    *((unsigned int *)(v11 + _start)) = sub_7e91(0x1e200, 10, v13, 4, "M", "M", "M");
    v11->field_18 = sub_7e91(0x1e200, 10, v13, 4, "M", "M", "M");
    *((unsigned int *)(v11 + sub_1c)) = sub_7e91(0x1e200, 10, v13, 4, "M", "M", "M");
    v11->field_24 = sub_7e91(0x1e200, 10, v13, 4, "M", "M", "M");
    *((unsigned int *)(v11 + sub_20)) = sub_7e91(0x1e200, 10, v13, 4, "M", "M", "M");
    if (v13 > sub_0)
    {
        do
        {
            if (sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M") != 4294967295)
            {
                v3 = sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
                j = sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
                v1 = sub_7e91(0x1e200, 72, a0, "M", "M", "M", "M");
                v0 = sub_7e91(0x1e200, 71, *((int *)(a0 + _start)), "M", "M", "M", "M");
                index = sub_7e91(0x1e200, 173, "M", "M", "M", "M", "M");
                index[1] = v3;
                *((unsigned int *)(index + _start)) = j;
                index[0] = v0;
                index[28] = v1;
                *((unsigned int *[29])(*((int *)(v11 + _start)) + idx * 4)) = index;
            }
        } while ((idx += 1, idx < v13));
    }
    v4 = sub_0;
    if (v13 > sub_0)
    {
        while (true)
        {
            if (sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M") == 4294967295)
            {
                *((void* *)(v11->field_4 + v4 * 4)) = sub_0;
            }
            else
            {
                v3 = sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
                j = sub_0;
                v15 = sub_7e91(0x1e200, 19, "M", "M", "M", "M", "M");
                v8 = v4 * 4;
                *((unsigned int *)(v11->field_4 + v8)) = v15;
                if (v3 > sub_0)
                {
                    do
                    {
                        if (v6 == 1 && v4 == v5)
                        {
                            v16 = sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
                            v17 = sub_7e91(0x1e200, 146, sub_7e91(0x1e200, 225, 82, "M", "M", "M", "M"), v16, "M", "M", "M");
                        }
                        else
                        {
                            v17 = sub_7e91(0x1e200, 149, a0, "M", "M", "M", "M");
                        }
                        v18 = v17 + 48;
                        if (!*((char *)(v18 + 3)))
                        {
                            *((char *)(v18 + 3)) = 1;
                            sub_7e91(0x1e200, 123, v17, "M", 2, 1, "M");
                        }
                        *((char *)(v17 + 22)) = 1;
                        *((void* *)(v17 + 20)) = sub_0;
                        sub_7e91(0x1e200, 148, v17, "M", "M", "M", "M");
                        sub_7e91(0x1e200, 54, *((int *)(v11->field_4 + v8)), v17, "M", "M", "M");
                        j += 1;
                    } while (j < v3);
                }
            }
            v4 += 1;
            if (v13 <= v4)
                break;
        }
    }
    idx1 = sub_0;
    if (v13 > sub_0)
    {
        do
        {
            v20 = sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
            if (v20 == 4294967295)
            {
                *((unsigned int *)(v11->field_0 + idx1 * 4)) = v20 + 1;
            }
            else
            {
                v21 = sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
                v7 = idx1 * 4;
                v22 = sub_7e91(0x1e200, 146, *((int *)(v11->field_4 + v7)), v21, "M", "M", "M");
                *((unsigned int *)(v11->field_0 + v7)) = v22;
            }
        } while ((idx1 += 1, idx1 < v13));
    }
    v11->field_14 = sub_7e91(0x1e200, 10, v13, 2, "M", "M", "M");
    idx2 = sub_0;
    if (v13 > sub_0)
    {
        do
        {
            v24 = idx2 + 1;
            *((void* *)(v11->field_14 + idx2 * 2)) = sub_0;
            idx2 = v24;
        } while (idx2 < v13);
    }
    v11->field_28 = sub_7e91(0x1e200, 10, v13, 2, "M", "M", "M");
    v11->field_2c = sub_7e91(0x1e200, 10, v13, 2, "M", "M", "M");
    if (v6 != 1)
    {
        v11->field_30 = 1;
        return v11;
    }
    v11->field_30 = -2;
    return v11;
}


/* ===== sub_21f9 @ 0x21f9, size=1076, cc=49 ===== */
typedef struct struct_0 {
    char padding_0[8];
    int field_8;
} struct_0;

typedef struct struct_1 {
    char padding_0[56];
    unsigned int field_38;
} struct_1;

extern unsigned int g_1;
extern int g_14;
extern int g_2c;
extern int g_2d;
extern int g_33;
extern int g_35;
extern int g_36;
extern char g_38;
extern int g_44;
extern int g_45;
extern int g_46;
extern int g_47;
extern int g_4f;
extern int g_52;
extern int g_5d;
extern int g_68;
extern int g_69;
extern int g_92;
extern int g_a7;
extern int g_a8;
extern int g_a9;
extern int g_aa;
extern int g_ab;
extern int g_b0c8;
extern int g_b528;
extern int g_bf;
extern int g_e1;
extern int g_e8;
extern char g_ff;

int sub_21f9(struct_0 *a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8)
{
    unsigned int v6;  // r6
    unsigned int v15;  // r5
    int v16;  // r0
    int v18;  // r0
    unsigned int v19;  // r6
    unsigned int j;  // r5
    unsigned int v22;  // r0
    unsigned int k;  // r5
    struct_1 *idx;  // r0
    unsigned int i;  // r5
    int v25;  // r0
    int v8;  // r0
    unsigned int v10;  // r0
    unsigned int v11;  // r0
    unsigned int v0;  // [bp-0x1c]
    unsigned int v1;  // [bp-0x18]
    unsigned int v2;  // [bp-0x14]
    unsigned int v3;  // [bp-0xc]
    unsigned int v4;  // [bp-0x8]
    unsigned int v5;  // [bp-0x4]

    sub_7e41("M", "M", "M");
    sub_7e91(0x1e200, 0x44, a0, "M", "M", "M", "M");
    v6 = sub_7e91(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") & 0xff;
    if (v6 > sub_0)
    {
        do
        {
            v8 = sub_7e91(0x1e200, 71, *((int *)(a0 + _start)), "M", "M", "M", "M");
            sub_7e91(0x1e200, 54, sub_7e91(0x1e200, 225, 93, "M", "M", "M", "M"), v8, "M", "M", "M");
            i += 1;
        } while (i < v6);
    }
    if ((char)sub_7e91(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") == 1)
    {
        sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
        v4 = sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
        v10 = sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
        v11 = sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
        sub_7e91(0x1e200, 20, 232, sub_7e91(0x1e200, 225, 232, "M", "M", "M", "M") + v11, "M", "M", "M");
        sub_7e91(0x1e200, 20, 104, sub_7e91(0x1e200, 225, 104, "M", "M", "M", "M") + v10, "M", "M", "M");
        sub_7e91(0x1e200, 225, 105, "M", "M", "M", "M");
        v2 = sub_0;
        v0 = sub_0;
        v1 = sub_0;
        sub_7e91(0x1e200, 20, 105);
        v15 = sub_0;
        v5 = sub_7e91(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") & 0xff;
        if (v5 > sub_0)
        {
            while (true)
            {
                if (!sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M"))
                {
                    v16 = sub_7e91(0x1e200, 53, sub_7e91(0x1e200, 45, sub_7e91(0x1e200, 167, a0, "M", "& &", "M", "M"), 0xb528, "M", "M", "M"), 0xb0c8, "M", "M", "M");
                    sub_7e91(0x1e200, 54, sub_7e91(0x1e200, 225, 93, "M", "M", "M", "M"), v16, "M", "M", "M");
                }
                else
                {
                    v18 = sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
                    v3 = sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
                    *((unsigned int *)(32 + sub_7e91(0x1e200, 146, sub_7e91(0x1e200, 225, 82, "M", "M", "M", "M"), v18, "M", "M", "M"))) = v3;
                }
                v15 += 1;
                if (v5 <= v15)
                    break;
            }
        }
        v19 = sub_7e91(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") & 0xff;
        j = sub_0;
        if (v19 > sub_0)
        {
            do
            {
                sub_7e91(0x1e200, 169, sub_7e91(0x1e200, 168, a0, "M", "M", "M", "M"), 1, "M", "M", "M");
                j += 1;
            } while (j < v19);
        }
        v22 = sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
        if (v22 > sub_0)
        {
            k = sub_0;
            do
            {
                idx = sub_7e91(0x1e200, 0xaa, sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M"), "M", "M", "M", "M");
                k += 1;
                idx->field_38 = idx->field_38 + 1;
            } while (k < v22);
        }
    }
    v25 = sub_7e91(0x1e200, 171, "M", "M", "M", "M", "M");
    sub_7e91(0x1e200, 44, "M", "M", "M", "M", "M");
    sub_592d();
    sub_7e91(0x1e200, 0x33, v25, "M", "M", "M", "M");
    sub_7e91(0x1e200, 20, 79, 70, "M", "M", "M");
    sub_7e91(0x1e200, 20, 191, "M", "M", "M", "M");
    return sub_7e91(65808, 57860, "M", "M", "M", "M", "M");
}


/* ===== sub_3fd @ 0x3fd, size=764, cc=40 ===== */
typedef struct struct_0 {
    char padding_0[12];
    unsigned short field_c;
} struct_0;

extern int g_1;
extern int g_11;
extern int g_12;
extern char g_14;
extern int g_2;
extern char g_28;
extern int g_29;
extern int g_2c;
extern int g_3;
extern char g_30;
extern int g_33;
extern int g_34;
extern int g_4;
extern int g_49;
extern int g_5;
extern char g_50;
extern char g_54;
extern int g_5a;
extern int g_5b;
extern char g_5c;
extern char g_60;
extern char g_74;
extern char g_80;
extern char g_8c;
extern int g_9c;
extern int g_a;
extern int g_a1;
extern int g_b494;
extern int g_b4a8;
extern char g_c;
extern char g_ce;
extern char g_e;
extern int g_e1;
extern int g_f;

int sub_3fd(unsigned int a0)
{
    unsigned int v0;  // r9
    int v1;  // r0
    int v10;  // r5
    int v11;  // r1
    int v12;  // r0
    struct_0 *v13;  // r0
    unsigned int v14;  // r0
    int v15;  // r0
    int v2;  // r4
    int v3;  // r5
    int v4[25];  // r4
    int v5;  // r5
    int v6[25];  // r4
    int v7[2];  // r1
    void* idx;  // r0
    unsigned int v9;  // r6

    v1 = sub_7e91(0x1e200, 0x11, *((int *)*((int *)(140 + v0 + 80))), 4, "M", "M", "M");
    v2 = v1;
    switch (a0)
    {
    case 2: case 4: case 12: case 14:
        v3 = 140 + v0 + 44;
        v4 = 140 + v0;
        sub_7e91(0x1e200, 41, v4[24], v4[23], v3, "M", "M");
        v1 = sub_c61("M", v3, v4[23], v4[24]);
    case 5: case 17: case 20:
        sub_7e91(0x1e200, 44, "M", "M", "M", "M", "M");
        v1 = *((char *)(140 + v0 - 116));
        switch (v1)
        {
        case 0:
            sub_5899();
            sub_7e91(0x1e200, 52, "M", "M", "M", "M", "M");
            sub_20(v2, *((int *)(140 + v0 + 44)));
            v1 = sub_9ca5("M");
            break;
        case 1:
            v13 = sub_6269(*((int *)(140 + v0 + 44)));
            v14 = sub_7e91(0x1e200, 225, 73, "M", "M", "M", "M");
            if (!*((char *)(*((int *)(v14 + v13->field_c * 4)) + 20)))
            {
                v1 = sub_7e91(0x1e200, 0x33, 0xb494, "M", "M", "M", "M");
                break;
            }
            else if (!v13[14].padding_0[10])
            {
                v1 = sub_7e91(0x1e200, 0x33, 0xb4a8, "M", "M", "M", "M");
                break;
            }
            else if (sub_7e91(0x1e200, 225, 90, "M", "M", "M", "M") == 1)
            {
                sub_7e91(0x1e200, 156, 18, "M", "M", "M", "M");
                v15 = sub_6269(*((int *)(140 + v0 + 44)));
                v1 = sub_a2a5(_start, sub_7e91(0x1e200, 225, 91, "M", "M", "M", "M"), v15);
                break;
            }
            else
            {
                v1 = sub_7e91(0x1e200, 161, 5, 2, "M", "M", "M");
                break;
            }
        case 2:
            v12 = sub_6269(*((int *)(140 + v0 + 44)));
            sub_7e91(0x1e200, 156, 18, "M", "M", "M", "M");
            v1 = sub_a2a5(10, sub_7e91(0x1e200, 225, 91, "M", "M", "M", "M"), v12);
            break;
        case 3:
            sub_5899();
            sub_7e91(0x1e200, 52, "M", "M", "M", "M", "M");
            sub_20(v2, *((int *)(140 + v0 + 44)));
            v1 = sub_9b55(3);
            break;
        case 4:
            idx = 140 + v0 - 128;
            if ((char)idx[10] == 1)
            {
                v9 = (char)idx[14];
                v10 = (int)idx[48];
            }
            else
            {
                v10 = *((int *)(*((int *)(*((int *)(140 + v0 + 40)) + (int)idx[84] * 4)) & 0xfffffffc));
                v9 = *((int *)((*((int *)(*((int *)(140 + v0 + 40)) + (int)idx[84] * 4)) & 0xfffffffc) + 4));
            }
            sub_7e91(0x1e200, 156, 18, "M", "M", "M", "M");
            sub_7e91(0x1e200, 156, 18, "M", "M", "M", "M");
            sub_7e91(0x1e200, 52, "M", "M", "M", "M", "M");
            sub_20(v2, *((int *)(140 + v0 + 44)));
            v1 = sub_9e5d(15, v10, v9, v11);
            break;
        }
    case 6: case 8: case 13: case 15:
        v5 = 140 + v0 + 44;
        v6 = 140 + v0;
        sub_7e91(0x1e200, 41, v6[24], v6[23], v5, 1, "M");
        v1 = sub_c61(1, v5, v6[23], v6[24]);
        break;
    case 18:
        sub_7e91(0x1e200, 44, "M", "M", "M", "M", "M");
        v7 = 140 + v0;
        v1 = v7[1];
        v7[0] = v1;
        break;
    }
    return v1;
}


/* ===== sub_95c5 @ 0x95c5, size=750, cc=45 ===== */
extern char g_1;
extern char g_10;
extern int g_11;
extern char g_14;
extern char g_18;
extern char g_24;
extern int g_26;
extern int g_27;
extern int g_28;
extern char g_2c;
extern int g_4;
extern int g_4a;
extern char g_70;
extern int g_8c;
extern int g_9;
extern char g_c;

int [12] sub_95c5(int *idx)
{
    int index[12];  // r6
    int v3[12];  // r7
    int v4[12];  // r5
    int idx1[12];  // r5
    int v6[12];  // r6
    int idx2[12];  // r5
    int v8[12];  // r6
    int v9[12];  // r6
    int i[12];  // r5
    int v0[12];  // [bp-0x1c]
    int v1[12];  // [bp-0x18]

    index = sub_0;
    if (!idx)
        return idx;
    v3 = sub_7e91(0x1e200, 0x11, *((int *)(idx + _start)), 4, "M", "M", "M");
    if (v3 > sub_0)
    {
        do
        {
            v4 = *((int *)(*((int *)(idx + _start)) + index * 4));
            if (v4)
            {
                if (v4[0])
                    sub_7e91(0x1e200, 9, v4[0], "M", "M", "M", "M");
                if (v4[2 + 4])
                    sub_7e91(0x1e200, 74, v4[2 + 4], "M", "M", "M", "M");
                sub_7e91(0x1e200, 9, v4, "M", "M", "M", "M");
            }
        } while ((index += 1, index < v3));
    }
    idx1 = sub_0;
    sub_7e91(0x1e200, 9, *((int *)(idx + _start)), "M", "M", "M", "M");
    sub_7e91(0x1e200, 9, *((int *)(idx + sub_20)), "M", "M", "M", "M");
    sub_7e91(0x1e200, 9, idx[9], "M", "M", "M", "M");
    if (*((int *)(idx + sub_1c)))
    {
        if (v3 > sub_0)
        {
            do
            {
                v6 = *((int *)(*((int *)(idx + sub_1c)) + idx1 * 4));
                if (v6)
                {
                    sub_7e91(0x1e200, 40, v6, "M", "M", "M", "M");
                    sub_7e91(0x1e200, 9, v6, "M", "M", "M", "M");
                }
            } while ((idx1 += 1, idx1 < v3));
        }
        sub_7e91(0x1e200, 9, *((int *)(idx + sub_1c)), "M", "M", "M", "M");
    }
    if (idx[6])
    {
        idx2 = sub_0;
        if (v3 > sub_0)
        {
            do
            {
                v8 = *((int *)(idx[6] + idx2 * 4));
                if (v8)
                {
                    sub_7e91(0x1e200, 40, v8, "M", "M", "M", "M");
                    sub_7e91(0x1e200, 9, v8, "M", "M", "M", "M");
                }
            } while ((idx2 += 1, idx2 < v3));
        }
        sub_7e91(0x1e200, 9, idx[6], "M", "M", "M", "M");
    }
    sub_7e91(0x1e200, 9, *(idx), "M", "M", "M", "M");
    v1 = sub_0;
    if (v3 > sub_0)
    {
        do
        {
            v9 = *((int *)(idx[1] + v1 * 4));
            if (v9)
            {
                if (!(char)idx[3] || idx[4] != v1)
                {
                    i = sub_0;
                    v0 = sub_7e91(0x1e200, 38, v9, "M", "M", "M", "M");
                    if (v0 > sub_0)
                    {
                        do
                        {
                            sub_7e91(0x1e200, 140, sub_7e91(0x1e200, 39, v9, i, "M", "M", "M"), "M", "M", "M", "M");
                            i = (char *)&i[0] + 1;
                        } while (i < v0);
                    }
                }
                sub_7e91(0x1e200, 40, v9, "M", "M", "M", "M");
                sub_7e91(0x1e200, 9, v9, "M", "M", "M", "M");
            }
        } while ((v1 += 1, v1 < v3));
    }
    sub_7e91(0x1e200, 9, idx[1], "M", "M", "M", "M");
    sub_7e91(0x1e200, 9, idx[5], "M", "M", "M", "M");
    sub_7e91(0x1e200, 9, idx[10], "M", "M", "M", "M");
    sub_7e91(0x1e200, 9, idx[11], "M", "M", "M", "M");
    return sub_7e91(0x1e200, 9, idx, "M", "M", "M", "M");
}


/* ===== sub_8d5 @ 0x8d5, size=670, cc=39 ===== */
typedef struct struct_0 {
    char padding_0[8];
    int field_8;
} struct_0;

typedef struct struct_2 {
    char field_0;
    char padding_1[11];
    unsigned int field_c;
    unsigned int field_10;
    char padding_14[16];
    unsigned int field_24;
    char padding_28[40];
    unsigned int field_50;
} struct_2;

typedef struct struct_1 {
    char padding_0[20];
    int field_14;
} struct_1;

extern char g_1;
extern char g_10;
extern int g_13;
extern char g_14;
extern char g_18;
extern char g_21;
extern char g_24;
extern int g_2e;
extern int g_36;
extern int g_4;
extern int g_44;
extern int g_45;
extern int g_46;
extern char g_50;
extern int g_67;
extern char g_78;
extern int g_7f;
extern char g_80;
extern char g_8c;
extern char g_c;
extern char g_ff;

int sub_8d5(struct_0 *a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8, unsigned int a9, unsigned int a10, unsigned int a11, unsigned int a12, unsigned int a13, unsigned int a14, unsigned int a15, unsigned int a16, unsigned int a17)
{
    int v0;  // r6
    struct_2 *idx;  // r5
    unsigned int v2;  // r9
    struct_1 *index;  // r0

    v0 = sub_0;
    sub_7e91(0x1e200, 0x44, a0, "M");
    sub_7e91(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M");
    sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
    a12 = sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
    a11 = sub_7e91(0x1e200, 19, "M", "M", "M", "M", "M");
    if (a12 > sub_0)
    {
        while (true)
        {
            a9 = sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
            a10 = sub_7e91(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") & 0xff;
            idx = sub_7d75(a9, a10, sub_7e91(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") & 0xff);
            switch (a9)
            {
            case 3:
                sub_8445(a0, idx);
                break;
            case 4:
                *((char *)(sub_20 + idx)) = sub_7e91(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M");
                break;
            case 7:
                sub_83b5(a0, idx);
                break;
            case 8:
                sub_8309(a0, idx);
                break;
            case 9:
                sub_8a51(a0, idx);
                break;
            case 11:
                idx->field_24 = sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
                break;
            case 12:
                idx->padding_14[13] = sub_7e91(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M");
                break;
            case 13:
                sub_88b5(a0, idx);
                goto LABEL_f45;
            case 14:
                sub_89e1(a0, idx);
                goto LABEL_f45;
            case 16:
                sub_8509(a0, idx);
                break;
            case 17:
                idx->field_50 = sub_7e91(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
                break;
            case 18:
                a8 = sub_7e91(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") & 0xff;
                idx->field_10 = sub_7e91(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") & 0xff;
                idx->field_c = a8;
                break;
            case 19:
                sub_856d(a0, idx);
                goto LABEL_f45;
            case 20:
                sub_86b5(a0, idx);
                goto LABEL_f45;
            case 21:
                sub_8781(a0, idx);
                goto LABEL_f45;
            case 22:
                sub_8915(a0, idx);
            case 0:
                sub_884d(a0, idx);
            case 1: case 2: case 5: case 6: case 10: case 15:
                goto LABEL_f45;
            default:
                break;
            }
LABEL_f45:
            sub_7e91(0x1e200, 54, a11, idx, "M", "M", "M");
            v0 += 1;
            if (a12 <= v0)
                break;
        }
    }
    sub_7e91(0x1e200, 127, "M", "M", "M", "M", "M");
    sub_7e91(0x1e200, 103, 46, "M", "M", "M", "M");
    index = 140 + v2;
    index->field_14 = a11;
    *((void* *)&index[1].padding_0[0]) = sub_0;
    *((void* *)(index + sub_1c)) = sub_0;
    *((char *)(140 + v2 - 120)) = 1;
    return sub_a115(4, 140 + v2 - 128);
}


/* ===== sub_9175 @ 0x9175, size=590, cc=34 ===== */
typedef struct struct_0 {
    char padding_0[100];
    int field_64;
} struct_0;

extern char g_1;
extern int g_12;
extern char g_14;
extern int g_26;
extern int g_27;
extern int g_28;
extern char g_30;
extern char g_38;
extern char g_3c;
extern char g_44;
extern char g_54;
extern char g_58;
extern char g_5c;
extern char g_60;
extern char g_64;
extern char g_68;
extern int g_8a;
extern int g_9;

int sub_9175(struct_0 *idx)
{
    int i;  // r7
    int v3;  // r6
    int j;  // r5
    int v6;  // r1
    int v7;  // r2
    int v8;  // r3
    int v0;  // [bp-0x1c]
    int v1;  // [bp-0x18]

    if (idx->field_64)
    {
        sub_93c5(idx->field_64);
        sub_7e91(0x1e200, 9, idx->field_64, "M", "M", "M", "M");
        idx->field_64 = sub_0;
    }
    if (*((int *)&idx[1].padding_0[0]))
    {
        sub_7e91(0x1e200, 9, *((int *)&idx[1].padding_0[0]), "M", "M", "M", "M");
        *((void* *)&idx[1].padding_0[0]) = sub_0;
    }
    if (*((int *)&idx->padding_0[96]))
        sub_7e91(0x1e200, 18, *((int *)&idx->padding_0[96]), "M", "M", "M", "M");
    if (*((int *)&idx->padding_0[84]))
        sub_7e91(0x1e200, 18, *((int *)&idx->padding_0[84]), "M", "M", "M", "M");
    if (*((int *)&idx->padding_0[88]))
        sub_7e91(0x1e200, 18, *((int *)&idx->padding_0[88]), "M", "M", "M", "M");
    if (*((int *)&idx->padding_0[92]))
        sub_7e91(0x1e200, 18, *((int *)&idx->padding_0[92]), "M", "M", "M", "M");
    if (*((int *)&idx->padding_0[48]))
    {
        i = sub_0;
        v1 = sub_7e91(0x1e200, 38, *((int *)&idx->padding_0[48]), "M", "M", "M", "M");
        if (v1 > sub_0)
        {
            do
            {
                v3 = sub_7e91(0x1e200, 39, *((int *)&idx->padding_0[48]), i, "M", "M", "M");
                j = sub_0;
                v0 = sub_7e91(0x1e200, 38, v3, "M", "M", "M", "M");
                if (v0 > sub_0)
                {
                    do
                    {
                        sub_99f5(sub_7e91(0x1e200, 39, v3, j, "M", "M", "M"), v6, v7, v8, "M", "M", "M");
                        j += 1;
                    } while (j < v0);
                }
                sub_7e91(0x1e200, 40, v3, "M", "M", "M", "M");
                sub_7e91(0x1e200, 9, v3, "M", "M", "M", "M");
                i += 1;
            } while (i < v1);
        }
        sub_7e91(0x1e200, 40, *((int *)&idx->padding_0[48]), "M", "M", "M", "M");
        sub_7e91(0x1e200, 9, *((int *)&idx->padding_0[48]), "M", "M", "M", "M");
    }
    if (*((int *)&idx->padding_0[20]))
        sub_7e91(0x1e200, 18, *((int *)&idx->padding_0[20]), "M", "M", "M", "M");
    if (*((int *)&idx->padding_0[0x44]))
        sub_7e91(0x1e200, 9, *((int *)&idx->padding_0[0x44]), "M", "M", "M", "M");
    if (*((int *)&idx->padding_0[56]))
        sub_7e91(0x1e200, 9, *((int *)&idx->padding_0[56]), "M", "M", "M", "M");
    if (*((int *)&idx->padding_0[60]))
        sub_7e91(0x1e200, 138, *((int *)&idx->padding_0[60]), "M", "M", "M", "M");
    return sub_7e91(0x1e200, 9, idx, "M", "M", "M", "M");
}


/* ===== sub_a305 @ 0xa305, size=496, cc=34 ===== */
typedef struct struct_3 {
    char padding_0[8];
    char field_8;
} struct_3;

typedef struct struct_1 {
    char padding_0[148];
    int field_94;
    int field_98;
    unsigned int field_9c;
    char padding_a0[4];
    int field_a4;
    char padding_a8[40];
    struct struct_0 *field_d0;
    struct struct_2 *field_d4;
} struct_1;

typedef struct struct_0 {
    char padding_0[16];
    unsigned int field_10;
} struct_0;

typedef struct struct_2 {
    int field_0;
} struct_2;

extern char g_1;
extern char g_10;
extern int g_11;
extern char g_12;
extern char g_14;
extern char g_18;
extern char g_24;
extern int g_26;
extern int g_27;
extern char g_33;
extern int g_34;
extern int g_4;
extern char g_40;
extern char g_48;
extern char g_4c;
extern char g_50;
extern char g_54;
extern char g_6;
extern char g_80;
extern int g_9d;
extern int g_b1e4;
extern char g_c;

int sub_a305(void)
{
    unsigned int v1;  // r9
    unsigned int v2;  // r4
    struct_1 *index;  // r4
    unsigned int v12;  // r0
    unsigned int v13;  // r0
    int v14;  // r0
    int v15;  // r0
    int v16;  // r1
    unsigned int v17;  // r1
    int v18;  // r2
    int v19;  // r3
    int v20;  // r1
    unsigned int v3;  // r0
    unsigned int v21;  // r0
    unsigned int v22;  // r2
    unsigned int v23;  // r1
    unsigned int v24;  // r0
    unsigned int idx;  // r1
    struct_3 *idx1;  // r6
    unsigned int v6;  // r4
    unsigned int v7;  // r0
    unsigned int v8;  // r4
    unsigned int v9;  // r0
    unsigned int v10;  // r0
    unsigned int v0;  // [bp-0x18]

    if (*((int *)(12 + v1 + 80)))
    {
        v0 = 1;
        v2 = sub_0;
        v3 = sub_7e91(0x1e200, 0x11, *((int *)(12 + v1 + 80)), 4, "M", "M", "M");
        if (v3 > sub_0)
        {
            do
            {
                if (*((int *)(*((int *)(*((int *)(12 + v1 + 80)) + v2 * 4)) + 4)))
                    return v3;
            } while ((v2 += 1, v2 < v3));
            if (!v0)
                return v0;
        }
        idx = 12 + v1;
        *((void* *)(idx + 80)) = sub_0;
        *((char *)(8 + idx)) = 1;
    }
    idx1 = 12 + v1;
    if (*((int *)&idx1[8].padding_0[4]))
    {
        v0 = 1;
        v6 = sub_0;
        v7 = sub_7e91(0x1e200, 0x11, *((int *)&idx1[8].padding_0[4]), 4, "M", "M", "M");
        if (v7 > sub_0)
        {
            do
            {
                if (*((int *)(8 + *((int *)(*((int *)&idx1[8].padding_0[4]) + v6 * 4)))))
                    return v7;
            } while ((v6 += 1, v6 < v7));
            if (!v0)
                return v0;
        }
        *((void* *)&idx1[8].padding_0[4]) = sub_0;
        *((char *)(idx1 + _start)) = 1;
    }
    if (*((int *)&idx1[8].padding_0[0]))
    {
        v0 = 1;
        v8 = sub_0;
        v9 = sub_7e91(0x1e200, 0x11, *((int *)&idx1[8].padding_0[0]), 4, "M", "M", "M");
        if (v9 > sub_0)
        {
            do
            {
                if (*((int *)*((int *)(*((int *)&idx1[8].padding_0[0]) + v8 * 4))))
                    return v9;
            } while ((v8 += 1, v8 < v9));
            if (!v0)
                return v0;
        }
        *((void* *)&idx1[8].padding_0[0]) = sub_0;
        *((char *)(idx1 + _start)) = 1;
    }
    else
    {
        v10 = *((char *)(idx1 + _start));
        if (!v10)
            return v10;
    }
    index = 12 + v1 + 128;
    if (*((int *)(index + sub_1c)) > sub_0)
    {
        v12 = *((int *)(index + sub_1c)) - 1;
        *((unsigned int *)(index + sub_1c)) = v12;
        return v12;
    }
    while (true)
    {
        v13 = *((char *)(idx1 + _start));
        if (v13 != 1)
            return v13;
        if (*((int *)(index + sub_1c)) > sub_0)
            return *((int *)(index + sub_1c));
        v14 = sub_7e91(0x1e200, 38, *((int *)&index->padding_0[20]), "M", "M", "M", "M");
        if (v14 <= *((int *)&index->padding_0[24]))
            break;
        v15 = sub_7e91(0x1e200, 39, *((int *)&index->padding_0[20]));
        *((void* *)(idx1 + _start)) = sub_0;
        v16 = *((int *)&index->padding_0[24]);
        *((int *)&index->padding_0[36]) = v15;
        v17 = v16 + 1;
        *((unsigned int *)&index->padding_0[24]) = v17;
        sub_1665(v15, v17, v18, v19, "M", "M", "M");
    }
    *((void* *)&idx1[8].padding_0[0]) = sub_0;
    v20 = 12 + v1;
    *((void* *)v20) = sub_0;
    sub_9421("M", v20);
    sub_a0d1(*((int *)*((int *)&index->padding_0[80])));
    sub_a0d1(*((int *)*((int *)&index->padding_0[84])));
    v21 = *((int *)(12 + v1 + 64)) - 1;
    *((unsigned int *)(12 + v1 + 64)) = v21;
    v22 = *((int *)*((int *)&index->padding_0[80]));
    v23 = *((int *)(*((int *)*((int *)&index->padding_0[80])) + *((int *)(*((int *)&index->padding_0[80]) + 16)) * 4));
    if (!(v23 && !((v22 = (unsigned int)(char)*((char *)(0x33 + v23)), v22 != 1))))
    {
        sub_a035(v21, v23, v22);
        sub_7e91(0x1e200, 157, 0xb1e4, "M", "M", "M", "M");
    }
    else if (v21 > sub_0)
    {
        sub_6781(v23);
    }
    else
    {
        sub_7e91(0x1e200, 52, "M", "M", "M", "M", "M");
        sub_9d8d(1);
    }
    if (!idx1[2].padding_0[0])
        *((void* *)&idx1->padding_0[6]) = sub_0;
    v24 = *((int *)&idx1[7].padding_0[1]);
    if (sub_0 < v24)
        return v24;
    *((void* *)&idx1[7].padding_0[1]) = sub_0;
    return v24;
}


/* ===== sub_4011 @ 0x4011, size=688, cc=31 ===== */
typedef struct struct_1 {
    char padding_0[24];
    unsigned int field_18;
    char padding_1c[96];
    struct struct_0 *field_7c;
} struct_1;

typedef struct struct_0 {
    char padding_0[28];
    unsigned int field_1c;
} struct_0;

extern char g_1;
extern char g_10;
extern char g_14;
extern char g_18;
extern char g_19;
extern char g_1f;
extern int g_2;
extern char g_24;
extern int g_26;
extern int g_27;
extern int g_2a;
extern char g_3;
extern char g_30;
extern char g_32;
extern char g_33;
extern int g_38;
extern char g_4;
extern char g_46;
extern int g_5;
extern int g_6e;
extern char g_7c;
extern char g_8c;
extern char g_9;
extern int g_9b;
extern char g_a;
extern char g_b;
extern int g_e1;
extern char g_f;
extern char g_ff;

int sub_4011(unsigned int *idx, unsigned int a1, int a2, int a3, int a4, int a5)
{
    int v11;  // r5
    struct_1 *v12;  // r4
    int v21;  // r0
    int v22;  // r7
    int v23;  // r5
    unsigned int v24;  // r0
    unsigned int v25;  // r6
    unsigned int v26;  // r1
    unsigned int v27;  // r7
    int v28;  // r2
    int v29;  // r3
    unsigned int v13;  // r6
    unsigned int v31;  // r0
    unsigned int v14;  // r9
    unsigned int v15;  // r0
    unsigned int v16;  // r0
    char v19[21];  // r4
    unsigned int v20;  // r6
    unsigned int v0;  // [bp-0x5c]
    int v1;  // [bp-0x44]
    char v2;  // [bp-0x40]
    unsigned int i;  // [bp-0x3c]
    unsigned int v4;  // [bp-0x38]
    unsigned int v5;  // [bp-0x34]
    unsigned int v6;  // [bp-0x30]
    int v7;  // [bp-0x2c]
    unsigned int v8;  // [bp-0x28]
    unsigned int v9[10];  // [bp-0x24]
    unsigned int v10;  // [bp-0x20]

    v9 = idx;
    v10 = a1;
    v11 = a4;
    v8 = a1 * 4;
    v12 = *((int *)(*(idx) + v8));
    v7 = sub_7e91(0x1e200, 110, *((int *)(v12->field_7c + sub_1c)), "M", "M", "M", "M");
    v4 = sub_0;
    v6 = sub_0;
    v5 = sub_0;
    v13 = *((int *)(idx[9] + v8));
    if (v13 && *((char *)(v13 + 1)) == *((int *)(140 + v14 + 48)))
    {
        v6 = 1;
        v15 = sub_7e91(0x1e200, 56, sub_651d(v13), "M", "M", "M", "M");
        v16 = v15 * 2 - *((char *)v13);
        if (*((char *)(v13 + 9)) != 255 && (v16 >> 31) + v16 >> 1 >= *((char *)(v13 + 9)))
        {
            i = (sub_7e91(0x1e200, 3, 2, "M", "M", "M", "M") ? ~(sub_0) : 1);
            v5 = i * sub_7e91(0x1e200, 3, 3, "M", "M", "M", "M");
            i = (sub_7e91(0x1e200, 3, 2, "M", "M", "M", "M") ? ~(sub_0) : 1);
            v4 = i * sub_7e91(0x1e200, 3, 3, "M", "M", "M", "M");
        }
    }
    sub_46cd(v12, v7, a3 + v5, v11 + v4, a2, a5, (*((int *)(140 + v14)) == 4 ? sub_0 : (*((int *)(140 + v14)) == 5 ? sub_0 : 1)));
    if (v6 == 1)
    {
        v19 = *((int *)(idx[9] + v8));
        v20 = *((int *)&v19[4]);
        sub_a261(v19, v8);
        if (v20)
        {
            sub_7e91(0x1e200, 42, v20, "M", "M", &i, &v2);
            v21 = (i + 10 >> 31) + i + 10 >> 1;
            v22 = v11 - 70;
            v23 = a3 - v21;
            if (a3 < v21)
            {
                v23 = 5;
            }
            else if (v23 + i + 10 >= sub_7e91(0x1e200, sub_1c, "M", "M", "M", "M", "M"))
            {
                v23 = sub_7e91(0x1e200, sub_1c, "M", "M", "M", "M", "M") - (i + 15);
            }
            v0 = v20;
            v1 = sub_0;
            sub_7e91(0x1e200, 155, &v0, "M", "M", "M", "M", v0, 0xff, 0xff, 0xff, v23, v22, v1);
            v11 = v22 + 70;
        }
        return sub_581d(v19, a3, v11, v19[20], v19[11]);
    }
    else
    {
        v24 = v12->padding_1c[23];
        if (!v24)
        {
            return v24;
        }
        else if (!v12->field_18)
        {
            return v24;
        }
        else
        {
            i = sub_7e91(0x1e200, 38, v12->field_18, "M", "M", "M", "M");
            v25 = sub_0;
            v27 = v26;
            if (sub_91c(i, v26, v28, v29, "M", "M", "M"))
                v27 += 1;
            if (sub_0 >= v27)
                v27 = 1;
            sub_8dc(sub_7e91(0x1e200, 225, 39, "M", "M", "M", "M"), v26, v28, v29, "M", "M", "M");
            sub_20(v27);
            while (i > v25 + v26)
            {
                v31 = sub_5771(sub_7e91(0x1e200, 39, v12->field_18), v25 * 16 + a3 - 25, v11 - 50, v29, "M", "M", "M");
                v25 += 1;
                if (v25 >= 3)
                    return v31;
            }
            return i;
        }
    }
}


/* ===== sub_3879 @ 0x3879, size=550, cc=28 ===== */
typedef struct struct_0 {
    int field_0;
    char padding_4[16];
    unsigned int field_14;
    char padding_18[8];
    unsigned int field_20;
    unsigned int field_24;
    unsigned int field_28;
    unsigned int field_2c;
} struct_0;

typedef struct struct_5 {
    char padding_0[72];
    unsigned short field_48;
    unsigned short field_4a;
    char padding_4c[48];
    struct struct_4 *field_7c;
} struct_5;

typedef struct struct_1 {
    char padding_0[92];
    int field_5c;
} struct_1;

typedef struct struct_2 {
    char padding_0[44];
    int field_2c;
} struct_2;

typedef struct struct_3 {
    char padding_0[52];
    unsigned int field_34;
} struct_3;

typedef struct struct_4 {
    char padding_0[28];
    unsigned int field_1c;
} struct_4;

extern unsigned int g_1;
extern int g_11;
extern char g_14;
extern char g_19;
extern char g_2;
extern int g_23;
extern char g_24;
extern char g_28;
extern char g_2c;
extern int g_2f;
extern char g_3;
extern int g_32;
extern char g_34;
extern int g_4;
extern char g_48;
extern char g_4a;
extern char g_5;
extern char g_5c;
extern char g_60;
extern int g_6e;
extern int g_74;
extern char g_7c;
extern char g_8c;
extern char g_ac;

struct_0 * sub_3879(struct_0 *idx, unsigned int a1, unsigned int a2, int a3, unsigned int a4, int a5)
{
    struct_0 *v15;  // r4
    struct_0 *v16;  // r0
    struct_2 *v25;  // r1
    struct_3 *v26;  // r1
    unsigned int v18;  // r0
    int v19;  // r0
    unsigned int v20;  // r0
    int v21;  // r7
    int v22;  // r6
    unsigned int v23;  // r9
    struct_1 *v24;  // r1
    int v0;  // [bp-0x58]
    int v1;  // [bp-0x54]
    int v2;  // [bp-0x50]
    int v3;  // [bp-0x4c]
    struct_5 *v4;  // [bp-0x48]
    struct_0 *v5;  // [bp-0x44]
    struct_0 *v6;  // [bp-0x40]
    int v7;  // [bp-0x3c]
    int v8;  // [bp-0x38]
    int v9;  // [bp-0x34]
    int v10;  // [bp-0x30]
    unsigned int v11;  // [bp-0x2c]
    unsigned int v12;  // [bp-0x28]
    struct_0 *v13;  // [bp-0x24]
    int v14;  // [bp-0x18]

    v13 = idx;
    v14 = a3;
    v15 = sub_0;
    v5 = sub_0;
    v16 = idx;
    if (v16)
    {
        v6 = sub_7e91(0x1e200, 0x11, idx->field_0, 4, "M", "M", "M");
        if (a1 != 4294967295)
            v5 = v6;
        v16 = v6;
        if (v16 > sub_0)
        {
            v18 = ~(sub_0);
            if (a1 != v18)
                v18 = 1;
            v12 = v18;
            while (true)
            {
                v11 = v15 * 4;
                v4 = *((int *)(idx->field_0 + v11));
                if (!*((int *)(idx->field_0 + v11)))
                    goto LABEL_3a89;
                v19 = sub_7e91(0x1e200, 110, *((int *)(v4->field_7c + sub_1c)), "M", "M", "M", "M");
                sub_7e91(0x1e200, 116, v19, v4->field_48, v4->field_4a, "M", "M");
                v20 = v15 * 2;
                v21 = v14 + 50;
                v22 = *((short *)(idx->field_14 + v20)) * v12 + a2;
                *((short *)(idx->field_28 + v20)) = v22;
                *((short *)(idx->field_2c + v20)) = v21;
                if (*((int *)(140 + v23)) == 5)
                {
                    if (*((int *)(idx->field_24 + v11)))
                    {
                        sub_4011(idx, v15, a1, v22, v21, a5);
                    }
                    else if (v4[1].padding_0[44] == 1)
                    {
                        sub_4011(idx, v15, a1, v22, v21, a5);
                    }
                    if (*((int *)(*((int *)(idx + sub_20)) + v11)))
                    {
                        v0 = v21;
                        sub_3aa5(idx, v15);
                    }
                    goto LABEL_3a89;
                }
                sub_4011(idx, v15, a1, v22, v21, a5);
                v0 = v21;
                sub_3aa5(idx, v15);
                v24 = 140 + v23;
                if (*((int *)&v24->padding_0[0]) != 2 && *((int *)&v24->padding_0[0]) == 3)
                {
                    v3 = v5 + v15;
                    if (v3 >= v24->field_5c && *((int *)&v24[1].padding_0[0]) > v3)
                    {
                        v9 = v22 - 25;
                        v10 = v21 - 50;
                        if (sub_7e91(0x1e200, 47, v9, v10, 50, 50, "M") == 1)
                        {
                            v25 = 140 + v23;
                            if (v25->field_2c - (char *)v5 == v15)
                            {
                                v0 = v10;
                                v1 = 50;
                                v2 = 50;
                                sub_7e91(0x1e200, 35, 4, v9);
                                goto LABEL_3a1f;
                            }
                            else
                            {
                                v25->field_2c = v3;
                                goto LABEL_3a1f;
                            }
                        }
                    }
                }
                v7 = v22 - 25;
                v8 = v21 - 50;
                if (sub_7e91(0x1e200, 47, v7, v8, 50, 50, "M") == 1)
                {
                    v26 = 140 + v23;
                    if (v26->field_34 - (char *)v5 == v15)
                    {
                        sub_7e91(0x1e200, 35, 4, v7, v8, 50, 50);
                        goto LABEL_3a1f;
                    }
                    else
                    {
                        v26->field_34 = v5 + v15;
LABEL_3a27:
                        sub_42c5(idx, v15, a1, v22, v21);
LABEL_3a89:
                        v15 = (char *)&v15->field_0 + 1;
                        v14 += a4;
                        if (v6 <= v15)
                            break;
                    }
                }
                else
                {
LABEL_3a1f:
                    goto LABEL_3a27;
                }
            }
            return v6;
        }
    }
    return v16;
}


/* ===== sub_2e89 @ 0x2e89, size=662, cc=25 ===== */
typedef struct struct_1 {
    char padding_0[52];
    int field_34;
    char padding_38[24];
    struct struct_0 *field_50;
    struct struct_0 *field_54;
} struct_1;

typedef struct struct_0 {
    int field_0;
    char padding_4[4];
    unsigned int field_8;
    char padding_c[28];
    unsigned int field_28;
    unsigned int field_2c;
    unsigned int field_30;
} struct_0;

typedef struct struct_3 {
    char padding_0[12];
    unsigned int field_c;
} struct_3;

extern int g_1;
extern unsigned int g_100;
extern int g_11;
extern char g_14;
extern int g_18;
extern int g_1d;
extern char g_1e;
extern char g_1f;
extern char g_2;
extern int g_24;
extern int g_27;
extern char g_28;
extern char g_2c;
extern char g_3;
extern char g_30;
extern char g_34;
extern int g_4;
extern int g_4a;
extern char g_50;
extern char g_54;
extern int g_86;
extern char g_8c;
extern int g_9b;
extern char g_a;
extern char g_b0dc;
extern char g_c;
extern int g_e1;
extern unsigned int g_ff;

int sub_2e89(void)
{
    unsigned int v11;  // r9
    struct_1 *v12;  // r4
    unsigned int v21;  // r7
    struct_3 *v24;  // r0
    int v13;  // r0
    int v14;  // r2
    int v15;  // r3
    struct_0 *v16;  // r4
    struct_0 *v17;  // r4
    unsigned int v18;  // r1
    unsigned int v19;  // r6
    unsigned int v20;  // r0
    unsigned int v0;  // [bp-0x40]
    unsigned int v1;  // [bp-0x3c]
    unsigned int v2;  // [bp-0x38]
    unsigned int v3;  // [bp-0x34], Other Possible Types: int
    unsigned int v4;  // [bp-0x30], Other Possible Types: int
    unsigned int v5;  // [bp-0x2c]
    int v6;  // [bp-0x28], Other Possible Types: unsigned int
    int v7;  // [bp-0x24], Other Possible Types: unsigned int
    char v8;  // [bp-0x20], Other Possible Types: int
    unsigned int v9;  // [bp-0x1c]
    unsigned int v10;  // [bp-0x18]

    v12 = 140 + v11;
    v13 = sub_7e91(0x1e200, 0x11, v12->field_50->field_0, 4, "M", "M", "M");
    v16 = (sub_20(v13, v12->field_34, v14, v15, "M", "M", "M") ? v12->field_54 : v12->field_50);
    v17 = v16;
    v19 = v18 * 4;
    if (!*((int *)(v17->field_0 + v19)))
        return *((int *)(v17->field_0 + v19));
    v20 = v18 * 2;
    v9 = *((short *)(v17->field_28 + v20));
    v21 = *((short *)(v17->field_2c + v20));
    if (v17->field_30 == -1)
    {
        v0 = sub_7e91(0x1e200, 225, 74, "M", "M", "M", "M");
        sub_91c(sub_7e91(0x1e200, 225, 39, "M", "M", "M", "M"), v18, v14, v15, "M", "M", "M");
        v4 = sub_0;
        v1 = (v18 - ((v18 >> 31) + v18 >> 1) * 2) * 3 + v9;
        v2 = v21 - 30;
        v3 = sub_0;
        v5 = *((short *)(8 + sub_7e91(0x1e200, 225, 74, "M", "M", "M", "M")));
        v6 = *((short *)(sub_7e91(0x1e200, 225, 74, "M", "M", "M", "M") + 10));
        v7 = 0x100;
        v8 = sub_0;
        sub_7e91(0x1e200, sub_20, &v0, "M", "M", "M", "M");
    }
    else
    {
        v0 = sub_7e91(0x1e200, 225, 74, "M", "M", "M", "M");
        sub_91c(sub_7e91(0x1e200, 225, 39, "M", "M", "M", "M"), v18, v14, v15, "M", "M", "M");
        v10 = (v18 - ((v18 >> 31) + v18 >> 1) * 2) * 3 + v9;
        v4 = sub_0;
        v1 = v10 - *((short *)(8 + sub_7e91(0x1e200, 225, 74, "M", "M", "M", "M")));
        v2 = v21 - 30;
        v3 = sub_0;
        v5 = *((short *)(8 + sub_7e91(0x1e200, 225, 74, "M", "M", "M", "M")));
        v6 = *((short *)(sub_7e91(0x1e200, 225, 74, "M", "M", "M", "M") + 10));
        v7 = sub_0;
        v8 = sub_0;
        sub_7e91(0x1e200, sub_20, &v0, "M", "M", "M", "M");
    }
    sub_7e91(0x1e200, 134, *((int *)(v17->field_0 + v19)), v17->field_30, 1, "M", "M");
    sub_7e91(0x1e200, 36, "M", 1, "M", "M", "M");
    if (!*((int *)(*((int *)(v17 + _start)) + v19)))
        return *((int *)(*((int *)(v17 + _start)) + v19));
    v24 = sub_7e91(0x1e200, 225, 24, "M", "M", "M", "M");
    if (v24->field_c == *((int *)(8 + *((int *)(*((int *)(v17 + _start)) + v19)))))
        return v24->field_c;
    v2 = 45276;
    v4 = 0xff;
    v5 = 0xff;
    v3 = 0xff;
    v6 = sub_0;
    v7 = sub_7e91(0x1e200, 29, "M", "M", "M", "M", "M") - 20;
    sub_91c(sub_7e91(0x1e200, 225, 39, "M", "M", "M", "M"), v18, v14, v15, "M", "M", "M");
    v8 = v18 - ((v18 >> 31) + v18 >> 1) * 2;
    return sub_7e91(0x1e200, 155, &v2, "M", "M", "M", "M");
}


/* ===== sub_54dd @ 0x54dd, size=650, cc=25 ===== */
typedef struct struct_0 {
    char padding_0[40];
    unsigned int field_28;
} struct_0;

typedef struct struct_1 {
    char padding_0[24];
    unsigned int field_18;
} struct_1;

extern int g_1;
extern int g_11;
extern int g_124;
extern int g_125;
extern int g_126;
extern int g_12a;
extern char g_14;
extern char g_18;
extern int g_19;
extern int g_1d;
extern int g_24;
extern char g_28;
extern int g_2a;
extern char g_2c;
extern int g_32;
extern int g_34;
extern int g_4;
extern int g_4c;
extern int g_53;
extern int g_56;
extern unsigned int g_6e;
extern int g_85;
extern int g_86;
extern int g_87;
extern char g_8c;
extern char g_b2e4;
extern int g_c6;
extern int g_e1;
extern int g_ed;
extern unsigned int g_ff;

int sub_54dd(void)
{
    unsigned int v13;  // r0
    unsigned int v15;  // r9
    struct_0 *idx;  // r6
    unsigned int v17[2];  // r6
    unsigned int v18;  // r0
    unsigned int v0;  // [bp-0x48]
    unsigned int v1;  // [bp-0x44]
    unsigned int v2;  // [bp-0x40]
    unsigned int v3;  // [bp-0x3c]
    unsigned int v4;  // [bp-0x38]
    int v5;  // [bp-0x34], Other Possible Types: unsigned int
    int v6;  // [bp-0x30], Other Possible Types: unsigned int
    unsigned int v7;  // [bp-0x2c]
    unsigned int v8;  // [bp-0x28]
    unsigned int v9;  // [bp-0x24], Other Possible Types: int
    struct_1 *v10;  // [bp-0x20], Other Possible Types: unsigned int
    char v11;  // [bp-0x1c], Other Possible Types: unsigned int
    char v12;  // [bp-0x18], Other Possible Types: unsigned int

    sub_7e91(0x1e200, 294, "M", "M", "M", "M", "M");
    sub_7e91(0x1e200, 293, "M", "M", "M", "M", "M");
    v13 = sub_7e91(0x1e200, 225, 237, "M", "M", "M", "M");
    if (v13 <= sub_0)
        return v13;
    sub_7e91(0x1e200, 292, "M", "M", "M", "M", "M");
    sub_7e41("M", "M", "M");
    sub_7e91(0x1e200, 50, "M", "M", sub_7e91(0x1e200, sub_1c, "M", "M", "M", "M", "M"), 25, "M");
    sub_7e91(0x1e200, 42, 0xb2e4, "M", "M", &v12, &v11);
    v3 = 45796;
    v9 = sub_0;
    v4 = sub_7e91(0x1e200, sub_1c, "M", "M", "M", "M", "M", 0xb2e4) - (v12 + 20);
    v5 = 25 - v11 >> 1;
    v8 = 0xff;
    v10 = sub_0;
    v6 = 0xff;
    v7 = 0xff;
    sub_7e91(0x1e200, 86, &v3, "M", "M", "M", "M");
    idx = 140 + v15;
    if (!sub_7e91(0x1e200, 225, 83, "M", "M", "M", "M"))
    {
        sub_7e91(0x1e200, 52, "M", "M", "M", "M", "M");
        v0 = sub_0;
        v1 = sub_0;
        v2 = sub_0;
        return sub_7e91(0x1e200, 298, 198, idx->field_28);
    }
    v4 = idx->field_28;
    v5 = sub_0;
    v6 = 25;
    v7 = sub_7e91(0x1e200, sub_1c, "M", "M", "M", "M", "M");
    v8 = sub_7e91(0x1e200, 29, "M", "M", "M", "M", "M") - 135;
    v10 = 140 + v15 - 44;
    v9 = 1;
    sub_7e91(0x1e200, 135, &v4, "M", "M", "M", "M");
    if (sub_7e91(0x1e200, 0x11, *((int *)(140 + v15 + 40)), 4, "M", "M", "M") > sub_0)
    {
        v17 = *((int *)(idx->field_28 + *((int *)(140 + v15 - 44)) * 4));
        v18 = sub_7e91(0x1e200, 225, 83, "M", "M", "M", "M");
        v10 = *((int *)(v18 + v17[0] * 4));
        v3 = sub_0;
        v4 = sub_7e91(0x1e200, 29, "M", "M", "M", "M", "M", "M") - 110;
        v5 = v10->field_18;
        v6 = v17[0];
        v9 = 1;
        v7 = v17[1];
        v8 = 110;
        sub_7e91(0x1e200, 133, &v3, "M", "M", "M", "M");
    }
    else
    {
        sub_7e91(0x1e200, 134, sub_7e91(0x1e200, 225, 76, "M", "M", "M", "M"), -2, 1, "M", "M");
    }
    return sub_7e91(0x1e200, 36, 1, 1, "M", "M", "M");
}


/* ===== sub_4381 @ 0x4381, size=252, cc=24 ===== */
extern char g_1;
extern int g_11;
extern int g_3;
extern int g_4;
extern int g_5;
extern int g_6;
extern int g_7;
extern int g_9;
extern int g_a;
extern int g_b;
extern int g_c;
extern int g_d;
extern char g_e;

int sub_4381(int a0, int a1, int a2, unsigned int a3)
{
    int v4;  // r5
    int v5;  // r6
    int v14;  // r0
    int v15;  // r2
    int v16;  // r0
    int idx;  // r4
    int v7;  // r0
    int v8;  // r0
    int v12;  // r0
    int v13;  // r5
    unsigned int v0;  // [bp-0x30]
    unsigned int v1;  // [bp-0x28]
    int v2;  // [bp-0x24]
    int v3;  // [bp+0x0]

    v2 = a0;
    v4 = v3;
    v5 = sub_7e91(0x1e200, 0x11, a0, 4, "M", "M", "M");
    idx = sub_0;
    if (v5 <= 5)
    {
        if (v4 == 13 || v4 == 12)
        {
            v13 = _start;
        }
        else
        {
            if (v4 == 11 || v4 == 10)
            {
                v13 = 7;
            }
            else
            {
                if (v4 == 9 || v4 == _start)
                {
                    v13 = 6;
                }
                else
                {
                    if (v4 == 7 || v4 == 6)
                        v13 = 5;
                    else
                        v13 = 4;
                }
            }
        }
        if (v5 <= sub_0)
            return v5;
        do
        {
            if (v13 > idx + 3)
            {
                v15 = v13 - idx;
                if (9 > v15)
                {
                    v16 = v15;
                    if (v16 > 6)
                    {
                        v16 = 5;
                        if (v15 != 7)
                        {
                            v16 = 4;
                            if (v15 != _start)
                                v16 = 3;
                        }
                    }
                    v1 = a3 - v16 * 14;
                    sub_4611(a2, a1);
                    v0 = *((int *)(*((int *)(a0 + idx * 4)) + 4));
                    v14 = sub_447d(*((int *)*((int *)(a0 + idx * 4))));
                }
            }
        } while ((idx += 1, idx < v5));
        return v14;
    }
    else if (9 > v4)
    {
        v7 = sub_61f1(a0);
        v8 = v4;
        if (v8 > 6)
        {
            v8 = 5;
            if (v4 != 7)
            {
                v8 = 4;
                if (v4 != _start)
                    v8 = 3;
            }
        }
        v12 = v8;
        return sub_447d(v7, sub_4611(a2, a1, v4, v12 * 4), a3 - v12 * 10, v4, "M");
    }
    else
    {
        return v5;
    }
}


/* ===== sub_7b91 @ 0x7b91, size=474, cc=24 ===== */
typedef struct struct_0 {
    char padding_0[84];
    int field_54;
} struct_0;

typedef struct struct_1 {
    unsigned int field_0;
    unsigned int field_4;
    char padding_8[6];
    unsigned short field_e;
} struct_1;

typedef struct struct_2 {
    unsigned int field_0;
    char padding_4[17];
    char field_15;
    char field_16;
} struct_2;

extern int g_1;
extern int g_11;
extern int g_14;
extern char g_15;
extern char g_16;
extern char g_28;
extern int g_29;
extern char g_2c;
extern int g_33;
extern int g_4;
extern int g_4c;
extern int g_53;
extern int g_54;
extern int g_57;
extern char g_60;
extern int g_b310;
extern char g_e;
extern int g_e1;
extern int g_e6;

int sub_7b91(int a0)
{
    unsigned int v0;  // r9
    int v1;  // r5
    struct_2 *v10;  // r4
    unsigned int v11;  // r0
    struct_0 *v3;  // r5
    int v4;  // r0
    unsigned int v5;  // r0
    unsigned int *idx;  // r6
    unsigned int v7;  // r1
    unsigned int v8;  // r0
    struct_1 *v9;  // r5

    v1 = 96 + v0;
    switch (a0)
    {
    case 8: case 13:
        sub_7e91(0x1e200, 41, sub_7e91(0x1e200, 225, 84, "M", "M", "M", "M"), "M", v1, 1, "M");
        sub_7e91(0x1e200, 20, 87, "M", "M", "M", "M");
        return sub_7e91(0x1e200, 230, "M", "M", "M", "M", "M");
    case 5: case 17: case 20:
        v3 = 96 + v0 + 44;
        v4 = sub_7e91(0x1e200, 0x11, *((int *)&v3->padding_0[40]), 4, "M", "M", "M");
        if (v4 <= sub_0)
            return v4;
        v5 = sub_7e91(0x1e200, 225, 83, "M", "M", "M", "M");
        idx = 96 + v0 - 84;
        v7 = idx[21];
        if (*((char *)(*((int *)(v5 + *((int *)*((int *)(*((int *)&v3->padding_0[40]) + v7 * 4))) * 4)) + 20)))
        {
            v8 = sub_7e91(0x1e200, 225, 83, "M", "M", "M", "M");
            v9 = *((int *)(*((int *)&v3->padding_0[40]) + idx[21] * 4));
            v10 = *((int *)(v8 + v9->field_0 * 4));
            v11 = v10->field_16;
            sub_a1e9(v10, v9, sub_7e91(0x1e200, 225, 76, "M", "M", "M", "M", v9->field_0, v11, v10->field_15, v9->field_e));
            return sub_27b1(v10->field_0, v9->field_0, v9->field_4, v11, v10->field_15, v9->field_e, "M");
        }
        break;
        return sub_7e91(0x1e200, 0x33, 0xb310, "M", "M", "M", "M");
    case 2: case 12:
        sub_7e91(0x1e200, 41, sub_7e91(0x1e200, 225, 84, "M", "M", "M", "M"), "M", v1, "M", "M");
        sub_7e91(0x1e200, 20, 87, "M", "M", "M", "M");
        return sub_7e91(0x1e200, 230, "M", "M", "M", "M", "M");
    case 18:
        return sub_9955();
    default:
        return a0;
    }
}


/* ===== sub_80c5 @ 0x80c5, size=276, cc=24 ===== */
typedef struct struct_4 {
    unsigned int field_0;
    struct struct_4 *field_4;
    unsigned int field_8;
    struct struct_4 *field_c;
    unsigned int field_10;
    unsigned int field_14;
    struct struct_4 *field_18;
} struct_4;

typedef struct struct_0 {
    char padding_0[8];
    struct struct_1 *field_8;
} struct_0;

typedef struct struct_1 {
    unsigned int field_0;
} struct_1;

extern char g_10;
extern char g_14;
extern char g_18;
extern char g_1b4;
extern char g_3;
extern char g_3e8;
extern char g_3e9;
extern char g_4;
extern char g_5;
extern struct_4 g_a;
extern char g_c;

struct_4 * sub_80c5(struct_4 *idx, struct_4 *a1, unsigned int a2, struct_4 *a3)
{
    unsigned int v2;  // r5
    unsigned int v3;  // r9
    struct_4 *iter;  // r0
    struct_0 *index;  // r7
    unsigned int v5;  // r0
    struct_4 *v6;  // r5
    struct_4 *v7;  // r0
    struct_4 *idx1;  // r1
    struct_4 *v9;  // r0
    struct_4 *idx2;  // r1
    struct_4 *v0;  // [bp-0x18]
    unsigned int v1;  // [bp+0x0]

    v0 = a3;
    v2 = ~(sub_0);
    if (!idx)
    {
        (*((int *)0x475052b5))("timer err:%d", 1000, *((int *)0x475052b5));
        return v2;
    }
    if (*((int *)*((int *)(8 + *((int *)0x475052a9)))) == 3 || *((int *)*((int *)(8 + *((int *)0x475052a9)))) == 4)
        return v2;
    if (idx->field_0 != 2041298127)
    {
        (*((int *)0x475052b5))("timer err:%d", 1001, *((int *)0x475052b5));
        return v2;
    }
    if (a1)
        idx->field_4 = a1;
    idx->field_10 = a2;
    *((void* *)(idx + _start)) = sub_0;
    if (a3)
        idx->field_c = a3;
    idx->field_14 = v1;
    if (sub_0 >= idx->field_4)
        return v2;
    if (10 > idx->field_4)
        idx->field_4 = 10;
    *((struct struct_4 **)(idx + _start)) = idx->field_4;
    index = 436 + v3;
    if (*((int *)&index[1].padding_0[4]))
    {
        v5 = (*((int *)0x475052d1))(*((int *)0x475052d1));
        v6 = *((int *)&index[1].padding_0[4]) - v5;
    }
    else
    {
        v6 = sub_0;
    }
    v7 = *((int *)(index + _start));
    if (v7 && sub_0 > v6)
        v6 = sub_0;
    if (v7 && v6 > (char *)&v7->field_4->field_4 + 1)
        v6 = v7->field_4;
    sub_8065(idx);
    idx1 = *((int *)(index + _start));
    if (idx1 && *((int *)(idx + _start)) >= v6)
    {
        *((struct_4 **)(idx + _start)) = *((int *)(idx + _start)) - (char *)v6;
    }
    else
    {
        v9 = *((int *)(idx + _start));
        *((void* *)(idx + _start)) = sub_0;
        if (idx1)
        {
            do
            {
                *((unsigned long *)(idx1 + _start)) = *((int *)(idx1 + _start)) + v6 - v9;
                idx1 = idx1->field_18;
            } while (idx1->field_18);
        }
        sub_81f1(v9);
    }
    idx2 = *((int *)(index + _start));
    if (!idx2)
    {
        *((struct_4 **)(index + _start)) = idx;
        idx->field_18 = sub_0;
    }
    else if (*((int *)(idx2 + _start)) > *((int *)(idx + _start)))
    {
        idx->field_18 = idx2;
        *((struct_4 **)(index + _start)) = idx;
    }
    else
    {
        for (iter = idx2->field_18; iter && *((int *)(iter + _start)) <= *((int *)(idx + _start)); iter = iter->field_18)
        {
            idx2 = iter;
        }
        idx2->field_18 = idx;
        idx->field_18 = iter;
    }
    return sub_0;
    return v2;
}


/* ===== sub_2009 @ 0x2009, size=470, cc=23 ===== */
typedef struct struct_0 {
    char padding_0[44];
    int field_2c;
    char padding_30[8];
    int field_38;
    unsigned int field_3c;
} struct_0;

extern char g_1;
extern char g_10;
extern int g_12;
extern int g_14;
extern char g_180;
extern int g_27;
extern int g_2c;
extern int g_34;
extern char g_38;
extern char g_3c;
extern int g_4;
extern int g_53;
extern char g_58;
extern int g_81;
extern int g_9;
extern int g_9c;
extern int g_a0;
extern char g_b2c0;
extern char g_b2d4;
extern char g_c;
extern char g_d0;
extern int g_e1;

int sub_2009(void)
{
    unsigned int v3;  // r9
    struct_0 *idx;  // r5
    unsigned int v5;  // r4
    int v6;  // r0
    int v8;  // r0
    int v9;  // r0
    int v10;  // r0
    int v0;  // [bp-0x20]
    int v1;  // [bp-0x1c]
    int v2;  // [bp-0x18]

    idx = 12 + v3;
    v5 = *((int *)(*((int *)&idx[1].padding_0[24]) + idx->field_3c * 4));
    if (!(*((int *)(384 + v3)))(v5, 0xb2c0, *((int *)(384 + v3))))
    {
        sub_7e91(0x1e200, 44, "M", "M", "M", "M", "M");
        sub_7e91(0x1e200, 44, "M", "M", "M", "M", "M");
        if (*((int *)&idx[1].padding_0[24]))
            sub_7e91(0x1e200, 18, *((int *)&idx[1].padding_0[24]), "M", "M", "M", "M");
        *((void* *)&idx[1].padding_0[24]) = sub_0;
        *((char *)(*((int *)(*((int *)*((int *)(12 + v3 + 208))) + *((int *)(*((int *)(12 + v3 + 208)) + 16)) * 4)) + 20)) = 1;
        sub_7e91(0x1e200, 52, "M", "M", "M", "M", "M");
        sub_9ca5(4, idx->field_38);
        if (idx->field_2c)
            sub_7e91(0x1e200, 9, idx->field_2c, "M", "M", "M", "M");
        idx->field_2c = sub_0;
        v6 = sub_7e91(0x1e200, 225, 83, "M", "M", "M", "M");
        if (!v6)
            return v6;
        sub_7e91(0x1e200, 160, sub_7e91(0x1e200, 225, 83, "M", "M", "M", "M"), "M", "M", "M", "M");
        v0 = sub_0;
        v1 = sub_0;
        v2 = sub_0;
        return sub_7e91(0x1e200, 20, 83, "M");
    }
    else if (!(*((int *)(384 + v3)))(v5, 0xb2d4, *((int *)(384 + v3))))
    {
        v8 = sub_7e91(0x1e200, 39, *((int *)(*((int *)(*((int *)(12 + v3 + 208)) + 4)) + *((int *)(*((int *)(12 + v3 + 208)) + 16)) * 4)), idx->field_38, "M", "M", "M");
        sub_7e91(0x1e200, 156, 18, "M", "M", "M", "M");
        return sub_7e91(0x1e200, 129, v8, "M", "M", "M", "M");
    }
    else
    {
        v9 = (*((int *)(384 + v3)))(v5, sub_b2cc, *((int *)(384 + v3)));
        if (v9)
            return v9;
        v10 = sub_7e91(0x1e200, 44, "M", "M", "M", "M", "M");
        if (*((int *)&idx[1].padding_0[24]))
            v10 = sub_7e91(0x1e200, 18, *((int *)&idx[1].padding_0[24]), "M", "M", "M", "M");
        *((void* *)&idx[1].padding_0[24]) = sub_0;
        return v10;
    }
}


/* ===== sub_721 @ 0x721, size=402, cc=22 ===== */
typedef struct struct_0 {
    char padding_0[52];
    unsigned int field_34;
} struct_0;

typedef struct struct_3 {
    unsigned int field_0;
    unsigned int field_4;
    char padding_8[44];
    int field_34;
    char padding_38[24];
    struct struct_4 *field_50;
} struct_3;

typedef struct struct_5 {
    char padding_0[8];
    unsigned int field_8;
} struct_5;

typedef struct struct_4 {
    int field_0;
} struct_4;

extern int g_1;
extern int g_11;
extern int g_118;
extern int g_14;
extern int g_18;
extern int g_2;
extern int g_3;
extern int g_34;
extern int g_4;
extern char g_50;
extern int g_81;
extern char g_8c;
extern char g_c;
extern int g_e1;

int sub_721(unsigned int a0)
{
    unsigned int v9;  // r4
    unsigned int v10;  // r5
    unsigned int v19;  // r1
    struct_0 *v20;  // r1
    struct_3 *v21;  // r5
    struct_5 *v22;  // r0
    unsigned int idx;  // r1
    int v24;  // r4
    unsigned int v25;  // r0
    unsigned int v11;  // r6
    unsigned int v12;  // r7
    unsigned int v13;  // lr
    unsigned int v14;  // r9
    unsigned int v15;  // r0
    struct_0 *index;  // r2
    unsigned int v17;  // r1
    struct_0 *idx1;  // r2
    int v0;  // [bp-0x28]
    int v1;  // [bp-0x24]
    int v2;  // [bp-0x20]
    int v3;  // [bp-0x18]
    unsigned int v4;  // [bp-0x14]
    unsigned int v5;  // [bp-0x10]
    unsigned int v6;  // [bp-0xc]
    unsigned int v7;  // [bp-0x8]
    unsigned int v8;  // [bp-0x4]

    v4 = v9;
    v5 = v10;
    v6 = v11;
    v7 = v12;
    v8 = v13;
    v15 = sub_7e91(0x1e200, 0x11, *((int *)*((int *)(140 + v14 + 80))), 4, "M", "M", "M");
    switch (a0)
    {
    case 2: case 12:
        index = 140 + v14;
        v17 = index->field_34;
        index->field_34 = v17 - 1;
        if (v17 < 1)
            index->field_34 = v15 * 2 - 1;
        sub_c61("M", 140 + v14 + 52, "M", v15 * 2);
    case 4: case 14:
        *((void* *)(140 + v14 + 52)) = sub_0;
        sub_c61(1, 140 + v14 + 52, "M", v15 * 2);
        break;
    case 5: case 20:
        sub_6269(*((int *)(140 + v14 + 52)));
        v2 = sub_0;
        v0 = sub_0;
        v1 = sub_0;
    case 6: case 15:
        v20 = 140 + v14;
        v20->field_34 = v15;
        sub_c61(1, &v20->field_34, "M", v15 * 2);
        break;
    case 8: case 13:
        idx1 = 140 + v14;
        v19 = idx1->field_34 + 1;
        idx1->field_34 = v19;
        if (v19 >= v15 * 2)
            idx1->field_34 = sub_0;
        sub_c61(1, 140 + v14 + 52, "M");
        break;
    case 17:
        v21 = 140 + v14;
        v3 = sub_7e91(0x1e200, 0x11, v21->field_50->field_0, 4, "M", "M", "M");
        v22 = sub_622d(v21->field_34);
        sub_20(v3, v21->field_34);
        v24 = *((int *)(*((int *)(v22 + _start)) + idx * 4));
        if (v24)
        {
            v25 = sub_7e91(0x1e200, 225, 24, "M", "M", "M", "M");
            if (*((int *)(v25 + 12)) != *((int *)(8 + v24)))
            {
                sub_7e91(0x1e200, 52, "M", "M", "M", "M", "M");
                sub_7e91(0x1e200, 20, 280, 3, "M", "M", "M");
                sub_7e91(123411, 2, *((int *)(v24 + 4)), *((int *)(8 + v24)), "M", "M", "M");
                break;
            }
            else
            {
                v21->field_0 = v21->field_4;
                break;
            }
        }
        else
        {
            sub_7e91(0x1e200, 129, sub_6269(v21->field_34), "M", "M", "M", "M");
            break;
        }
    case 18:
        *((int *)(140 + v14)) = *((int *)(140 + v14 + 4));
        break;
    }
}

