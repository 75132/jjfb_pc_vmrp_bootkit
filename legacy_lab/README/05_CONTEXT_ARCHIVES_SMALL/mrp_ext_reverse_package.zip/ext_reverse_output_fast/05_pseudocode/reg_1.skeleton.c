/* Skeleton recovered from function map for reg_1. Fill bodies from 02_disassembly. */
typedef int i32;

// addr=0x8, offset=0x8, mode=ARM, size=None, cc=None
i32 candidate_000008(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb, offset=0xa, mode=Thumb, size=None, cc=None
i32 candidate_00000a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3d, offset=0x3c, mode=Thumb, size=None, cc=None
i32 candidate_00003c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xc9, offset=0xc8, mode=Thumb, size=None, cc=None
i32 candidate_0000c8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11d, offset=0x11c, mode=Thumb, size=None, cc=None
i32 candidate_00011c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x169, offset=0x168, mode=Thumb, size=None, cc=None
i32 candidate_000168(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7a9, offset=0x7a8, mode=Thumb, size=None, cc=None
i32 candidate_0007a8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7c9, offset=0x7c8, mode=Thumb, size=None, cc=None
i32 candidate_0007c8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7f9, offset=0x7f8, mode=Thumb, size=None, cc=None
i32 candidate_0007f8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

