/* Skeleton recovered from function map for itembagshopmodule_1. Fill bodies from 02_disassembly. */
typedef int i32;

// addr=0x0, offset=0x0, mode=ARM, size=8, cc=1
i32 sub_0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8, offset=0x8, mode=ARM, size=20, cc=1
i32 _start(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c, offset=0x1c, mode=ARM, size=4, cc=1
i32 sub_1c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20, offset=0x20, mode=ARM, size=296, cc=7
i32 sub_20(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf4, offset=0xf4, mode=ARM, size=4, cc=1
i32 sub_f4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x109, offset=0x108, mode=Thumb, size=2, cc=1
i32 sub_109(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10b, offset=0x10a, mode=Thumb, size=2, cc=1
i32 sub_10b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x135, offset=0x134, mode=Thumb, size=58, cc=3
i32 sub_135(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x177, offset=0x176, mode=Thumb, size=6, cc=1
i32 sub_177(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18d, offset=0x18c, mode=Thumb, size=8, cc=1
i32 sub_18d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x195, offset=0x194, mode=Thumb, size=150, cc=18
i32 sub_195(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x231, offset=0x230, mode=Thumb, size=130, cc=1
i32 sub_231(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b5, offset=0x2b4, mode=Thumb, size=18, cc=1
i32 sub_2b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c8, offset=0x2c8, mode=ARM, size=16, cc=1
i32 sub_2c8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d8, offset=0x2d8, mode=ARM, size=8, cc=1
i32 sub_2d8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e0, offset=0x2e0, mode=ARM, size=8, cc=1
i32 sub_2e0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e8, offset=0x2e8, mode=ARM, size=28, cc=1
i32 sub_2e8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x305, offset=0x304, mode=Thumb, size=8, cc=1
i32 sub_305(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30d, offset=0x30c, mode=Thumb, size=182, cc=3
i32 sub_30d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3c5, offset=0x3c4, mode=Thumb, size=16, cc=1
i32 sub_3c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3d5, offset=0x3d4, mode=Thumb, size=84, cc=4
i32 sub_3d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x429, offset=0x428, mode=Thumb, size=132, cc=5
i32 sub_429(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ad, offset=0x4ac, mode=Thumb, size=316, cc=15
i32 sub_4ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5e9, offset=0x5e8, mode=Thumb, size=4, cc=1
i32 sub_5e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5ed, offset=0x5ec, mode=Thumb, size=112, cc=4
i32 sub_5ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x65d, offset=0x65c, mode=Thumb, size=4, cc=1
i32 sub_65d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x661, offset=0x660, mode=Thumb, size=192, cc=7
i32 sub_661(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x721, offset=0x720, mode=Thumb, size=4, cc=1
i32 sub_721(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x725, offset=0x724, mode=Thumb, size=4642, cc=230
i32 sub_725(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19e7, offset=0x19e6, mode=Thumb, size=1924, cc=80
i32 sub_19e7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1fe1, offset=0x1fe0, mode=Thumb, size=2, cc=1
i32 sub_1fe1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1fe3, offset=0x1fe2, mode=Thumb, size=120, cc=5
i32 sub_1fe3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1fef, offset=0x1fee, mode=Thumb, size=4, cc=1
i32 sub_1fef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21f5, offset=0x21f4, mode=Thumb, size=248, cc=13
i32 sub_21f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21ff, offset=0x21fe, mode=Thumb, size=2, cc=1
i32 sub_21ff(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2201, offset=0x2200, mode=Thumb, size=296, cc=14
i32 sub_2201(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2329, offset=0x2328, mode=Thumb, size=4, cc=1
i32 sub_2329(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x232d, offset=0x232c, mode=Thumb, size=204, cc=9
i32 sub_232d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2465, offset=0x2464, mode=Thumb, size=144, cc=7
i32 sub_2465(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24f5, offset=0x24f4, mode=Thumb, size=4, cc=1
i32 sub_24f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24f9, offset=0x24f8, mode=Thumb, size=272, cc=11
i32 sub_24f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26f9, offset=0x26f8, mode=Thumb, size=4, cc=1
i32 sub_26f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26fd, offset=0x26fc, mode=Thumb, size=588, cc=26
i32 sub_26fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2959, offset=0x2958, mode=Thumb, size=136, cc=6
i32 sub_2959(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29e1, offset=0x29e0, mode=Thumb, size=298, cc=13
i32 sub_29e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b0d, offset=0x2b0c, mode=Thumb, size=8, cc=1
i32 sub_2b0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b15, offset=0x2b14, mode=Thumb, size=72, cc=2
i32 sub_2b15(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b5d, offset=0x2b5c, mode=Thumb, size=28, cc=1
i32 sub_2b5d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b79, offset=0x2b78, mode=Thumb, size=2, cc=1
i32 sub_2b79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b7b, offset=0x2b7a, mode=Thumb, size=52, cc=2
i32 sub_2b7b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2baf, offset=0x2bae, mode=Thumb, size=52, cc=2
i32 sub_2baf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2be3, offset=0x2be2, mode=Thumb, size=82, cc=4
i32 sub_2be3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c35, offset=0x2c34, mode=Thumb, size=82, cc=4
i32 sub_2c35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c87, offset=0x2c86, mode=Thumb, size=106, cc=5
i32 sub_2c87(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cf1, offset=0x2cf0, mode=Thumb, size=38, cc=1
i32 sub_2cf1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d17, offset=0x2d16, mode=Thumb, size=250, cc=12
i32 sub_2d17(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e13, offset=0x2e12, mode=Thumb, size=102, cc=5
i32 sub_2e13(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e77, offset=0x2e76, mode=Thumb, size=496, cc=23
i32 sub_2e77(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f59, offset=0x2f58, mode=Thumb, size=2, cc=1
i32 sub_2f59(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f5b, offset=0x2f5a, mode=Thumb, size=2, cc=1
i32 sub_2f5b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3083, offset=0x3082, mode=Thumb, size=8, cc=1
i32 sub_3083(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x308b, offset=0x308a, mode=Thumb, size=172, cc=8
i32 sub_308b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3137, offset=0x3136, mode=Thumb, size=234, cc=10
i32 sub_3137(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3221, offset=0x3220, mode=Thumb, size=2, cc=1
i32 sub_3221(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3223, offset=0x3222, mode=Thumb, size=8, cc=1
i32 sub_3223(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x322b, offset=0x322a, mode=Thumb, size=8, cc=1
i32 sub_322b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3233, offset=0x3232, mode=Thumb, size=2, cc=1
i32 sub_3233(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3235, offset=0x3234, mode=Thumb, size=264, cc=11
i32 sub_3235(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3361, offset=0x3360, mode=Thumb, size=252, cc=14
i32 sub_3361(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3439, offset=0x3438, mode=Thumb, size=4, cc=1
i32 sub_3439(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x343d, offset=0x343c, mode=Thumb, size=492, cc=19
i32 sub_343d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3629, offset=0x3628, mode=Thumb, size=84, cc=4
i32 sub_3629(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367d, offset=0x367c, mode=Thumb, size=2, cc=1
i32 sub_367d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367f, offset=0x367e, mode=Thumb, size=14, cc=1
i32 sub_367f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368d, offset=0x368c, mode=Thumb, size=1018, cc=42
i32 sub_368d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3abd, offset=0x3abc, mode=Thumb, size=496, cc=21
i32 sub_3abd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3cad, offset=0x3cac, mode=Thumb, size=4, cc=1
i32 sub_3cad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3cb1, offset=0x3cb0, mode=Thumb, size=1576, cc=68
i32 sub_3cb1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x40c1, offset=0x40c0, mode=Thumb, size=8, cc=1
i32 sub_40c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x42e1, offset=0x42e0, mode=Thumb, size=4, cc=1
i32 sub_42e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x42e5, offset=0x42e4, mode=Thumb, size=252, cc=8
i32 sub_42e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43e1, offset=0x43e0, mode=Thumb, size=8, cc=1
i32 sub_43e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43e9, offset=0x43e8, mode=Thumb, size=1468, cc=59
i32 sub_43e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x49d5, offset=0x49d4, mode=Thumb, size=2544, cc=98
i32 sub_49d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4a83, offset=0x4a82, mode=Thumb, size=4, cc=1
i32 sub_4a83(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x53f1, offset=0x53f0, mode=Thumb, size=84, cc=4
i32 sub_53f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5445, offset=0x5444, mode=Thumb, size=4, cc=1
i32 sub_5445(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5449, offset=0x5448, mode=Thumb, size=494, cc=26
i32 sub_5449(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5639, offset=0x5638, mode=Thumb, size=4, cc=1
i32 sub_5639(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x563d, offset=0x563c, mode=Thumb, size=226, cc=10
i32 sub_563d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5721, offset=0x5720, mode=Thumb, size=4, cc=1
i32 sub_5721(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5725, offset=0x5724, mode=Thumb, size=46, cc=2
i32 sub_5725(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5755, offset=0x5754, mode=Thumb, size=4, cc=1
i32 sub_5755(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5759, offset=0x5758, mode=Thumb, size=108, cc=7
i32 sub_5759(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x57cd, offset=0x57cc, mode=Thumb, size=8, cc=1
i32 sub_57cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x57d5, offset=0x57d4, mode=Thumb, size=80, cc=7
i32 sub_57d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5845, offset=0x5844, mode=Thumb, size=90, cc=3
i32 sub_5845(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x58a1, offset=0x58a0, mode=Thumb, size=94, cc=3
i32 sub_58a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5901, offset=0x5900, mode=Thumb, size=94, cc=3
i32 sub_5901(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5961, offset=0x5960, mode=Thumb, size=180, cc=9
i32 sub_5961(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5a15, offset=0x5a14, mode=Thumb, size=710, cc=34
i32 sub_5a15(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5d05, offset=0x5d04, mode=Thumb, size=1898, cc=102
i32 sub_5d05(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x64c5, offset=0x64c4, mode=Thumb, size=182, cc=7
i32 sub_64c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x657d, offset=0x657c, mode=Thumb, size=8, cc=1
i32 sub_657d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6585, offset=0x6584, mode=Thumb, size=550, cc=24
i32 sub_6585(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x67ad, offset=0x67ac, mode=Thumb, size=8, cc=1
i32 sub_67ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x67b5, offset=0x67b4, mode=Thumb, size=560, cc=25
i32 sub_67b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x69fd, offset=0x69fc, mode=Thumb, size=82, cc=3
i32 sub_69fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6a51, offset=0x6a50, mode=Thumb, size=128, cc=6
i32 sub_6a51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6ad1, offset=0x6ad0, mode=Thumb, size=4, cc=1
i32 sub_6ad1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6ad5, offset=0x6ad4, mode=Thumb, size=2940, cc=161
i32 sub_6ad5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6ef5, offset=0x6ef4, mode=Thumb, size=8, cc=1
i32 sub_6ef5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7659, offset=0x7658, mode=Thumb, size=8, cc=1
i32 sub_7659(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7661, offset=0x7660, mode=Thumb, size=826, cc=40
i32 sub_7661(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x799d, offset=0x799c, mode=Thumb, size=8, cc=1
i32 sub_799d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x79a5, offset=0x79a4, mode=Thumb, size=238, cc=12
i32 sub_79a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7a95, offset=0x7a94, mode=Thumb, size=4, cc=1
i32 sub_7a95(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7a99, offset=0x7a98, mode=Thumb, size=118, cc=6
i32 sub_7a99(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7b11, offset=0x7b10, mode=Thumb, size=146, cc=12
i32 sub_7b11(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7ba5, offset=0x7ba4, mode=Thumb, size=4, cc=1
i32 sub_7ba5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7ba9, offset=0x7ba8, mode=Thumb, size=32, cc=1
i32 sub_7ba9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7bc9, offset=0x7bc8, mode=Thumb, size=38, cc=1
i32 sub_7bc9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7bef, offset=0x7bee, mode=Thumb, size=2, cc=1
i32 sub_7bef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7bf1, offset=0x7bf0, mode=Thumb, size=486, cc=29
i32 sub_7bf1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7dd9, offset=0x7dd8, mode=Thumb, size=158, cc=5
i32 sub_7dd9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7e79, offset=0x7e78, mode=Thumb, size=156, cc=5
i32 sub_7e79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7f19, offset=0x7f18, mode=Thumb, size=90, cc=4
i32 sub_7f19(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7f7d, offset=0x7f7c, mode=Thumb, size=62, cc=4
i32 sub_7f7d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7fb9, offset=0x7fb8, mode=Thumb, size=356, cc=20
i32 sub_7fb9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x811d, offset=0x811c, mode=Thumb, size=102, cc=3
i32 sub_811d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8179, offset=0x8178, mode=Thumb, size=92, cc=1
i32 sub_8179(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x81d9, offset=0x81d8, mode=Thumb, size=10, cc=1
i32 sub_81d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x81e3, offset=0x81e2, mode=Thumb, size=10, cc=1
i32 sub_81e3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x81ed, offset=0x81ec, mode=Thumb, size=10, cc=1
i32 sub_81ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x81f7, offset=0x81f6, mode=Thumb, size=8, cc=1
i32 sub_81f7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x81ff, offset=0x81fe, mode=Thumb, size=8, cc=1
i32 sub_81ff(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8207, offset=0x8206, mode=Thumb, size=8, cc=1
i32 sub_8207(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x820f, offset=0x820e, mode=Thumb, size=10, cc=1
i32 sub_820f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8219, offset=0x8218, mode=Thumb, size=16, cc=1
i32 sub_8219(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8229, offset=0x8228, mode=Thumb, size=10, cc=1
i32 sub_8229(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8233, offset=0x8232, mode=Thumb, size=12, cc=1
i32 sub_8233(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x823f, offset=0x823e, mode=Thumb, size=10, cc=1
i32 sub_823f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8249, offset=0x8248, mode=Thumb, size=8, cc=1
i32 sub_8249(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8251, offset=0x8250, mode=Thumb, size=12, cc=1
i32 sub_8251(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x825d, offset=0x825c, mode=Thumb, size=10, cc=1
i32 sub_825d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8267, offset=0x8266, mode=Thumb, size=12, cc=1
i32 sub_8267(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8273, offset=0x8272, mode=Thumb, size=10, cc=1
i32 sub_8273(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x827d, offset=0x827c, mode=Thumb, size=10, cc=1
i32 sub_827d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8287, offset=0x8286, mode=Thumb, size=32, cc=4
i32 sub_8287(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x82b5, offset=0x82b4, mode=Thumb, size=10, cc=1
i32 sub_82b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x82bf, offset=0x82be, mode=Thumb, size=10, cc=1
i32 sub_82bf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x82c9, offset=0x82c8, mode=Thumb, size=10, cc=1
i32 sub_82c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x82d3, offset=0x82d2, mode=Thumb, size=8, cc=1
i32 sub_82d3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x82db, offset=0x82da, mode=Thumb, size=46, cc=5
i32 sub_82db(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8313, offset=0x8312, mode=Thumb, size=10, cc=1
i32 sub_8313(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x831d, offset=0x831c, mode=Thumb, size=10, cc=1
i32 sub_831d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8327, offset=0x8326, mode=Thumb, size=10, cc=1
i32 sub_8327(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8331, offset=0x8330, mode=Thumb, size=10, cc=1
i32 sub_8331(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x833b, offset=0x833a, mode=Thumb, size=36, cc=4
i32 sub_833b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x835f, offset=0x835e, mode=Thumb, size=44, cc=5
i32 sub_835f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x838b, offset=0x838a, mode=Thumb, size=10, cc=2
i32 sub_838b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8395, offset=0x8394, mode=Thumb, size=22, cc=1
i32 sub_8395(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x83ab, offset=0x83aa, mode=Thumb, size=22, cc=1
i32 sub_83ab(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x83c9, offset=0x83c8, mode=Thumb, size=18, cc=1
i32 sub_83c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x83d1, offset=0x83d0, mode=Thumb, size=8, cc=1
i32 sub_83d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x83d9, offset=0x83d8, mode=Thumb, size=474, cc=33
i32 sub_83d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x85b5, offset=0x85b4, mode=Thumb, size=8, cc=1
i32 sub_85b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x85bd, offset=0x85bc, mode=Thumb, size=118, cc=6
i32 sub_85bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8639, offset=0x8638, mode=Thumb, size=12, cc=1
i32 sub_8639(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8645, offset=0x8644, mode=Thumb, size=66, cc=1
i32 sub_8645(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x868d, offset=0x868c, mode=Thumb, size=4, cc=1
i32 sub_868d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8691, offset=0x8690, mode=Thumb, size=4, cc=1
i32 sub_8691(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8695, offset=0x8694, mode=Thumb, size=52, cc=1
i32 sub_8695(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x86c9, offset=0x86c8, mode=Thumb, size=40, cc=1
i32 sub_86c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x86f1, offset=0x86f0, mode=Thumb, size=42, cc=1
i32 sub_86f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8721, offset=0x8720, mode=Thumb, size=14, cc=1
i32 sub_8721(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8735, offset=0x8734, mode=Thumb, size=70, cc=2
i32 sub_8735(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x877d, offset=0x877c, mode=Thumb, size=4, cc=1
i32 sub_877d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8781, offset=0x8780, mode=Thumb, size=2, cc=1
i32 sub_8781(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8783, offset=0x8782, mode=Thumb, size=18, cc=1
i32 sub_8783(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8795, offset=0x8794, mode=Thumb, size=4, cc=1
i32 sub_8795(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8799, offset=0x8798, mode=Thumb, size=122, cc=11
i32 sub_8799(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x882d, offset=0x882c, mode=Thumb, size=54, cc=2
i32 sub_882d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8865, offset=0x8864, mode=Thumb, size=4, cc=1
i32 sub_8865(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8869, offset=0x8868, mode=Thumb, size=90, cc=10
i32 sub_8869(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x88c5, offset=0x88c4, mode=Thumb, size=4, cc=1
i32 sub_88c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x88c9, offset=0x88c8, mode=Thumb, size=276, cc=24
i32 sub_88c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x89f5, offset=0x89f4, mode=Thumb, size=44, cc=3
i32 sub_89f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8a21, offset=0x8a20, mode=Thumb, size=8, cc=1
i32 sub_8a21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8a29, offset=0x8a28, mode=Thumb, size=216, cc=18
i32 sub_8a29(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8b0b, offset=0x8b0a, mode=Thumb, size=2, cc=1
i32 sub_8b0b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8b0d, offset=0x8b0c, mode=Thumb, size=162, cc=6
i32 sub_8b0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8bb3, offset=0x8bb2, mode=Thumb, size=390, cc=17
i32 sub_8bb3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8d35, offset=0x8d34, mode=Thumb, size=12, cc=1
i32 sub_8d35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8d41, offset=0x8d40, mode=Thumb, size=202, cc=10
i32 sub_8d41(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8e0d, offset=0x8e0c, mode=Thumb, size=396, cc=17
i32 sub_8e0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8f99, offset=0x8f98, mode=Thumb, size=4, cc=1
i32 sub_8f99(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8f9d, offset=0x8f9c, mode=Thumb, size=68, cc=3
i32 sub_8f9d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8fe1, offset=0x8fe0, mode=Thumb, size=4, cc=1
i32 sub_8fe1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8fe5, offset=0x8fe4, mode=Thumb, size=202, cc=9
i32 sub_8fe5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x90b1, offset=0x90b0, mode=Thumb, size=46, cc=2
i32 sub_90b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x90e1, offset=0x90e0, mode=Thumb, size=4, cc=1
i32 sub_90e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x90e5, offset=0x90e4, mode=Thumb, size=32, cc=1
i32 sub_90e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9105, offset=0x9104, mode=Thumb, size=38, cc=1
i32 sub_9105(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x912b, offset=0x912a, mode=Thumb, size=2, cc=1
i32 sub_912b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x912d, offset=0x912c, mode=Thumb, size=102, cc=5
i32 sub_912d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9195, offset=0x9194, mode=Thumb, size=138, cc=4
i32 sub_9195(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9223, offset=0x9222, mode=Thumb, size=140, cc=4
i32 sub_9223(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x92b1, offset=0x92b0, mode=Thumb, size=86, cc=3
i32 sub_92b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9305, offset=0x9304, mode=Thumb, size=32, cc=2
i32 sub_9305(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9323, offset=0x9322, mode=Thumb, size=472, cc=21
i32 sub_9323(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x94b9, offset=0x94b8, mode=Thumb, size=4, cc=1
i32 sub_94b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9515, offset=0x9514, mode=Thumb, size=8, cc=1
i32 sub_9515(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x951d, offset=0x951c, mode=Thumb, size=240, cc=9
i32 sub_951d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x960d, offset=0x960c, mode=Thumb, size=4, cc=1
i32 sub_960d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9611, offset=0x9610, mode=Thumb, size=206, cc=8
i32 sub_9611(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x96e1, offset=0x96e0, mode=Thumb, size=206, cc=8
i32 sub_96e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x97b1, offset=0x97b0, mode=Thumb, size=254, cc=10
i32 sub_97b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x98b1, offset=0x98b0, mode=Thumb, size=182, cc=7
i32 sub_98b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9969, offset=0x9968, mode=Thumb, size=206, cc=8
i32 sub_9969(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9a39, offset=0x9a38, mode=Thumb, size=206, cc=8
i32 sub_9a39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9b09, offset=0x9b08, mode=Thumb, size=76, cc=3
i32 sub_9b09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9b55, offset=0x9b54, mode=Thumb, size=4, cc=1
i32 sub_9b55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9b59, offset=0x9b58, mode=Thumb, size=84, cc=3
i32 sub_9b59(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9bad, offset=0x9bac, mode=Thumb, size=20, cc=1
i32 sub_9bad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9bc5, offset=0x9bc4, mode=Thumb, size=2, cc=1
i32 sub_9bc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9bc7, offset=0x9bc6, mode=Thumb, size=26, cc=1
i32 sub_9bc7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c15, offset=0x9c14, mode=Thumb, size=2, cc=1
i32 sub_9c15(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c27, offset=0x9c26, mode=Thumb, size=6, cc=1
i32 sub_9c27(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c2f, offset=0x9c2e, mode=Thumb, size=6, cc=1
i32 sub_9c2f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c39, offset=0x9c38, mode=Thumb, size=2, cc=1
i32 sub_9c39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c3b, offset=0x9c3a, mode=Thumb, size=6, cc=1
i32 sub_9c3b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c47, offset=0x9c46, mode=Thumb, size=6, cc=1
i32 sub_9c47(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c51, offset=0x9c50, mode=Thumb, size=10, cc=1
i32 sub_9c51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c5b, offset=0x9c5a, mode=Thumb, size=10, cc=1
i32 sub_9c5b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c71, offset=0x9c70, mode=Thumb, size=10, cc=1
i32 sub_9c71(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c7c, offset=0x9c7c, mode=ARM, size=4, cc=1
i32 sub_9c7c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9ca0, offset=0x9ca0, mode=ARM, size=4, cc=1
i32 sub_9ca0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9cb4, offset=0x9cb4, mode=ARM, size=4, cc=1
i32 sub_9cb4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9cb8, offset=0x9cb8, mode=ARM, size=8, cc=1
i32 sub_9cb8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9cc9, offset=0x9cc8, mode=Thumb, size=6, cc=1
i32 sub_9cc9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9ce0, offset=0x9ce0, mode=ARM, size=4, cc=1
i32 sub_9ce0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9ceb, offset=0x9cea, mode=Thumb, size=8, cc=1
i32 sub_9ceb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9cfc, offset=0x9cfc, mode=ARM, size=4, cc=1
i32 sub_9cfc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d00, offset=0x9d00, mode=ARM, size=4, cc=1
i32 sub_9d00(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d0f, offset=0x9d0e, mode=Thumb, size=4, cc=1
i32 sub_9d0f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d21, offset=0x9d20, mode=Thumb, size=6, cc=1
i32 sub_9d21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d30, offset=0x9d30, mode=ARM, size=4, cc=1
i32 sub_9d30(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d34, offset=0x9d34, mode=ARM, size=4, cc=1
i32 sub_9d34(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d4c, offset=0x9d4c, mode=ARM, size=4, cc=1
i32 sub_9d4c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d78, offset=0x9d78, mode=ARM, size=2, cc=1
i32 sub_9d78(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d7b, offset=0x9d7a, mode=Thumb, size=2, cc=1
i32 sub_9d7b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d7d, offset=0x9d7c, mode=Thumb, size=6, cc=1
i32 sub_9d7d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d8c, offset=0x9d8c, mode=ARM, size=4, cc=1
i32 sub_9d8c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9e0b, offset=0x9e0a, mode=Thumb, size=12, cc=1
i32 sub_9e0b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa2cf, offset=0xa2ce, mode=Thumb, size=8, cc=1
i32 sub_a2cf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa317, offset=0xa316, mode=Thumb, size=20, cc=1
i32 sub_a317(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa4a3, offset=0xa4a2, mode=Thumb, size=6, cc=1
i32 sub_a4a3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x100014, offset=0x100014, mode=ARM, size=0, cc=1
i32 UnresolvableJumpTarget(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x100018, offset=0x100018, mode=ARM, size=0, cc=1
i32 UnresolvableCallTarget(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

