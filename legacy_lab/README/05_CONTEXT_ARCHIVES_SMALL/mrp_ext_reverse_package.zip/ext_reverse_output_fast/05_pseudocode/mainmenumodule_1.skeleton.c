/* Skeleton recovered from function map for mainmenumodule_1. Fill bodies from 02_disassembly. */
typedef int i32;

// addr=0x0, offset=0x0, mode=ARM, size=8, cc=1
i32 sub_0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8, offset=0x8, mode=ARM, size=20, cc=1
i32 _start(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c, offset=0x1c, mode=ARM, size=4, cc=1
i32 sub_1c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20, offset=0x20, mode=ARM, size=284, cc=7
i32 sub_20(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf4, offset=0xf4, mode=ARM, size=4, cc=1
i32 sub_f4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x109, offset=0x108, mode=Thumb, size=2, cc=1
i32 sub_109(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10b, offset=0x10a, mode=Thumb, size=2, cc=1
i32 sub_10b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x135, offset=0x134, mode=Thumb, size=58, cc=3
i32 sub_135(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x177, offset=0x176, mode=Thumb, size=6, cc=1
i32 sub_177(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18d, offset=0x18c, mode=Thumb, size=8, cc=1
i32 sub_18d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x195, offset=0x194, mode=Thumb, size=150, cc=18
i32 sub_195(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x231, offset=0x230, mode=Thumb, size=130, cc=1
i32 sub_231(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b5, offset=0x2b4, mode=Thumb, size=18, cc=1
i32 sub_2b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c8, offset=0x2c8, mode=ARM, size=16, cc=1
i32 sub_2c8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d8, offset=0x2d8, mode=ARM, size=8, cc=1
i32 sub_2d8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e0, offset=0x2e0, mode=ARM, size=8, cc=1
i32 sub_2e0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e8, offset=0x2e8, mode=ARM, size=28, cc=1
i32 sub_2e8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x304, offset=0x304, mode=ARM, size=4, cc=1
i32 sub_304(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x308, offset=0x308, mode=ARM, size=28, cc=1
i32 sub_308(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x324, offset=0x324, mode=ARM, size=4, cc=1
i32 sub_324(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x329, offset=0x328, mode=Thumb, size=22, cc=1
i32 sub_329(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b, offset=0x34a, mode=Thumb, size=148, cc=2
i32 sub_34b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e1, offset=0x3e0, mode=Thumb, size=16, cc=1
i32 sub_3e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3f1, offset=0x3f0, mode=Thumb, size=76, cc=2
i32 sub_3f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43d, offset=0x43c, mode=Thumb, size=38, cc=1
i32 sub_43d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x463, offset=0x462, mode=Thumb, size=2, cc=1
i32 sub_463(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x465, offset=0x464, mode=Thumb, size=28, cc=1
i32 sub_465(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x481, offset=0x480, mode=Thumb, size=30, cc=1
i32 sub_481(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x49f, offset=0x49e, mode=Thumb, size=30, cc=1
i32 sub_49f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4bd, offset=0x4bc, mode=Thumb, size=182, cc=10
i32 sub_4bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x573, offset=0x572, mode=Thumb, size=182, cc=9
i32 sub_573(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x629, offset=0x628, mode=Thumb, size=230, cc=11
i32 sub_629(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x70f, offset=0x70e, mode=Thumb, size=160, cc=7
i32 sub_70f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7c5, offset=0x7c4, mode=Thumb, size=210, cc=10
i32 sub_7c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x899, offset=0x898, mode=Thumb, size=340, cc=21
i32 sub_899(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9fd, offset=0x9fc, mode=Thumb, size=4, cc=1
i32 sub_9fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa01, offset=0xa00, mode=Thumb, size=386, cc=21
i32 sub_a01(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xba1, offset=0xba0, mode=Thumb, size=124, cc=4
i32 sub_ba1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xc1d, offset=0xc1c, mode=Thumb, size=720, cc=26
i32 sub_c1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xeed, offset=0xeec, mode=Thumb, size=578, cc=23
i32 sub_eed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1131, offset=0x1130, mode=Thumb, size=4, cc=1
i32 sub_1131(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1135, offset=0x1134, mode=Thumb, size=254, cc=14
i32 sub_1135(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1235, offset=0x1234, mode=Thumb, size=4, cc=0
i32 sub_1235(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1239, offset=0x1238, mode=Thumb, size=3450, cc=123
i32 sub_1239(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1fed, offset=0x1fec, mode=Thumb, size=4, cc=1
i32 sub_1fed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ff1, offset=0x1ff0, mode=Thumb, size=64, cc=2
i32 sub_1ff1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2031, offset=0x2030, mode=Thumb, size=22, cc=1
i32 sub_2031(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2047, offset=0x2046, mode=Thumb, size=220, cc=7
i32 sub_2047(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2123, offset=0x2122, mode=Thumb, size=154, cc=4
i32 sub_2123(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21bd, offset=0x21bc, mode=Thumb, size=154, cc=4
i32 sub_21bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2257, offset=0x2256, mode=Thumb, size=242, cc=6
i32 sub_2257(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2349, offset=0x2348, mode=Thumb, size=94, cc=3
i32 sub_2349(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23a7, offset=0x23a6, mode=Thumb, size=78, cc=3
i32 sub_23a7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23d5, offset=0x23d4, mode=Thumb, size=8, cc=1
i32 sub_23d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23fd, offset=0x23fc, mode=Thumb, size=200, cc=5
i32 sub_23fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24cd, offset=0x24cc, mode=Thumb, size=922, cc=19
i32 sub_24cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2869, offset=0x2868, mode=Thumb, size=516, cc=17
i32 sub_2869(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2a6d, offset=0x2a6c, mode=Thumb, size=4, cc=1
i32 sub_2a6d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2a71, offset=0x2a70, mode=Thumb, size=226, cc=7
i32 sub_2a71(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b55, offset=0x2b54, mode=Thumb, size=4, cc=1
i32 sub_2b55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b59, offset=0x2b58, mode=Thumb, size=570, cc=18
i32 sub_2b59(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d95, offset=0x2d94, mode=Thumb, size=4, cc=1
i32 sub_2d95(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d99, offset=0x2d98, mode=Thumb, size=260, cc=8
i32 sub_2d99(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e9d, offset=0x2e9c, mode=Thumb, size=8, cc=0
i32 sub_2e9d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ea5, offset=0x2ea4, mode=Thumb, size=2228, cc=82
i32 sub_2ea5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32b1, offset=0x32b0, mode=Thumb, size=8, cc=1
i32 sub_32b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3795, offset=0x3794, mode=Thumb, size=2144, cc=85
i32 sub_3795(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4015, offset=0x4014, mode=Thumb, size=12, cc=1
i32 sub_4015(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4021, offset=0x4020, mode=Thumb, size=94, cc=3
i32 sub_4021(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4081, offset=0x4080, mode=Thumb, size=8, cc=1
i32 sub_4081(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4089, offset=0x4088, mode=Thumb, size=258, cc=9
i32 sub_4089(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x418d, offset=0x418c, mode=Thumb, size=4, cc=1
i32 sub_418d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4191, offset=0x4190, mode=Thumb, size=86, cc=4
i32 sub_4191(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x41e9, offset=0x41e8, mode=Thumb, size=262, cc=9
i32 sub_41e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4301, offset=0x4300, mode=Thumb, size=96, cc=3
i32 sub_4301(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4361, offset=0x4360, mode=Thumb, size=8, cc=1
i32 sub_4361(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4369, offset=0x4368, mode=Thumb, size=70, cc=1
i32 sub_4369(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43b1, offset=0x43b0, mode=Thumb, size=4, cc=1
i32 sub_43b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43b5, offset=0x43b4, mode=Thumb, size=490, cc=20
i32 sub_43b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45a1, offset=0x45a0, mode=Thumb, size=8, cc=1
i32 sub_45a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45a9, offset=0x45a8, mode=Thumb, size=464, cc=21
i32 sub_45a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4791, offset=0x4790, mode=Thumb, size=138, cc=5
i32 sub_4791(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x481d, offset=0x481c, mode=Thumb, size=4, cc=1
i32 sub_481d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4821, offset=0x4820, mode=Thumb, size=396, cc=19
i32 sub_4821(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x49bd, offset=0x49bc, mode=Thumb, size=220, cc=9
i32 sub_49bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4a99, offset=0x4a98, mode=Thumb, size=4, cc=1
i32 sub_4a99(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4a9d, offset=0x4a9c, mode=Thumb, size=370, cc=14
i32 sub_4a9d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4c41, offset=0x4c40, mode=Thumb, size=272, cc=19
i32 sub_4c41(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4d51, offset=0x4d50, mode=Thumb, size=4, cc=1
i32 sub_4d51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4d55, offset=0x4d54, mode=Thumb, size=144, cc=9
i32 sub_4d55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4df9, offset=0x4df8, mode=Thumb, size=36, cc=1
i32 sub_4df9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4e15, offset=0x4e14, mode=Thumb, size=88, cc=1
i32 sub_4e15(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4e71, offset=0x4e70, mode=Thumb, size=10, cc=1
i32 sub_4e71(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4e7b, offset=0x4e7a, mode=Thumb, size=10, cc=1
i32 sub_4e7b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4e85, offset=0x4e84, mode=Thumb, size=10, cc=1
i32 sub_4e85(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4e8f, offset=0x4e8e, mode=Thumb, size=22, cc=1
i32 sub_4e8f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ea5, offset=0x4ea4, mode=Thumb, size=22, cc=1
i32 sub_4ea5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ebb, offset=0x4eba, mode=Thumb, size=8, cc=1
i32 sub_4ebb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ec3, offset=0x4ec2, mode=Thumb, size=8, cc=1
i32 sub_4ec3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ecb, offset=0x4eca, mode=Thumb, size=8, cc=1
i32 sub_4ecb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ed3, offset=0x4ed2, mode=Thumb, size=8, cc=1
i32 sub_4ed3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4edb, offset=0x4eda, mode=Thumb, size=8, cc=1
i32 sub_4edb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ee3, offset=0x4ee2, mode=Thumb, size=52, cc=5
i32 sub_4ee3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f17, offset=0x4f16, mode=Thumb, size=18, cc=2
i32 sub_4f17(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f29, offset=0x4f28, mode=Thumb, size=8, cc=1
i32 sub_4f29(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f31, offset=0x4f30, mode=Thumb, size=8, cc=1
i32 sub_4f31(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f39, offset=0x4f38, mode=Thumb, size=10, cc=1
i32 sub_4f39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f43, offset=0x4f42, mode=Thumb, size=8, cc=1
i32 sub_4f43(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f4b, offset=0x4f4a, mode=Thumb, size=10, cc=1
i32 sub_4f4b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f55, offset=0x4f54, mode=Thumb, size=8, cc=1
i32 sub_4f55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f5d, offset=0x4f5c, mode=Thumb, size=8, cc=1
i32 sub_4f5d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f65, offset=0x4f64, mode=Thumb, size=10, cc=1
i32 sub_4f65(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f6f, offset=0x4f6e, mode=Thumb, size=8, cc=1
i32 sub_4f6f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f77, offset=0x4f76, mode=Thumb, size=8, cc=1
i32 sub_4f77(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f7f, offset=0x4f7e, mode=Thumb, size=4, cc=1
i32 sub_4f7f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f83, offset=0x4f82, mode=Thumb, size=50, cc=2
i32 sub_4f83(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4fb5, offset=0x4fb4, mode=Thumb, size=8, cc=1
i32 sub_4fb5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4fbd, offset=0x4fbc, mode=Thumb, size=8, cc=1
i32 sub_4fbd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4fc5, offset=0x4fc4, mode=Thumb, size=8, cc=1
i32 sub_4fc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4fcd, offset=0x4fcc, mode=Thumb, size=8, cc=1
i32 sub_4fcd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4fd5, offset=0x4fd4, mode=Thumb, size=10, cc=1
i32 sub_4fd5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4fdf, offset=0x4fde, mode=Thumb, size=10, cc=2
i32 sub_4fdf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4fe9, offset=0x4fe8, mode=Thumb, size=10, cc=1
i32 sub_4fe9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ff3, offset=0x4ff2, mode=Thumb, size=10, cc=1
i32 sub_4ff3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ffd, offset=0x4ffc, mode=Thumb, size=10, cc=1
i32 sub_4ffd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5007, offset=0x5006, mode=Thumb, size=10, cc=1
i32 sub_5007(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5011, offset=0x5010, mode=Thumb, size=10, cc=1
i32 sub_5011(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x501b, offset=0x501a, mode=Thumb, size=10, cc=1
i32 sub_501b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5025, offset=0x5024, mode=Thumb, size=8, cc=1
i32 sub_5025(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x502d, offset=0x502c, mode=Thumb, size=8, cc=1
i32 sub_502d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5035, offset=0x5034, mode=Thumb, size=34, cc=1
i32 sub_5035(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5057, offset=0x5056, mode=Thumb, size=10, cc=1
i32 sub_5057(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5069, offset=0x5068, mode=Thumb, size=2, cc=1
i32 sub_5069(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x506d, offset=0x506c, mode=Thumb, size=20, cc=1
i32 sub_506d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5081, offset=0x5080, mode=Thumb, size=118, cc=6
i32 sub_5081(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x50fd, offset=0x50fc, mode=Thumb, size=12, cc=1
i32 sub_50fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5109, offset=0x5108, mode=Thumb, size=66, cc=1
i32 sub_5109(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5151, offset=0x5150, mode=Thumb, size=4, cc=1
i32 sub_5151(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5155, offset=0x5154, mode=Thumb, size=4, cc=1
i32 sub_5155(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5159, offset=0x5158, mode=Thumb, size=52, cc=1
i32 sub_5159(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x518d, offset=0x518c, mode=Thumb, size=40, cc=1
i32 sub_518d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x51b5, offset=0x51b4, mode=Thumb, size=42, cc=1
i32 sub_51b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x51e5, offset=0x51e4, mode=Thumb, size=14, cc=1
i32 sub_51e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x51f9, offset=0x51f8, mode=Thumb, size=70, cc=2
i32 sub_51f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5245, offset=0x5244, mode=Thumb, size=2, cc=1
i32 sub_5245(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5247, offset=0x5246, mode=Thumb, size=18, cc=1
i32 sub_5247(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5259, offset=0x5258, mode=Thumb, size=4, cc=1
i32 sub_5259(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x525d, offset=0x525c, mode=Thumb, size=126, cc=11
i32 sub_525d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5299, offset=0x5298, mode=Thumb, size=8, cc=1
i32 sub_5299(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x52f3, offset=0x52f2, mode=Thumb, size=52, cc=2
i32 sub_52f3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5329, offset=0x5328, mode=Thumb, size=4, cc=1
i32 sub_5329(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x532d, offset=0x532c, mode=Thumb, size=90, cc=10
i32 sub_532d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5389, offset=0x5388, mode=Thumb, size=4, cc=1
i32 sub_5389(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x538d, offset=0x538c, mode=Thumb, size=240, cc=19
i32 sub_538d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x547f, offset=0x547e, mode=Thumb, size=36, cc=4
i32 sub_547f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x54b9, offset=0x54b8, mode=Thumb, size=44, cc=3
i32 sub_54b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x54e9, offset=0x54e8, mode=Thumb, size=4, cc=1
i32 sub_54e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x54ed, offset=0x54ec, mode=Thumb, size=216, cc=18
i32 sub_54ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x55cf, offset=0x55ce, mode=Thumb, size=2, cc=1
i32 sub_55cf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x55d1, offset=0x55d0, mode=Thumb, size=138, cc=5
i32 sub_55d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x565b, offset=0x565a, mode=Thumb, size=80, cc=2
i32 sub_565b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x56ad, offset=0x56ac, mode=Thumb, size=4, cc=1
i32 sub_56ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x56b1, offset=0x56b0, mode=Thumb, size=326, cc=9
i32 sub_56b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x57f9, offset=0x57f8, mode=Thumb, size=4, cc=1
i32 sub_57f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x57fd, offset=0x57fc, mode=Thumb, size=154, cc=4
i32 sub_57fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5899, offset=0x5898, mode=Thumb, size=4, cc=1
i32 sub_5899(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x589d, offset=0x589c, mode=Thumb, size=172, cc=13
i32 sub_589d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5949, offset=0x5948, mode=Thumb, size=4, cc=1
i32 sub_5949(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x594d, offset=0x594c, mode=Thumb, size=118, cc=8
i32 sub_594d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x59d9, offset=0x59d8, mode=Thumb, size=4, cc=1
i32 sub_59d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x59dd, offset=0x59dc, mode=Thumb, size=168, cc=8
i32 sub_59dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5a85, offset=0x5a84, mode=Thumb, size=4, cc=1
i32 sub_5a85(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5a89, offset=0x5a88, mode=Thumb, size=310, cc=18
i32 sub_5a89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5bc1, offset=0x5bc0, mode=Thumb, size=4, cc=1
i32 sub_5bc1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5bc5, offset=0x5bc4, mode=Thumb, size=66, cc=2
i32 sub_5bc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5c09, offset=0x5c08, mode=Thumb, size=4, cc=1
i32 sub_5c09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5c0d, offset=0x5c0c, mode=Thumb, size=284, cc=17
i32 sub_5c0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5d29, offset=0x5d28, mode=Thumb, size=4, cc=1
i32 sub_5d29(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5d2d, offset=0x5d2c, mode=Thumb, size=344, cc=18
i32 sub_5d2d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5e85, offset=0x5e84, mode=Thumb, size=4, cc=1
i32 sub_5e85(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5e89, offset=0x5e88, mode=Thumb, size=46, cc=2
i32 sub_5e89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5eb9, offset=0x5eb8, mode=Thumb, size=4, cc=1
i32 sub_5eb9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5ebd, offset=0x5ebc, mode=Thumb, size=322, cc=19
i32 sub_5ebd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6001, offset=0x6000, mode=Thumb, size=4, cc=1
i32 sub_6001(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6005, offset=0x6004, mode=Thumb, size=48, cc=2
i32 sub_6005(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6035, offset=0x6034, mode=Thumb, size=4, cc=1
i32 sub_6035(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6039, offset=0x6038, mode=Thumb, size=264, cc=10
i32 sub_6039(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6141, offset=0x6140, mode=Thumb, size=8, cc=1
i32 sub_6141(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6149, offset=0x6148, mode=Thumb, size=112, cc=4
i32 sub_6149(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x61b9, offset=0x61b8, mode=Thumb, size=4, cc=1
i32 sub_61b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x61bd, offset=0x61bc, mode=Thumb, size=208, cc=8
i32 sub_61bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x628d, offset=0x628c, mode=Thumb, size=4, cc=1
i32 sub_628d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6291, offset=0x6290, mode=Thumb, size=184, cc=7
i32 sub_6291(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6349, offset=0x6348, mode=Thumb, size=4, cc=1
i32 sub_6349(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x634d, offset=0x634c, mode=Thumb, size=190, cc=8
i32 sub_634d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x640d, offset=0x640c, mode=Thumb, size=8, cc=1
i32 sub_640d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6415, offset=0x6414, mode=Thumb, size=362, cc=23
i32 sub_6415(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6591, offset=0x6590, mode=Thumb, size=258, cc=14
i32 sub_6591(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6695, offset=0x6694, mode=Thumb, size=4, cc=1
i32 sub_6695(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6699, offset=0x6698, mode=Thumb, size=296, cc=16
i32 sub_6699(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x67d1, offset=0x67d0, mode=Thumb, size=8, cc=1
i32 sub_67d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x67d9, offset=0x67d8, mode=Thumb, size=50, cc=4
i32 sub_67d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x680c, offset=0x680c, mode=ARM, size=12, cc=1
i32 sub_680c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6829, offset=0x6828, mode=Thumb, size=4, cc=1
i32 sub_6829(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6835, offset=0x6834, mode=Thumb, size=12, cc=1
i32 sub_6835(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x684d, offset=0x684c, mode=Thumb, size=2, cc=1
i32 sub_684d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x685f, offset=0x685e, mode=Thumb, size=4, cc=1
i32 sub_685f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6879, offset=0x6878, mode=Thumb, size=4, cc=1
i32 sub_6879(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6893, offset=0x6892, mode=Thumb, size=2, cc=1
i32 sub_6893(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6894, offset=0x6894, mode=ARM, size=12, cc=1
i32 sub_6894(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x68b4, offset=0x68b4, mode=ARM, size=4, cc=1
i32 sub_68b4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x68bf, offset=0x68be, mode=Thumb, size=4, cc=1
i32 sub_68bf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x68dc, offset=0x68dc, mode=ARM, size=12, cc=1
i32 sub_68dc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x68f4, offset=0x68f4, mode=ARM, size=4, cc=1
i32 sub_68f4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6903, offset=0x6902, mode=Thumb, size=10, cc=1
i32 sub_6903(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6924, offset=0x6924, mode=ARM, size=4, cc=1
i32 sub_6924(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6936, offset=0x6936, mode=ARM, size=4, cc=1
i32 sub_6936(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6948, offset=0x6948, mode=ARM, size=4, cc=1
i32 sub_6948(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6969, offset=0x6968, mode=Thumb, size=6, cc=1
i32 sub_6969(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x696f, offset=0x696e, mode=Thumb, size=4, cc=1
i32 sub_696f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x69bb, offset=0x69ba, mode=Thumb, size=4, cc=1
i32 sub_69bb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x69cb, offset=0x69ca, mode=Thumb, size=2, cc=1
i32 sub_69cb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x69cd, offset=0x69cc, mode=Thumb, size=2, cc=1
i32 sub_69cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x100014, offset=0x100014, mode=ARM, size=0, cc=1
i32 UnresolvableJumpTarget(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x100018, offset=0x100018, mode=ARM, size=0, cc=1
i32 UnresolvableCallTarget(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

