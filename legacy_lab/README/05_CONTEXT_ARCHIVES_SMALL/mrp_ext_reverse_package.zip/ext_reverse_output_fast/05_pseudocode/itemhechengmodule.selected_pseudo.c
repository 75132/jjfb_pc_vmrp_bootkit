/* Selected recovered pseudo-C for itemhechengmodule. Not original source. */


/* ===== _start @ 0x8, size=20, cc=1 ===== */
int _start(int a0)
{
    return sub_4b55(a0);
}


/* ===== sub_28b1 @ 0x28b1, size=3380, cc=137 ===== */
typedef struct struct_2 {
    char padding_0[72];
    struct struct_1 *field_48;
} struct_2;

typedef struct struct_1 {
    char padding_0[4];
    int field_4;
} struct_1;

typedef struct struct_0 {
    char padding_0[36];
    unsigned int field_24;
} struct_0;

typedef struct struct_4 {
    char padding_0[100];
    int field_64;
} struct_4;

extern unsigned int g_1;
extern int g_11;
extern int g_124;
extern int g_125;
extern int g_137;
extern int g_14;
extern char g_18;
extern int g_19;
extern int g_1d;
extern char g_1f;
extern char g_24;
extern int g_28;
extern int g_29;
extern int g_2a;
extern int g_2d;
extern int g_2e;
extern int g_2f;
extern char g_3;
extern int g_30;
extern int g_31;
extern int g_32;
extern int g_34;
extern char g_38;
extern unsigned int g_3c;
extern int g_3f;
extern int g_4;
extern int g_41;
extern int g_42;
extern int g_43;
extern int g_46;
extern char g_48;
extern unsigned int g_5;
extern int g_56;
extern int g_58;
extern int g_5b8c;
extern int g_5bc0;
extern char g_5be4;
extern char g_5c;
extern int g_5d88;
extern char g_5d94;
extern int g_5da4;
extern int g_5db0;
extern int g_5dbc;
extern int g_5dc0;
extern int g_5dd4;
extern int g_5de4;
extern int g_5e00;
extern int g_5e10;
extern char g_5e38;
extern int g_5f;
extern char g_6;
extern char g_60;
extern char g_64;
extern char g_68;
extern char g_6c;
extern char g_70;
extern int g_78;
extern int g_7b;
extern int g_7d;
extern int g_8e;
extern int g_9;
extern int g_9c;
extern int g_9f;
extern int g_a;
extern int g_b1;
extern char g_c;
extern int g_c8;
extern int g_e1;
extern int g_ed;
extern int g_ff;

int sub_28b1(void)
{
    int v22;  // r4
    int v23;  // r0
    int v32;  // r4
    int v33;  // r0
    int v34;  // r0
    unsigned int v35;  // r0
    int v37;  // r0
    int iter;  // r4
    int v40;  // r7
    int v41;  // r6
    struct_0 *v42;  // r3
    unsigned int v43;  // r0
    struct_0 *v44;  // r3
    int v46;  // r0
    int v48;  // r7
    int v50;  // r6
    unsigned int v51;  // r0
    unsigned int v25;  // r9
    struct_0 *v52;  // r2
    unsigned int v53;  // r0
    int v55;  // r0
    int v57;  // r6
    unsigned int v58;  // r7
    struct_4 *v60;  // r1
    int v61;  // r0
    unsigned int v62;  // r6
    int v64;  // r0
    unsigned int v66;  // r5
    unsigned int v67;  // r6
    unsigned int v68;  // r0
    unsigned int v69;  // r0
    struct_2 *v30;  // r1
    struct_1 *v31;  // r4
    unsigned int v0;  // [bp-0x68]
    unsigned int v1;  // [bp-0x64]
    unsigned int v2;  // [bp-0x60]
    unsigned int v3;  // [bp-0x5c]
    int v4;  // [bp-0x58], Other Possible Types: unsigned int
    int v5;  // [bp-0x54], Other Possible Types: unsigned int
    int v6;  // [bp-0x50], Other Possible Types: unsigned int
    unsigned int v7;  // [bp-0x4c], Other Possible Types: int
    int v8;  // [bp-0x48]
    unsigned int v9;  // [bp-0x44], Other Possible Types: int
    unsigned int *v10;  // [bp-0x40], Other Possible Types: int, unsigned int
    unsigned int v11;  // [bp-0x3c], Other Possible Types: int
    unsigned int v12;  // [bp-0x3b], Other Possible Types: int
    int v13;  // [bp-0x38]
    int v14;  // [bp-0x34]
    unsigned int v15;  // [bp-0x30]
    int v16;  // [bp-0x2c]
    unsigned int v17;  // [bp-0x28]
    int v18;  // [bp-0x24]
    int v19;  // [bp-0x20]
    char v20;  // [bp-0x1c], Other Possible Types: unsigned int
    char v21;  // [bp-0x18], Other Possible Types: unsigned int

    v22 = sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M");
    v18 = 25;
    v16 = 70;
    v14 = 25;
    sub_4c2d(0x1e200, 293, "M", "M", "M", "M", "M");
    v23 = sub_4c2d(0x1e200, 225, 237, "M", "M", "M", "M");
    if (v23 <= sub_0)
        return v23;
    sub_4c2d(0x1e200, 292, "M", "M", "M", "M", "M");
    sub_4bdd("M", "M", "M");
    sub_4c2d(0x1e200, 50, "M", "M", sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M"), v18, "M");
    v17 = sub_4c2d(0x1e200, 45, 0x5d88, *((int *)(4 + v25 + 92)), "M", "M", "M");
    v11 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
    sub_4c2d(0x1e200, 42, v17, sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M"), v11, &v21, &v20);
    v4 = v17;
    v5 = sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M") - v21 >> 1;
    v6 = v18 - v20 >> 1;
    v7 = 0xff;
    v8 = 0xff;
    v9 = 200;
    v10 = sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M");
    v11 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
    sub_4c2d(0x1e200, 86, &v4, "M", "M", "M", "M");
    v19 = 25;
    sub_4c2d(0x1e200, 46, "M", 25, v22, v16, "M");
    if (!sub_4c2d(0x1e200, 225, 88, "M", "M", "M", "M"))
    {
        sub_4c2d(0x1e200, 20, 88, sub_4c2d(0x1e200, 66, *((int *)(4 + v25 + 96)), v22 - 20, "M", "M", "M"), "M", "M", "M");
        sub_4c2d(0x1e200, 20, 123, "M", "M", "M", "M");
    }
    v5 = sub_4c2d(0x1e200, 225, 88, "M", "M", "M", "M");
    v6 = sub_4c2d(0x1e200, 225, 123, "M", "M", "M", "M");
    v7 = 5;
    v9 = v22 - 20;
    v10 = 60;
    v8 = v19;
    v11 = sub_0;
    v12 = 1;
    sub_4c2d(0x1e200, 67, &v5, "M", "M", "M", "M");
    sub_4c2d(0x1e200, 49, "M", 95, v22, v14, "M");
    v11 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
    sub_4c2d(0x1e200, 42, 0x5d94, sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M"), v11, &v21, &v20);
    v4 = 23956;
    v5 = sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M") - v21 >> 1;
    v6 = (v14 - v20 >> 1) + 95;
    v8 = 0xff;
    v7 = 0xff;
    v9 = 200;
    v10 = sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M");
    v11 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
    sub_4c2d(0x1e200, 86, &v4, "M", "M", "M", "M");
    v15 = sub_4c2d(0x1e200, 29, "M", "M", "M", "M", "M") - 120;
    sub_4c2d(0x1e200, 50, "M", 120, sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M"), v15, "M");
    v19 = 125;
    v30 = 4 + v25;
    v30->padding_0[0] = 1;
    v31 = v30->field_48;
    if (v31)
    {
        v11 = 23972;
        v32 = sub_4c2d(0x1e200, 45, sub_4c2d(0x1e200, 45, v11, sub_4c2d(0x1e200, 177, v31, v31->field_4, "M", "M", "M"), "M", "M", "M"), 0x5b8c, "M", "M", "M");
        if (*((int *)(4 + v25 + 100)) == -1)
        {
            v10 = *((int *)(*((int *)(*((int *)(*((int *)*((int *)(4 + v25 + 56))) + *((int *)(4 + v25 + 108)) * 4)) + 12)) + *((int *)(4 + v25 + 112)) * 4));
            sub_4c2d(0x1e200, 52, "M", "M", "M", "M", "M");
            sub_58cd(*((int *)*((int *)(4 + v25 + 72))), *(v10));
        }
    }
    else
    {
        v11 = 24000;
        v33 = sub_4c2d(0x1e200, 63, *((char *)(4 + v25 + 4)), "M", "M", "M", "M");
        v13 = sub_4c2d(0x1e200, 45, sub_4c2d(0x1e200, 45, v11, v33, "M", "M", "M"), 0x5dbc, "M", "M", "M");
        sub_4c2d(0x1e200, 9, v33, "M", "M", "M", "M");
        v34 = sub_4c2d(0x1e200, 63, *((char *)(4 + v25 + 5)), "M", "M", "M", "M");
        v13 = sub_4c2d(0x1e200, 45, v13, v34, "M", "M", "M");
        sub_4c2d(0x1e200, 9, v34, "M", "M", "M", "M");
        v32 = sub_4c2d(0x1e200, 45, v13, 0x5db0, "M", "M", "M");
    }
    if (sub_4c2d(0x1e200, 47, "M", v19, sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M"), 0x11, "M") == 1)
    {
        v35 = 4 + v25;
        if (!*((int *)(v35 + 36)))
        {
            sub_4c2d(0x1e200, 156, 0x11, "M", "M", "M", "M");
            goto LABEL_2e45;
        }
        else
        {
            *((void* *)(v35 + 36)) = sub_0;
LABEL_2e4f:
            sub_4c2d(0x1e200, 48, "M", v19, sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M"), 0x11, "M");
        }
    }
    else
    {
LABEL_2e45:
        if (*((int *)(4 + v25 + 36)))
            goto LABEL_2e77;
        goto LABEL_2e4f;
    }
LABEL_2e77:
    v37 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
    sub_4c2d(0x1e200, 42, v32, sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M"), v37, &v21, &v20);
    sub_4c2d(0x1e200, 311, v32, 10, (0x11 - v20 >> 1) + 125, "M", "M");
    iter = 142;
    if (*((int *)(32 + v25)))
    {
        v40 = *((int *)(4 + v25 + 20));
        if (v40)
            v41 = sub_4c2d(0x1e200, 45, sub_4c2d(0x1e200, 45, 0x5dd4, sub_4c2d(0x1e200, 177, v40, *((int *)(v40 + 4)), "M", "M", "M"), "M", "M", "M"), 0x5b8c, "M", "M", "M");
        else
            v41 = 24036;
        if (sub_4c2d(0x1e200, 47, "M", 142, sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M"), 0x11, "M") == 1)
        {
            v42 = 4 + v25;
            v43 = (*((int *)(v42 + sub_1c)) ? 1 : 4294967294);
            if (v43 == v42->field_24)
                sub_4c2d(0x1e200, 156, 0x11, "M", "M", "M", "M");
            else
                v42->field_24 = v43;
        }
        v44 = 4 + v25;
        if ((*((int *)(v44 + sub_1c)) ? 1 : ~(sub_0)) == v44->field_24)
            sub_4c2d(0x1e200, 48, "M", 142, sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M"), 0x11, "M");
        v46 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
        sub_4c2d(0x1e200, 42, v41, sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M"), v46, &v21, &v20);
        sub_4c2d(0x1e200, 311, v41, 10, (0x11 - v20 >> 1) + 142, "M", "M");
        iter = 159;
    }
    if (*((int *)(36 + v25)))
    {
        v48 = *((int *)(4 + v25 + 24));
        v50 = (!v48 ? 24080 : sub_4c2d(0x1e200, 45, sub_4c2d(0x1e200, 45, 0x5e00, sub_4c2d(0x1e200, 177, v48, *((int *)(v48 + 4)), "M", "M", "M"), "M", "M", "M"), 0x5b8c, "M", "M", "M"));
        if (sub_4c2d(0x1e200, 47, "M", iter, sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M"), 0x11, "M") == 1)
        {
            v51 = sub_3635();
            if (v51 == *((int *)(4 + v25 + 36)))
                sub_4c2d(0x1e200, 156, 0x11, "M", "M", "M", "M");
            else
                v52->field_24 = sub_3635();
        }
        v53 = sub_3635();
        if (v53 == *((int *)(4 + v25 + 36)))
            sub_4c2d(0x1e200, 48, "M", iter, sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M"), 0x11, "M");
        v55 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
        sub_4c2d(0x1e200, 42, v50, sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M"), v55, &v21, &v20);
        sub_4c2d(0x1e200, 311, v50, 10, (0x11 - v20 >> 1) + iter, "M", "M");
        iter += 0x11;
    }
    if (*((int *)(4 + v25 + 52)) && !((v57 = (int)sub_0, v11 = (int)sub_4c2d(0x1e200, 0x11, *((int *)(4 + v25 + 52)), 4, "M", "M", "M"), v11 <= sub_0)))
    {
        do
        {
            v58 = sub_36dd(*((int *)(*((int *)(4 + v25 + 52)) + v57 * 4)), *((int *)(4 + v25 + 52)));
            v10 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
            sub_4c2d(0x1e200, 42, v58, sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M"), v10, &v21, &v20);
            v3 = v58;
            v9 = sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M", v58, 10, (0x11 - v20 >> 1) + iter, 0xff, 0xff, 200);
            v10 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
            sub_4c2d(0x1e200, 86, &v3, "M", "M", "M", "M");
        } while ((iter += 0x11, v57 += 1, v57 < v11));
    }
    v60 = 4 + v25;
    if (v60->field_64 != -1)
    {
        v61 = sub_4c2d(0x1e200, 45, 0x5bc0, sub_3931(v60->field_64, v60), "M", "M", "M");
        v11 = sub_4c2d(0x1e200, 63, *((int *)(4 + v25 + 104)), "M", "M", "M", "M");
        v62 = sub_4c2d(0x1e200, 45, sub_4c2d(0x1e200, 45, v61, sub_5bbc, "M", "M", "M"), v11, "M", "M", "M");
        sub_4c2d(0x1e200, 9, v11, "M", "M", "M", "M");
        v10 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
        sub_4c2d(0x1e200, 42, v62, sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M"), v10, &v21, &v20);
        v4 = 10;
        v3 = v62;
        v5 = (0x11 - v20 >> 1) + iter;
        v6 = 0xff;
        v7 = 0xff;
        v8 = 200;
        v9 = sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M");
        v10 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
        sub_4c2d(0x1e200, 86, &v3, "M", "M", "M", "M");
    }
    v7 = sub_3979();
    v8 = 200;
    v9 = sub_0;
    v10 = sub_0;
    v11 = 1;
    v12 = sub_0;
    sub_4c2d(0x1e200, 65, &v7, "M", "M", "M", "M");
    v7 = 23524;
    v8 = 200;
    v9 = sub_0;
    v10 = sub_0;
    v11 = sub_0;
    v12 = sub_0;
    sub_4c2d(0x1e200, 65, &v7, "M", "M", "M", "M");
    v64 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
    sub_4c2d(0x1e200, 42, 0x5e38, sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M"), v64, &v21, &v20);
    v66 = v21 + 10;
    v67 = v20 + 6;
    v11 = sub_4c2d(0x1e200, 29, "M", "M", "M", "M", "M") - v67;
    sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M");
    v1 = v66;
    v2 = v67;
    v0 = v11;
    sub_4c2d(0x1e200);
    v11 = sub_4c2d(0x1e200, 29, "M", "M", "M", "M", "M") - v67;
    v68 = sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M");
    sub_4c2d(0x1e200, 48, (v68 - v66 >> 31) + v68 - v66 >> 1, v11, v66, v67, "M");
    v4 = 24120;
    v69 = sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M");
    v5 = ((v69 - v66 >> 31) + v69 - v66 >> 1) + 5;
    v6 = sub_4c2d(0x1e200, 29, "M", "M", "M", "M", "M") - v67 + 3;
    v8 = 0xff;
    v7 = 0xff;
    v9 = 200;
    v10 = sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M");
    v11 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
    return sub_4c2d(0x1e200, 86, &v4, "M", "M", "M", "M");
}


/* ===== sub_1955 @ 0x1955, size=1924, cc=71 ===== */
extern char g_1;
extern int g_11;
extern int g_124;
extern int g_125;
extern int g_14;
extern int g_19;
extern int g_1d;
extern int g_28;
extern int g_29;
extern int g_2a;
extern int g_2d;
extern int g_2e;
extern int g_30;
extern int g_31;
extern int g_32;
extern char g_34;
extern unsigned int g_3c;
extern int g_3f;
extern int g_4;
extern int g_41;
extern int g_42;
extern int g_43;
extern int g_46;
extern char g_4c;
extern unsigned int g_5;
extern char g_50;
extern int g_56;
extern int g_58;
extern int g_5ba0;
extern char g_5bac;
extern int g_5bc0;
extern char g_5bc8;
extern char g_5bd8;
extern char g_5be4;
extern char g_5c;
extern int g_5f;
extern char g_6;
extern char g_60;
extern int g_78;
extern int g_7b;
extern int g_7d;
extern int g_8e;
extern int g_9;
extern int g_a;
extern int g_c8;
extern int g_e1;
extern int g_ed;
extern int g_ff;

int sub_1955(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3, unsigned int a4, unsigned int a5, unsigned int a6, unsigned int a7, unsigned int a8, unsigned int a9, unsigned int a10, unsigned int a11, unsigned int a12, unsigned int a13, unsigned int a14, unsigned int a15, unsigned int a16, unsigned int a17, unsigned int a18, unsigned int a19, unsigned int a20, unsigned int a21, unsigned int a22, unsigned int a23, unsigned int a24, unsigned int a25)
{
    int v1;  // r4
    int v2;  // r0
    int v12;  // r1
    int v13;  // r4
    unsigned int v14;  // r5
    int v16;  // r0
    int v18;  // r5
    unsigned int v19;  // r7
    int v21;  // r0
    unsigned int v22;  // r7
    unsigned int v4;  // r9
    unsigned int v5;  // r7
    int v8;  // r0
    int v10;  // r0
    char v0;  // [bp+0x2d], Other Possible Types: int

    v1 = sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M");
    a18 = 25;
    a17 = 70;
    a16 = 25;
    sub_4c2d(0x1e200, 293, "M", "M", "M", "M", "M");
    v2 = sub_4c2d(0x1e200, 225, 237, "M", "M", "M", "M");
    if (v2 <= sub_0)
        return v2;
    sub_4c2d(0x1e200, 292, "M", "M", "M", "M", "M");
    sub_4bdd("M", "M", "M");
    sub_4c2d(0x1e200, 50, "M", "M", sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M"), a18, "M");
    v5 = sub_4c2d(0x1e200, 45, 0x5ba0, *((int *)(4 + v4 + 92)), "M", "M", "M");
    a15 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
    sub_4c2d(0x1e200, 42, v5, sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M"), a15, &/* unsupported instruction */, &/* unsupported instruction */);
    a8 = v5;
    a9 = sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M") - a20 >> 1;
    a10 = a18 - a19 >> 1;
    a11 = 0xff;
    a12 = 0xff;
    a13 = 200;
    a14 = sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M");
    a15 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
    sub_4c2d(0x1e200, 86, &a8, "M", "M", "M", "M");
    sub_4c2d(0x1e200, 46, "M", 25, v1, a17, "M");
    if (!sub_4c2d(0x1e200, 225, 88, "M", "M", "M", "M"))
    {
        sub_4c2d(0x1e200, 20, 88, sub_4c2d(0x1e200, 66, *((int *)(4 + v4 + 96)), v1 - 20, "M", "M", "M"), "M", "M", "M");
        sub_4c2d(0x1e200, 20, 123, "M", "M", "M", "M");
    }
    a9 = sub_4c2d(0x1e200, 225, 88, "M", "M", "M", "M");
    a10 = sub_4c2d(0x1e200, 225, 123, "M", "M", "M", "M");
    a11 = 5;
    a13 = v1 - 20;
    a14 = 60;
    a12 = 25;
    a15 = sub_0;
    v0 = 1;
    sub_4c2d(0x1e200, 67, &a9, "M", "M", "M", "M");
    sub_4c2d(0x1e200, 49, "M", 95, v1, a16, "M");
    v8 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
    sub_4c2d(0x1e200, 42, 0x5bac, sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M"), v8, &/* unsupported instruction */, &/* unsupported instruction */);
    a8 = 23468;
    a9 = sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M") - a20 >> 1;
    a13 = 200;
    a10 = (a16 - a19 >> 1) + 95;
    a12 = 0xff;
    a11 = 0xff;
    a14 = sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M");
    a15 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
    sub_4c2d(0x1e200, 86, &a8, "M", "M", "M", "M");
    v10 = sub_4c2d(0x1e200, 29, "M", "M", "M", "M", "M");
    sub_4c2d(0x1e200, 50, "M", 120, sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M"), v10 - 120, "M");
    v12 = 4 + v4;
    *((char *)v12) = 1;
    v13 = 125;
    if (*((int *)(v12 + 76)))
    {
        v14 = sub_36dd(*((int *)(v12 + 76)), v12);
        sub_4c2d(0x1e200, 48, "M", 125, sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M"), 0x11, "M");
        v16 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
        sub_4c2d(0x1e200, 42, v14, sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M"), v16, &/* unsupported instruction */, &/* unsupported instruction */);
        a9 = 10;
        a10 = (0x11 - a19 >> 1) + 125;
        a12 = 0xff;
        a13 = 200;
        a11 = 0xff;
        a8 = v14;
        a14 = sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M");
        a15 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
        sub_4c2d(0x1e200, 86, &a8, "M", "M", "M", "M");
        v13 = 142;
    }
    if (*((int *)(4 + v4 + 52)) && !((v18 = (int)sub_0, a15 = (int)sub_4c2d(0x1e200, 0x11, *((int *)(4 + v4 + 52)), 4, "M", "M", "M"), a15 <= sub_0)))
    {
        do
        {
            v19 = sub_36dd(*((int *)(*((int *)(4 + v4 + 52)) + v18 * 4)), *((int *)(4 + v4 + 52)));
            a14 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
            sub_4c2d(0x1e200, 42, v19, sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M"), a14, &/* unsupported instruction */, &/* unsupported instruction */);
            a7 = v19;
            a13 = sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M", v19, 10, (0x11 - a19 >> 1) + v13, 0xff, 0xff, 200);
            a14 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
            sub_4c2d(0x1e200, 86, &a7, "M", "M", "M", "M");
        } while ((v13 += 0x11, v18 += 1, v18 < a15));
    }
    v21 = sub_4c2d(0x1e200, 45, 0x5bc0, sub_3931(*((char *)(4 + v4 + 6))), "M", "M", "M");
    a15 = sub_4c2d(0x1e200, 63, *((int *)(4 + v4 + 80)), "M", "M", "M", "M");
    v22 = sub_4c2d(0x1e200, 45, sub_4c2d(0x1e200, 45, v21, sub_5bbc, "M", "M", "M"), a15, "M", "M", "M");
    sub_4c2d(0x1e200, 9, a15, "M", "M", "M", "M");
    a14 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
    sub_4c2d(0x1e200, 42, v22, sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M"), a14, &/* unsupported instruction */, &/* unsupported instruction */);
    a7 = v22;
    a13 = sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M", v22, 10, (0x11 - a19 >> 1) + v13, 0xff, 0xff, 200);
    a14 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
    sub_4c2d(0x1e200, 86, &a7, "M", "M", "M", "M");
    if (*((int *)(4 + v4 + 76)) && !*((int *)(4 + v4 + 48)))
    {
        a11 = 23496;
        a12 = 200;
        a13 = sub_0;
        a14 = sub_0;
        a15 = 1;
        v0 = sub_0;
        sub_4c2d(0x1e200, 65, &a11, "M", "M", "M", "M");
    }
    else
    {
        a11 = 23512;
        a12 = 200;
        a13 = sub_0;
        a14 = sub_0;
        a15 = 1;
        v0 = sub_0;
        sub_4c2d(0x1e200, 65, &a11, "M", "M", "M", "M");
    }
    a11 = 23524;
    a12 = 200;
    a13 = sub_0;
    a14 = sub_0;
    a15 = sub_0;
    v0 = sub_0;
    return sub_4c2d(0x1e200, 65, &a11, "M", "M", "M", "M");
}


/* ===== sub_1281 @ 0x1281, size=1704, cc=58 ===== */
typedef struct struct_1 {
    char padding_0[44];
    unsigned int field_2c;
} struct_1;

typedef struct struct_0 {
    char padding_0[16];
    int field_10;
} struct_0;

extern unsigned int g_1;
extern char g_10;
extern int g_11;
extern int g_137;
extern int g_19;
extern int g_1f;
extern char g_2;
extern int g_23;
extern int g_27;
extern int g_28;
extern int g_29;
extern int g_2a;
extern char g_2c;
extern int g_2f;
extern int g_3;
extern int g_32;
extern int g_3c;
extern int g_3f;
extern int g_4;
extern char g_40;
extern int g_41;
extern int g_42;
extern char g_44;
extern int g_46;
extern int g_5;
extern int g_56;
extern char g_5be4;
extern int g_5c74;
extern char g_5c84;
extern char g_5c8c;
extern char g_5c94;
extern char g_5ca0;
extern int g_64;
extern int g_9;
extern char g_a;
extern unsigned int g_c8;
extern char g_d2;
extern int g_e1;
extern unsigned int g_ff;

int sub_1281(void)
{
    int v31;  // r7
    unsigned int v32;  // r9
    int idx;  // r5
    struct_0 *v43;  // r1
    unsigned int v33;  // r0
    int v34;  // r4
    int v35;  // r0
    int v36;  // r5
    unsigned int v37;  // r4
    struct_1 *v39;  // r5
    unsigned int v40;  // r0
    unsigned int v0;  // [bp-0x90]
    char *v1;  // [bp-0x8c]
    char *v2;  // [bp-0x88]
    unsigned int v3;  // [bp-0x80]
    unsigned int v4;  // [bp-0x7c]
    int v5;  // [bp-0x78], Other Possible Types: unsigned int
    int v6;  // [bp-0x74], Other Possible Types: unsigned int
    int v7;  // [bp-0x70], Other Possible Types: unsigned int
    int v8;  // [bp-0x6c], Other Possible Types: unsigned int
    int v9;  // [bp-0x68], Other Possible Types: unsigned int
    int v10;  // [bp-0x64], Other Possible Types: unsigned int
    int v11;  // [bp-0x60], Other Possible Types: unsigned int
    int v12;  // [bp-0x5c]
    char v13;  // [bp-0x58], Other Possible Types: unsigned int, int
    char v14;  // [bp-0x54], Other Possible Types: int, unsigned int
    int v15;  // [bp-0x53]
    int v16;  // [bp-0x50]
    int v17;  // [bp-0x4c]
    int v18;  // [bp-0x48]
    int v19;  // [bp-0x44]
    int v20;  // [bp-0x40]
    int v21;  // [bp-0x3c]
    int v22;  // [bp-0x38]
    int v23;  // [bp-0x34]
    unsigned int v24;  // [bp-0x30]
    unsigned int v25;  // [bp-0x2c]
    int v26;  // [bp-0x28]
    int v27;  // [bp-0x24]
    int v28;  // [bp-0x20]
    int v29;  // [bp-0x1c]
    int v30;  // [bp-0x18]

    v31 = sub_0;
    v20 = 60;
    v17 = sub_0;
    sub_4bdd("M", "M", "M");
    v22 = 3;
    v21 = sub_20(3, sub_4c2d(0x1e200, 0x11, *((int *)(4 + v32 + 40)), 4, "M", "M", "M"));
    *((int *)(4 + v32 + 64)) = v22;
    *((int *)(4 + v32 + 0x44)) = v21;
    v33 = sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M");
    v19 = (v33 - 210 >> 31) + v33 - 210 >> 1;
    v18 = 40;
    v34 = sub_4c2d(0x1e200, 63, *((char *)(4 + v32 + 1)), "M", "M", "M", "M");
    sub_4c2d(0x1e200, 50, "M", "M", 100, 25, "M");
    sub_4c2d(0x1e200, 60, 0x5c74, v34, 5, 5, "M");
    sub_4c2d(0x1e200, 9, v34, "M", "M", "M", "M");
    if (v21 > sub_0)
    {
        v30 = 60;
        v29 = v20 - 10;
        while (true)
        {
            v16 = sub_0;
            if (v22 > sub_0)
            {
                v35 = v17 * v20 + v18;
                v28 = v35;
                v26 = v35 + 5;
                v27 = v35 + 10;
                while (true)
                {
                    v36 = v28;
                    v37 = v16 * 70 + v19;
                    v25 = v31 * 4;
                    v12 = *((int *)(*((int *)(4 + v32 + 40)) + v25));
                    sub_4c2d(0x1e200, 50, v37, v36, 70, v20, "M");
                    if (!*((char *)(4 + v32 + 2)))
                    {
                        if (sub_4c2d(0x1e200, 47, v37, v36, 70, v20, "M") == 1)
                        {
                            v43 = 4 + v32;
                            if (v43->field_10 == v31)
                                sub_4c2d(0x1e200, 35, 4, v37, v36, 70, v20);
                            else
                                v43->field_10 = v31;
                        }
                        if (!v12)
                        {
                            v11 = 23684;
                            if (*((int *)(4 + v32 + 16)) == v31 && ((char)((sub_4c2d(0x1e200, 225, 39, "M", "M", "M", "M") >> 31) + sub_4c2d(0x1e200, 225, 39, "M", "M", "M", "M") >> 1) & 1) != 1)
                            {
                                v4 = v37 + 5;
                                v5 = v26;
                                v7 = v29;
                                v8 = 200;
                                v9 = 100;
                                v10 = 100;
                                v6 = v30;
                                sub_4c2d(0x1e200, 31, &v4, "M", "M", "M", "M");
                            }
                            v10 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
                            sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M");
                            v0 = v10;
                            v1 = &v14;
                            v2 = &v13;
                            sub_4c2d(0x1e200, 42, v11);
                            v3 = v11;
                            v4 = ((70 - v14 >> 31) + 70 - v14 >> 1) + v37;
                            v5 = ((v20 - v13 >> 31) + v20 - v13 >> 1) + v36;
                            v7 = 0xff;
                            v6 = 0xff;
                            v8 = 200;
                            v9 = sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M");
                            v10 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
                            sub_4c2d(0x1e200, 86, &v3, "M", "M", "M", "M");
                        }
                        else
                        {
                            v11 = 23692;
                            v24 = v37 + 5;
                            v4 = v24;
                            v5 = v26;
                            v23 = v5;
                            v7 = v29;
                            v8 = 100;
                            v9 = 100;
                            v10 = 100;
                            v6 = v30;
                            sub_4c2d(0x1e200, 31, &v4, "M", "M", "M", "M");
                            if (*((int *)(4 + v32 + 16)) == v31 && ((char)((sub_4c2d(0x1e200, 225, 39, "M", "M", "M", "M") >> 31) + sub_4c2d(0x1e200, 225, 39, "M", "M", "M", "M") >> 1) & 1) != 1)
                            {
                                v4 = v24;
                                v5 = v23;
                                v7 = v29;
                                v8 = 200;
                                v9 = 100;
                                v10 = 100;
                                v6 = v30;
                                sub_4c2d(0x1e200, 31, &v4, "M", "M", "M", "M");
                            }
                            v10 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
                            sub_4c2d(0x1e200, 42, v11, sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M"), v10, &v14, &v13);
                            v3 = v11;
                            v4 = ((70 - v14 >> 31) + 70 - v14 >> 1) + v37;
                            v5 = ((v20 - v13 >> 31) + v20 - v13 >> 1) + v36;
                            v7 = 0xff;
                            v6 = 0xff;
                            v8 = 200;
                            v9 = sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M");
                            v10 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
                            sub_4c2d(0x1e200, 86, &v3, "M", "M", "M", "M");
                        }
                    }
                    else if (!v12)
                    {
                        v11 = 23684;
                        v10 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
                        sub_4c2d(0x1e200, 42, v11, sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M"), v10, &v14, &v13);
                        v3 = v11;
                        v4 = ((70 - v14 >> 31) + 70 - v14 >> 1) + v37;
                        v5 = ((v20 - v13 >> 31) + v20 - v13 >> 1) + v36;
                        v7 = 0xff;
                        v6 = 0xff;
                        v8 = 200;
                        v9 = sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M");
                        v10 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
                        sub_4c2d(0x1e200, 86, &v3, "M", "M", "M", "M");
                    }
                    else
                    {
                        v39 = 4 + v32;
                        if (!*((int *)(v39->field_2c + v25)))
                        {
                            v40 = sub_4c2d(0x1e200, 66, v12, v30, "M", "M", "M");
                            *((unsigned int *)(v39->field_2c + v25)) = v40;
                        }
                        idx = sub_0;
                        v11 = sub_4c2d(0x1e200, 0x11, *((int *)(*((int *)(4 + v32 + 44)) + v25)), 4, "M", "M", "M");
                        v10 = v27;
                        if (v11 > sub_0)
                        {
                            do
                            {
                                v9 = *((int *)(*((int *)(*((int *)(4 + v32 + 44)) + v25)) + idx * 4));
                                v8 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
                                sub_4c2d(0x1e200, 42, v9, sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M"), v8, &v14, &v13);
                                sub_4c2d(0x1e200, 311, v9, ((70 - v14 >> 31) + 70 - v14 >> 1) + v37, (v13 + 2) * idx + v10, "M", "M");
                                idx += 1;
                            } while (idx < v11);
                        }
                    }
                    v31 += 1;
                    v16 += 1;
                    if (v22 <= v16)
                        break;
                }
            }
            v17 += 1;
            if (v21 <= v17)
                break;
        }
    }
    if (*((char *)(4 + v32 + 2)))
    {
        v10 = 23700;
        v11 = 200;
        v12 = sub_0;
        v13 = sub_0;
        v14 = 1;
        v15 = sub_0;
        sub_4c2d(0x1e200, 65, &v10, "M", "M", "M", "M");
    }
    else
    {
        v10 = 23712;
        v11 = 200;
        v12 = sub_0;
        v13 = sub_0;
        v14 = 1;
        v15 = sub_0;
        sub_4c2d(0x1e200, 65, &v10, "M", "M", "M", "M");
    }
    v11 = 200;
    v10 = 23524;
    v12 = sub_0;
    v13 = sub_0;
    v14 = sub_0;
    v15 = sub_0;
    return sub_4c2d(0x1e200, 65, &v10, "M", "M", "M", "M");
}


/* ===== sub_20fd @ 0x20fd, size=1008, cc=39 ===== */
typedef struct struct_0 {
    char padding_0[56];
    struct struct_1 *field_38;
    char padding_3c[48];
    unsigned int field_6c;
} struct_0;

typedef struct struct_1 {
    unsigned int field_0;
} struct_1;

extern int g_1;
extern unsigned int g_10;
extern int g_12;
extern int g_124;
extern int g_125;
extern int g_12c;
extern int g_14;
extern int g_1a;
extern int g_1d;
extern int g_24;
extern int g_28;
extern int g_29;
extern int g_2a;
extern int g_2d;
extern int g_31;
extern int g_32;
extern int g_36;
extern char g_38;
extern int g_3c;
extern char g_4;
extern int g_42;
extern int g_43;
extern unsigned int g_5;
extern int g_55;
extern int g_56;
extern int g_58;
extern int g_5b74;
extern int g_64;
extern char g_6c;
extern char g_70;
extern int g_7b;
extern int g_9c;
extern char g_a;
extern char g_c;
extern unsigned int g_c8;
extern int g_e1;
extern int g_ed;
extern unsigned int g_ff;

int sub_20fd(void)
{
    int v16;  // r5
    int v17;  // r4
    int v26;  // r7
    unsigned int v18;  // r9
    int v19;  // r0
    unsigned int v22;  // r0
    int v23;  // r2
    struct_0 *v24;  // r6
    unsigned int v25;  // r5
    int v0;  // [bp-0x50], Other Possible Types: unsigned int
    int v1;  // [bp-0x4c], Other Possible Types: unsigned int
    int v2;  // [bp-0x48]
    unsigned int v3;  // [bp-0x44]
    unsigned int v4;  // [bp-0x40]
    unsigned int v5;  // [bp-0x3c], Other Possible Types: int
    unsigned int v6;  // [bp-0x38]
    unsigned int v7;  // [bp-0x34]
    unsigned int v8;  // [bp-0x30]
    int v9;  // [bp-0x2c], Other Possible Types: unsigned int
    int v10;  // [bp-0x28], Other Possible Types: unsigned int
    int v11;  // [bp-0x24], Other Possible Types: unsigned int
    int v12;  // [bp-0x23]
    int v13;  // [bp-0x20]
    char v14;  // [bp-0x1c], Other Possible Types: unsigned int
    char v15;  // [bp-0x18], Other Possible Types: unsigned int

    v16 = sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M");
    v13 = 26;
    v17 = 60;
    if (!*((int *)(4 + v18 + 56)))
        return sub_4c2d(0x1e200, 156, 18, "M", "M", "M", "M");
    sub_4c2d(0x1e200, 293, "M", "M", "M", "M", "M");
    v19 = sub_4c2d(0x1e200, 225, 237, "M", "M", "M", "M");
    if (v19 <= sub_0)
        return v19;
    sub_4c2d(0x1e200, 292, "M", "M", "M", "M", "M");
    sub_4bdd("M", "M", "M");
    if (!*((int *)(4 + v18 + 60)))
        sub_4c2d(0x1e200, 156, 20, "M", "M", "M", "M");
    if (sub_4c2d(0x1e200, 29, "M", "M", "M", "M", "M") >= 300)
        v17 = 100;
    sub_4c2d(0x1e200, 50, "M", v13, sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M"), 26, "M");
    sub_ea1("M", v16, sub_1c, 26);
    v13 = 54;
    sub_4c2d(0x1e200, 49, "M", sub_4c2d(0x1e200, 29, "M", "M", "M", "M", "M") - v17, v16, v17, "M");
    sub_4c2d(0x1e200, 0x55, "M", "M", 1, 1, 1);
    v22 = sub_4c2d(0x1e200, 29, "M", "M", "M", "M", "M");
    sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M");
    v5 = sub_0;
    v3 = 16;
    v4 = 16;
    v23 = 1;
    if (*((int *)(4 + v18 + 60)) != 1)
        v23 = sub_0;
    v1 = 4 + v18 + 112;
    v0 = v22 - 54 - v17;
    v2 = v23;
    v24 = 4 + v18;
    sub_bb5(*((int *)(*((int *)(v24->field_38->field_0 + v24->field_6c * 4)) + 12)), "M", v13);
    if (!*((int *)&v24->padding_3c[0]))
    {
        v25 = sub_4c2d(0x1e200, 45, 0x5b74, *((int *)(*((int *)(v24->field_38->field_0 + v24->field_6c * 4)) + 4)), "M", "M", "M");
        v26 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
        sub_4c2d(0x1e200, 42, v25, sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M"), v26, &v15, &v14);
        v4 = v25;
        v5 = sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M") - v15 >> 1;
        v6 = sub_4c2d(0x1e200, 29, "M", "M", "M", "M", "M") - v14 - (v17 - v14 >> 1);
        v8 = 0xff;
        v7 = 0xff;
        v9 = 200;
        v0 = sub_0;
        v1 = sub_0;
        v10 = sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M");
        v2 = sub_0;
        v11 = sub_4c2d(0x1e200, 225, 40, "M");
        sub_4c2d(0x1e200, 86, &v4, "M", "M", "M", "M");
    }
    else
    {
        if (!sub_4c2d(0x1e200, 225, 88, "M", "M", "M", "M"))
        {
            sub_4c2d(0x1e200, 20, 88, sub_4c2d(0x1e200, 66, *((int *)(*((int *)(*((int *)(*((int *)(*((int *)*((int *)(4 + v18 + 56))) + *((int *)(4 + v18 + 108)) * 4)) + 12)) + *((int *)(4 + v18 + 112)) * 4)) + 16)), v16 - 20, "M", "M", "M"), "M", "M", "M");
            sub_4c2d(0x1e200, 20, 123, "M", "M", "M", "M");
        }
        v5 = sub_4c2d(0x1e200, 225, 88, "M", "M", "M", "M");
        v6 = sub_4c2d(0x1e200, 225, 123, "M", "M", "M", "M");
        v7 = 5;
        v8 = sub_4c2d(0x1e200, 29, "M", "M", "M", "M", "M") - v17;
        v9 = v16 - 20;
        v10 = v17 - 10;
        v11 = sub_0;
        v12 = 1;
        sub_4c2d(0x1e200, 67, &v5, "M", "M", "M", "M");
    }
    return sub_4c2d(0x1e200, 36, 1, 1, "M", "M", "M");
}


/* ===== sub_ea1 @ 0xea1, size=986, cc=39 ===== */
typedef struct struct_0 {
    char padding_0[56];
    struct struct_1 *field_38;
    char padding_3c[48];
    int field_6c;
} struct_0;

typedef struct struct_2 {
    char padding_0[108];
    int field_6c;
} struct_2;

typedef struct struct_1 {
    int field_0;
} struct_1;

extern int g_1;
extern int g_10;
extern int g_11;
extern int g_12;
extern int g_14;
extern int g_1e;
extern int g_1f;
extern int g_2;
extern int g_22;
extern int g_23;
extern int g_26;
extern int g_27;
extern int g_2f;
extern int g_3;
extern char g_38;
extern char g_3c;
extern int g_4;
extern char g_6c;
extern unsigned int g_8b;
extern unsigned int g_90;
extern int g_b8;
extern int g_c4;
extern unsigned int g_e;
extern int g_e1;
extern int g_e6;

int sub_ea1(unsigned int a0, int a1, unsigned int a2, unsigned int a3)
{
    unsigned int v18;  // r9
    struct_0 *v19;  // r5
    struct_2 *idx;  // r1
    int v29;  // r0
    int v30;  // r0
    int v31;  // r0
    unsigned int v32;  // r2
    int v33;  // r0
    int v34;  // r0
    int v35;  // r0
    struct_0 *v36;  // r7
    int v37;  // r0
    int v20;  // r6
    int v38;  // r0
    int v39;  // r0
    int v40;  // r0
    int v42;  // r2
    int v43;  // r3
    unsigned int v45;  // r0
    unsigned int v47;  // r0
    unsigned int v21;  // r0
    unsigned int v22;  // r1
    int v23;  // r1
    int v24;  // r0
    int v25;  // r4
    unsigned int v26;  // r5
    unsigned int v27;  // r7
    int v0;  // [bp-0x60]
    int v1;  // [bp-0x5c]
    int v2;  // [bp-0x58]
    unsigned int v3;  // [bp-0x54]
    unsigned int v4;  // [bp-0x50]
    unsigned int v5;  // [bp-0x4c]
    int v6;  // [bp-0x48], Other Possible Types: unsigned int
    int v7;  // [bp-0x44], Other Possible Types: unsigned int
    int v8;  // [bp-0x40], Other Possible Types: unsigned int
    unsigned int v9;  // [bp-0x3c], Other Possible Types: int
    int v10;  // [bp-0x38]
    int v11;  // [bp-0x34]
    int v12;  // [bp-0x30]
    unsigned int v13;  // [bp-0x2c]
    int v14;  // [bp-0x28]
    unsigned int v15;  // [bp-0x24]
    int v16;  // [bp-0x20]
    unsigned int v17;  // [bp-0x18]

    v15 = a0;
    v16 = a1;
    v17 = a3;
    v19 = 4 + v18;
    v12 = sub_4c2d(0x1e200, 0x11, v19->field_38->field_0, 4, "M", "M", "M");
    v20 = sub_0;
    v15 = a0 + _start;
    v21 = sub_2e8(a1 - 20);
    v11 = sub_20(v22, v19->field_6c) * v22;
    v23 = v11 + v22;
    v24 = v12;
    if (v24 > v23)
        v24 = v23;
    v25 = v11;
    v26 = a2 + 3;
    v10 = v24;
    if (v24 > v25)
    {
        v14 = (v21 >> 31) + v21 >> 1;
        while (true)
        {
            v13 = v14 + v20 * 20 + v15;
            v27 = v13 + 4;
            if (sub_4c2d(0x1e200, 47, v27, v26, 20, 16, "M") == 1)
            {
                idx = 4 + v18;
                if (idx->field_6c != v25)
                {
                    *((void* *)&idx->padding_0[60]) = sub_0;
                    idx->field_6c = v25;
                    sub_4c2d(0x1e200, 230, "M", "M", "M", "M", "M");
                }
            }
            if (*((int *)(4 + v18 + 108)) == v25)
            {
                v29 = sub_0;
                if (!*((int *)(4 + v18 + 60)))
                {
                    v30 = sub_4c2d(0x1e200, 225, 39, "M", "M", "M", "M");
                    v31 = (v30 >> 31 >> 30) + v30 >> 2;
                    v29 = (v31 - ((v31 >> 31) + v31 >> 1) * 2) * 2 + 1;
                }
                sub_4c2d(0x1e200, 196, v13 + 2, v26 - v29 - 2, 18, 20, 1);
                v3 = v27;
                v32 = 4 + v18;
                v33 = sub_0;
                if (!*((int *)(v32 + 60)))
                {
                    v33 = sub_0;
                    if (*((int *)(v32 + 108)) == v25)
                    {
                        v0 = sub_0;
                        v1 = sub_0;
                        v2 = sub_0;
                        v34 = sub_4c2d(0x1e200, 225, 39);
                        v35 = (v34 >> 31 >> 30) + v34 >> 2;
                        v33 = (v35 - ((v35 >> 31) + v35 >> 1) * 2) * 2 + 1;
                    }
                }
                v4 = v26 - v33;
                v5 = 14;
                v6 = 16;
                v7 = 139;
                v8 = 144;
                v9 = sub_0;
                sub_4c2d(0x1e200, 31, &v3, "M", "M", "M", "M");
            }
            v5 = v27;
            v4 = sub_4c2d(0x1e200, 225, 184, "M", "M", "M", "M");
            v36 = 4 + v18;
            v37 = sub_0;
            if (!*((int *)&v36->padding_3c[0]))
            {
                v37 = sub_0;
                if (v36->field_6c == v25)
                {
                    v2 = sub_0;
                    v0 = sub_0;
                    v1 = sub_0;
                    v38 = sub_4c2d(0x1e200, 225, 39);
                    v39 = (v38 >> 31 >> 30) + v38 >> 2;
                    v37 = (v39 - ((v39 >> 31) + v39 >> 1) * 2) * 2 + 1;
                }
            }
            v6 = v26 - v37;
            v7 = 16;
            v8 = 16;
            v9 = *((char *)(8 + *((int *)(v36->field_38->field_0 + v25 * 4))));
            sub_4c2d(0x1e200, 0x22, &v4, "M", "M", "M", "M");
            v20 += 1;
            v25 += 1;
            if (v10 <= v25)
                break;
        }
    }
    v40 = *((int *)(4 + v18 + 60));
    if (!*((int *)(4 + v18 + 60)))
    {
        if (v11 > sub_0)
        {
            v4 = sub_4c2d(0x1e200, 225, 38, "M", "M", "M", "M");
            sub_308(sub_4c2d(0x1e200, 225, 39, "M", "M", "M", "M"), v22, v42, v43, "M", "M", "M");
            v5 = (v22 - ((v22 >> 31) + v22 >> 1) * 2) * 2;
            v8 = 14;
            v9 = sub_0;
            v6 = v26;
            v7 = _start;
            sub_4c2d(0x1e200, 0x22, &v4, "M", "M", "M", "M");
            sub_308(sub_4c2d(0x1e200, 225, 39, "M", "M", "M", "M"), v22, v42, v43, "M", "M", "M");
            sub_4c2d(0x1e200, 35, 2, (v22 - ((v22 >> 31) + v22 >> 1) * 2) * 2 - 20, v26, 30, 20);
        }
        v40 = v10;
        if (v12 > v40)
        {
            v0 = sub_0;
            v1 = sub_0;
            v2 = sub_0;
            v4 = sub_4c2d(0x1e200, 225, 38, "M", "M", "M", "M");
            v45 = sub_4c2d(0x1e200);
            sub_308(sub_4c2d(0x1e200, 225, 39, "M", "M", "M", "M"), v22, v42, v43, "M", "M", "M");
            v5 = v45 - _start - (v22 - ((v22 >> 31) + v22 >> 1) * 2) * 2;
            v8 = 14;
            v9 = 1;
            v6 = v26;
            v7 = _start;
            sub_4c2d(0x1e200, 0x22, &v4, "M", "M", "M", "M");
            v47 = sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M");
            sub_308(sub_4c2d(0x1e200, 225, 39, "M", "M", "M", "M"), v22, v42, v43, "M", "M", "M");
            return sub_4c2d(0x1e200, 35, 3, v47 - _start - (v22 - ((v22 >> 31) + v22 >> 1) * 2) * 2, v26, 30, 20);
        }
    }
    return v40;
}


/* ===== sub_4755 @ 0x4755, size=984, cc=56 ===== */
typedef struct struct_1 {
    char padding_0[4];
    char field_4;
    char field_5;
    char padding_6[14];
    struct struct_2 *field_14;
    char padding_18[32];
    struct struct_2 *field_38;
    char padding_3c[12];
    struct struct_0 *field_48;
    char padding_4c[28];
    int field_68;
    unsigned int field_6c;
    unsigned int field_70;
} struct_1;

typedef struct struct_2 {
    unsigned int field_0;
} struct_2;

typedef struct struct_0 {
    char padding_0[4];
    int field_4;
} struct_0;

extern char g_1;
extern char g_108;
extern int g_11;
extern int g_12;
extern int g_126;
extern int g_127;
extern int g_128;
extern int g_129;
extern int g_14;
extern char g_18;
extern char g_24;
extern int g_2c;
extern int g_2d;
extern int g_33;
extern int g_34;
extern char g_38;
extern char g_4;
extern char g_48;
extern int g_5;
extern int g_51;
extern int g_5bec;
extern int g_5c04;
extern char g_5d10;
extern char g_5d1c;
extern char g_5d2c;
extern int g_5d48;
extern int g_5d64;
extern char g_64;
extern char g_68;
extern int g_69;
extern char g_6c;
extern char g_70;
extern int g_9;
extern int g_9c;
extern int g_a1;
extern int g_b;
extern int g_b1;
extern int g_c;
extern int g_d;
extern int g_e1;
extern int g_e6;

int sub_4755(int a0)
{
    int v1;  // r4
    unsigned int v2;  // r0
    unsigned int v11;  // r4
    unsigned int v13;  // r4
    unsigned int v14;  // r0
    int v16;  // r1
    int v17;  // r2
    int v18;  // r3
    unsigned int v19;  // r4
    unsigned int v20;  // r3
    unsigned int v3;  // r9
    unsigned int v21;  // r0
    unsigned int v22;  // r0
    struct_1 *idx;  // r5
    unsigned int v5;  // r0
    unsigned int v6;  // r0
    struct_1 *index;  // r4
    int v8;  // r0
    int v9;  // r0
    unsigned int v10;  // r4
    unsigned int v0;  // [bp-0x18]

    v1 = a0;
    v2 = sub_4c2d(0x1e200, 225, sub_20, "M", "M", "M", "M");
    if (v2 == 1 && v1 == 0x11)
        v1 = 20;
    idx = 4 + v3;
    switch (v1)
    {
    case 8: case 13:
        v22 = sub_38b1();
        *((unsigned int *)&idx->padding_18[12]) = v22;
        return v22;
    case 17:
        v19 = sub_3979();
        if (!(*((int *)(264 + v3)))(v19, 0x5d10, *((int *)(264 + v3)), v20))
        {
            sub_4c2d(0x1e200, 52, "M", "M", "M", "M", "M");
            sub_4c2d(0x1e200, 20, 294, idx->field_4, "M", "M", "M");
            sub_4c2d(0x1e200, 20, 295, idx->field_5, "M", "M", "M");
            sub_4c2d(0x1e200, 161, -5, 11, "M", "M", "M");
            v21 = ~(sub_0);
            *((unsigned int *)&idx->padding_4c[24]) = v21;
            idx->field_68 = v21;
            return v21;
        }
        else if (!(*((int *)(264 + v3)))(v19, 0x5d1c, *((int *)(264 + v3))))
        {
            sub_4c2d(0x1e200, 52, "M", "M", "M", "M", "M");
            sub_4c2d(0x1e200, 20, 296, *((int *)(idx + sub_1c)), "M", "M", "M");
            return sub_4c2d(0x1e200, 161, -6, 12, "M", "M", "M");
        }
        else
        {
            v14 = (*((int *)(264 + v3)))(v19, 0x5d2c, *((int *)(264 + v3)));
            if (!v14)
            {
                sub_4c2d(0x1e200, 52, "M", "M", "M", "M", "M");
                sub_4c2d(0x1e200, 20, 297, *((int *)(idx + sub_20)), "M", "M", "M");
                return sub_4c2d(0x1e200, 161, -7, 13, "M", "M", "M");
            }
        }
    case 2: case 12:
        v5 = sub_3655();
        *((unsigned int *)&idx->padding_18[12]) = v5;
        return v5;
    case 18:
        if (*((int *)(idx + sub_20)))
        {
            sub_4c2d(0x1e200, 9, *((int *)(idx + sub_20)), "M", "M", "M", "M");
            *((void* *)(idx + sub_20)) = sub_0;
            break;
        }
        if (*((int *)(idx + sub_1c)))
        {
            sub_4c2d(0x1e200, 9, *((int *)(idx + sub_1c)), "M", "M", "M", "M");
            *((void* *)(idx + sub_1c)) = sub_0;
        }
        sub_5491(sub_4c2d(0x1e200, 230, "M", "M", "M", "M", "M"), v16, v17, v18, "M", "M", "M");
        return sub_4c2d(0x1e200, 44, "M", "M", "M", "M", "M");
    case 5: case 20:
        if (!idx->field_48)
        {
            *((void* *)&idx->padding_18[12]) = sub_0;
            sub_4c2d(0x1e200, 156, 0x11, "M", "M", "M", "M");
            v6 = sub_4c2d(0x1e200, 0x33, 0x5d48, "M", "M", "M", "M");
            *((void* *)&idx->padding_18[12]) = sub_0;
            return v6;
        }
        index = idx;
        if (!idx->padding_0[0])
            return sub_4c2d(0x1e200, 0x33, 0x5bec, "M", "M", "M", "M");
        if (!*((int *)&index->padding_4c[24]))
        {
            v8 = sub_4c2d(0x1e200, 225, 105, "M", "M", "M", "M");
            if (index->field_68 > v8)
                return sub_4c2d(0x1e200, 0x33, 0x5c04, "M", "M", "M", "M");
        }
        if (*((int *)&index->padding_4c[24]) == 1)
        {
            v9 = sub_4c2d(0x1e200, 225, sub_1c, "M", "M", "M", "M");
            if (index->field_68 > v9)
                return sub_4c2d(0x1e200, 0x33, sub_5c24, "M", "M", "M", "M");
        }
        if (!sub_4c2d(0x1e200, 225, sub_20, "M", "M", "M", "M"))
            return sub_4c2d(0x1e200, 81, sub_4c2d(0x1e200, 45, 0x5d64, sub_4c2d(0x1e200, 177, index->field_48, index->field_48->field_4, "M", "M", "M"), "M", "M", "M"), "M", "M", "M", "M");
        v0 = *((int *)*((int *)(*((int *)(*((int *)(index->field_38->field_0 + index->field_6c * 4)) + 12)) + index->field_70 * 4)));
        v10 = ~(sub_0);
        v11 = v10;
        if (index->field_14)
            v11 = index->field_14->field_0;
        v13 = v11;
        if (*((int *)(4 + v3 + 24)))
            v10 = *((int *)*((int *)(4 + v3 + 24)));
        sub_4c2d(0x1e200, 156, 18, "M", "M", "M", "M");
        sub_4c2d(0x1e200, 52, "M", "M", "M", "M", "M");
        sub_4c2d(0x1e200, 20, sub_20, "M", "M", "M", "M");
        v14 = sub_57cd(v0, *((int *)*((int *)(4 + v3 + 72))), v13, v10);
    default:
        return v2;
    }
    return v14;
}


/* ===== sub_3eb9 @ 0x3eb9, size=706, cc=41 ===== */
typedef struct struct_0 {
    char padding_0[16];
    unsigned int field_10;
} struct_0;

typedef struct struct_3 {
    char padding_0[16];
    int field_10;
    char padding_14[20];
    unsigned int field_28;
} struct_3;

extern int g_1;
extern char g_10;
extern int g_11;
extern int g_14;
extern int g_19b;
extern char g_2;
extern char g_28;
extern int g_2c;
extern int g_2d;
extern int g_33;
extern int g_34;
extern int g_3f;
extern int g_4;
extern char g_40;
extern int g_50;
extern int g_51;
extern char g_54;
extern int g_5c04;
extern int g_5cac;
extern int g_5cc0;
extern int g_5cdc;
extern int g_5cf8;
extern int g_69;
extern char g_7;
extern int g_7d;
extern int g_9;
extern int g_be;
extern int g_bf;
extern char g_c;
extern int g_e1;

int sub_3eb9(unsigned int a0)
{
    unsigned int v3;  // r9
    int iter;  // r0
    int v13;  // r1
    struct_3 *v14;  // r7
    int v15;  // r4
    int v16;  // r0
    int v17;  // r5
    int v18;  // r0
    int v19;  // r0
    struct_0 *index;  // r1
    int v6;  // r0
    int v7;  // r2
    unsigned int idx[17];  // r2
    int v9;  // r1
    struct_0 *idx1;  // r1
    unsigned int v11;  // r0
    struct_0 *idx2;  // r2
    int v0;  // [bp-0x20]
    int v1;  // [bp-0x1c]
    int v2;  // [bp-0x18]

    iter = sub_4c2d(0x1e200, 0x11, *((int *)(4 + v3 + 40)), 4, "M", "M", "M");
    switch (a0)
    {
    case 2: case 12:
        index = 4 + v3;
        v6 = index->field_10;
        v7 = *((int *)&index[3].padding_0[4]);
        iter = v6 - v7;
        index->field_10 = iter;
        if (v6 < v7)
        {
            iter = sub_0;
            index->field_10 = sub_0;
            break;
        }
        break;
    case 4: case 14:
        idx1 = 4 + v3;
        v11 = idx1->field_10;
        iter = v11 - 1;
        idx1->field_10 = iter;
        if (v11 < 1)
        {
            iter = sub_0;
            idx1->field_10 = sub_0;
            break;
        }
        break;
    case 5: case 17: case 20:
        v14 = 4 + v3;
        if (v14->padding_0[2] == 1)
        {
            iter = sub_0;
            *((void* *)&v14->padding_0[2]) = sub_0;
            break;
        }
        else if (v14->padding_0[7] == -1)
        {
            v2 = sub_0;
            v0 = sub_0;
            v1 = sub_0;
            iter = sub_4c2d(0x1e200, 0x33, 0x5cac);
            break;
        }
        else if (!*((int *)(v14->field_28 + v14->field_10 * 4)))
        {
            iter = sub_4c2d(0x1e200, 0x33, 0x5cc0, "M", "M", "M", "M");
            break;
        }
        else
        {
            if (v14->padding_0[1] > sub_0)
            {
                v15 = 23772;
            }
            else
            {
                v16 = sub_3931();
                v17 = sub_4c2d(0x1e200, 63, v14[1].field_28, "M", "M", "M", "M");
                v15 = sub_4c2d(0x1e200, 45, sub_4c2d(0x1e200, 45, 0x5cf8, v16, "M", "M", "M"), v17, "M", "M", "M");
                sub_4c2d(0x1e200, 9, v17, "M", "M", "M", "M");
            }
            if (!sub_4c2d(0x1e200, 225, sub_20, "M", "M", "M", "M"))
            {
                iter = sub_4c2d(0x1e200, 81, v15, "M", "M", "M", "M");
                break;
            }
            else if (!v14->padding_0[7] && !((v18 = (int)sub_4c2d(0x1e200, 225, 105, "M", "M", "M", "M"), v14[1].field_28 <= sub_4c2d(0x1e200, 225, 105, "M", "M", "M", "M"))))
            {
                iter = sub_4c2d(0x1e200, 0x33, 0x5c04, "M", "M", "M", "M");
                break;
            }
            else if (v14->padding_0[7] == 1 && !((v19 = (int)sub_4c2d(0x1e200, 225, sub_1c, "M", "M", "M", "M"), v14[1].field_28 <= sub_4c2d(0x1e200, 225, sub_1c, "M", "M", "M", "M"))))
            {
                iter = sub_4c2d(0x1e200, 0x33, sub_5c24, "M", "M", "M", "M");
                break;
            }
            else
            {
                sub_4c2d(0x1e200, 52, "M", "M", "M", "M", "M");
                sub_4c2d(0x1e200, 20, sub_20, "M", "M", "M", "M");
                iter = sub_4c2d(0x1e200, 80, 411, v14->field_10, "M", "M", "M");
                break;
            }
        }
    case 6: case 15:
        idx2 = 4 + v3;
        v13 = idx2->field_10 + 1;
        idx2->field_10 = v13;
        if (v13 >= iter)
        {
            iter -= 1;
            idx2->field_10 = iter;
            break;
        }
        break;
    case 8: case 13:
        idx = 4 + v3;
        v9 = idx[4] + idx[16];
        idx[4] = v9;
        if (v9 >= iter)
        {
            iter -= 1;
            idx[4] = iter;
            break;
        }
        break;
    case 18:
        sub_5575();
        if (!*((int *)(4 + v3 + 12)))
        {
            sub_4c2d(0x1e200, 44, "M", "M", "M", "M", "M");
        }
        else
        {
            sub_4c2d(0x1e200, 190, *((int *)(4 + v3 + 12)), "M", "M", "M", "M");
            sub_4c2d(0x1e200, 191, "M", "M", "M", "M", "M");
        }
        iter = sub_4c2d(0x1e200, 125, "M", "M", "M", "M", "M");
    }
    return iter;
}


/* ===== sub_24f5 @ 0x24f5, size=948, cc=37 ===== */
typedef struct struct_0 {
    char padding_0[56];
    struct struct_1 *field_38;
    char padding_3c[48];
    unsigned int field_6c;
} struct_0;

typedef struct struct_1 {
    unsigned int field_0;
} struct_1;

extern int g_1;
extern unsigned int g_10;
extern int g_12;
extern int g_124;
extern int g_125;
extern int g_12c;
extern int g_14;
extern int g_1a;
extern int g_1d;
extern int g_24;
extern int g_28;
extern int g_29;
extern int g_2a;
extern int g_2d;
extern int g_31;
extern char g_38;
extern int g_3c;
extern char g_4;
extern int g_42;
extern int g_43;
extern unsigned int g_5;
extern int g_55;
extern int g_56;
extern int g_58;
extern int g_5b74;
extern int g_64;
extern char g_6c;
extern char g_70;
extern int g_7b;
extern int g_9c;
extern char g_a;
extern char g_c;
extern unsigned int g_c8;
extern int g_e1;
extern int g_ed;
extern unsigned int g_ff;

int sub_24f5(void)
{
    int v16;  // r5
    int v17;  // r4
    unsigned int v18;  // r9
    int v19;  // r0
    int v21;  // r2
    struct_0 *v22;  // r7
    unsigned int v23;  // r5
    int v0;  // [bp-0x50], Other Possible Types: unsigned int
    int v1;  // [bp-0x4c], Other Possible Types: unsigned int
    int v2;  // [bp-0x48]
    unsigned int v3;  // [bp-0x44]
    int v4;  // [bp-0x40], Other Possible Types: unsigned int
    int v5;  // [bp-0x3c], Other Possible Types: unsigned int
    unsigned int v6;  // [bp-0x38]
    unsigned int v7;  // [bp-0x34]
    int v8;  // [bp-0x30], Other Possible Types: unsigned int
    int v9;  // [bp-0x2c], Other Possible Types: unsigned int
    unsigned int v10;  // [bp-0x28], Other Possible Types: int
    int v11;  // [bp-0x27]
    int v12;  // [bp-0x24]
    char v13;  // [bp-0x20], Other Possible Types: unsigned int
    char v14;  // [bp-0x1c], Other Possible Types: unsigned int
    unsigned int v15;  // [bp-0x18]

    v16 = sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M");
    v12 = 26;
    v17 = 60;
    if (!*((int *)(4 + v18 + 56)))
        return sub_4c2d(0x1e200, 156, 18, "M", "M", "M", "M");
    sub_4c2d(0x1e200, 293, "M", "M", "M", "M", "M");
    v19 = sub_4c2d(0x1e200, 225, 237, "M", "M", "M", "M");
    if (v19 <= sub_0)
        return v19;
    sub_4c2d(0x1e200, 292, "M", "M", "M", "M", "M");
    sub_4bdd("M", "M", "M");
    if (!*((int *)(4 + v18 + 60)))
        sub_4c2d(0x1e200, 156, 20, "M", "M", "M", "M");
    if (sub_4c2d(0x1e200, 29, "M", "M", "M", "M", "M") >= 300)
        v17 = 100;
    sub_4c2d(0x1e200, 49, "M", sub_4c2d(0x1e200, 29, "M", "M", "M", "M", "M") - v17, v16, v17, "M");
    sub_4c2d(0x1e200, 0x55, "M", "M", 1, 1, 1);
    v15 = sub_4c2d(0x1e200, 29, "M", "M", "M", "M", "M") - sub_1c - v17;
    sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M");
    v21 = 1;
    v5 = 1;
    v3 = 16;
    v4 = 16;
    if (*((int *)(4 + v18 + 60)) != 1)
        v21 = sub_0;
    v1 = 4 + v18 + 112;
    v2 = v21;
    v0 = v15;
    v22 = 4 + v18;
    sub_bb5(*((int *)(*((int *)(v22->field_38->field_0 + v22->field_6c * 4)) + 12)), "M", v12);
    if (!*((int *)&v22->padding_3c[0]))
    {
        v23 = sub_4c2d(0x1e200, 45, 0x5b74, *((int *)(*((int *)(v22->field_38->field_0 + v22->field_6c * 4)) + 4)), "M", "M", "M");
        v10 = sub_4c2d(0x1e200, 225, 40, "M", "M", "M", "M");
        sub_4c2d(0x1e200, 42, v23, sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M"), v10, &v14, &v13);
        v3 = v23;
        v4 = sub_4c2d(0x1e200, sub_1c, "M", "M", "M", "M", "M", v23) - v14 >> 1;
        v5 = sub_4c2d(0x1e200, 29, "M", "M", "M", "M", "M") - v13 - (v17 - v13 >> 1);
        v6 = 0xff;
        v7 = 0xff;
        v8 = 200;
        v9 = sub_4c2d(0x1e200, 225, 41, "M", "M", "M", "M");
        v1 = sub_0;
        v0 = sub_0;
        v2 = sub_0;
        v10 = sub_4c2d(0x1e200, 225, 40, "M");
        sub_4c2d(0x1e200, 86, &v3, "M", "M", "M", "M");
    }
    else
    {
        if (!sub_4c2d(0x1e200, 225, 88, "M", "M", "M", "M"))
        {
            sub_4c2d(0x1e200, 20, 88, sub_4c2d(0x1e200, 66, *((int *)(*((int *)(*((int *)(*((int *)(*((int *)*((int *)(4 + v18 + 56))) + *((int *)(4 + v18 + 108)) * 4)) + 12)) + *((int *)(4 + v18 + 112)) * 4)) + 16)), v16 - 20, "M", "M", "M"), "M", "M", "M");
            sub_4c2d(0x1e200, 20, 123, "M", "M", "M", "M");
        }
        v4 = sub_4c2d(0x1e200, 225, 88, "M", "M", "M", "M");
        v5 = sub_4c2d(0x1e200, 225, 123, "M", "M", "M", "M");
        v6 = 5;
        v7 = sub_4c2d(0x1e200, 29, "M", "M", "M", "M", "M") - v17;
        v8 = v16 - 20;
        v9 = v17 - 10;
        v10 = sub_0;
        v11 = 1;
        sub_4c2d(0x1e200, 67, &v4, "M", "M", "M", "M");
    }
    return sub_4c2d(0x1e200, 36, 1, 1, "M", "M", "M");
}


/* ===== sub_41ad @ 0x41ad, size=622, cc=34 ===== */
typedef struct struct_0 {
    char padding_0[48];
    struct struct_1 *field_30;
    char padding_34[4];
    struct struct_1 *field_38;
    char padding_3c[16];
    struct struct_3 *field_4c;
    int field_50;
    char padding_54[8];
    int field_5c;
    char padding_60[12];
    unsigned int field_6c;
    unsigned int field_70;
} struct_0;

typedef struct struct_1 {
    unsigned int field_0;
} struct_1;

typedef struct struct_3 {
    int field_0;
    int field_4;
} struct_3;

extern int g_1;
extern int g_11c;
extern int g_12;
extern int g_123;
extern int g_124;
extern char g_13b;
extern int g_14;
extern int g_17;
extern int g_198;
extern int g_2c;
extern int g_2d;
extern char g_30;
extern int g_33;
extern int g_34;
extern char g_38;
extern char g_4;
extern char g_4c;
extern char g_50;
extern int g_51;
extern int g_5bec;
extern char g_5c;
extern int g_5c04;
extern int g_5c3c;
extern char g_6;
extern int g_69;
extern char g_6c;
extern char g_70;
extern int g_9c;
extern int g_a;
extern int g_a1;
extern char g_c;
extern int g_e1;
extern int g_e6;

int sub_41ad(int a0)
{
    int v1;  // r1
    int v2;  // r2
    int v3;  // r3
    unsigned int v4;  // r9
    struct_0 *v5;  // r4
    int v6;  // r0
    int v7;  // r0
    unsigned int v8;  // r5

    switch (a0)
    {
    case 5: case 17: case 20:
        v5 = 4 + v4;
        if (v5->field_4c && !v5->field_30)
        {
            sub_4c2d(0x1e200, 52, "M", "M", "M", "M", "M");
            sub_4c2d(0x1e200, 20, 291, v5->field_4c->field_0, "M", "M", "M");
            sub_4c2d(0x1e200, 20, 292, v5->field_4c->field_4, "M", "M", "M");
            return sub_4c2d(0x1e200, 161, -3, 10, "M", "M", "M");
        }
        if (!v5->padding_0[0])
            return sub_4c2d(0x1e200, 0x33, 0x5bec, "M", "M", "M", "M");
        if (!v5->padding_0[6])
        {
            v6 = sub_4c2d(0x1e200, 225, 105, "M", "M", "M", "M");
            if (v5->field_50 > v6)
                return sub_4c2d(0x1e200, 0x33, 0x5c04, "M", "M", "M", "M");
        }
        if (v5->padding_0[6] == 1)
        {
            v7 = sub_4c2d(0x1e200, 225, sub_1c, "M", "M", "M", "M");
            if (v5->field_50 > v7)
                return sub_4c2d(0x1e200, 0x33, sub_5c24, "M", "M", "M", "M");
        }
        if (!sub_4c2d(0x1e200, 225, sub_20, "M", "M", "M", "M"))
            return sub_4c2d(0x1e200, 81, sub_4c2d(0x1e200, 45, 0x5c3c, v5->field_5c, "M", "M", "M"), "M", "M", "M", "M");
        v8 = ~(sub_0);
        if (v5->field_30)
        {
            v8 = v5->field_30->field_0;
            break;
        }
        sub_4c2d(0x1e200, 156, 18, "M", "M", "M", "M");
        sub_4c2d(0x1e200, 52, "M", "M", "M", "M", "M");
        sub_4c2d(0x1e200, 20, sub_20, "M", "M", "M", "M");
        return (sub_4c2d(0x1e200, 225, 23, "M", "M", "M", "M") != 315 ? sub_4c2d(0x1e200, 284, 408, *((int *)*((int *)(*((int *)(*((int *)(v5->field_38->field_0 + v5->field_6c * 4)) + 12)) + v5->field_70 * 4))), ~(sub_0), "M", "M") : sub_4c2d(0x1e200, 284, sub_195, *((int *)*((int *)(*((int *)(*((int *)(v5->field_38->field_0 + v5->field_6c * 4)) + 12)) + v5->field_70 * 4))), v8, "M", "M"));
    case 18:
        sub_5491(sub_4c2d(0x1e200, 230, "M", "M", "M", "M", "M"), v1, v2, v3, "M", "M", "M");
        return sub_4c2d(0x1e200, 44, "M", "M", "M", "M", "M");
    default:
        return a0;
    }
}


/* ===== sub_bb5 @ 0xbb5, size=738, cc=29 ===== */
typedef struct struct_1 {
    char padding_0[4];
    unsigned int field_4;
    char field_8;
    char padding_9[3];
    unsigned int field_c;
} struct_1;

typedef struct struct_0 {
    char padding_0[24];
    char field_18;
} struct_0;

extern char g_1;
extern int g_11;
extern char g_14;
extern int g_150;
extern char g_18;
extern int g_19;
extern char g_1f;
extern int g_23;
extern int g_2a;
extern int g_2d;
extern int g_2e;
extern int g_2f;
extern char g_3;
extern int g_30;
extern int g_3b;
extern char g_3f;
extern int g_4;
extern char g_5;
extern int g_56;
extern int g_5b74;
extern char g_9;
extern int g_ae;
extern char g_c;
extern int g_d8;
extern int g_e1;
extern int g_e6;
extern unsigned int g_ff;

int sub_bb5(int a0, int a1, int a2, unsigned int a3, int a4, unsigned int *a5, unsigned int a6, unsigned int a7, unsigned int a8, unsigned int a9)
{
    unsigned int v29;  // r5
    unsigned int v30;  // r0
    unsigned int v39;  // r9
    int v31;  // r4
    int v32;  // r2
    unsigned int v33;  // r1
    unsigned int v34;  // r0
    unsigned int index;  // r5
    struct_1 *idx;  // r2
    struct_0 *v37;  // r2
    char v0;  // [bp-0xa8]
    unsigned int v1;  // [bp-0xa4]
    char v2;  // [bp-0x88]
    char v3;  // [bp-0x84]
    unsigned int v4;  // [bp-0x80]
    int v5;  // [bp-0x7c], Other Possible Types: unsigned int
    int v6;  // [bp-0x78], Other Possible Types: unsigned int
    unsigned int v7;  // [bp-0x74]
    unsigned int v8;  // [bp-0x70]
    unsigned int v9;  // [bp-0x6c]
    unsigned int v10;  // [bp-0x68]
    unsigned int v11;  // [bp-0x64]
    unsigned int v12;  // [bp-0x60]
    unsigned int v13;  // [bp-0x5c]
    unsigned int v14;  // [bp-0x58]
    unsigned int v15;  // [bp-0x54]
    unsigned int v16;  // [bp-0x50]
    unsigned int v17;  // [bp-0x4c]
    unsigned int v18;  // [bp-0x48]
    int v19;  // [bp-0x44]
    unsigned int v20;  // [bp-0x40]
    unsigned int v21;  // [bp-0x3c]
    int v22;  // [bp-0x38]
    unsigned int v23;  // [bp-0x34]
    int v24;  // [bp-0x30]
    char *v25;  // [bp-0x2c]
    unsigned int v26;  // [bp-0x28]
    int v27;  // [bp-0x20]
    unsigned int v28;  // [bp-0x18]

    v27 = a1;
    v28 = a3;
    v29 = sub_4c2d(0x1e200, 0x11, a0, 4, "M", "M", "M");
    v20 = sub_4c2d(0x1e200, 225, 45, "M", "M", "M", "M");
    v30 = sub_4c2d(0x1e200, 225, 46, "M", "M", "M", "M");
    v21 = v30;
    if (v29 > sub_0)
    {
        v19 = sub_20(25, a4);
        v31 = a2 + 3;
        v26 = *(a5);
        v32 = v19;
        v18 = sub_20(v19, *(a5)) * v32;
        v33 = v18 + v32;
        v34 = v29;
        if (v34 > v33)
            v34 = v33;
        v17 = v34;
        sub_4c2d(0x1e200, 59, a1 + v28 - 12, a2, a4, v29, v26);
        index = v18;
        v28 -= 12;
        v30 = v17;
        if (v30 > index)
        {
            v24 = a1 + 5;
            v23 = a1 + v28 - 63;
            v25 = &v2;
            while (true)
            {
                idx = *((int *)(a0 + index * 4));
                v16 = idx->field_4;
                v15 = idx->field_c;
                v14 = idx[1].field_4;
                v13 = sub_3931(*((char *)(idx + _start)), idx[1].field_4, idx, idx->field_c);
                v12 = v37->field_18;
                v22 = v31 - 5;
                sub_4c2d(0x1e200, 46, a1, v22, v28, 25, "M");
                if (a6 == 1 && sub_4c2d(0x1e200, 47, a1, v22, v28, 25, "M") == 1)
                {
                    if (*(a5) == index)
                    {
                        sub_4c2d(0x1e200, 35, 4, a1, v22, v28, 25);
                    }
                    else
                    {
                        *(a5) = index;
                        sub_4c2d(0x1e200, 230, "M", "M", "M", "M", "M");
                    }
                }
                if (*(a5) == index && a6)
                    sub_4c2d(0x1e200, 48, a1, v22, v28, 25, "M");
                if (a9)
                {
                    sub_4c2d(0x1e200, 174, v14, sub_4c2d(0x1e200, 45, 0x5b74, v15, "M", "M", "M"), v24, ((a8 - v21 >> 31) + a8 - v21 >> 1) + v31, ~(sub_0));
                }
                else if (v14 != 4294967295)
                {
                    v3 = v12;
                    v1 = v14;
                    sub_4c2d(0x1e200, 336, v15, &v0, v24, ((a8 - v21 >> 31) + a8 - v21 >> 1) + v31, 1);
                }
                else
                {
                    v5 = v24;
                    v4 = v15;
                    v6 = ((a8 - v21 >> 31) + a8 - v21 >> 1) + v31;
                    v7 = 0xff;
                    v8 = 0xff;
                    v9 = 0xff;
                    v10 = sub_0;
                    v11 = sub_0;
                    sub_4c2d(0x1e200, 86, &v4, "M", "M", "M", "M");
                }
                if (!*((char *)(4 + v39 + 3)))
                {
                    sub_4c2d(0x1e200, 42, v13, "M", "M", &v20, &v21);
                    v4 = v13;
                    v5 = v23 - v20 - 3;
                    v6 = v31 + 3;
                    v7 = 0xff;
                    v8 = 0xff;
                    v9 = 0xff;
                    v10 = sub_0;
                    v11 = sub_0;
                    sub_4c2d(0x1e200, 86, &v4, "M", "M", "M", "M");
                    sub_4c2d(0x1e200, 216, v16, v23, ((a8 - v21 >> 31) + a8 - v21 >> 1) + v31 + (v21 - 9 >> 1), "M", "M");
                }
                v31 += 25;
                index += 1;
                if (v17 <= index)
                    break;
            }
            return v17;
        }
    }
    return v30;
}


/* ===== sub_965 @ 0x965, size=586, cc=27 ===== */
typedef struct struct_0 {
    char padding_0[8];
    int field_8;
} struct_0;

typedef struct struct_1 {
    char padding_0[4];
    char field_4;
    char field_5;
    char field_6;
    char padding_7[73];
    unsigned int field_50;
    char padding_54[8];
    unsigned int field_5c;
    unsigned int field_60;
} struct_1;

extern unsigned int g_1;
extern char g_34;
extern int g_4;
extern int g_44;
extern int g_45;
extern int g_46;
extern int g_47;
extern char g_5;
extern char g_50;
extern char g_5c;
extern char g_6;
extern char g_60;
extern int g_a;
extern char g_ff;

int sub_965(struct_0 *a0)
{
    unsigned int i;  // r5
    unsigned int v1;  // r9
    unsigned int v10;  // r0
    unsigned int v11;  // r5
    unsigned int v12;  // r0
    unsigned int v13;  // r5
    unsigned int v14;  // r7
    unsigned int k;  // r6
    unsigned int index;  // r6
    unsigned int v17;  // r6
    struct_1 *idx;  // r6
    unsigned int v3;  // r6
    unsigned int idx1;  // r5
    unsigned int v5;  // r0
    unsigned int v6;  // r5
    unsigned int j;  // r5
    unsigned int v8;  // r6
    unsigned int idx2;  // r5

    i = sub_0;
    sub_4c2d(0x1e200, 0x44, a0, "M", "M", "M", "M");
    idx = 4 + v1;
    idx->field_6 = sub_4c2d(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M");
    idx->field_50 = sub_4c2d(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
    idx->field_4 = sub_4c2d(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M");
    idx->field_5 = sub_4c2d(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M");
    idx->field_5c = sub_4c2d(0x1e200, 71, *((int *)(a0 + _start)), "M", "M", "M", "M");
    idx->field_60 = sub_4c2d(0x1e200, 71, *((int *)(a0 + _start)), "M", "M", "M", "M");
    if ((char)sub_4c2d(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") == 1)
    {
        v3 = sub_4c2d(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") & 0xff;
        *((unsigned int *)(32 + v1)) = sub_4c2d(0x1e200, 10, v3, 4, "M", "M", "M");
        if (v3 > sub_0)
        {
            do
            {
                idx1 = i;
                v5 = sub_4c2d(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
                v6 = idx1 + 1;
                *((unsigned int *)(*((int *)(32 + v1)) + idx1 * 4)) = v5;
                i = v6;
            } while (i < v3);
        }
    }
    if ((char)sub_4c2d(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") == 1)
    {
        j = sub_0;
        v8 = sub_4c2d(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") & 0xff;
        *((unsigned int *)(36 + v1)) = sub_4c2d(0x1e200, 10, v8, 4, "M", "M", "M");
        if (v8 > sub_0)
        {
            do
            {
                idx2 = j;
                v10 = sub_4c2d(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
                v11 = idx2 + 1;
                *((unsigned int *)(*((int *)(36 + v1)) + idx2 * 4)) = v10;
                j = v11;
            } while (j < v8);
        }
    }
    v12 = sub_4c2d(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") & 0xff;
    if (v12 == 1)
    {
        v13 = sub_4c2d(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") & 0xff;
        v12 = sub_4c2d(0x1e200, 10, v13, 4, "M", "M", "M");
        v14 = v12;
        k = sub_0;
        if (v13 > sub_0)
        {
            do
            {
                index = k;
                v17 = index + 1;
                *((unsigned int *)(v14 + index * 4)) = sub_50a5(a0);
                k = v17;
            } while (k < v13);
        }
        *((unsigned int *)(4 + v1 + 52)) = v14;
    }
    return sub_3b39(v12);
}

