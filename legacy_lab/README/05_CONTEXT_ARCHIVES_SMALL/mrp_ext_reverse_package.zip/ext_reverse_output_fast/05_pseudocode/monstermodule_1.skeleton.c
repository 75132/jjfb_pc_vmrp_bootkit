/* Skeleton recovered from function map for monstermodule_1. Fill bodies from 02_disassembly. */
typedef int i32;

// addr=0x0, offset=0x0, mode=ARM, size=8, cc=1
i32 sub_0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8, offset=0x8, mode=ARM, size=20, cc=1
i32 _start(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c, offset=0x1c, mode=ARM, size=16, cc=1
i32 sub_1c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c, offset=0x2c, mode=ARM, size=8, cc=1
i32 sub_2c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34, offset=0x34, mode=ARM, size=8, cc=1
i32 sub_34(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3d, offset=0x3c, mode=Thumb, size=182, cc=3
i32 sub_3d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xfd, offset=0xfc, mode=Thumb, size=8, cc=1
i32 sub_fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x105, offset=0x104, mode=Thumb, size=212, cc=9
i32 sub_105(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d9, offset=0x1d8, mode=Thumb, size=4, cc=1
i32 sub_1d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1dd, offset=0x1dc, mode=Thumb, size=432, cc=21
i32 sub_1dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38d, offset=0x38c, mode=Thumb, size=4, cc=1
i32 sub_38d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x391, offset=0x390, mode=Thumb, size=3888, cc=187
i32 sub_391(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1349, offset=0x1348, mode=Thumb, size=398, cc=17
i32 sub_1349(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14f1, offset=0x14f0, mode=Thumb, size=300, cc=13
i32 sub_14f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x161d, offset=0x161c, mode=Thumb, size=4, cc=1
i32 sub_161d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1621, offset=0x1620, mode=Thumb, size=152, cc=7
i32 sub_1621(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16b9, offset=0x16b8, mode=Thumb, size=36, cc=1
i32 sub_16b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16dd, offset=0x16dc, mode=Thumb, size=12, cc=1
i32 sub_16dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16e9, offset=0x16e8, mode=Thumb, size=2, cc=1
i32 sub_16e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16eb, offset=0x16ea, mode=Thumb, size=266, cc=12
i32 sub_16eb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17f5, offset=0x17f4, mode=Thumb, size=48, cc=2
i32 sub_17f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1825, offset=0x1824, mode=Thumb, size=84, cc=3
i32 sub_1825(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1879, offset=0x1878, mode=Thumb, size=504, cc=22
i32 sub_1879(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a89, offset=0x1a88, mode=Thumb, size=300, cc=14
i32 sub_1a89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1bb5, offset=0x1bb4, mode=Thumb, size=4, cc=1
i32 sub_1bb5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1bb9, offset=0x1bb8, mode=Thumb, size=418, cc=21
i32 sub_1bb9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d6d, offset=0x1d6c, mode=Thumb, size=450, cc=16
i32 sub_1d6d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f31, offset=0x1f30, mode=Thumb, size=2136, cc=84
i32 sub_1f31(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x279d, offset=0x279c, mode=Thumb, size=384, cc=19
i32 sub_279d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x291d, offset=0x291c, mode=Thumb, size=4, cc=1
i32 sub_291d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2921, offset=0x2920, mode=Thumb, size=56, cc=4
i32 sub_2921(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2959, offset=0x2958, mode=Thumb, size=12, cc=1
i32 sub_2959(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2965, offset=0x2964, mode=Thumb, size=1024, cc=45
i32 sub_2965(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d95, offset=0x2d94, mode=Thumb, size=172, cc=8
i32 sub_2d95(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e41, offset=0x2e40, mode=Thumb, size=634, cc=28
i32 sub_2e41(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30d1, offset=0x30d0, mode=Thumb, size=126, cc=5
i32 sub_30d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3151, offset=0x3150, mode=Thumb, size=68, cc=8
i32 sub_3151(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3195, offset=0x3194, mode=Thumb, size=4, cc=1
i32 sub_3195(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3199, offset=0x3198, mode=Thumb, size=388, cc=25
i32 sub_3199(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x331d, offset=0x331c, mode=Thumb, size=926, cc=54
i32 sub_331d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36bd, offset=0x36bc, mode=Thumb, size=26, cc=1
i32 sub_36bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36c9, offset=0x36c8, mode=Thumb, size=94, cc=3
i32 sub_36c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x371d, offset=0x371c, mode=Thumb, size=54, cc=1
i32 sub_371d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3757, offset=0x3756, mode=Thumb, size=10, cc=1
i32 sub_3757(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3761, offset=0x3760, mode=Thumb, size=60, cc=2
i32 sub_3761(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x379d, offset=0x379c, mode=Thumb, size=10, cc=1
i32 sub_379d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37a7, offset=0x37a6, mode=Thumb, size=10, cc=1
i32 sub_37a7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37b1, offset=0x37b0, mode=Thumb, size=10, cc=1
i32 sub_37b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37bb, offset=0x37ba, mode=Thumb, size=10, cc=1
i32 sub_37bb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37c5, offset=0x37c4, mode=Thumb, size=8, cc=1
i32 sub_37c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37cd, offset=0x37cc, mode=Thumb, size=8, cc=1
i32 sub_37cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37d5, offset=0x37d4, mode=Thumb, size=12, cc=1
i32 sub_37d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37e1, offset=0x37e0, mode=Thumb, size=8, cc=1
i32 sub_37e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37e9, offset=0x37e8, mode=Thumb, size=10, cc=1
i32 sub_37e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37f3, offset=0x37f2, mode=Thumb, size=10, cc=1
i32 sub_37f3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37fd, offset=0x37fc, mode=Thumb, size=10, cc=1
i32 sub_37fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3807, offset=0x3806, mode=Thumb, size=10, cc=1
i32 sub_3807(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3811, offset=0x3810, mode=Thumb, size=30, cc=1
i32 sub_3811(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x382f, offset=0x382e, mode=Thumb, size=10, cc=2
i32 sub_382f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3839, offset=0x3838, mode=Thumb, size=44, cc=5
i32 sub_3839(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3865, offset=0x3864, mode=Thumb, size=36, cc=4
i32 sub_3865(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3889, offset=0x3888, mode=Thumb, size=22, cc=1
i32 sub_3889(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x389f, offset=0x389e, mode=Thumb, size=22, cc=1
i32 sub_389f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38bd, offset=0x38bc, mode=Thumb, size=52, cc=3
i32 sub_38bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38c9, offset=0x38c8, mode=Thumb, size=8, cc=1
i32 sub_38c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38d1, offset=0x38d0, mode=Thumb, size=118, cc=6
i32 sub_38d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x394d, offset=0x394c, mode=Thumb, size=12, cc=1
i32 sub_394d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3959, offset=0x3958, mode=Thumb, size=66, cc=1
i32 sub_3959(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39a1, offset=0x39a0, mode=Thumb, size=4, cc=1
i32 sub_39a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39a5, offset=0x39a4, mode=Thumb, size=4, cc=1
i32 sub_39a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39a9, offset=0x39a8, mode=Thumb, size=52, cc=1
i32 sub_39a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39dd, offset=0x39dc, mode=Thumb, size=40, cc=1
i32 sub_39dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a05, offset=0x3a04, mode=Thumb, size=42, cc=1
i32 sub_3a05(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a35, offset=0x3a34, mode=Thumb, size=14, cc=1
i32 sub_3a35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a49, offset=0x3a48, mode=Thumb, size=70, cc=2
i32 sub_3a49(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a91, offset=0x3a90, mode=Thumb, size=138, cc=6
i32 sub_3a91(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a97, offset=0x3a96, mode=Thumb, size=18, cc=1
i32 sub_3a97(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aa9, offset=0x3aa8, mode=Thumb, size=4, cc=1
i32 sub_3aa9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aad, offset=0x3aac, mode=Thumb, size=118, cc=11
i32 sub_3aad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3b41, offset=0x3b40, mode=Thumb, size=54, cc=2
i32 sub_3b41(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3b79, offset=0x3b78, mode=Thumb, size=4, cc=1
i32 sub_3b79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3b7d, offset=0x3b7c, mode=Thumb, size=90, cc=10
i32 sub_3b7d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3bd9, offset=0x3bd8, mode=Thumb, size=4, cc=1
i32 sub_3bd9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3bdd, offset=0x3bdc, mode=Thumb, size=276, cc=24
i32 sub_3bdd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3d09, offset=0x3d08, mode=Thumb, size=2, cc=1
i32 sub_3d09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3d39, offset=0x3d38, mode=Thumb, size=4, cc=1
i32 sub_3d39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3d3d, offset=0x3d3c, mode=Thumb, size=216, cc=18
i32 sub_3d3d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e1f, offset=0x3e1e, mode=Thumb, size=2, cc=1
i32 sub_3e1f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e21, offset=0x3e20, mode=Thumb, size=210, cc=8
i32 sub_3e21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3f79, offset=0x3f78, mode=Thumb, size=12, cc=1
i32 sub_3f79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3f85, offset=0x3f84, mode=Thumb, size=182, cc=7
i32 sub_3f85(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x403d, offset=0x403c, mode=Thumb, size=206, cc=8
i32 sub_403d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x410d, offset=0x410c, mode=Thumb, size=182, cc=7
i32 sub_410d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x41c5, offset=0x41c4, mode=Thumb, size=230, cc=9
i32 sub_41c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x42ad, offset=0x42ac, mode=Thumb, size=208, cc=8
i32 sub_42ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x437d, offset=0x437c, mode=Thumb, size=268, cc=10
i32 sub_437d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4488, offset=0x4488, mode=ARM, size=58, cc=2
i32 sub_4488(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44bf, offset=0x44be, mode=Thumb, size=48, cc=2
i32 sub_44bf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44ef, offset=0x44ee, mode=Thumb, size=8, cc=1
i32 sub_44ef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4503, offset=0x4502, mode=Thumb, size=10, cc=1
i32 sub_4503(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4511, offset=0x4510, mode=Thumb, size=2, cc=1
i32 sub_4511(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4513, offset=0x4512, mode=Thumb, size=4, cc=1
i32 sub_4513(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4524, offset=0x4524, mode=ARM, size=6, cc=1
i32 sub_4524(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x452b, offset=0x452a, mode=Thumb, size=2, cc=1
i32 sub_452b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4535, offset=0x4534, mode=Thumb, size=4, cc=1
i32 sub_4535(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4543, offset=0x4542, mode=Thumb, size=8, cc=1
i32 sub_4543(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4550, offset=0x4550, mode=ARM, size=4, cc=1
i32 sub_4550(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4564, offset=0x4564, mode=ARM, size=20, cc=1
i32 sub_4564(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4580, offset=0x4580, mode=ARM, size=4, cc=1
i32 sub_4580(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4584, offset=0x4584, mode=ARM, size=4, cc=1
i32 sub_4584(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45c0, offset=0x45c0, mode=ARM, size=8, cc=1
i32 sub_45c0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45cf, offset=0x45ce, mode=Thumb, size=10, cc=1
i32 sub_45cf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45d9, offset=0x45d8, mode=Thumb, size=2, cc=1
i32 sub_45d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45e4, offset=0x45e4, mode=ARM, size=8, cc=1
i32 sub_45e4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45f3, offset=0x45f2, mode=Thumb, size=2, cc=1
i32 sub_45f3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4614, offset=0x4614, mode=ARM, size=8, cc=1
i32 sub_4614(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x461c, offset=0x461c, mode=ARM, size=8, cc=1
i32 sub_461c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4633, offset=0x4632, mode=Thumb, size=2, cc=1
i32 sub_4633(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x463d, offset=0x463c, mode=Thumb, size=12, cc=1
i32 sub_463d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x464d, offset=0x464c, mode=Thumb, size=4, cc=1
i32 sub_464d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4679, offset=0x4678, mode=Thumb, size=2, cc=1
i32 sub_4679(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x467f, offset=0x467e, mode=Thumb, size=16, cc=1
i32 sub_467f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x469f, offset=0x469e, mode=Thumb, size=8, cc=1
i32 sub_469f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x46e0, offset=0x46e0, mode=ARM, size=2, cc=1
i32 sub_46e0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x46e3, offset=0x46e2, mode=Thumb, size=4, cc=1
i32 sub_46e3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x46ff, offset=0x46fe, mode=Thumb, size=8, cc=1
i32 sub_46ff(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x470d, offset=0x470c, mode=Thumb, size=4, cc=1
i32 sub_470d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4715, offset=0x4714, mode=Thumb, size=12, cc=1
i32 sub_4715(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4723, offset=0x4722, mode=Thumb, size=6, cc=1
i32 sub_4723(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x472b, offset=0x472a, mode=Thumb, size=2, cc=1
i32 sub_472b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x473c, offset=0x473c, mode=ARM, size=4, cc=1
i32 sub_473c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4764, offset=0x4764, mode=ARM, size=8, cc=1
i32 sub_4764(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4791, offset=0x4790, mode=Thumb, size=4, cc=1
i32 sub_4791(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47a3, offset=0x47a2, mode=Thumb, size=2, cc=1
i32 sub_47a3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47a8, offset=0x47a8, mode=ARM, size=8, cc=1
i32 sub_47a8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47b0, offset=0x47b0, mode=ARM, size=4, cc=1
i32 sub_47b0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47bb, offset=0x47ba, mode=Thumb, size=4, cc=1
i32 sub_47bb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x100014, offset=0x100014, mode=ARM, size=0, cc=1
i32 UnresolvableJumpTarget(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x100018, offset=0x100018, mode=ARM, size=0, cc=1
i32 UnresolvableCallTarget(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

