/* Skeleton recovered from function map for betmodule_2. Fill bodies from 02_disassembly. */
typedef int i32;

// addr=0x0, offset=0x0, mode=ARM, size=8, cc=1
i32 sub_0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8, offset=0x8, mode=ARM, size=20, cc=1
i32 _start(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c, offset=0x1c, mode=ARM, size=4, cc=1
i32 sub_1c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20, offset=0x20, mode=ARM, size=284, cc=7
i32 sub_20(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf4, offset=0xf4, mode=ARM, size=4, cc=1
i32 sub_f4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x109, offset=0x108, mode=Thumb, size=2, cc=1
i32 sub_109(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10b, offset=0x10a, mode=Thumb, size=2, cc=1
i32 sub_10b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x135, offset=0x134, mode=Thumb, size=58, cc=3
i32 sub_135(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x177, offset=0x176, mode=Thumb, size=6, cc=1
i32 sub_177(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18d, offset=0x18c, mode=Thumb, size=8, cc=1
i32 sub_18d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x195, offset=0x194, mode=Thumb, size=150, cc=18
i32 sub_195(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x231, offset=0x230, mode=Thumb, size=130, cc=1
i32 sub_231(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b5, offset=0x2b4, mode=Thumb, size=18, cc=1
i32 sub_2b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c8, offset=0x2c8, mode=ARM, size=16, cc=1
i32 sub_2c8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d8, offset=0x2d8, mode=ARM, size=8, cc=1
i32 sub_2d8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e0, offset=0x2e0, mode=ARM, size=8, cc=1
i32 sub_2e0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e9, offset=0x2e8, mode=Thumb, size=182, cc=3
i32 sub_2e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a1, offset=0x3a0, mode=Thumb, size=250, cc=18
i32 sub_3a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ad, offset=0x4ac, mode=Thumb, size=12, cc=1
i32 sub_4ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4b9, offset=0x4b8, mode=Thumb, size=1030, cc=50
i32 sub_4b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8f9, offset=0x8f8, mode=Thumb, size=470, cc=28
i32 sub_8f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaed, offset=0xaec, mode=Thumb, size=804, cc=33
i32 sub_aed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe11, offset=0xe10, mode=Thumb, size=8, cc=1
i32 sub_e11(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe19, offset=0xe18, mode=Thumb, size=150, cc=6
i32 sub_e19(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xeb1, offset=0xeb0, mode=Thumb, size=4, cc=1
i32 sub_eb1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xeb5, offset=0xeb4, mode=Thumb, size=220, cc=9
i32 sub_eb5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf91, offset=0xf90, mode=Thumb, size=4, cc=1
i32 sub_f91(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf95, offset=0xf94, mode=Thumb, size=1700, cc=65
i32 sub_f95(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1685, offset=0x1684, mode=Thumb, size=728, cc=31
i32 sub_1685(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1975, offset=0x1974, mode=Thumb, size=174, cc=5
i32 sub_1975(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a25, offset=0x1a24, mode=Thumb, size=8, cc=1
i32 sub_1a25(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a2d, offset=0x1a2c, mode=Thumb, size=1986, cc=74
i32 sub_1a2d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2249, offset=0x2248, mode=Thumb, size=76, cc=2
i32 sub_2249(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2295, offset=0x2294, mode=Thumb, size=4, cc=1
i32 sub_2295(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2299, offset=0x2298, mode=Thumb, size=116, cc=4
i32 sub_2299(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x230d, offset=0x230c, mode=Thumb, size=4, cc=1
i32 sub_230d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2311, offset=0x2310, mode=Thumb, size=92, cc=4
i32 sub_2311(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x236d, offset=0x236c, mode=Thumb, size=4, cc=1
i32 sub_236d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2371, offset=0x2370, mode=Thumb, size=534, cc=22
i32 sub_2371(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2589, offset=0x2588, mode=Thumb, size=8, cc=1
i32 sub_2589(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2591, offset=0x2590, mode=Thumb, size=188, cc=8
i32 sub_2591(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x264d, offset=0x264c, mode=Thumb, size=8, cc=1
i32 sub_264d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2655, offset=0x2654, mode=Thumb, size=200, cc=19
i32 sub_2655(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x271d, offset=0x271c, mode=Thumb, size=4, cc=1
i32 sub_271d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2721, offset=0x2720, mode=Thumb, size=212, cc=17
i32 sub_2721(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2809, offset=0x2808, mode=Thumb, size=4, cc=1
i32 sub_2809(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x280d, offset=0x280c, mode=Thumb, size=170, cc=15
i32 sub_280d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28b9, offset=0x28b8, mode=Thumb, size=4, cc=1
i32 sub_28b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28bd, offset=0x28bc, mode=Thumb, size=290, cc=21
i32 sub_28bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29e1, offset=0x29e0, mode=Thumb, size=4, cc=1
i32 sub_29e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29e5, offset=0x29e4, mode=Thumb, size=54, cc=1
i32 sub_29e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2a1b, offset=0x2a1a, mode=Thumb, size=64, cc=4
i32 sub_2a1b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2a61, offset=0x2a60, mode=Thumb, size=12, cc=1
i32 sub_2a61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2a6d, offset=0x2a6c, mode=Thumb, size=66, cc=1
i32 sub_2a6d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ab5, offset=0x2ab4, mode=Thumb, size=4, cc=1
i32 sub_2ab5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ab9, offset=0x2ab8, mode=Thumb, size=4, cc=1
i32 sub_2ab9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2abd, offset=0x2abc, mode=Thumb, size=52, cc=1
i32 sub_2abd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2af1, offset=0x2af0, mode=Thumb, size=40, cc=1
i32 sub_2af1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b19, offset=0x2b18, mode=Thumb, size=42, cc=1
i32 sub_2b19(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b49, offset=0x2b48, mode=Thumb, size=14, cc=1
i32 sub_2b49(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b5d, offset=0x2b5c, mode=Thumb, size=70, cc=2
i32 sub_2b5d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ba9, offset=0x2ba8, mode=Thumb, size=20, cc=1
i32 sub_2ba9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bbd, offset=0x2bbc, mode=Thumb, size=4, cc=1
i32 sub_2bbd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bc1, offset=0x2bc0, mode=Thumb, size=134, cc=12
i32 sub_2bc1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c55, offset=0x2c54, mode=Thumb, size=54, cc=2
i32 sub_2c55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c8d, offset=0x2c8c, mode=Thumb, size=4, cc=1
i32 sub_2c8d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c91, offset=0x2c90, mode=Thumb, size=90, cc=10
i32 sub_2c91(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ced, offset=0x2cec, mode=Thumb, size=4, cc=1
i32 sub_2ced(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cf1, offset=0x2cf0, mode=Thumb, size=276, cc=24
i32 sub_2cf1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e1d, offset=0x2e1c, mode=Thumb, size=44, cc=3
i32 sub_2e1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e49, offset=0x2e48, mode=Thumb, size=8, cc=1
i32 sub_2e49(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e51, offset=0x2e50, mode=Thumb, size=216, cc=18
i32 sub_2e51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f29, offset=0x2f28, mode=Thumb, size=2, cc=1
i32 sub_2f29(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f33, offset=0x2f32, mode=Thumb, size=2, cc=1
i32 sub_2f33(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f35, offset=0x2f34, mode=Thumb, size=342, cc=20
i32 sub_2f35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x308d, offset=0x308c, mode=Thumb, size=4, cc=1
i32 sub_308d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3091, offset=0x3090, mode=Thumb, size=46, cc=2
i32 sub_3091(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30c1, offset=0x30c0, mode=Thumb, size=4, cc=1
i32 sub_30c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30c5, offset=0x30c4, mode=Thumb, size=232, cc=9
i32 sub_30c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31ad, offset=0x31ac, mode=Thumb, size=104, cc=3
i32 sub_31ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3215, offset=0x3214, mode=Thumb, size=28, cc=2
i32 sub_3215(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3231, offset=0x3230, mode=Thumb, size=74, cc=3
i32 sub_3231(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3281, offset=0x3280, mode=Thumb, size=6, cc=1
i32 sub_3281(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3294, offset=0x3294, mode=ARM, size=2, cc=1
i32 sub_3294(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3297, offset=0x3296, mode=Thumb, size=2, cc=1
i32 sub_3297(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32a7, offset=0x32a6, mode=Thumb, size=2, cc=1
i32 sub_32a7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32a9, offset=0x32a8, mode=Thumb, size=14, cc=1
i32 sub_32a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32b8, offset=0x32b8, mode=ARM, size=20, cc=1
i32 sub_32b8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32d0, offset=0x32d0, mode=ARM, size=54, cc=1
i32 sub_32d0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x330c, offset=0x330c, mode=ARM, size=12, cc=1
i32 sub_330c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3325, offset=0x3324, mode=Thumb, size=4, cc=1
i32 sub_3325(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3333, offset=0x3332, mode=Thumb, size=14, cc=1
i32 sub_3333(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x336c, offset=0x336c, mode=ARM, size=2, cc=1
i32 sub_336c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x336f, offset=0x336e, mode=Thumb, size=2, cc=1
i32 sub_336f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x338d, offset=0x338c, mode=Thumb, size=6, cc=1
i32 sub_338d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33a1, offset=0x33a0, mode=Thumb, size=4, cc=1
i32 sub_33a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33ab, offset=0x33aa, mode=Thumb, size=10, cc=1
i32 sub_33ab(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33d7, offset=0x33d6, mode=Thumb, size=6, cc=1
i32 sub_33d7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33dd, offset=0x33dc, mode=Thumb, size=12, cc=1
i32 sub_33dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3409, offset=0x3408, mode=Thumb, size=8, cc=1
i32 sub_3409(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x341d, offset=0x341c, mode=Thumb, size=2, cc=1
i32 sub_341d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x341f, offset=0x341e, mode=Thumb, size=4, cc=1
i32 sub_341f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x342b, offset=0x342a, mode=Thumb, size=4, cc=1
i32 sub_342b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3460, offset=0x3460, mode=ARM, size=18, cc=1
i32 sub_3460(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x347d, offset=0x347c, mode=Thumb, size=8, cc=1
i32 sub_347d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x348b, offset=0x348a, mode=Thumb, size=2, cc=1
i32 sub_348b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x348d, offset=0x348c, mode=Thumb, size=6, cc=1
i32 sub_348d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3568, offset=0x3568, mode=ARM, size=20, cc=1
i32 sub_3568(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x373c, offset=0x373c, mode=ARM, size=8, cc=1
i32 sub_373c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x100014, offset=0x100014, mode=ARM, size=0, cc=1
i32 UnresolvableJumpTarget(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x100018, offset=0x100018, mode=ARM, size=0, cc=1
i32 UnresolvableCallTarget(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

