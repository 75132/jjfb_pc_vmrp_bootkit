/* Skeleton recovered from function map for cfunction_1. Fill bodies from 02_disassembly. */
typedef int i32;

// addr=0x8, offset=0x8, mode=ARM, size=None, cc=None
i32 candidate_000008(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb, offset=0xa, mode=Thumb, size=None, cc=None
i32 candidate_00000a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2157, offset=0x2156, mode=Thumb, size=None, cc=None
i32 candidate_002156(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x265f, offset=0x265e, mode=Thumb, size=None, cc=None
i32 candidate_00265e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26ab, offset=0x26aa, mode=Thumb, size=None, cc=None
i32 candidate_0026aa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26cb, offset=0x26ca, mode=Thumb, size=None, cc=None
i32 candidate_0026ca(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26ff, offset=0x26fe, mode=Thumb, size=None, cc=None
i32 candidate_0026fe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2719, offset=0x2718, mode=Thumb, size=None, cc=None
i32 candidate_002718(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x275d, offset=0x275c, mode=Thumb, size=None, cc=None
i32 candidate_00275c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x275f, offset=0x275e, mode=Thumb, size=None, cc=None
i32 candidate_00275e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27cd, offset=0x27cc, mode=Thumb, size=None, cc=None
i32 candidate_0027cc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28ed, offset=0x28ec, mode=Thumb, size=None, cc=None
i32 candidate_0028ec(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x293b, offset=0x293a, mode=Thumb, size=None, cc=None
i32 candidate_00293a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2acb, offset=0x2aca, mode=Thumb, size=None, cc=None
i32 candidate_002aca(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2aff, offset=0x2afe, mode=Thumb, size=None, cc=None
i32 candidate_002afe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b33, offset=0x2b32, mode=Thumb, size=None, cc=None
i32 candidate_002b32(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ba7, offset=0x2ba6, mode=Thumb, size=None, cc=None
i32 candidate_002ba6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c33, offset=0x2c32, mode=Thumb, size=None, cc=None
i32 candidate_002c32(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c73, offset=0x2c72, mode=Thumb, size=None, cc=None
i32 candidate_002c72(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ddb, offset=0x2dda, mode=Thumb, size=None, cc=None
i32 candidate_002dda(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2dfb, offset=0x2dfa, mode=Thumb, size=None, cc=None
i32 candidate_002dfa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ee3, offset=0x2ee2, mode=Thumb, size=None, cc=None
i32 candidate_002ee2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30ab, offset=0x30aa, mode=Thumb, size=None, cc=None
i32 candidate_0030aa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3123, offset=0x3122, mode=Thumb, size=None, cc=None
i32 candidate_003122(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31af, offset=0x31ae, mode=Thumb, size=None, cc=None
i32 candidate_0031ae(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31fb, offset=0x31fa, mode=Thumb, size=None, cc=None
i32 candidate_0031fa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x323b, offset=0x323a, mode=Thumb, size=None, cc=None
i32 candidate_00323a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33db, offset=0x33da, mode=Thumb, size=None, cc=None
i32 candidate_0033da(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33fb, offset=0x33fa, mode=Thumb, size=None, cc=None
i32 candidate_0033fa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3463, offset=0x3462, mode=Thumb, size=None, cc=None
i32 candidate_003462(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3597, offset=0x3596, mode=Thumb, size=None, cc=None
i32 candidate_003596(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37b7, offset=0x37b6, mode=Thumb, size=None, cc=None
i32 candidate_0037b6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37ff, offset=0x37fe, mode=Thumb, size=None, cc=None
i32 candidate_0037fe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x398b, offset=0x398a, mode=Thumb, size=None, cc=None
i32 candidate_00398a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a13, offset=0x3a12, mode=Thumb, size=None, cc=None
i32 candidate_003a12(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ad3, offset=0x3ad2, mode=Thumb, size=None, cc=None
i32 candidate_003ad2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3b5f, offset=0x3b5e, mode=Thumb, size=None, cc=None
i32 candidate_003b5e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ba3, offset=0x3ba2, mode=Thumb, size=None, cc=None
i32 candidate_003ba2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3c07, offset=0x3c06, mode=Thumb, size=None, cc=None
i32 candidate_003c06(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3c23, offset=0x3c22, mode=Thumb, size=None, cc=None
i32 candidate_003c22(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e8b, offset=0x3e8a, mode=Thumb, size=None, cc=None
i32 candidate_003e8a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3f27, offset=0x3f26, mode=Thumb, size=None, cc=None
i32 candidate_003f26(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4243, offset=0x4242, mode=Thumb, size=None, cc=None
i32 candidate_004242(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x435b, offset=0x435a, mode=Thumb, size=None, cc=None
i32 candidate_00435a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44ff, offset=0x44fe, mode=Thumb, size=None, cc=None
i32 candidate_0044fe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4607, offset=0x4606, mode=Thumb, size=None, cc=None
i32 candidate_004606(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4757, offset=0x4756, mode=Thumb, size=None, cc=None
i32 candidate_004756(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47d7, offset=0x47d6, mode=Thumb, size=None, cc=None
i32 candidate_0047d6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x488b, offset=0x488a, mode=Thumb, size=None, cc=None
i32 candidate_00488a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x492f, offset=0x492e, mode=Thumb, size=None, cc=None
i32 candidate_00492e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4abf, offset=0x4abe, mode=Thumb, size=None, cc=None
i32 candidate_004abe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4b0f, offset=0x4b0e, mode=Thumb, size=None, cc=None
i32 candidate_004b0e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4bb7, offset=0x4bb6, mode=Thumb, size=None, cc=None
i32 candidate_004bb6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4be3, offset=0x4be2, mode=Thumb, size=None, cc=None
i32 candidate_004be2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4caf, offset=0x4cae, mode=Thumb, size=None, cc=None
i32 candidate_004cae(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4d87, offset=0x4d86, mode=Thumb, size=None, cc=None
i32 candidate_004d86(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ecf, offset=0x4ece, mode=Thumb, size=None, cc=None
i32 candidate_004ece(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4fa3, offset=0x4fa2, mode=Thumb, size=None, cc=None
i32 candidate_004fa2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x508b, offset=0x508a, mode=Thumb, size=None, cc=None
i32 candidate_00508a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x50bf, offset=0x50be, mode=Thumb, size=None, cc=None
i32 candidate_0050be(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x51d7, offset=0x51d6, mode=Thumb, size=None, cc=None
i32 candidate_0051d6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x52df, offset=0x52de, mode=Thumb, size=None, cc=None
i32 candidate_0052de(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5403, offset=0x5402, mode=Thumb, size=None, cc=None
i32 candidate_005402(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x54bb, offset=0x54ba, mode=Thumb, size=None, cc=None
i32 candidate_0054ba(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5517, offset=0x5516, mode=Thumb, size=None, cc=None
i32 candidate_005516(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5583, offset=0x5582, mode=Thumb, size=None, cc=None
i32 candidate_005582(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x56f7, offset=0x56f6, mode=Thumb, size=None, cc=None
i32 candidate_0056f6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x584b, offset=0x584a, mode=Thumb, size=None, cc=None
i32 candidate_00584a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5a13, offset=0x5a12, mode=Thumb, size=None, cc=None
i32 candidate_005a12(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5a93, offset=0x5a92, mode=Thumb, size=None, cc=None
i32 candidate_005a92(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5acf, offset=0x5ace, mode=Thumb, size=None, cc=None
i32 candidate_005ace(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5d77, offset=0x5d76, mode=Thumb, size=None, cc=None
i32 candidate_005d76(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6077, offset=0x6076, mode=Thumb, size=None, cc=None
i32 candidate_006076(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x61db, offset=0x61da, mode=Thumb, size=None, cc=None
i32 candidate_0061da(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6357, offset=0x6356, mode=Thumb, size=None, cc=None
i32 candidate_006356(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x642b, offset=0x642a, mode=Thumb, size=None, cc=None
i32 candidate_00642a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x65b3, offset=0x65b2, mode=Thumb, size=None, cc=None
i32 candidate_0065b2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x662f, offset=0x662e, mode=Thumb, size=None, cc=None
i32 candidate_00662e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x665b, offset=0x665a, mode=Thumb, size=None, cc=None
i32 candidate_00665a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x668f, offset=0x668e, mode=Thumb, size=None, cc=None
i32 candidate_00668e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6753, offset=0x6752, mode=Thumb, size=None, cc=None
i32 candidate_006752(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x677f, offset=0x677e, mode=Thumb, size=None, cc=None
i32 candidate_00677e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x67b7, offset=0x67b6, mode=Thumb, size=None, cc=None
i32 candidate_0067b6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x67df, offset=0x67de, mode=Thumb, size=None, cc=None
i32 candidate_0067de(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6813, offset=0x6812, mode=Thumb, size=None, cc=None
i32 candidate_006812(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x685b, offset=0x685a, mode=Thumb, size=None, cc=None
i32 candidate_00685a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x691b, offset=0x691a, mode=Thumb, size=None, cc=None
i32 candidate_00691a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x694f, offset=0x694e, mode=Thumb, size=None, cc=None
i32 candidate_00694e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x69c3, offset=0x69c2, mode=Thumb, size=None, cc=None
i32 candidate_0069c2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6a23, offset=0x6a22, mode=Thumb, size=None, cc=None
i32 candidate_006a22(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6a63, offset=0x6a62, mode=Thumb, size=None, cc=None
i32 candidate_006a62(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6aa3, offset=0x6aa2, mode=Thumb, size=None, cc=None
i32 candidate_006aa2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6ab3, offset=0x6ab2, mode=Thumb, size=None, cc=None
i32 candidate_006ab2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6af3, offset=0x6af2, mode=Thumb, size=None, cc=None
i32 candidate_006af2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6b9b, offset=0x6b9a, mode=Thumb, size=None, cc=None
i32 candidate_006b9a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6c1b, offset=0x6c1a, mode=Thumb, size=None, cc=None
i32 candidate_006c1a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6cc3, offset=0x6cc2, mode=Thumb, size=None, cc=None
i32 candidate_006cc2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6da7, offset=0x6da6, mode=Thumb, size=None, cc=None
i32 candidate_006da6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6df3, offset=0x6df2, mode=Thumb, size=None, cc=None
i32 candidate_006df2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6e47, offset=0x6e46, mode=Thumb, size=None, cc=None
i32 candidate_006e46(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6ebb, offset=0x6eba, mode=Thumb, size=None, cc=None
i32 candidate_006eba(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6f2f, offset=0x6f2e, mode=Thumb, size=None, cc=None
i32 candidate_006f2e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6f6f, offset=0x6f6e, mode=Thumb, size=None, cc=None
i32 candidate_006f6e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x705b, offset=0x705a, mode=Thumb, size=None, cc=None
i32 candidate_00705a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7243, offset=0x7242, mode=Thumb, size=None, cc=None
i32 candidate_007242(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x737f, offset=0x737e, mode=Thumb, size=None, cc=None
i32 candidate_00737e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x73b3, offset=0x73b2, mode=Thumb, size=None, cc=None
i32 candidate_0073b2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x73f3, offset=0x73f2, mode=Thumb, size=None, cc=None
i32 candidate_0073f2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x751f, offset=0x751e, mode=Thumb, size=None, cc=None
i32 candidate_00751e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7557, offset=0x7556, mode=Thumb, size=None, cc=None
i32 candidate_007556(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x75ed, offset=0x75ec, mode=Thumb, size=None, cc=None
i32 candidate_0075ec(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7cb7, offset=0x7cb6, mode=Thumb, size=None, cc=None
i32 candidate_007cb6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x82a7, offset=0x82a6, mode=Thumb, size=None, cc=None
i32 candidate_0082a6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x82cf, offset=0x82ce, mode=Thumb, size=None, cc=None
i32 candidate_0082ce(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x840f, offset=0x840e, mode=Thumb, size=None, cc=None
i32 candidate_00840e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8413, offset=0x8412, mode=Thumb, size=None, cc=None
i32 candidate_008412(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x857f, offset=0x857e, mode=Thumb, size=None, cc=None
i32 candidate_00857e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x86a3, offset=0x86a2, mode=Thumb, size=None, cc=None
i32 candidate_0086a2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x87a7, offset=0x87a6, mode=Thumb, size=None, cc=None
i32 candidate_0087a6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x88ff, offset=0x88fe, mode=Thumb, size=None, cc=None
i32 candidate_0088fe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8e23, offset=0x8e22, mode=Thumb, size=None, cc=None
i32 candidate_008e22(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9393, offset=0x9392, mode=Thumb, size=None, cc=None
i32 candidate_009392(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c87, offset=0x9c86, mode=Thumb, size=None, cc=None
i32 candidate_009c86(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xab67, offset=0xab66, mode=Thumb, size=None, cc=None
i32 candidate_00ab66(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xade3, offset=0xade2, mode=Thumb, size=None, cc=None
i32 candidate_00ade2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb10b, offset=0xb10a, mode=Thumb, size=None, cc=None
i32 candidate_00b10a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb18f, offset=0xb18e, mode=Thumb, size=None, cc=None
i32 candidate_00b18e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb28f, offset=0xb28e, mode=Thumb, size=None, cc=None
i32 candidate_00b28e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xc78f, offset=0xc78e, mode=Thumb, size=None, cc=None
i32 candidate_00c78e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xc9fb, offset=0xc9fa, mode=Thumb, size=None, cc=None
i32 candidate_00c9fa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xcb33, offset=0xcb32, mode=Thumb, size=None, cc=None
i32 candidate_00cb32(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xcbef, offset=0xcbee, mode=Thumb, size=None, cc=None
i32 candidate_00cbee(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xcc83, offset=0xcc82, mode=Thumb, size=None, cc=None
i32 candidate_00cc82(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xcc97, offset=0xcc96, mode=Thumb, size=None, cc=None
i32 candidate_00cc96(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xcd63, offset=0xcd62, mode=Thumb, size=None, cc=None
i32 candidate_00cd62(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xcdcf, offset=0xcdce, mode=Thumb, size=None, cc=None
i32 candidate_00cdce(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xceb7, offset=0xceb6, mode=Thumb, size=None, cc=None
i32 candidate_00ceb6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xd977, offset=0xd976, mode=Thumb, size=None, cc=None
i32 candidate_00d976(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xda1f, offset=0xda1e, mode=Thumb, size=None, cc=None
i32 candidate_00da1e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xdb43, offset=0xdb42, mode=Thumb, size=None, cc=None
i32 candidate_00db42(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xdbc7, offset=0xdbc6, mode=Thumb, size=None, cc=None
i32 candidate_00dbc6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xdc6f, offset=0xdc6e, mode=Thumb, size=None, cc=None
i32 candidate_00dc6e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xdd1f, offset=0xdd1e, mode=Thumb, size=None, cc=None
i32 candidate_00dd1e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe1cb, offset=0xe1ca, mode=Thumb, size=None, cc=None
i32 candidate_00e1ca(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe353, offset=0xe352, mode=Thumb, size=None, cc=None
i32 candidate_00e352(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe383, offset=0xe382, mode=Thumb, size=None, cc=None
i32 candidate_00e382(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe3f7, offset=0xe3f6, mode=Thumb, size=None, cc=None
i32 candidate_00e3f6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe653, offset=0xe652, mode=Thumb, size=None, cc=None
i32 candidate_00e652(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe707, offset=0xe706, mode=Thumb, size=None, cc=None
i32 candidate_00e706(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe82f, offset=0xe82e, mode=Thumb, size=None, cc=None
i32 candidate_00e82e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe957, offset=0xe956, mode=Thumb, size=None, cc=None
i32 candidate_00e956(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xebbb, offset=0xebba, mode=Thumb, size=None, cc=None
i32 candidate_00ebba(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xebbf, offset=0xebbe, mode=Thumb, size=None, cc=None
i32 candidate_00ebbe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf0bf, offset=0xf0be, mode=Thumb, size=None, cc=None
i32 candidate_00f0be(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf187, offset=0xf186, mode=Thumb, size=None, cc=None
i32 candidate_00f186(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf25b, offset=0xf25a, mode=Thumb, size=None, cc=None
i32 candidate_00f25a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf46b, offset=0xf46a, mode=Thumb, size=None, cc=None
i32 candidate_00f46a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf7db, offset=0xf7da, mode=Thumb, size=None, cc=None
i32 candidate_00f7da(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf907, offset=0xf906, mode=Thumb, size=None, cc=None
i32 candidate_00f906(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xfc77, offset=0xfc76, mode=Thumb, size=None, cc=None
i32 candidate_00fc76(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xfcc3, offset=0xfcc2, mode=Thumb, size=None, cc=None
i32 candidate_00fcc2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10007, offset=0x10006, mode=Thumb, size=None, cc=None
i32 candidate_010006(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1002f, offset=0x1002e, mode=Thumb, size=None, cc=None
i32 candidate_01002e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1008f, offset=0x1008e, mode=Thumb, size=None, cc=None
i32 candidate_01008e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10153, offset=0x10152, mode=Thumb, size=None, cc=None
i32 candidate_010152(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x101df, offset=0x101de, mode=Thumb, size=None, cc=None
i32 candidate_0101de(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10267, offset=0x10266, mode=Thumb, size=None, cc=None
i32 candidate_010266(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10303, offset=0x10302, mode=Thumb, size=None, cc=None
i32 candidate_010302(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1034f, offset=0x1034e, mode=Thumb, size=None, cc=None
i32 candidate_01034e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x103ff, offset=0x103fe, mode=Thumb, size=None, cc=None
i32 candidate_0103fe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x104af, offset=0x104ae, mode=Thumb, size=None, cc=None
i32 candidate_0104ae(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1053f, offset=0x1053e, mode=Thumb, size=None, cc=None
i32 candidate_01053e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10627, offset=0x10626, mode=Thumb, size=None, cc=None
i32 candidate_010626(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1079f, offset=0x1079e, mode=Thumb, size=None, cc=None
i32 candidate_01079e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10863, offset=0x10862, mode=Thumb, size=None, cc=None
i32 candidate_010862(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10bb7, offset=0x10bb6, mode=Thumb, size=None, cc=None
i32 candidate_010bb6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10cd7, offset=0x10cd6, mode=Thumb, size=None, cc=None
i32 candidate_010cd6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10d2f, offset=0x10d2e, mode=Thumb, size=None, cc=None
i32 candidate_010d2e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10e4f, offset=0x10e4e, mode=Thumb, size=None, cc=None
i32 candidate_010e4e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10ec3, offset=0x10ec2, mode=Thumb, size=None, cc=None
i32 candidate_010ec2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10f2b, offset=0x10f2a, mode=Thumb, size=None, cc=None
i32 candidate_010f2a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10fd3, offset=0x10fd2, mode=Thumb, size=None, cc=None
i32 candidate_010fd2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11137, offset=0x11136, mode=Thumb, size=None, cc=None
i32 candidate_011136(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x111d3, offset=0x111d2, mode=Thumb, size=None, cc=None
i32 candidate_0111d2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x112f7, offset=0x112f6, mode=Thumb, size=None, cc=None
i32 candidate_0112f6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11373, offset=0x11372, mode=Thumb, size=None, cc=None
i32 candidate_011372(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11403, offset=0x11402, mode=Thumb, size=None, cc=None
i32 candidate_011402(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11453, offset=0x11452, mode=Thumb, size=None, cc=None
i32 candidate_011452(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11477, offset=0x11476, mode=Thumb, size=None, cc=None
i32 candidate_011476(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11493, offset=0x11492, mode=Thumb, size=None, cc=None
i32 candidate_011492(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1159f, offset=0x1159e, mode=Thumb, size=None, cc=None
i32 candidate_01159e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1195f, offset=0x1195e, mode=Thumb, size=None, cc=None
i32 candidate_01195e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11aff, offset=0x11afe, mode=Thumb, size=None, cc=None
i32 candidate_011afe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11b9b, offset=0x11b9a, mode=Thumb, size=None, cc=None
i32 candidate_011b9a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11cd3, offset=0x11cd2, mode=Thumb, size=None, cc=None
i32 candidate_011cd2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11e03, offset=0x11e02, mode=Thumb, size=None, cc=None
i32 candidate_011e02(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11f6f, offset=0x11f6e, mode=Thumb, size=None, cc=None
i32 candidate_011f6e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x12027, offset=0x12026, mode=Thumb, size=None, cc=None
i32 candidate_012026(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x12083, offset=0x12082, mode=Thumb, size=None, cc=None
i32 candidate_012082(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x12167, offset=0x12166, mode=Thumb, size=None, cc=None
i32 candidate_012166(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x121f3, offset=0x121f2, mode=Thumb, size=None, cc=None
i32 candidate_0121f2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1226f, offset=0x1226e, mode=Thumb, size=None, cc=None
i32 candidate_01226e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1228b, offset=0x1228a, mode=Thumb, size=None, cc=None
i32 candidate_01228a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1275b, offset=0x1275a, mode=Thumb, size=None, cc=None
i32 candidate_01275a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x12787, offset=0x12786, mode=Thumb, size=None, cc=None
i32 candidate_012786(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x127ef, offset=0x127ee, mode=Thumb, size=None, cc=None
i32 candidate_0127ee(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x12b63, offset=0x12b62, mode=Thumb, size=None, cc=None
i32 candidate_012b62(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x12f5f, offset=0x12f5e, mode=Thumb, size=None, cc=None
i32 candidate_012f5e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1349b, offset=0x1349a, mode=Thumb, size=None, cc=None
i32 candidate_01349a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x134e7, offset=0x134e6, mode=Thumb, size=None, cc=None
i32 candidate_0134e6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1353b, offset=0x1353a, mode=Thumb, size=None, cc=None
i32 candidate_01353a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1359f, offset=0x1359e, mode=Thumb, size=None, cc=None
i32 candidate_01359e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x135cb, offset=0x135ca, mode=Thumb, size=None, cc=None
i32 candidate_0135ca(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1364f, offset=0x1364e, mode=Thumb, size=None, cc=None
i32 candidate_01364e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1367b, offset=0x1367a, mode=Thumb, size=None, cc=None
i32 candidate_01367a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x136a7, offset=0x136a6, mode=Thumb, size=None, cc=None
i32 candidate_0136a6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x136c7, offset=0x136c6, mode=Thumb, size=None, cc=None
i32 candidate_0136c6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x136fb, offset=0x136fa, mode=Thumb, size=None, cc=None
i32 candidate_0136fa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1378f, offset=0x1378e, mode=Thumb, size=None, cc=None
i32 candidate_01378e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x138af, offset=0x138ae, mode=Thumb, size=None, cc=None
i32 candidate_0138ae(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x138e3, offset=0x138e2, mode=Thumb, size=None, cc=None
i32 candidate_0138e2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1392f, offset=0x1392e, mode=Thumb, size=None, cc=None
i32 candidate_01392e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13963, offset=0x13962, mode=Thumb, size=None, cc=None
i32 candidate_013962(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13a13, offset=0x13a12, mode=Thumb, size=None, cc=None
i32 candidate_013a12(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13a77, offset=0x13a76, mode=Thumb, size=None, cc=None
i32 candidate_013a76(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13b53, offset=0x13b52, mode=Thumb, size=None, cc=None
i32 candidate_013b52(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13bf3, offset=0x13bf2, mode=Thumb, size=None, cc=None
i32 candidate_013bf2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13bf5, offset=0x13bf4, mode=Thumb, size=None, cc=None
i32 candidate_013bf4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x141d3, offset=0x141d2, mode=Thumb, size=None, cc=None
i32 candidate_0141d2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14287, offset=0x14286, mode=Thumb, size=None, cc=None
i32 candidate_014286(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14303, offset=0x14302, mode=Thumb, size=None, cc=None
i32 candidate_014302(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14cc1, offset=0x14cc0, mode=Thumb, size=None, cc=None
i32 candidate_014cc0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14e1f, offset=0x14e1e, mode=Thumb, size=None, cc=None
i32 candidate_014e1e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14e83, offset=0x14e82, mode=Thumb, size=None, cc=None
i32 candidate_014e82(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14ebb, offset=0x14eba, mode=Thumb, size=None, cc=None
i32 candidate_014eba(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14f83, offset=0x14f82, mode=Thumb, size=None, cc=None
i32 candidate_014f82(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14fd7, offset=0x14fd6, mode=Thumb, size=None, cc=None
i32 candidate_014fd6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14ffb, offset=0x14ffa, mode=Thumb, size=None, cc=None
i32 candidate_014ffa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1505b, offset=0x1505a, mode=Thumb, size=None, cc=None
i32 candidate_01505a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1513f, offset=0x1513e, mode=Thumb, size=None, cc=None
i32 candidate_01513e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1523f, offset=0x1523e, mode=Thumb, size=None, cc=None
i32 candidate_01523e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15297, offset=0x15296, mode=Thumb, size=None, cc=None
i32 candidate_015296(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x152a7, offset=0x152a6, mode=Thumb, size=None, cc=None
i32 candidate_0152a6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1537f, offset=0x1537e, mode=Thumb, size=None, cc=None
i32 candidate_01537e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x153f7, offset=0x153f6, mode=Thumb, size=None, cc=None
i32 candidate_0153f6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15407, offset=0x15406, mode=Thumb, size=None, cc=None
i32 candidate_015406(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x155df, offset=0x155de, mode=Thumb, size=None, cc=None
i32 candidate_0155de(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15627, offset=0x15626, mode=Thumb, size=None, cc=None
i32 candidate_015626(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15697, offset=0x15696, mode=Thumb, size=None, cc=None
i32 candidate_015696(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1570b, offset=0x1570a, mode=Thumb, size=None, cc=None
i32 candidate_01570a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15733, offset=0x15732, mode=Thumb, size=None, cc=None
i32 candidate_015732(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x157cb, offset=0x157ca, mode=Thumb, size=None, cc=None
i32 candidate_0157ca(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1588b, offset=0x1588a, mode=Thumb, size=None, cc=None
i32 candidate_01588a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15917, offset=0x15916, mode=Thumb, size=None, cc=None
i32 candidate_015916(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15977, offset=0x15976, mode=Thumb, size=None, cc=None
i32 candidate_015976(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x159f3, offset=0x159f2, mode=Thumb, size=None, cc=None
i32 candidate_0159f2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15a8f, offset=0x15a8e, mode=Thumb, size=None, cc=None
i32 candidate_015a8e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15b3f, offset=0x15b3e, mode=Thumb, size=None, cc=None
i32 candidate_015b3e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15b9f, offset=0x15b9e, mode=Thumb, size=None, cc=None
i32 candidate_015b9e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15bf3, offset=0x15bf2, mode=Thumb, size=None, cc=None
i32 candidate_015bf2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15c27, offset=0x15c26, mode=Thumb, size=None, cc=None
i32 candidate_015c26(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15ce7, offset=0x15ce6, mode=Thumb, size=None, cc=None
i32 candidate_015ce6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15d53, offset=0x15d52, mode=Thumb, size=None, cc=None
i32 candidate_015d52(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15d9f, offset=0x15d9e, mode=Thumb, size=None, cc=None
i32 candidate_015d9e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15e07, offset=0x15e06, mode=Thumb, size=None, cc=None
i32 candidate_015e06(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15e8b, offset=0x15e8a, mode=Thumb, size=None, cc=None
i32 candidate_015e8a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15ed3, offset=0x15ed2, mode=Thumb, size=None, cc=None
i32 candidate_015ed2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15f2b, offset=0x15f2a, mode=Thumb, size=None, cc=None
i32 candidate_015f2a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15f7f, offset=0x15f7e, mode=Thumb, size=None, cc=None
i32 candidate_015f7e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16073, offset=0x16072, mode=Thumb, size=None, cc=None
i32 candidate_016072(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x160b3, offset=0x160b2, mode=Thumb, size=None, cc=None
i32 candidate_0160b2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x160e7, offset=0x160e6, mode=Thumb, size=None, cc=None
i32 candidate_0160e6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16127, offset=0x16126, mode=Thumb, size=None, cc=None
i32 candidate_016126(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x161b7, offset=0x161b6, mode=Thumb, size=None, cc=None
i32 candidate_0161b6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x162af, offset=0x162ae, mode=Thumb, size=None, cc=None
i32 candidate_0162ae(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16347, offset=0x16346, mode=Thumb, size=None, cc=None
i32 candidate_016346(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1637f, offset=0x1637e, mode=Thumb, size=None, cc=None
i32 candidate_01637e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x163bb, offset=0x163ba, mode=Thumb, size=None, cc=None
i32 candidate_0163ba(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1672f, offset=0x1672e, mode=Thumb, size=None, cc=None
i32 candidate_01672e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x167f3, offset=0x167f2, mode=Thumb, size=None, cc=None
i32 candidate_0167f2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1691b, offset=0x1691a, mode=Thumb, size=None, cc=None
i32 candidate_01691a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16ae3, offset=0x16ae2, mode=Thumb, size=None, cc=None
i32 candidate_016ae2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16b9f, offset=0x16b9e, mode=Thumb, size=None, cc=None
i32 candidate_016b9e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16bdb, offset=0x16bda, mode=Thumb, size=None, cc=None
i32 candidate_016bda(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16c47, offset=0x16c46, mode=Thumb, size=None, cc=None
i32 candidate_016c46(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16cab, offset=0x16caa, mode=Thumb, size=None, cc=None
i32 candidate_016caa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16cc7, offset=0x16cc6, mode=Thumb, size=None, cc=None
i32 candidate_016cc6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16dc3, offset=0x16dc2, mode=Thumb, size=None, cc=None
i32 candidate_016dc2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16fb3, offset=0x16fb2, mode=Thumb, size=None, cc=None
i32 candidate_016fb2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1708f, offset=0x1708e, mode=Thumb, size=None, cc=None
i32 candidate_01708e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1711b, offset=0x1711a, mode=Thumb, size=None, cc=None
i32 candidate_01711a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x171f3, offset=0x171f2, mode=Thumb, size=None, cc=None
i32 candidate_0171f2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x172eb, offset=0x172ea, mode=Thumb, size=None, cc=None
i32 candidate_0172ea(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x173bf, offset=0x173be, mode=Thumb, size=None, cc=None
i32 candidate_0173be(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x174b3, offset=0x174b2, mode=Thumb, size=None, cc=None
i32 candidate_0174b2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17883, offset=0x17882, mode=Thumb, size=None, cc=None
i32 candidate_017882(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1790b, offset=0x1790a, mode=Thumb, size=None, cc=None
i32 candidate_01790a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1795f, offset=0x1795e, mode=Thumb, size=None, cc=None
i32 candidate_01795e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x179d7, offset=0x179d6, mode=Thumb, size=None, cc=None
i32 candidate_0179d6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17adb, offset=0x17ada, mode=Thumb, size=None, cc=None
i32 candidate_017ada(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17b43, offset=0x17b42, mode=Thumb, size=None, cc=None
i32 candidate_017b42(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17beb, offset=0x17bea, mode=Thumb, size=None, cc=None
i32 candidate_017bea(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17c43, offset=0x17c42, mode=Thumb, size=None, cc=None
i32 candidate_017c42(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17cd3, offset=0x17cd2, mode=Thumb, size=None, cc=None
i32 candidate_017cd2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17d8f, offset=0x17d8e, mode=Thumb, size=None, cc=None
i32 candidate_017d8e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17df3, offset=0x17df2, mode=Thumb, size=None, cc=None
i32 candidate_017df2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17e3f, offset=0x17e3e, mode=Thumb, size=None, cc=None
i32 candidate_017e3e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17e9b, offset=0x17e9a, mode=Thumb, size=None, cc=None
i32 candidate_017e9a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17f1b, offset=0x17f1a, mode=Thumb, size=None, cc=None
i32 candidate_017f1a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17f8b, offset=0x17f8a, mode=Thumb, size=None, cc=None
i32 candidate_017f8a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1802b, offset=0x1802a, mode=Thumb, size=None, cc=None
i32 candidate_01802a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18067, offset=0x18066, mode=Thumb, size=None, cc=None
i32 candidate_018066(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x180a3, offset=0x180a2, mode=Thumb, size=None, cc=None
i32 candidate_0180a2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x180a7, offset=0x180a6, mode=Thumb, size=None, cc=None
i32 candidate_0180a6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18177, offset=0x18176, mode=Thumb, size=None, cc=None
i32 candidate_018176(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18623, offset=0x18622, mode=Thumb, size=None, cc=None
i32 candidate_018622(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x186e7, offset=0x186e6, mode=Thumb, size=None, cc=None
i32 candidate_0186e6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1876b, offset=0x1876a, mode=Thumb, size=None, cc=None
i32 candidate_01876a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x187d7, offset=0x187d6, mode=Thumb, size=None, cc=None
i32 candidate_0187d6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x188ab, offset=0x188aa, mode=Thumb, size=None, cc=None
i32 candidate_0188aa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x189b7, offset=0x189b6, mode=Thumb, size=None, cc=None
i32 candidate_0189b6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18acb, offset=0x18aca, mode=Thumb, size=None, cc=None
i32 candidate_018aca(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18b7b, offset=0x18b7a, mode=Thumb, size=None, cc=None
i32 candidate_018b7a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18d03, offset=0x18d02, mode=Thumb, size=None, cc=None
i32 candidate_018d02(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18d6b, offset=0x18d6a, mode=Thumb, size=None, cc=None
i32 candidate_018d6a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18dc3, offset=0x18dc2, mode=Thumb, size=None, cc=None
i32 candidate_018dc2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18ea3, offset=0x18ea2, mode=Thumb, size=None, cc=None
i32 candidate_018ea2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18ee7, offset=0x18ee6, mode=Thumb, size=None, cc=None
i32 candidate_018ee6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19013, offset=0x19012, mode=Thumb, size=None, cc=None
i32 candidate_019012(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19083, offset=0x19082, mode=Thumb, size=None, cc=None
i32 candidate_019082(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x191c7, offset=0x191c6, mode=Thumb, size=None, cc=None
i32 candidate_0191c6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19293, offset=0x19292, mode=Thumb, size=None, cc=None
i32 candidate_019292(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19327, offset=0x19326, mode=Thumb, size=None, cc=None
i32 candidate_019326(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19367, offset=0x19366, mode=Thumb, size=None, cc=None
i32 candidate_019366(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x194d7, offset=0x194d6, mode=Thumb, size=None, cc=None
i32 candidate_0194d6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19567, offset=0x19566, mode=Thumb, size=None, cc=None
i32 candidate_019566(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x195d7, offset=0x195d6, mode=Thumb, size=None, cc=None
i32 candidate_0195d6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x196a7, offset=0x196a6, mode=Thumb, size=None, cc=None
i32 candidate_0196a6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x196c7, offset=0x196c6, mode=Thumb, size=None, cc=None
i32 candidate_0196c6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x197ef, offset=0x197ee, mode=Thumb, size=None, cc=None
i32 candidate_0197ee(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19837, offset=0x19836, mode=Thumb, size=None, cc=None
i32 candidate_019836(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19957, offset=0x19956, mode=Thumb, size=None, cc=None
i32 candidate_019956(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19a87, offset=0x19a86, mode=Thumb, size=None, cc=None
i32 candidate_019a86(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19d5f, offset=0x19d5e, mode=Thumb, size=None, cc=None
i32 candidate_019d5e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a03b, offset=0x1a03a, mode=Thumb, size=None, cc=None
i32 candidate_01a03a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a08f, offset=0x1a08e, mode=Thumb, size=None, cc=None
i32 candidate_01a08e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a113, offset=0x1a112, mode=Thumb, size=None, cc=None
i32 candidate_01a112(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a173, offset=0x1a172, mode=Thumb, size=None, cc=None
i32 candidate_01a172(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a293, offset=0x1a292, mode=Thumb, size=None, cc=None
i32 candidate_01a292(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a2db, offset=0x1a2da, mode=Thumb, size=None, cc=None
i32 candidate_01a2da(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a407, offset=0x1a406, mode=Thumb, size=None, cc=None
i32 candidate_01a406(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a4df, offset=0x1a4de, mode=Thumb, size=None, cc=None
i32 candidate_01a4de(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a597, offset=0x1a596, mode=Thumb, size=None, cc=None
i32 candidate_01a596(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a5cb, offset=0x1a5ca, mode=Thumb, size=None, cc=None
i32 candidate_01a5ca(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a65b, offset=0x1a65a, mode=Thumb, size=None, cc=None
i32 candidate_01a65a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a6e3, offset=0x1a6e2, mode=Thumb, size=None, cc=None
i32 candidate_01a6e2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a717, offset=0x1a716, mode=Thumb, size=None, cc=None
i32 candidate_01a716(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a78b, offset=0x1a78a, mode=Thumb, size=None, cc=None
i32 candidate_01a78a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a80b, offset=0x1a80a, mode=Thumb, size=None, cc=None
i32 candidate_01a80a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a80f, offset=0x1a80e, mode=Thumb, size=None, cc=None
i32 candidate_01a80e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a8d3, offset=0x1a8d2, mode=Thumb, size=None, cc=None
i32 candidate_01a8d2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a93f, offset=0x1a93e, mode=Thumb, size=None, cc=None
i32 candidate_01a93e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a95f, offset=0x1a95e, mode=Thumb, size=None, cc=None
i32 candidate_01a95e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1aac7, offset=0x1aac6, mode=Thumb, size=None, cc=None
i32 candidate_01aac6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1abb3, offset=0x1abb2, mode=Thumb, size=None, cc=None
i32 candidate_01abb2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ac53, offset=0x1ac52, mode=Thumb, size=None, cc=None
i32 candidate_01ac52(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ad67, offset=0x1ad66, mode=Thumb, size=None, cc=None
i32 candidate_01ad66(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ae33, offset=0x1ae32, mode=Thumb, size=None, cc=None
i32 candidate_01ae32(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1aed7, offset=0x1aed6, mode=Thumb, size=None, cc=None
i32 candidate_01aed6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1af9b, offset=0x1af9a, mode=Thumb, size=None, cc=None
i32 candidate_01af9a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1afe7, offset=0x1afe6, mode=Thumb, size=None, cc=None
i32 candidate_01afe6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b0e7, offset=0x1b0e6, mode=Thumb, size=None, cc=None
i32 candidate_01b0e6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b16f, offset=0x1b16e, mode=Thumb, size=None, cc=None
i32 candidate_01b16e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b1e7, offset=0x1b1e6, mode=Thumb, size=None, cc=None
i32 candidate_01b1e6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b29f, offset=0x1b29e, mode=Thumb, size=None, cc=None
i32 candidate_01b29e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b45f, offset=0x1b45e, mode=Thumb, size=None, cc=None
i32 candidate_01b45e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b463, offset=0x1b462, mode=Thumb, size=None, cc=None
i32 candidate_01b462(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b483, offset=0x1b482, mode=Thumb, size=None, cc=None
i32 candidate_01b482(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b6fb, offset=0x1b6fa, mode=Thumb, size=None, cc=None
i32 candidate_01b6fa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b793, offset=0x1b792, mode=Thumb, size=None, cc=None
i32 candidate_01b792(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b8d3, offset=0x1b8d2, mode=Thumb, size=None, cc=None
i32 candidate_01b8d2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b927, offset=0x1b926, mode=Thumb, size=None, cc=None
i32 candidate_01b926(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b9e3, offset=0x1b9e2, mode=Thumb, size=None, cc=None
i32 candidate_01b9e2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ba67, offset=0x1ba66, mode=Thumb, size=None, cc=None
i32 candidate_01ba66(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1bbaf, offset=0x1bbae, mode=Thumb, size=None, cc=None
i32 candidate_01bbae(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1bd2f, offset=0x1bd2e, mode=Thumb, size=None, cc=None
i32 candidate_01bd2e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1bf9b, offset=0x1bf9a, mode=Thumb, size=None, cc=None
i32 candidate_01bf9a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c153, offset=0x1c152, mode=Thumb, size=None, cc=None
i32 candidate_01c152(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c297, offset=0x1c296, mode=Thumb, size=None, cc=None
i32 candidate_01c296(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d673, offset=0x1d672, mode=Thumb, size=None, cc=None
i32 candidate_01d672(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d6f7, offset=0x1d6f6, mode=Thumb, size=None, cc=None
i32 candidate_01d6f6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d783, offset=0x1d782, mode=Thumb, size=None, cc=None
i32 candidate_01d782(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d86b, offset=0x1d86a, mode=Thumb, size=None, cc=None
i32 candidate_01d86a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d967, offset=0x1d966, mode=Thumb, size=None, cc=None
i32 candidate_01d966(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1dae7, offset=0x1dae6, mode=Thumb, size=None, cc=None
i32 candidate_01dae6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1db4b, offset=0x1db4a, mode=Thumb, size=None, cc=None
i32 candidate_01db4a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1dbbb, offset=0x1dbba, mode=Thumb, size=None, cc=None
i32 candidate_01dbba(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1dc6b, offset=0x1dc6a, mode=Thumb, size=None, cc=None
i32 candidate_01dc6a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1dcd3, offset=0x1dcd2, mode=Thumb, size=None, cc=None
i32 candidate_01dcd2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1df13, offset=0x1df12, mode=Thumb, size=None, cc=None
i32 candidate_01df12(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e6fb, offset=0x1e6fa, mode=Thumb, size=None, cc=None
i32 candidate_01e6fa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e7b3, offset=0x1e7b2, mode=Thumb, size=None, cc=None
i32 candidate_01e7b2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e873, offset=0x1e872, mode=Thumb, size=None, cc=None
i32 candidate_01e872(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ea1b, offset=0x1ea1a, mode=Thumb, size=None, cc=None
i32 candidate_01ea1a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ea8b, offset=0x1ea8a, mode=Thumb, size=None, cc=None
i32 candidate_01ea8a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eb13, offset=0x1eb12, mode=Thumb, size=None, cc=None
i32 candidate_01eb12(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eb4b, offset=0x1eb4a, mode=Thumb, size=None, cc=None
i32 candidate_01eb4a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ec1f, offset=0x1ec1e, mode=Thumb, size=None, cc=None
i32 candidate_01ec1e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ed27, offset=0x1ed26, mode=Thumb, size=None, cc=None
i32 candidate_01ed26(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1efbf, offset=0x1efbe, mode=Thumb, size=None, cc=None
i32 candidate_01efbe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f077, offset=0x1f076, mode=Thumb, size=None, cc=None
i32 candidate_01f076(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f7f7, offset=0x1f7f6, mode=Thumb, size=None, cc=None
i32 candidate_01f7f6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f823, offset=0x1f822, mode=Thumb, size=None, cc=None
i32 candidate_01f822(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f86b, offset=0x1f86a, mode=Thumb, size=None, cc=None
i32 candidate_01f86a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f8ab, offset=0x1f8aa, mode=Thumb, size=None, cc=None
i32 candidate_01f8aa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f8e7, offset=0x1f8e6, mode=Thumb, size=None, cc=None
i32 candidate_01f8e6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f9a7, offset=0x1f9a6, mode=Thumb, size=None, cc=None
i32 candidate_01f9a6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f9d7, offset=0x1f9d6, mode=Thumb, size=None, cc=None
i32 candidate_01f9d6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ff5f, offset=0x1ff5e, mode=Thumb, size=None, cc=None
i32 candidate_01ff5e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1fff7, offset=0x1fff6, mode=Thumb, size=None, cc=None
i32 candidate_01fff6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20077, offset=0x20076, mode=Thumb, size=None, cc=None
i32 candidate_020076(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x200c7, offset=0x200c6, mode=Thumb, size=None, cc=None
i32 candidate_0200c6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x201bf, offset=0x201be, mode=Thumb, size=None, cc=None
i32 candidate_0201be(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20233, offset=0x20232, mode=Thumb, size=None, cc=None
i32 candidate_020232(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x202ef, offset=0x202ee, mode=Thumb, size=None, cc=None
i32 candidate_0202ee(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2039f, offset=0x2039e, mode=Thumb, size=None, cc=None
i32 candidate_02039e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2051b, offset=0x2051a, mode=Thumb, size=None, cc=None
i32 candidate_02051a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x205b3, offset=0x205b2, mode=Thumb, size=None, cc=None
i32 candidate_0205b2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2067f, offset=0x2067e, mode=Thumb, size=None, cc=None
i32 candidate_02067e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x206a7, offset=0x206a6, mode=Thumb, size=None, cc=None
i32 candidate_0206a6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20743, offset=0x20742, mode=Thumb, size=None, cc=None
i32 candidate_020742(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x207e3, offset=0x207e2, mode=Thumb, size=None, cc=None
i32 candidate_0207e2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20acf, offset=0x20ace, mode=Thumb, size=None, cc=None
i32 candidate_020ace(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20bf7, offset=0x20bf6, mode=Thumb, size=None, cc=None
i32 candidate_020bf6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20cef, offset=0x20cee, mode=Thumb, size=None, cc=None
i32 candidate_020cee(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20d6b, offset=0x20d6a, mode=Thumb, size=None, cc=None
i32 candidate_020d6a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x216cf, offset=0x216ce, mode=Thumb, size=None, cc=None
i32 candidate_0216ce(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2181b, offset=0x2181a, mode=Thumb, size=None, cc=None
i32 candidate_02181a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2183b, offset=0x2183a, mode=Thumb, size=None, cc=None
i32 candidate_02183a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2190b, offset=0x2190a, mode=Thumb, size=None, cc=None
i32 candidate_02190a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21a63, offset=0x21a62, mode=Thumb, size=None, cc=None
i32 candidate_021a62(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21ab3, offset=0x21ab2, mode=Thumb, size=None, cc=None
i32 candidate_021ab2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21b17, offset=0x21b16, mode=Thumb, size=None, cc=None
i32 candidate_021b16(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21beb, offset=0x21bea, mode=Thumb, size=None, cc=None
i32 candidate_021bea(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21ce3, offset=0x21ce2, mode=Thumb, size=None, cc=None
i32 candidate_021ce2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21db3, offset=0x21db2, mode=Thumb, size=None, cc=None
i32 candidate_021db2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2240f, offset=0x2240e, mode=Thumb, size=None, cc=None
i32 candidate_02240e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22413, offset=0x22412, mode=Thumb, size=None, cc=None
i32 candidate_022412(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2249b, offset=0x2249a, mode=Thumb, size=None, cc=None
i32 candidate_02249a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22513, offset=0x22512, mode=Thumb, size=None, cc=None
i32 candidate_022512(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2255f, offset=0x2255e, mode=Thumb, size=None, cc=None
i32 candidate_02255e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x225d7, offset=0x225d6, mode=Thumb, size=None, cc=None
i32 candidate_0225d6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22613, offset=0x22612, mode=Thumb, size=None, cc=None
i32 candidate_022612(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2266b, offset=0x2266a, mode=Thumb, size=None, cc=None
i32 candidate_02266a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x226d7, offset=0x226d6, mode=Thumb, size=None, cc=None
i32 candidate_0226d6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x227b1, offset=0x227b0, mode=Thumb, size=None, cc=None
i32 candidate_0227b0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x227b7, offset=0x227b6, mode=Thumb, size=None, cc=None
i32 candidate_0227b6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2281f, offset=0x2281e, mode=Thumb, size=None, cc=None
i32 candidate_02281e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22877, offset=0x22876, mode=Thumb, size=None, cc=None
i32 candidate_022876(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2288f, offset=0x2288e, mode=Thumb, size=None, cc=None
i32 candidate_02288e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2291b, offset=0x2291a, mode=Thumb, size=None, cc=None
i32 candidate_02291a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x229db, offset=0x229da, mode=Thumb, size=None, cc=None
i32 candidate_0229da(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22b53, offset=0x22b52, mode=Thumb, size=None, cc=None
i32 candidate_022b52(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22bbf, offset=0x22bbe, mode=Thumb, size=None, cc=None
i32 candidate_022bbe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22d5f, offset=0x22d5e, mode=Thumb, size=None, cc=None
i32 candidate_022d5e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22d83, offset=0x22d82, mode=Thumb, size=None, cc=None
i32 candidate_022d82(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22e13, offset=0x22e12, mode=Thumb, size=None, cc=None
i32 candidate_022e12(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22e7f, offset=0x22e7e, mode=Thumb, size=None, cc=None
i32 candidate_022e7e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x234d3, offset=0x234d2, mode=Thumb, size=None, cc=None
i32 candidate_0234d2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23849, offset=0x23848, mode=Thumb, size=None, cc=None
i32 candidate_023848(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x238eb, offset=0x238ea, mode=Thumb, size=None, cc=None
i32 candidate_0238ea(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23b47, offset=0x23b46, mode=Thumb, size=None, cc=None
i32 candidate_023b46(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23d63, offset=0x23d62, mode=Thumb, size=None, cc=None
i32 candidate_023d62(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23df3, offset=0x23df2, mode=Thumb, size=None, cc=None
i32 candidate_023df2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2408b, offset=0x2408a, mode=Thumb, size=None, cc=None
i32 candidate_02408a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2418b, offset=0x2418a, mode=Thumb, size=None, cc=None
i32 candidate_02418a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x241bf, offset=0x241be, mode=Thumb, size=None, cc=None
i32 candidate_0241be(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24217, offset=0x24216, mode=Thumb, size=None, cc=None
i32 candidate_024216(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2424f, offset=0x2424e, mode=Thumb, size=None, cc=None
i32 candidate_02424e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2430f, offset=0x2430e, mode=Thumb, size=None, cc=None
i32 candidate_02430e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x243f7, offset=0x243f6, mode=Thumb, size=None, cc=None
i32 candidate_0243f6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x244a3, offset=0x244a2, mode=Thumb, size=None, cc=None
i32 candidate_0244a2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24553, offset=0x24552, mode=Thumb, size=None, cc=None
i32 candidate_024552(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24557, offset=0x24556, mode=Thumb, size=None, cc=None
i32 candidate_024556(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x245a7, offset=0x245a6, mode=Thumb, size=None, cc=None
i32 candidate_0245a6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x245ef, offset=0x245ee, mode=Thumb, size=None, cc=None
i32 candidate_0245ee(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x246bb, offset=0x246ba, mode=Thumb, size=None, cc=None
i32 candidate_0246ba(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24763, offset=0x24762, mode=Thumb, size=None, cc=None
i32 candidate_024762(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x247d3, offset=0x247d2, mode=Thumb, size=None, cc=None
i32 candidate_0247d2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x248eb, offset=0x248ea, mode=Thumb, size=None, cc=None
i32 candidate_0248ea(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2494b, offset=0x2494a, mode=Thumb, size=None, cc=None
i32 candidate_02494a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x249bb, offset=0x249ba, mode=Thumb, size=None, cc=None
i32 candidate_0249ba(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24a93, offset=0x24a92, mode=Thumb, size=None, cc=None
i32 candidate_024a92(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24aaf, offset=0x24aae, mode=Thumb, size=None, cc=None
i32 candidate_024aae(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24af7, offset=0x24af6, mode=Thumb, size=None, cc=None
i32 candidate_024af6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24b5b, offset=0x24b5a, mode=Thumb, size=None, cc=None
i32 candidate_024b5a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24b6b, offset=0x24b6a, mode=Thumb, size=None, cc=None
i32 candidate_024b6a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24bdb, offset=0x24bda, mode=Thumb, size=None, cc=None
i32 candidate_024bda(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24d2b, offset=0x24d2a, mode=Thumb, size=None, cc=None
i32 candidate_024d2a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24df3, offset=0x24df2, mode=Thumb, size=None, cc=None
i32 candidate_024df2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24e1f, offset=0x24e1e, mode=Thumb, size=None, cc=None
i32 candidate_024e1e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24e6f, offset=0x24e6e, mode=Thumb, size=None, cc=None
i32 candidate_024e6e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24ebf, offset=0x24ebe, mode=Thumb, size=None, cc=None
i32 candidate_024ebe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24f3f, offset=0x24f3e, mode=Thumb, size=None, cc=None
i32 candidate_024f3e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24f67, offset=0x24f66, mode=Thumb, size=None, cc=None
i32 candidate_024f66(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24f93, offset=0x24f92, mode=Thumb, size=None, cc=None
i32 candidate_024f92(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24fd7, offset=0x24fd6, mode=Thumb, size=None, cc=None
i32 candidate_024fd6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25037, offset=0x25036, mode=Thumb, size=None, cc=None
i32 candidate_025036(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25087, offset=0x25086, mode=Thumb, size=None, cc=None
i32 candidate_025086(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x250cf, offset=0x250ce, mode=Thumb, size=None, cc=None
i32 candidate_0250ce(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25123, offset=0x25122, mode=Thumb, size=None, cc=None
i32 candidate_025122(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2515b, offset=0x2515a, mode=Thumb, size=None, cc=None
i32 candidate_02515a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2521f, offset=0x2521e, mode=Thumb, size=None, cc=None
i32 candidate_02521e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x252d7, offset=0x252d6, mode=Thumb, size=None, cc=None
i32 candidate_0252d6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x253bb, offset=0x253ba, mode=Thumb, size=None, cc=None
i32 candidate_0253ba(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x253e7, offset=0x253e6, mode=Thumb, size=None, cc=None
i32 candidate_0253e6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2540b, offset=0x2540a, mode=Thumb, size=None, cc=None
i32 candidate_02540a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x254a7, offset=0x254a6, mode=Thumb, size=None, cc=None
i32 candidate_0254a6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25537, offset=0x25536, mode=Thumb, size=None, cc=None
i32 candidate_025536(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2553b, offset=0x2553a, mode=Thumb, size=None, cc=None
i32 candidate_02553a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x255a3, offset=0x255a2, mode=Thumb, size=None, cc=None
i32 candidate_0255a2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25637, offset=0x25636, mode=Thumb, size=None, cc=None
i32 candidate_025636(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x256b7, offset=0x256b6, mode=Thumb, size=None, cc=None
i32 candidate_0256b6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x256e7, offset=0x256e6, mode=Thumb, size=None, cc=None
i32 candidate_0256e6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25723, offset=0x25722, mode=Thumb, size=None, cc=None
i32 candidate_025722(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25763, offset=0x25762, mode=Thumb, size=None, cc=None
i32 candidate_025762(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25797, offset=0x25796, mode=Thumb, size=None, cc=None
i32 candidate_025796(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x257d7, offset=0x257d6, mode=Thumb, size=None, cc=None
i32 candidate_0257d6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2581b, offset=0x2581a, mode=Thumb, size=None, cc=None
i32 candidate_02581a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25863, offset=0x25862, mode=Thumb, size=None, cc=None
i32 candidate_025862(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x258af, offset=0x258ae, mode=Thumb, size=None, cc=None
i32 candidate_0258ae(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x258e7, offset=0x258e6, mode=Thumb, size=None, cc=None
i32 candidate_0258e6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25ab7, offset=0x25ab6, mode=Thumb, size=None, cc=None
i32 candidate_025ab6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25b3b, offset=0x25b3a, mode=Thumb, size=None, cc=None
i32 candidate_025b3a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25ba3, offset=0x25ba2, mode=Thumb, size=None, cc=None
i32 candidate_025ba2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25be7, offset=0x25be6, mode=Thumb, size=None, cc=None
i32 candidate_025be6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25c5b, offset=0x25c5a, mode=Thumb, size=None, cc=None
i32 candidate_025c5a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25c9f, offset=0x25c9e, mode=Thumb, size=None, cc=None
i32 candidate_025c9e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25da3, offset=0x25da2, mode=Thumb, size=None, cc=None
i32 candidate_025da2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25dd7, offset=0x25dd6, mode=Thumb, size=None, cc=None
i32 candidate_025dd6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25e57, offset=0x25e56, mode=Thumb, size=None, cc=None
i32 candidate_025e56(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25ef7, offset=0x25ef6, mode=Thumb, size=None, cc=None
i32 candidate_025ef6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25f5b, offset=0x25f5a, mode=Thumb, size=None, cc=None
i32 candidate_025f5a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2607f, offset=0x2607e, mode=Thumb, size=None, cc=None
i32 candidate_02607e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x260a7, offset=0x260a6, mode=Thumb, size=None, cc=None
i32 candidate_0260a6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x260db, offset=0x260da, mode=Thumb, size=None, cc=None
i32 candidate_0260da(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2612f, offset=0x2612e, mode=Thumb, size=None, cc=None
i32 candidate_02612e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2616b, offset=0x2616a, mode=Thumb, size=None, cc=None
i32 candidate_02616a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2622f, offset=0x2622e, mode=Thumb, size=None, cc=None
i32 candidate_02622e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2629b, offset=0x2629a, mode=Thumb, size=None, cc=None
i32 candidate_02629a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2636f, offset=0x2636e, mode=Thumb, size=None, cc=None
i32 candidate_02636e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x263eb, offset=0x263ea, mode=Thumb, size=None, cc=None
i32 candidate_0263ea(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2647f, offset=0x2647e, mode=Thumb, size=None, cc=None
i32 candidate_02647e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x264f3, offset=0x264f2, mode=Thumb, size=None, cc=None
i32 candidate_0264f2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x265ab, offset=0x265aa, mode=Thumb, size=None, cc=None
i32 candidate_0265aa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26827, offset=0x26826, mode=Thumb, size=None, cc=None
i32 candidate_026826(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2693f, offset=0x2693e, mode=Thumb, size=None, cc=None
i32 candidate_02693e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x273a7, offset=0x273a6, mode=Thumb, size=None, cc=None
i32 candidate_0273a6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x274af, offset=0x274ae, mode=Thumb, size=None, cc=None
i32 candidate_0274ae(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x276ef, offset=0x276ee, mode=Thumb, size=None, cc=None
i32 candidate_0276ee(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x278d7, offset=0x278d6, mode=Thumb, size=None, cc=None
i32 candidate_0278d6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27cd7, offset=0x27cd6, mode=Thumb, size=None, cc=None
i32 candidate_027cd6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27daf, offset=0x27dae, mode=Thumb, size=None, cc=None
i32 candidate_027dae(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27e3f, offset=0x27e3e, mode=Thumb, size=None, cc=None
i32 candidate_027e3e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27e9f, offset=0x27e9e, mode=Thumb, size=None, cc=None
i32 candidate_027e9e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x281c7, offset=0x281c6, mode=Thumb, size=None, cc=None
i32 candidate_0281c6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28523, offset=0x28522, mode=Thumb, size=None, cc=None
i32 candidate_028522(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28aaf, offset=0x28aae, mode=Thumb, size=None, cc=None
i32 candidate_028aae(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29593, offset=0x29592, mode=Thumb, size=None, cc=None
i32 candidate_029592(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x296af, offset=0x296ae, mode=Thumb, size=None, cc=None
i32 candidate_0296ae(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x298c3, offset=0x298c2, mode=Thumb, size=None, cc=None
i32 candidate_0298c2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2996b, offset=0x2996a, mode=Thumb, size=None, cc=None
i32 candidate_02996a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29a1f, offset=0x29a1e, mode=Thumb, size=None, cc=None
i32 candidate_029a1e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29adb, offset=0x29ada, mode=Thumb, size=None, cc=None
i32 candidate_029ada(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29cd7, offset=0x29cd6, mode=Thumb, size=None, cc=None
i32 candidate_029cd6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29edb, offset=0x29eda, mode=Thumb, size=None, cc=None
i32 candidate_029eda(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29f1b, offset=0x29f1a, mode=Thumb, size=None, cc=None
i32 candidate_029f1a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29f4f, offset=0x29f4e, mode=Thumb, size=None, cc=None
i32 candidate_029f4e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29fdb, offset=0x29fda, mode=Thumb, size=None, cc=None
i32 candidate_029fda(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2a01b, offset=0x2a01a, mode=Thumb, size=None, cc=None
i32 candidate_02a01a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2a0c3, offset=0x2a0c2, mode=Thumb, size=None, cc=None
i32 candidate_02a0c2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2aba3, offset=0x2aba2, mode=Thumb, size=None, cc=None
i32 candidate_02aba2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ac0b, offset=0x2ac0a, mode=Thumb, size=None, cc=None
i32 candidate_02ac0a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2acb3, offset=0x2acb2, mode=Thumb, size=None, cc=None
i32 candidate_02acb2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2acef, offset=0x2acee, mode=Thumb, size=None, cc=None
i32 candidate_02acee(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ad33, offset=0x2ad32, mode=Thumb, size=None, cc=None
i32 candidate_02ad32(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ae43, offset=0x2ae42, mode=Thumb, size=None, cc=None
i32 candidate_02ae42(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ae87, offset=0x2ae86, mode=Thumb, size=None, cc=None
i32 candidate_02ae86(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2aef3, offset=0x2aef2, mode=Thumb, size=None, cc=None
i32 candidate_02aef2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b103, offset=0x2b102, mode=Thumb, size=None, cc=None
i32 candidate_02b102(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b537, offset=0x2b536, mode=Thumb, size=None, cc=None
i32 candidate_02b536(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b8bb, offset=0x2b8ba, mode=Thumb, size=None, cc=None
i32 candidate_02b8ba(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b8eb, offset=0x2b8ea, mode=Thumb, size=None, cc=None
i32 candidate_02b8ea(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b97f, offset=0x2b97e, mode=Thumb, size=None, cc=None
i32 candidate_02b97e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ba57, offset=0x2ba56, mode=Thumb, size=None, cc=None
i32 candidate_02ba56(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bb4b, offset=0x2bb4a, mode=Thumb, size=None, cc=None
i32 candidate_02bb4a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bbc7, offset=0x2bbc6, mode=Thumb, size=None, cc=None
i32 candidate_02bbc6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bc03, offset=0x2bc02, mode=Thumb, size=None, cc=None
i32 candidate_02bc02(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bc53, offset=0x2bc52, mode=Thumb, size=None, cc=None
i32 candidate_02bc52(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bd07, offset=0x2bd06, mode=Thumb, size=None, cc=None
i32 candidate_02bd06(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bd43, offset=0x2bd42, mode=Thumb, size=None, cc=None
i32 candidate_02bd42(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2be57, offset=0x2be56, mode=Thumb, size=None, cc=None
i32 candidate_02be56(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bec3, offset=0x2bec2, mode=Thumb, size=None, cc=None
i32 candidate_02bec2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bed3, offset=0x2bed2, mode=Thumb, size=None, cc=None
i32 candidate_02bed2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bee3, offset=0x2bee2, mode=Thumb, size=None, cc=None
i32 candidate_02bee2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bf57, offset=0x2bf56, mode=Thumb, size=None, cc=None
i32 candidate_02bf56(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bfeb, offset=0x2bfea, mode=Thumb, size=None, cc=None
i32 candidate_02bfea(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c02f, offset=0x2c02e, mode=Thumb, size=None, cc=None
i32 candidate_02c02e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c123, offset=0x2c122, mode=Thumb, size=None, cc=None
i32 candidate_02c122(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c2ab, offset=0x2c2aa, mode=Thumb, size=None, cc=None
i32 candidate_02c2aa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c343, offset=0x2c342, mode=Thumb, size=None, cc=None
i32 candidate_02c342(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c497, offset=0x2c496, mode=Thumb, size=None, cc=None
i32 candidate_02c496(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c5df, offset=0x2c5de, mode=Thumb, size=None, cc=None
i32 candidate_02c5de(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c669, offset=0x2c668, mode=Thumb, size=None, cc=None
i32 candidate_02c668(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c721, offset=0x2c720, mode=Thumb, size=None, cc=None
i32 candidate_02c720(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c911, offset=0x2c910, mode=Thumb, size=None, cc=None
i32 candidate_02c910(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c94b, offset=0x2c94a, mode=Thumb, size=None, cc=None
i32 candidate_02c94a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ca47, offset=0x2ca46, mode=Thumb, size=None, cc=None
i32 candidate_02ca46(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ca83, offset=0x2ca82, mode=Thumb, size=None, cc=None
i32 candidate_02ca82(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cabf, offset=0x2cabe, mode=Thumb, size=None, cc=None
i32 candidate_02cabe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cafb, offset=0x2cafa, mode=Thumb, size=None, cc=None
i32 candidate_02cafa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cb5b, offset=0x2cb5a, mode=Thumb, size=None, cc=None
i32 candidate_02cb5a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cbbf, offset=0x2cbbe, mode=Thumb, size=None, cc=None
i32 candidate_02cbbe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ccdb, offset=0x2ccda, mode=Thumb, size=None, cc=None
i32 candidate_02ccda(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ccf7, offset=0x2ccf6, mode=Thumb, size=None, cc=None
i32 candidate_02ccf6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cd8f, offset=0x2cd8e, mode=Thumb, size=None, cc=None
i32 candidate_02cd8e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cdb7, offset=0x2cdb6, mode=Thumb, size=None, cc=None
i32 candidate_02cdb6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cdbd, offset=0x2cdbc, mode=Thumb, size=None, cc=None
i32 candidate_02cdbc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ce1b, offset=0x2ce1a, mode=Thumb, size=None, cc=None
i32 candidate_02ce1a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cecb, offset=0x2ceca, mode=Thumb, size=None, cc=None
i32 candidate_02ceca(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cecf, offset=0x2cece, mode=Thumb, size=None, cc=None
i32 candidate_02cece(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ced3, offset=0x2ced2, mode=Thumb, size=None, cc=None
i32 candidate_02ced2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d0c7, offset=0x2d0c6, mode=Thumb, size=None, cc=None
i32 candidate_02d0c6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d0cb, offset=0x2d0ca, mode=Thumb, size=None, cc=None
i32 candidate_02d0ca(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d127, offset=0x2d126, mode=Thumb, size=None, cc=None
i32 candidate_02d126(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d12b, offset=0x2d12a, mode=Thumb, size=None, cc=None
i32 candidate_02d12a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x365c9, offset=0x365c8, mode=Thumb, size=None, cc=None
i32 candidate_0365c8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x365cd, offset=0x365cc, mode=Thumb, size=None, cc=None
i32 candidate_0365cc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x365d1, offset=0x365d0, mode=Thumb, size=None, cc=None
i32 candidate_0365d0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x365d5, offset=0x365d4, mode=Thumb, size=None, cc=None
i32 candidate_0365d4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x365d9, offset=0x365d8, mode=Thumb, size=None, cc=None
i32 candidate_0365d8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x365dd, offset=0x365dc, mode=Thumb, size=None, cc=None
i32 candidate_0365dc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x365e1, offset=0x365e0, mode=Thumb, size=None, cc=None
i32 candidate_0365e0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x365e5, offset=0x365e4, mode=Thumb, size=None, cc=None
i32 candidate_0365e4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x365e9, offset=0x365e8, mode=Thumb, size=None, cc=None
i32 candidate_0365e8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x365ed, offset=0x365ec, mode=Thumb, size=None, cc=None
i32 candidate_0365ec(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x365f1, offset=0x365f0, mode=Thumb, size=None, cc=None
i32 candidate_0365f0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x365f5, offset=0x365f4, mode=Thumb, size=None, cc=None
i32 candidate_0365f4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x365f9, offset=0x365f8, mode=Thumb, size=None, cc=None
i32 candidate_0365f8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x365fd, offset=0x365fc, mode=Thumb, size=None, cc=None
i32 candidate_0365fc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36601, offset=0x36600, mode=Thumb, size=None, cc=None
i32 candidate_036600(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36605, offset=0x36604, mode=Thumb, size=None, cc=None
i32 candidate_036604(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36609, offset=0x36608, mode=Thumb, size=None, cc=None
i32 candidate_036608(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3660d, offset=0x3660c, mode=Thumb, size=None, cc=None
i32 candidate_03660c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36611, offset=0x36610, mode=Thumb, size=None, cc=None
i32 candidate_036610(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36615, offset=0x36614, mode=Thumb, size=None, cc=None
i32 candidate_036614(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36619, offset=0x36618, mode=Thumb, size=None, cc=None
i32 candidate_036618(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3661d, offset=0x3661c, mode=Thumb, size=None, cc=None
i32 candidate_03661c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36621, offset=0x36620, mode=Thumb, size=None, cc=None
i32 candidate_036620(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36625, offset=0x36624, mode=Thumb, size=None, cc=None
i32 candidate_036624(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36629, offset=0x36628, mode=Thumb, size=None, cc=None
i32 candidate_036628(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3662d, offset=0x3662c, mode=Thumb, size=None, cc=None
i32 candidate_03662c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36631, offset=0x36630, mode=Thumb, size=None, cc=None
i32 candidate_036630(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36635, offset=0x36634, mode=Thumb, size=None, cc=None
i32 candidate_036634(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36639, offset=0x36638, mode=Thumb, size=None, cc=None
i32 candidate_036638(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3663d, offset=0x3663c, mode=Thumb, size=None, cc=None
i32 candidate_03663c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36641, offset=0x36640, mode=Thumb, size=None, cc=None
i32 candidate_036640(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36645, offset=0x36644, mode=Thumb, size=None, cc=None
i32 candidate_036644(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36649, offset=0x36648, mode=Thumb, size=None, cc=None
i32 candidate_036648(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3664d, offset=0x3664c, mode=Thumb, size=None, cc=None
i32 candidate_03664c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36651, offset=0x36650, mode=Thumb, size=None, cc=None
i32 candidate_036650(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36655, offset=0x36654, mode=Thumb, size=None, cc=None
i32 candidate_036654(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36659, offset=0x36658, mode=Thumb, size=None, cc=None
i32 candidate_036658(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3665d, offset=0x3665c, mode=Thumb, size=None, cc=None
i32 candidate_03665c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36661, offset=0x36660, mode=Thumb, size=None, cc=None
i32 candidate_036660(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36665, offset=0x36664, mode=Thumb, size=None, cc=None
i32 candidate_036664(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36669, offset=0x36668, mode=Thumb, size=None, cc=None
i32 candidate_036668(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3666d, offset=0x3666c, mode=Thumb, size=None, cc=None
i32 candidate_03666c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36671, offset=0x36670, mode=Thumb, size=None, cc=None
i32 candidate_036670(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36675, offset=0x36674, mode=Thumb, size=None, cc=None
i32 candidate_036674(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36679, offset=0x36678, mode=Thumb, size=None, cc=None
i32 candidate_036678(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3667d, offset=0x3667c, mode=Thumb, size=None, cc=None
i32 candidate_03667c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36681, offset=0x36680, mode=Thumb, size=None, cc=None
i32 candidate_036680(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36685, offset=0x36684, mode=Thumb, size=None, cc=None
i32 candidate_036684(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36689, offset=0x36688, mode=Thumb, size=None, cc=None
i32 candidate_036688(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3668d, offset=0x3668c, mode=Thumb, size=None, cc=None
i32 candidate_03668c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36691, offset=0x36690, mode=Thumb, size=None, cc=None
i32 candidate_036690(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36695, offset=0x36694, mode=Thumb, size=None, cc=None
i32 candidate_036694(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36699, offset=0x36698, mode=Thumb, size=None, cc=None
i32 candidate_036698(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3669d, offset=0x3669c, mode=Thumb, size=None, cc=None
i32 candidate_03669c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366a1, offset=0x366a0, mode=Thumb, size=None, cc=None
i32 candidate_0366a0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366a5, offset=0x366a4, mode=Thumb, size=None, cc=None
i32 candidate_0366a4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366a9, offset=0x366a8, mode=Thumb, size=None, cc=None
i32 candidate_0366a8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366ad, offset=0x366ac, mode=Thumb, size=None, cc=None
i32 candidate_0366ac(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366b1, offset=0x366b0, mode=Thumb, size=None, cc=None
i32 candidate_0366b0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366b5, offset=0x366b4, mode=Thumb, size=None, cc=None
i32 candidate_0366b4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366b9, offset=0x366b8, mode=Thumb, size=None, cc=None
i32 candidate_0366b8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366bd, offset=0x366bc, mode=Thumb, size=None, cc=None
i32 candidate_0366bc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366c1, offset=0x366c0, mode=Thumb, size=None, cc=None
i32 candidate_0366c0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366c5, offset=0x366c4, mode=Thumb, size=None, cc=None
i32 candidate_0366c4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366c9, offset=0x366c8, mode=Thumb, size=None, cc=None
i32 candidate_0366c8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366cd, offset=0x366cc, mode=Thumb, size=None, cc=None
i32 candidate_0366cc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366d1, offset=0x366d0, mode=Thumb, size=None, cc=None
i32 candidate_0366d0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366d5, offset=0x366d4, mode=Thumb, size=None, cc=None
i32 candidate_0366d4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366d9, offset=0x366d8, mode=Thumb, size=None, cc=None
i32 candidate_0366d8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366dd, offset=0x366dc, mode=Thumb, size=None, cc=None
i32 candidate_0366dc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366e1, offset=0x366e0, mode=Thumb, size=None, cc=None
i32 candidate_0366e0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366e5, offset=0x366e4, mode=Thumb, size=None, cc=None
i32 candidate_0366e4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366e9, offset=0x366e8, mode=Thumb, size=None, cc=None
i32 candidate_0366e8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366ed, offset=0x366ec, mode=Thumb, size=None, cc=None
i32 candidate_0366ec(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366f1, offset=0x366f0, mode=Thumb, size=None, cc=None
i32 candidate_0366f0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366f5, offset=0x366f4, mode=Thumb, size=None, cc=None
i32 candidate_0366f4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366f9, offset=0x366f8, mode=Thumb, size=None, cc=None
i32 candidate_0366f8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x366fd, offset=0x366fc, mode=Thumb, size=None, cc=None
i32 candidate_0366fc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36701, offset=0x36700, mode=Thumb, size=None, cc=None
i32 candidate_036700(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36705, offset=0x36704, mode=Thumb, size=None, cc=None
i32 candidate_036704(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36709, offset=0x36708, mode=Thumb, size=None, cc=None
i32 candidate_036708(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3670d, offset=0x3670c, mode=Thumb, size=None, cc=None
i32 candidate_03670c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36711, offset=0x36710, mode=Thumb, size=None, cc=None
i32 candidate_036710(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36715, offset=0x36714, mode=Thumb, size=None, cc=None
i32 candidate_036714(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36719, offset=0x36718, mode=Thumb, size=None, cc=None
i32 candidate_036718(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3671d, offset=0x3671c, mode=Thumb, size=None, cc=None
i32 candidate_03671c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36721, offset=0x36720, mode=Thumb, size=None, cc=None
i32 candidate_036720(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36725, offset=0x36724, mode=Thumb, size=None, cc=None
i32 candidate_036724(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36729, offset=0x36728, mode=Thumb, size=None, cc=None
i32 candidate_036728(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3672d, offset=0x3672c, mode=Thumb, size=None, cc=None
i32 candidate_03672c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36731, offset=0x36730, mode=Thumb, size=None, cc=None
i32 candidate_036730(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36735, offset=0x36734, mode=Thumb, size=None, cc=None
i32 candidate_036734(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36739, offset=0x36738, mode=Thumb, size=None, cc=None
i32 candidate_036738(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3673d, offset=0x3673c, mode=Thumb, size=None, cc=None
i32 candidate_03673c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36741, offset=0x36740, mode=Thumb, size=None, cc=None
i32 candidate_036740(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36745, offset=0x36744, mode=Thumb, size=None, cc=None
i32 candidate_036744(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36749, offset=0x36748, mode=Thumb, size=None, cc=None
i32 candidate_036748(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3674d, offset=0x3674c, mode=Thumb, size=None, cc=None
i32 candidate_03674c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36751, offset=0x36750, mode=Thumb, size=None, cc=None
i32 candidate_036750(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36755, offset=0x36754, mode=Thumb, size=None, cc=None
i32 candidate_036754(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36759, offset=0x36758, mode=Thumb, size=None, cc=None
i32 candidate_036758(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3675d, offset=0x3675c, mode=Thumb, size=None, cc=None
i32 candidate_03675c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36761, offset=0x36760, mode=Thumb, size=None, cc=None
i32 candidate_036760(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36765, offset=0x36764, mode=Thumb, size=None, cc=None
i32 candidate_036764(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36769, offset=0x36768, mode=Thumb, size=None, cc=None
i32 candidate_036768(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3676d, offset=0x3676c, mode=Thumb, size=None, cc=None
i32 candidate_03676c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36771, offset=0x36770, mode=Thumb, size=None, cc=None
i32 candidate_036770(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36775, offset=0x36774, mode=Thumb, size=None, cc=None
i32 candidate_036774(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36779, offset=0x36778, mode=Thumb, size=None, cc=None
i32 candidate_036778(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3677d, offset=0x3677c, mode=Thumb, size=None, cc=None
i32 candidate_03677c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36781, offset=0x36780, mode=Thumb, size=None, cc=None
i32 candidate_036780(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36785, offset=0x36784, mode=Thumb, size=None, cc=None
i32 candidate_036784(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36789, offset=0x36788, mode=Thumb, size=None, cc=None
i32 candidate_036788(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3678d, offset=0x3678c, mode=Thumb, size=None, cc=None
i32 candidate_03678c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36791, offset=0x36790, mode=Thumb, size=None, cc=None
i32 candidate_036790(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36795, offset=0x36794, mode=Thumb, size=None, cc=None
i32 candidate_036794(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36799, offset=0x36798, mode=Thumb, size=None, cc=None
i32 candidate_036798(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3679d, offset=0x3679c, mode=Thumb, size=None, cc=None
i32 candidate_03679c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367a1, offset=0x367a0, mode=Thumb, size=None, cc=None
i32 candidate_0367a0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367a5, offset=0x367a4, mode=Thumb, size=None, cc=None
i32 candidate_0367a4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367a9, offset=0x367a8, mode=Thumb, size=None, cc=None
i32 candidate_0367a8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367ad, offset=0x367ac, mode=Thumb, size=None, cc=None
i32 candidate_0367ac(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367b1, offset=0x367b0, mode=Thumb, size=None, cc=None
i32 candidate_0367b0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367b5, offset=0x367b4, mode=Thumb, size=None, cc=None
i32 candidate_0367b4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367b9, offset=0x367b8, mode=Thumb, size=None, cc=None
i32 candidate_0367b8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367bd, offset=0x367bc, mode=Thumb, size=None, cc=None
i32 candidate_0367bc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367c1, offset=0x367c0, mode=Thumb, size=None, cc=None
i32 candidate_0367c0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367c5, offset=0x367c4, mode=Thumb, size=None, cc=None
i32 candidate_0367c4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367c9, offset=0x367c8, mode=Thumb, size=None, cc=None
i32 candidate_0367c8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367cd, offset=0x367cc, mode=Thumb, size=None, cc=None
i32 candidate_0367cc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367d1, offset=0x367d0, mode=Thumb, size=None, cc=None
i32 candidate_0367d0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367d5, offset=0x367d4, mode=Thumb, size=None, cc=None
i32 candidate_0367d4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367d9, offset=0x367d8, mode=Thumb, size=None, cc=None
i32 candidate_0367d8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367dd, offset=0x367dc, mode=Thumb, size=None, cc=None
i32 candidate_0367dc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367e1, offset=0x367e0, mode=Thumb, size=None, cc=None
i32 candidate_0367e0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367e5, offset=0x367e4, mode=Thumb, size=None, cc=None
i32 candidate_0367e4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367e9, offset=0x367e8, mode=Thumb, size=None, cc=None
i32 candidate_0367e8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367ed, offset=0x367ec, mode=Thumb, size=None, cc=None
i32 candidate_0367ec(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367f1, offset=0x367f0, mode=Thumb, size=None, cc=None
i32 candidate_0367f0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367f5, offset=0x367f4, mode=Thumb, size=None, cc=None
i32 candidate_0367f4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367f9, offset=0x367f8, mode=Thumb, size=None, cc=None
i32 candidate_0367f8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x367fd, offset=0x367fc, mode=Thumb, size=None, cc=None
i32 candidate_0367fc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36801, offset=0x36800, mode=Thumb, size=None, cc=None
i32 candidate_036800(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36805, offset=0x36804, mode=Thumb, size=None, cc=None
i32 candidate_036804(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36809, offset=0x36808, mode=Thumb, size=None, cc=None
i32 candidate_036808(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3680d, offset=0x3680c, mode=Thumb, size=None, cc=None
i32 candidate_03680c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36811, offset=0x36810, mode=Thumb, size=None, cc=None
i32 candidate_036810(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36815, offset=0x36814, mode=Thumb, size=None, cc=None
i32 candidate_036814(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36819, offset=0x36818, mode=Thumb, size=None, cc=None
i32 candidate_036818(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3681d, offset=0x3681c, mode=Thumb, size=None, cc=None
i32 candidate_03681c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36821, offset=0x36820, mode=Thumb, size=None, cc=None
i32 candidate_036820(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36825, offset=0x36824, mode=Thumb, size=None, cc=None
i32 candidate_036824(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36829, offset=0x36828, mode=Thumb, size=None, cc=None
i32 candidate_036828(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3682d, offset=0x3682c, mode=Thumb, size=None, cc=None
i32 candidate_03682c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36831, offset=0x36830, mode=Thumb, size=None, cc=None
i32 candidate_036830(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36835, offset=0x36834, mode=Thumb, size=None, cc=None
i32 candidate_036834(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36839, offset=0x36838, mode=Thumb, size=None, cc=None
i32 candidate_036838(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3683d, offset=0x3683c, mode=Thumb, size=None, cc=None
i32 candidate_03683c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36841, offset=0x36840, mode=Thumb, size=None, cc=None
i32 candidate_036840(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36845, offset=0x36844, mode=Thumb, size=None, cc=None
i32 candidate_036844(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36849, offset=0x36848, mode=Thumb, size=None, cc=None
i32 candidate_036848(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3684d, offset=0x3684c, mode=Thumb, size=None, cc=None
i32 candidate_03684c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36851, offset=0x36850, mode=Thumb, size=None, cc=None
i32 candidate_036850(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36855, offset=0x36854, mode=Thumb, size=None, cc=None
i32 candidate_036854(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36859, offset=0x36858, mode=Thumb, size=None, cc=None
i32 candidate_036858(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3685d, offset=0x3685c, mode=Thumb, size=None, cc=None
i32 candidate_03685c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36861, offset=0x36860, mode=Thumb, size=None, cc=None
i32 candidate_036860(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36865, offset=0x36864, mode=Thumb, size=None, cc=None
i32 candidate_036864(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36869, offset=0x36868, mode=Thumb, size=None, cc=None
i32 candidate_036868(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3686d, offset=0x3686c, mode=Thumb, size=None, cc=None
i32 candidate_03686c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36871, offset=0x36870, mode=Thumb, size=None, cc=None
i32 candidate_036870(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36875, offset=0x36874, mode=Thumb, size=None, cc=None
i32 candidate_036874(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36879, offset=0x36878, mode=Thumb, size=None, cc=None
i32 candidate_036878(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3687d, offset=0x3687c, mode=Thumb, size=None, cc=None
i32 candidate_03687c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36881, offset=0x36880, mode=Thumb, size=None, cc=None
i32 candidate_036880(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36885, offset=0x36884, mode=Thumb, size=None, cc=None
i32 candidate_036884(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36889, offset=0x36888, mode=Thumb, size=None, cc=None
i32 candidate_036888(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3688d, offset=0x3688c, mode=Thumb, size=None, cc=None
i32 candidate_03688c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36891, offset=0x36890, mode=Thumb, size=None, cc=None
i32 candidate_036890(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36895, offset=0x36894, mode=Thumb, size=None, cc=None
i32 candidate_036894(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36899, offset=0x36898, mode=Thumb, size=None, cc=None
i32 candidate_036898(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3689d, offset=0x3689c, mode=Thumb, size=None, cc=None
i32 candidate_03689c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368a1, offset=0x368a0, mode=Thumb, size=None, cc=None
i32 candidate_0368a0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368a5, offset=0x368a4, mode=Thumb, size=None, cc=None
i32 candidate_0368a4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368a9, offset=0x368a8, mode=Thumb, size=None, cc=None
i32 candidate_0368a8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368ad, offset=0x368ac, mode=Thumb, size=None, cc=None
i32 candidate_0368ac(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368b1, offset=0x368b0, mode=Thumb, size=None, cc=None
i32 candidate_0368b0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368b5, offset=0x368b4, mode=Thumb, size=None, cc=None
i32 candidate_0368b4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368b9, offset=0x368b8, mode=Thumb, size=None, cc=None
i32 candidate_0368b8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368bd, offset=0x368bc, mode=Thumb, size=None, cc=None
i32 candidate_0368bc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368c1, offset=0x368c0, mode=Thumb, size=None, cc=None
i32 candidate_0368c0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368c5, offset=0x368c4, mode=Thumb, size=None, cc=None
i32 candidate_0368c4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368c9, offset=0x368c8, mode=Thumb, size=None, cc=None
i32 candidate_0368c8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368cd, offset=0x368cc, mode=Thumb, size=None, cc=None
i32 candidate_0368cc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368d1, offset=0x368d0, mode=Thumb, size=None, cc=None
i32 candidate_0368d0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368d5, offset=0x368d4, mode=Thumb, size=None, cc=None
i32 candidate_0368d4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368d9, offset=0x368d8, mode=Thumb, size=None, cc=None
i32 candidate_0368d8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368dd, offset=0x368dc, mode=Thumb, size=None, cc=None
i32 candidate_0368dc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368e1, offset=0x368e0, mode=Thumb, size=None, cc=None
i32 candidate_0368e0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368e5, offset=0x368e4, mode=Thumb, size=None, cc=None
i32 candidate_0368e4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368e9, offset=0x368e8, mode=Thumb, size=None, cc=None
i32 candidate_0368e8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368ed, offset=0x368ec, mode=Thumb, size=None, cc=None
i32 candidate_0368ec(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368f1, offset=0x368f0, mode=Thumb, size=None, cc=None
i32 candidate_0368f0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368f5, offset=0x368f4, mode=Thumb, size=None, cc=None
i32 candidate_0368f4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368f9, offset=0x368f8, mode=Thumb, size=None, cc=None
i32 candidate_0368f8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368fd, offset=0x368fc, mode=Thumb, size=None, cc=None
i32 candidate_0368fc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36901, offset=0x36900, mode=Thumb, size=None, cc=None
i32 candidate_036900(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36905, offset=0x36904, mode=Thumb, size=None, cc=None
i32 candidate_036904(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36909, offset=0x36908, mode=Thumb, size=None, cc=None
i32 candidate_036908(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3690d, offset=0x3690c, mode=Thumb, size=None, cc=None
i32 candidate_03690c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36911, offset=0x36910, mode=Thumb, size=None, cc=None
i32 candidate_036910(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36915, offset=0x36914, mode=Thumb, size=None, cc=None
i32 candidate_036914(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36919, offset=0x36918, mode=Thumb, size=None, cc=None
i32 candidate_036918(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3691d, offset=0x3691c, mode=Thumb, size=None, cc=None
i32 candidate_03691c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36921, offset=0x36920, mode=Thumb, size=None, cc=None
i32 candidate_036920(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36925, offset=0x36924, mode=Thumb, size=None, cc=None
i32 candidate_036924(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36929, offset=0x36928, mode=Thumb, size=None, cc=None
i32 candidate_036928(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3692d, offset=0x3692c, mode=Thumb, size=None, cc=None
i32 candidate_03692c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36931, offset=0x36930, mode=Thumb, size=None, cc=None
i32 candidate_036930(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36935, offset=0x36934, mode=Thumb, size=None, cc=None
i32 candidate_036934(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36939, offset=0x36938, mode=Thumb, size=None, cc=None
i32 candidate_036938(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3693d, offset=0x3693c, mode=Thumb, size=None, cc=None
i32 candidate_03693c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36941, offset=0x36940, mode=Thumb, size=None, cc=None
i32 candidate_036940(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36945, offset=0x36944, mode=Thumb, size=None, cc=None
i32 candidate_036944(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36949, offset=0x36948, mode=Thumb, size=None, cc=None
i32 candidate_036948(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3694d, offset=0x3694c, mode=Thumb, size=None, cc=None
i32 candidate_03694c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36951, offset=0x36950, mode=Thumb, size=None, cc=None
i32 candidate_036950(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36955, offset=0x36954, mode=Thumb, size=None, cc=None
i32 candidate_036954(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36959, offset=0x36958, mode=Thumb, size=None, cc=None
i32 candidate_036958(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3695d, offset=0x3695c, mode=Thumb, size=None, cc=None
i32 candidate_03695c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36961, offset=0x36960, mode=Thumb, size=None, cc=None
i32 candidate_036960(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36965, offset=0x36964, mode=Thumb, size=None, cc=None
i32 candidate_036964(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36969, offset=0x36968, mode=Thumb, size=None, cc=None
i32 candidate_036968(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3696d, offset=0x3696c, mode=Thumb, size=None, cc=None
i32 candidate_03696c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36971, offset=0x36970, mode=Thumb, size=None, cc=None
i32 candidate_036970(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36975, offset=0x36974, mode=Thumb, size=None, cc=None
i32 candidate_036974(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36979, offset=0x36978, mode=Thumb, size=None, cc=None
i32 candidate_036978(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3697d, offset=0x3697c, mode=Thumb, size=None, cc=None
i32 candidate_03697c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36981, offset=0x36980, mode=Thumb, size=None, cc=None
i32 candidate_036980(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36985, offset=0x36984, mode=Thumb, size=None, cc=None
i32 candidate_036984(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36989, offset=0x36988, mode=Thumb, size=None, cc=None
i32 candidate_036988(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3698d, offset=0x3698c, mode=Thumb, size=None, cc=None
i32 candidate_03698c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36991, offset=0x36990, mode=Thumb, size=None, cc=None
i32 candidate_036990(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36995, offset=0x36994, mode=Thumb, size=None, cc=None
i32 candidate_036994(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36999, offset=0x36998, mode=Thumb, size=None, cc=None
i32 candidate_036998(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3699d, offset=0x3699c, mode=Thumb, size=None, cc=None
i32 candidate_03699c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369a1, offset=0x369a0, mode=Thumb, size=None, cc=None
i32 candidate_0369a0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369a5, offset=0x369a4, mode=Thumb, size=None, cc=None
i32 candidate_0369a4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369a9, offset=0x369a8, mode=Thumb, size=None, cc=None
i32 candidate_0369a8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369ad, offset=0x369ac, mode=Thumb, size=None, cc=None
i32 candidate_0369ac(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369b1, offset=0x369b0, mode=Thumb, size=None, cc=None
i32 candidate_0369b0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369b5, offset=0x369b4, mode=Thumb, size=None, cc=None
i32 candidate_0369b4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369b9, offset=0x369b8, mode=Thumb, size=None, cc=None
i32 candidate_0369b8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369bd, offset=0x369bc, mode=Thumb, size=None, cc=None
i32 candidate_0369bc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369c1, offset=0x369c0, mode=Thumb, size=None, cc=None
i32 candidate_0369c0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369c5, offset=0x369c4, mode=Thumb, size=None, cc=None
i32 candidate_0369c4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369c9, offset=0x369c8, mode=Thumb, size=None, cc=None
i32 candidate_0369c8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369cd, offset=0x369cc, mode=Thumb, size=None, cc=None
i32 candidate_0369cc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369d1, offset=0x369d0, mode=Thumb, size=None, cc=None
i32 candidate_0369d0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369d5, offset=0x369d4, mode=Thumb, size=None, cc=None
i32 candidate_0369d4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369d9, offset=0x369d8, mode=Thumb, size=None, cc=None
i32 candidate_0369d8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369dd, offset=0x369dc, mode=Thumb, size=None, cc=None
i32 candidate_0369dc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369e1, offset=0x369e0, mode=Thumb, size=None, cc=None
i32 candidate_0369e0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369e5, offset=0x369e4, mode=Thumb, size=None, cc=None
i32 candidate_0369e4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369e9, offset=0x369e8, mode=Thumb, size=None, cc=None
i32 candidate_0369e8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369ed, offset=0x369ec, mode=Thumb, size=None, cc=None
i32 candidate_0369ec(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369f1, offset=0x369f0, mode=Thumb, size=None, cc=None
i32 candidate_0369f0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369f5, offset=0x369f4, mode=Thumb, size=None, cc=None
i32 candidate_0369f4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369f9, offset=0x369f8, mode=Thumb, size=None, cc=None
i32 candidate_0369f8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369fd, offset=0x369fc, mode=Thumb, size=None, cc=None
i32 candidate_0369fc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a01, offset=0x36a00, mode=Thumb, size=None, cc=None
i32 candidate_036a00(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a05, offset=0x36a04, mode=Thumb, size=None, cc=None
i32 candidate_036a04(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a09, offset=0x36a08, mode=Thumb, size=None, cc=None
i32 candidate_036a08(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a0d, offset=0x36a0c, mode=Thumb, size=None, cc=None
i32 candidate_036a0c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a11, offset=0x36a10, mode=Thumb, size=None, cc=None
i32 candidate_036a10(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a15, offset=0x36a14, mode=Thumb, size=None, cc=None
i32 candidate_036a14(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a19, offset=0x36a18, mode=Thumb, size=None, cc=None
i32 candidate_036a18(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a1d, offset=0x36a1c, mode=Thumb, size=None, cc=None
i32 candidate_036a1c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a21, offset=0x36a20, mode=Thumb, size=None, cc=None
i32 candidate_036a20(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a25, offset=0x36a24, mode=Thumb, size=None, cc=None
i32 candidate_036a24(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a29, offset=0x36a28, mode=Thumb, size=None, cc=None
i32 candidate_036a28(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a2d, offset=0x36a2c, mode=Thumb, size=None, cc=None
i32 candidate_036a2c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a31, offset=0x36a30, mode=Thumb, size=None, cc=None
i32 candidate_036a30(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a35, offset=0x36a34, mode=Thumb, size=None, cc=None
i32 candidate_036a34(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a39, offset=0x36a38, mode=Thumb, size=None, cc=None
i32 candidate_036a38(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a3d, offset=0x36a3c, mode=Thumb, size=None, cc=None
i32 candidate_036a3c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a41, offset=0x36a40, mode=Thumb, size=None, cc=None
i32 candidate_036a40(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a45, offset=0x36a44, mode=Thumb, size=None, cc=None
i32 candidate_036a44(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a49, offset=0x36a48, mode=Thumb, size=None, cc=None
i32 candidate_036a48(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a4d, offset=0x36a4c, mode=Thumb, size=None, cc=None
i32 candidate_036a4c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a51, offset=0x36a50, mode=Thumb, size=None, cc=None
i32 candidate_036a50(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a55, offset=0x36a54, mode=Thumb, size=None, cc=None
i32 candidate_036a54(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a59, offset=0x36a58, mode=Thumb, size=None, cc=None
i32 candidate_036a58(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a5d, offset=0x36a5c, mode=Thumb, size=None, cc=None
i32 candidate_036a5c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a61, offset=0x36a60, mode=Thumb, size=None, cc=None
i32 candidate_036a60(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a65, offset=0x36a64, mode=Thumb, size=None, cc=None
i32 candidate_036a64(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a69, offset=0x36a68, mode=Thumb, size=None, cc=None
i32 candidate_036a68(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a6d, offset=0x36a6c, mode=Thumb, size=None, cc=None
i32 candidate_036a6c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a71, offset=0x36a70, mode=Thumb, size=None, cc=None
i32 candidate_036a70(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a75, offset=0x36a74, mode=Thumb, size=None, cc=None
i32 candidate_036a74(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a79, offset=0x36a78, mode=Thumb, size=None, cc=None
i32 candidate_036a78(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a7d, offset=0x36a7c, mode=Thumb, size=None, cc=None
i32 candidate_036a7c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a81, offset=0x36a80, mode=Thumb, size=None, cc=None
i32 candidate_036a80(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a85, offset=0x36a84, mode=Thumb, size=None, cc=None
i32 candidate_036a84(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a89, offset=0x36a88, mode=Thumb, size=None, cc=None
i32 candidate_036a88(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a8d, offset=0x36a8c, mode=Thumb, size=None, cc=None
i32 candidate_036a8c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a91, offset=0x36a90, mode=Thumb, size=None, cc=None
i32 candidate_036a90(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a95, offset=0x36a94, mode=Thumb, size=None, cc=None
i32 candidate_036a94(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a99, offset=0x36a98, mode=Thumb, size=None, cc=None
i32 candidate_036a98(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a9d, offset=0x36a9c, mode=Thumb, size=None, cc=None
i32 candidate_036a9c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36aa1, offset=0x36aa0, mode=Thumb, size=None, cc=None
i32 candidate_036aa0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36aa5, offset=0x36aa4, mode=Thumb, size=None, cc=None
i32 candidate_036aa4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36aa9, offset=0x36aa8, mode=Thumb, size=None, cc=None
i32 candidate_036aa8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36aad, offset=0x36aac, mode=Thumb, size=None, cc=None
i32 candidate_036aac(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ab1, offset=0x36ab0, mode=Thumb, size=None, cc=None
i32 candidate_036ab0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ab5, offset=0x36ab4, mode=Thumb, size=None, cc=None
i32 candidate_036ab4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ab9, offset=0x36ab8, mode=Thumb, size=None, cc=None
i32 candidate_036ab8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36abd, offset=0x36abc, mode=Thumb, size=None, cc=None
i32 candidate_036abc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ac1, offset=0x36ac0, mode=Thumb, size=None, cc=None
i32 candidate_036ac0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ac5, offset=0x36ac4, mode=Thumb, size=None, cc=None
i32 candidate_036ac4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ac9, offset=0x36ac8, mode=Thumb, size=None, cc=None
i32 candidate_036ac8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36acd, offset=0x36acc, mode=Thumb, size=None, cc=None
i32 candidate_036acc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ad1, offset=0x36ad0, mode=Thumb, size=None, cc=None
i32 candidate_036ad0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ad5, offset=0x36ad4, mode=Thumb, size=None, cc=None
i32 candidate_036ad4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ad9, offset=0x36ad8, mode=Thumb, size=None, cc=None
i32 candidate_036ad8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36add, offset=0x36adc, mode=Thumb, size=None, cc=None
i32 candidate_036adc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ae1, offset=0x36ae0, mode=Thumb, size=None, cc=None
i32 candidate_036ae0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ae5, offset=0x36ae4, mode=Thumb, size=None, cc=None
i32 candidate_036ae4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ae9, offset=0x36ae8, mode=Thumb, size=None, cc=None
i32 candidate_036ae8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36aed, offset=0x36aec, mode=Thumb, size=None, cc=None
i32 candidate_036aec(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36af1, offset=0x36af0, mode=Thumb, size=None, cc=None
i32 candidate_036af0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36af5, offset=0x36af4, mode=Thumb, size=None, cc=None
i32 candidate_036af4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36af9, offset=0x36af8, mode=Thumb, size=None, cc=None
i32 candidate_036af8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36afd, offset=0x36afc, mode=Thumb, size=None, cc=None
i32 candidate_036afc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b01, offset=0x36b00, mode=Thumb, size=None, cc=None
i32 candidate_036b00(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b05, offset=0x36b04, mode=Thumb, size=None, cc=None
i32 candidate_036b04(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b09, offset=0x36b08, mode=Thumb, size=None, cc=None
i32 candidate_036b08(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b0d, offset=0x36b0c, mode=Thumb, size=None, cc=None
i32 candidate_036b0c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b11, offset=0x36b10, mode=Thumb, size=None, cc=None
i32 candidate_036b10(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b15, offset=0x36b14, mode=Thumb, size=None, cc=None
i32 candidate_036b14(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b19, offset=0x36b18, mode=Thumb, size=None, cc=None
i32 candidate_036b18(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b1d, offset=0x36b1c, mode=Thumb, size=None, cc=None
i32 candidate_036b1c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b21, offset=0x36b20, mode=Thumb, size=None, cc=None
i32 candidate_036b20(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b25, offset=0x36b24, mode=Thumb, size=None, cc=None
i32 candidate_036b24(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b29, offset=0x36b28, mode=Thumb, size=None, cc=None
i32 candidate_036b28(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b2d, offset=0x36b2c, mode=Thumb, size=None, cc=None
i32 candidate_036b2c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b31, offset=0x36b30, mode=Thumb, size=None, cc=None
i32 candidate_036b30(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b35, offset=0x36b34, mode=Thumb, size=None, cc=None
i32 candidate_036b34(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b39, offset=0x36b38, mode=Thumb, size=None, cc=None
i32 candidate_036b38(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b3d, offset=0x36b3c, mode=Thumb, size=None, cc=None
i32 candidate_036b3c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b41, offset=0x36b40, mode=Thumb, size=None, cc=None
i32 candidate_036b40(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b45, offset=0x36b44, mode=Thumb, size=None, cc=None
i32 candidate_036b44(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b49, offset=0x36b48, mode=Thumb, size=None, cc=None
i32 candidate_036b48(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b4d, offset=0x36b4c, mode=Thumb, size=None, cc=None
i32 candidate_036b4c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b51, offset=0x36b50, mode=Thumb, size=None, cc=None
i32 candidate_036b50(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b55, offset=0x36b54, mode=Thumb, size=None, cc=None
i32 candidate_036b54(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b59, offset=0x36b58, mode=Thumb, size=None, cc=None
i32 candidate_036b58(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b5d, offset=0x36b5c, mode=Thumb, size=None, cc=None
i32 candidate_036b5c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b61, offset=0x36b60, mode=Thumb, size=None, cc=None
i32 candidate_036b60(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b65, offset=0x36b64, mode=Thumb, size=None, cc=None
i32 candidate_036b64(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b69, offset=0x36b68, mode=Thumb, size=None, cc=None
i32 candidate_036b68(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b6d, offset=0x36b6c, mode=Thumb, size=None, cc=None
i32 candidate_036b6c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b71, offset=0x36b70, mode=Thumb, size=None, cc=None
i32 candidate_036b70(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b75, offset=0x36b74, mode=Thumb, size=None, cc=None
i32 candidate_036b74(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b79, offset=0x36b78, mode=Thumb, size=None, cc=None
i32 candidate_036b78(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b7d, offset=0x36b7c, mode=Thumb, size=None, cc=None
i32 candidate_036b7c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b81, offset=0x36b80, mode=Thumb, size=None, cc=None
i32 candidate_036b80(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b85, offset=0x36b84, mode=Thumb, size=None, cc=None
i32 candidate_036b84(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b89, offset=0x36b88, mode=Thumb, size=None, cc=None
i32 candidate_036b88(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b8d, offset=0x36b8c, mode=Thumb, size=None, cc=None
i32 candidate_036b8c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b91, offset=0x36b90, mode=Thumb, size=None, cc=None
i32 candidate_036b90(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b95, offset=0x36b94, mode=Thumb, size=None, cc=None
i32 candidate_036b94(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b99, offset=0x36b98, mode=Thumb, size=None, cc=None
i32 candidate_036b98(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b9d, offset=0x36b9c, mode=Thumb, size=None, cc=None
i32 candidate_036b9c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ba1, offset=0x36ba0, mode=Thumb, size=None, cc=None
i32 candidate_036ba0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ba5, offset=0x36ba4, mode=Thumb, size=None, cc=None
i32 candidate_036ba4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ba9, offset=0x36ba8, mode=Thumb, size=None, cc=None
i32 candidate_036ba8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36bad, offset=0x36bac, mode=Thumb, size=None, cc=None
i32 candidate_036bac(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36bb1, offset=0x36bb0, mode=Thumb, size=None, cc=None
i32 candidate_036bb0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36bb5, offset=0x36bb4, mode=Thumb, size=None, cc=None
i32 candidate_036bb4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4390b, offset=0x4390a, mode=Thumb, size=None, cc=None
i32 candidate_04390a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43939, offset=0x43938, mode=Thumb, size=None, cc=None
i32 candidate_043938(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43947, offset=0x43946, mode=Thumb, size=None, cc=None
i32 candidate_043946(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43a71, offset=0x43a70, mode=Thumb, size=None, cc=None
i32 candidate_043a70(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43a9b, offset=0x43a9a, mode=Thumb, size=None, cc=None
i32 candidate_043a9a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43b15, offset=0x43b14, mode=Thumb, size=None, cc=None
i32 candidate_043b14(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43b5b, offset=0x43b5a, mode=Thumb, size=None, cc=None
i32 candidate_043b5a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43b61, offset=0x43b60, mode=Thumb, size=None, cc=None
i32 candidate_043b60(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43b71, offset=0x43b70, mode=Thumb, size=None, cc=None
i32 candidate_043b70(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43c5b, offset=0x43c5a, mode=Thumb, size=None, cc=None
i32 candidate_043c5a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43cf9, offset=0x43cf8, mode=Thumb, size=None, cc=None
i32 candidate_043cf8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43e1b, offset=0x43e1a, mode=Thumb, size=None, cc=None
i32 candidate_043e1a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43e25, offset=0x43e24, mode=Thumb, size=None, cc=None
i32 candidate_043e24(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43e2d, offset=0x43e2c, mode=Thumb, size=None, cc=None
i32 candidate_043e2c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43f89, offset=0x43f88, mode=Thumb, size=None, cc=None
i32 candidate_043f88(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x43fc5, offset=0x43fc4, mode=Thumb, size=None, cc=None
i32 candidate_043fc4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4406b, offset=0x4406a, mode=Thumb, size=None, cc=None
i32 candidate_04406a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44077, offset=0x44076, mode=Thumb, size=None, cc=None
i32 candidate_044076(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x440bb, offset=0x440ba, mode=Thumb, size=None, cc=None
i32 candidate_0440ba(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x440d5, offset=0x440d4, mode=Thumb, size=None, cc=None
i32 candidate_0440d4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x440d7, offset=0x440d6, mode=Thumb, size=None, cc=None
i32 candidate_0440d6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4410b, offset=0x4410a, mode=Thumb, size=None, cc=None
i32 candidate_04410a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44135, offset=0x44134, mode=Thumb, size=None, cc=None
i32 candidate_044134(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44149, offset=0x44148, mode=Thumb, size=None, cc=None
i32 candidate_044148(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x442e1, offset=0x442e0, mode=Thumb, size=None, cc=None
i32 candidate_0442e0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4437f, offset=0x4437e, mode=Thumb, size=None, cc=None
i32 candidate_04437e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44495, offset=0x44494, mode=Thumb, size=None, cc=None
i32 candidate_044494(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x444cd, offset=0x444cc, mode=Thumb, size=None, cc=None
i32 candidate_0444cc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x444e9, offset=0x444e8, mode=Thumb, size=None, cc=None
i32 candidate_0444e8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44547, offset=0x44546, mode=Thumb, size=None, cc=None
i32 candidate_044546(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44561, offset=0x44560, mode=Thumb, size=None, cc=None
i32 candidate_044560(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x446e3, offset=0x446e2, mode=Thumb, size=None, cc=None
i32 candidate_0446e2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44805, offset=0x44804, mode=Thumb, size=None, cc=None
i32 candidate_044804(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44ab7, offset=0x44ab6, mode=Thumb, size=None, cc=None
i32 candidate_044ab6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44b35, offset=0x44b34, mode=Thumb, size=None, cc=None
i32 candidate_044b34(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44bd9, offset=0x44bd8, mode=Thumb, size=None, cc=None
i32 candidate_044bd8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44c2b, offset=0x44c2a, mode=Thumb, size=None, cc=None
i32 candidate_044c2a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44d1d, offset=0x44d1c, mode=Thumb, size=None, cc=None
i32 candidate_044d1c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44edd, offset=0x44edc, mode=Thumb, size=None, cc=None
i32 candidate_044edc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44f23, offset=0x44f22, mode=Thumb, size=None, cc=None
i32 candidate_044f22(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44f95, offset=0x44f94, mode=Thumb, size=None, cc=None
i32 candidate_044f94(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45297, offset=0x45296, mode=Thumb, size=None, cc=None
i32 candidate_045296(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45385, offset=0x45384, mode=Thumb, size=None, cc=None
i32 candidate_045384(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x454c5, offset=0x454c4, mode=Thumb, size=None, cc=None
i32 candidate_0454c4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x454cd, offset=0x454cc, mode=Thumb, size=None, cc=None
i32 candidate_0454cc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4560b, offset=0x4560a, mode=Thumb, size=None, cc=None
i32 candidate_04560a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x456fd, offset=0x456fc, mode=Thumb, size=None, cc=None
i32 candidate_0456fc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4588f, offset=0x4588e, mode=Thumb, size=None, cc=None
i32 candidate_04588e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4590f, offset=0x4590e, mode=Thumb, size=None, cc=None
i32 candidate_04590e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45921, offset=0x45920, mode=Thumb, size=None, cc=None
i32 candidate_045920(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45999, offset=0x45998, mode=Thumb, size=None, cc=None
i32 candidate_045998(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x459e9, offset=0x459e8, mode=Thumb, size=None, cc=None
i32 candidate_0459e8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x459ff, offset=0x459fe, mode=Thumb, size=None, cc=None
i32 candidate_0459fe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45a03, offset=0x45a02, mode=Thumb, size=None, cc=None
i32 candidate_045a02(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45b13, offset=0x45b12, mode=Thumb, size=None, cc=None
i32 candidate_045b12(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45b47, offset=0x45b46, mode=Thumb, size=None, cc=None
i32 candidate_045b46(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45b7b, offset=0x45b7a, mode=Thumb, size=None, cc=None
i32 candidate_045b7a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45bdf, offset=0x45bde, mode=Thumb, size=None, cc=None
i32 candidate_045bde(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45c03, offset=0x45c02, mode=Thumb, size=None, cc=None
i32 candidate_045c02(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45c43, offset=0x45c42, mode=Thumb, size=None, cc=None
i32 candidate_045c42(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45d15, offset=0x45d14, mode=Thumb, size=None, cc=None
i32 candidate_045d14(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45e4d, offset=0x45e4c, mode=Thumb, size=None, cc=None
i32 candidate_045e4c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45ea1, offset=0x45ea0, mode=Thumb, size=None, cc=None
i32 candidate_045ea0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45eb1, offset=0x45eb0, mode=Thumb, size=None, cc=None
i32 candidate_045eb0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45f65, offset=0x45f64, mode=Thumb, size=None, cc=None
i32 candidate_045f64(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4613b, offset=0x4613a, mode=Thumb, size=None, cc=None
i32 candidate_04613a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4613d, offset=0x4613c, mode=Thumb, size=None, cc=None
i32 candidate_04613c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4617b, offset=0x4617a, mode=Thumb, size=None, cc=None
i32 candidate_04617a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4623f, offset=0x4623e, mode=Thumb, size=None, cc=None
i32 candidate_04623e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4625f, offset=0x4625e, mode=Thumb, size=None, cc=None
i32 candidate_04625e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x46317, offset=0x46316, mode=Thumb, size=None, cc=None
i32 candidate_046316(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4632b, offset=0x4632a, mode=Thumb, size=None, cc=None
i32 candidate_04632a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4639b, offset=0x4639a, mode=Thumb, size=None, cc=None
i32 candidate_04639a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x463c1, offset=0x463c0, mode=Thumb, size=None, cc=None
i32 candidate_0463c0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x463d9, offset=0x463d8, mode=Thumb, size=None, cc=None
i32 candidate_0463d8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x463e7, offset=0x463e6, mode=Thumb, size=None, cc=None
i32 candidate_0463e6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x46429, offset=0x46428, mode=Thumb, size=None, cc=None
i32 candidate_046428(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x46445, offset=0x46444, mode=Thumb, size=None, cc=None
i32 candidate_046444(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4649b, offset=0x4649a, mode=Thumb, size=None, cc=None
i32 candidate_04649a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x464f5, offset=0x464f4, mode=Thumb, size=None, cc=None
i32 candidate_0464f4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x464fb, offset=0x464fa, mode=Thumb, size=None, cc=None
i32 candidate_0464fa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4652f, offset=0x4652e, mode=Thumb, size=None, cc=None
i32 candidate_04652e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x465a3, offset=0x465a2, mode=Thumb, size=None, cc=None
i32 candidate_0465a2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x46631, offset=0x46630, mode=Thumb, size=None, cc=None
i32 candidate_046630(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4676d, offset=0x4676c, mode=Thumb, size=None, cc=None
i32 candidate_04676c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x468a1, offset=0x468a0, mode=Thumb, size=None, cc=None
i32 candidate_0468a0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4691f, offset=0x4691e, mode=Thumb, size=None, cc=None
i32 candidate_04691e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x46b77, offset=0x46b76, mode=Thumb, size=None, cc=None
i32 candidate_046b76(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x46d9b, offset=0x46d9a, mode=Thumb, size=None, cc=None
i32 candidate_046d9a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x46f4f, offset=0x46f4e, mode=Thumb, size=None, cc=None
i32 candidate_046f4e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x46f53, offset=0x46f52, mode=Thumb, size=None, cc=None
i32 candidate_046f52(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47317, offset=0x47316, mode=Thumb, size=None, cc=None
i32 candidate_047316(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4739d, offset=0x4739c, mode=Thumb, size=None, cc=None
i32 candidate_04739c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x473c7, offset=0x473c6, mode=Thumb, size=None, cc=None
i32 candidate_0473c6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x473e1, offset=0x473e0, mode=Thumb, size=None, cc=None
i32 candidate_0473e0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47453, offset=0x47452, mode=Thumb, size=None, cc=None
i32 candidate_047452(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47531, offset=0x47530, mode=Thumb, size=None, cc=None
i32 candidate_047530(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4781d, offset=0x4781c, mode=Thumb, size=None, cc=None
i32 candidate_04781c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47855, offset=0x47854, mode=Thumb, size=None, cc=None
i32 candidate_047854(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47897, offset=0x47896, mode=Thumb, size=None, cc=None
i32 candidate_047896(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x478ad, offset=0x478ac, mode=Thumb, size=None, cc=None
i32 candidate_0478ac(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x478bb, offset=0x478ba, mode=Thumb, size=None, cc=None
i32 candidate_0478ba(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47a63, offset=0x47a62, mode=Thumb, size=None, cc=None
i32 candidate_047a62(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47abd, offset=0x47abc, mode=Thumb, size=None, cc=None
i32 candidate_047abc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47db3, offset=0x47db2, mode=Thumb, size=None, cc=None
i32 candidate_047db2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47de9, offset=0x47de8, mode=Thumb, size=None, cc=None
i32 candidate_047de8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47e47, offset=0x47e46, mode=Thumb, size=None, cc=None
i32 candidate_047e46(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48147, offset=0x48146, mode=Thumb, size=None, cc=None
i32 candidate_048146(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4825d, offset=0x4825c, mode=Thumb, size=None, cc=None
i32 candidate_04825c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x486c3, offset=0x486c2, mode=Thumb, size=None, cc=None
i32 candidate_0486c2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4873f, offset=0x4873e, mode=Thumb, size=None, cc=None
i32 candidate_04873e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48745, offset=0x48744, mode=Thumb, size=None, cc=None
i32 candidate_048744(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48831, offset=0x48830, mode=Thumb, size=None, cc=None
i32 candidate_048830(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4883f, offset=0x4883e, mode=Thumb, size=None, cc=None
i32 candidate_04883e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x488d7, offset=0x488d6, mode=Thumb, size=None, cc=None
i32 candidate_0488d6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48927, offset=0x48926, mode=Thumb, size=None, cc=None
i32 candidate_048926(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x489cb, offset=0x489ca, mode=Thumb, size=None, cc=None
i32 candidate_0489ca(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x489dd, offset=0x489dc, mode=Thumb, size=None, cc=None
i32 candidate_0489dc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48a83, offset=0x48a82, mode=Thumb, size=None, cc=None
i32 candidate_048a82(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48c29, offset=0x48c28, mode=Thumb, size=None, cc=None
i32 candidate_048c28(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48c83, offset=0x48c82, mode=Thumb, size=None, cc=None
i32 candidate_048c82(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48d55, offset=0x48d54, mode=Thumb, size=None, cc=None
i32 candidate_048d54(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ddd, offset=0x48ddc, mode=Thumb, size=None, cc=None
i32 candidate_048ddc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ddf, offset=0x48dde, mode=Thumb, size=None, cc=None
i32 candidate_048dde(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48de1, offset=0x48de0, mode=Thumb, size=None, cc=None
i32 candidate_048de0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48de5, offset=0x48de4, mode=Thumb, size=None, cc=None
i32 candidate_048de4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48de7, offset=0x48de6, mode=Thumb, size=None, cc=None
i32 candidate_048de6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48de9, offset=0x48de8, mode=Thumb, size=None, cc=None
i32 candidate_048de8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48deb, offset=0x48dea, mode=Thumb, size=None, cc=None
i32 candidate_048dea(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48df3, offset=0x48df2, mode=Thumb, size=None, cc=None
i32 candidate_048df2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48df5, offset=0x48df4, mode=Thumb, size=None, cc=None
i32 candidate_048df4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48df9, offset=0x48df8, mode=Thumb, size=None, cc=None
i32 candidate_048df8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48dfd, offset=0x48dfc, mode=Thumb, size=None, cc=None
i32 candidate_048dfc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48dff, offset=0x48dfe, mode=Thumb, size=None, cc=None
i32 candidate_048dfe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e01, offset=0x48e00, mode=Thumb, size=None, cc=None
i32 candidate_048e00(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e05, offset=0x48e04, mode=Thumb, size=None, cc=None
i32 candidate_048e04(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e07, offset=0x48e06, mode=Thumb, size=None, cc=None
i32 candidate_048e06(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e0f, offset=0x48e0e, mode=Thumb, size=None, cc=None
i32 candidate_048e0e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e11, offset=0x48e10, mode=Thumb, size=None, cc=None
i32 candidate_048e10(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e13, offset=0x48e12, mode=Thumb, size=None, cc=None
i32 candidate_048e12(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e15, offset=0x48e14, mode=Thumb, size=None, cc=None
i32 candidate_048e14(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e19, offset=0x48e18, mode=Thumb, size=None, cc=None
i32 candidate_048e18(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e1d, offset=0x48e1c, mode=Thumb, size=None, cc=None
i32 candidate_048e1c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e21, offset=0x48e20, mode=Thumb, size=None, cc=None
i32 candidate_048e20(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e25, offset=0x48e24, mode=Thumb, size=None, cc=None
i32 candidate_048e24(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e27, offset=0x48e26, mode=Thumb, size=None, cc=None
i32 candidate_048e26(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e29, offset=0x48e28, mode=Thumb, size=None, cc=None
i32 candidate_048e28(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e2b, offset=0x48e2a, mode=Thumb, size=None, cc=None
i32 candidate_048e2a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e2d, offset=0x48e2c, mode=Thumb, size=None, cc=None
i32 candidate_048e2c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e2f, offset=0x48e2e, mode=Thumb, size=None, cc=None
i32 candidate_048e2e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e31, offset=0x48e30, mode=Thumb, size=None, cc=None
i32 candidate_048e30(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e33, offset=0x48e32, mode=Thumb, size=None, cc=None
i32 candidate_048e32(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e3f, offset=0x48e3e, mode=Thumb, size=None, cc=None
i32 candidate_048e3e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e41, offset=0x48e40, mode=Thumb, size=None, cc=None
i32 candidate_048e40(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e43, offset=0x48e42, mode=Thumb, size=None, cc=None
i32 candidate_048e42(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e45, offset=0x48e44, mode=Thumb, size=None, cc=None
i32 candidate_048e44(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e49, offset=0x48e48, mode=Thumb, size=None, cc=None
i32 candidate_048e48(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e4b, offset=0x48e4a, mode=Thumb, size=None, cc=None
i32 candidate_048e4a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e4d, offset=0x48e4c, mode=Thumb, size=None, cc=None
i32 candidate_048e4c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e4f, offset=0x48e4e, mode=Thumb, size=None, cc=None
i32 candidate_048e4e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e53, offset=0x48e52, mode=Thumb, size=None, cc=None
i32 candidate_048e52(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e55, offset=0x48e54, mode=Thumb, size=None, cc=None
i32 candidate_048e54(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e57, offset=0x48e56, mode=Thumb, size=None, cc=None
i32 candidate_048e56(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e59, offset=0x48e58, mode=Thumb, size=None, cc=None
i32 candidate_048e58(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e5b, offset=0x48e5a, mode=Thumb, size=None, cc=None
i32 candidate_048e5a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e5d, offset=0x48e5c, mode=Thumb, size=None, cc=None
i32 candidate_048e5c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e61, offset=0x48e60, mode=Thumb, size=None, cc=None
i32 candidate_048e60(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e63, offset=0x48e62, mode=Thumb, size=None, cc=None
i32 candidate_048e62(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e65, offset=0x48e64, mode=Thumb, size=None, cc=None
i32 candidate_048e64(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e6b, offset=0x48e6a, mode=Thumb, size=None, cc=None
i32 candidate_048e6a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e6d, offset=0x48e6c, mode=Thumb, size=None, cc=None
i32 candidate_048e6c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e6f, offset=0x48e6e, mode=Thumb, size=None, cc=None
i32 candidate_048e6e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e71, offset=0x48e70, mode=Thumb, size=None, cc=None
i32 candidate_048e70(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e73, offset=0x48e72, mode=Thumb, size=None, cc=None
i32 candidate_048e72(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e77, offset=0x48e76, mode=Thumb, size=None, cc=None
i32 candidate_048e76(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e79, offset=0x48e78, mode=Thumb, size=None, cc=None
i32 candidate_048e78(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e7b, offset=0x48e7a, mode=Thumb, size=None, cc=None
i32 candidate_048e7a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e81, offset=0x48e80, mode=Thumb, size=None, cc=None
i32 candidate_048e80(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e83, offset=0x48e82, mode=Thumb, size=None, cc=None
i32 candidate_048e82(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e85, offset=0x48e84, mode=Thumb, size=None, cc=None
i32 candidate_048e84(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e89, offset=0x48e88, mode=Thumb, size=None, cc=None
i32 candidate_048e88(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e8b, offset=0x48e8a, mode=Thumb, size=None, cc=None
i32 candidate_048e8a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e8d, offset=0x48e8c, mode=Thumb, size=None, cc=None
i32 candidate_048e8c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e8f, offset=0x48e8e, mode=Thumb, size=None, cc=None
i32 candidate_048e8e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e91, offset=0x48e90, mode=Thumb, size=None, cc=None
i32 candidate_048e90(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e93, offset=0x48e92, mode=Thumb, size=None, cc=None
i32 candidate_048e92(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e95, offset=0x48e94, mode=Thumb, size=None, cc=None
i32 candidate_048e94(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e97, offset=0x48e96, mode=Thumb, size=None, cc=None
i32 candidate_048e96(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e99, offset=0x48e98, mode=Thumb, size=None, cc=None
i32 candidate_048e98(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e9b, offset=0x48e9a, mode=Thumb, size=None, cc=None
i32 candidate_048e9a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e9d, offset=0x48e9c, mode=Thumb, size=None, cc=None
i32 candidate_048e9c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48e9f, offset=0x48e9e, mode=Thumb, size=None, cc=None
i32 candidate_048e9e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ea1, offset=0x48ea0, mode=Thumb, size=None, cc=None
i32 candidate_048ea0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ea3, offset=0x48ea2, mode=Thumb, size=None, cc=None
i32 candidate_048ea2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ea7, offset=0x48ea6, mode=Thumb, size=None, cc=None
i32 candidate_048ea6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ea9, offset=0x48ea8, mode=Thumb, size=None, cc=None
i32 candidate_048ea8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48eab, offset=0x48eaa, mode=Thumb, size=None, cc=None
i32 candidate_048eaa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48eaf, offset=0x48eae, mode=Thumb, size=None, cc=None
i32 candidate_048eae(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48eb1, offset=0x48eb0, mode=Thumb, size=None, cc=None
i32 candidate_048eb0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48eb3, offset=0x48eb2, mode=Thumb, size=None, cc=None
i32 candidate_048eb2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48eb5, offset=0x48eb4, mode=Thumb, size=None, cc=None
i32 candidate_048eb4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48eb7, offset=0x48eb6, mode=Thumb, size=None, cc=None
i32 candidate_048eb6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ebb, offset=0x48eba, mode=Thumb, size=None, cc=None
i32 candidate_048eba(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ebf, offset=0x48ebe, mode=Thumb, size=None, cc=None
i32 candidate_048ebe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ec1, offset=0x48ec0, mode=Thumb, size=None, cc=None
i32 candidate_048ec0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ec5, offset=0x48ec4, mode=Thumb, size=None, cc=None
i32 candidate_048ec4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ec7, offset=0x48ec6, mode=Thumb, size=None, cc=None
i32 candidate_048ec6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ecb, offset=0x48eca, mode=Thumb, size=None, cc=None
i32 candidate_048eca(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ecd, offset=0x48ecc, mode=Thumb, size=None, cc=None
i32 candidate_048ecc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ecf, offset=0x48ece, mode=Thumb, size=None, cc=None
i32 candidate_048ece(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ed1, offset=0x48ed0, mode=Thumb, size=None, cc=None
i32 candidate_048ed0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ed3, offset=0x48ed2, mode=Thumb, size=None, cc=None
i32 candidate_048ed2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ed5, offset=0x48ed4, mode=Thumb, size=None, cc=None
i32 candidate_048ed4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ed9, offset=0x48ed8, mode=Thumb, size=None, cc=None
i32 candidate_048ed8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48edb, offset=0x48eda, mode=Thumb, size=None, cc=None
i32 candidate_048eda(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48edd, offset=0x48edc, mode=Thumb, size=None, cc=None
i32 candidate_048edc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ee1, offset=0x48ee0, mode=Thumb, size=None, cc=None
i32 candidate_048ee0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ee3, offset=0x48ee2, mode=Thumb, size=None, cc=None
i32 candidate_048ee2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ee5, offset=0x48ee4, mode=Thumb, size=None, cc=None
i32 candidate_048ee4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ee7, offset=0x48ee6, mode=Thumb, size=None, cc=None
i32 candidate_048ee6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ee9, offset=0x48ee8, mode=Thumb, size=None, cc=None
i32 candidate_048ee8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48eeb, offset=0x48eea, mode=Thumb, size=None, cc=None
i32 candidate_048eea(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48eed, offset=0x48eec, mode=Thumb, size=None, cc=None
i32 candidate_048eec(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48eef, offset=0x48eee, mode=Thumb, size=None, cc=None
i32 candidate_048eee(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ef1, offset=0x48ef0, mode=Thumb, size=None, cc=None
i32 candidate_048ef0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ef3, offset=0x48ef2, mode=Thumb, size=None, cc=None
i32 candidate_048ef2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ef5, offset=0x48ef4, mode=Thumb, size=None, cc=None
i32 candidate_048ef4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ef7, offset=0x48ef6, mode=Thumb, size=None, cc=None
i32 candidate_048ef6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ef9, offset=0x48ef8, mode=Thumb, size=None, cc=None
i32 candidate_048ef8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48efd, offset=0x48efc, mode=Thumb, size=None, cc=None
i32 candidate_048efc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48eff, offset=0x48efe, mode=Thumb, size=None, cc=None
i32 candidate_048efe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f01, offset=0x48f00, mode=Thumb, size=None, cc=None
i32 candidate_048f00(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f03, offset=0x48f02, mode=Thumb, size=None, cc=None
i32 candidate_048f02(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f05, offset=0x48f04, mode=Thumb, size=None, cc=None
i32 candidate_048f04(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f07, offset=0x48f06, mode=Thumb, size=None, cc=None
i32 candidate_048f06(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f09, offset=0x48f08, mode=Thumb, size=None, cc=None
i32 candidate_048f08(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f0b, offset=0x48f0a, mode=Thumb, size=None, cc=None
i32 candidate_048f0a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f0d, offset=0x48f0c, mode=Thumb, size=None, cc=None
i32 candidate_048f0c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f0f, offset=0x48f0e, mode=Thumb, size=None, cc=None
i32 candidate_048f0e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f13, offset=0x48f12, mode=Thumb, size=None, cc=None
i32 candidate_048f12(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f15, offset=0x48f14, mode=Thumb, size=None, cc=None
i32 candidate_048f14(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f17, offset=0x48f16, mode=Thumb, size=None, cc=None
i32 candidate_048f16(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f19, offset=0x48f18, mode=Thumb, size=None, cc=None
i32 candidate_048f18(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f1b, offset=0x48f1a, mode=Thumb, size=None, cc=None
i32 candidate_048f1a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f1f, offset=0x48f1e, mode=Thumb, size=None, cc=None
i32 candidate_048f1e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f21, offset=0x48f20, mode=Thumb, size=None, cc=None
i32 candidate_048f20(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f23, offset=0x48f22, mode=Thumb, size=None, cc=None
i32 candidate_048f22(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f25, offset=0x48f24, mode=Thumb, size=None, cc=None
i32 candidate_048f24(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f27, offset=0x48f26, mode=Thumb, size=None, cc=None
i32 candidate_048f26(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f29, offset=0x48f28, mode=Thumb, size=None, cc=None
i32 candidate_048f28(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f2b, offset=0x48f2a, mode=Thumb, size=None, cc=None
i32 candidate_048f2a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f2d, offset=0x48f2c, mode=Thumb, size=None, cc=None
i32 candidate_048f2c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f2f, offset=0x48f2e, mode=Thumb, size=None, cc=None
i32 candidate_048f2e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f31, offset=0x48f30, mode=Thumb, size=None, cc=None
i32 candidate_048f30(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f33, offset=0x48f32, mode=Thumb, size=None, cc=None
i32 candidate_048f32(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f35, offset=0x48f34, mode=Thumb, size=None, cc=None
i32 candidate_048f34(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f37, offset=0x48f36, mode=Thumb, size=None, cc=None
i32 candidate_048f36(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f39, offset=0x48f38, mode=Thumb, size=None, cc=None
i32 candidate_048f38(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f3b, offset=0x48f3a, mode=Thumb, size=None, cc=None
i32 candidate_048f3a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f3f, offset=0x48f3e, mode=Thumb, size=None, cc=None
i32 candidate_048f3e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f41, offset=0x48f40, mode=Thumb, size=None, cc=None
i32 candidate_048f40(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f43, offset=0x48f42, mode=Thumb, size=None, cc=None
i32 candidate_048f42(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f45, offset=0x48f44, mode=Thumb, size=None, cc=None
i32 candidate_048f44(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f47, offset=0x48f46, mode=Thumb, size=None, cc=None
i32 candidate_048f46(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f4f, offset=0x48f4e, mode=Thumb, size=None, cc=None
i32 candidate_048f4e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f53, offset=0x48f52, mode=Thumb, size=None, cc=None
i32 candidate_048f52(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f59, offset=0x48f58, mode=Thumb, size=None, cc=None
i32 candidate_048f58(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f5b, offset=0x48f5a, mode=Thumb, size=None, cc=None
i32 candidate_048f5a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f5d, offset=0x48f5c, mode=Thumb, size=None, cc=None
i32 candidate_048f5c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f5f, offset=0x48f5e, mode=Thumb, size=None, cc=None
i32 candidate_048f5e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f63, offset=0x48f62, mode=Thumb, size=None, cc=None
i32 candidate_048f62(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f69, offset=0x48f68, mode=Thumb, size=None, cc=None
i32 candidate_048f68(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f6b, offset=0x48f6a, mode=Thumb, size=None, cc=None
i32 candidate_048f6a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f6d, offset=0x48f6c, mode=Thumb, size=None, cc=None
i32 candidate_048f6c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f6f, offset=0x48f6e, mode=Thumb, size=None, cc=None
i32 candidate_048f6e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f71, offset=0x48f70, mode=Thumb, size=None, cc=None
i32 candidate_048f70(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f73, offset=0x48f72, mode=Thumb, size=None, cc=None
i32 candidate_048f72(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f75, offset=0x48f74, mode=Thumb, size=None, cc=None
i32 candidate_048f74(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f77, offset=0x48f76, mode=Thumb, size=None, cc=None
i32 candidate_048f76(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f79, offset=0x48f78, mode=Thumb, size=None, cc=None
i32 candidate_048f78(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f7d, offset=0x48f7c, mode=Thumb, size=None, cc=None
i32 candidate_048f7c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f7f, offset=0x48f7e, mode=Thumb, size=None, cc=None
i32 candidate_048f7e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f85, offset=0x48f84, mode=Thumb, size=None, cc=None
i32 candidate_048f84(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f87, offset=0x48f86, mode=Thumb, size=None, cc=None
i32 candidate_048f86(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f97, offset=0x48f96, mode=Thumb, size=None, cc=None
i32 candidate_048f96(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f9b, offset=0x48f9a, mode=Thumb, size=None, cc=None
i32 candidate_048f9a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48f9d, offset=0x48f9c, mode=Thumb, size=None, cc=None
i32 candidate_048f9c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fa1, offset=0x48fa0, mode=Thumb, size=None, cc=None
i32 candidate_048fa0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fa7, offset=0x48fa6, mode=Thumb, size=None, cc=None
i32 candidate_048fa6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fa9, offset=0x48fa8, mode=Thumb, size=None, cc=None
i32 candidate_048fa8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fab, offset=0x48faa, mode=Thumb, size=None, cc=None
i32 candidate_048faa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fad, offset=0x48fac, mode=Thumb, size=None, cc=None
i32 candidate_048fac(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fb1, offset=0x48fb0, mode=Thumb, size=None, cc=None
i32 candidate_048fb0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fb5, offset=0x48fb4, mode=Thumb, size=None, cc=None
i32 candidate_048fb4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fb7, offset=0x48fb6, mode=Thumb, size=None, cc=None
i32 candidate_048fb6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fb9, offset=0x48fb8, mode=Thumb, size=None, cc=None
i32 candidate_048fb8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fbb, offset=0x48fba, mode=Thumb, size=None, cc=None
i32 candidate_048fba(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fbd, offset=0x48fbc, mode=Thumb, size=None, cc=None
i32 candidate_048fbc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fbf, offset=0x48fbe, mode=Thumb, size=None, cc=None
i32 candidate_048fbe(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fc1, offset=0x48fc0, mode=Thumb, size=None, cc=None
i32 candidate_048fc0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fc3, offset=0x48fc2, mode=Thumb, size=None, cc=None
i32 candidate_048fc2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fc7, offset=0x48fc6, mode=Thumb, size=None, cc=None
i32 candidate_048fc6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fcb, offset=0x48fca, mode=Thumb, size=None, cc=None
i32 candidate_048fca(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fcd, offset=0x48fcc, mode=Thumb, size=None, cc=None
i32 candidate_048fcc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fcf, offset=0x48fce, mode=Thumb, size=None, cc=None
i32 candidate_048fce(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fd1, offset=0x48fd0, mode=Thumb, size=None, cc=None
i32 candidate_048fd0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fd3, offset=0x48fd2, mode=Thumb, size=None, cc=None
i32 candidate_048fd2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fd9, offset=0x48fd8, mode=Thumb, size=None, cc=None
i32 candidate_048fd8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fdb, offset=0x48fda, mode=Thumb, size=None, cc=None
i32 candidate_048fda(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fe1, offset=0x48fe0, mode=Thumb, size=None, cc=None
i32 candidate_048fe0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fe3, offset=0x48fe2, mode=Thumb, size=None, cc=None
i32 candidate_048fe2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fe5, offset=0x48fe4, mode=Thumb, size=None, cc=None
i32 candidate_048fe4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fe7, offset=0x48fe6, mode=Thumb, size=None, cc=None
i32 candidate_048fe6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48feb, offset=0x48fea, mode=Thumb, size=None, cc=None
i32 candidate_048fea(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fed, offset=0x48fec, mode=Thumb, size=None, cc=None
i32 candidate_048fec(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48fef, offset=0x48fee, mode=Thumb, size=None, cc=None
i32 candidate_048fee(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ff1, offset=0x48ff0, mode=Thumb, size=None, cc=None
i32 candidate_048ff0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ff5, offset=0x48ff4, mode=Thumb, size=None, cc=None
i32 candidate_048ff4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ff7, offset=0x48ff6, mode=Thumb, size=None, cc=None
i32 candidate_048ff6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ff9, offset=0x48ff8, mode=Thumb, size=None, cc=None
i32 candidate_048ff8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4914b, offset=0x4914a, mode=Thumb, size=None, cc=None
i32 candidate_04914a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x491d3, offset=0x491d2, mode=Thumb, size=None, cc=None
i32 candidate_0491d2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x49203, offset=0x49202, mode=Thumb, size=None, cc=None
i32 candidate_049202(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4920d, offset=0x4920c, mode=Thumb, size=None, cc=None
i32 candidate_04920c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4930b, offset=0x4930a, mode=Thumb, size=None, cc=None
i32 candidate_04930a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4932d, offset=0x4932c, mode=Thumb, size=None, cc=None
i32 candidate_04932c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x49367, offset=0x49366, mode=Thumb, size=None, cc=None
i32 candidate_049366(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4937d, offset=0x4937c, mode=Thumb, size=None, cc=None
i32 candidate_04937c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x49497, offset=0x49496, mode=Thumb, size=None, cc=None
i32 candidate_049496(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x494e3, offset=0x494e2, mode=Thumb, size=None, cc=None
i32 candidate_0494e2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x49603, offset=0x49602, mode=Thumb, size=None, cc=None
i32 candidate_049602(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x49647, offset=0x49646, mode=Thumb, size=None, cc=None
i32 candidate_049646(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x49a33, offset=0x49a32, mode=Thumb, size=None, cc=None
i32 candidate_049a32(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x49ab5, offset=0x49ab4, mode=Thumb, size=None, cc=None
i32 candidate_049ab4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x49afd, offset=0x49afc, mode=Thumb, size=None, cc=None
i32 candidate_049afc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x49c93, offset=0x49c92, mode=Thumb, size=None, cc=None
i32 candidate_049c92(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x49c95, offset=0x49c94, mode=Thumb, size=None, cc=None
i32 candidate_049c94(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x49d4f, offset=0x49d4e, mode=Thumb, size=None, cc=None
i32 candidate_049d4e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x49da9, offset=0x49da8, mode=Thumb, size=None, cc=None
i32 candidate_049da8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x49e61, offset=0x49e60, mode=Thumb, size=None, cc=None
i32 candidate_049e60(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x49ee1, offset=0x49ee0, mode=Thumb, size=None, cc=None
i32 candidate_049ee0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4a147, offset=0x4a146, mode=Thumb, size=None, cc=None
i32 candidate_04a146(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4a325, offset=0x4a324, mode=Thumb, size=None, cc=None
i32 candidate_04a324(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4a397, offset=0x4a396, mode=Thumb, size=None, cc=None
i32 candidate_04a396(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4a5b7, offset=0x4a5b6, mode=Thumb, size=None, cc=None
i32 candidate_04a5b6(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4a5d9, offset=0x4a5d8, mode=Thumb, size=None, cc=None
i32 candidate_04a5d8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4aa6b, offset=0x4aa6a, mode=Thumb, size=None, cc=None
i32 candidate_04aa6a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4abc1, offset=0x4abc0, mode=Thumb, size=None, cc=None
i32 candidate_04abc0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ad19, offset=0x4ad18, mode=Thumb, size=None, cc=None
i32 candidate_04ad18(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4adeb, offset=0x4adea, mode=Thumb, size=None, cc=None
i32 candidate_04adea(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4b0a1, offset=0x4b0a0, mode=Thumb, size=None, cc=None
i32 candidate_04b0a0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4b46f, offset=0x4b46e, mode=Thumb, size=None, cc=None
i32 candidate_04b46e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4b491, offset=0x4b490, mode=Thumb, size=None, cc=None
i32 candidate_04b490(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4b4db, offset=0x4b4da, mode=Thumb, size=None, cc=None
i32 candidate_04b4da(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4b4ef, offset=0x4b4ee, mode=Thumb, size=None, cc=None
i32 candidate_04b4ee(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4b743, offset=0x4b742, mode=Thumb, size=None, cc=None
i32 candidate_04b742(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4b775, offset=0x4b774, mode=Thumb, size=None, cc=None
i32 candidate_04b774(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4b86d, offset=0x4b86c, mode=Thumb, size=None, cc=None
i32 candidate_04b86c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4b965, offset=0x4b964, mode=Thumb, size=None, cc=None
i32 candidate_04b964(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4b9ad, offset=0x4b9ac, mode=Thumb, size=None, cc=None
i32 candidate_04b9ac(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4b9d3, offset=0x4b9d2, mode=Thumb, size=None, cc=None
i32 candidate_04b9d2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4bc11, offset=0x4bc10, mode=Thumb, size=None, cc=None
i32 candidate_04bc10(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4bc51, offset=0x4bc50, mode=Thumb, size=None, cc=None
i32 candidate_04bc50(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4bca9, offset=0x4bca8, mode=Thumb, size=None, cc=None
i32 candidate_04bca8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4bcaf, offset=0x4bcae, mode=Thumb, size=None, cc=None
i32 candidate_04bcae(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4bcf9, offset=0x4bcf8, mode=Thumb, size=None, cc=None
i32 candidate_04bcf8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4bd31, offset=0x4bd30, mode=Thumb, size=None, cc=None
i32 candidate_04bd30(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4bd7b, offset=0x4bd7a, mode=Thumb, size=None, cc=None
i32 candidate_04bd7a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4bdfb, offset=0x4bdfa, mode=Thumb, size=None, cc=None
i32 candidate_04bdfa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4bec5, offset=0x4bec4, mode=Thumb, size=None, cc=None
i32 candidate_04bec4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4bfe3, offset=0x4bfe2, mode=Thumb, size=None, cc=None
i32 candidate_04bfe2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4bfeb, offset=0x4bfea, mode=Thumb, size=None, cc=None
i32 candidate_04bfea(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4c5fb, offset=0x4c5fa, mode=Thumb, size=None, cc=None
i32 candidate_04c5fa(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4c707, offset=0x4c706, mode=Thumb, size=None, cc=None
i32 candidate_04c706(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4c71d, offset=0x4c71c, mode=Thumb, size=None, cc=None
i32 candidate_04c71c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4c8b3, offset=0x4c8b2, mode=Thumb, size=None, cc=None
i32 candidate_04c8b2(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ca6d, offset=0x4ca6c, mode=Thumb, size=None, cc=None
i32 candidate_04ca6c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ca7f, offset=0x4ca7e, mode=Thumb, size=None, cc=None
i32 candidate_04ca7e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4cb8b, offset=0x4cb8a, mode=Thumb, size=None, cc=None
i32 candidate_04cb8a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ce15, offset=0x4ce14, mode=Thumb, size=None, cc=None
i32 candidate_04ce14(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ff81, offset=0x4ff80, mode=Thumb, size=None, cc=None
i32 candidate_04ff80(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ffc5, offset=0x4ffc4, mode=Thumb, size=None, cc=None
i32 candidate_04ffc4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5003d, offset=0x5003c, mode=Thumb, size=None, cc=None
i32 candidate_05003c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x500f9, offset=0x500f8, mode=Thumb, size=None, cc=None
i32 candidate_0500f8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5021f, offset=0x5021e, mode=Thumb, size=None, cc=None
i32 candidate_05021e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5031b, offset=0x5031a, mode=Thumb, size=None, cc=None
i32 candidate_05031a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

