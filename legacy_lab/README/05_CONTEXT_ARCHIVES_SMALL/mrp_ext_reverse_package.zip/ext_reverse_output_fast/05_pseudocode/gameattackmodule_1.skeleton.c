/* Skeleton recovered from function map for gameattackmodule_1. Fill bodies from 02_disassembly. */
typedef int i32;

// addr=0x0, offset=0x0, mode=ARM, size=8, cc=1
i32 sub_0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8, offset=0x8, mode=ARM, size=20, cc=1
i32 _start(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c, offset=0x1c, mode=ARM, size=4, cc=1
i32 sub_1c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20, offset=0x20, mode=ARM, size=280, cc=7
i32 sub_20(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf4, offset=0xf4, mode=ARM, size=4, cc=1
i32 sub_f4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x109, offset=0x108, mode=Thumb, size=2, cc=1
i32 sub_109(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10b, offset=0x10a, mode=Thumb, size=2, cc=1
i32 sub_10b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x135, offset=0x134, mode=Thumb, size=58, cc=3
i32 sub_135(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x177, offset=0x176, mode=Thumb, size=6, cc=1
i32 sub_177(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18d, offset=0x18c, mode=Thumb, size=8, cc=1
i32 sub_18d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x195, offset=0x194, mode=Thumb, size=150, cc=18
i32 sub_195(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x249, offset=0x248, mode=Thumb, size=106, cc=1
i32 sub_249(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b5, offset=0x2b4, mode=Thumb, size=18, cc=1
i32 sub_2b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c8, offset=0x2c8, mode=ARM, size=16, cc=1
i32 sub_2c8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d8, offset=0x2d8, mode=ARM, size=8, cc=1
i32 sub_2d8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e0, offset=0x2e0, mode=ARM, size=8, cc=1
i32 sub_2e0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e9, offset=0x2e8, mode=Thumb, size=270, cc=18
i32 sub_2e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3f9, offset=0x3f8, mode=Thumb, size=4, cc=1
i32 sub_3f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3fd, offset=0x3fc, mode=Thumb, size=764, cc=40
i32 sub_3fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x715, offset=0x714, mode=Thumb, size=12, cc=1
i32 sub_715(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x721, offset=0x720, mode=Thumb, size=402, cc=22
i32 sub_721(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8d5, offset=0x8d4, mode=Thumb, size=670, cc=39
i32 sub_8d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8db, offset=0x8da, mode=Thumb, size=2, cc=1
i32 sub_8db(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8dc, offset=0x8dc, mode=ARM, size=28, cc=1
i32 sub_8dc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8f9, offset=0x8f8, mode=Thumb, size=4, cc=1
i32 sub_8f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8fc, offset=0x8fc, mode=ARM, size=28, cc=1
i32 sub_8fc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x919, offset=0x918, mode=Thumb, size=4, cc=1
i32 sub_919(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x91c, offset=0x91c, mode=ARM, size=28, cc=1
i32 sub_91c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x939, offset=0x938, mode=Thumb, size=4, cc=1
i32 sub_939(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x93d, offset=0x93c, mode=Thumb, size=182, cc=3
i32 sub_93d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9f5, offset=0x9f4, mode=Thumb, size=16, cc=1
i32 sub_9f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa05, offset=0xa04, mode=Thumb, size=146, cc=8
i32 sub_a05(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa99, offset=0xa98, mode=Thumb, size=82, cc=10
i32 sub_a99(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaf1, offset=0xaf0, mode=Thumb, size=4, cc=1
i32 sub_af1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaf5, offset=0xaf4, mode=Thumb, size=186, cc=14
i32 sub_af5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xbb1, offset=0xbb0, mode=Thumb, size=4, cc=1
i32 sub_bb1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xbb5, offset=0xbb4, mode=Thumb, size=168, cc=13
i32 sub_bb5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xc5d, offset=0xc5c, mode=Thumb, size=4, cc=1
i32 sub_c5d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xc61, offset=0xc60, mode=Thumb, size=142, cc=8
i32 sub_c61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xcf1, offset=0xcf0, mode=Thumb, size=4, cc=1
i32 sub_cf1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xcf5, offset=0xcf4, mode=Thumb, size=14, cc=1
i32 sub_cf5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xfb5, offset=0xfb4, mode=Thumb, size=4, cc=1
i32 sub_fb5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xfb9, offset=0xfb8, mode=Thumb, size=102, cc=5
i32 sub_fb9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1021, offset=0x1020, mode=Thumb, size=8, cc=1
i32 sub_1021(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1029, offset=0x1028, mode=Thumb, size=98, cc=3
i32 sub_1029(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x108d, offset=0x108c, mode=Thumb, size=4, cc=1
i32 sub_108d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1091, offset=0x1090, mode=Thumb, size=126, cc=7
i32 sub_1091(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1111, offset=0x1110, mode=Thumb, size=4, cc=1
i32 sub_1111(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1115, offset=0x1114, mode=Thumb, size=278, cc=13
i32 sub_1115(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1245, offset=0x1244, mode=Thumb, size=96, cc=7
i32 sub_1245(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x12a5, offset=0x12a4, mode=Thumb, size=4, cc=1
i32 sub_12a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x12a9, offset=0x12a8, mode=Thumb, size=164, cc=6
i32 sub_12a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x134d, offset=0x134c, mode=Thumb, size=4, cc=1
i32 sub_134d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1351, offset=0x1350, mode=Thumb, size=118, cc=4
i32 sub_1351(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13c9, offset=0x13c8, mode=Thumb, size=4, cc=1
i32 sub_13c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13cd, offset=0x13cc, mode=Thumb, size=112, cc=4
i32 sub_13cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x143d, offset=0x143c, mode=Thumb, size=4, cc=0
i32 sub_143d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1441, offset=0x1440, mode=Thumb, size=108, cc=4
i32 sub_1441(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14ad, offset=0x14ac, mode=Thumb, size=434, cc=19
i32 sub_14ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1661, offset=0x1660, mode=Thumb, size=4, cc=1
i32 sub_1661(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1665, offset=0x1664, mode=Thumb, size=76, cc=3
i32 sub_1665(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16b1, offset=0x16b0, mode=Thumb, size=46, cc=1
i32 sub_16b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16df, offset=0x16de, mode=Thumb, size=2, cc=1
i32 sub_16df(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16e1, offset=0x16e0, mode=Thumb, size=18, cc=2
i32 sub_16e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16f3, offset=0x16f2, mode=Thumb, size=34, cc=3
i32 sub_16f3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1715, offset=0x1714, mode=Thumb, size=42, cc=2
i32 sub_1715(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x173f, offset=0x173e, mode=Thumb, size=50, cc=3
i32 sub_173f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1771, offset=0x1770, mode=Thumb, size=44, cc=1
i32 sub_1771(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17a1, offset=0x17a0, mode=Thumb, size=12, cc=1
i32 sub_17a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17ad, offset=0x17ac, mode=Thumb, size=34, cc=1
i32 sub_17ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17cf, offset=0x17ce, mode=Thumb, size=18, cc=1
i32 sub_17cf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17e1, offset=0x17e0, mode=Thumb, size=18, cc=1
i32 sub_17e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17f3, offset=0x17f2, mode=Thumb, size=48, cc=2
i32 sub_17f3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1823, offset=0x1822, mode=Thumb, size=20, cc=1
i32 sub_1823(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1837, offset=0x1836, mode=Thumb, size=32, cc=1
i32 sub_1837(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1857, offset=0x1856, mode=Thumb, size=70, cc=3
i32 sub_1857(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1899, offset=0x1898, mode=Thumb, size=40, cc=2
i32 sub_1899(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18c1, offset=0x18c0, mode=Thumb, size=40, cc=2
i32 sub_18c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18e9, offset=0x18e8, mode=Thumb, size=20, cc=1
i32 sub_18e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18fd, offset=0x18fc, mode=Thumb, size=20, cc=1
i32 sub_18fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1911, offset=0x1910, mode=Thumb, size=28, cc=2
i32 sub_1911(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x192d, offset=0x192c, mode=Thumb, size=28, cc=2
i32 sub_192d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1949, offset=0x1948, mode=Thumb, size=12, cc=1
i32 sub_1949(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1955, offset=0x1954, mode=Thumb, size=18, cc=1
i32 sub_1955(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1969, offset=0x1968, mode=Thumb, size=8, cc=1
i32 sub_1969(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1971, offset=0x1970, mode=Thumb, size=1286, cc=74
i32 sub_1971(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1edd, offset=0x1edc, mode=Thumb, size=294, cc=14
i32 sub_1edd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2005, offset=0x2004, mode=Thumb, size=4, cc=1
i32 sub_2005(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2009, offset=0x2008, mode=Thumb, size=470, cc=23
i32 sub_2009(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21f9, offset=0x21f8, mode=Thumb, size=1076, cc=49
i32 sub_21f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x262d, offset=0x262c, mode=Thumb, size=462, cc=15
i32 sub_262d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x263d, offset=0x263c, mode=Thumb, size=4, cc=1
i32 sub_263d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2641, offset=0x2640, mode=Thumb, size=346, cc=17
i32 sub_2641(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27b1, offset=0x27b0, mode=Thumb, size=276, cc=14
i32 sub_27b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28c5, offset=0x28c4, mode=Thumb, size=8, cc=1
i32 sub_28c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28cd, offset=0x28cc, mode=Thumb, size=166, cc=9
i32 sub_28cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2975, offset=0x2974, mode=Thumb, size=4, cc=1
i32 sub_2975(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2979, offset=0x2978, mode=Thumb, size=204, cc=5
i32 sub_2979(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c05, offset=0x2c04, mode=Thumb, size=8, cc=1
i32 sub_2c05(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c0d, offset=0x2c0c, mode=Thumb, size=628, cc=20
i32 sub_2c0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e81, offset=0x2e80, mode=Thumb, size=8, cc=1
i32 sub_2e81(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e89, offset=0x2e88, mode=Thumb, size=662, cc=25
i32 sub_2e89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3121, offset=0x3120, mode=Thumb, size=8, cc=1
i32 sub_3121(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3129, offset=0x3128, mode=Thumb, size=1118, cc=51
i32 sub_3129(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34f9, offset=0x34f8, mode=Thumb, size=12, cc=1
i32 sub_34f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3595, offset=0x3594, mode=Thumb, size=12, cc=1
i32 sub_3595(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35a1, offset=0x35a0, mode=Thumb, size=504, cc=17
i32 sub_35a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3799, offset=0x3798, mode=Thumb, size=8, cc=1
i32 sub_3799(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37a1, offset=0x37a0, mode=Thumb, size=206, cc=6
i32 sub_37a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3871, offset=0x3870, mode=Thumb, size=8, cc=1
i32 sub_3871(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3879, offset=0x3878, mode=Thumb, size=550, cc=28
i32 sub_3879(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aa1, offset=0x3aa0, mode=Thumb, size=4, cc=1
i32 sub_3aa1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aa5, offset=0x3aa4, mode=Thumb, size=1376, cc=46
i32 sub_3aa5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4005, offset=0x4004, mode=Thumb, size=12, cc=1
i32 sub_4005(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4011, offset=0x4010, mode=Thumb, size=688, cc=31
i32 sub_4011(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x42c1, offset=0x42c0, mode=Thumb, size=4, cc=1
i32 sub_42c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x42c5, offset=0x42c4, mode=Thumb, size=186, cc=9
i32 sub_42c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4381, offset=0x4380, mode=Thumb, size=252, cc=24
i32 sub_4381(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x447d, offset=0x447c, mode=Thumb, size=396, cc=14
i32 sub_447d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4609, offset=0x4608, mode=Thumb, size=8, cc=1
i32 sub_4609(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4611, offset=0x4610, mode=Thumb, size=182, cc=7
i32 sub_4611(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x46c9, offset=0x46c8, mode=Thumb, size=4, cc=1
i32 sub_46c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x46cd, offset=0x46cc, mode=Thumb, size=316, cc=19
i32 sub_46cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4815, offset=0x4814, mode=Thumb, size=1782, cc=71
i32 sub_4815(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f1d, offset=0x4f1c, mode=Thumb, size=4, cc=1
i32 sub_4f1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f21, offset=0x4f20, mode=Thumb, size=352, cc=14
i32 sub_4f21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5081, offset=0x5080, mode=Thumb, size=4, cc=1
i32 sub_5081(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5085, offset=0x5084, mode=Thumb, size=114, cc=4
i32 sub_5085(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x50f9, offset=0x50f8, mode=Thumb, size=416, cc=15
i32 sub_50f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5299, offset=0x5298, mode=Thumb, size=8, cc=1
i32 sub_5299(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x52a1, offset=0x52a0, mode=Thumb, size=562, cc=20
i32 sub_52a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x54d5, offset=0x54d4, mode=Thumb, size=8, cc=1
i32 sub_54d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x54dd, offset=0x54dc, mode=Thumb, size=650, cc=25
i32 sub_54dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5769, offset=0x5768, mode=Thumb, size=8, cc=1
i32 sub_5769(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5771, offset=0x5770, mode=Thumb, size=166, cc=4
i32 sub_5771(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5819, offset=0x5818, mode=Thumb, size=4, cc=1
i32 sub_5819(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x581d, offset=0x581c, mode=Thumb, size=118, cc=6
i32 sub_581d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5895, offset=0x5894, mode=Thumb, size=4, cc=1
i32 sub_5895(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5899, offset=0x5898, mode=Thumb, size=142, cc=7
i32 sub_5899(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5929, offset=0x5928, mode=Thumb, size=4, cc=1
i32 sub_5929(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x592d, offset=0x592c, mode=Thumb, size=1594, cc=80
i32 sub_592d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5d61, offset=0x5d60, mode=Thumb, size=4, cc=1
i32 sub_5d61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5f6d, offset=0x5f6c, mode=Thumb, size=92, cc=3
i32 sub_5f6d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5fc1, offset=0x5fc0, mode=Thumb, size=68, cc=1
i32 sub_5fc1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6009, offset=0x6008, mode=Thumb, size=36, cc=3
i32 sub_6009(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x602d, offset=0x602c, mode=Thumb, size=44, cc=4
i32 sub_602d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6059, offset=0x6058, mode=Thumb, size=8, cc=1
i32 sub_6059(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6061, offset=0x6060, mode=Thumb, size=10, cc=1
i32 sub_6061(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x606b, offset=0x606a, mode=Thumb, size=10, cc=1
i32 sub_606b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6075, offset=0x6074, mode=Thumb, size=10, cc=1
i32 sub_6075(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x607f, offset=0x607e, mode=Thumb, size=8, cc=1
i32 sub_607f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6087, offset=0x6086, mode=Thumb, size=8, cc=1
i32 sub_6087(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x608f, offset=0x608e, mode=Thumb, size=8, cc=1
i32 sub_608f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6097, offset=0x6096, mode=Thumb, size=10, cc=1
i32 sub_6097(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x60a1, offset=0x60a0, mode=Thumb, size=8, cc=1
i32 sub_60a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x60a9, offset=0x60a8, mode=Thumb, size=10, cc=1
i32 sub_60a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x60b3, offset=0x60b2, mode=Thumb, size=54, cc=2
i32 sub_60b3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x60e9, offset=0x60e8, mode=Thumb, size=8, cc=1
i32 sub_60e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x60f1, offset=0x60f0, mode=Thumb, size=8, cc=1
i32 sub_60f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x60f9, offset=0x60f8, mode=Thumb, size=14, cc=1
i32 sub_60f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6107, offset=0x6106, mode=Thumb, size=36, cc=4
i32 sub_6107(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x612b, offset=0x612a, mode=Thumb, size=8, cc=1
i32 sub_612b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6133, offset=0x6132, mode=Thumb, size=8, cc=1
i32 sub_6133(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x613b, offset=0x613a, mode=Thumb, size=26, cc=1
i32 sub_613b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6155, offset=0x6154, mode=Thumb, size=10, cc=1
i32 sub_6155(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x615f, offset=0x615e, mode=Thumb, size=8, cc=1
i32 sub_615f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6167, offset=0x6166, mode=Thumb, size=10, cc=1
i32 sub_6167(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6171, offset=0x6170, mode=Thumb, size=10, cc=1
i32 sub_6171(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x617b, offset=0x617a, mode=Thumb, size=8, cc=1
i32 sub_617b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6183, offset=0x6182, mode=Thumb, size=8, cc=1
i32 sub_6183(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x618b, offset=0x618a, mode=Thumb, size=22, cc=1
i32 sub_618b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x61a1, offset=0x61a0, mode=Thumb, size=22, cc=1
i32 sub_61a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x61b7, offset=0x61b6, mode=Thumb, size=10, cc=1
i32 sub_61b7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x61c1, offset=0x61c0, mode=Thumb, size=20, cc=1
i32 sub_61c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x61dd, offset=0x61dc, mode=Thumb, size=78, cc=4
i32 sub_61dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x61e9, offset=0x61e8, mode=Thumb, size=8, cc=1
i32 sub_61e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x61f1, offset=0x61f0, mode=Thumb, size=58, cc=3
i32 sub_61f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x622d, offset=0x622c, mode=Thumb, size=56, cc=2
i32 sub_622d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6265, offset=0x6264, mode=Thumb, size=4, cc=1
i32 sub_6265(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6269, offset=0x6268, mode=Thumb, size=64, cc=1
i32 sub_6269(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x62a9, offset=0x62a8, mode=Thumb, size=4, cc=1
i32 sub_62a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x62ad, offset=0x62ac, mode=Thumb, size=16, cc=1
i32 sub_62ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x62bd, offset=0x62bc, mode=Thumb, size=4, cc=1
i32 sub_62bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x62c1, offset=0x62c0, mode=Thumb, size=174, cc=11
i32 sub_62c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6379, offset=0x6378, mode=Thumb, size=4, cc=1
i32 sub_6379(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x637d, offset=0x637c, mode=Thumb, size=68, cc=4
i32 sub_637d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x63c1, offset=0x63c0, mode=Thumb, size=256, cc=13
i32 sub_63c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x64c1, offset=0x64c0, mode=Thumb, size=86, cc=4
i32 sub_64c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6519, offset=0x6518, mode=Thumb, size=4, cc=1
i32 sub_6519(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x651d, offset=0x651c, mode=Thumb, size=68, cc=2
i32 sub_651d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6561, offset=0x6560, mode=Thumb, size=4, cc=1
i32 sub_6561(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6565, offset=0x6564, mode=Thumb, size=166, cc=6
i32 sub_6565(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6651, offset=0x6650, mode=Thumb, size=164, cc=6
i32 sub_6651(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x66f5, offset=0x66f4, mode=Thumb, size=4, cc=1
i32 sub_66f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x66f9, offset=0x66f8, mode=Thumb, size=134, cc=3
i32 sub_66f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6781, offset=0x6780, mode=Thumb, size=1888, cc=91
i32 sub_6781(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6f2d, offset=0x6f2c, mode=Thumb, size=1164, cc=51
i32 sub_6f2d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7331, offset=0x7330, mode=Thumb, size=16, cc=1
i32 sub_7331(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x73cd, offset=0x73cc, mode=Thumb, size=4, cc=1
i32 sub_73cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x73d1, offset=0x73d0, mode=Thumb, size=132, cc=5
i32 sub_73d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7455, offset=0x7454, mode=Thumb, size=8, cc=1
i32 sub_7455(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x745d, offset=0x745c, mode=Thumb, size=342, cc=14
i32 sub_745d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x75c5, offset=0x75c4, mode=Thumb, size=76, cc=3
i32 sub_75c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7611, offset=0x7610, mode=Thumb, size=8, cc=1
i32 sub_7611(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7619, offset=0x7618, mode=Thumb, size=96, cc=3
i32 sub_7619(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7679, offset=0x7678, mode=Thumb, size=4, cc=1
i32 sub_7679(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x767d, offset=0x767c, mode=Thumb, size=90, cc=4
i32 sub_767d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x76d9, offset=0x76d8, mode=Thumb, size=4, cc=1
i32 sub_76d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x76dd, offset=0x76dc, mode=Thumb, size=90, cc=4
i32 sub_76dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7739, offset=0x7738, mode=Thumb, size=4, cc=1
i32 sub_7739(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x773d, offset=0x773c, mode=Thumb, size=52, cc=2
i32 sub_773d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7771, offset=0x7770, mode=Thumb, size=38, cc=1
i32 sub_7771(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7799, offset=0x7798, mode=Thumb, size=20, cc=2
i32 sub_7799(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x77ad, offset=0x77ac, mode=Thumb, size=248, cc=9
i32 sub_77ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x78a5, offset=0x78a4, mode=Thumb, size=4, cc=1
i32 sub_78a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x78a9, offset=0x78a8, mode=Thumb, size=124, cc=4
i32 sub_78a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7939, offset=0x7938, mode=Thumb, size=80, cc=5
i32 sub_7939(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7989, offset=0x7988, mode=Thumb, size=188, cc=9
i32 sub_7989(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7a45, offset=0x7a44, mode=Thumb, size=114, cc=6
i32 sub_7a45(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7ac9, offset=0x7ac8, mode=Thumb, size=46, cc=2
i32 sub_7ac9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7af9, offset=0x7af8, mode=Thumb, size=8, cc=1
i32 sub_7af9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7b01, offset=0x7b00, mode=Thumb, size=62, cc=4
i32 sub_7b01(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7b41, offset=0x7b40, mode=Thumb, size=76, cc=5
i32 sub_7b41(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7b8d, offset=0x7b8c, mode=Thumb, size=4, cc=1
i32 sub_7b8d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7b91, offset=0x7b90, mode=Thumb, size=474, cc=24
i32 sub_7b91(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7d6d, offset=0x7d6c, mode=Thumb, size=8, cc=1
i32 sub_7d6d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7d75, offset=0x7d74, mode=Thumb, size=68, cc=1
i32 sub_7d75(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7db9, offset=0x7db8, mode=Thumb, size=118, cc=6
i32 sub_7db9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7e35, offset=0x7e34, mode=Thumb, size=12, cc=1
i32 sub_7e35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7e41, offset=0x7e40, mode=Thumb, size=66, cc=1
i32 sub_7e41(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7e89, offset=0x7e88, mode=Thumb, size=4, cc=1
i32 sub_7e89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7e8d, offset=0x7e8c, mode=Thumb, size=4, cc=1
i32 sub_7e8d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7e91, offset=0x7e90, mode=Thumb, size=52, cc=1
i32 sub_7e91(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7ec5, offset=0x7ec4, mode=Thumb, size=40, cc=1
i32 sub_7ec5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7eed, offset=0x7eec, mode=Thumb, size=42, cc=1
i32 sub_7eed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7f1d, offset=0x7f1c, mode=Thumb, size=14, cc=1
i32 sub_7f1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7f31, offset=0x7f30, mode=Thumb, size=70, cc=2
i32 sub_7f31(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7f79, offset=0x7f78, mode=Thumb, size=2, cc=1
i32 sub_7f79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7f7d, offset=0x7f7c, mode=Thumb, size=46, cc=1
i32 sub_7f7d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7f7f, offset=0x7f7e, mode=Thumb, size=18, cc=1
i32 sub_7f7f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7f91, offset=0x7f90, mode=Thumb, size=4, cc=1
i32 sub_7f91(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7f95, offset=0x7f94, mode=Thumb, size=110, cc=11
i32 sub_7f95(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7fcb, offset=0x7fca, mode=Thumb, size=24, cc=1
i32 sub_7fcb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8029, offset=0x8028, mode=Thumb, size=54, cc=2
i32 sub_8029(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8061, offset=0x8060, mode=Thumb, size=4, cc=1
i32 sub_8061(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8065, offset=0x8064, mode=Thumb, size=90, cc=10
i32 sub_8065(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x80c1, offset=0x80c0, mode=Thumb, size=4, cc=1
i32 sub_80c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x80c5, offset=0x80c4, mode=Thumb, size=276, cc=24
i32 sub_80c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x81f1, offset=0x81f0, mode=Thumb, size=44, cc=3
i32 sub_81f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x821d, offset=0x821c, mode=Thumb, size=8, cc=1
i32 sub_821d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8225, offset=0x8224, mode=Thumb, size=216, cc=18
i32 sub_8225(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8309, offset=0x8308, mode=Thumb, size=128, cc=4
i32 sub_8309(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x83b5, offset=0x83b4, mode=Thumb, size=142, cc=7
i32 sub_83b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8445, offset=0x8444, mode=Thumb, size=196, cc=8
i32 sub_8445(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8509, offset=0x8508, mode=Thumb, size=100, cc=3
i32 sub_8509(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x856d, offset=0x856c, mode=Thumb, size=326, cc=12
i32 sub_856d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x86b5, offset=0x86b4, mode=Thumb, size=202, cc=8
i32 sub_86b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8781, offset=0x8780, mode=Thumb, size=202, cc=8
i32 sub_8781(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x884d, offset=0x884c, mode=Thumb, size=104, cc=3
i32 sub_884d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x88b5, offset=0x88b4, mode=Thumb, size=94, cc=3
i32 sub_88b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8915, offset=0x8914, mode=Thumb, size=200, cc=10
i32 sub_8915(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x89dd, offset=0x89dc, mode=Thumb, size=4, cc=1
i32 sub_89dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x89e1, offset=0x89e0, mode=Thumb, size=112, cc=5
i32 sub_89e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8a51, offset=0x8a50, mode=Thumb, size=338, cc=16
i32 sub_8a51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8ba5, offset=0x8ba4, mode=Thumb, size=1096, cc=51
i32 sub_8ba5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8fed, offset=0x8fec, mode=Thumb, size=392, cc=14
i32 sub_8fed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9175, offset=0x9174, mode=Thumb, size=590, cc=34
i32 sub_9175(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x93c5, offset=0x93c4, mode=Thumb, size=90, cc=6
i32 sub_93c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9421, offset=0x9420, mode=Thumb, size=134, cc=7
i32 sub_9421(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x94a9, offset=0x94a8, mode=Thumb, size=4, cc=1
i32 sub_94a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x94ad, offset=0x94ac, mode=Thumb, size=72, cc=2
i32 sub_94ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x94f5, offset=0x94f4, mode=Thumb, size=118, cc=4
i32 sub_94f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x956d, offset=0x956c, mode=Thumb, size=4, cc=1
i32 sub_956d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9571, offset=0x9570, mode=Thumb, size=78, cc=4
i32 sub_9571(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x95c1, offset=0x95c0, mode=Thumb, size=4, cc=1
i32 sub_95c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x95c5, offset=0x95c4, mode=Thumb, size=750, cc=45
i32 sub_95c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x98b5, offset=0x98b4, mode=Thumb, size=102, cc=5
i32 sub_98b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x991d, offset=0x991c, mode=Thumb, size=4, cc=1
i32 sub_991d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9921, offset=0x9920, mode=Thumb, size=46, cc=2
i32 sub_9921(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9951, offset=0x9950, mode=Thumb, size=4, cc=1
i32 sub_9951(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9955, offset=0x9954, mode=Thumb, size=156, cc=6
i32 sub_9955(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x99f1, offset=0x99f0, mode=Thumb, size=4, cc=1
i32 sub_99f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x99f5, offset=0x99f4, mode=Thumb, size=94, cc=5
i32 sub_99f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9a55, offset=0x9a54, mode=Thumb, size=254, cc=10
i32 sub_9a55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9b55, offset=0x9b54, mode=Thumb, size=336, cc=16
i32 sub_9b55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9ca5, offset=0x9ca4, mode=Thumb, size=230, cc=9
i32 sub_9ca5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d8d, offset=0x9d8c, mode=Thumb, size=206, cc=8
i32 sub_9d8d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9e5d, offset=0x9e5c, mode=Thumb, size=278, cc=11
i32 sub_9e5d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9f75, offset=0x9f74, mode=Thumb, size=186, cc=7
i32 sub_9f75(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa031, offset=0xa030, mode=Thumb, size=4, cc=1
i32 sub_a031(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa035, offset=0xa034, mode=Thumb, size=156, cc=6
i32 sub_a035(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa0d1, offset=0xa0d0, mode=Thumb, size=66, cc=5
i32 sub_a0d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa115, offset=0xa114, mode=Thumb, size=18, cc=2
i32 sub_a115(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa129, offset=0xa128, mode=Thumb, size=4, cc=1
i32 sub_a129(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa12d, offset=0xa12c, mode=Thumb, size=120, cc=4
i32 sub_a12d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa1a5, offset=0xa1a4, mode=Thumb, size=68, cc=4
i32 sub_a1a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa1e9, offset=0xa1e8, mode=Thumb, size=112, cc=4
i32 sub_a1e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa259, offset=0xa258, mode=Thumb, size=8, cc=1
i32 sub_a259(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa261, offset=0xa260, mode=Thumb, size=68, cc=3
i32 sub_a261(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa2a5, offset=0xa2a4, mode=Thumb, size=96, cc=3
i32 sub_a2a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa305, offset=0xa304, mode=Thumb, size=496, cc=34
i32 sub_a305(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa4f5, offset=0xa4f4, mode=Thumb, size=8, cc=1
i32 sub_a4f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa4fd, offset=0xa4fc, mode=Thumb, size=260, cc=15
i32 sub_a4fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa601, offset=0xa600, mode=Thumb, size=8, cc=1
i32 sub_a601(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa609, offset=0xa608, mode=Thumb, size=96, cc=8
i32 sub_a609(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa669, offset=0xa668, mode=Thumb, size=4, cc=1
i32 sub_a669(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa66d, offset=0xa66c, mode=Thumb, size=138, cc=7
i32 sub_a66d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa6f9, offset=0xa6f8, mode=Thumb, size=4, cc=1
i32 sub_a6f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa6fd, offset=0xa6fc, mode=Thumb, size=244, cc=15
i32 sub_a6fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa7f1, offset=0xa7f0, mode=Thumb, size=4, cc=1
i32 sub_a7f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa7f5, offset=0xa7f4, mode=Thumb, size=256, cc=18
i32 sub_a7f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa8f5, offset=0xa8f4, mode=Thumb, size=4, cc=1
i32 sub_a8f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa8f9, offset=0xa8f8, mode=Thumb, size=160, cc=8
i32 sub_a8f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa999, offset=0xa998, mode=Thumb, size=4, cc=1
i32 sub_a999(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa99d, offset=0xa99c, mode=Thumb, size=298, cc=15
i32 sub_a99d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaac9, offset=0xaac8, mode=Thumb, size=4, cc=1
i32 sub_aac9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaacd, offset=0xaacc, mode=Thumb, size=396, cc=12
i32 sub_aacd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xab79, offset=0xab78, mode=Thumb, size=80, cc=2
i32 sub_ab79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaca9, offset=0xaca8, mode=Thumb, size=4, cc=1
i32 sub_aca9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xacad, offset=0xacac, mode=Thumb, size=112, cc=9
i32 sub_acad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xad1d, offset=0xad1c, mode=Thumb, size=4, cc=1
i32 sub_ad1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xad21, offset=0xad20, mode=Thumb, size=310, cc=17
i32 sub_ad21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae59, offset=0xae58, mode=Thumb, size=4, cc=1
i32 sub_ae59(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae5d, offset=0xae5c, mode=Thumb, size=280, cc=11
i32 sub_ae5d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaed1, offset=0xaed0, mode=Thumb, size=22, cc=1
i32 sub_aed1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaf8b, offset=0xaf8a, mode=Thumb, size=2, cc=1
i32 sub_af8b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaf8d, offset=0xaf8c, mode=Thumb, size=4, cc=1
i32 sub_af8d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaf91, offset=0xaf90, mode=Thumb, size=180, cc=11
i32 sub_af91(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb04f, offset=0xb04e, mode=Thumb, size=6, cc=1
i32 sub_b04f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb054, offset=0xb054, mode=ARM, size=8, cc=1
i32 sub_b054(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb070, offset=0xb070, mode=ARM, size=4, cc=1
i32 sub_b070(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb0ed, offset=0xb0ec, mode=Thumb, size=6, cc=1
i32 sub_b0ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb0f8, offset=0xb0f8, mode=ARM, size=4, cc=1
i32 sub_b0f8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb119, offset=0xb118, mode=Thumb, size=2, cc=1
i32 sub_b119(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb11c, offset=0xb11c, mode=ARM, size=4, cc=1
i32 sub_b11c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb139, offset=0xb138, mode=Thumb, size=8, cc=1
i32 sub_b139(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb141, offset=0xb140, mode=Thumb, size=6, cc=1
i32 sub_b141(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb177, offset=0xb176, mode=Thumb, size=4, cc=1
i32 sub_b177(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb17d, offset=0xb17c, mode=Thumb, size=10, cc=1
i32 sub_b17d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb193, offset=0xb192, mode=Thumb, size=2, cc=1
i32 sub_b193(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb19b, offset=0xb19a, mode=Thumb, size=4, cc=1
i32 sub_b19b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb1d1, offset=0xb1d0, mode=Thumb, size=6, cc=1
i32 sub_b1d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb1e9, offset=0xb1e8, mode=Thumb, size=2, cc=1
i32 sub_b1e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb1ed, offset=0xb1ec, mode=Thumb, size=2, cc=1
i32 sub_b1ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb1f0, offset=0xb1f0, mode=ARM, size=4, cc=1
i32 sub_b1f0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb208, offset=0xb208, mode=ARM, size=4, cc=1
i32 sub_b208(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb20c, offset=0xb20c, mode=ARM, size=12, cc=1
i32 sub_b20c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb23c, offset=0xb23c, mode=ARM, size=4, cc=1
i32 sub_b23c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb240, offset=0xb240, mode=ARM, size=8, cc=1
i32 sub_b240(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb274, offset=0xb274, mode=ARM, size=8, cc=1
i32 sub_b274(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb2b3, offset=0xb2b2, mode=Thumb, size=2, cc=1
i32 sub_b2b3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb2cc, offset=0xb2cc, mode=ARM, size=16, cc=1
i32 sub_b2cc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb2e1, offset=0xb2e0, mode=Thumb, size=0, cc=1
i32 sub_b2e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb2f0, offset=0xb2f0, mode=ARM, size=8, cc=1
i32 sub_b2f0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb308, offset=0xb308, mode=ARM, size=4, cc=1
i32 sub_b308(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb30c, offset=0xb30c, mode=ARM, size=8, cc=1
i32 sub_b30c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb317, offset=0xb316, mode=Thumb, size=2, cc=1
i32 sub_b317(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb321, offset=0xb320, mode=Thumb, size=12, cc=1
i32 sub_b321(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb325, offset=0xb324, mode=Thumb, size=8, cc=1
i32 sub_b325(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb339, offset=0xb338, mode=Thumb, size=14, cc=1
i32 sub_b339(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb35f, offset=0xb35e, mode=Thumb, size=12, cc=1
i32 sub_b35f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb36d, offset=0xb36c, mode=Thumb, size=4, cc=1
i32 sub_b36d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb377, offset=0xb376, mode=Thumb, size=2, cc=1
i32 sub_b377(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb381, offset=0xb380, mode=Thumb, size=10, cc=1
i32 sub_b381(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb383, offset=0xb382, mode=Thumb, size=8, cc=1
i32 sub_b383(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x100014, offset=0x100014, mode=ARM, size=0, cc=1
i32 UnresolvableJumpTarget(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x100018, offset=0x100018, mode=ARM, size=0, cc=1
i32 UnresolvableCallTarget(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

