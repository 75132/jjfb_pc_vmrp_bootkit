/* Skeleton recovered from function map for shopmodule. Fill bodies from 02_disassembly. */
typedef int i32;

// addr=0x0, offset=0x0, mode=ARM, size=8, cc=1
i32 sub_0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8, offset=0x8, mode=ARM, size=20, cc=1
i32 _start(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c, offset=0x1c, mode=ARM, size=4, cc=1
i32 sub_1c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20, offset=0x20, mode=ARM, size=290, cc=11
i32 sub_20(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c, offset=0x2c, mode=ARM, size=4, cc=1
i32 sub_2c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30, offset=0x30, mode=ARM, size=212, cc=7
i32 sub_30(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x104, offset=0x104, mode=ARM, size=4, cc=1
i32 sub_104(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x119, offset=0x118, mode=Thumb, size=2, cc=1
i32 sub_119(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11b, offset=0x11a, mode=Thumb, size=2, cc=1
i32 sub_11b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x145, offset=0x144, mode=Thumb, size=58, cc=3
i32 sub_145(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x183, offset=0x182, mode=Thumb, size=10, cc=1
i32 sub_183(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19d, offset=0x19c, mode=Thumb, size=8, cc=1
i32 sub_19d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a5, offset=0x1a4, mode=Thumb, size=150, cc=18
i32 sub_1a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x241, offset=0x240, mode=Thumb, size=130, cc=1
i32 sub_241(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c5, offset=0x2c4, mode=Thumb, size=18, cc=1
i32 sub_2c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d8, offset=0x2d8, mode=ARM, size=16, cc=1
i32 sub_2d8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e8, offset=0x2e8, mode=ARM, size=8, cc=1
i32 sub_2e8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f0, offset=0x2f0, mode=ARM, size=8, cc=1
i32 sub_2f0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f8, offset=0x2f8, mode=ARM, size=28, cc=1
i32 sub_2f8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x315, offset=0x314, mode=Thumb, size=4, cc=1
i32 sub_315(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x318, offset=0x318, mode=ARM, size=28, cc=1
i32 sub_318(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x334, offset=0x334, mode=ARM, size=4, cc=1
i32 sub_334(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x339, offset=0x338, mode=Thumb, size=22, cc=1
i32 sub_339(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35b, offset=0x35a, mode=Thumb, size=148, cc=2
i32 sub_35b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3f1, offset=0x3f0, mode=Thumb, size=16, cc=1
i32 sub_3f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x401, offset=0x400, mode=Thumb, size=170, cc=8
i32 sub_401(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ad, offset=0x4ac, mode=Thumb, size=8, cc=1
i32 sub_4ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4b5, offset=0x4b4, mode=Thumb, size=84, cc=3
i32 sub_4b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x509, offset=0x508, mode=Thumb, size=4, cc=1
i32 sub_509(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x50d, offset=0x50c, mode=Thumb, size=312, cc=12
i32 sub_50d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x645, offset=0x644, mode=Thumb, size=4, cc=1
i32 sub_645(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x649, offset=0x648, mode=Thumb, size=194, cc=8
i32 sub_649(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x70d, offset=0x70c, mode=Thumb, size=4, cc=1
i32 sub_70d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x711, offset=0x710, mode=Thumb, size=394, cc=16
i32 sub_711(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x89d, offset=0x89c, mode=Thumb, size=4, cc=1
i32 sub_89d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8a1, offset=0x8a0, mode=Thumb, size=50, cc=1
i32 sub_8a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9b1, offset=0x9b0, mode=Thumb, size=1004, cc=48
i32 sub_9b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xda5, offset=0xda4, mode=Thumb, size=8, cc=1
i32 sub_da5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xdad, offset=0xdac, mode=Thumb, size=652, cc=26
i32 sub_dad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1039, offset=0x1038, mode=Thumb, size=4, cc=1
i32 sub_1039(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x103d, offset=0x103c, mode=Thumb, size=162, cc=6
i32 sub_103d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10e1, offset=0x10e0, mode=Thumb, size=4, cc=1
i32 sub_10e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10e5, offset=0x10e4, mode=Thumb, size=1010, cc=40
i32 sub_10e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14d9, offset=0x14d8, mode=Thumb, size=4, cc=1
i32 sub_14d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14dd, offset=0x14dc, mode=Thumb, size=1070, cc=43
i32 sub_14dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x191d, offset=0x191c, mode=Thumb, size=74, cc=3
i32 sub_191d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1969, offset=0x1968, mode=Thumb, size=38, cc=1
i32 sub_1969(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x198f, offset=0x198e, mode=Thumb, size=2, cc=1
i32 sub_198f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1991, offset=0x1990, mode=Thumb, size=292, cc=15
i32 sub_1991(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ab7, offset=0x1ab6, mode=Thumb, size=82, cc=3
i32 sub_1ab7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b0b, offset=0x1b0a, mode=Thumb, size=82, cc=3
i32 sub_1b0b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b5f, offset=0x1b5e, mode=Thumb, size=94, cc=4
i32 sub_1b5f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1bbb, offset=0x1bba, mode=Thumb, size=94, cc=4
i32 sub_1bbb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c17, offset=0x1c16, mode=Thumb, size=232, cc=12
i32 sub_1c17(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1cfc, offset=0x1cfc, mode=ARM, size=24, cc=1
i32 sub_1cfc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d14, offset=0x1d14, mode=ARM, size=8, cc=1
i32 sub_1d14(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d31, offset=0x1d30, mode=Thumb, size=878, cc=45
i32 sub_1d31(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20d5, offset=0x20d4, mode=Thumb, size=132, cc=6
i32 sub_20d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2159, offset=0x2158, mode=Thumb, size=162, cc=9
i32 sub_2159(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21fd, offset=0x21fc, mode=Thumb, size=46, cc=2
i32 sub_21fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2245, offset=0x2244, mode=Thumb, size=80, cc=4
i32 sub_2245(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2295, offset=0x2294, mode=Thumb, size=4, cc=1
i32 sub_2295(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2299, offset=0x2298, mode=Thumb, size=1138, cc=54
i32 sub_2299(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x273d, offset=0x273c, mode=Thumb, size=8, cc=1
i32 sub_273d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2745, offset=0x2744, mode=Thumb, size=230, cc=9
i32 sub_2745(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x282d, offset=0x282c, mode=Thumb, size=4, cc=1
i32 sub_282d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2831, offset=0x2830, mode=Thumb, size=88, cc=3
i32 sub_2831(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2889, offset=0x2888, mode=Thumb, size=4, cc=1
i32 sub_2889(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x288d, offset=0x288c, mode=Thumb, size=234, cc=18
i32 sub_288d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2979, offset=0x2978, mode=Thumb, size=8, cc=1
i32 sub_2979(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2981, offset=0x2980, mode=Thumb, size=24, cc=1
i32 sub_2981(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2998, offset=0x2998, mode=ARM, size=8, cc=1
i32 sub_2998(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29a0, offset=0x29a0, mode=ARM, size=20, cc=1
i32 sub_29a0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29bb, offset=0x29ba, mode=Thumb, size=60, cc=3
i32 sub_29bb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29fd, offset=0x29fc, mode=Thumb, size=12, cc=1
i32 sub_29fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2a09, offset=0x2a08, mode=Thumb, size=66, cc=1
i32 sub_2a09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2a51, offset=0x2a50, mode=Thumb, size=4, cc=1
i32 sub_2a51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2a55, offset=0x2a54, mode=Thumb, size=4, cc=1
i32 sub_2a55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2a59, offset=0x2a58, mode=Thumb, size=52, cc=1
i32 sub_2a59(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2a8f, offset=0x2a8e, mode=Thumb, size=38, cc=1
i32 sub_2a8f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ab5, offset=0x2ab4, mode=Thumb, size=88, cc=3
i32 sub_2ab5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ae5, offset=0x2ae4, mode=Thumb, size=14, cc=1
i32 sub_2ae5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2af9, offset=0x2af8, mode=Thumb, size=24, cc=1
i32 sub_2af9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b59, offset=0x2b58, mode=Thumb, size=4, cc=1
i32 sub_2b59(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b5d, offset=0x2b5c, mode=Thumb, size=126, cc=11
i32 sub_2b5d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b99, offset=0x2b98, mode=Thumb, size=8, cc=1
i32 sub_2b99(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bf1, offset=0x2bf0, mode=Thumb, size=54, cc=2
i32 sub_2bf1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c29, offset=0x2c28, mode=Thumb, size=4, cc=1
i32 sub_2c29(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c2d, offset=0x2c2c, mode=Thumb, size=90, cc=10
i32 sub_2c2d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c89, offset=0x2c88, mode=Thumb, size=4, cc=1
i32 sub_2c89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c8d, offset=0x2c8c, mode=Thumb, size=276, cc=24
i32 sub_2c8d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2db9, offset=0x2db8, mode=Thumb, size=44, cc=3
i32 sub_2db9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2de5, offset=0x2de4, mode=Thumb, size=216, cc=18
i32 sub_2de5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ded, offset=0x2dec, mode=Thumb, size=8, cc=1
i32 sub_2ded(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ec5, offset=0x2ec4, mode=Thumb, size=2, cc=1
i32 sub_2ec5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ecf, offset=0x2ece, mode=Thumb, size=2, cc=1
i32 sub_2ecf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ed1, offset=0x2ed0, mode=Thumb, size=256, cc=15
i32 sub_2ed1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fd1, offset=0x2fd0, mode=Thumb, size=4, cc=1
i32 sub_2fd1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fd5, offset=0x2fd4, mode=Thumb, size=514, cc=27
i32 sub_2fd5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31d9, offset=0x31d8, mode=Thumb, size=4, cc=1
i32 sub_31d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31dd, offset=0x31dc, mode=Thumb, size=254, cc=10
i32 sub_31dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32dd, offset=0x32dc, mode=Thumb, size=274, cc=20
i32 sub_32dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33e3, offset=0x33e2, mode=Thumb, size=6, cc=1
i32 sub_33e3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3417, offset=0x3416, mode=Thumb, size=8, cc=1
i32 sub_3417(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3427, offset=0x3426, mode=Thumb, size=8, cc=1
i32 sub_3427(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x342f, offset=0x342e, mode=Thumb, size=10, cc=1
i32 sub_342f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3437, offset=0x3436, mode=Thumb, size=6, cc=1
i32 sub_3437(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3474, offset=0x3474, mode=ARM, size=20, cc=1
i32 sub_3474(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3491, offset=0x3490, mode=Thumb, size=10, cc=1
i32 sub_3491(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3493, offset=0x3492, mode=Thumb, size=6, cc=1
i32 sub_3493(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3499, offset=0x3498, mode=Thumb, size=2, cc=1
i32 sub_3499(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34a1, offset=0x34a0, mode=Thumb, size=4, cc=1
i32 sub_34a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b4, offset=0x34b4, mode=ARM, size=4, cc=1
i32 sub_34b4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c1, offset=0x34c0, mode=Thumb, size=12, cc=1
i32 sub_34c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c5, offset=0x34c4, mode=Thumb, size=8, cc=1
i32 sub_34c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34ed, offset=0x34ec, mode=Thumb, size=2, cc=1
i32 sub_34ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34f4, offset=0x34f4, mode=ARM, size=4, cc=1
i32 sub_34f4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34f8, offset=0x34f8, mode=ARM, size=8, cc=1
i32 sub_34f8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3527, offset=0x3526, mode=Thumb, size=2, cc=1
i32 sub_3527(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3528, offset=0x3528, mode=ARM, size=4, cc=1
i32 sub_3528(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x353d, offset=0x353c, mode=Thumb, size=4, cc=1
i32 sub_353d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3550, offset=0x3550, mode=ARM, size=8, cc=1
i32 sub_3550(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x355d, offset=0x355c, mode=Thumb, size=4, cc=1
i32 sub_355d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3561, offset=0x3560, mode=Thumb, size=4, cc=1
i32 sub_3561(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3569, offset=0x3568, mode=Thumb, size=10, cc=1
i32 sub_3569(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x357c, offset=0x357c, mode=ARM, size=4, cc=1
i32 sub_357c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x358f, offset=0x358e, mode=Thumb, size=2, cc=1
i32 sub_358f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3591, offset=0x3590, mode=Thumb, size=738, cc=1
i32 sub_3591(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x359f, offset=0x359e, mode=Thumb, size=2, cc=1
i32 sub_359f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35a0, offset=0x35a0, mode=ARM, size=8, cc=1
i32 sub_35a0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35b1, offset=0x35b0, mode=Thumb, size=4, cc=1
i32 sub_35b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x100014, offset=0x100014, mode=ARM, size=0, cc=1
i32 UnresolvableJumpTarget(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x100018, offset=0x100018, mode=ARM, size=0, cc=1
i32 UnresolvableCallTarget(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1011a7, offset=0x1011a6, mode=Thumb, size=28250, cc=1
i32 sub_1011a7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

