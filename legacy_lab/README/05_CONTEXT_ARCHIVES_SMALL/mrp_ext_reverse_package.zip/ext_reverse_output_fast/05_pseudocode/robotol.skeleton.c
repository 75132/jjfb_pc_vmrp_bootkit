/* Skeleton recovered from function map for robotol. Fill bodies from 02_disassembly. */
typedef int i32;

// addr=0x0, offset=0x0, mode=ARM, size=8, cc=1
i32 sub_0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8, offset=0x8, mode=ARM, size=20, cc=1
i32 _start(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c, offset=0x1c, mode=ARM, size=4, cc=1
i32 sub_1c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20, offset=0x20, mode=ARM, size=68, cc=1
i32 sub_20(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c, offset=0x2c, mode=ARM, size=4, cc=1
i32 sub_2c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30, offset=0x30, mode=ARM, size=288, cc=12
i32 sub_30(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe4, offset=0xe4, mode=ARM, size=4, cc=1
i32 sub_e4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe8, offset=0xe8, mode=ARM, size=212, cc=7
i32 sub_e8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1bc, offset=0x1bc, mode=ARM, size=4, cc=1
i32 sub_1bc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c0, offset=0x1c0, mode=ARM, size=192, cc=7
i32 sub_1c0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x280, offset=0x280, mode=ARM, size=4, cc=1
i32 sub_280(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x290, offset=0x290, mode=ARM, size=4, cc=1
i32 sub_290(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x305, offset=0x304, mode=Thumb, size=2, cc=1
i32 sub_305(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x307, offset=0x306, mode=Thumb, size=2, cc=1
i32 sub_307(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x331, offset=0x330, mode=Thumb, size=58, cc=3
i32 sub_331(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36d, offset=0x36c, mode=Thumb, size=10, cc=1
i32 sub_36d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x389, offset=0x388, mode=Thumb, size=8, cc=1
i32 sub_389(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x391, offset=0x390, mode=Thumb, size=150, cc=18
i32 sub_391(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x42d, offset=0x42c, mode=Thumb, size=130, cc=2
i32 sub_42d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4b1, offset=0x4b0, mode=Thumb, size=18, cc=1
i32 sub_4b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4c4, offset=0x4c4, mode=ARM, size=16, cc=1
i32 sub_4c4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4d5, offset=0x4d4, mode=Thumb, size=62, cc=2
i32 sub_4d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4e1, offset=0x4e0, mode=Thumb, size=14, cc=1
i32 sub_4e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f1, offset=0x4f0, mode=Thumb, size=714, cc=59
i32 sub_4f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x80d, offset=0x80c, mode=Thumb, size=18, cc=1
i32 sub_80d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x851, offset=0x850, mode=Thumb, size=4, cc=1
i32 sub_851(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x855, offset=0x854, mode=Thumb, size=108, cc=8
i32 sub_855(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8c1, offset=0x8c0, mode=Thumb, size=8, cc=1
i32 sub_8c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8c9, offset=0x8c8, mode=Thumb, size=98, cc=8
i32 sub_8c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x92d, offset=0x92c, mode=Thumb, size=8, cc=1
i32 sub_92d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x934, offset=0x934, mode=ARM, size=28, cc=1
i32 sub_934(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x951, offset=0x950, mode=Thumb, size=4, cc=1
i32 sub_951(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x954, offset=0x954, mode=ARM, size=28, cc=1
i32 sub_954(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x971, offset=0x970, mode=Thumb, size=4, cc=1
i32 sub_971(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x974, offset=0x974, mode=ARM, size=28, cc=1
i32 sub_974(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x991, offset=0x990, mode=Thumb, size=8, cc=1
i32 sub_991(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x998, offset=0x998, mode=ARM, size=28, cc=1
i32 sub_998(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9b4, offset=0x9b4, mode=ARM, size=4, cc=1
i32 sub_9b4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9b8, offset=0x9b8, mode=ARM, size=32, cc=1
i32 sub_9b8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9e0, offset=0x9e0, mode=ARM, size=32, cc=1
i32 sub_9e0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa00, offset=0xa00, mode=ARM, size=4, cc=1
i32 sub_a00(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa04, offset=0xa04, mode=ARM, size=28, cc=1
i32 sub_a04(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa21, offset=0xa20, mode=Thumb, size=4, cc=1
i32 sub_a21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa24, offset=0xa24, mode=ARM, size=28, cc=1
i32 sub_a24(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa40, offset=0xa40, mode=ARM, size=4, cc=1
i32 sub_a40(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa44, offset=0xa44, mode=ARM, size=28, cc=1
i32 sub_a44(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa61, offset=0xa60, mode=Thumb, size=4, cc=1
i32 sub_a61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa64, offset=0xa64, mode=ARM, size=28, cc=1
i32 sub_a64(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa80, offset=0xa80, mode=ARM, size=4, cc=1
i32 sub_a80(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa84, offset=0xa84, mode=ARM, size=32, cc=1
i32 sub_a84(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaa4, offset=0xaa4, mode=ARM, size=4, cc=1
i32 sub_aa4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaa8, offset=0xaa8, mode=ARM, size=28, cc=1
i32 sub_aa8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xacc, offset=0xacc, mode=ARM, size=32, cc=1
i32 sub_acc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaed, offset=0xaec, mode=Thumb, size=4, cc=1
i32 sub_aed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaf1, offset=0xaf0, mode=Thumb, size=182, cc=3
i32 sub_af1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xba9, offset=0xba8, mode=Thumb, size=16, cc=1
i32 sub_ba9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xbb9, offset=0xbb8, mode=Thumb, size=300, cc=21
i32 sub_bb9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xd05, offset=0xd04, mode=Thumb, size=126, cc=6
i32 sub_d05(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xd9d, offset=0xd9c, mode=Thumb, size=60, cc=4
i32 sub_d9d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xdd9, offset=0xdd8, mode=Thumb, size=4, cc=1
i32 sub_dd9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xddd, offset=0xddc, mode=Thumb, size=120, cc=5
i32 sub_ddd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe55, offset=0xe54, mode=Thumb, size=12, cc=1
i32 sub_e55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe61, offset=0xe60, mode=Thumb, size=46, cc=3
i32 sub_e61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe91, offset=0xe90, mode=Thumb, size=4, cc=1
i32 sub_e91(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe95, offset=0xe94, mode=Thumb, size=46, cc=3
i32 sub_e95(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xec5, offset=0xec4, mode=Thumb, size=4, cc=1
i32 sub_ec5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xec9, offset=0xec8, mode=Thumb, size=86, cc=6
i32 sub_ec9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf31, offset=0xf30, mode=Thumb, size=202, cc=13
i32 sub_f31(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1025, offset=0x1024, mode=Thumb, size=280, cc=12
i32 sub_1025(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x115d, offset=0x115c, mode=Thumb, size=120, cc=3
i32 sub_115d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11e9, offset=0x11e8, mode=Thumb, size=2, cc=1
i32 sub_11e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11ed, offset=0x11ec, mode=Thumb, size=78, cc=2
i32 sub_11ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x124d, offset=0x124c, mode=Thumb, size=54, cc=5
i32 sub_124d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1285, offset=0x1284, mode=Thumb, size=188, cc=13
i32 sub_1285(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1341, offset=0x1340, mode=Thumb, size=4, cc=1
i32 sub_1341(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1345, offset=0x1344, mode=Thumb, size=56, cc=2
i32 sub_1345(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x137d, offset=0x137c, mode=Thumb, size=4, cc=1
i32 sub_137d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1381, offset=0x1380, mode=Thumb, size=134, cc=12
i32 sub_1381(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1409, offset=0x1408, mode=Thumb, size=192, cc=17
i32 sub_1409(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14c9, offset=0x14c8, mode=Thumb, size=142, cc=5
i32 sub_14c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1559, offset=0x1558, mode=Thumb, size=40, cc=2
i32 sub_1559(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1581, offset=0x1580, mode=Thumb, size=30, cc=2
i32 sub_1581(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15a1, offset=0x15a0, mode=Thumb, size=4, cc=1
i32 sub_15a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15a5, offset=0x15a4, mode=Thumb, size=34, cc=1
i32 sub_15a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15c9, offset=0x15c8, mode=Thumb, size=12, cc=1
i32 sub_15c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15d5, offset=0x15d4, mode=Thumb, size=88, cc=5
i32 sub_15d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x162d, offset=0x162c, mode=Thumb, size=4, cc=1
i32 sub_162d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1631, offset=0x1630, mode=Thumb, size=36, cc=4
i32 sub_1631(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1655, offset=0x1654, mode=Thumb, size=258, cc=24
i32 sub_1655(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1771, offset=0x1770, mode=Thumb, size=46, cc=2
i32 sub_1771(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17b1, offset=0x17b0, mode=Thumb, size=110, cc=6
i32 sub_17b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1821, offset=0x1820, mode=Thumb, size=52, cc=1
i32 sub_1821(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x182b, offset=0x182a, mode=Thumb, size=2, cc=1
i32 sub_182b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x182d, offset=0x182c, mode=Thumb, size=48, cc=1
i32 sub_182d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x186d, offset=0x186c, mode=Thumb, size=42, cc=3
i32 sub_186d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1899, offset=0x1898, mode=Thumb, size=210, cc=17
i32 sub_1899(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x196d, offset=0x196c, mode=Thumb, size=12, cc=1
i32 sub_196d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1979, offset=0x1978, mode=Thumb, size=52, cc=3
i32 sub_1979(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19bd, offset=0x19bc, mode=Thumb, size=164, cc=7
i32 sub_19bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a75, offset=0x1a74, mode=Thumb, size=56, cc=4
i32 sub_1a75(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1aad, offset=0x1aac, mode=Thumb, size=8, cc=1
i32 sub_1aad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ab5, offset=0x1ab4, mode=Thumb, size=136, cc=8
i32 sub_1ab5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b3d, offset=0x1b3c, mode=Thumb, size=8, cc=1
i32 sub_1b3d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b45, offset=0x1b44, mode=Thumb, size=242, cc=22
i32 sub_1b45(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c39, offset=0x1c38, mode=Thumb, size=12, cc=1
i32 sub_1c39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c45, offset=0x1c44, mode=Thumb, size=22, cc=1
i32 sub_1c45(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c99, offset=0x1c98, mode=Thumb, size=70, cc=6
i32 sub_1c99(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ce1, offset=0x1ce0, mode=Thumb, size=4, cc=1
i32 sub_1ce1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ce5, offset=0x1ce4, mode=Thumb, size=58, cc=4
i32 sub_1ce5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d21, offset=0x1d20, mode=Thumb, size=4, cc=1
i32 sub_1d21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d25, offset=0x1d24, mode=Thumb, size=670, cc=35
i32 sub_1d25(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1fc5, offset=0x1fc4, mode=Thumb, size=12, cc=1
i32 sub_1fc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1fd1, offset=0x1fd0, mode=Thumb, size=206, cc=6
i32 sub_1fd1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20d1, offset=0x20d0, mode=Thumb, size=260, cc=14
i32 sub_20d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21fd, offset=0x21fc, mode=Thumb, size=50, cc=1
i32 sub_21fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2241, offset=0x2240, mode=Thumb, size=14, cc=1
i32 sub_2241(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2251, offset=0x2250, mode=Thumb, size=130, cc=3
i32 sub_2251(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22d5, offset=0x22d4, mode=Thumb, size=4, cc=1
i32 sub_22d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22d9, offset=0x22d8, mode=Thumb, size=32, cc=1
i32 sub_22d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22f9, offset=0x22f8, mode=Thumb, size=120, cc=1
i32 sub_22f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2381, offset=0x2380, mode=Thumb, size=26, cc=1
i32 sub_2381(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x239d, offset=0x239c, mode=Thumb, size=78, cc=2
i32 sub_239d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23ed, offset=0x23ec, mode=Thumb, size=4, cc=1
i32 sub_23ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23f1, offset=0x23f0, mode=Thumb, size=74, cc=3
i32 sub_23f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x243d, offset=0x243c, mode=Thumb, size=12, cc=1
i32 sub_243d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2449, offset=0x2448, mode=Thumb, size=188, cc=2
i32 sub_2449(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2515, offset=0x2514, mode=Thumb, size=178, cc=5
i32 sub_2515(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25c9, offset=0x25c8, mode=Thumb, size=4, cc=1
i32 sub_25c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25cd, offset=0x25cc, mode=Thumb, size=66, cc=3
i32 sub_25cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2613, offset=0x2612, mode=Thumb, size=20, cc=1
i32 sub_2613(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2629, offset=0x2628, mode=Thumb, size=22, cc=1
i32 sub_2629(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2641, offset=0x2640, mode=Thumb, size=8, cc=1
i32 sub_2641(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2649, offset=0x2648, mode=Thumb, size=22, cc=2
i32 sub_2649(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2661, offset=0x2660, mode=Thumb, size=4, cc=1
i32 sub_2661(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2665, offset=0x2664, mode=Thumb, size=116, cc=11
i32 sub_2665(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26d9, offset=0x26d8, mode=Thumb, size=4, cc=1
i32 sub_26d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26dd, offset=0x26dc, mode=Thumb, size=86, cc=6
i32 sub_26dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2735, offset=0x2734, mode=Thumb, size=8, cc=1
i32 sub_2735(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x273d, offset=0x273c, mode=Thumb, size=120, cc=4
i32 sub_273d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27d1, offset=0x27d0, mode=Thumb, size=180, cc=9
i32 sub_27d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2899, offset=0x2898, mode=Thumb, size=150, cc=8
i32 sub_2899(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2941, offset=0x2940, mode=Thumb, size=190, cc=7
i32 sub_2941(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2a21, offset=0x2a20, mode=Thumb, size=186, cc=10
i32 sub_2a21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2add, offset=0x2adc, mode=Thumb, size=12, cc=1
i32 sub_2add(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ae9, offset=0x2ae8, mode=Thumb, size=88, cc=2
i32 sub_2ae9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b55, offset=0x2b54, mode=Thumb, size=162, cc=6
i32 sub_2b55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c19, offset=0x2c18, mode=Thumb, size=34, cc=1
i32 sub_2c19(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c3d, offset=0x2c3c, mode=Thumb, size=8, cc=1
i32 sub_2c3d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c45, offset=0x2c44, mode=Thumb, size=126, cc=4
i32 sub_2c45(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cd9, offset=0x2cd8, mode=Thumb, size=126, cc=2
i32 sub_2cd9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d71, offset=0x2d70, mode=Thumb, size=100, cc=2
i32 sub_2d71(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2de9, offset=0x2de8, mode=Thumb, size=188, cc=6
i32 sub_2de9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ec1, offset=0x2ec0, mode=Thumb, size=782, cc=47
i32 sub_2ec1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3259, offset=0x3258, mode=Thumb, size=58, cc=1
i32 sub_3259(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3295, offset=0x3294, mode=Thumb, size=12, cc=1
i32 sub_3295(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32a1, offset=0x32a0, mode=Thumb, size=138, cc=2
i32 sub_32a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3345, offset=0x3344, mode=Thumb, size=320, cc=18
i32 sub_3345(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34bd, offset=0x34bc, mode=Thumb, size=118, cc=2
i32 sub_34bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3549, offset=0x3548, mode=Thumb, size=134, cc=3
i32 sub_3549(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35ed, offset=0x35ec, mode=Thumb, size=56, cc=2
i32 sub_35ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3635, offset=0x3634, mode=Thumb, size=90, cc=6
i32 sub_3635(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a1, offset=0x36a0, mode=Thumb, size=54, cc=3
i32 sub_36a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36d9, offset=0x36d8, mode=Thumb, size=12, cc=1
i32 sub_36d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36e5, offset=0x36e4, mode=Thumb, size=210, cc=6
i32 sub_36e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37e1, offset=0x37e0, mode=Thumb, size=58, cc=1
i32 sub_37e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x382d, offset=0x382c, mode=Thumb, size=92, cc=5
i32 sub_382d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38a1, offset=0x38a0, mode=Thumb, size=70, cc=2
i32 sub_38a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38e9, offset=0x38e8, mode=Thumb, size=8, cc=1
i32 sub_38e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38f1, offset=0x38f0, mode=Thumb, size=58, cc=3
i32 sub_38f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x392d, offset=0x392c, mode=Thumb, size=12, cc=1
i32 sub_392d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3939, offset=0x3938, mode=Thumb, size=62, cc=2
i32 sub_3939(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3979, offset=0x3978, mode=Thumb, size=12, cc=1
i32 sub_3979(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3985, offset=0x3984, mode=Thumb, size=140, cc=5
i32 sub_3985(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a11, offset=0x3a10, mode=Thumb, size=8, cc=1
i32 sub_3a11(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a19, offset=0x3a18, mode=Thumb, size=342, cc=28
i32 sub_3a19(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3b91, offset=0x3b90, mode=Thumb, size=80, cc=6
i32 sub_3b91(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3be1, offset=0x3be0, mode=Thumb, size=8, cc=1
i32 sub_3be1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3be9, offset=0x3be8, mode=Thumb, size=140, cc=3
i32 sub_3be9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3c89, offset=0x3c88, mode=Thumb, size=180, cc=9
i32 sub_3c89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3d4d, offset=0x3d4c, mode=Thumb, size=196, cc=12
i32 sub_3d4d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e11, offset=0x3e10, mode=Thumb, size=4, cc=1
i32 sub_3e11(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e15, offset=0x3e14, mode=Thumb, size=30, cc=1
i32 sub_3e15(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e35, offset=0x3e34, mode=Thumb, size=4, cc=1
i32 sub_3e35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e39, offset=0x3e38, mode=Thumb, size=58, cc=2
i32 sub_3e39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e75, offset=0x3e74, mode=Thumb, size=12, cc=1
i32 sub_3e75(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e81, offset=0x3e80, mode=Thumb, size=86, cc=4
i32 sub_3e81(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ed9, offset=0x3ed8, mode=Thumb, size=8, cc=1
i32 sub_3ed9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ee1, offset=0x3ee0, mode=Thumb, size=130, cc=4
i32 sub_3ee1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3f7d, offset=0x3f7c, mode=Thumb, size=132, cc=4
i32 sub_3f7d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4011, offset=0x4010, mode=Thumb, size=440, cc=19
i32 sub_4011(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4201, offset=0x4200, mode=Thumb, size=100, cc=6
i32 sub_4201(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4275, offset=0x4274, mode=Thumb, size=720, cc=56
i32 sub_4275(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x42fd, offset=0x42fc, mode=Thumb, size=42, cc=1
i32 sub_42fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4339, offset=0x4338, mode=Thumb, size=42, cc=1
i32 sub_4339(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4363, offset=0x4362, mode=Thumb, size=2, cc=1
i32 sub_4363(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4401, offset=0x4400, mode=Thumb, size=20, cc=1
i32 sub_4401(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4493, offset=0x4492, mode=Thumb, size=16, cc=1
i32 sub_4493(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44a3, offset=0x44a2, mode=Thumb, size=16, cc=1
i32 sub_44a3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44b5, offset=0x44b4, mode=Thumb, size=8, cc=1
i32 sub_44b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44bd, offset=0x44bc, mode=Thumb, size=18, cc=1
i32 sub_44bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44cf, offset=0x44ce, mode=Thumb, size=8, cc=1
i32 sub_44cf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44d7, offset=0x44d6, mode=Thumb, size=14, cc=1
i32 sub_44d7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4563, offset=0x4562, mode=Thumb, size=8, cc=1
i32 sub_4563(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x456b, offset=0x456a, mode=Thumb, size=8, cc=1
i32 sub_456b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4573, offset=0x4572, mode=Thumb, size=28, cc=2
i32 sub_4573(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4597, offset=0x4596, mode=Thumb, size=16, cc=1
i32 sub_4597(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45af, offset=0x45ae, mode=Thumb, size=14, cc=1
i32 sub_45af(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45bd, offset=0x45bc, mode=Thumb, size=8, cc=1
i32 sub_45bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45c5, offset=0x45c4, mode=Thumb, size=22, cc=1
i32 sub_45c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4665, offset=0x4664, mode=Thumb, size=8, cc=1
i32 sub_4665(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x466d, offset=0x466c, mode=Thumb, size=8, cc=1
i32 sub_466d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4675, offset=0x4674, mode=Thumb, size=20, cc=1
i32 sub_4675(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4689, offset=0x4688, mode=Thumb, size=20, cc=1
i32 sub_4689(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x46ab, offset=0x46aa, mode=Thumb, size=40, cc=2
i32 sub_46ab(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x46d3, offset=0x46d2, mode=Thumb, size=48, cc=2
i32 sub_46d3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4703, offset=0x4702, mode=Thumb, size=50, cc=3
i32 sub_4703(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4735, offset=0x4734, mode=Thumb, size=8, cc=1
i32 sub_4735(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x473d, offset=0x473c, mode=Thumb, size=66, cc=3
i32 sub_473d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x477f, offset=0x477e, mode=Thumb, size=18, cc=1
i32 sub_477f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4793, offset=0x4792, mode=Thumb, size=44, cc=2
i32 sub_4793(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47bf, offset=0x47be, mode=Thumb, size=8, cc=1
i32 sub_47bf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47d3, offset=0x47d2, mode=Thumb, size=30, cc=1
i32 sub_47d3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x47f1, offset=0x47f0, mode=Thumb, size=72, cc=1
i32 sub_47f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4839, offset=0x4838, mode=Thumb, size=30, cc=2
i32 sub_4839(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4857, offset=0x4856, mode=Thumb, size=12, cc=1
i32 sub_4857(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4863, offset=0x4862, mode=Thumb, size=18, cc=1
i32 sub_4863(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4875, offset=0x4874, mode=Thumb, size=24, cc=2
i32 sub_4875(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x48ad, offset=0x48ac, mode=Thumb, size=184, cc=12
i32 sub_48ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4975, offset=0x4974, mode=Thumb, size=162, cc=9
i32 sub_4975(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4a29, offset=0x4a28, mode=Thumb, size=464, cc=26
i32 sub_4a29(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4c31, offset=0x4c30, mode=Thumb, size=102, cc=3
i32 sub_4c31(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4c99, offset=0x4c98, mode=Thumb, size=8, cc=1
i32 sub_4c99(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ca1, offset=0x4ca0, mode=Thumb, size=72, cc=1
i32 sub_4ca1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ce9, offset=0x4ce8, mode=Thumb, size=8, cc=1
i32 sub_4ce9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4cf1, offset=0x4cf0, mode=Thumb, size=60, cc=2
i32 sub_4cf1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4d2d, offset=0x4d2c, mode=Thumb, size=8, cc=1
i32 sub_4d2d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4d35, offset=0x4d34, mode=Thumb, size=82, cc=2
i32 sub_4d35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4d89, offset=0x4d88, mode=Thumb, size=8, cc=1
i32 sub_4d89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4d91, offset=0x4d90, mode=Thumb, size=86, cc=2
i32 sub_4d91(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4e01, offset=0x4e00, mode=Thumb, size=86, cc=2
i32 sub_4e01(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4e71, offset=0x4e70, mode=Thumb, size=156, cc=6
i32 sub_4e71(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f1d, offset=0x4f1c, mode=Thumb, size=62, cc=3
i32 sub_4f1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f5d, offset=0x4f5c, mode=Thumb, size=12, cc=1
i32 sub_4f5d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f69, offset=0x4f68, mode=Thumb, size=150, cc=7
i32 sub_4f69(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5019, offset=0x5018, mode=Thumb, size=148, cc=5
i32 sub_5019(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x50ad, offset=0x50ac, mode=Thumb, size=12, cc=1
i32 sub_50ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x50b9, offset=0x50b8, mode=Thumb, size=336, cc=25
i32 sub_50b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x523d, offset=0x523c, mode=Thumb, size=92, cc=4
i32 sub_523d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5299, offset=0x5298, mode=Thumb, size=12, cc=1
i32 sub_5299(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x52a5, offset=0x52a4, mode=Thumb, size=116, cc=3
i32 sub_52a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5335, offset=0x5334, mode=Thumb, size=54, cc=3
i32 sub_5335(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x537d, offset=0x537c, mode=Thumb, size=86, cc=2
i32 sub_537d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x53ed, offset=0x53ec, mode=Thumb, size=206, cc=9
i32 sub_53ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x54d1, offset=0x54d0, mode=Thumb, size=82, cc=2
i32 sub_54d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5525, offset=0x5524, mode=Thumb, size=10, cc=1
i32 sub_5525(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x552f, offset=0x552e, mode=Thumb, size=2, cc=1
i32 sub_552f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5531, offset=0x5530, mode=Thumb, size=74, cc=3
i32 sub_5531(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x557d, offset=0x557c, mode=Thumb, size=8, cc=1
i32 sub_557d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5585, offset=0x5584, mode=Thumb, size=246, cc=10
i32 sub_5585(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x568d, offset=0x568c, mode=Thumb, size=224, cc=11
i32 sub_568d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x577d, offset=0x577c, mode=Thumb, size=56, cc=1
i32 sub_577d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x57b5, offset=0x57b4, mode=Thumb, size=12, cc=1
i32 sub_57b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x57c1, offset=0x57c0, mode=Thumb, size=70, cc=3
i32 sub_57c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5809, offset=0x5808, mode=Thumb, size=12, cc=1
i32 sub_5809(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5815, offset=0x5814, mode=Thumb, size=60, cc=2
i32 sub_5815(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5859, offset=0x5858, mode=Thumb, size=344, cc=25
i32 sub_5859(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x59bd, offset=0x59bc, mode=Thumb, size=12, cc=1
i32 sub_59bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x59c9, offset=0x59c8, mode=Thumb, size=60, cc=2
i32 sub_59c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5a05, offset=0x5a04, mode=Thumb, size=8, cc=1
i32 sub_5a05(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5a0d, offset=0x5a0c, mode=Thumb, size=126, cc=4
i32 sub_5a0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5aa1, offset=0x5aa0, mode=Thumb, size=128, cc=4
i32 sub_5aa1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5b35, offset=0x5b34, mode=Thumb, size=210, cc=10
i32 sub_5b35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5c21, offset=0x5c20, mode=Thumb, size=126, cc=4
i32 sub_5c21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5cb5, offset=0x5cb4, mode=Thumb, size=126, cc=4
i32 sub_5cb5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5d49, offset=0x5d48, mode=Thumb, size=258, cc=10
i32 sub_5d49(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5e75, offset=0x5e74, mode=Thumb, size=96, cc=3
i32 sub_5e75(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5ed5, offset=0x5ed4, mode=Thumb, size=12, cc=1
i32 sub_5ed5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5ee1, offset=0x5ee0, mode=Thumb, size=126, cc=2
i32 sub_5ee1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5f79, offset=0x5f78, mode=Thumb, size=70, cc=1
i32 sub_5f79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5fc1, offset=0x5fc0, mode=Thumb, size=8, cc=1
i32 sub_5fc1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5fc9, offset=0x5fc8, mode=Thumb, size=50, cc=3
i32 sub_5fc9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5ffd, offset=0x5ffc, mode=Thumb, size=12, cc=1
i32 sub_5ffd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6009, offset=0x6008, mode=Thumb, size=32, cc=2
i32 sub_6009(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6025, offset=0x6024, mode=Thumb, size=62, cc=1
i32 sub_6025(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6063, offset=0x6062, mode=Thumb, size=174, cc=9
i32 sub_6063(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6111, offset=0x6110, mode=Thumb, size=122, cc=7
i32 sub_6111(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x618b, offset=0x618a, mode=Thumb, size=54, cc=3
i32 sub_618b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x61c1, offset=0x61c0, mode=Thumb, size=44, cc=2
i32 sub_61c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x61ed, offset=0x61ec, mode=Thumb, size=48, cc=1
i32 sub_61ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x621d, offset=0x621c, mode=Thumb, size=14, cc=1
i32 sub_621d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x622b, offset=0x622a, mode=Thumb, size=20, cc=1
i32 sub_622b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6241, offset=0x6240, mode=Thumb, size=24, cc=1
i32 sub_6241(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6259, offset=0x6258, mode=Thumb, size=24, cc=1
i32 sub_6259(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6271, offset=0x6270, mode=Thumb, size=24, cc=1
i32 sub_6271(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6289, offset=0x6288, mode=Thumb, size=24, cc=1
i32 sub_6289(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x62a1, offset=0x62a0, mode=Thumb, size=24, cc=1
i32 sub_62a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x62b9, offset=0x62b8, mode=Thumb, size=44, cc=1
i32 sub_62b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x62e5, offset=0x62e4, mode=Thumb, size=74, cc=3
i32 sub_62e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x632f, offset=0x632e, mode=Thumb, size=28, cc=1
i32 sub_632f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x634b, offset=0x634a, mode=Thumb, size=86, cc=4
i32 sub_634b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x63a1, offset=0x63a0, mode=Thumb, size=46, cc=2
i32 sub_63a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x63f5, offset=0x63f4, mode=Thumb, size=28, cc=2
i32 sub_63f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6411, offset=0x6410, mode=Thumb, size=44, cc=1
i32 sub_6411(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x643d, offset=0x643c, mode=Thumb, size=28, cc=1
i32 sub_643d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6459, offset=0x6458, mode=Thumb, size=28, cc=2
i32 sub_6459(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6475, offset=0x6474, mode=Thumb, size=42, cc=3
i32 sub_6475(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x649f, offset=0x649e, mode=Thumb, size=246, cc=16
i32 sub_649f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x65a1, offset=0x65a0, mode=Thumb, size=14, cc=1
i32 sub_65a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x65e9, offset=0x65e8, mode=Thumb, size=188, cc=8
i32 sub_65e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x66c1, offset=0x66c0, mode=Thumb, size=128, cc=4
i32 sub_66c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6741, offset=0x6740, mode=Thumb, size=8, cc=1
i32 sub_6741(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6749, offset=0x6748, mode=Thumb, size=82, cc=2
i32 sub_6749(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x679d, offset=0x679c, mode=Thumb, size=8, cc=1
i32 sub_679d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x67a5, offset=0x67a4, mode=Thumb, size=82, cc=2
i32 sub_67a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x67f9, offset=0x67f8, mode=Thumb, size=8, cc=1
i32 sub_67f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6801, offset=0x6800, mode=Thumb, size=80, cc=2
i32 sub_6801(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6851, offset=0x6850, mode=Thumb, size=8, cc=1
i32 sub_6851(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6859, offset=0x6858, mode=Thumb, size=82, cc=2
i32 sub_6859(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x68ad, offset=0x68ac, mode=Thumb, size=8, cc=1
i32 sub_68ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x68b5, offset=0x68b4, mode=Thumb, size=130, cc=4
i32 sub_68b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6939, offset=0x6938, mode=Thumb, size=8, cc=1
i32 sub_6939(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6941, offset=0x6940, mode=Thumb, size=74, cc=2
i32 sub_6941(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x698d, offset=0x698c, mode=Thumb, size=8, cc=1
i32 sub_698d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6995, offset=0x6994, mode=Thumb, size=186, cc=8
i32 sub_6995(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6a65, offset=0x6a64, mode=Thumb, size=130, cc=7
i32 sub_6a65(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6af9, offset=0x6af8, mode=Thumb, size=458, cc=25
i32 sub_6af9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6ce1, offset=0x6ce0, mode=Thumb, size=60, cc=1
i32 sub_6ce1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6d2d, offset=0x6d2c, mode=Thumb, size=144, cc=3
i32 sub_6d2d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6dd1, offset=0x6dd0, mode=Thumb, size=102, cc=2
i32 sub_6dd1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x6e49, offset=0x6e48, mode=Thumb, size=3776, cc=347
i32 sub_6e49(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7f2d, offset=0x7f2c, mode=Thumb, size=64, cc=2
i32 sub_7f2d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7f6d, offset=0x7f6c, mode=Thumb, size=12, cc=1
i32 sub_7f6d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7f79, offset=0x7f78, mode=Thumb, size=124, cc=4
i32 sub_7f79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x800d, offset=0x800c, mode=Thumb, size=5214, cc=389
i32 sub_800d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9665, offset=0x9664, mode=Thumb, size=182, cc=10
i32 sub_9665(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x972d, offset=0x972c, mode=Thumb, size=924, cc=1
i32 sub_972d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9ac9, offset=0x9ac8, mode=Thumb, size=24, cc=1
i32 sub_9ac9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9ae1, offset=0x9ae0, mode=Thumb, size=24, cc=1
i32 sub_9ae1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9af9, offset=0x9af8, mode=Thumb, size=16, cc=1
i32 sub_9af9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9b09, offset=0x9b08, mode=Thumb, size=24, cc=1
i32 sub_9b09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9b21, offset=0x9b20, mode=Thumb, size=24, cc=1
i32 sub_9b21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9b39, offset=0x9b38, mode=Thumb, size=24, cc=1
i32 sub_9b39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9b51, offset=0x9b50, mode=Thumb, size=24, cc=1
i32 sub_9b51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9b69, offset=0x9b68, mode=Thumb, size=24, cc=1
i32 sub_9b69(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9b81, offset=0x9b80, mode=Thumb, size=28, cc=1
i32 sub_9b81(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9b9d, offset=0x9b9c, mode=Thumb, size=8, cc=1
i32 sub_9b9d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9ba5, offset=0x9ba4, mode=Thumb, size=8, cc=1
i32 sub_9ba5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9bad, offset=0x9bac, mode=Thumb, size=24, cc=1
i32 sub_9bad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9bc5, offset=0x9bc4, mode=Thumb, size=30, cc=1
i32 sub_9bc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9be3, offset=0x9be2, mode=Thumb, size=24, cc=1
i32 sub_9be3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9bfb, offset=0x9bfa, mode=Thumb, size=28, cc=1
i32 sub_9bfb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c17, offset=0x9c16, mode=Thumb, size=24, cc=1
i32 sub_9c17(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c2f, offset=0x9c2e, mode=Thumb, size=28, cc=1
i32 sub_9c2f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c4b, offset=0x9c4a, mode=Thumb, size=38, cc=1
i32 sub_9c4b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c71, offset=0x9c70, mode=Thumb, size=24, cc=1
i32 sub_9c71(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c89, offset=0x9c88, mode=Thumb, size=16, cc=1
i32 sub_9c89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9c99, offset=0x9c98, mode=Thumb, size=24, cc=1
i32 sub_9c99(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9cb1, offset=0x9cb0, mode=Thumb, size=28, cc=1
i32 sub_9cb1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9ccd, offset=0x9ccc, mode=Thumb, size=28, cc=1
i32 sub_9ccd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9ce9, offset=0x9ce8, mode=Thumb, size=8, cc=1
i32 sub_9ce9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9cf1, offset=0x9cf0, mode=Thumb, size=8, cc=1
i32 sub_9cf1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9cf9, offset=0x9cf8, mode=Thumb, size=8, cc=1
i32 sub_9cf9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d01, offset=0x9d00, mode=Thumb, size=18, cc=1
i32 sub_9d01(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d13, offset=0x9d12, mode=Thumb, size=18, cc=2
i32 sub_9d13(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d25, offset=0x9d24, mode=Thumb, size=44, cc=1
i32 sub_9d25(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d51, offset=0x9d50, mode=Thumb, size=8, cc=1
i32 sub_9d51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d59, offset=0x9d58, mode=Thumb, size=14, cc=1
i32 sub_9d59(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d67, offset=0x9d66, mode=Thumb, size=8, cc=1
i32 sub_9d67(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d6f, offset=0x9d6e, mode=Thumb, size=8, cc=1
i32 sub_9d6f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d77, offset=0x9d76, mode=Thumb, size=24, cc=1
i32 sub_9d77(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9d8f, offset=0x9d8e, mode=Thumb, size=24, cc=1
i32 sub_9d8f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9da7, offset=0x9da6, mode=Thumb, size=24, cc=1
i32 sub_9da7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9dbf, offset=0x9dbe, mode=Thumb, size=24, cc=1
i32 sub_9dbf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9dd7, offset=0x9dd6, mode=Thumb, size=12, cc=1
i32 sub_9dd7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9de1, offset=0x9de0, mode=Thumb, size=10, cc=1
i32 sub_9de1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9deb, offset=0x9dea, mode=Thumb, size=30, cc=1
i32 sub_9deb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9e09, offset=0x9e08, mode=Thumb, size=22, cc=1
i32 sub_9e09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9e1f, offset=0x9e1e, mode=Thumb, size=24, cc=1
i32 sub_9e1f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9e37, offset=0x9e36, mode=Thumb, size=24, cc=1
i32 sub_9e37(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9e4f, offset=0x9e4e, mode=Thumb, size=24, cc=1
i32 sub_9e4f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9ead, offset=0x9eac, mode=Thumb, size=24, cc=1
i32 sub_9ead(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9ec5, offset=0x9ec4, mode=Thumb, size=54, cc=1
i32 sub_9ec5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9efb, offset=0x9efa, mode=Thumb, size=8, cc=1
i32 sub_9efb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9f03, offset=0x9f02, mode=Thumb, size=48, cc=1
i32 sub_9f03(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9f33, offset=0x9f32, mode=Thumb, size=8, cc=1
i32 sub_9f33(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9f3b, offset=0x9f3a, mode=Thumb, size=24, cc=1
i32 sub_9f3b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9f53, offset=0x9f52, mode=Thumb, size=22, cc=1
i32 sub_9f53(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9f69, offset=0x9f68, mode=Thumb, size=22, cc=1
i32 sub_9f69(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9f7f, offset=0x9f7e, mode=Thumb, size=24, cc=1
i32 sub_9f7f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9f97, offset=0x9f96, mode=Thumb, size=24, cc=1
i32 sub_9f97(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9faf, offset=0x9fae, mode=Thumb, size=8, cc=1
i32 sub_9faf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9fb7, offset=0x9fb6, mode=Thumb, size=8, cc=1
i32 sub_9fb7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9fbf, offset=0x9fbe, mode=Thumb, size=30, cc=1
i32 sub_9fbf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x9fdd, offset=0x9fdc, mode=Thumb, size=46, cc=1
i32 sub_9fdd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa00b, offset=0xa00a, mode=Thumb, size=38, cc=1
i32 sub_a00b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa031, offset=0xa030, mode=Thumb, size=44, cc=1
i32 sub_a031(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa05d, offset=0xa05c, mode=Thumb, size=46, cc=2
i32 sub_a05d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa08b, offset=0xa08a, mode=Thumb, size=8, cc=1
i32 sub_a08b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa093, offset=0xa092, mode=Thumb, size=4, cc=1
i32 sub_a093(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa097, offset=0xa096, mode=Thumb, size=40, cc=1
i32 sub_a097(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa0bf, offset=0xa0be, mode=Thumb, size=24, cc=1
i32 sub_a0bf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa0d7, offset=0xa0d6, mode=Thumb, size=24, cc=1
i32 sub_a0d7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa0ef, offset=0xa0ee, mode=Thumb, size=48, cc=1
i32 sub_a0ef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa121, offset=0xa120, mode=Thumb, size=8, cc=1
i32 sub_a121(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa129, offset=0xa128, mode=Thumb, size=30, cc=1
i32 sub_a129(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa147, offset=0xa146, mode=Thumb, size=16, cc=1
i32 sub_a147(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa157, offset=0xa156, mode=Thumb, size=12, cc=1
i32 sub_a157(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa163, offset=0xa162, mode=Thumb, size=24, cc=1
i32 sub_a163(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa17b, offset=0xa17a, mode=Thumb, size=24, cc=1
i32 sub_a17b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa193, offset=0xa192, mode=Thumb, size=24, cc=1
i32 sub_a193(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa1ab, offset=0xa1aa, mode=Thumb, size=24, cc=1
i32 sub_a1ab(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa1c3, offset=0xa1c2, mode=Thumb, size=24, cc=1
i32 sub_a1c3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa1db, offset=0xa1da, mode=Thumb, size=8, cc=1
i32 sub_a1db(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa1e3, offset=0xa1e2, mode=Thumb, size=24, cc=1
i32 sub_a1e3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa1fb, offset=0xa1fa, mode=Thumb, size=24, cc=1
i32 sub_a1fb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa213, offset=0xa212, mode=Thumb, size=24, cc=1
i32 sub_a213(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa22b, offset=0xa22a, mode=Thumb, size=24, cc=1
i32 sub_a22b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa243, offset=0xa242, mode=Thumb, size=24, cc=1
i32 sub_a243(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa25b, offset=0xa25a, mode=Thumb, size=24, cc=1
i32 sub_a25b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa2c9, offset=0xa2c8, mode=Thumb, size=24, cc=1
i32 sub_a2c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa2e1, offset=0xa2e0, mode=Thumb, size=24, cc=1
i32 sub_a2e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa2f9, offset=0xa2f8, mode=Thumb, size=8, cc=1
i32 sub_a2f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa301, offset=0xa300, mode=Thumb, size=26, cc=1
i32 sub_a301(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa31b, offset=0xa31a, mode=Thumb, size=24, cc=1
i32 sub_a31b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa333, offset=0xa332, mode=Thumb, size=24, cc=1
i32 sub_a333(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa34b, offset=0xa34a, mode=Thumb, size=8, cc=1
i32 sub_a34b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa353, offset=0xa352, mode=Thumb, size=8, cc=1
i32 sub_a353(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa35b, offset=0xa35a, mode=Thumb, size=24, cc=1
i32 sub_a35b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa373, offset=0xa372, mode=Thumb, size=24, cc=1
i32 sub_a373(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa38b, offset=0xa38a, mode=Thumb, size=48, cc=3
i32 sub_a38b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa3bb, offset=0xa3ba, mode=Thumb, size=8, cc=1
i32 sub_a3bb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa3c3, offset=0xa3c2, mode=Thumb, size=24, cc=1
i32 sub_a3c3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa3db, offset=0xa3da, mode=Thumb, size=24, cc=1
i32 sub_a3db(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa3f3, offset=0xa3f2, mode=Thumb, size=8, cc=1
i32 sub_a3f3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa3fb, offset=0xa3fa, mode=Thumb, size=16, cc=1
i32 sub_a3fb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa40b, offset=0xa40a, mode=Thumb, size=8, cc=1
i32 sub_a40b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa413, offset=0xa412, mode=Thumb, size=8, cc=1
i32 sub_a413(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa41b, offset=0xa41a, mode=Thumb, size=32, cc=2
i32 sub_a41b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa43b, offset=0xa43a, mode=Thumb, size=8, cc=1
i32 sub_a43b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa443, offset=0xa442, mode=Thumb, size=34, cc=3
i32 sub_a443(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa465, offset=0xa464, mode=Thumb, size=8, cc=1
i32 sub_a465(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa46d, offset=0xa46c, mode=Thumb, size=8, cc=1
i32 sub_a46d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa475, offset=0xa474, mode=Thumb, size=8, cc=1
i32 sub_a475(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa47d, offset=0xa47c, mode=Thumb, size=8, cc=1
i32 sub_a47d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa485, offset=0xa484, mode=Thumb, size=8, cc=1
i32 sub_a485(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa48d, offset=0xa48c, mode=Thumb, size=8, cc=1
i32 sub_a48d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa495, offset=0xa494, mode=Thumb, size=24, cc=1
i32 sub_a495(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa4ad, offset=0xa4ac, mode=Thumb, size=8, cc=1
i32 sub_a4ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa4b5, offset=0xa4b4, mode=Thumb, size=24, cc=1
i32 sub_a4b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa4cd, offset=0xa4cc, mode=Thumb, size=24, cc=1
i32 sub_a4cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa4e5, offset=0xa4e4, mode=Thumb, size=8, cc=1
i32 sub_a4e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa4ed, offset=0xa4ec, mode=Thumb, size=12, cc=1
i32 sub_a4ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa4f9, offset=0xa4f8, mode=Thumb, size=8, cc=1
i32 sub_a4f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa501, offset=0xa500, mode=Thumb, size=8, cc=1
i32 sub_a501(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa509, offset=0xa508, mode=Thumb, size=24, cc=1
i32 sub_a509(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa521, offset=0xa520, mode=Thumb, size=10, cc=1
i32 sub_a521(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa52b, offset=0xa52a, mode=Thumb, size=8, cc=1
i32 sub_a52b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa533, offset=0xa532, mode=Thumb, size=8, cc=1
i32 sub_a533(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa53b, offset=0xa53a, mode=Thumb, size=24, cc=1
i32 sub_a53b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa553, offset=0xa552, mode=Thumb, size=24, cc=1
i32 sub_a553(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa56b, offset=0xa56a, mode=Thumb, size=24, cc=1
i32 sub_a56b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa583, offset=0xa582, mode=Thumb, size=8, cc=1
i32 sub_a583(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa58b, offset=0xa58a, mode=Thumb, size=8, cc=1
i32 sub_a58b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa593, offset=0xa592, mode=Thumb, size=8, cc=1
i32 sub_a593(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa59b, offset=0xa59a, mode=Thumb, size=8, cc=1
i32 sub_a59b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa5a3, offset=0xa5a2, mode=Thumb, size=8, cc=1
i32 sub_a5a3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa5ab, offset=0xa5aa, mode=Thumb, size=38, cc=1
i32 sub_a5ab(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa5d1, offset=0xa5d0, mode=Thumb, size=8, cc=1
i32 sub_a5d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa5d9, offset=0xa5d8, mode=Thumb, size=8, cc=1
i32 sub_a5d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa5e1, offset=0xa5e0, mode=Thumb, size=8, cc=1
i32 sub_a5e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa5e9, offset=0xa5e8, mode=Thumb, size=8, cc=1
i32 sub_a5e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa5f1, offset=0xa5f0, mode=Thumb, size=8, cc=1
i32 sub_a5f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa5f9, offset=0xa5f8, mode=Thumb, size=24, cc=1
i32 sub_a5f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa611, offset=0xa610, mode=Thumb, size=16, cc=1
i32 sub_a611(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa621, offset=0xa620, mode=Thumb, size=10, cc=1
i32 sub_a621(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa629, offset=0xa628, mode=Thumb, size=24, cc=1
i32 sub_a629(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa641, offset=0xa640, mode=Thumb, size=24, cc=1
i32 sub_a641(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa659, offset=0xa658, mode=Thumb, size=24, cc=1
i32 sub_a659(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa671, offset=0xa670, mode=Thumb, size=24, cc=1
i32 sub_a671(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa6d5, offset=0xa6d4, mode=Thumb, size=24, cc=1
i32 sub_a6d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa6ed, offset=0xa6ec, mode=Thumb, size=8, cc=1
i32 sub_a6ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa6f5, offset=0xa6f4, mode=Thumb, size=8, cc=1
i32 sub_a6f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa6fd, offset=0xa6fc, mode=Thumb, size=48, cc=1
i32 sub_a6fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa72d, offset=0xa72c, mode=Thumb, size=16, cc=1
i32 sub_a72d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa73d, offset=0xa73c, mode=Thumb, size=16, cc=1
i32 sub_a73d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa74d, offset=0xa74c, mode=Thumb, size=50, cc=1
i32 sub_a74d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa77f, offset=0xa77e, mode=Thumb, size=26, cc=1
i32 sub_a77f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa799, offset=0xa798, mode=Thumb, size=26, cc=1
i32 sub_a799(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa7b3, offset=0xa7b2, mode=Thumb, size=24, cc=1
i32 sub_a7b3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa7cb, offset=0xa7ca, mode=Thumb, size=8, cc=1
i32 sub_a7cb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa7d3, offset=0xa7d2, mode=Thumb, size=28, cc=3
i32 sub_a7d3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa7ef, offset=0xa7ee, mode=Thumb, size=8, cc=1
i32 sub_a7ef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa7f7, offset=0xa7f6, mode=Thumb, size=16, cc=1
i32 sub_a7f7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa807, offset=0xa806, mode=Thumb, size=16, cc=1
i32 sub_a807(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa817, offset=0xa816, mode=Thumb, size=16, cc=1
i32 sub_a817(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa827, offset=0xa826, mode=Thumb, size=16, cc=1
i32 sub_a827(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa837, offset=0xa836, mode=Thumb, size=8, cc=1
i32 sub_a837(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa83f, offset=0xa83e, mode=Thumb, size=24, cc=1
i32 sub_a83f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa857, offset=0xa856, mode=Thumb, size=24, cc=1
i32 sub_a857(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa86f, offset=0xa86e, mode=Thumb, size=24, cc=1
i32 sub_a86f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa887, offset=0xa886, mode=Thumb, size=24, cc=1
i32 sub_a887(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa89f, offset=0xa89e, mode=Thumb, size=8, cc=1
i32 sub_a89f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa8a7, offset=0xa8a6, mode=Thumb, size=30, cc=1
i32 sub_a8a7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa8c7, offset=0xa8c6, mode=Thumb, size=24, cc=1
i32 sub_a8c7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa8df, offset=0xa8de, mode=Thumb, size=24, cc=1
i32 sub_a8df(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa8f7, offset=0xa8f6, mode=Thumb, size=24, cc=1
i32 sub_a8f7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa90f, offset=0xa90e, mode=Thumb, size=8, cc=1
i32 sub_a90f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa917, offset=0xa916, mode=Thumb, size=6, cc=1
i32 sub_a917(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa91d, offset=0xa91c, mode=Thumb, size=24, cc=1
i32 sub_a91d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa935, offset=0xa934, mode=Thumb, size=24, cc=1
i32 sub_a935(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa94d, offset=0xa94c, mode=Thumb, size=32, cc=1
i32 sub_a94d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa96d, offset=0xa96c, mode=Thumb, size=8, cc=1
i32 sub_a96d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa975, offset=0xa974, mode=Thumb, size=30, cc=1
i32 sub_a975(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa993, offset=0xa992, mode=Thumb, size=24, cc=1
i32 sub_a993(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa9ab, offset=0xa9aa, mode=Thumb, size=8, cc=1
i32 sub_a9ab(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa9b3, offset=0xa9b2, mode=Thumb, size=34, cc=1
i32 sub_a9b3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa9d5, offset=0xa9d4, mode=Thumb, size=8, cc=1
i32 sub_a9d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa9dd, offset=0xa9dc, mode=Thumb, size=8, cc=1
i32 sub_a9dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xa9e5, offset=0xa9e4, mode=Thumb, size=44, cc=1
i32 sub_a9e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaa11, offset=0xaa10, mode=Thumb, size=8, cc=1
i32 sub_aa11(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaa19, offset=0xaa18, mode=Thumb, size=24, cc=1
i32 sub_aa19(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaa31, offset=0xaa30, mode=Thumb, size=8, cc=1
i32 sub_aa31(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaa39, offset=0xaa38, mode=Thumb, size=8, cc=1
i32 sub_aa39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaa41, offset=0xaa40, mode=Thumb, size=8, cc=1
i32 sub_aa41(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaa49, offset=0xaa48, mode=Thumb, size=8, cc=1
i32 sub_aa49(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaa51, offset=0xaa50, mode=Thumb, size=8, cc=1
i32 sub_aa51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaa59, offset=0xaa58, mode=Thumb, size=8, cc=1
i32 sub_aa59(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaa61, offset=0xaa60, mode=Thumb, size=8, cc=1
i32 sub_aa61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaa69, offset=0xaa68, mode=Thumb, size=30, cc=1
i32 sub_aa69(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaaf1, offset=0xaaf0, mode=Thumb, size=12, cc=1
i32 sub_aaf1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaafd, offset=0xaafc, mode=Thumb, size=24, cc=1
i32 sub_aafd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xab15, offset=0xab14, mode=Thumb, size=24, cc=1
i32 sub_ab15(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xab2d, offset=0xab2c, mode=Thumb, size=24, cc=1
i32 sub_ab2d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xab45, offset=0xab44, mode=Thumb, size=26, cc=1
i32 sub_ab45(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xab5f, offset=0xab5e, mode=Thumb, size=8, cc=1
i32 sub_ab5f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xab67, offset=0xab66, mode=Thumb, size=24, cc=1
i32 sub_ab67(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xab7f, offset=0xab7e, mode=Thumb, size=24, cc=1
i32 sub_ab7f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xab97, offset=0xab96, mode=Thumb, size=48, cc=2
i32 sub_ab97(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xabc7, offset=0xabc6, mode=Thumb, size=10, cc=1
i32 sub_abc7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xabd1, offset=0xabd0, mode=Thumb, size=10, cc=1
i32 sub_abd1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xabdb, offset=0xabda, mode=Thumb, size=10, cc=1
i32 sub_abdb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xabe5, offset=0xabe4, mode=Thumb, size=10, cc=1
i32 sub_abe5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xabef, offset=0xabee, mode=Thumb, size=24, cc=1
i32 sub_abef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xac07, offset=0xac06, mode=Thumb, size=24, cc=1
i32 sub_ac07(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xac1f, offset=0xac1e, mode=Thumb, size=24, cc=1
i32 sub_ac1f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xac37, offset=0xac36, mode=Thumb, size=24, cc=1
i32 sub_ac37(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xac4f, offset=0xac4e, mode=Thumb, size=48, cc=2
i32 sub_ac4f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xac7f, offset=0xac7e, mode=Thumb, size=44, cc=1
i32 sub_ac7f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xacab, offset=0xacaa, mode=Thumb, size=8, cc=1
i32 sub_acab(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xacb3, offset=0xacb2, mode=Thumb, size=10, cc=1
i32 sub_acb3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xacbd, offset=0xacbc, mode=Thumb, size=8, cc=1
i32 sub_acbd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xacc5, offset=0xacc4, mode=Thumb, size=24, cc=1
i32 sub_acc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xacdd, offset=0xacdc, mode=Thumb, size=8, cc=1
i32 sub_acdd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xace5, offset=0xace4, mode=Thumb, size=8, cc=1
i32 sub_ace5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaced, offset=0xacec, mode=Thumb, size=24, cc=1
i32 sub_aced(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xad05, offset=0xad04, mode=Thumb, size=24, cc=1
i32 sub_ad05(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xad1d, offset=0xad1c, mode=Thumb, size=30, cc=1
i32 sub_ad1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xad3b, offset=0xad3a, mode=Thumb, size=8, cc=1
i32 sub_ad3b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xad43, offset=0xad42, mode=Thumb, size=8, cc=1
i32 sub_ad43(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xad4b, offset=0xad4a, mode=Thumb, size=24, cc=1
i32 sub_ad4b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xad63, offset=0xad62, mode=Thumb, size=24, cc=1
i32 sub_ad63(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xad7b, offset=0xad7a, mode=Thumb, size=24, cc=1
i32 sub_ad7b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xad93, offset=0xad92, mode=Thumb, size=24, cc=1
i32 sub_ad93(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xadab, offset=0xadaa, mode=Thumb, size=16, cc=1
i32 sub_adab(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xadbb, offset=0xadba, mode=Thumb, size=10, cc=1
i32 sub_adbb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xadc5, offset=0xadc4, mode=Thumb, size=8, cc=1
i32 sub_adc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xadcd, offset=0xadcc, mode=Thumb, size=24, cc=1
i32 sub_adcd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xade5, offset=0xade4, mode=Thumb, size=24, cc=1
i32 sub_ade5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xadfd, offset=0xadfc, mode=Thumb, size=24, cc=1
i32 sub_adfd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae15, offset=0xae14, mode=Thumb, size=14, cc=1
i32 sub_ae15(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xae23, offset=0xae22, mode=Thumb, size=178, cc=10
i32 sub_ae23(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaf55, offset=0xaf54, mode=Thumb, size=10, cc=1
i32 sub_af55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaf5f, offset=0xaf5e, mode=Thumb, size=12, cc=1
i32 sub_af5f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaf6b, offset=0xaf6a, mode=Thumb, size=12, cc=1
i32 sub_af6b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xaf77, offset=0xaf76, mode=Thumb, size=46, cc=2
i32 sub_af77(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xafa5, offset=0xafa4, mode=Thumb, size=46, cc=2
i32 sub_afa5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xafd3, offset=0xafd2, mode=Thumb, size=46, cc=2
i32 sub_afd3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb001, offset=0xb000, mode=Thumb, size=28, cc=1
i32 sub_b001(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb01d, offset=0xb01c, mode=Thumb, size=46, cc=2
i32 sub_b01d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb04b, offset=0xb04a, mode=Thumb, size=8, cc=1
i32 sub_b04b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb053, offset=0xb052, mode=Thumb, size=8, cc=1
i32 sub_b053(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb05b, offset=0xb05a, mode=Thumb, size=8, cc=1
i32 sub_b05b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb063, offset=0xb062, mode=Thumb, size=8, cc=1
i32 sub_b063(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb06b, offset=0xb06a, mode=Thumb, size=8, cc=1
i32 sub_b06b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb073, offset=0xb072, mode=Thumb, size=24, cc=1
i32 sub_b073(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb08b, offset=0xb08a, mode=Thumb, size=46, cc=1
i32 sub_b08b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb0b9, offset=0xb0b8, mode=Thumb, size=24, cc=1
i32 sub_b0b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb0d1, offset=0xb0d0, mode=Thumb, size=8, cc=1
i32 sub_b0d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb0d9, offset=0xb0d8, mode=Thumb, size=18, cc=1
i32 sub_b0d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb0eb, offset=0xb0ea, mode=Thumb, size=20, cc=1
i32 sub_b0eb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb0ff, offset=0xb0fe, mode=Thumb, size=46, cc=2
i32 sub_b0ff(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb12d, offset=0xb12c, mode=Thumb, size=24, cc=1
i32 sub_b12d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb145, offset=0xb144, mode=Thumb, size=8, cc=1
i32 sub_b145(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb14d, offset=0xb14c, mode=Thumb, size=24, cc=1
i32 sub_b14d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb165, offset=0xb164, mode=Thumb, size=24, cc=1
i32 sub_b165(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb17d, offset=0xb17c, mode=Thumb, size=8, cc=1
i32 sub_b17d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb185, offset=0xb184, mode=Thumb, size=10, cc=1
i32 sub_b185(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb18f, offset=0xb18e, mode=Thumb, size=24, cc=1
i32 sub_b18f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb1a7, offset=0xb1a6, mode=Thumb, size=24, cc=1
i32 sub_b1a7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb1bf, offset=0xb1be, mode=Thumb, size=30, cc=2
i32 sub_b1bf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb1dd, offset=0xb1dc, mode=Thumb, size=8, cc=1
i32 sub_b1dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb1e5, offset=0xb1e4, mode=Thumb, size=24, cc=1
i32 sub_b1e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb1fd, offset=0xb1fc, mode=Thumb, size=24, cc=1
i32 sub_b1fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb215, offset=0xb214, mode=Thumb, size=24, cc=1
i32 sub_b215(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb22d, offset=0xb22c, mode=Thumb, size=8, cc=1
i32 sub_b22d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb235, offset=0xb234, mode=Thumb, size=24, cc=1
i32 sub_b235(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb24d, offset=0xb24c, mode=Thumb, size=44, cc=1
i32 sub_b24d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb279, offset=0xb278, mode=Thumb, size=8, cc=1
i32 sub_b279(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb281, offset=0xb280, mode=Thumb, size=8, cc=1
i32 sub_b281(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb289, offset=0xb288, mode=Thumb, size=8, cc=1
i32 sub_b289(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb291, offset=0xb290, mode=Thumb, size=8, cc=1
i32 sub_b291(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb299, offset=0xb298, mode=Thumb, size=24, cc=1
i32 sub_b299(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb2b1, offset=0xb2b0, mode=Thumb, size=42, cc=2
i32 sub_b2b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb2db, offset=0xb2da, mode=Thumb, size=92, cc=3
i32 sub_b2db(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb3a1, offset=0xb3a0, mode=Thumb, size=8, cc=1
i32 sub_b3a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb3a9, offset=0xb3a8, mode=Thumb, size=366, cc=45
i32 sub_b3a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb519, offset=0xb518, mode=Thumb, size=4, cc=1
i32 sub_b519(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb51d, offset=0xb51c, mode=Thumb, size=342, cc=22
i32 sub_b51d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb6a1, offset=0xb6a0, mode=Thumb, size=260, cc=11
i32 sub_b6a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb7cd, offset=0xb7cc, mode=Thumb, size=440, cc=17
i32 sub_b7cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xb995, offset=0xb994, mode=Thumb, size=938, cc=67
i32 sub_b995(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xbda1, offset=0xbda0, mode=Thumb, size=280, cc=14
i32 sub_bda1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xbed1, offset=0xbed0, mode=Thumb, size=144, cc=5
i32 sub_bed1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xbf79, offset=0xbf78, mode=Thumb, size=452, cc=27
i32 sub_bf79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xc151, offset=0xc150, mode=Thumb, size=168, cc=10
i32 sub_c151(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xc219, offset=0xc218, mode=Thumb, size=128, cc=5
i32 sub_c219(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xc2a9, offset=0xc2a8, mode=Thumb, size=194, cc=10
i32 sub_c2a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xc395, offset=0xc394, mode=Thumb, size=468, cc=27
i32 sub_c395(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xc5a9, offset=0xc5a8, mode=Thumb, size=130, cc=5
i32 sub_c5a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xc62d, offset=0xc62c, mode=Thumb, size=8, cc=1
i32 sub_c62d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xc635, offset=0xc634, mode=Thumb, size=704, cc=31
i32 sub_c635(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xc95d, offset=0xc95c, mode=Thumb, size=1576, cc=99
i32 sub_c95d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xd06d, offset=0xd06c, mode=Thumb, size=2198, cc=143
i32 sub_d06d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xda3d, offset=0xda3c, mode=Thumb, size=170, cc=6
i32 sub_da3d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xdafd, offset=0xdafc, mode=Thumb, size=178, cc=7
i32 sub_dafd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xdbc9, offset=0xdbc8, mode=Thumb, size=62, cc=2
i32 sub_dbc9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xdc21, offset=0xdc20, mode=Thumb, size=212, cc=10
i32 sub_dc21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xdd15, offset=0xdd14, mode=Thumb, size=332, cc=19
i32 sub_dd15(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xde8d, offset=0xde8c, mode=Thumb, size=138, cc=6
i32 sub_de8d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xdf39, offset=0xdf38, mode=Thumb, size=196, cc=9
i32 sub_df39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe011, offset=0xe010, mode=Thumb, size=208, cc=12
i32 sub_e011(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe0e1, offset=0xe0e0, mode=Thumb, size=4, cc=1
i32 sub_e0e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe0e5, offset=0xe0e4, mode=Thumb, size=88, cc=4
i32 sub_e0e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe14d, offset=0xe14c, mode=Thumb, size=820, cc=47
i32 sub_e14d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe4f5, offset=0xe4f4, mode=Thumb, size=264, cc=14
i32 sub_e4f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe619, offset=0xe618, mode=Thumb, size=76, cc=4
i32 sub_e619(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe679, offset=0xe678, mode=Thumb, size=846, cc=44
i32 sub_e679(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xea25, offset=0xea24, mode=Thumb, size=142, cc=5
i32 sub_ea25(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xeacd, offset=0xeacc, mode=Thumb, size=104, cc=2
i32 sub_eacd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xeb35, offset=0xeb34, mode=Thumb, size=12, cc=1
i32 sub_eb35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xeb41, offset=0xeb40, mode=Thumb, size=62, cc=2
i32 sub_eb41(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xeb81, offset=0xeb80, mode=Thumb, size=12, cc=1
i32 sub_eb81(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xeb8d, offset=0xeb8c, mode=Thumb, size=36, cc=1
i32 sub_eb8d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xebb1, offset=0xebb0, mode=Thumb, size=90, cc=4
i32 sub_ebb1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xec0d, offset=0xec0c, mode=Thumb, size=8, cc=1
i32 sub_ec0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xec15, offset=0xec14, mode=Thumb, size=110, cc=5
i32 sub_ec15(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xec85, offset=0xec84, mode=Thumb, size=12, cc=1
i32 sub_ec85(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xec91, offset=0xec90, mode=Thumb, size=208, cc=17
i32 sub_ec91(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xed89, offset=0xed88, mode=Thumb, size=64, cc=5
i32 sub_ed89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xedc9, offset=0xedc8, mode=Thumb, size=4, cc=1
i32 sub_edc9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xedcd, offset=0xedcc, mode=Thumb, size=74, cc=4
i32 sub_edcd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xee19, offset=0xee18, mode=Thumb, size=12, cc=1
i32 sub_ee19(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xee25, offset=0xee24, mode=Thumb, size=122, cc=7
i32 sub_ee25(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xeeb5, offset=0xeeb4, mode=Thumb, size=108, cc=4
i32 sub_eeb5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xef41, offset=0xef40, mode=Thumb, size=100, cc=5
i32 sub_ef41(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xefb5, offset=0xefb4, mode=Thumb, size=78, cc=2
i32 sub_efb5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf01d, offset=0xf01c, mode=Thumb, size=100, cc=6
i32 sub_f01d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf081, offset=0xf080, mode=Thumb, size=12, cc=1
i32 sub_f081(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf08d, offset=0xf08c, mode=Thumb, size=76, cc=5
i32 sub_f08d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf0d9, offset=0xf0d8, mode=Thumb, size=8, cc=1
i32 sub_f0d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf0e1, offset=0xf0e0, mode=Thumb, size=104, cc=4
i32 sub_f0e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf165, offset=0xf164, mode=Thumb, size=62, cc=3
i32 sub_f165(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf1b9, offset=0xf1b8, mode=Thumb, size=152, cc=4
i32 sub_f1b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf269, offset=0xf268, mode=Thumb, size=264, cc=18
i32 sub_f269(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf395, offset=0xf394, mode=Thumb, size=108, cc=4
i32 sub_f395(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf415, offset=0xf414, mode=Thumb, size=152, cc=10
i32 sub_f415(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf4c5, offset=0xf4c4, mode=Thumb, size=180, cc=7
i32 sub_f4c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf591, offset=0xf590, mode=Thumb, size=356, cc=20
i32 sub_f591(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf719, offset=0xf718, mode=Thumb, size=432, cc=23
i32 sub_f719(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf83d, offset=0xf83c, mode=Thumb, size=8, cc=1
i32 sub_f83d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf84b, offset=0xf84a, mode=Thumb, size=6, cc=1
i32 sub_f84b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf851, offset=0xf850, mode=Thumb, size=6, cc=1
i32 sub_f851(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf857, offset=0xf856, mode=Thumb, size=6, cc=1
i32 sub_f857(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf85d, offset=0xf85c, mode=Thumb, size=4, cc=1
i32 sub_f85d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf861, offset=0xf860, mode=Thumb, size=6, cc=1
i32 sub_f861(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf867, offset=0xf866, mode=Thumb, size=6, cc=1
i32 sub_f867(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf86d, offset=0xf86c, mode=Thumb, size=4, cc=1
i32 sub_f86d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf901, offset=0xf900, mode=Thumb, size=8, cc=1
i32 sub_f901(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf909, offset=0xf908, mode=Thumb, size=172, cc=6
i32 sub_f909(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf9b5, offset=0xf9b4, mode=Thumb, size=12, cc=1
i32 sub_f9b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf9c1, offset=0xf9c0, mode=Thumb, size=204, cc=6
i32 sub_f9c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xfaa9, offset=0xfaa8, mode=Thumb, size=48, cc=1
i32 sub_faa9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xfad9, offset=0xfad8, mode=Thumb, size=388, cc=19
i32 sub_fad9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xfc81, offset=0xfc80, mode=Thumb, size=344, cc=10
i32 sub_fc81(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xfdd9, offset=0xfdd8, mode=Thumb, size=12, cc=1
i32 sub_fdd9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xfde5, offset=0xfde4, mode=Thumb, size=38, cc=1
i32 sub_fde5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xfe0d, offset=0xfe0c, mode=Thumb, size=342, cc=14
i32 sub_fe0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xff65, offset=0xff64, mode=Thumb, size=8, cc=1
i32 sub_ff65(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xff6d, offset=0xff6c, mode=Thumb, size=104, cc=7
i32 sub_ff6d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xffd5, offset=0xffd4, mode=Thumb, size=4, cc=1
i32 sub_ffd5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xffd9, offset=0xffd8, mode=Thumb, size=1314, cc=28
i32 sub_ffd9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10525, offset=0x10524, mode=Thumb, size=254, cc=17
i32 sub_10525(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10635, offset=0x10634, mode=Thumb, size=594, cc=16
i32 sub_10635(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10899, offset=0x10898, mode=Thumb, size=650, cc=26
i32 sub_10899(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10b49, offset=0x10b48, mode=Thumb, size=174, cc=6
i32 sub_10b49(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10c0d, offset=0x10c0c, mode=Thumb, size=540, cc=21
i32 sub_10c0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10e41, offset=0x10e40, mode=Thumb, size=256, cc=4
i32 sub_10e41(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10f41, offset=0x10f40, mode=Thumb, size=12, cc=1
i32 sub_10f41(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10f4d, offset=0x10f4c, mode=Thumb, size=766, cc=34
i32 sub_10f4d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11265, offset=0x11264, mode=Thumb, size=194, cc=6
i32 sub_11265(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11329, offset=0x11328, mode=Thumb, size=12, cc=1
i32 sub_11329(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11335, offset=0x11334, mode=Thumb, size=94, cc=8
i32 sub_11335(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11395, offset=0x11394, mode=Thumb, size=114, cc=10
i32 sub_11395(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11409, offset=0x11408, mode=Thumb, size=32, cc=1
i32 sub_11409(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11429, offset=0x11428, mode=Thumb, size=22, cc=1
i32 sub_11429(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11441, offset=0x11440, mode=Thumb, size=32, cc=1
i32 sub_11441(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11461, offset=0x11460, mode=Thumb, size=400, cc=12
i32 sub_11461(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1160d, offset=0x1160c, mode=Thumb, size=200, cc=6
i32 sub_1160d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x116d5, offset=0x116d4, mode=Thumb, size=94, cc=1
i32 sub_116d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11735, offset=0x11734, mode=Thumb, size=4, cc=1
i32 sub_11735(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11739, offset=0x11738, mode=Thumb, size=188, cc=2
i32 sub_11739(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x117f5, offset=0x117f4, mode=Thumb, size=12, cc=1
i32 sub_117f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11801, offset=0x11800, mode=Thumb, size=1008, cc=39
i32 sub_11801(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11c19, offset=0x11c18, mode=Thumb, size=8, cc=1
i32 sub_11c19(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x11c21, offset=0x11c20, mode=Thumb, size=1680, cc=91
i32 sub_11c21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x122ed, offset=0x122ec, mode=Thumb, size=396, cc=10
i32 sub_122ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x12491, offset=0x12490, mode=Thumb, size=250, cc=9
i32 sub_12491(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x125b9, offset=0x125b8, mode=Thumb, size=208, cc=6
i32 sub_125b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x12689, offset=0x12688, mode=Thumb, size=8, cc=1
i32 sub_12689(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x12691, offset=0x12690, mode=Thumb, size=670, cc=29
i32 sub_12691(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1297d, offset=0x1297c, mode=Thumb, size=652, cc=23
i32 sub_1297d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x12c39, offset=0x12c38, mode=Thumb, size=580, cc=20
i32 sub_12c39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x12ea1, offset=0x12ea0, mode=Thumb, size=118, cc=3
i32 sub_12ea1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x12f19, offset=0x12f18, mode=Thumb, size=4, cc=1
i32 sub_12f19(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x12f1d, offset=0x12f1c, mode=Thumb, size=42, cc=1
i32 sub_12f1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x12f49, offset=0x12f48, mode=Thumb, size=774, cc=25
i32 sub_12f49(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13251, offset=0x13250, mode=Thumb, size=70, cc=1
i32 sub_13251(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13257, offset=0x13256, mode=Thumb, size=2, cc=1
i32 sub_13257(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13259, offset=0x13258, mode=Thumb, size=1520, cc=83
i32 sub_13259(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x138c5, offset=0x138c4, mode=Thumb, size=152, cc=3
i32 sub_138c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1395d, offset=0x1395c, mode=Thumb, size=12, cc=1
i32 sub_1395d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13969, offset=0x13968, mode=Thumb, size=36, cc=1
i32 sub_13969(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1398d, offset=0x1398c, mode=Thumb, size=330, cc=17
i32 sub_1398d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13a89, offset=0x13a88, mode=Thumb, size=6, cc=1
i32 sub_13a89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13ab9, offset=0x13ab8, mode=Thumb, size=54, cc=1
i32 sub_13ab9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13aef, offset=0x13aee, mode=Thumb, size=26, cc=1
i32 sub_13aef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13b0b, offset=0x13b0a, mode=Thumb, size=44, cc=1
i32 sub_13b0b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13b37, offset=0x13b36, mode=Thumb, size=54, cc=1
i32 sub_13b37(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13ba9, offset=0x13ba8, mode=Thumb, size=34, cc=1
i32 sub_13ba9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x13bcd, offset=0x13bcc, mode=Thumb, size=1114, cc=49
i32 sub_13bcd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1405d, offset=0x1405c, mode=Thumb, size=28, cc=1
i32 sub_1405d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14079, offset=0x14078, mode=Thumb, size=478, cc=22
i32 sub_14079(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14279, offset=0x14278, mode=Thumb, size=118, cc=4
i32 sub_14279(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x142f1, offset=0x142f0, mode=Thumb, size=106, cc=2
i32 sub_142f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1435d, offset=0x1435c, mode=Thumb, size=100, cc=2
i32 sub_1435d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x143c1, offset=0x143c0, mode=Thumb, size=38, cc=1
i32 sub_143c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x143e9, offset=0x143e8, mode=Thumb, size=52, cc=1
i32 sub_143e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1441d, offset=0x1441c, mode=Thumb, size=4, cc=1
i32 sub_1441d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14421, offset=0x14420, mode=Thumb, size=340, cc=13
i32 sub_14421(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1459d, offset=0x1459c, mode=Thumb, size=794, cc=31
i32 sub_1459d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x148dd, offset=0x148dc, mode=Thumb, size=298, cc=17
i32 sub_148dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14a29, offset=0x14a28, mode=Thumb, size=72, cc=1
i32 sub_14a29(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14a71, offset=0x14a70, mode=Thumb, size=4, cc=1
i32 sub_14a71(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14a75, offset=0x14a74, mode=Thumb, size=112, cc=3
i32 sub_14a75(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14ae5, offset=0x14ae4, mode=Thumb, size=12, cc=1
i32 sub_14ae5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14af1, offset=0x14af0, mode=Thumb, size=466, cc=11
i32 sub_14af1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14ce1, offset=0x14ce0, mode=Thumb, size=348, cc=23
i32 sub_14ce1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14e6d, offset=0x14e6c, mode=Thumb, size=132, cc=4
i32 sub_14e6d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14ef1, offset=0x14ef0, mode=Thumb, size=164, cc=5
i32 sub_14ef1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14fa5, offset=0x14fa4, mode=Thumb, size=62, cc=3
i32 sub_14fa5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14fe5, offset=0x14fe4, mode=Thumb, size=4, cc=1
i32 sub_14fe5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x14fe9, offset=0x14fe8, mode=Thumb, size=558, cc=14
i32 sub_14fe9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15239, offset=0x15238, mode=Thumb, size=170, cc=4
i32 sub_15239(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x152e5, offset=0x152e4, mode=Thumb, size=4, cc=1
i32 sub_152e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x152e9, offset=0x152e8, mode=Thumb, size=22, cc=1
i32 sub_152e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15301, offset=0x15300, mode=Thumb, size=292, cc=19
i32 sub_15301(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1544d, offset=0x1544c, mode=Thumb, size=122, cc=9
i32 sub_1544d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x154cf, offset=0x154ce, mode=Thumb, size=6, cc=1
i32 sub_154cf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x154d5, offset=0x154d4, mode=Thumb, size=862, cc=13
i32 sub_154d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1585d, offset=0x1585c, mode=Thumb, size=1792, cc=83
i32 sub_1585d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15fc9, offset=0x15fc8, mode=Thumb, size=40, cc=1
i32 sub_15fc9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x15ff1, offset=0x15ff0, mode=Thumb, size=96, cc=2
i32 sub_15ff1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16051, offset=0x16050, mode=Thumb, size=294, cc=11
i32 sub_16051(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16199, offset=0x16198, mode=Thumb, size=138, cc=4
i32 sub_16199(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16225, offset=0x16224, mode=Thumb, size=8, cc=1
i32 sub_16225(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1622d, offset=0x1622c, mode=Thumb, size=168, cc=7
i32 sub_1622d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x162d5, offset=0x162d4, mode=Thumb, size=12, cc=1
i32 sub_162d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x162e1, offset=0x162e0, mode=Thumb, size=28, cc=1
i32 sub_162e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x162fd, offset=0x162fc, mode=Thumb, size=830, cc=31
i32 sub_162fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16675, offset=0x16674, mode=Thumb, size=28, cc=1
i32 sub_16675(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16691, offset=0x16690, mode=Thumb, size=978, cc=42
i32 sub_16691(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16a81, offset=0x16a80, mode=Thumb, size=1174, cc=61
i32 sub_16a81(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x16f9d, offset=0x16f9c, mode=Thumb, size=404, cc=21
i32 sub_16f9d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17161, offset=0x17160, mode=Thumb, size=54, cc=1
i32 sub_17161(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17199, offset=0x17198, mode=Thumb, size=4, cc=1
i32 sub_17199(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1719d, offset=0x1719c, mode=Thumb, size=24, cc=1
i32 sub_1719d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x171b5, offset=0x171b4, mode=Thumb, size=200, cc=11
i32 sub_171b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1727d, offset=0x1727c, mode=Thumb, size=12, cc=1
i32 sub_1727d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17289, offset=0x17288, mode=Thumb, size=22, cc=1
i32 sub_17289(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x172a1, offset=0x172a0, mode=Thumb, size=608, cc=33
i32 sub_172a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17521, offset=0x17520, mode=Thumb, size=54, cc=1
i32 sub_17521(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17559, offset=0x17558, mode=Thumb, size=4, cc=1
i32 sub_17559(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1755d, offset=0x1755c, mode=Thumb, size=164, cc=9
i32 sub_1755d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17601, offset=0x17600, mode=Thumb, size=12, cc=1
i32 sub_17601(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1760d, offset=0x1760c, mode=Thumb, size=400, cc=13
i32 sub_1760d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x177b1, offset=0x177b0, mode=Thumb, size=114, cc=3
i32 sub_177b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17825, offset=0x17824, mode=Thumb, size=8, cc=1
i32 sub_17825(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1782d, offset=0x1782c, mode=Thumb, size=100, cc=2
i32 sub_1782d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17897, offset=0x17896, mode=Thumb, size=2, cc=1
i32 sub_17897(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17899, offset=0x17898, mode=Thumb, size=354, cc=8
i32 sub_17899(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x179fd, offset=0x179fc, mode=Thumb, size=22, cc=1
i32 sub_179fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17a03, offset=0x17a02, mode=Thumb, size=2, cc=1
i32 sub_17a03(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17a05, offset=0x17a04, mode=Thumb, size=24, cc=1
i32 sub_17a05(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17a1d, offset=0x17a1c, mode=Thumb, size=326, cc=12
i32 sub_17a1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17b79, offset=0x17b78, mode=Thumb, size=632, cc=25
i32 sub_17b79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17e1d, offset=0x17e1c, mode=Thumb, size=332, cc=12
i32 sub_17e1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17f69, offset=0x17f68, mode=Thumb, size=22, cc=1
i32 sub_17f69(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x17f81, offset=0x17f80, mode=Thumb, size=1068, cc=35
i32 sub_17f81(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x183dd, offset=0x183dc, mode=Thumb, size=4, cc=1
i32 sub_183dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x183e1, offset=0x183e0, mode=Thumb, size=78, cc=6
i32 sub_183e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18431, offset=0x18430, mode=Thumb, size=8, cc=1
i32 sub_18431(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18439, offset=0x18438, mode=Thumb, size=478, cc=10
i32 sub_18439(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1862d, offset=0x1862c, mode=Thumb, size=446, cc=21
i32 sub_1862d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1880d, offset=0x1880c, mode=Thumb, size=52, cc=2
i32 sub_1880d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1885b, offset=0x1885a, mode=Thumb, size=30, cc=1
i32 sub_1885b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18879, offset=0x18878, mode=Thumb, size=4, cc=1
i32 sub_18879(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1887d, offset=0x1887c, mode=Thumb, size=242, cc=9
i32 sub_1887d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18971, offset=0x18970, mode=Thumb, size=8, cc=1
i32 sub_18971(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18979, offset=0x18978, mode=Thumb, size=370, cc=13
i32 sub_18979(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18b01, offset=0x18b00, mode=Thumb, size=104, cc=2
i32 sub_18b01(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18b69, offset=0x18b68, mode=Thumb, size=4, cc=1
i32 sub_18b69(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18b6d, offset=0x18b6c, mode=Thumb, size=1504, cc=71
i32 sub_18b6d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x191ad, offset=0x191ac, mode=Thumb, size=96, cc=1
i32 sub_191ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1920d, offset=0x1920c, mode=Thumb, size=8, cc=1
i32 sub_1920d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19215, offset=0x19214, mode=Thumb, size=144, cc=5
i32 sub_19215(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x192a5, offset=0x192a4, mode=Thumb, size=8, cc=1
i32 sub_192a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x192ad, offset=0x192ac, mode=Thumb, size=54, cc=1
i32 sub_192ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x192e5, offset=0x192e4, mode=Thumb, size=4, cc=1
i32 sub_192e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x192e9, offset=0x192e8, mode=Thumb, size=142, cc=3
i32 sub_192e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19379, offset=0x19378, mode=Thumb, size=8, cc=1
i32 sub_19379(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19381, offset=0x19380, mode=Thumb, size=108, cc=6
i32 sub_19381(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x193ed, offset=0x193ec, mode=Thumb, size=4, cc=1
i32 sub_193ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x193f1, offset=0x193f0, mode=Thumb, size=178, cc=6
i32 sub_193f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x194a7, offset=0x194a6, mode=Thumb, size=24, cc=1
i32 sub_194a7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x194c1, offset=0x194c0, mode=Thumb, size=138, cc=2
i32 sub_194c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1954d, offset=0x1954c, mode=Thumb, size=30, cc=1
i32 sub_1954d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1956d, offset=0x1956c, mode=Thumb, size=68, cc=1
i32 sub_1956d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x195b1, offset=0x195b0, mode=Thumb, size=4, cc=1
i32 sub_195b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x195b5, offset=0x195b4, mode=Thumb, size=154, cc=4
i32 sub_195b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19669, offset=0x19668, mode=Thumb, size=26, cc=1
i32 sub_19669(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19685, offset=0x19684, mode=Thumb, size=716, cc=34
i32 sub_19685(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19979, offset=0x19978, mode=Thumb, size=208, cc=6
i32 sub_19979(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19a61, offset=0x19a60, mode=Thumb, size=40, cc=1
i32 sub_19a61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19a89, offset=0x19a88, mode=Thumb, size=392, cc=16
i32 sub_19a89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19c11, offset=0x19c10, mode=Thumb, size=4, cc=1
i32 sub_19c11(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19c15, offset=0x19c14, mode=Thumb, size=314, cc=16
i32 sub_19c15(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19d65, offset=0x19d64, mode=Thumb, size=224, cc=5
i32 sub_19d65(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x19e65, offset=0x19e64, mode=Thumb, size=506, cc=21
i32 sub_19e65(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a071, offset=0x1a070, mode=Thumb, size=376, cc=13
i32 sub_1a071(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a201, offset=0x1a200, mode=Thumb, size=3414, cc=160
i32 sub_1a201(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a23b, offset=0x1a23a, mode=Thumb, size=4, cc=1
i32 sub_1a23b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a9c5, offset=0x1a9c4, mode=Thumb, size=14, cc=1
i32 sub_1a9c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1a9d3, offset=0x1a9d2, mode=Thumb, size=230, cc=7
i32 sub_1a9d3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1aaef, offset=0x1aaee, mode=Thumb, size=74, cc=3
i32 sub_1aaef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ab39, offset=0x1ab38, mode=Thumb, size=222, cc=7
i32 sub_1ab39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ac19, offset=0x1ac18, mode=Thumb, size=200, cc=7
i32 sub_1ac19(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b34d, offset=0x1b34c, mode=Thumb, size=376, cc=24
i32 sub_1b34d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b4e1, offset=0x1b4e0, mode=Thumb, size=198, cc=5
i32 sub_1b4e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b5a9, offset=0x1b5a8, mode=Thumb, size=214, cc=7
i32 sub_1b5a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b681, offset=0x1b680, mode=Thumb, size=38, cc=1
i32 sub_1b681(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1b6a9, offset=0x1b6a8, mode=Thumb, size=1364, cc=40
i32 sub_1b6a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1bc89, offset=0x1bc88, mode=Thumb, size=12, cc=1
i32 sub_1bc89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1bc95, offset=0x1bc94, mode=Thumb, size=116, cc=4
i32 sub_1bc95(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1bd09, offset=0x1bd08, mode=Thumb, size=44, cc=1
i32 sub_1bd09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1bd35, offset=0x1bd34, mode=Thumb, size=68, cc=8
i32 sub_1bd35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1bd79, offset=0x1bd78, mode=Thumb, size=100, cc=3
i32 sub_1bd79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1bded, offset=0x1bdec, mode=Thumb, size=272, cc=29
i32 sub_1bded(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1bf1d, offset=0x1bf1c, mode=Thumb, size=68, cc=2
i32 sub_1bf1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1bf61, offset=0x1bf60, mode=Thumb, size=2, cc=1
i32 sub_1bf61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1bf63, offset=0x1bf62, mode=Thumb, size=6, cc=1
i32 sub_1bf63(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1bf69, offset=0x1bf68, mode=Thumb, size=216, cc=10
i32 sub_1bf69(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c071, offset=0x1c070, mode=Thumb, size=72, cc=4
i32 sub_1c071(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c0c9, offset=0x1c0c8, mode=Thumb, size=210, cc=7
i32 sub_1c0c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c1b9, offset=0x1c1b8, mode=Thumb, size=184, cc=10
i32 sub_1c1b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c281, offset=0x1c280, mode=Thumb, size=134, cc=10
i32 sub_1c281(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c2d1, offset=0x1c2d0, mode=Thumb, size=70, cc=1
i32 sub_1c2d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c317, offset=0x1c316, mode=Thumb, size=86, cc=3
i32 sub_1c317(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c36d, offset=0x1c36c, mode=Thumb, size=86, cc=3
i32 sub_1c36d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c3c1, offset=0x1c3c0, mode=Thumb, size=52, cc=2
i32 sub_1c3c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c3f5, offset=0x1c3f4, mode=Thumb, size=62, cc=4
i32 sub_1c3f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c433, offset=0x1c432, mode=Thumb, size=34, cc=1
i32 sub_1c433(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c455, offset=0x1c454, mode=Thumb, size=22, cc=1
i32 sub_1c455(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c46b, offset=0x1c46a, mode=Thumb, size=82, cc=3
i32 sub_1c46b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c4f7, offset=0x1c4f6, mode=Thumb, size=4, cc=1
i32 sub_1c4f7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c529, offset=0x1c528, mode=Thumb, size=52, cc=3
i32 sub_1c529(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c55d, offset=0x1c55c, mode=Thumb, size=4, cc=1
i32 sub_1c55d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c561, offset=0x1c560, mode=Thumb, size=56, cc=4
i32 sub_1c561(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c599, offset=0x1c598, mode=Thumb, size=4, cc=1
i32 sub_1c599(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c59d, offset=0x1c59c, mode=Thumb, size=96, cc=4
i32 sub_1c59d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c615, offset=0x1c614, mode=Thumb, size=1348, cc=125
i32 sub_1c615(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1cbdd, offset=0x1cbdc, mode=Thumb, size=22, cc=1
i32 sub_1cbdd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1cbf5, offset=0x1cbf4, mode=Thumb, size=18, cc=2
i32 sub_1cbf5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1cc09, offset=0x1cc08, mode=Thumb, size=22, cc=2
i32 sub_1cc09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1cc21, offset=0x1cc20, mode=Thumb, size=270, cc=23
i32 sub_1cc21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1cd45, offset=0x1cd44, mode=Thumb, size=46, cc=5
i32 sub_1cd45(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1cd77, offset=0x1cd76, mode=Thumb, size=2, cc=1
i32 sub_1cd77(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1cd79, offset=0x1cd78, mode=Thumb, size=204, cc=16
i32 sub_1cd79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ce5f, offset=0x1ce5e, mode=Thumb, size=2, cc=1
i32 sub_1ce5f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ce61, offset=0x1ce60, mode=Thumb, size=80, cc=10
i32 sub_1ce61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ceb1, offset=0x1ceb0, mode=Thumb, size=114, cc=9
i32 sub_1ceb1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1cf39, offset=0x1cf38, mode=Thumb, size=130, cc=8
i32 sub_1cf39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1cfc5, offset=0x1cfc4, mode=Thumb, size=4, cc=1
i32 sub_1cfc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1cfc9, offset=0x1cfc8, mode=Thumb, size=52, cc=3
i32 sub_1cfc9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d01d, offset=0x1d01c, mode=Thumb, size=1028, cc=59
i32 sub_1d01d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d465, offset=0x1d464, mode=Thumb, size=102, cc=5
i32 sub_1d465(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d4cd, offset=0x1d4cc, mode=Thumb, size=452, cc=43
i32 sub_1d4cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d6d9, offset=0x1d6d8, mode=Thumb, size=212, cc=20
i32 sub_1d6d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d7c5, offset=0x1d7c4, mode=Thumb, size=4, cc=1
i32 sub_1d7c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d7c9, offset=0x1d7c8, mode=Thumb, size=92, cc=3
i32 sub_1d7c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d825, offset=0x1d824, mode=Thumb, size=26, cc=1
i32 sub_1d825(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d841, offset=0x1d840, mode=Thumb, size=8, cc=1
i32 sub_1d841(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d849, offset=0x1d848, mode=Thumb, size=52, cc=4
i32 sub_1d849(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d87d, offset=0x1d87c, mode=Thumb, size=4, cc=1
i32 sub_1d87d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d881, offset=0x1d880, mode=Thumb, size=48, cc=3
i32 sub_1d881(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d8b1, offset=0x1d8b0, mode=Thumb, size=8, cc=1
i32 sub_1d8b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d8b9, offset=0x1d8b8, mode=Thumb, size=70, cc=5
i32 sub_1d8b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d901, offset=0x1d900, mode=Thumb, size=8, cc=1
i32 sub_1d901(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d909, offset=0x1d908, mode=Thumb, size=78, cc=6
i32 sub_1d909(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d959, offset=0x1d958, mode=Thumb, size=2, cc=1
i32 sub_1d959(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d95b, offset=0x1d95a, mode=Thumb, size=4, cc=1
i32 sub_1d95b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d95f, offset=0x1d95e, mode=Thumb, size=2, cc=1
i32 sub_1d95f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d961, offset=0x1d960, mode=Thumb, size=146, cc=10
i32 sub_1d961(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d9f5, offset=0x1d9f4, mode=Thumb, size=4, cc=1
i32 sub_1d9f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1d9f9, offset=0x1d9f8, mode=Thumb, size=76, cc=8
i32 sub_1d9f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1da45, offset=0x1da44, mode=Thumb, size=136, cc=16
i32 sub_1da45(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1daf1, offset=0x1daf0, mode=Thumb, size=116, cc=5
i32 sub_1daf1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1db65, offset=0x1db64, mode=Thumb, size=8, cc=1
i32 sub_1db65(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1db6d, offset=0x1db6c, mode=Thumb, size=224, cc=19
i32 sub_1db6d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1dc61, offset=0x1dc60, mode=Thumb, size=52, cc=2
i32 sub_1dc61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1dca5, offset=0x1dca4, mode=Thumb, size=102, cc=8
i32 sub_1dca5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1dd0d, offset=0x1dd0c, mode=Thumb, size=4, cc=1
i32 sub_1dd0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1dd11, offset=0x1dd10, mode=Thumb, size=38, cc=2
i32 sub_1dd11(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1dd39, offset=0x1dd38, mode=Thumb, size=38, cc=2
i32 sub_1dd39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1dd61, offset=0x1dd60, mode=Thumb, size=30, cc=1
i32 sub_1dd61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1dd81, offset=0x1dd80, mode=Thumb, size=6, cc=1
i32 sub_1dd81(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1dd87, offset=0x1dd86, mode=Thumb, size=6, cc=1
i32 sub_1dd87(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1dd8d, offset=0x1dd8c, mode=Thumb, size=6, cc=1
i32 sub_1dd8d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1dd93, offset=0x1dd92, mode=Thumb, size=6, cc=1
i32 sub_1dd93(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ddad, offset=0x1ddac, mode=Thumb, size=52, cc=1
i32 sub_1ddad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1dde1, offset=0x1dde0, mode=Thumb, size=94, cc=8
i32 sub_1dde1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1de51, offset=0x1de50, mode=Thumb, size=92, cc=3
i32 sub_1de51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1dead, offset=0x1deac, mode=Thumb, size=36, cc=2
i32 sub_1dead(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1deb5, offset=0x1deb4, mode=Thumb, size=16, cc=1
i32 sub_1deb5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1dec5, offset=0x1dec4, mode=Thumb, size=38, cc=1
i32 sub_1dec5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1df09, offset=0x1df08, mode=Thumb, size=56, cc=4
i32 sub_1df09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1df41, offset=0x1df40, mode=Thumb, size=18, cc=1
i32 sub_1df41(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1df55, offset=0x1df54, mode=Thumb, size=4, cc=1
i32 sub_1df55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1df59, offset=0x1df58, mode=Thumb, size=638, cc=2
i32 sub_1df59(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e1d7, offset=0x1e1d6, mode=Thumb, size=14, cc=2
i32 sub_1e1d7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e1e5, offset=0x1e1e4, mode=Thumb, size=14, cc=2
i32 sub_1e1e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e1f3, offset=0x1e1f2, mode=Thumb, size=14, cc=2
i32 sub_1e1f3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e201, offset=0x1e200, mode=Thumb, size=14, cc=2
i32 sub_1e201(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e20f, offset=0x1e20e, mode=Thumb, size=14, cc=2
i32 sub_1e20f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e21d, offset=0x1e21c, mode=Thumb, size=14, cc=2
i32 sub_1e21d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e22b, offset=0x1e22a, mode=Thumb, size=14, cc=2
i32 sub_1e22b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e239, offset=0x1e238, mode=Thumb, size=14, cc=2
i32 sub_1e239(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e247, offset=0x1e246, mode=Thumb, size=14, cc=2
i32 sub_1e247(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e255, offset=0x1e254, mode=Thumb, size=14, cc=2
i32 sub_1e255(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e263, offset=0x1e262, mode=Thumb, size=14, cc=2
i32 sub_1e263(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e271, offset=0x1e270, mode=Thumb, size=14, cc=2
i32 sub_1e271(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e27f, offset=0x1e27e, mode=Thumb, size=14, cc=2
i32 sub_1e27f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e28d, offset=0x1e28c, mode=Thumb, size=14, cc=2
i32 sub_1e28d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e29b, offset=0x1e29a, mode=Thumb, size=14, cc=2
i32 sub_1e29b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e2a9, offset=0x1e2a8, mode=Thumb, size=14, cc=2
i32 sub_1e2a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e2b7, offset=0x1e2b6, mode=Thumb, size=14, cc=2
i32 sub_1e2b7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e2c5, offset=0x1e2c4, mode=Thumb, size=14, cc=2
i32 sub_1e2c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e2d3, offset=0x1e2d2, mode=Thumb, size=14, cc=2
i32 sub_1e2d3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e2e1, offset=0x1e2e0, mode=Thumb, size=16, cc=2
i32 sub_1e2e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e2f1, offset=0x1e2f0, mode=Thumb, size=14, cc=2
i32 sub_1e2f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e2ff, offset=0x1e2fe, mode=Thumb, size=14, cc=2
i32 sub_1e2ff(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e30d, offset=0x1e30c, mode=Thumb, size=14, cc=2
i32 sub_1e30d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e31b, offset=0x1e31a, mode=Thumb, size=14, cc=2
i32 sub_1e31b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e329, offset=0x1e328, mode=Thumb, size=14, cc=2
i32 sub_1e329(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e337, offset=0x1e336, mode=Thumb, size=14, cc=2
i32 sub_1e337(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e345, offset=0x1e344, mode=Thumb, size=14, cc=2
i32 sub_1e345(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e353, offset=0x1e352, mode=Thumb, size=14, cc=2
i32 sub_1e353(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e361, offset=0x1e360, mode=Thumb, size=14, cc=2
i32 sub_1e361(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e36f, offset=0x1e36e, mode=Thumb, size=14, cc=2
i32 sub_1e36f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e37d, offset=0x1e37c, mode=Thumb, size=14, cc=2
i32 sub_1e37d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e38b, offset=0x1e38a, mode=Thumb, size=14, cc=2
i32 sub_1e38b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e399, offset=0x1e398, mode=Thumb, size=14, cc=2
i32 sub_1e399(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e3a7, offset=0x1e3a6, mode=Thumb, size=14, cc=2
i32 sub_1e3a7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e3b5, offset=0x1e3b4, mode=Thumb, size=16, cc=2
i32 sub_1e3b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e3c5, offset=0x1e3c4, mode=Thumb, size=14, cc=2
i32 sub_1e3c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e3d3, offset=0x1e3d2, mode=Thumb, size=14, cc=2
i32 sub_1e3d3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e3e1, offset=0x1e3e0, mode=Thumb, size=14, cc=2
i32 sub_1e3e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e3ef, offset=0x1e3ee, mode=Thumb, size=14, cc=2
i32 sub_1e3ef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e3fd, offset=0x1e3fc, mode=Thumb, size=14, cc=2
i32 sub_1e3fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e40b, offset=0x1e40a, mode=Thumb, size=14, cc=2
i32 sub_1e40b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e419, offset=0x1e418, mode=Thumb, size=14, cc=2
i32 sub_1e419(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e427, offset=0x1e426, mode=Thumb, size=14, cc=2
i32 sub_1e427(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e435, offset=0x1e434, mode=Thumb, size=14, cc=2
i32 sub_1e435(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e443, offset=0x1e442, mode=Thumb, size=14, cc=2
i32 sub_1e443(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e451, offset=0x1e450, mode=Thumb, size=14, cc=2
i32 sub_1e451(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e45f, offset=0x1e45e, mode=Thumb, size=16, cc=2
i32 sub_1e45f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e46f, offset=0x1e46e, mode=Thumb, size=14, cc=2
i32 sub_1e46f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e47d, offset=0x1e47c, mode=Thumb, size=14, cc=2
i32 sub_1e47d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e48b, offset=0x1e48a, mode=Thumb, size=14, cc=2
i32 sub_1e48b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e499, offset=0x1e498, mode=Thumb, size=14, cc=2
i32 sub_1e499(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e4a7, offset=0x1e4a6, mode=Thumb, size=14, cc=2
i32 sub_1e4a7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e4b5, offset=0x1e4b4, mode=Thumb, size=14, cc=2
i32 sub_1e4b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e4c3, offset=0x1e4c2, mode=Thumb, size=14, cc=2
i32 sub_1e4c3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e4d1, offset=0x1e4d0, mode=Thumb, size=14, cc=2
i32 sub_1e4d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e4df, offset=0x1e4de, mode=Thumb, size=14, cc=2
i32 sub_1e4df(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e4ed, offset=0x1e4ec, mode=Thumb, size=14, cc=2
i32 sub_1e4ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e4fb, offset=0x1e4fa, mode=Thumb, size=14, cc=2
i32 sub_1e4fb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e509, offset=0x1e508, mode=Thumb, size=14, cc=2
i32 sub_1e509(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e517, offset=0x1e516, mode=Thumb, size=14, cc=2
i32 sub_1e517(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e525, offset=0x1e524, mode=Thumb, size=14, cc=2
i32 sub_1e525(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e533, offset=0x1e532, mode=Thumb, size=14, cc=2
i32 sub_1e533(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e541, offset=0x1e540, mode=Thumb, size=14, cc=2
i32 sub_1e541(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e54f, offset=0x1e54e, mode=Thumb, size=14, cc=2
i32 sub_1e54f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e55d, offset=0x1e55c, mode=Thumb, size=14, cc=2
i32 sub_1e55d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e56b, offset=0x1e56a, mode=Thumb, size=14, cc=2
i32 sub_1e56b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e579, offset=0x1e578, mode=Thumb, size=16, cc=2
i32 sub_1e579(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e685, offset=0x1e684, mode=Thumb, size=14, cc=2
i32 sub_1e685(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e693, offset=0x1e692, mode=Thumb, size=14, cc=2
i32 sub_1e693(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e6a1, offset=0x1e6a0, mode=Thumb, size=14, cc=2
i32 sub_1e6a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e6af, offset=0x1e6ae, mode=Thumb, size=14, cc=2
i32 sub_1e6af(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e6bd, offset=0x1e6bc, mode=Thumb, size=14, cc=2
i32 sub_1e6bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e6cb, offset=0x1e6ca, mode=Thumb, size=14, cc=2
i32 sub_1e6cb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e6d9, offset=0x1e6d8, mode=Thumb, size=14, cc=2
i32 sub_1e6d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e6e7, offset=0x1e6e6, mode=Thumb, size=14, cc=2
i32 sub_1e6e7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e6f5, offset=0x1e6f4, mode=Thumb, size=14, cc=2
i32 sub_1e6f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e703, offset=0x1e702, mode=Thumb, size=14, cc=2
i32 sub_1e703(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e711, offset=0x1e710, mode=Thumb, size=14, cc=2
i32 sub_1e711(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e71f, offset=0x1e71e, mode=Thumb, size=14, cc=2
i32 sub_1e71f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e72d, offset=0x1e72c, mode=Thumb, size=14, cc=2
i32 sub_1e72d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e73b, offset=0x1e73a, mode=Thumb, size=14, cc=2
i32 sub_1e73b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e749, offset=0x1e748, mode=Thumb, size=14, cc=2
i32 sub_1e749(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e757, offset=0x1e756, mode=Thumb, size=14, cc=2
i32 sub_1e757(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e765, offset=0x1e764, mode=Thumb, size=14, cc=2
i32 sub_1e765(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e773, offset=0x1e772, mode=Thumb, size=14, cc=2
i32 sub_1e773(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e781, offset=0x1e780, mode=Thumb, size=14, cc=2
i32 sub_1e781(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e78f, offset=0x1e78e, mode=Thumb, size=14, cc=2
i32 sub_1e78f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e79d, offset=0x1e79c, mode=Thumb, size=14, cc=2
i32 sub_1e79d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e7ab, offset=0x1e7aa, mode=Thumb, size=14, cc=2
i32 sub_1e7ab(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e7b9, offset=0x1e7b8, mode=Thumb, size=14, cc=2
i32 sub_1e7b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e7c7, offset=0x1e7c6, mode=Thumb, size=14, cc=2
i32 sub_1e7c7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e7d5, offset=0x1e7d4, mode=Thumb, size=14, cc=2
i32 sub_1e7d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e7e3, offset=0x1e7e2, mode=Thumb, size=14, cc=2
i32 sub_1e7e3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e7f1, offset=0x1e7f0, mode=Thumb, size=14, cc=2
i32 sub_1e7f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e7ff, offset=0x1e7fe, mode=Thumb, size=14, cc=2
i32 sub_1e7ff(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e80d, offset=0x1e80c, mode=Thumb, size=14, cc=2
i32 sub_1e80d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e81b, offset=0x1e81a, mode=Thumb, size=14, cc=2
i32 sub_1e81b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e829, offset=0x1e828, mode=Thumb, size=14, cc=2
i32 sub_1e829(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e837, offset=0x1e836, mode=Thumb, size=14, cc=2
i32 sub_1e837(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e845, offset=0x1e844, mode=Thumb, size=14, cc=2
i32 sub_1e845(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e853, offset=0x1e852, mode=Thumb, size=14, cc=2
i32 sub_1e853(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e861, offset=0x1e860, mode=Thumb, size=14, cc=2
i32 sub_1e861(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e86f, offset=0x1e86e, mode=Thumb, size=14, cc=2
i32 sub_1e86f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e87d, offset=0x1e87c, mode=Thumb, size=14, cc=2
i32 sub_1e87d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e88b, offset=0x1e88a, mode=Thumb, size=14, cc=2
i32 sub_1e88b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e899, offset=0x1e898, mode=Thumb, size=14, cc=2
i32 sub_1e899(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e8a7, offset=0x1e8a6, mode=Thumb, size=14, cc=2
i32 sub_1e8a7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e8b5, offset=0x1e8b4, mode=Thumb, size=14, cc=2
i32 sub_1e8b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e8c3, offset=0x1e8c2, mode=Thumb, size=14, cc=2
i32 sub_1e8c3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e8d1, offset=0x1e8d0, mode=Thumb, size=14, cc=2
i32 sub_1e8d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e8df, offset=0x1e8de, mode=Thumb, size=14, cc=2
i32 sub_1e8df(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e8ed, offset=0x1e8ec, mode=Thumb, size=14, cc=2
i32 sub_1e8ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e8fb, offset=0x1e8fa, mode=Thumb, size=14, cc=2
i32 sub_1e8fb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e909, offset=0x1e908, mode=Thumb, size=14, cc=2
i32 sub_1e909(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e917, offset=0x1e916, mode=Thumb, size=14, cc=2
i32 sub_1e917(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e925, offset=0x1e924, mode=Thumb, size=14, cc=2
i32 sub_1e925(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e933, offset=0x1e932, mode=Thumb, size=14, cc=2
i32 sub_1e933(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e941, offset=0x1e940, mode=Thumb, size=14, cc=2
i32 sub_1e941(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e94f, offset=0x1e94e, mode=Thumb, size=14, cc=2
i32 sub_1e94f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e95d, offset=0x1e95c, mode=Thumb, size=14, cc=2
i32 sub_1e95d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e96b, offset=0x1e96a, mode=Thumb, size=14, cc=2
i32 sub_1e96b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e979, offset=0x1e978, mode=Thumb, size=14, cc=2
i32 sub_1e979(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e987, offset=0x1e986, mode=Thumb, size=16, cc=2
i32 sub_1e987(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e997, offset=0x1e996, mode=Thumb, size=14, cc=2
i32 sub_1e997(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e9a5, offset=0x1e9a4, mode=Thumb, size=16, cc=2
i32 sub_1e9a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e9b5, offset=0x1e9b4, mode=Thumb, size=14, cc=2
i32 sub_1e9b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e9c3, offset=0x1e9c2, mode=Thumb, size=14, cc=2
i32 sub_1e9c3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e9d1, offset=0x1e9d0, mode=Thumb, size=14, cc=2
i32 sub_1e9d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e9df, offset=0x1e9de, mode=Thumb, size=14, cc=2
i32 sub_1e9df(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e9ed, offset=0x1e9ec, mode=Thumb, size=14, cc=2
i32 sub_1e9ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1e9fb, offset=0x1e9fa, mode=Thumb, size=14, cc=2
i32 sub_1e9fb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ea09, offset=0x1ea08, mode=Thumb, size=14, cc=2
i32 sub_1ea09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ea17, offset=0x1ea16, mode=Thumb, size=14, cc=2
i32 sub_1ea17(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eb25, offset=0x1eb24, mode=Thumb, size=14, cc=2
i32 sub_1eb25(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eb33, offset=0x1eb32, mode=Thumb, size=14, cc=2
i32 sub_1eb33(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eb41, offset=0x1eb40, mode=Thumb, size=14, cc=2
i32 sub_1eb41(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eb4f, offset=0x1eb4e, mode=Thumb, size=14, cc=2
i32 sub_1eb4f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eb5d, offset=0x1eb5c, mode=Thumb, size=14, cc=2
i32 sub_1eb5d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eb6b, offset=0x1eb6a, mode=Thumb, size=14, cc=2
i32 sub_1eb6b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eb79, offset=0x1eb78, mode=Thumb, size=14, cc=2
i32 sub_1eb79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eb87, offset=0x1eb86, mode=Thumb, size=14, cc=2
i32 sub_1eb87(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eb95, offset=0x1eb94, mode=Thumb, size=14, cc=2
i32 sub_1eb95(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eba3, offset=0x1eba2, mode=Thumb, size=14, cc=2
i32 sub_1eba3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ebb1, offset=0x1ebb0, mode=Thumb, size=14, cc=2
i32 sub_1ebb1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ebbf, offset=0x1ebbe, mode=Thumb, size=14, cc=2
i32 sub_1ebbf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ebcd, offset=0x1ebcc, mode=Thumb, size=14, cc=2
i32 sub_1ebcd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ebdb, offset=0x1ebda, mode=Thumb, size=14, cc=2
i32 sub_1ebdb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ebe9, offset=0x1ebe8, mode=Thumb, size=14, cc=2
i32 sub_1ebe9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ebf7, offset=0x1ebf6, mode=Thumb, size=14, cc=2
i32 sub_1ebf7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ec05, offset=0x1ec04, mode=Thumb, size=14, cc=2
i32 sub_1ec05(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ec13, offset=0x1ec12, mode=Thumb, size=14, cc=2
i32 sub_1ec13(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ec21, offset=0x1ec20, mode=Thumb, size=14, cc=2
i32 sub_1ec21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ec2f, offset=0x1ec2e, mode=Thumb, size=14, cc=2
i32 sub_1ec2f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ec3d, offset=0x1ec3c, mode=Thumb, size=14, cc=2
i32 sub_1ec3d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ec4b, offset=0x1ec4a, mode=Thumb, size=14, cc=2
i32 sub_1ec4b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ec59, offset=0x1ec58, mode=Thumb, size=14, cc=2
i32 sub_1ec59(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ec67, offset=0x1ec66, mode=Thumb, size=14, cc=2
i32 sub_1ec67(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ec75, offset=0x1ec74, mode=Thumb, size=14, cc=2
i32 sub_1ec75(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ec83, offset=0x1ec82, mode=Thumb, size=14, cc=2
i32 sub_1ec83(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ec91, offset=0x1ec90, mode=Thumb, size=14, cc=2
i32 sub_1ec91(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ec9f, offset=0x1ec9e, mode=Thumb, size=14, cc=2
i32 sub_1ec9f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ecad, offset=0x1ecac, mode=Thumb, size=16, cc=2
i32 sub_1ecad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ecbd, offset=0x1ecbc, mode=Thumb, size=16, cc=2
i32 sub_1ecbd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eccd, offset=0x1eccc, mode=Thumb, size=14, cc=2
i32 sub_1eccd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ecdb, offset=0x1ecda, mode=Thumb, size=16, cc=2
i32 sub_1ecdb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eceb, offset=0x1ecea, mode=Thumb, size=14, cc=2
i32 sub_1eceb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ecf9, offset=0x1ecf8, mode=Thumb, size=16, cc=2
i32 sub_1ecf9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ed09, offset=0x1ed08, mode=Thumb, size=16, cc=2
i32 sub_1ed09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ed19, offset=0x1ed18, mode=Thumb, size=16, cc=2
i32 sub_1ed19(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ed29, offset=0x1ed28, mode=Thumb, size=14, cc=2
i32 sub_1ed29(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ed37, offset=0x1ed36, mode=Thumb, size=14, cc=2
i32 sub_1ed37(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ed45, offset=0x1ed44, mode=Thumb, size=14, cc=2
i32 sub_1ed45(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ed53, offset=0x1ed52, mode=Thumb, size=14, cc=2
i32 sub_1ed53(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ed61, offset=0x1ed60, mode=Thumb, size=16, cc=2
i32 sub_1ed61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ed71, offset=0x1ed70, mode=Thumb, size=14, cc=2
i32 sub_1ed71(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ed7f, offset=0x1ed7e, mode=Thumb, size=14, cc=2
i32 sub_1ed7f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ed8d, offset=0x1ed8c, mode=Thumb, size=14, cc=2
i32 sub_1ed8d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ed9b, offset=0x1ed9a, mode=Thumb, size=14, cc=2
i32 sub_1ed9b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eda9, offset=0x1eda8, mode=Thumb, size=16, cc=2
i32 sub_1eda9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1edb9, offset=0x1edb8, mode=Thumb, size=14, cc=2
i32 sub_1edb9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1edc7, offset=0x1edc6, mode=Thumb, size=14, cc=2
i32 sub_1edc7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1edd5, offset=0x1edd4, mode=Thumb, size=14, cc=2
i32 sub_1edd5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ede3, offset=0x1ede2, mode=Thumb, size=14, cc=2
i32 sub_1ede3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1edf1, offset=0x1edf0, mode=Thumb, size=14, cc=2
i32 sub_1edf1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1edff, offset=0x1edfe, mode=Thumb, size=14, cc=2
i32 sub_1edff(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ee0d, offset=0x1ee0c, mode=Thumb, size=14, cc=2
i32 sub_1ee0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ee1b, offset=0x1ee1a, mode=Thumb, size=14, cc=2
i32 sub_1ee1b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ee29, offset=0x1ee28, mode=Thumb, size=14, cc=2
i32 sub_1ee29(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ee37, offset=0x1ee36, mode=Thumb, size=14, cc=2
i32 sub_1ee37(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ee45, offset=0x1ee44, mode=Thumb, size=14, cc=2
i32 sub_1ee45(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ee53, offset=0x1ee52, mode=Thumb, size=14, cc=2
i32 sub_1ee53(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ee61, offset=0x1ee60, mode=Thumb, size=14, cc=2
i32 sub_1ee61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ee6f, offset=0x1ee6e, mode=Thumb, size=14, cc=2
i32 sub_1ee6f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ee7d, offset=0x1ee7c, mode=Thumb, size=14, cc=2
i32 sub_1ee7d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ee8b, offset=0x1ee8a, mode=Thumb, size=14, cc=2
i32 sub_1ee8b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1ee99, offset=0x1ee98, mode=Thumb, size=14, cc=2
i32 sub_1ee99(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eea7, offset=0x1eea6, mode=Thumb, size=14, cc=2
i32 sub_1eea7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eeb5, offset=0x1eeb4, mode=Thumb, size=14, cc=2
i32 sub_1eeb5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eec3, offset=0x1eec2, mode=Thumb, size=14, cc=2
i32 sub_1eec3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1efb9, offset=0x1efb8, mode=Thumb, size=14, cc=2
i32 sub_1efb9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1efc7, offset=0x1efc6, mode=Thumb, size=14, cc=2
i32 sub_1efc7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1efd5, offset=0x1efd4, mode=Thumb, size=14, cc=2
i32 sub_1efd5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1efe3, offset=0x1efe2, mode=Thumb, size=14, cc=2
i32 sub_1efe3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1eff1, offset=0x1eff0, mode=Thumb, size=14, cc=2
i32 sub_1eff1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1efff, offset=0x1effe, mode=Thumb, size=14, cc=2
i32 sub_1efff(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f00d, offset=0x1f00c, mode=Thumb, size=14, cc=2
i32 sub_1f00d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f01b, offset=0x1f01a, mode=Thumb, size=14, cc=2
i32 sub_1f01b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f029, offset=0x1f028, mode=Thumb, size=14, cc=2
i32 sub_1f029(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f037, offset=0x1f036, mode=Thumb, size=14, cc=2
i32 sub_1f037(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f045, offset=0x1f044, mode=Thumb, size=14, cc=2
i32 sub_1f045(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f053, offset=0x1f052, mode=Thumb, size=14, cc=2
i32 sub_1f053(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f061, offset=0x1f060, mode=Thumb, size=14, cc=2
i32 sub_1f061(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f06f, offset=0x1f06e, mode=Thumb, size=14, cc=2
i32 sub_1f06f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f07d, offset=0x1f07c, mode=Thumb, size=14, cc=2
i32 sub_1f07d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f08b, offset=0x1f08a, mode=Thumb, size=14, cc=2
i32 sub_1f08b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f099, offset=0x1f098, mode=Thumb, size=14, cc=2
i32 sub_1f099(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f0a7, offset=0x1f0a6, mode=Thumb, size=14, cc=2
i32 sub_1f0a7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f0b5, offset=0x1f0b4, mode=Thumb, size=14, cc=2
i32 sub_1f0b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f0c3, offset=0x1f0c2, mode=Thumb, size=14, cc=2
i32 sub_1f0c3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f0d1, offset=0x1f0d0, mode=Thumb, size=14, cc=2
i32 sub_1f0d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f0df, offset=0x1f0de, mode=Thumb, size=14, cc=2
i32 sub_1f0df(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f0ed, offset=0x1f0ec, mode=Thumb, size=14, cc=2
i32 sub_1f0ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f0fb, offset=0x1f0fa, mode=Thumb, size=14, cc=2
i32 sub_1f0fb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f109, offset=0x1f108, mode=Thumb, size=14, cc=2
i32 sub_1f109(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f117, offset=0x1f116, mode=Thumb, size=14, cc=2
i32 sub_1f117(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f125, offset=0x1f124, mode=Thumb, size=14, cc=2
i32 sub_1f125(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f133, offset=0x1f132, mode=Thumb, size=14, cc=2
i32 sub_1f133(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f141, offset=0x1f140, mode=Thumb, size=14, cc=2
i32 sub_1f141(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f14f, offset=0x1f14e, mode=Thumb, size=14, cc=2
i32 sub_1f14f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f15d, offset=0x1f15c, mode=Thumb, size=14, cc=2
i32 sub_1f15d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f16b, offset=0x1f16a, mode=Thumb, size=14, cc=2
i32 sub_1f16b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f179, offset=0x1f178, mode=Thumb, size=14, cc=2
i32 sub_1f179(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f187, offset=0x1f186, mode=Thumb, size=14, cc=2
i32 sub_1f187(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f195, offset=0x1f194, mode=Thumb, size=14, cc=2
i32 sub_1f195(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f1a3, offset=0x1f1a2, mode=Thumb, size=14, cc=2
i32 sub_1f1a3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f1b1, offset=0x1f1b0, mode=Thumb, size=14, cc=2
i32 sub_1f1b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f1bf, offset=0x1f1be, mode=Thumb, size=14, cc=2
i32 sub_1f1bf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f1cd, offset=0x1f1cc, mode=Thumb, size=14, cc=2
i32 sub_1f1cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f1db, offset=0x1f1da, mode=Thumb, size=14, cc=2
i32 sub_1f1db(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f1e9, offset=0x1f1e8, mode=Thumb, size=14, cc=2
i32 sub_1f1e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f1f7, offset=0x1f1f6, mode=Thumb, size=16, cc=2
i32 sub_1f1f7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f207, offset=0x1f206, mode=Thumb, size=16, cc=2
i32 sub_1f207(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f217, offset=0x1f216, mode=Thumb, size=14, cc=2
i32 sub_1f217(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f225, offset=0x1f224, mode=Thumb, size=14, cc=2
i32 sub_1f225(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f233, offset=0x1f232, mode=Thumb, size=14, cc=2
i32 sub_1f233(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f241, offset=0x1f240, mode=Thumb, size=14, cc=2
i32 sub_1f241(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f24f, offset=0x1f24e, mode=Thumb, size=14, cc=2
i32 sub_1f24f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f25d, offset=0x1f25c, mode=Thumb, size=14, cc=2
i32 sub_1f25d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f26b, offset=0x1f26a, mode=Thumb, size=14, cc=2
i32 sub_1f26b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f279, offset=0x1f278, mode=Thumb, size=14, cc=2
i32 sub_1f279(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f287, offset=0x1f286, mode=Thumb, size=14, cc=2
i32 sub_1f287(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f295, offset=0x1f294, mode=Thumb, size=14, cc=2
i32 sub_1f295(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f2a3, offset=0x1f2a2, mode=Thumb, size=14, cc=2
i32 sub_1f2a3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f2b1, offset=0x1f2b0, mode=Thumb, size=14, cc=2
i32 sub_1f2b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f2bf, offset=0x1f2be, mode=Thumb, size=14, cc=2
i32 sub_1f2bf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f2cd, offset=0x1f2cc, mode=Thumb, size=14, cc=2
i32 sub_1f2cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f2db, offset=0x1f2da, mode=Thumb, size=16, cc=2
i32 sub_1f2db(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f2eb, offset=0x1f2ea, mode=Thumb, size=16, cc=2
i32 sub_1f2eb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f2fb, offset=0x1f2fa, mode=Thumb, size=16, cc=2
i32 sub_1f2fb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f30b, offset=0x1f30a, mode=Thumb, size=16, cc=2
i32 sub_1f30b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f31b, offset=0x1f31a, mode=Thumb, size=14, cc=2
i32 sub_1f31b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f329, offset=0x1f328, mode=Thumb, size=14, cc=2
i32 sub_1f329(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f337, offset=0x1f336, mode=Thumb, size=14, cc=2
i32 sub_1f337(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f345, offset=0x1f344, mode=Thumb, size=16, cc=2
i32 sub_1f345(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f355, offset=0x1f354, mode=Thumb, size=16, cc=2
i32 sub_1f355(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f44d, offset=0x1f44c, mode=Thumb, size=14, cc=2
i32 sub_1f44d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f45b, offset=0x1f45a, mode=Thumb, size=14, cc=2
i32 sub_1f45b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f469, offset=0x1f468, mode=Thumb, size=14, cc=2
i32 sub_1f469(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f477, offset=0x1f476, mode=Thumb, size=14, cc=2
i32 sub_1f477(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f485, offset=0x1f484, mode=Thumb, size=16, cc=2
i32 sub_1f485(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f495, offset=0x1f494, mode=Thumb, size=16, cc=2
i32 sub_1f495(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f4a5, offset=0x1f4a4, mode=Thumb, size=16, cc=2
i32 sub_1f4a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f4b5, offset=0x1f4b4, mode=Thumb, size=14, cc=2
i32 sub_1f4b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f4c3, offset=0x1f4c2, mode=Thumb, size=14, cc=2
i32 sub_1f4c3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f4d1, offset=0x1f4d0, mode=Thumb, size=16, cc=2
i32 sub_1f4d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f4e1, offset=0x1f4e0, mode=Thumb, size=16, cc=2
i32 sub_1f4e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f4f1, offset=0x1f4f0, mode=Thumb, size=14, cc=2
i32 sub_1f4f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f4ff, offset=0x1f4fe, mode=Thumb, size=14, cc=2
i32 sub_1f4ff(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f50d, offset=0x1f50c, mode=Thumb, size=14, cc=2
i32 sub_1f50d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f51b, offset=0x1f51a, mode=Thumb, size=14, cc=2
i32 sub_1f51b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f529, offset=0x1f528, mode=Thumb, size=14, cc=2
i32 sub_1f529(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f537, offset=0x1f536, mode=Thumb, size=16, cc=2
i32 sub_1f537(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f547, offset=0x1f546, mode=Thumb, size=14, cc=2
i32 sub_1f547(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f555, offset=0x1f554, mode=Thumb, size=16, cc=2
i32 sub_1f555(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f565, offset=0x1f564, mode=Thumb, size=14, cc=2
i32 sub_1f565(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f573, offset=0x1f572, mode=Thumb, size=14, cc=2
i32 sub_1f573(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f581, offset=0x1f580, mode=Thumb, size=14, cc=2
i32 sub_1f581(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f58f, offset=0x1f58e, mode=Thumb, size=14, cc=2
i32 sub_1f58f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f59d, offset=0x1f59c, mode=Thumb, size=14, cc=2
i32 sub_1f59d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f5ab, offset=0x1f5aa, mode=Thumb, size=14, cc=2
i32 sub_1f5ab(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f5b9, offset=0x1f5b8, mode=Thumb, size=16, cc=2
i32 sub_1f5b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f5c9, offset=0x1f5c8, mode=Thumb, size=14, cc=2
i32 sub_1f5c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f5d7, offset=0x1f5d6, mode=Thumb, size=14, cc=2
i32 sub_1f5d7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f5e5, offset=0x1f5e4, mode=Thumb, size=14, cc=2
i32 sub_1f5e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f5f3, offset=0x1f5f2, mode=Thumb, size=14, cc=2
i32 sub_1f5f3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f601, offset=0x1f600, mode=Thumb, size=14, cc=2
i32 sub_1f601(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f60f, offset=0x1f60e, mode=Thumb, size=14, cc=2
i32 sub_1f60f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f61d, offset=0x1f61c, mode=Thumb, size=14, cc=2
i32 sub_1f61d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f62b, offset=0x1f62a, mode=Thumb, size=14, cc=2
i32 sub_1f62b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f639, offset=0x1f638, mode=Thumb, size=14, cc=2
i32 sub_1f639(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f647, offset=0x1f646, mode=Thumb, size=14, cc=2
i32 sub_1f647(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f655, offset=0x1f654, mode=Thumb, size=14, cc=2
i32 sub_1f655(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f663, offset=0x1f662, mode=Thumb, size=14, cc=2
i32 sub_1f663(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f671, offset=0x1f670, mode=Thumb, size=14, cc=2
i32 sub_1f671(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f67f, offset=0x1f67e, mode=Thumb, size=14, cc=2
i32 sub_1f67f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f68d, offset=0x1f68c, mode=Thumb, size=14, cc=2
i32 sub_1f68d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f69b, offset=0x1f69a, mode=Thumb, size=14, cc=2
i32 sub_1f69b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f6a9, offset=0x1f6a8, mode=Thumb, size=4, cc=1
i32 sub_1f6a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f735, offset=0x1f734, mode=Thumb, size=120, cc=7
i32 sub_1f735(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f7ad, offset=0x1f7ac, mode=Thumb, size=8, cc=1
i32 sub_1f7ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f7b5, offset=0x1f7b4, mode=Thumb, size=134, cc=15
i32 sub_1f7b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f861, offset=0x1f860, mode=Thumb, size=54, cc=3
i32 sub_1f861(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f899, offset=0x1f898, mode=Thumb, size=4, cc=1
i32 sub_1f899(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f89d, offset=0x1f89c, mode=Thumb, size=94, cc=7
i32 sub_1f89d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f8fd, offset=0x1f8fc, mode=Thumb, size=4, cc=1
i32 sub_1f8fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f901, offset=0x1f900, mode=Thumb, size=42, cc=4
i32 sub_1f901(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f92d, offset=0x1f92c, mode=Thumb, size=106, cc=9
i32 sub_1f92d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f999, offset=0x1f998, mode=Thumb, size=4, cc=1
i32 sub_1f999(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f99d, offset=0x1f99c, mode=Thumb, size=56, cc=4
i32 sub_1f99d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f9d5, offset=0x1f9d4, mode=Thumb, size=4, cc=1
i32 sub_1f9d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1f9d9, offset=0x1f9d8, mode=Thumb, size=42, cc=4
i32 sub_1f9d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1fa05, offset=0x1fa04, mode=Thumb, size=146, cc=7
i32 sub_1fa05(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1fa99, offset=0x1fa98, mode=Thumb, size=8, cc=1
i32 sub_1fa99(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1faa1, offset=0x1faa0, mode=Thumb, size=96, cc=7
i32 sub_1faa1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1fb01, offset=0x1fb00, mode=Thumb, size=4, cc=1
i32 sub_1fb01(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1fb05, offset=0x1fb04, mode=Thumb, size=104, cc=5
i32 sub_1fb05(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1fb81, offset=0x1fb80, mode=Thumb, size=26, cc=1
i32 sub_1fb81(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1fb9d, offset=0x1fb9c, mode=Thumb, size=4, cc=1
i32 sub_1fb9d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1fba1, offset=0x1fba0, mode=Thumb, size=70, cc=3
i32 sub_1fba1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1fbe9, offset=0x1fbe8, mode=Thumb, size=924, cc=81
i32 sub_1fbe9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20001, offset=0x20000, mode=Thumb, size=184, cc=4
i32 sub_20001(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20121, offset=0x20120, mode=Thumb, size=96, cc=4
i32 sub_20121(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20191, offset=0x20190, mode=Thumb, size=12, cc=1
i32 sub_20191(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2019d, offset=0x2019c, mode=Thumb, size=24, cc=1
i32 sub_2019d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x201b5, offset=0x201b4, mode=Thumb, size=8, cc=1
i32 sub_201b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x201bd, offset=0x201bc, mode=Thumb, size=12, cc=1
i32 sub_201bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x201c9, offset=0x201c8, mode=Thumb, size=4, cc=1
i32 sub_201c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x201cd, offset=0x201cc, mode=Thumb, size=6, cc=1
i32 sub_201cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x201d5, offset=0x201d4, mode=Thumb, size=204, cc=20
i32 sub_201d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x202cd, offset=0x202cc, mode=Thumb, size=4, cc=1
i32 sub_202cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x202d1, offset=0x202d0, mode=Thumb, size=4, cc=1
i32 sub_202d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x202d5, offset=0x202d4, mode=Thumb, size=16, cc=2
i32 sub_202d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x202e5, offset=0x202e4, mode=Thumb, size=8, cc=1
i32 sub_202e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x202ed, offset=0x202ec, mode=Thumb, size=4, cc=1
i32 sub_202ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x202f1, offset=0x202f0, mode=Thumb, size=4, cc=1
i32 sub_202f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x202f5, offset=0x202f4, mode=Thumb, size=4, cc=1
i32 sub_202f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x202f9, offset=0x202f8, mode=Thumb, size=4, cc=1
i32 sub_202f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x202fd, offset=0x202fc, mode=Thumb, size=4, cc=1
i32 sub_202fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20301, offset=0x20300, mode=Thumb, size=4, cc=1
i32 sub_20301(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20305, offset=0x20304, mode=Thumb, size=74, cc=4
i32 sub_20305(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20351, offset=0x20350, mode=Thumb, size=8, cc=1
i32 sub_20351(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20359, offset=0x20358, mode=Thumb, size=72, cc=7
i32 sub_20359(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x203a1, offset=0x203a0, mode=Thumb, size=4, cc=1
i32 sub_203a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x203a5, offset=0x203a4, mode=Thumb, size=148, cc=10
i32 sub_203a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20439, offset=0x20438, mode=Thumb, size=4, cc=1
i32 sub_20439(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2043d, offset=0x2043c, mode=Thumb, size=60, cc=5
i32 sub_2043d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20479, offset=0x20478, mode=Thumb, size=8, cc=1
i32 sub_20479(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20481, offset=0x20480, mode=Thumb, size=236, cc=13
i32 sub_20481(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20585, offset=0x20584, mode=Thumb, size=4, cc=1
i32 sub_20585(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20589, offset=0x20588, mode=Thumb, size=10, cc=1
i32 sub_20589(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20595, offset=0x20594, mode=Thumb, size=78, cc=4
i32 sub_20595(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x205e5, offset=0x205e4, mode=Thumb, size=72, cc=4
i32 sub_205e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2062d, offset=0x2062c, mode=Thumb, size=4, cc=1
i32 sub_2062d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20631, offset=0x20630, mode=Thumb, size=48, cc=4
i32 sub_20631(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20661, offset=0x20660, mode=Thumb, size=46, cc=4
i32 sub_20661(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20691, offset=0x20690, mode=Thumb, size=74, cc=5
i32 sub_20691(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x206e5, offset=0x206e4, mode=Thumb, size=46, cc=1
i32 sub_206e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2071b, offset=0x2071a, mode=Thumb, size=2, cc=1
i32 sub_2071b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2071d, offset=0x2071c, mode=Thumb, size=66, cc=3
i32 sub_2071d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20779, offset=0x20778, mode=Thumb, size=50, cc=3
i32 sub_20779(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x207bd, offset=0x207bc, mode=Thumb, size=14, cc=1
i32 sub_207bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x207cd, offset=0x207cc, mode=Thumb, size=64, cc=2
i32 sub_207cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20819, offset=0x20818, mode=Thumb, size=134, cc=14
i32 sub_20819(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x208a1, offset=0x208a0, mode=Thumb, size=12, cc=1
i32 sub_208a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x208ad, offset=0x208ac, mode=Thumb, size=70, cc=8
i32 sub_208ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x208f5, offset=0x208f4, mode=Thumb, size=54, cc=5
i32 sub_208f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2092d, offset=0x2092c, mode=Thumb, size=64, cc=4
i32 sub_2092d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20979, offset=0x20978, mode=Thumb, size=76, cc=6
i32 sub_20979(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x209c5, offset=0x209c4, mode=Thumb, size=106, cc=4
i32 sub_209c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20a31, offset=0x20a30, mode=Thumb, size=4, cc=1
i32 sub_20a31(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20a35, offset=0x20a34, mode=Thumb, size=52, cc=4
i32 sub_20a35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20a69, offset=0x20a68, mode=Thumb, size=4, cc=1
i32 sub_20a69(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20a6d, offset=0x20a6c, mode=Thumb, size=44, cc=2
i32 sub_20a6d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20aad, offset=0x20aac, mode=Thumb, size=24, cc=1
i32 sub_20aad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20ac5, offset=0x20ac4, mode=Thumb, size=52, cc=4
i32 sub_20ac5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20af9, offset=0x20af8, mode=Thumb, size=4, cc=1
i32 sub_20af9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20afd, offset=0x20afc, mode=Thumb, size=94, cc=1
i32 sub_20afd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20b71, offset=0x20b70, mode=Thumb, size=8, cc=1
i32 sub_20b71(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20b79, offset=0x20b78, mode=Thumb, size=4, cc=1
i32 sub_20b79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20b7d, offset=0x20b7c, mode=Thumb, size=8, cc=1
i32 sub_20b7d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20b85, offset=0x20b84, mode=Thumb, size=4, cc=1
i32 sub_20b85(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20b89, offset=0x20b88, mode=Thumb, size=26, cc=2
i32 sub_20b89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20ba5, offset=0x20ba4, mode=Thumb, size=8, cc=1
i32 sub_20ba5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20bad, offset=0x20bac, mode=Thumb, size=4, cc=1
i32 sub_20bad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20bb1, offset=0x20bb0, mode=Thumb, size=42, cc=4
i32 sub_20bb1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20bdd, offset=0x20bdc, mode=Thumb, size=728, cc=68
i32 sub_20bdd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20f01, offset=0x20f00, mode=Thumb, size=164, cc=12
i32 sub_20f01(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20fa5, offset=0x20fa4, mode=Thumb, size=18, cc=2
i32 sub_20fa5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20fb9, offset=0x20fb8, mode=Thumb, size=4, cc=1
i32 sub_20fb9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20fbd, offset=0x20fbc, mode=Thumb, size=316, cc=16
i32 sub_20fbd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x210f9, offset=0x210f8, mode=Thumb, size=8, cc=1
i32 sub_210f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21101, offset=0x21100, mode=Thumb, size=46, cc=4
i32 sub_21101(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21131, offset=0x21130, mode=Thumb, size=4, cc=1
i32 sub_21131(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21135, offset=0x21134, mode=Thumb, size=4, cc=1
i32 sub_21135(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21139, offset=0x21138, mode=Thumb, size=134, cc=9
i32 sub_21139(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x211c1, offset=0x211c0, mode=Thumb, size=46, cc=8
i32 sub_211c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x211f1, offset=0x211f0, mode=Thumb, size=4, cc=1
i32 sub_211f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x211f5, offset=0x211f4, mode=Thumb, size=46, cc=3
i32 sub_211f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21225, offset=0x21224, mode=Thumb, size=18, cc=1
i32 sub_21225(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21239, offset=0x21238, mode=Thumb, size=4, cc=1
i32 sub_21239(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2123d, offset=0x2123c, mode=Thumb, size=24, cc=2
i32 sub_2123d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21255, offset=0x21254, mode=Thumb, size=8, cc=1
i32 sub_21255(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2125d, offset=0x2125c, mode=Thumb, size=62, cc=5
i32 sub_2125d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2129d, offset=0x2129c, mode=Thumb, size=8, cc=1
i32 sub_2129d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x212a5, offset=0x212a4, mode=Thumb, size=46, cc=2
i32 sub_212a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x212ed, offset=0x212ec, mode=Thumb, size=56, cc=5
i32 sub_212ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21325, offset=0x21324, mode=Thumb, size=4, cc=1
i32 sub_21325(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21329, offset=0x21328, mode=Thumb, size=58, cc=4
i32 sub_21329(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21365, offset=0x21364, mode=Thumb, size=48, cc=3
i32 sub_21365(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21395, offset=0x21394, mode=Thumb, size=756, cc=58
i32 sub_21395(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x216c1, offset=0x216c0, mode=Thumb, size=72, cc=2
i32 sub_216c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21709, offset=0x21708, mode=Thumb, size=4, cc=1
i32 sub_21709(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2170d, offset=0x2170c, mode=Thumb, size=222, cc=18
i32 sub_2170d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21805, offset=0x21804, mode=Thumb, size=510, cc=20
i32 sub_21805(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21a15, offset=0x21a14, mode=Thumb, size=554, cc=20
i32 sub_21a15(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21c51, offset=0x21c50, mode=Thumb, size=558, cc=20
i32 sub_21c51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x21e91, offset=0x21e90, mode=Thumb, size=516, cc=20
i32 sub_21e91(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x220a5, offset=0x220a4, mode=Thumb, size=92, cc=4
i32 sub_220a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22111, offset=0x22110, mode=Thumb, size=206, cc=12
i32 sub_22111(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22209, offset=0x22208, mode=Thumb, size=16, cc=1
i32 sub_22209(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22219, offset=0x22218, mode=Thumb, size=4, cc=1
i32 sub_22219(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2221d, offset=0x2221c, mode=Thumb, size=198, cc=16
i32 sub_2221d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x222f9, offset=0x222f8, mode=Thumb, size=24, cc=1
i32 sub_222f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22311, offset=0x22310, mode=Thumb, size=8, cc=1
i32 sub_22311(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22319, offset=0x22318, mode=Thumb, size=32, cc=1
i32 sub_22319(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22339, offset=0x22338, mode=Thumb, size=4, cc=1
i32 sub_22339(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2233d, offset=0x2233c, mode=Thumb, size=126, cc=5
i32 sub_2233d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x223d9, offset=0x223d8, mode=Thumb, size=94, cc=1
i32 sub_223d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22455, offset=0x22454, mode=Thumb, size=178, cc=5
i32 sub_22455(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22545, offset=0x22544, mode=Thumb, size=32, cc=1
i32 sub_22545(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22565, offset=0x22564, mode=Thumb, size=52, cc=3
i32 sub_22565(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2256b, offset=0x2256a, mode=Thumb, size=2, cc=1
i32 sub_2256b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2256d, offset=0x2256c, mode=Thumb, size=464, cc=37
i32 sub_2256d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x227c9, offset=0x227c8, mode=Thumb, size=66, cc=2
i32 sub_227c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22805, offset=0x22804, mode=Thumb, size=124, cc=7
i32 sub_22805(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22881, offset=0x22880, mode=Thumb, size=72, cc=4
i32 sub_22881(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x228cb, offset=0x228ca, mode=Thumb, size=188, cc=13
i32 sub_228cb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22989, offset=0x22988, mode=Thumb, size=34, cc=1
i32 sub_22989(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x229d5, offset=0x229d4, mode=Thumb, size=184, cc=13
i32 sub_229d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22a8f, offset=0x22a8e, mode=Thumb, size=298, cc=23
i32 sub_22a8f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22c5b, offset=0x22c5a, mode=Thumb, size=170, cc=11
i32 sub_22c5b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22d05, offset=0x22d04, mode=Thumb, size=74, cc=3
i32 sub_22d05(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x22d79, offset=0x22d78, mode=Thumb, size=880, cc=24
i32 sub_22d79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23171, offset=0x23170, mode=Thumb, size=32, cc=3
i32 sub_23171(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23191, offset=0x23190, mode=Thumb, size=8, cc=1
i32 sub_23191(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23199, offset=0x23198, mode=Thumb, size=30, cc=1
i32 sub_23199(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x231b9, offset=0x231b8, mode=Thumb, size=8, cc=1
i32 sub_231b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x231c1, offset=0x231c0, mode=Thumb, size=108, cc=4
i32 sub_231c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23249, offset=0x23248, mode=Thumb, size=40, cc=1
i32 sub_23249(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23271, offset=0x23270, mode=Thumb, size=12, cc=1
i32 sub_23271(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2327d, offset=0x2327c, mode=Thumb, size=98, cc=1
i32 sub_2327d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x232f5, offset=0x232f4, mode=Thumb, size=72, cc=2
i32 sub_232f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2333d, offset=0x2333c, mode=Thumb, size=8, cc=1
i32 sub_2333d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23345, offset=0x23344, mode=Thumb, size=78, cc=3
i32 sub_23345(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23395, offset=0x23394, mode=Thumb, size=12, cc=1
i32 sub_23395(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x233a1, offset=0x233a0, mode=Thumb, size=22, cc=1
i32 sub_233a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x233b9, offset=0x233b8, mode=Thumb, size=8, cc=1
i32 sub_233b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x233c1, offset=0x233c0, mode=Thumb, size=38, cc=1
i32 sub_233c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x233e9, offset=0x233e8, mode=Thumb, size=2, cc=1
i32 sub_233e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x233eb, offset=0x233ea, mode=Thumb, size=2, cc=1
i32 sub_233eb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x233ed, offset=0x233ec, mode=Thumb, size=60, cc=2
i32 sub_233ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23441, offset=0x23440, mode=Thumb, size=38, cc=2
i32 sub_23441(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23479, offset=0x23478, mode=Thumb, size=380, cc=21
i32 sub_23479(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23625, offset=0x23624, mode=Thumb, size=52, cc=3
i32 sub_23625(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23659, offset=0x23658, mode=Thumb, size=12, cc=1
i32 sub_23659(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23665, offset=0x23664, mode=Thumb, size=426, cc=38
i32 sub_23665(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2380f, offset=0x2380e, mode=Thumb, size=116, cc=7
i32 sub_2380f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x238ed, offset=0x238ec, mode=Thumb, size=50, cc=2
i32 sub_238ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23921, offset=0x23920, mode=Thumb, size=8, cc=1
i32 sub_23921(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23929, offset=0x23928, mode=Thumb, size=66, cc=1
i32 sub_23929(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2397d, offset=0x2397c, mode=Thumb, size=32, cc=1
i32 sub_2397d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2399d, offset=0x2399c, mode=Thumb, size=8, cc=1
i32 sub_2399d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x239a5, offset=0x239a4, mode=Thumb, size=50, cc=1
i32 sub_239a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x239d9, offset=0x239d8, mode=Thumb, size=2, cc=1
i32 sub_239d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x239db, offset=0x239da, mode=Thumb, size=10, cc=1
i32 sub_239db(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x239e5, offset=0x239e4, mode=Thumb, size=64, cc=3
i32 sub_239e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23a25, offset=0x23a24, mode=Thumb, size=12, cc=1
i32 sub_23a25(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23a31, offset=0x23a30, mode=Thumb, size=46, cc=1
i32 sub_23a31(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23a79, offset=0x23a78, mode=Thumb, size=28, cc=1
i32 sub_23a79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23a95, offset=0x23a94, mode=Thumb, size=12, cc=1
i32 sub_23a95(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23aa1, offset=0x23aa0, mode=Thumb, size=36, cc=1
i32 sub_23aa1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23ac5, offset=0x23ac4, mode=Thumb, size=8, cc=1
i32 sub_23ac5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23acd, offset=0x23acc, mode=Thumb, size=24, cc=1
i32 sub_23acd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23ae5, offset=0x23ae4, mode=Thumb, size=4, cc=1
i32 sub_23ae5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23ae9, offset=0x23ae8, mode=Thumb, size=138, cc=4
i32 sub_23ae9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23b91, offset=0x23b90, mode=Thumb, size=212, cc=12
i32 sub_23b91(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23c8d, offset=0x23c8c, mode=Thumb, size=378, cc=9
i32 sub_23c8d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x23e0b, offset=0x23e0a, mode=Thumb, size=866, cc=50
i32 sub_23e0b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24241, offset=0x24240, mode=Thumb, size=698, cc=68
i32 sub_24241(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24575, offset=0x24574, mode=Thumb, size=30, cc=1
i32 sub_24575(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24595, offset=0x24594, mode=Thumb, size=12, cc=1
i32 sub_24595(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x245a1, offset=0x245a0, mode=Thumb, size=38, cc=1
i32 sub_245a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x245c9, offset=0x245c8, mode=Thumb, size=12, cc=1
i32 sub_245c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x245d5, offset=0x245d4, mode=Thumb, size=60, cc=1
i32 sub_245d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24621, offset=0x24620, mode=Thumb, size=28, cc=1
i32 sub_24621(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2463d, offset=0x2463c, mode=Thumb, size=4, cc=1
i32 sub_2463d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24641, offset=0x24640, mode=Thumb, size=64, cc=1
i32 sub_24641(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24691, offset=0x24690, mode=Thumb, size=118, cc=6
i32 sub_24691(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2471d, offset=0x2471c, mode=Thumb, size=810, cc=43
i32 sub_2471d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24a51, offset=0x24a50, mode=Thumb, size=32, cc=3
i32 sub_24a51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24a75, offset=0x24a74, mode=Thumb, size=46, cc=2
i32 sub_24a75(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24aa5, offset=0x24aa4, mode=Thumb, size=4, cc=1
i32 sub_24aa5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24aa9, offset=0x24aa8, mode=Thumb, size=570, cc=40
i32 sub_24aa9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24cf5, offset=0x24cf4, mode=Thumb, size=682, cc=38
i32 sub_24cf5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24fb9, offset=0x24fb8, mode=Thumb, size=946, cc=67
i32 sub_24fb9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25389, offset=0x25388, mode=Thumb, size=330, cc=12
i32 sub_25389(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25509, offset=0x25508, mode=Thumb, size=42, cc=3
i32 sub_25509(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25535, offset=0x25534, mode=Thumb, size=8, cc=1
i32 sub_25535(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2553d, offset=0x2553c, mode=Thumb, size=70, cc=1
i32 sub_2553d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25585, offset=0x25584, mode=Thumb, size=12, cc=1
i32 sub_25585(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25591, offset=0x25590, mode=Thumb, size=244, cc=14
i32 sub_25591(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x256c5, offset=0x256c4, mode=Thumb, size=24, cc=1
i32 sub_256c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x256dd, offset=0x256dc, mode=Thumb, size=4, cc=1
i32 sub_256dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x256e1, offset=0x256e0, mode=Thumb, size=708, cc=29
i32 sub_256e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x259b5, offset=0x259b4, mode=Thumb, size=52, cc=5
i32 sub_259b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x259e9, offset=0x259e8, mode=Thumb, size=4, cc=1
i32 sub_259e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x259ed, offset=0x259ec, mode=Thumb, size=60, cc=3
i32 sub_259ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25a41, offset=0x25a40, mode=Thumb, size=332, cc=26
i32 sub_25a41(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25bdd, offset=0x25bdc, mode=Thumb, size=38, cc=3
i32 sub_25bdd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25c05, offset=0x25c04, mode=Thumb, size=18, cc=1
i32 sub_25c05(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25c19, offset=0x25c18, mode=Thumb, size=4, cc=1
i32 sub_25c19(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25c1d, offset=0x25c1c, mode=Thumb, size=340, cc=12
i32 sub_25c1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25da1, offset=0x25da0, mode=Thumb, size=36, cc=3
i32 sub_25da1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25dc5, offset=0x25dc4, mode=Thumb, size=4, cc=1
i32 sub_25dc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25dc9, offset=0x25dc8, mode=Thumb, size=290, cc=9
i32 sub_25dc9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x25f21, offset=0x25f20, mode=Thumb, size=904, cc=23
i32 sub_25f21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26309, offset=0x26308, mode=Thumb, size=420, cc=23
i32 sub_26309(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26531, offset=0x26530, mode=Thumb, size=28, cc=1
i32 sub_26531(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2654d, offset=0x2654c, mode=Thumb, size=8, cc=1
i32 sub_2654d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26555, offset=0x26554, mode=Thumb, size=34, cc=1
i32 sub_26555(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26579, offset=0x26578, mode=Thumb, size=8, cc=1
i32 sub_26579(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26581, offset=0x26580, mode=Thumb, size=130, cc=10
i32 sub_26581(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26605, offset=0x26604, mode=Thumb, size=12, cc=1
i32 sub_26605(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26611, offset=0x26610, mode=Thumb, size=52, cc=4
i32 sub_26611(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26645, offset=0x26644, mode=Thumb, size=4, cc=1
i32 sub_26645(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26649, offset=0x26648, mode=Thumb, size=80, cc=7
i32 sub_26649(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26699, offset=0x26698, mode=Thumb, size=8, cc=1
i32 sub_26699(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x266a1, offset=0x266a0, mode=Thumb, size=18, cc=1
i32 sub_266a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x266b5, offset=0x266b4, mode=Thumb, size=4, cc=1
i32 sub_266b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x266b9, offset=0x266b8, mode=Thumb, size=46, cc=2
i32 sub_266b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x266e9, offset=0x266e8, mode=Thumb, size=8, cc=1
i32 sub_266e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x266f1, offset=0x266f0, mode=Thumb, size=196, cc=21
i32 sub_266f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x267d1, offset=0x267d0, mode=Thumb, size=126, cc=5
i32 sub_267d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26851, offset=0x26850, mode=Thumb, size=8, cc=1
i32 sub_26851(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26859, offset=0x26858, mode=Thumb, size=134, cc=10
i32 sub_26859(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x268f9, offset=0x268f8, mode=Thumb, size=36, cc=3
i32 sub_268f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2691d, offset=0x2691c, mode=Thumb, size=4, cc=1
i32 sub_2691d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26921, offset=0x26920, mode=Thumb, size=272, cc=32
i32 sub_26921(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26a31, offset=0x26a30, mode=Thumb, size=12, cc=1
i32 sub_26a31(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26a3d, offset=0x26a3c, mode=Thumb, size=94, cc=17
i32 sub_26a3d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26a9d, offset=0x26a9c, mode=Thumb, size=32, cc=1
i32 sub_26a9d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26abd, offset=0x26abc, mode=Thumb, size=20, cc=1
i32 sub_26abd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26ad1, offset=0x26ad0, mode=Thumb, size=4, cc=1
i32 sub_26ad1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26ad5, offset=0x26ad4, mode=Thumb, size=12, cc=1
i32 sub_26ad5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26ae1, offset=0x26ae0, mode=Thumb, size=52, cc=3
i32 sub_26ae1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26b15, offset=0x26b14, mode=Thumb, size=90, cc=9
i32 sub_26b15(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26b89, offset=0x26b88, mode=Thumb, size=92, cc=7
i32 sub_26b89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26be5, offset=0x26be4, mode=Thumb, size=4, cc=1
i32 sub_26be5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26be9, offset=0x26be8, mode=Thumb, size=70, cc=6
i32 sub_26be9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26c31, offset=0x26c30, mode=Thumb, size=50, cc=4
i32 sub_26c31(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26c65, offset=0x26c64, mode=Thumb, size=4, cc=1
i32 sub_26c65(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26c69, offset=0x26c68, mode=Thumb, size=334, cc=39
i32 sub_26c69(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26e09, offset=0x26e08, mode=Thumb, size=52, cc=5
i32 sub_26e09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26e3d, offset=0x26e3c, mode=Thumb, size=56, cc=5
i32 sub_26e3d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26e75, offset=0x26e74, mode=Thumb, size=4, cc=1
i32 sub_26e75(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26e79, offset=0x26e78, mode=Thumb, size=18, cc=2
i32 sub_26e79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26e8d, offset=0x26e8c, mode=Thumb, size=26, cc=1
i32 sub_26e8d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26ea9, offset=0x26ea8, mode=Thumb, size=4, cc=1
i32 sub_26ea9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26ead, offset=0x26eac, mode=Thumb, size=26, cc=1
i32 sub_26ead(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26ec9, offset=0x26ec8, mode=Thumb, size=4, cc=1
i32 sub_26ec9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26ecd, offset=0x26ecc, mode=Thumb, size=40, cc=3
i32 sub_26ecd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26ef5, offset=0x26ef4, mode=Thumb, size=4, cc=1
i32 sub_26ef5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26ef9, offset=0x26ef8, mode=Thumb, size=24, cc=2
i32 sub_26ef9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26f11, offset=0x26f10, mode=Thumb, size=4, cc=1
i32 sub_26f11(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26f15, offset=0x26f14, mode=Thumb, size=224, cc=17
i32 sub_26f15(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26ff5, offset=0x26ff4, mode=Thumb, size=8, cc=1
i32 sub_26ff5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x26ffd, offset=0x26ffc, mode=Thumb, size=278, cc=25
i32 sub_26ffd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27115, offset=0x27114, mode=Thumb, size=8, cc=1
i32 sub_27115(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2711d, offset=0x2711c, mode=Thumb, size=30, cc=1
i32 sub_2711d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2713d, offset=0x2713c, mode=Thumb, size=4, cc=1
i32 sub_2713d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27141, offset=0x27140, mode=Thumb, size=20, cc=1
i32 sub_27141(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27155, offset=0x27154, mode=Thumb, size=4, cc=1
i32 sub_27155(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27159, offset=0x27158, mode=Thumb, size=78, cc=3
i32 sub_27159(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x271b9, offset=0x271b8, mode=Thumb, size=54, cc=3
i32 sub_271b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x271f1, offset=0x271f0, mode=Thumb, size=4, cc=1
i32 sub_271f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x271f5, offset=0x271f4, mode=Thumb, size=56, cc=7
i32 sub_271f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2722d, offset=0x2722c, mode=Thumb, size=4, cc=1
i32 sub_2722d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27231, offset=0x27230, mode=Thumb, size=126, cc=16
i32 sub_27231(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x272b1, offset=0x272b0, mode=Thumb, size=16, cc=1
i32 sub_272b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x272b7, offset=0x272b6, mode=Thumb, size=2, cc=1
i32 sub_272b7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x272b9, offset=0x272b8, mode=Thumb, size=34, cc=1
i32 sub_272b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x272dd, offset=0x272dc, mode=Thumb, size=4, cc=1
i32 sub_272dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x272e1, offset=0x272e0, mode=Thumb, size=30, cc=2
i32 sub_272e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27301, offset=0x27300, mode=Thumb, size=26, cc=1
i32 sub_27301(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2731d, offset=0x2731c, mode=Thumb, size=4, cc=1
i32 sub_2731d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27321, offset=0x27320, mode=Thumb, size=54, cc=4
i32 sub_27321(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27359, offset=0x27358, mode=Thumb, size=12, cc=1
i32 sub_27359(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27365, offset=0x27364, mode=Thumb, size=650, cc=53
i32 sub_27365(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27405, offset=0x27404, mode=Thumb, size=24, cc=1
i32 sub_27405(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x274c7, offset=0x274c6, mode=Thumb, size=14, cc=2
i32 sub_274c7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2751d, offset=0x2751c, mode=Thumb, size=30, cc=1
i32 sub_2751d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27599, offset=0x27598, mode=Thumb, size=62, cc=2
i32 sub_27599(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27601, offset=0x27600, mode=Thumb, size=24, cc=1
i32 sub_27601(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27619, offset=0x27618, mode=Thumb, size=30, cc=1
i32 sub_27619(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27637, offset=0x27636, mode=Thumb, size=30, cc=1
i32 sub_27637(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27655, offset=0x27654, mode=Thumb, size=24, cc=1
i32 sub_27655(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2766d, offset=0x2766c, mode=Thumb, size=30, cc=1
i32 sub_2766d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27735, offset=0x27734, mode=Thumb, size=46, cc=4
i32 sub_27735(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27765, offset=0x27764, mode=Thumb, size=8, cc=1
i32 sub_27765(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2776d, offset=0x2776c, mode=Thumb, size=172, cc=14
i32 sub_2776d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27831, offset=0x27830, mode=Thumb, size=4, cc=1
i32 sub_27831(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27835, offset=0x27834, mode=Thumb, size=204, cc=16
i32 sub_27835(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27919, offset=0x27918, mode=Thumb, size=8, cc=1
i32 sub_27919(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27921, offset=0x27920, mode=Thumb, size=622, cc=50
i32 sub_27921(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x279ad, offset=0x279ac, mode=Thumb, size=14, cc=1
i32 sub_279ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x279bb, offset=0x279ba, mode=Thumb, size=2, cc=1
i32 sub_279bb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x279d5, offset=0x279d4, mode=Thumb, size=16, cc=1
i32 sub_279d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x279e5, offset=0x279e4, mode=Thumb, size=2, cc=1
i32 sub_279e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27a39, offset=0x27a38, mode=Thumb, size=14, cc=1
i32 sub_27a39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27a47, offset=0x27a46, mode=Thumb, size=2, cc=1
i32 sub_27a47(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27a81, offset=0x27a80, mode=Thumb, size=30, cc=1
i32 sub_27a81(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27a9f, offset=0x27a9e, mode=Thumb, size=2, cc=1
i32 sub_27a9f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27ac9, offset=0x27ac8, mode=Thumb, size=94, cc=1
i32 sub_27ac9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27b27, offset=0x27b26, mode=Thumb, size=2, cc=1
i32 sub_27b27(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27b29, offset=0x27b28, mode=Thumb, size=32, cc=1
i32 sub_27b29(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27b4b, offset=0x27b4a, mode=Thumb, size=30, cc=1
i32 sub_27b4b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27b69, offset=0x27b68, mode=Thumb, size=30, cc=1
i32 sub_27b69(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27b87, offset=0x27b86, mode=Thumb, size=30, cc=1
i32 sub_27b87(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27ba5, offset=0x27ba4, mode=Thumb, size=30, cc=1
i32 sub_27ba5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27bc3, offset=0x27bc2, mode=Thumb, size=30, cc=1
i32 sub_27bc3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27be1, offset=0x27be0, mode=Thumb, size=30, cc=1
i32 sub_27be1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27bff, offset=0x27bfe, mode=Thumb, size=30, cc=1
i32 sub_27bff(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27c1d, offset=0x27c1c, mode=Thumb, size=30, cc=1
i32 sub_27c1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27c3b, offset=0x27c3a, mode=Thumb, size=30, cc=1
i32 sub_27c3b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27c59, offset=0x27c58, mode=Thumb, size=30, cc=1
i32 sub_27c59(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27c77, offset=0x27c76, mode=Thumb, size=30, cc=1
i32 sub_27c77(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27c95, offset=0x27c94, mode=Thumb, size=30, cc=1
i32 sub_27c95(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27cb3, offset=0x27cb2, mode=Thumb, size=30, cc=1
i32 sub_27cb3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27ced, offset=0x27cec, mode=Thumb, size=42, cc=1
i32 sub_27ced(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27cf3, offset=0x27cf2, mode=Thumb, size=2, cc=1
i32 sub_27cf3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27cf5, offset=0x27cf4, mode=Thumb, size=30, cc=1
i32 sub_27cf5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27d13, offset=0x27d12, mode=Thumb, size=30, cc=1
i32 sub_27d13(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27d31, offset=0x27d30, mode=Thumb, size=30, cc=1
i32 sub_27d31(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27d4f, offset=0x27d4e, mode=Thumb, size=50, cc=3
i32 sub_27d4f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27d81, offset=0x27d80, mode=Thumb, size=30, cc=1
i32 sub_27d81(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27d9f, offset=0x27d9e, mode=Thumb, size=30, cc=1
i32 sub_27d9f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27dbd, offset=0x27dbc, mode=Thumb, size=30, cc=1
i32 sub_27dbd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27ddb, offset=0x27dda, mode=Thumb, size=30, cc=1
i32 sub_27ddb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27df9, offset=0x27df8, mode=Thumb, size=30, cc=1
i32 sub_27df9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27e17, offset=0x27e16, mode=Thumb, size=14, cc=1
i32 sub_27e17(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27e25, offset=0x27e24, mode=Thumb, size=14, cc=1
i32 sub_27e25(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27e33, offset=0x27e32, mode=Thumb, size=30, cc=1
i32 sub_27e33(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27e51, offset=0x27e50, mode=Thumb, size=30, cc=1
i32 sub_27e51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27e6f, offset=0x27e6e, mode=Thumb, size=30, cc=1
i32 sub_27e6f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27e8d, offset=0x27e8c, mode=Thumb, size=30, cc=1
i32 sub_27e8d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27ec3, offset=0x27ec2, mode=Thumb, size=30, cc=1
i32 sub_27ec3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27ee1, offset=0x27ee0, mode=Thumb, size=30, cc=1
i32 sub_27ee1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27eff, offset=0x27efe, mode=Thumb, size=30, cc=1
i32 sub_27eff(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27f1d, offset=0x27f1c, mode=Thumb, size=30, cc=1
i32 sub_27f1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27f3b, offset=0x27f3a, mode=Thumb, size=30, cc=1
i32 sub_27f3b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27f77, offset=0x27f76, mode=Thumb, size=30, cc=1
i32 sub_27f77(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27f95, offset=0x27f94, mode=Thumb, size=14, cc=1
i32 sub_27f95(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27fa3, offset=0x27fa2, mode=Thumb, size=14, cc=1
i32 sub_27fa3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27fb1, offset=0x27fb0, mode=Thumb, size=30, cc=1
i32 sub_27fb1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27fcf, offset=0x27fce, mode=Thumb, size=30, cc=1
i32 sub_27fcf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x27fed, offset=0x27fec, mode=Thumb, size=30, cc=1
i32 sub_27fed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2800b, offset=0x2800a, mode=Thumb, size=30, cc=1
i32 sub_2800b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28029, offset=0x28028, mode=Thumb, size=30, cc=1
i32 sub_28029(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28047, offset=0x28046, mode=Thumb, size=14, cc=1
i32 sub_28047(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2809f, offset=0x2809e, mode=Thumb, size=30, cc=1
i32 sub_2809f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x280bd, offset=0x280bc, mode=Thumb, size=30, cc=1
i32 sub_280bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x280db, offset=0x280da, mode=Thumb, size=30, cc=1
i32 sub_280db(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2812d, offset=0x2812c, mode=Thumb, size=24, cc=1
i32 sub_2812d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28163, offset=0x28162, mode=Thumb, size=16, cc=1
i32 sub_28163(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28171, offset=0x28170, mode=Thumb, size=14, cc=1
i32 sub_28171(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2817f, offset=0x2817e, mode=Thumb, size=30, cc=1
i32 sub_2817f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2819d, offset=0x2819c, mode=Thumb, size=30, cc=1
i32 sub_2819d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x281d9, offset=0x281d8, mode=Thumb, size=30, cc=1
i32 sub_281d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x281f7, offset=0x281f6, mode=Thumb, size=30, cc=1
i32 sub_281f7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2821b, offset=0x2821a, mode=Thumb, size=30, cc=1
i32 sub_2821b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28239, offset=0x28238, mode=Thumb, size=14, cc=1
i32 sub_28239(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28299, offset=0x28298, mode=Thumb, size=2, cc=1
i32 sub_28299(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2829b, offset=0x2829a, mode=Thumb, size=14, cc=1
i32 sub_2829b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2829f, offset=0x2829e, mode=Thumb, size=4, cc=1
i32 sub_2829f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x282a3, offset=0x282a2, mode=Thumb, size=2, cc=1
i32 sub_282a3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x282a5, offset=0x282a4, mode=Thumb, size=68, cc=8
i32 sub_282a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x282fd, offset=0x282fc, mode=Thumb, size=4, cc=1
i32 sub_282fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28301, offset=0x28300, mode=Thumb, size=346, cc=34
i32 sub_28301(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28481, offset=0x28480, mode=Thumb, size=212, cc=16
i32 sub_28481(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28575, offset=0x28574, mode=Thumb, size=12, cc=1
i32 sub_28575(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28581, offset=0x28580, mode=Thumb, size=96, cc=9
i32 sub_28581(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x285e1, offset=0x285e0, mode=Thumb, size=4, cc=1
i32 sub_285e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x285e5, offset=0x285e4, mode=Thumb, size=200, cc=14
i32 sub_285e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x286a3, offset=0x286a2, mode=Thumb, size=12, cc=1
i32 sub_286a3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x286cd, offset=0x286cc, mode=Thumb, size=370, cc=25
i32 sub_286cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2885d, offset=0x2885c, mode=Thumb, size=316, cc=22
i32 sub_2885d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x289c5, offset=0x289c4, mode=Thumb, size=108, cc=11
i32 sub_289c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28a31, offset=0x28a30, mode=Thumb, size=4, cc=1
i32 sub_28a31(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28a35, offset=0x28a34, mode=Thumb, size=26, cc=2
i32 sub_28a35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28a51, offset=0x28a50, mode=Thumb, size=4, cc=1
i32 sub_28a51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28a55, offset=0x28a54, mode=Thumb, size=24, cc=2
i32 sub_28a55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28a6d, offset=0x28a6c, mode=Thumb, size=4, cc=1
i32 sub_28a6d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28a71, offset=0x28a70, mode=Thumb, size=44, cc=3
i32 sub_28a71(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28aad, offset=0x28aac, mode=Thumb, size=310, cc=24
i32 sub_28aad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28c09, offset=0x28c08, mode=Thumb, size=76, cc=11
i32 sub_28c09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28c55, offset=0x28c54, mode=Thumb, size=4, cc=1
i32 sub_28c55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28c59, offset=0x28c58, mode=Thumb, size=914, cc=53
i32 sub_28c59(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28ffd, offset=0x28ffc, mode=Thumb, size=92, cc=5
i32 sub_28ffd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29059, offset=0x29058, mode=Thumb, size=4, cc=1
i32 sub_29059(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2905d, offset=0x2905c, mode=Thumb, size=462, cc=34
i32 sub_2905d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2923d, offset=0x2923c, mode=Thumb, size=44, cc=4
i32 sub_2923d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29269, offset=0x29268, mode=Thumb, size=50, cc=1
i32 sub_29269(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2929d, offset=0x2929c, mode=Thumb, size=34, cc=1
i32 sub_2929d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x292c1, offset=0x292c0, mode=Thumb, size=18, cc=1
i32 sub_292c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x292d5, offset=0x292d4, mode=Thumb, size=2576, cc=195
i32 sub_292d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x299e9, offset=0x299e8, mode=Thumb, size=16, cc=1
i32 sub_299e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x299f9, offset=0x299f8, mode=Thumb, size=2, cc=1
i32 sub_299f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29c43, offset=0x29c42, mode=Thumb, size=8, cc=1
i32 sub_29c43(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29d09, offset=0x29d08, mode=Thumb, size=24, cc=1
i32 sub_29d09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29de9, offset=0x29de8, mode=Thumb, size=8, cc=1
i32 sub_29de9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29e09, offset=0x29e08, mode=Thumb, size=24, cc=1
i32 sub_29e09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29e21, offset=0x29e20, mode=Thumb, size=8, cc=1
i32 sub_29e21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x29e90, offset=0x29e90, mode=ARM, size=2984, cc=91
i32 sub_29e90(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2aa45, offset=0x2aa44, mode=Thumb, size=162, cc=6
i32 sub_2aa45(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2aaf9, offset=0x2aaf8, mode=Thumb, size=178, cc=8
i32 sub_2aaf9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2abbd, offset=0x2abbc, mode=Thumb, size=246, cc=8
i32 sub_2abbd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2acc5, offset=0x2acc4, mode=Thumb, size=184, cc=8
i32 sub_2acc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ad8d, offset=0x2ad8c, mode=Thumb, size=118, cc=6
i32 sub_2ad8d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ae09, offset=0x2ae08, mode=Thumb, size=12, cc=1
i32 sub_2ae09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ae15, offset=0x2ae14, mode=Thumb, size=68, cc=1
i32 sub_2ae15(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ae5d, offset=0x2ae5c, mode=Thumb, size=20, cc=1
i32 sub_2ae5d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ae75, offset=0x2ae74, mode=Thumb, size=66, cc=1
i32 sub_2ae75(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2aebd, offset=0x2aebc, mode=Thumb, size=16, cc=1
i32 sub_2aebd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2aed1, offset=0x2aed0, mode=Thumb, size=212, cc=11
i32 sub_2aed1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2afa9, offset=0x2afa8, mode=Thumb, size=44, cc=1
i32 sub_2afa9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2afd9, offset=0x2afd8, mode=Thumb, size=18, cc=1
i32 sub_2afd9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2afed, offset=0x2afec, mode=Thumb, size=4, cc=1
i32 sub_2afed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2aff1, offset=0x2aff0, mode=Thumb, size=18, cc=1
i32 sub_2aff1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b009, offset=0x2b008, mode=Thumb, size=18, cc=1
i32 sub_2b009(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b021, offset=0x2b020, mode=Thumb, size=1248, cc=91
i32 sub_2b021(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b2c5, offset=0x2b2c4, mode=Thumb, size=60, cc=2
i32 sub_2b2c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b335, offset=0x2b334, mode=Thumb, size=36, cc=1
i32 sub_2b335(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b359, offset=0x2b358, mode=Thumb, size=76, cc=2
i32 sub_2b359(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b3a9, offset=0x2b3a8, mode=Thumb, size=46, cc=2
i32 sub_2b3a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b68d, offset=0x2b68c, mode=Thumb, size=192, cc=10
i32 sub_2b68d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b765, offset=0x2b764, mode=Thumb, size=52, cc=1
i32 sub_2b765(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b799, offset=0x2b798, mode=Thumb, size=40, cc=1
i32 sub_2b799(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b7c1, offset=0x2b7c0, mode=Thumb, size=42, cc=1
i32 sub_2b7c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b7f1, offset=0x2b7f0, mode=Thumb, size=38, cc=4
i32 sub_2b7f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b821, offset=0x2b820, mode=Thumb, size=14, cc=1
i32 sub_2b821(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b835, offset=0x2b834, mode=Thumb, size=16, cc=1
i32 sub_2b835(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b849, offset=0x2b848, mode=Thumb, size=16, cc=1
i32 sub_2b849(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b85d, offset=0x2b85c, mode=Thumb, size=14, cc=1
i32 sub_2b85d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b86f, offset=0x2b86e, mode=Thumb, size=2, cc=1
i32 sub_2b86f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b871, offset=0x2b870, mode=Thumb, size=18, cc=1
i32 sub_2b871(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b885, offset=0x2b884, mode=Thumb, size=2, cc=1
i32 sub_2b885(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b889, offset=0x2b888, mode=Thumb, size=38, cc=3
i32 sub_2b889(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b8b5, offset=0x2b8b4, mode=Thumb, size=16, cc=1
i32 sub_2b8b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b8c9, offset=0x2b8c8, mode=Thumb, size=424, cc=42
i32 sub_2b8c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ba71, offset=0x2ba70, mode=Thumb, size=12, cc=1
i32 sub_2ba71(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ba7d, offset=0x2ba7c, mode=Thumb, size=158, cc=16
i32 sub_2ba7d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bb1d, offset=0x2bb1c, mode=Thumb, size=4, cc=1
i32 sub_2bb1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bb21, offset=0x2bb20, mode=Thumb, size=268, cc=11
i32 sub_2bb21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bc61, offset=0x2bc60, mode=Thumb, size=34, cc=2
i32 sub_2bc61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bc85, offset=0x2bc84, mode=Thumb, size=4, cc=1
i32 sub_2bc85(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bc89, offset=0x2bc88, mode=Thumb, size=44, cc=2
i32 sub_2bc89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bcb5, offset=0x2bcb4, mode=Thumb, size=8, cc=1
i32 sub_2bcb5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bcbd, offset=0x2bcbc, mode=Thumb, size=16, cc=1
i32 sub_2bcbd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bcd1, offset=0x2bcd0, mode=Thumb, size=16, cc=1
i32 sub_2bcd1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bce1, offset=0x2bce0, mode=Thumb, size=4, cc=1
i32 sub_2bce1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bce5, offset=0x2bce4, mode=Thumb, size=16, cc=1
i32 sub_2bce5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bcf5, offset=0x2bcf4, mode=Thumb, size=138, cc=12
i32 sub_2bcf5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bd8d, offset=0x2bd8c, mode=Thumb, size=54, cc=2
i32 sub_2bd8d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bdc5, offset=0x2bdc4, mode=Thumb, size=22, cc=1
i32 sub_2bdc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bddd, offset=0x2bddc, mode=Thumb, size=12, cc=1
i32 sub_2bddd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bde9, offset=0x2bde8, mode=Thumb, size=16, cc=1
i32 sub_2bde9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2bdfd, offset=0x2bdfc, mode=Thumb, size=1772, cc=156
i32 sub_2bdfd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c575, offset=0x2c574, mode=Thumb, size=50, cc=3
i32 sub_2c575(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c5b1, offset=0x2c5b0, mode=Thumb, size=16, cc=1
i32 sub_2c5b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c5c5, offset=0x2c5c4, mode=Thumb, size=10, cc=2
i32 sub_2c5c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c5d1, offset=0x2c5d0, mode=Thumb, size=8, cc=1
i32 sub_2c5d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c5d9, offset=0x2c5d8, mode=Thumb, size=4, cc=1
i32 sub_2c5d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c5dd, offset=0x2c5dc, mode=Thumb, size=16, cc=1
i32 sub_2c5dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c5f1, offset=0x2c5f0, mode=Thumb, size=28, cc=1
i32 sub_2c5f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c611, offset=0x2c610, mode=Thumb, size=50, cc=2
i32 sub_2c611(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c645, offset=0x2c644, mode=Thumb, size=12, cc=1
i32 sub_2c645(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c651, offset=0x2c650, mode=Thumb, size=90, cc=10
i32 sub_2c651(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c6ad, offset=0x2c6ac, mode=Thumb, size=4, cc=1
i32 sub_2c6ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c6b1, offset=0x2c6b0, mode=Thumb, size=276, cc=24
i32 sub_2c6b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c7dd, offset=0x2c7dc, mode=Thumb, size=44, cc=3
i32 sub_2c7dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c80d, offset=0x2c80c, mode=Thumb, size=4, cc=1
i32 sub_2c80d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c811, offset=0x2c810, mode=Thumb, size=8, cc=1
i32 sub_2c811(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c819, offset=0x2c818, mode=Thumb, size=216, cc=18
i32 sub_2c819(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c8fb, offset=0x2c8fa, mode=Thumb, size=2, cc=1
i32 sub_2c8fb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c8fd, offset=0x2c8fc, mode=Thumb, size=82, cc=6
i32 sub_2c8fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c961, offset=0x2c960, mode=Thumb, size=146, cc=7
i32 sub_2c961(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c9f5, offset=0x2c9f4, mode=Thumb, size=4, cc=1
i32 sub_2c9f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c9f9, offset=0x2c9f8, mode=Thumb, size=178, cc=10
i32 sub_2c9f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cab5, offset=0x2cab4, mode=Thumb, size=202, cc=11
i32 sub_2cab5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cb99, offset=0x2cb98, mode=Thumb, size=4, cc=1
i32 sub_2cb99(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cb9d, offset=0x2cb9c, mode=Thumb, size=52, cc=4
i32 sub_2cb9d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cbd1, offset=0x2cbd0, mode=Thumb, size=8, cc=1
i32 sub_2cbd1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cbd9, offset=0x2cbd8, mode=Thumb, size=16, cc=1
i32 sub_2cbd9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cbed, offset=0x2cbec, mode=Thumb, size=30, cc=3
i32 sub_2cbed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cc0d, offset=0x2cc0c, mode=Thumb, size=136, cc=1
i32 sub_2cc0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ccad, offset=0x2ccac, mode=Thumb, size=36, cc=1
i32 sub_2ccad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ccd1, offset=0x2ccd0, mode=Thumb, size=82, cc=1
i32 sub_2ccd1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cd25, offset=0x2cd24, mode=Thumb, size=8, cc=1
i32 sub_2cd25(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cd2d, offset=0x2cd2c, mode=Thumb, size=8, cc=1
i32 sub_2cd2d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cd35, offset=0x2cd34, mode=Thumb, size=68, cc=1
i32 sub_2cd35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cd79, offset=0x2cd78, mode=Thumb, size=4, cc=1
i32 sub_2cd79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cd7d, offset=0x2cd7c, mode=Thumb, size=58, cc=1
i32 sub_2cd7d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cdb9, offset=0x2cdb8, mode=Thumb, size=8, cc=1
i32 sub_2cdb9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cdc1, offset=0x2cdc0, mode=Thumb, size=62, cc=1
i32 sub_2cdc1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ce01, offset=0x2ce00, mode=Thumb, size=8, cc=1
i32 sub_2ce01(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ce09, offset=0x2ce08, mode=Thumb, size=58, cc=2
i32 sub_2ce09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ce45, offset=0x2ce44, mode=Thumb, size=4, cc=1
i32 sub_2ce45(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ce49, offset=0x2ce48, mode=Thumb, size=368, cc=17
i32 sub_2ce49(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cfd1, offset=0x2cfd0, mode=Thumb, size=34, cc=1
i32 sub_2cfd1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2cff5, offset=0x2cff4, mode=Thumb, size=32, cc=1
i32 sub_2cff5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d015, offset=0x2d014, mode=Thumb, size=34, cc=2
i32 sub_2d015(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d039, offset=0x2d038, mode=Thumb, size=4, cc=1
i32 sub_2d039(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d03d, offset=0x2d03c, mode=Thumb, size=66, cc=3
i32 sub_2d03d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d081, offset=0x2d080, mode=Thumb, size=4, cc=1
i32 sub_2d081(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d085, offset=0x2d084, mode=Thumb, size=58, cc=1
i32 sub_2d085(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d0c1, offset=0x2d0c0, mode=Thumb, size=4, cc=1
i32 sub_2d0c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d0c5, offset=0x2d0c4, mode=Thumb, size=66, cc=5
i32 sub_2d0c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d119, offset=0x2d118, mode=Thumb, size=358, cc=32
i32 sub_2d119(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d281, offset=0x2d280, mode=Thumb, size=4, cc=1
i32 sub_2d281(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d285, offset=0x2d284, mode=Thumb, size=120, cc=13
i32 sub_2d285(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d2fd, offset=0x2d2fc, mode=Thumb, size=388, cc=37
i32 sub_2d2fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d481, offset=0x2d480, mode=Thumb, size=4, cc=1
i32 sub_2d481(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d485, offset=0x2d484, mode=Thumb, size=146, cc=13
i32 sub_2d485(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d519, offset=0x2d518, mode=Thumb, size=1192, cc=76
i32 sub_2d519(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d5d1, offset=0x2d5d0, mode=Thumb, size=26, cc=1
i32 sub_2d5d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d6f7, offset=0x2d6f6, mode=Thumb, size=52, cc=2
i32 sub_2d6f7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d72d, offset=0x2d72c, mode=Thumb, size=22, cc=1
i32 sub_2d72d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d7af, offset=0x2d7ae, mode=Thumb, size=16, cc=1
i32 sub_2d7af(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d7bf, offset=0x2d7be, mode=Thumb, size=26, cc=1
i32 sub_2d7bf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d7d9, offset=0x2d7d8, mode=Thumb, size=22, cc=1
i32 sub_2d7d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d7ef, offset=0x2d7ee, mode=Thumb, size=16, cc=1
i32 sub_2d7ef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d7ff, offset=0x2d7fe, mode=Thumb, size=22, cc=1
i32 sub_2d7ff(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d815, offset=0x2d814, mode=Thumb, size=22, cc=1
i32 sub_2d815(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d8b1, offset=0x2d8b0, mode=Thumb, size=8, cc=2
i32 sub_2d8b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2db11, offset=0x2db10, mode=Thumb, size=542, cc=33
i32 sub_2db11(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2dc0d, offset=0x2dc0c, mode=Thumb, size=38, cc=1
i32 sub_2dc0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2dc53, offset=0x2dc52, mode=Thumb, size=6, cc=1
i32 sub_2dc53(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2dcc1, offset=0x2dcc0, mode=Thumb, size=120, cc=1
i32 sub_2dcc1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2dd3d, offset=0x2dd3c, mode=Thumb, size=22, cc=1
i32 sub_2dd3d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2dd55, offset=0x2dd54, mode=Thumb, size=22, cc=1
i32 sub_2dd55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2dd6f, offset=0x2dd6e, mode=Thumb, size=22, cc=1
i32 sub_2dd6f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2dd85, offset=0x2dd84, mode=Thumb, size=22, cc=1
i32 sub_2dd85(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2dd9b, offset=0x2dd9a, mode=Thumb, size=22, cc=1
i32 sub_2dd9b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ddb1, offset=0x2ddb0, mode=Thumb, size=22, cc=1
i32 sub_2ddb1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ddc7, offset=0x2ddc6, mode=Thumb, size=22, cc=1
i32 sub_2ddc7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2dddd, offset=0x2dddc, mode=Thumb, size=22, cc=1
i32 sub_2dddd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ddf3, offset=0x2ddf2, mode=Thumb, size=22, cc=1
i32 sub_2ddf3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2de09, offset=0x2de08, mode=Thumb, size=22, cc=1
i32 sub_2de09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2de1f, offset=0x2de1e, mode=Thumb, size=22, cc=1
i32 sub_2de1f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2de35, offset=0x2de34, mode=Thumb, size=22, cc=1
i32 sub_2de35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2de4b, offset=0x2de4a, mode=Thumb, size=22, cc=1
i32 sub_2de4b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2de61, offset=0x2de60, mode=Thumb, size=22, cc=1
i32 sub_2de61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2de77, offset=0x2de76, mode=Thumb, size=22, cc=1
i32 sub_2de77(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2de8d, offset=0x2de8c, mode=Thumb, size=22, cc=1
i32 sub_2de8d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2dea3, offset=0x2dea2, mode=Thumb, size=22, cc=1
i32 sub_2dea3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ded5, offset=0x2ded4, mode=Thumb, size=394, cc=19
i32 sub_2ded5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2dedb, offset=0x2deda, mode=Thumb, size=2, cc=1
i32 sub_2dedb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2dedd, offset=0x2dedc, mode=Thumb, size=22, cc=1
i32 sub_2dedd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2def3, offset=0x2def2, mode=Thumb, size=22, cc=1
i32 sub_2def3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2df09, offset=0x2df08, mode=Thumb, size=22, cc=1
i32 sub_2df09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2df1f, offset=0x2df1e, mode=Thumb, size=22, cc=1
i32 sub_2df1f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2df35, offset=0x2df34, mode=Thumb, size=6, cc=1
i32 sub_2df35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2df3b, offset=0x2df3a, mode=Thumb, size=6, cc=1
i32 sub_2df3b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2df41, offset=0x2df40, mode=Thumb, size=22, cc=1
i32 sub_2df41(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2df57, offset=0x2df56, mode=Thumb, size=22, cc=1
i32 sub_2df57(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2df6d, offset=0x2df6c, mode=Thumb, size=22, cc=1
i32 sub_2df6d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2df83, offset=0x2df82, mode=Thumb, size=22, cc=1
i32 sub_2df83(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2df99, offset=0x2df98, mode=Thumb, size=22, cc=1
i32 sub_2df99(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2dfaf, offset=0x2dfae, mode=Thumb, size=22, cc=1
i32 sub_2dfaf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2dfc5, offset=0x2dfc4, mode=Thumb, size=22, cc=1
i32 sub_2dfc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2dfdb, offset=0x2dfda, mode=Thumb, size=22, cc=1
i32 sub_2dfdb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2dff1, offset=0x2dff0, mode=Thumb, size=22, cc=1
i32 sub_2dff1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e007, offset=0x2e006, mode=Thumb, size=22, cc=1
i32 sub_2e007(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e0a9, offset=0x2e0a8, mode=Thumb, size=22, cc=1
i32 sub_2e0a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e0bf, offset=0x2e0be, mode=Thumb, size=22, cc=1
i32 sub_2e0bf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e0d5, offset=0x2e0d4, mode=Thumb, size=22, cc=1
i32 sub_2e0d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e0eb, offset=0x2e0ea, mode=Thumb, size=22, cc=1
i32 sub_2e0eb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e107, offset=0x2e106, mode=Thumb, size=22, cc=1
i32 sub_2e107(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e11d, offset=0x2e11c, mode=Thumb, size=22, cc=1
i32 sub_2e11d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e133, offset=0x2e132, mode=Thumb, size=6, cc=1
i32 sub_2e133(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e139, offset=0x2e138, mode=Thumb, size=6, cc=1
i32 sub_2e139(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e13f, offset=0x2e13e, mode=Thumb, size=22, cc=1
i32 sub_2e13f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e155, offset=0x2e154, mode=Thumb, size=22, cc=1
i32 sub_2e155(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e16b, offset=0x2e16a, mode=Thumb, size=40, cc=2
i32 sub_2e16b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e193, offset=0x2e192, mode=Thumb, size=6, cc=1
i32 sub_2e193(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e199, offset=0x2e198, mode=Thumb, size=22, cc=1
i32 sub_2e199(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e1af, offset=0x2e1ae, mode=Thumb, size=22, cc=1
i32 sub_2e1af(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e1c5, offset=0x2e1c4, mode=Thumb, size=22, cc=1
i32 sub_2e1c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e1db, offset=0x2e1da, mode=Thumb, size=6, cc=1
i32 sub_2e1db(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e1e1, offset=0x2e1e0, mode=Thumb, size=22, cc=1
i32 sub_2e1e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e1f7, offset=0x2e1f6, mode=Thumb, size=6, cc=1
i32 sub_2e1f7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e1fd, offset=0x2e1fc, mode=Thumb, size=22, cc=1
i32 sub_2e1fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e213, offset=0x2e212, mode=Thumb, size=6, cc=1
i32 sub_2e213(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e219, offset=0x2e218, mode=Thumb, size=6, cc=1
i32 sub_2e219(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e21f, offset=0x2e21e, mode=Thumb, size=32, cc=3
i32 sub_2e21f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e23f, offset=0x2e23e, mode=Thumb, size=6, cc=1
i32 sub_2e23f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e245, offset=0x2e244, mode=Thumb, size=4, cc=1
i32 sub_2e245(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e249, offset=0x2e248, mode=Thumb, size=18, cc=2
i32 sub_2e249(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e289, offset=0x2e288, mode=Thumb, size=114, cc=6
i32 sub_2e289(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e4a5, offset=0x2e4a4, mode=Thumb, size=398, cc=13
i32 sub_2e4a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e665, offset=0x2e664, mode=Thumb, size=186, cc=17
i32 sub_2e665(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e721, offset=0x2e720, mode=Thumb, size=134, cc=7
i32 sub_2e721(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e7a9, offset=0x2e7a8, mode=Thumb, size=8, cc=1
i32 sub_2e7a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e7b1, offset=0x2e7b0, mode=Thumb, size=444, cc=16
i32 sub_2e7b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e995, offset=0x2e994, mode=Thumb, size=52, cc=2
i32 sub_2e995(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e9c9, offset=0x2e9c8, mode=Thumb, size=8, cc=1
i32 sub_2e9c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e9d1, offset=0x2e9d0, mode=Thumb, size=320, cc=12
i32 sub_2e9d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2eb2d, offset=0x2eb2c, mode=Thumb, size=298, cc=12
i32 sub_2eb2d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ec75, offset=0x2ec74, mode=Thumb, size=326, cc=12
i32 sub_2ec75(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2edd9, offset=0x2edd8, mode=Thumb, size=296, cc=12
i32 sub_2edd9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ef1d, offset=0x2ef1c, mode=Thumb, size=212, cc=20
i32 sub_2ef1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f001, offset=0x2f000, mode=Thumb, size=26, cc=1
i32 sub_2f001(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f01d, offset=0x2f01c, mode=Thumb, size=8, cc=1
i32 sub_2f01d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f025, offset=0x2f024, mode=Thumb, size=148, cc=9
i32 sub_2f025(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f0b9, offset=0x2f0b8, mode=Thumb, size=8, cc=1
i32 sub_2f0b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f0c1, offset=0x2f0c0, mode=Thumb, size=254, cc=22
i32 sub_2f0c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f1c1, offset=0x2f1c0, mode=Thumb, size=8, cc=1
i32 sub_2f1c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f1c9, offset=0x2f1c8, mode=Thumb, size=58, cc=6
i32 sub_2f1c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f205, offset=0x2f204, mode=Thumb, size=294, cc=10
i32 sub_2f205(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f33d, offset=0x2f33c, mode=Thumb, size=168, cc=10
i32 sub_2f33d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f3e5, offset=0x2f3e4, mode=Thumb, size=8, cc=1
i32 sub_2f3e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f3ed, offset=0x2f3ec, mode=Thumb, size=204, cc=14
i32 sub_2f3ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f4b9, offset=0x2f4b8, mode=Thumb, size=12, cc=1
i32 sub_2f4b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f4c5, offset=0x2f4c4, mode=Thumb, size=1154, cc=82
i32 sub_2f4c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f62d, offset=0x2f62c, mode=Thumb, size=20, cc=1
i32 sub_2f62d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f659, offset=0x2f658, mode=Thumb, size=20, cc=1
i32 sub_2f659(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f6bd, offset=0x2f6bc, mode=Thumb, size=168, cc=10
i32 sub_2f6bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f76d, offset=0x2f76c, mode=Thumb, size=26, cc=1
i32 sub_2f76d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f7c9, offset=0x2f7c8, mode=Thumb, size=56, cc=3
i32 sub_2f7c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f82d, offset=0x2f82c, mode=Thumb, size=70, cc=3
i32 sub_2f82d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f873, offset=0x2f872, mode=Thumb, size=50, cc=1
i32 sub_2f873(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f8a5, offset=0x2f8a4, mode=Thumb, size=8, cc=1
i32 sub_2f8a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f8ad, offset=0x2f8ac, mode=Thumb, size=84, cc=4
i32 sub_2f8ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f901, offset=0x2f900, mode=Thumb, size=54, cc=2
i32 sub_2f901(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f937, offset=0x2f936, mode=Thumb, size=56, cc=2
i32 sub_2f937(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f96f, offset=0x2f96e, mode=Thumb, size=74, cc=4
i32 sub_2f96f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f9b9, offset=0x2f9b8, mode=Thumb, size=40, cc=2
i32 sub_2f9b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f9e1, offset=0x2f9e0, mode=Thumb, size=24, cc=1
i32 sub_2f9e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2f9f9, offset=0x2f9f8, mode=Thumb, size=32, cc=1
i32 sub_2f9f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fa19, offset=0x2fa18, mode=Thumb, size=54, cc=3
i32 sub_2fa19(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fa4f, offset=0x2fa4e, mode=Thumb, size=68, cc=3
i32 sub_2fa4f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fa93, offset=0x2fa92, mode=Thumb, size=54, cc=3
i32 sub_2fa93(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fc99, offset=0x2fc98, mode=Thumb, size=8, cc=1
i32 sub_2fc99(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fd09, offset=0x2fd08, mode=Thumb, size=54, cc=3
i32 sub_2fd09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fd3f, offset=0x2fd3e, mode=Thumb, size=176, cc=11
i32 sub_2fd3f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fdef, offset=0x2fdee, mode=Thumb, size=78, cc=6
i32 sub_2fdef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fe45, offset=0x2fe44, mode=Thumb, size=8, cc=1
i32 sub_2fe45(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fe4d, offset=0x2fe4c, mode=Thumb, size=74, cc=5
i32 sub_2fe4d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fe89, offset=0x2fe88, mode=Thumb, size=12, cc=1
i32 sub_2fe89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fe9d, offset=0x2fe9c, mode=Thumb, size=8, cc=1
i32 sub_2fe9d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fea5, offset=0x2fea4, mode=Thumb, size=8, cc=1
i32 sub_2fea5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fead, offset=0x2feac, mode=Thumb, size=8, cc=1
i32 sub_2fead(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2feb5, offset=0x2feb4, mode=Thumb, size=8, cc=1
i32 sub_2feb5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2febd, offset=0x2febc, mode=Thumb, size=8, cc=1
i32 sub_2febd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fec5, offset=0x2fec4, mode=Thumb, size=8, cc=1
i32 sub_2fec5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fecd, offset=0x2fecc, mode=Thumb, size=8, cc=1
i32 sub_2fecd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fed5, offset=0x2fed4, mode=Thumb, size=8, cc=1
i32 sub_2fed5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fedd, offset=0x2fedc, mode=Thumb, size=8, cc=1
i32 sub_2fedd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fee5, offset=0x2fee4, mode=Thumb, size=8, cc=1
i32 sub_2fee5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2feed, offset=0x2feec, mode=Thumb, size=6, cc=1
i32 sub_2feed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ff35, offset=0x2ff34, mode=Thumb, size=46, cc=3
i32 sub_2ff35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ff65, offset=0x2ff64, mode=Thumb, size=56, cc=3
i32 sub_2ff65(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ff9d, offset=0x2ff9c, mode=Thumb, size=8, cc=1
i32 sub_2ff9d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ffa5, offset=0x2ffa4, mode=Thumb, size=30, cc=2
i32 sub_2ffa5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ffc5, offset=0x2ffc4, mode=Thumb, size=38, cc=2
i32 sub_2ffc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2ffed, offset=0x2ffec, mode=Thumb, size=8, cc=1
i32 sub_2ffed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2fff5, offset=0x2fff4, mode=Thumb, size=18, cc=1
i32 sub_2fff5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30009, offset=0x30008, mode=Thumb, size=28, cc=1
i32 sub_30009(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30025, offset=0x30024, mode=Thumb, size=8, cc=1
i32 sub_30025(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3002d, offset=0x3002c, mode=Thumb, size=526, cc=29
i32 sub_3002d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3023d, offset=0x3023c, mode=Thumb, size=12, cc=1
i32 sub_3023d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30249, offset=0x30248, mode=Thumb, size=150, cc=10
i32 sub_30249(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x302e1, offset=0x302e0, mode=Thumb, size=8, cc=1
i32 sub_302e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x302e9, offset=0x302e8, mode=Thumb, size=56, cc=1
i32 sub_302e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30321, offset=0x30320, mode=Thumb, size=8, cc=1
i32 sub_30321(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30329, offset=0x30328, mode=Thumb, size=72, cc=3
i32 sub_30329(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30371, offset=0x30370, mode=Thumb, size=8, cc=1
i32 sub_30371(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30379, offset=0x30378, mode=Thumb, size=1030, cc=43
i32 sub_30379(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30795, offset=0x30794, mode=Thumb, size=954, cc=57
i32 sub_30795(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30b51, offset=0x30b50, mode=Thumb, size=12, cc=1
i32 sub_30b51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30b5d, offset=0x30b5c, mode=Thumb, size=144, cc=6
i32 sub_30b5d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30bed, offset=0x30bec, mode=Thumb, size=12, cc=1
i32 sub_30bed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30bf9, offset=0x30bf8, mode=Thumb, size=236, cc=15
i32 sub_30bf9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30ce5, offset=0x30ce4, mode=Thumb, size=12, cc=1
i32 sub_30ce5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x30cf1, offset=0x30cf0, mode=Thumb, size=766, cc=53
i32 sub_30cf1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31019, offset=0x31018, mode=Thumb, size=176, cc=11
i32 sub_31019(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x310c9, offset=0x310c8, mode=Thumb, size=8, cc=1
i32 sub_310c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x310d1, offset=0x310d0, mode=Thumb, size=348, cc=18
i32 sub_310d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3122d, offset=0x3122c, mode=Thumb, size=8, cc=1
i32 sub_3122d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31235, offset=0x31234, mode=Thumb, size=156, cc=8
i32 sub_31235(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x312d1, offset=0x312d0, mode=Thumb, size=8, cc=1
i32 sub_312d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x312d9, offset=0x312d8, mode=Thumb, size=76, cc=3
i32 sub_312d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31325, offset=0x31324, mode=Thumb, size=20, cc=1
i32 sub_31325(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31339, offset=0x31338, mode=Thumb, size=8, cc=1
i32 sub_31339(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31341, offset=0x31340, mode=Thumb, size=216, cc=9
i32 sub_31341(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31419, offset=0x31418, mode=Thumb, size=8, cc=1
i32 sub_31419(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31421, offset=0x31420, mode=Thumb, size=44, cc=3
i32 sub_31421(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3144d, offset=0x3144c, mode=Thumb, size=4, cc=1
i32 sub_3144d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31451, offset=0x31450, mode=Thumb, size=18, cc=1
i32 sub_31451(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31465, offset=0x31464, mode=Thumb, size=8, cc=1
i32 sub_31465(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3146d, offset=0x3146c, mode=Thumb, size=42, cc=2
i32 sub_3146d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x314a9, offset=0x314a8, mode=Thumb, size=86, cc=5
i32 sub_314a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31501, offset=0x31500, mode=Thumb, size=8, cc=1
i32 sub_31501(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31509, offset=0x31508, mode=Thumb, size=110, cc=8
i32 sub_31509(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31579, offset=0x31578, mode=Thumb, size=4, cc=1
i32 sub_31579(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3157d, offset=0x3157c, mode=Thumb, size=58, cc=3
i32 sub_3157d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x315b9, offset=0x315b8, mode=Thumb, size=8, cc=1
i32 sub_315b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x315c1, offset=0x315c0, mode=Thumb, size=112, cc=15
i32 sub_315c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31631, offset=0x31630, mode=Thumb, size=48, cc=6
i32 sub_31631(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31661, offset=0x31660, mode=Thumb, size=92, cc=11
i32 sub_31661(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x316bd, offset=0x316bc, mode=Thumb, size=188, cc=19
i32 sub_316bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31789, offset=0x31788, mode=Thumb, size=46, cc=3
i32 sub_31789(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x317b9, offset=0x317b8, mode=Thumb, size=4, cc=1
i32 sub_317b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x317bd, offset=0x317bc, mode=Thumb, size=84, cc=9
i32 sub_317bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31811, offset=0x31810, mode=Thumb, size=4, cc=1
i32 sub_31811(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31815, offset=0x31814, mode=Thumb, size=602, cc=51
i32 sub_31815(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31ab0, offset=0x31ab0, mode=ARM, size=12, cc=1
i32 sub_31ab0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31abd, offset=0x31abc, mode=Thumb, size=28, cc=2
i32 sub_31abd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31ad9, offset=0x31ad8, mode=Thumb, size=4, cc=1
i32 sub_31ad9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31add, offset=0x31adc, mode=Thumb, size=70, cc=7
i32 sub_31add(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31b35, offset=0x31b34, mode=Thumb, size=58, cc=7
i32 sub_31b35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31b71, offset=0x31b70, mode=Thumb, size=4, cc=1
i32 sub_31b71(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31b75, offset=0x31b74, mode=Thumb, size=126, cc=14
i32 sub_31b75(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31bf5, offset=0x31bf4, mode=Thumb, size=4, cc=1
i32 sub_31bf5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31bf9, offset=0x31bf8, mode=Thumb, size=102, cc=9
i32 sub_31bf9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31c71, offset=0x31c70, mode=Thumb, size=72, cc=2
i32 sub_31c71(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31cb9, offset=0x31cb8, mode=Thumb, size=12, cc=1
i32 sub_31cb9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31cc5, offset=0x31cc4, mode=Thumb, size=144, cc=18
i32 sub_31cc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31d55, offset=0x31d54, mode=Thumb, size=206, cc=22
i32 sub_31d55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31e25, offset=0x31e24, mode=Thumb, size=54, cc=4
i32 sub_31e25(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31e5d, offset=0x31e5c, mode=Thumb, size=4, cc=1
i32 sub_31e5d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31e61, offset=0x31e60, mode=Thumb, size=126, cc=17
i32 sub_31e61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31ee1, offset=0x31ee0, mode=Thumb, size=90, cc=7
i32 sub_31ee1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31f3d, offset=0x31f3c, mode=Thumb, size=4, cc=1
i32 sub_31f3d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31f41, offset=0x31f40, mode=Thumb, size=64, cc=5
i32 sub_31f41(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31f81, offset=0x31f80, mode=Thumb, size=4, cc=1
i32 sub_31f81(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x31f85, offset=0x31f84, mode=Thumb, size=222, cc=34
i32 sub_31f85(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32065, offset=0x32064, mode=Thumb, size=78, cc=11
i32 sub_32065(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x320b5, offset=0x320b4, mode=Thumb, size=34, cc=3
i32 sub_320b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x320d9, offset=0x320d8, mode=Thumb, size=4, cc=1
i32 sub_320d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x320dd, offset=0x320dc, mode=Thumb, size=1318, cc=121
i32 sub_320dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32649, offset=0x32648, mode=Thumb, size=120, cc=19
i32 sub_32649(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x326c9, offset=0x326c8, mode=Thumb, size=66, cc=5
i32 sub_326c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3270d, offset=0x3270c, mode=Thumb, size=12, cc=1
i32 sub_3270d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32719, offset=0x32718, mode=Thumb, size=66, cc=6
i32 sub_32719(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3275d, offset=0x3275c, mode=Thumb, size=4, cc=1
i32 sub_3275d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32761, offset=0x32760, mode=Thumb, size=62, cc=6
i32 sub_32761(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x327a1, offset=0x327a0, mode=Thumb, size=4, cc=1
i32 sub_327a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x327a5, offset=0x327a4, mode=Thumb, size=216, cc=26
i32 sub_327a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32899, offset=0x32898, mode=Thumb, size=50, cc=7
i32 sub_32899(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x328cd, offset=0x328cc, mode=Thumb, size=24, cc=2
i32 sub_328cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x328e5, offset=0x328e4, mode=Thumb, size=4, cc=1
i32 sub_328e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x328e9, offset=0x328e8, mode=Thumb, size=58, cc=5
i32 sub_328e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32925, offset=0x32924, mode=Thumb, size=4, cc=1
i32 sub_32925(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32929, offset=0x32928, mode=Thumb, size=22, cc=2
i32 sub_32929(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32941, offset=0x32940, mode=Thumb, size=4, cc=1
i32 sub_32941(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32945, offset=0x32944, mode=Thumb, size=46, cc=4
i32 sub_32945(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32975, offset=0x32974, mode=Thumb, size=54, cc=5
i32 sub_32975(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x329ad, offset=0x329ac, mode=Thumb, size=4, cc=1
i32 sub_329ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x329b1, offset=0x329b0, mode=Thumb, size=50, cc=6
i32 sub_329b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x329e5, offset=0x329e4, mode=Thumb, size=4, cc=1
i32 sub_329e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x329e9, offset=0x329e8, mode=Thumb, size=42, cc=2
i32 sub_329e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32a14, offset=0x32a14, mode=ARM, size=12, cc=1
i32 sub_32a14(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32a21, offset=0x32a20, mode=Thumb, size=92, cc=14
i32 sub_32a21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32a7d, offset=0x32a7c, mode=Thumb, size=4, cc=1
i32 sub_32a7d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32a81, offset=0x32a80, mode=Thumb, size=44, cc=6
i32 sub_32a81(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32aad, offset=0x32aac, mode=Thumb, size=4, cc=1
i32 sub_32aad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32ab1, offset=0x32ab0, mode=Thumb, size=24, cc=4
i32 sub_32ab1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32ac9, offset=0x32ac8, mode=Thumb, size=30, cc=1
i32 sub_32ac9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32ae9, offset=0x32ae8, mode=Thumb, size=8, cc=1
i32 sub_32ae9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32af1, offset=0x32af0, mode=Thumb, size=68, cc=7
i32 sub_32af1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32b35, offset=0x32b34, mode=Thumb, size=4, cc=1
i32 sub_32b35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32b39, offset=0x32b38, mode=Thumb, size=30, cc=3
i32 sub_32b39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32b59, offset=0x32b58, mode=Thumb, size=4, cc=1
i32 sub_32b59(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32b5d, offset=0x32b5c, mode=Thumb, size=328, cc=14
i32 sub_32b5d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32cd8, offset=0x32cd8, mode=ARM, size=12, cc=1
i32 sub_32cd8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32ce5, offset=0x32ce4, mode=Thumb, size=112, cc=15
i32 sub_32ce5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32d55, offset=0x32d54, mode=Thumb, size=30, cc=3
i32 sub_32d55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32d75, offset=0x32d74, mode=Thumb, size=66, cc=7
i32 sub_32d75(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32db9, offset=0x32db8, mode=Thumb, size=20, cc=2
i32 sub_32db9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32dcd, offset=0x32dcc, mode=Thumb, size=52, cc=4
i32 sub_32dcd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32e01, offset=0x32e00, mode=Thumb, size=70, cc=6
i32 sub_32e01(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32e49, offset=0x32e48, mode=Thumb, size=4, cc=1
i32 sub_32e49(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32e4d, offset=0x32e4c, mode=Thumb, size=28, cc=4
i32 sub_32e4d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32e69, offset=0x32e68, mode=Thumb, size=42, cc=3
i32 sub_32e69(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32e95, offset=0x32e94, mode=Thumb, size=110, cc=13
i32 sub_32e95(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32f05, offset=0x32f04, mode=Thumb, size=78, cc=6
i32 sub_32f05(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32f55, offset=0x32f54, mode=Thumb, size=4, cc=1
i32 sub_32f55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32f59, offset=0x32f58, mode=Thumb, size=46, cc=4
i32 sub_32f59(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32f89, offset=0x32f88, mode=Thumb, size=92, cc=10
i32 sub_32f89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32fe5, offset=0x32fe4, mode=Thumb, size=4, cc=1
i32 sub_32fe5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x32fe9, offset=0x32fe8, mode=Thumb, size=168, cc=10
i32 sub_32fe9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33091, offset=0x33090, mode=Thumb, size=4, cc=1
i32 sub_33091(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33095, offset=0x33094, mode=Thumb, size=76, cc=8
i32 sub_33095(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x330e1, offset=0x330e0, mode=Thumb, size=8, cc=1
i32 sub_330e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x330e9, offset=0x330e8, mode=Thumb, size=50, cc=4
i32 sub_330e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3311d, offset=0x3311c, mode=Thumb, size=4, cc=1
i32 sub_3311d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33121, offset=0x33120, mode=Thumb, size=36, cc=1
i32 sub_33121(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33145, offset=0x33144, mode=Thumb, size=202, cc=14
i32 sub_33145(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33211, offset=0x33210, mode=Thumb, size=4, cc=1
i32 sub_33211(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33215, offset=0x33214, mode=Thumb, size=34, cc=3
i32 sub_33215(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33239, offset=0x33238, mode=Thumb, size=4, cc=1
i32 sub_33239(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3323d, offset=0x3323c, mode=Thumb, size=382, cc=34
i32 sub_3323d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x333d5, offset=0x333d4, mode=Thumb, size=48, cc=4
i32 sub_333d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33405, offset=0x33404, mode=Thumb, size=4, cc=1
i32 sub_33405(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33409, offset=0x33408, mode=Thumb, size=456, cc=49
i32 sub_33409(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33629, offset=0x33628, mode=Thumb, size=220, cc=16
i32 sub_33629(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33745, offset=0x33744, mode=Thumb, size=66, cc=7
i32 sub_33745(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33789, offset=0x33788, mode=Thumb, size=4, cc=1
i32 sub_33789(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3378d, offset=0x3378c, mode=Thumb, size=42, cc=2
i32 sub_3378d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x337b9, offset=0x337b8, mode=Thumb, size=8, cc=1
i32 sub_337b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x337c1, offset=0x337c0, mode=Thumb, size=24, cc=4
i32 sub_337c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x337d9, offset=0x337d8, mode=Thumb, size=42, cc=6
i32 sub_337d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33805, offset=0x33804, mode=Thumb, size=200, cc=27
i32 sub_33805(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x338cd, offset=0x338cc, mode=Thumb, size=12, cc=1
i32 sub_338cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x338d9, offset=0x338d8, mode=Thumb, size=48, cc=3
i32 sub_338d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33909, offset=0x33908, mode=Thumb, size=72, cc=10
i32 sub_33909(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33951, offset=0x33950, mode=Thumb, size=128, cc=12
i32 sub_33951(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x339d1, offset=0x339d0, mode=Thumb, size=8, cc=1
i32 sub_339d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x339d9, offset=0x339d8, mode=Thumb, size=62, cc=4
i32 sub_339d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33a19, offset=0x33a18, mode=Thumb, size=4, cc=1
i32 sub_33a19(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33a1d, offset=0x33a1c, mode=Thumb, size=24, cc=3
i32 sub_33a1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33a35, offset=0x33a34, mode=Thumb, size=66, cc=6
i32 sub_33a35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33a79, offset=0x33a78, mode=Thumb, size=4, cc=1
i32 sub_33a79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33a7d, offset=0x33a7c, mode=Thumb, size=52, cc=5
i32 sub_33a7d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33ab1, offset=0x33ab0, mode=Thumb, size=46, cc=4
i32 sub_33ab1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33ae1, offset=0x33ae0, mode=Thumb, size=196, cc=14
i32 sub_33ae1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33ba5, offset=0x33ba4, mode=Thumb, size=6, cc=1
i32 sub_33ba5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33bab, offset=0x33baa, mode=Thumb, size=2, cc=1
i32 sub_33bab(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33bad, offset=0x33bac, mode=Thumb, size=108, cc=6
i32 sub_33bad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33c19, offset=0x33c18, mode=Thumb, size=10, cc=1
i32 sub_33c19(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33c23, offset=0x33c22, mode=Thumb, size=2, cc=1
i32 sub_33c23(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33c25, offset=0x33c24, mode=Thumb, size=34, cc=3
i32 sub_33c25(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33c49, offset=0x33c48, mode=Thumb, size=4, cc=1
i32 sub_33c49(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33c4d, offset=0x33c4c, mode=Thumb, size=46, cc=5
i32 sub_33c4d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33c7d, offset=0x33c7c, mode=Thumb, size=4, cc=1
i32 sub_33c7d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33c81, offset=0x33c80, mode=Thumb, size=66, cc=6
i32 sub_33c81(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33cc5, offset=0x33cc4, mode=Thumb, size=4, cc=1
i32 sub_33cc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33cc9, offset=0x33cc8, mode=Thumb, size=96, cc=8
i32 sub_33cc9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33d29, offset=0x33d28, mode=Thumb, size=4, cc=1
i32 sub_33d29(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33d2d, offset=0x33d2c, mode=Thumb, size=106, cc=6
i32 sub_33d2d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33d99, offset=0x33d98, mode=Thumb, size=48, cc=1
i32 sub_33d99(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x33dc9, offset=0x33dc8, mode=Thumb, size=1282, cc=36
i32 sub_33dc9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34455, offset=0x34454, mode=Thumb, size=4, cc=1
i32 sub_34455(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34459, offset=0x34458, mode=Thumb, size=148, cc=4
i32 sub_34459(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34505, offset=0x34504, mode=Thumb, size=8, cc=1
i32 sub_34505(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3450d, offset=0x3450c, mode=Thumb, size=742, cc=2
i32 sub_3450d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x347f7, offset=0x347f6, mode=Thumb, size=30, cc=2
i32 sub_347f7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34817, offset=0x34816, mode=Thumb, size=12, cc=1
i32 sub_34817(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3481f, offset=0x3481e, mode=Thumb, size=8, cc=1
i32 sub_3481f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34827, offset=0x34826, mode=Thumb, size=8, cc=1
i32 sub_34827(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3482f, offset=0x3482e, mode=Thumb, size=10, cc=1
i32 sub_3482f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3483b, offset=0x3483a, mode=Thumb, size=8, cc=1
i32 sub_3483b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34845, offset=0x34844, mode=Thumb, size=4, cc=1
i32 sub_34845(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34849, offset=0x34848, mode=Thumb, size=8, cc=1
i32 sub_34849(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34851, offset=0x34850, mode=Thumb, size=46, cc=3
i32 sub_34851(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34881, offset=0x34880, mode=Thumb, size=6, cc=1
i32 sub_34881(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34889, offset=0x34888, mode=Thumb, size=8, cc=1
i32 sub_34889(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34891, offset=0x34890, mode=Thumb, size=8, cc=1
i32 sub_34891(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3489b, offset=0x3489a, mode=Thumb, size=12, cc=1
i32 sub_3489b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x348a9, offset=0x348a8, mode=Thumb, size=6, cc=1
i32 sub_348a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x348b1, offset=0x348b0, mode=Thumb, size=8, cc=1
i32 sub_348b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x348b9, offset=0x348b8, mode=Thumb, size=6, cc=1
i32 sub_348b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x348c1, offset=0x348c0, mode=Thumb, size=6, cc=1
i32 sub_348c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x348c9, offset=0x348c8, mode=Thumb, size=8, cc=1
i32 sub_348c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x348d1, offset=0x348d0, mode=Thumb, size=10, cc=1
i32 sub_348d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x348db, offset=0x348da, mode=Thumb, size=6, cc=2
i32 sub_348db(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x348e1, offset=0x348e0, mode=Thumb, size=6, cc=1
i32 sub_348e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x348e7, offset=0x348e6, mode=Thumb, size=6, cc=1
i32 sub_348e7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x348ed, offset=0x348ec, mode=Thumb, size=6, cc=1
i32 sub_348ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x348f5, offset=0x348f4, mode=Thumb, size=14, cc=1
i32 sub_348f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34903, offset=0x34902, mode=Thumb, size=12, cc=1
i32 sub_34903(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34911, offset=0x34910, mode=Thumb, size=10, cc=1
i32 sub_34911(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3491b, offset=0x3491a, mode=Thumb, size=8, cc=1
i32 sub_3491b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34923, offset=0x34922, mode=Thumb, size=8, cc=1
i32 sub_34923(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3492d, offset=0x3492c, mode=Thumb, size=12, cc=1
i32 sub_3492d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3493b, offset=0x3493a, mode=Thumb, size=8, cc=1
i32 sub_3493b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34945, offset=0x34944, mode=Thumb, size=16, cc=1
i32 sub_34945(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34957, offset=0x34956, mode=Thumb, size=10, cc=1
i32 sub_34957(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34963, offset=0x34962, mode=Thumb, size=8, cc=1
i32 sub_34963(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3496b, offset=0x3496a, mode=Thumb, size=8, cc=1
i32 sub_3496b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34975, offset=0x34974, mode=Thumb, size=14, cc=1
i32 sub_34975(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34985, offset=0x34984, mode=Thumb, size=10, cc=1
i32 sub_34985(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3498f, offset=0x3498e, mode=Thumb, size=8, cc=1
i32 sub_3498f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34997, offset=0x34996, mode=Thumb, size=10, cc=1
i32 sub_34997(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x349a1, offset=0x349a0, mode=Thumb, size=8, cc=2
i32 sub_349a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x349a9, offset=0x349a8, mode=Thumb, size=10, cc=1
i32 sub_349a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x349b5, offset=0x349b4, mode=Thumb, size=6, cc=1
i32 sub_349b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x349bb, offset=0x349ba, mode=Thumb, size=10, cc=1
i32 sub_349bb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x349c7, offset=0x349c6, mode=Thumb, size=8, cc=1
i32 sub_349c7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x349cf, offset=0x349ce, mode=Thumb, size=6, cc=1
i32 sub_349cf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x349d7, offset=0x349d6, mode=Thumb, size=14, cc=1
i32 sub_349d7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x349e7, offset=0x349e6, mode=Thumb, size=8, cc=1
i32 sub_349e7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x349ef, offset=0x349ee, mode=Thumb, size=6, cc=1
i32 sub_349ef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x349f7, offset=0x349f6, mode=Thumb, size=6, cc=2
i32 sub_349f7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x349ff, offset=0x349fe, mode=Thumb, size=6, cc=1
i32 sub_349ff(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34a07, offset=0x34a06, mode=Thumb, size=6, cc=1
i32 sub_34a07(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34a0d, offset=0x34a0c, mode=Thumb, size=8, cc=1
i32 sub_34a0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34a17, offset=0x34a16, mode=Thumb, size=6, cc=1
i32 sub_34a17(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34a1d, offset=0x34a1c, mode=Thumb, size=28, cc=2
i32 sub_34a1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34a3b, offset=0x34a3a, mode=Thumb, size=8, cc=1
i32 sub_34a3b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34a45, offset=0x34a44, mode=Thumb, size=12, cc=1
i32 sub_34a45(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34a53, offset=0x34a52, mode=Thumb, size=10, cc=2
i32 sub_34a53(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34a5d, offset=0x34a5c, mode=Thumb, size=6, cc=1
i32 sub_34a5d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34a63, offset=0x34a62, mode=Thumb, size=6, cc=1
i32 sub_34a63(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34a69, offset=0x34a68, mode=Thumb, size=12, cc=1
i32 sub_34a69(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34a77, offset=0x34a76, mode=Thumb, size=12, cc=1
i32 sub_34a77(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34a85, offset=0x34a84, mode=Thumb, size=12, cc=1
i32 sub_34a85(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34a93, offset=0x34a92, mode=Thumb, size=18, cc=1
i32 sub_34a93(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34aa7, offset=0x34aa6, mode=Thumb, size=8, cc=1
i32 sub_34aa7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34aaf, offset=0x34aae, mode=Thumb, size=8, cc=1
i32 sub_34aaf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34ab9, offset=0x34ab8, mode=Thumb, size=6, cc=1
i32 sub_34ab9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34ac1, offset=0x34ac0, mode=Thumb, size=12, cc=1
i32 sub_34ac1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34acf, offset=0x34ace, mode=Thumb, size=8, cc=1
i32 sub_34acf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34ad7, offset=0x34ad6, mode=Thumb, size=8, cc=1
i32 sub_34ad7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34adf, offset=0x34ade, mode=Thumb, size=14, cc=1
i32 sub_34adf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34aed, offset=0x34aec, mode=Thumb, size=6, cc=1
i32 sub_34aed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34af3, offset=0x34af2, mode=Thumb, size=16, cc=1
i32 sub_34af3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b03, offset=0x34b02, mode=Thumb, size=10, cc=1
i32 sub_34b03(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b0d, offset=0x34b0c, mode=Thumb, size=8, cc=1
i32 sub_34b0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b17, offset=0x34b16, mode=Thumb, size=18, cc=1
i32 sub_34b17(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b29, offset=0x34b28, mode=Thumb, size=8, cc=1
i32 sub_34b29(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b31, offset=0x34b30, mode=Thumb, size=8, cc=1
i32 sub_34b31(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b39, offset=0x34b38, mode=Thumb, size=6, cc=1
i32 sub_34b39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b3f, offset=0x34b3e, mode=Thumb, size=12, cc=1
i32 sub_34b3f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b4d, offset=0x34b4c, mode=Thumb, size=10, cc=1
i32 sub_34b4d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b57, offset=0x34b56, mode=Thumb, size=10, cc=1
i32 sub_34b57(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b61, offset=0x34b60, mode=Thumb, size=6, cc=1
i32 sub_34b61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b67, offset=0x34b66, mode=Thumb, size=6, cc=1
i32 sub_34b67(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b6d, offset=0x34b6c, mode=Thumb, size=10, cc=2
i32 sub_34b6d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b77, offset=0x34b76, mode=Thumb, size=12, cc=1
i32 sub_34b77(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b83, offset=0x34b82, mode=Thumb, size=6, cc=1
i32 sub_34b83(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b89, offset=0x34b88, mode=Thumb, size=6, cc=1
i32 sub_34b89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b8f, offset=0x34b8e, mode=Thumb, size=6, cc=1
i32 sub_34b8f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b95, offset=0x34b94, mode=Thumb, size=6, cc=1
i32 sub_34b95(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b9d, offset=0x34b9c, mode=Thumb, size=12, cc=1
i32 sub_34b9d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34ba9, offset=0x34ba8, mode=Thumb, size=6, cc=1
i32 sub_34ba9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34baf, offset=0x34bae, mode=Thumb, size=12, cc=1
i32 sub_34baf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34bbd, offset=0x34bbc, mode=Thumb, size=6, cc=1
i32 sub_34bbd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34bc5, offset=0x34bc4, mode=Thumb, size=6, cc=1
i32 sub_34bc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34bcd, offset=0x34bcc, mode=Thumb, size=12, cc=1
i32 sub_34bcd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34bdb, offset=0x34bda, mode=Thumb, size=6, cc=1
i32 sub_34bdb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34be3, offset=0x34be2, mode=Thumb, size=8, cc=1
i32 sub_34be3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34bed, offset=0x34bec, mode=Thumb, size=10, cc=1
i32 sub_34bed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34bf7, offset=0x34bf6, mode=Thumb, size=10, cc=1
i32 sub_34bf7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c03, offset=0x34c02, mode=Thumb, size=8, cc=1
i32 sub_34c03(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c0d, offset=0x34c0c, mode=Thumb, size=6, cc=1
i32 sub_34c0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c13, offset=0x34c12, mode=Thumb, size=6, cc=1
i32 sub_34c13(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c19, offset=0x34c18, mode=Thumb, size=12, cc=1
i32 sub_34c19(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c27, offset=0x34c26, mode=Thumb, size=12, cc=1
i32 sub_34c27(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c33, offset=0x34c32, mode=Thumb, size=8, cc=1
i32 sub_34c33(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c3b, offset=0x34c3a, mode=Thumb, size=10, cc=1
i32 sub_34c3b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c45, offset=0x34c44, mode=Thumb, size=8, cc=1
i32 sub_34c45(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c4d, offset=0x34c4c, mode=Thumb, size=8, cc=1
i32 sub_34c4d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c55, offset=0x34c54, mode=Thumb, size=12, cc=1
i32 sub_34c55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c61, offset=0x34c60, mode=Thumb, size=12, cc=1
i32 sub_34c61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c6d, offset=0x34c6c, mode=Thumb, size=8, cc=1
i32 sub_34c6d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c75, offset=0x34c74, mode=Thumb, size=6, cc=1
i32 sub_34c75(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c7d, offset=0x34c7c, mode=Thumb, size=8, cc=1
i32 sub_34c7d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c87, offset=0x34c86, mode=Thumb, size=8, cc=1
i32 sub_34c87(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c8f, offset=0x34c8e, mode=Thumb, size=8, cc=1
i32 sub_34c8f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34c97, offset=0x34c96, mode=Thumb, size=10, cc=1
i32 sub_34c97(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34ca3, offset=0x34ca2, mode=Thumb, size=40, cc=3
i32 sub_34ca3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34ccf, offset=0x34cce, mode=Thumb, size=10, cc=1
i32 sub_34ccf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34cd9, offset=0x34cd8, mode=Thumb, size=14, cc=1
i32 sub_34cd9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34ce7, offset=0x34ce6, mode=Thumb, size=20, cc=1
i32 sub_34ce7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34cfb, offset=0x34cfa, mode=Thumb, size=8, cc=1
i32 sub_34cfb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34d03, offset=0x34d02, mode=Thumb, size=10, cc=1
i32 sub_34d03(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34d0d, offset=0x34d0c, mode=Thumb, size=8, cc=1
i32 sub_34d0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34d15, offset=0x34d14, mode=Thumb, size=10, cc=1
i32 sub_34d15(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34d21, offset=0x34d20, mode=Thumb, size=8, cc=1
i32 sub_34d21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34d29, offset=0x34d28, mode=Thumb, size=12, cc=1
i32 sub_34d29(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34d35, offset=0x34d34, mode=Thumb, size=8, cc=1
i32 sub_34d35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34d3d, offset=0x34d3c, mode=Thumb, size=10, cc=1
i32 sub_34d3d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34d47, offset=0x34d46, mode=Thumb, size=8, cc=1
i32 sub_34d47(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34d51, offset=0x34d50, mode=Thumb, size=8, cc=1
i32 sub_34d51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34d59, offset=0x34d58, mode=Thumb, size=8, cc=1
i32 sub_34d59(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34d61, offset=0x34d60, mode=Thumb, size=6, cc=1
i32 sub_34d61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34d67, offset=0x34d66, mode=Thumb, size=12, cc=1
i32 sub_34d67(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34d73, offset=0x34d72, mode=Thumb, size=10, cc=1
i32 sub_34d73(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34d7f, offset=0x34d7e, mode=Thumb, size=6, cc=1
i32 sub_34d7f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34d87, offset=0x34d86, mode=Thumb, size=14, cc=1
i32 sub_34d87(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34d97, offset=0x34d96, mode=Thumb, size=16, cc=1
i32 sub_34d97(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34da7, offset=0x34da6, mode=Thumb, size=8, cc=1
i32 sub_34da7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34daf, offset=0x34dae, mode=Thumb, size=12, cc=1
i32 sub_34daf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34dbb, offset=0x34dba, mode=Thumb, size=10, cc=1
i32 sub_34dbb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34dc5, offset=0x34dc4, mode=Thumb, size=10, cc=1
i32 sub_34dc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34dd1, offset=0x34dd0, mode=Thumb, size=10, cc=1
i32 sub_34dd1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34ddb, offset=0x34dda, mode=Thumb, size=14, cc=1
i32 sub_34ddb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34deb, offset=0x34dea, mode=Thumb, size=14, cc=1
i32 sub_34deb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34dfb, offset=0x34dfa, mode=Thumb, size=14, cc=1
i32 sub_34dfb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34e0b, offset=0x34e0a, mode=Thumb, size=28, cc=1
i32 sub_34e0b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34e29, offset=0x34e28, mode=Thumb, size=14, cc=1
i32 sub_34e29(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34e39, offset=0x34e38, mode=Thumb, size=8, cc=1
i32 sub_34e39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34e41, offset=0x34e40, mode=Thumb, size=8, cc=1
i32 sub_34e41(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34e49, offset=0x34e48, mode=Thumb, size=14, cc=1
i32 sub_34e49(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34e59, offset=0x34e58, mode=Thumb, size=6, cc=1
i32 sub_34e59(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34e5f, offset=0x34e5e, mode=Thumb, size=8, cc=1
i32 sub_34e5f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34e69, offset=0x34e68, mode=Thumb, size=8, cc=1
i32 sub_34e69(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34e71, offset=0x34e70, mode=Thumb, size=8, cc=1
i32 sub_34e71(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34e7b, offset=0x34e7a, mode=Thumb, size=10, cc=1
i32 sub_34e7b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34e87, offset=0x34e86, mode=Thumb, size=6, cc=1
i32 sub_34e87(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34e8f, offset=0x34e8e, mode=Thumb, size=10, cc=1
i32 sub_34e8f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34e9b, offset=0x34e9a, mode=Thumb, size=16, cc=1
i32 sub_34e9b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34ead, offset=0x34eac, mode=Thumb, size=16, cc=1
i32 sub_34ead(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34ebf, offset=0x34ebe, mode=Thumb, size=16, cc=1
i32 sub_34ebf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34ecf, offset=0x34ece, mode=Thumb, size=20, cc=1
i32 sub_34ecf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34ee3, offset=0x34ee2, mode=Thumb, size=14, cc=1
i32 sub_34ee3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34ef1, offset=0x34ef0, mode=Thumb, size=14, cc=2
i32 sub_34ef1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34f01, offset=0x34f00, mode=Thumb, size=16, cc=1
i32 sub_34f01(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34f13, offset=0x34f12, mode=Thumb, size=18, cc=1
i32 sub_34f13(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34f25, offset=0x34f24, mode=Thumb, size=10, cc=1
i32 sub_34f25(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34f2f, offset=0x34f2e, mode=Thumb, size=12, cc=1
i32 sub_34f2f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34f3b, offset=0x34f3a, mode=Thumb, size=12, cc=1
i32 sub_34f3b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34f47, offset=0x34f46, mode=Thumb, size=16, cc=1
i32 sub_34f47(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34f57, offset=0x34f56, mode=Thumb, size=6, cc=1
i32 sub_34f57(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34f5d, offset=0x34f5c, mode=Thumb, size=16, cc=1
i32 sub_34f5d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34f6d, offset=0x34f6c, mode=Thumb, size=6, cc=2
i32 sub_34f6d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34f73, offset=0x34f72, mode=Thumb, size=8, cc=1
i32 sub_34f73(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34f7b, offset=0x34f7a, mode=Thumb, size=14, cc=1
i32 sub_34f7b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34f89, offset=0x34f88, mode=Thumb, size=8, cc=1
i32 sub_34f89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34f91, offset=0x34f90, mode=Thumb, size=14, cc=1
i32 sub_34f91(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34f9f, offset=0x34f9e, mode=Thumb, size=10, cc=1
i32 sub_34f9f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34fa9, offset=0x34fa8, mode=Thumb, size=16, cc=1
i32 sub_34fa9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34fb9, offset=0x34fb8, mode=Thumb, size=8, cc=1
i32 sub_34fb9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34fc1, offset=0x34fc0, mode=Thumb, size=8, cc=1
i32 sub_34fc1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34fc9, offset=0x34fc8, mode=Thumb, size=8, cc=1
i32 sub_34fc9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34fd1, offset=0x34fd0, mode=Thumb, size=12, cc=1
i32 sub_34fd1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34fdd, offset=0x34fdc, mode=Thumb, size=10, cc=1
i32 sub_34fdd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34fe7, offset=0x34fe6, mode=Thumb, size=8, cc=1
i32 sub_34fe7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34fef, offset=0x34fee, mode=Thumb, size=8, cc=1
i32 sub_34fef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34ff7, offset=0x34ff6, mode=Thumb, size=10, cc=1
i32 sub_34ff7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35001, offset=0x35000, mode=Thumb, size=12, cc=1
i32 sub_35001(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3500b, offset=0x3500a, mode=Thumb, size=10, cc=1
i32 sub_3500b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35015, offset=0x35014, mode=Thumb, size=20, cc=1
i32 sub_35015(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35027, offset=0x35026, mode=Thumb, size=14, cc=1
i32 sub_35027(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35033, offset=0x35032, mode=Thumb, size=10, cc=1
i32 sub_35033(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3503d, offset=0x3503c, mode=Thumb, size=12, cc=1
i32 sub_3503d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35047, offset=0x35046, mode=Thumb, size=10, cc=1
i32 sub_35047(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35051, offset=0x35050, mode=Thumb, size=10, cc=1
i32 sub_35051(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3505b, offset=0x3505a, mode=Thumb, size=10, cc=1
i32 sub_3505b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35065, offset=0x35064, mode=Thumb, size=14, cc=1
i32 sub_35065(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35073, offset=0x35072, mode=Thumb, size=12, cc=1
i32 sub_35073(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3507d, offset=0x3507c, mode=Thumb, size=12, cc=1
i32 sub_3507d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35087, offset=0x35086, mode=Thumb, size=8, cc=1
i32 sub_35087(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3508f, offset=0x3508e, mode=Thumb, size=12, cc=1
i32 sub_3508f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35099, offset=0x35098, mode=Thumb, size=12, cc=1
i32 sub_35099(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x350a3, offset=0x350a2, mode=Thumb, size=14, cc=1
i32 sub_350a3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x350af, offset=0x350ae, mode=Thumb, size=12, cc=1
i32 sub_350af(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x350b9, offset=0x350b8, mode=Thumb, size=10, cc=1
i32 sub_350b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x350c3, offset=0x350c2, mode=Thumb, size=10, cc=1
i32 sub_350c3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x350cd, offset=0x350cc, mode=Thumb, size=8, cc=1
i32 sub_350cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x350d5, offset=0x350d4, mode=Thumb, size=10, cc=1
i32 sub_350d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x350df, offset=0x350de, mode=Thumb, size=12, cc=1
i32 sub_350df(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x350e9, offset=0x350e8, mode=Thumb, size=20, cc=1
i32 sub_350e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x350fb, offset=0x350fa, mode=Thumb, size=10, cc=1
i32 sub_350fb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35105, offset=0x35104, mode=Thumb, size=10, cc=1
i32 sub_35105(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3510f, offset=0x3510e, mode=Thumb, size=12, cc=1
i32 sub_3510f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35119, offset=0x35118, mode=Thumb, size=16, cc=1
i32 sub_35119(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35127, offset=0x35126, mode=Thumb, size=16, cc=1
i32 sub_35127(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35135, offset=0x35134, mode=Thumb, size=10, cc=1
i32 sub_35135(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3513d, offset=0x3513c, mode=Thumb, size=8, cc=1
i32 sub_3513d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35145, offset=0x35144, mode=Thumb, size=14, cc=1
i32 sub_35145(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35151, offset=0x35150, mode=Thumb, size=8, cc=1
i32 sub_35151(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35159, offset=0x35158, mode=Thumb, size=14, cc=1
i32 sub_35159(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35165, offset=0x35164, mode=Thumb, size=18, cc=1
i32 sub_35165(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35175, offset=0x35174, mode=Thumb, size=8, cc=1
i32 sub_35175(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3517d, offset=0x3517c, mode=Thumb, size=8, cc=1
i32 sub_3517d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35185, offset=0x35184, mode=Thumb, size=8, cc=1
i32 sub_35185(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3518d, offset=0x3518c, mode=Thumb, size=10, cc=1
i32 sub_3518d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35197, offset=0x35196, mode=Thumb, size=10, cc=1
i32 sub_35197(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3519f, offset=0x3519e, mode=Thumb, size=8, cc=1
i32 sub_3519f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x351a7, offset=0x351a6, mode=Thumb, size=14, cc=1
i32 sub_351a7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x351b3, offset=0x351b2, mode=Thumb, size=12, cc=1
i32 sub_351b3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x351bf, offset=0x351be, mode=Thumb, size=10, cc=1
i32 sub_351bf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x351c7, offset=0x351c6, mode=Thumb, size=10, cc=1
i32 sub_351c7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x351cf, offset=0x351ce, mode=Thumb, size=12, cc=1
i32 sub_351cf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x351db, offset=0x351da, mode=Thumb, size=12, cc=1
i32 sub_351db(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x351e5, offset=0x351e4, mode=Thumb, size=10, cc=1
i32 sub_351e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x351ed, offset=0x351ec, mode=Thumb, size=10, cc=1
i32 sub_351ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x351f5, offset=0x351f4, mode=Thumb, size=8, cc=1
i32 sub_351f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x351fd, offset=0x351fc, mode=Thumb, size=14, cc=1
i32 sub_351fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35209, offset=0x35208, mode=Thumb, size=8, cc=1
i32 sub_35209(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35211, offset=0x35210, mode=Thumb, size=10, cc=1
i32 sub_35211(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35219, offset=0x35218, mode=Thumb, size=8, cc=1
i32 sub_35219(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35221, offset=0x35220, mode=Thumb, size=10, cc=1
i32 sub_35221(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3522b, offset=0x3522a, mode=Thumb, size=14, cc=1
i32 sub_3522b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35237, offset=0x35236, mode=Thumb, size=10, cc=1
i32 sub_35237(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3523f, offset=0x3523e, mode=Thumb, size=12, cc=2
i32 sub_3523f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3524b, offset=0x3524a, mode=Thumb, size=10, cc=1
i32 sub_3524b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35255, offset=0x35254, mode=Thumb, size=12, cc=1
i32 sub_35255(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3525f, offset=0x3525e, mode=Thumb, size=10, cc=1
i32 sub_3525f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35269, offset=0x35268, mode=Thumb, size=10, cc=1
i32 sub_35269(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35271, offset=0x35270, mode=Thumb, size=8, cc=1
i32 sub_35271(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35279, offset=0x35278, mode=Thumb, size=10, cc=1
i32 sub_35279(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35281, offset=0x35280, mode=Thumb, size=10, cc=1
i32 sub_35281(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35289, offset=0x35288, mode=Thumb, size=12, cc=1
i32 sub_35289(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35295, offset=0x35294, mode=Thumb, size=8, cc=1
i32 sub_35295(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3529d, offset=0x3529c, mode=Thumb, size=12, cc=1
i32 sub_3529d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x352a7, offset=0x352a6, mode=Thumb, size=10, cc=1
i32 sub_352a7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x352af, offset=0x352ae, mode=Thumb, size=12, cc=1
i32 sub_352af(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x352b9, offset=0x352b8, mode=Thumb, size=10, cc=1
i32 sub_352b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x352c3, offset=0x352c2, mode=Thumb, size=26, cc=1
i32 sub_352c3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x352dd, offset=0x352dc, mode=Thumb, size=8, cc=1
i32 sub_352dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x352e5, offset=0x352e4, mode=Thumb, size=36, cc=1
i32 sub_352e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35307, offset=0x35306, mode=Thumb, size=16, cc=1
i32 sub_35307(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35317, offset=0x35316, mode=Thumb, size=10, cc=1
i32 sub_35317(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35321, offset=0x35320, mode=Thumb, size=12, cc=1
i32 sub_35321(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3532d, offset=0x3532c, mode=Thumb, size=12, cc=1
i32 sub_3532d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35337, offset=0x35336, mode=Thumb, size=24, cc=1
i32 sub_35337(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3534f, offset=0x3534e, mode=Thumb, size=28, cc=1
i32 sub_3534f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3536b, offset=0x3536a, mode=Thumb, size=8, cc=1
i32 sub_3536b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35373, offset=0x35372, mode=Thumb, size=8, cc=1
i32 sub_35373(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3537b, offset=0x3537a, mode=Thumb, size=10, cc=2
i32 sub_3537b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35385, offset=0x35384, mode=Thumb, size=14, cc=1
i32 sub_35385(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35393, offset=0x35392, mode=Thumb, size=8, cc=1
i32 sub_35393(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3539b, offset=0x3539a, mode=Thumb, size=8, cc=1
i32 sub_3539b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x353a3, offset=0x353a2, mode=Thumb, size=10, cc=1
i32 sub_353a3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x353ab, offset=0x353aa, mode=Thumb, size=12, cc=1
i32 sub_353ab(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x353b5, offset=0x353b4, mode=Thumb, size=12, cc=1
i32 sub_353b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x353bf, offset=0x353be, mode=Thumb, size=14, cc=1
i32 sub_353bf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x353cb, offset=0x353ca, mode=Thumb, size=10, cc=1
i32 sub_353cb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x353d3, offset=0x353d2, mode=Thumb, size=14, cc=1
i32 sub_353d3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x353df, offset=0x353de, mode=Thumb, size=8, cc=1
i32 sub_353df(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x353e7, offset=0x353e6, mode=Thumb, size=10, cc=1
i32 sub_353e7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x353ef, offset=0x353ee, mode=Thumb, size=12, cc=1
i32 sub_353ef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x353f9, offset=0x353f8, mode=Thumb, size=10, cc=1
i32 sub_353f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35403, offset=0x35402, mode=Thumb, size=10, cc=1
i32 sub_35403(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3540d, offset=0x3540c, mode=Thumb, size=8, cc=1
i32 sub_3540d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35413, offset=0x35412, mode=Thumb, size=36, cc=4
i32 sub_35413(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35437, offset=0x35436, mode=Thumb, size=12, cc=1
i32 sub_35437(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35443, offset=0x35442, mode=Thumb, size=30, cc=1
i32 sub_35443(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35461, offset=0x35460, mode=Thumb, size=12, cc=1
i32 sub_35461(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3546b, offset=0x3546a, mode=Thumb, size=14, cc=1
i32 sub_3546b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35477, offset=0x35476, mode=Thumb, size=10, cc=1
i32 sub_35477(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35481, offset=0x35480, mode=Thumb, size=14, cc=1
i32 sub_35481(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3548d, offset=0x3548c, mode=Thumb, size=16, cc=1
i32 sub_3548d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3549b, offset=0x3549a, mode=Thumb, size=6, cc=1
i32 sub_3549b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x354a1, offset=0x354a0, mode=Thumb, size=6, cc=1
i32 sub_354a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x354a7, offset=0x354a6, mode=Thumb, size=10, cc=1
i32 sub_354a7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x354b1, offset=0x354b0, mode=Thumb, size=12, cc=1
i32 sub_354b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x354bb, offset=0x354ba, mode=Thumb, size=10, cc=1
i32 sub_354bb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x354c5, offset=0x354c4, mode=Thumb, size=10, cc=1
i32 sub_354c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x354cf, offset=0x354ce, mode=Thumb, size=10, cc=1
i32 sub_354cf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x354d9, offset=0x354d8, mode=Thumb, size=18, cc=1
i32 sub_354d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x354eb, offset=0x354ea, mode=Thumb, size=12, cc=1
i32 sub_354eb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x354f7, offset=0x354f6, mode=Thumb, size=10, cc=1
i32 sub_354f7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35501, offset=0x35500, mode=Thumb, size=8, cc=1
i32 sub_35501(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35509, offset=0x35508, mode=Thumb, size=12, cc=1
i32 sub_35509(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35513, offset=0x35512, mode=Thumb, size=10, cc=1
i32 sub_35513(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3551d, offset=0x3551c, mode=Thumb, size=18, cc=1
i32 sub_3551d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3552f, offset=0x3552e, mode=Thumb, size=20, cc=1
i32 sub_3552f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35541, offset=0x35540, mode=Thumb, size=10, cc=1
i32 sub_35541(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3554b, offset=0x3554a, mode=Thumb, size=6, cc=1
i32 sub_3554b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35551, offset=0x35550, mode=Thumb, size=10, cc=1
i32 sub_35551(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3555b, offset=0x3555a, mode=Thumb, size=18, cc=1
i32 sub_3555b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3556b, offset=0x3556a, mode=Thumb, size=16, cc=1
i32 sub_3556b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35579, offset=0x35578, mode=Thumb, size=18, cc=1
i32 sub_35579(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35589, offset=0x35588, mode=Thumb, size=16, cc=1
i32 sub_35589(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35599, offset=0x35598, mode=Thumb, size=16, cc=1
i32 sub_35599(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x355a9, offset=0x355a8, mode=Thumb, size=12, cc=1
i32 sub_355a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x355b5, offset=0x355b4, mode=Thumb, size=10, cc=1
i32 sub_355b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x355bd, offset=0x355bc, mode=Thumb, size=10, cc=1
i32 sub_355bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x355c7, offset=0x355c6, mode=Thumb, size=14, cc=1
i32 sub_355c7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x355d3, offset=0x355d2, mode=Thumb, size=8, cc=1
i32 sub_355d3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x355db, offset=0x355da, mode=Thumb, size=12, cc=1
i32 sub_355db(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x355e5, offset=0x355e4, mode=Thumb, size=10, cc=1
i32 sub_355e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x355ef, offset=0x355ee, mode=Thumb, size=12, cc=1
i32 sub_355ef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x355f9, offset=0x355f8, mode=Thumb, size=20, cc=1
i32 sub_355f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3560b, offset=0x3560a, mode=Thumb, size=14, cc=1
i32 sub_3560b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35619, offset=0x35618, mode=Thumb, size=22, cc=2
i32 sub_35619(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3562d, offset=0x3562c, mode=Thumb, size=16, cc=1
i32 sub_3562d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3563d, offset=0x3563c, mode=Thumb, size=10, cc=1
i32 sub_3563d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35645, offset=0x35644, mode=Thumb, size=14, cc=1
i32 sub_35645(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35653, offset=0x35652, mode=Thumb, size=12, cc=1
i32 sub_35653(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3565d, offset=0x3565c, mode=Thumb, size=12, cc=1
i32 sub_3565d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35667, offset=0x35666, mode=Thumb, size=12, cc=1
i32 sub_35667(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35671, offset=0x35670, mode=Thumb, size=10, cc=1
i32 sub_35671(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3567b, offset=0x3567a, mode=Thumb, size=10, cc=1
i32 sub_3567b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35683, offset=0x35682, mode=Thumb, size=10, cc=1
i32 sub_35683(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3568d, offset=0x3568c, mode=Thumb, size=12, cc=1
i32 sub_3568d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35699, offset=0x35698, mode=Thumb, size=10, cc=1
i32 sub_35699(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x356a1, offset=0x356a0, mode=Thumb, size=10, cc=1
i32 sub_356a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x356a9, offset=0x356a8, mode=Thumb, size=10, cc=1
i32 sub_356a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x356b3, offset=0x356b2, mode=Thumb, size=10, cc=1
i32 sub_356b3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x356bd, offset=0x356bc, mode=Thumb, size=12, cc=1
i32 sub_356bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x356c9, offset=0x356c8, mode=Thumb, size=10, cc=1
i32 sub_356c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x356d3, offset=0x356d2, mode=Thumb, size=16, cc=1
i32 sub_356d3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x356e3, offset=0x356e2, mode=Thumb, size=14, cc=1
i32 sub_356e3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x356ef, offset=0x356ee, mode=Thumb, size=12, cc=1
i32 sub_356ef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x356f9, offset=0x356f8, mode=Thumb, size=6, cc=1
i32 sub_356f9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35701, offset=0x35700, mode=Thumb, size=92, cc=3
i32 sub_35701(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3575d, offset=0x3575c, mode=Thumb, size=12, cc=1
i32 sub_3575d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35769, offset=0x35768, mode=Thumb, size=78, cc=4
i32 sub_35769(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x357b9, offset=0x357b8, mode=Thumb, size=8, cc=1
i32 sub_357b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x357c1, offset=0x357c0, mode=Thumb, size=460, cc=32
i32 sub_357c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x359c1, offset=0x359c0, mode=Thumb, size=60, cc=1
i32 sub_359c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x359fd, offset=0x359fc, mode=Thumb, size=8, cc=1
i32 sub_359fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35a05, offset=0x35a04, mode=Thumb, size=48, cc=1
i32 sub_35a05(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35a35, offset=0x35a34, mode=Thumb, size=8, cc=1
i32 sub_35a35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35a3d, offset=0x35a3c, mode=Thumb, size=76, cc=1
i32 sub_35a3d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35a89, offset=0x35a88, mode=Thumb, size=8, cc=1
i32 sub_35a89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35a91, offset=0x35a90, mode=Thumb, size=50, cc=1
i32 sub_35a91(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35ac5, offset=0x35ac4, mode=Thumb, size=8, cc=1
i32 sub_35ac5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35acd, offset=0x35acc, mode=Thumb, size=104, cc=1
i32 sub_35acd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35b35, offset=0x35b34, mode=Thumb, size=8, cc=1
i32 sub_35b35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35b3d, offset=0x35b3c, mode=Thumb, size=82, cc=1
i32 sub_35b3d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35b91, offset=0x35b90, mode=Thumb, size=8, cc=1
i32 sub_35b91(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35b99, offset=0x35b98, mode=Thumb, size=76, cc=1
i32 sub_35b99(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35be5, offset=0x35be4, mode=Thumb, size=8, cc=1
i32 sub_35be5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35bed, offset=0x35bec, mode=Thumb, size=50, cc=1
i32 sub_35bed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35c21, offset=0x35c20, mode=Thumb, size=8, cc=1
i32 sub_35c21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35c29, offset=0x35c28, mode=Thumb, size=122, cc=8
i32 sub_35c29(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35ca5, offset=0x35ca4, mode=Thumb, size=8, cc=1
i32 sub_35ca5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35cad, offset=0x35cac, mode=Thumb, size=60, cc=1
i32 sub_35cad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35ce9, offset=0x35ce8, mode=Thumb, size=8, cc=1
i32 sub_35ce9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35cf1, offset=0x35cf0, mode=Thumb, size=76, cc=2
i32 sub_35cf1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35d3d, offset=0x35d3c, mode=Thumb, size=8, cc=1
i32 sub_35d3d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35d45, offset=0x35d44, mode=Thumb, size=152, cc=4
i32 sub_35d45(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35dfd, offset=0x35dfc, mode=Thumb, size=12, cc=1
i32 sub_35dfd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35e09, offset=0x35e08, mode=Thumb, size=64, cc=2
i32 sub_35e09(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35e49, offset=0x35e48, mode=Thumb, size=8, cc=1
i32 sub_35e49(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35e51, offset=0x35e50, mode=Thumb, size=78, cc=3
i32 sub_35e51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35ea1, offset=0x35ea0, mode=Thumb, size=8, cc=1
i32 sub_35ea1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35ea9, offset=0x35ea8, mode=Thumb, size=58, cc=1
i32 sub_35ea9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35ee5, offset=0x35ee4, mode=Thumb, size=8, cc=1
i32 sub_35ee5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35eed, offset=0x35eec, mode=Thumb, size=64, cc=1
i32 sub_35eed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35f2d, offset=0x35f2c, mode=Thumb, size=12, cc=1
i32 sub_35f2d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x35f39, offset=0x35f38, mode=Thumb, size=242, cc=10
i32 sub_35f39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3605d, offset=0x3605c, mode=Thumb, size=72, cc=4
i32 sub_3605d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x360b9, offset=0x360b8, mode=Thumb, size=66, cc=1
i32 sub_360b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x360fd, offset=0x360fc, mode=Thumb, size=8, cc=1
i32 sub_360fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36105, offset=0x36104, mode=Thumb, size=276, cc=11
i32 sub_36105(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36251, offset=0x36250, mode=Thumb, size=28, cc=1
i32 sub_36251(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3626d, offset=0x3626c, mode=Thumb, size=52, cc=1
i32 sub_3626d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x362a1, offset=0x362a0, mode=Thumb, size=8, cc=1
i32 sub_362a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x362a9, offset=0x362a8, mode=Thumb, size=42, cc=1
i32 sub_362a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x362d5, offset=0x362d4, mode=Thumb, size=8, cc=1
i32 sub_362d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x362dd, offset=0x362dc, mode=Thumb, size=52, cc=1
i32 sub_362dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36311, offset=0x36310, mode=Thumb, size=8, cc=1
i32 sub_36311(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36319, offset=0x36318, mode=Thumb, size=96, cc=5
i32 sub_36319(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36379, offset=0x36378, mode=Thumb, size=8, cc=1
i32 sub_36379(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36381, offset=0x36380, mode=Thumb, size=76, cc=2
i32 sub_36381(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x363cd, offset=0x363cc, mode=Thumb, size=8, cc=1
i32 sub_363cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x363d5, offset=0x363d4, mode=Thumb, size=90, cc=2
i32 sub_363d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36449, offset=0x36448, mode=Thumb, size=64, cc=2
i32 sub_36449(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3649d, offset=0x3649c, mode=Thumb, size=58, cc=1
i32 sub_3649d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x364d9, offset=0x364d8, mode=Thumb, size=8, cc=1
i32 sub_364d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x364e1, offset=0x364e0, mode=Thumb, size=108, cc=1
i32 sub_364e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3654d, offset=0x3654c, mode=Thumb, size=12, cc=1
i32 sub_3654d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36559, offset=0x36558, mode=Thumb, size=58, cc=1
i32 sub_36559(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36595, offset=0x36594, mode=Thumb, size=8, cc=1
i32 sub_36595(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3659d, offset=0x3659c, mode=Thumb, size=56, cc=1
i32 sub_3659d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x365d5, offset=0x365d4, mode=Thumb, size=8, cc=1
i32 sub_365d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x365dd, offset=0x365dc, mode=Thumb, size=64, cc=1
i32 sub_365dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3662d, offset=0x3662c, mode=Thumb, size=50, cc=1
i32 sub_3662d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36661, offset=0x36660, mode=Thumb, size=8, cc=1
i32 sub_36661(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36669, offset=0x36668, mode=Thumb, size=138, cc=1
i32 sub_36669(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36719, offset=0x36718, mode=Thumb, size=50, cc=1
i32 sub_36719(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3674d, offset=0x3674c, mode=Thumb, size=8, cc=1
i32 sub_3674d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36755, offset=0x36754, mode=Thumb, size=48, cc=1
i32 sub_36755(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36789, offset=0x36788, mode=Thumb, size=182, cc=8
i32 sub_36789(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36861, offset=0x36860, mode=Thumb, size=50, cc=1
i32 sub_36861(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36895, offset=0x36894, mode=Thumb, size=8, cc=1
i32 sub_36895(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3689d, offset=0x3689c, mode=Thumb, size=66, cc=1
i32 sub_3689d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368e1, offset=0x368e0, mode=Thumb, size=12, cc=1
i32 sub_368e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x368ed, offset=0x368ec, mode=Thumb, size=60, cc=1
i32 sub_368ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36939, offset=0x36938, mode=Thumb, size=50, cc=1
i32 sub_36939(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3696d, offset=0x3696c, mode=Thumb, size=8, cc=1
i32 sub_3696d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36975, offset=0x36974, mode=Thumb, size=50, cc=1
i32 sub_36975(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369a9, offset=0x369a8, mode=Thumb, size=8, cc=1
i32 sub_369a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369b1, offset=0x369b0, mode=Thumb, size=50, cc=1
i32 sub_369b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369e5, offset=0x369e4, mode=Thumb, size=8, cc=1
i32 sub_369e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x369ed, offset=0x369ec, mode=Thumb, size=48, cc=1
i32 sub_369ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a1d, offset=0x36a1c, mode=Thumb, size=8, cc=1
i32 sub_36a1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a25, offset=0x36a24, mode=Thumb, size=66, cc=1
i32 sub_36a25(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a69, offset=0x36a68, mode=Thumb, size=8, cc=1
i32 sub_36a69(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36a71, offset=0x36a70, mode=Thumb, size=78, cc=1
i32 sub_36a71(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ac1, offset=0x36ac0, mode=Thumb, size=8, cc=1
i32 sub_36ac1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ac9, offset=0x36ac8, mode=Thumb, size=66, cc=1
i32 sub_36ac9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b0d, offset=0x36b0c, mode=Thumb, size=8, cc=1
i32 sub_36b0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b15, offset=0x36b14, mode=Thumb, size=58, cc=1
i32 sub_36b15(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b51, offset=0x36b50, mode=Thumb, size=12, cc=1
i32 sub_36b51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36b5d, offset=0x36b5c, mode=Thumb, size=60, cc=1
i32 sub_36b5d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ba9, offset=0x36ba8, mode=Thumb, size=34, cc=1
i32 sub_36ba9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36bcd, offset=0x36bcc, mode=Thumb, size=8, cc=1
i32 sub_36bcd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36bd5, offset=0x36bd4, mode=Thumb, size=128, cc=13
i32 sub_36bd5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36c55, offset=0x36c54, mode=Thumb, size=8, cc=1
i32 sub_36c55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36c5d, offset=0x36c5c, mode=Thumb, size=60, cc=1
i32 sub_36c5d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ca3, offset=0x36ca2, mode=Thumb, size=2, cc=1
i32 sub_36ca3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36ca5, offset=0x36ca4, mode=Thumb, size=68, cc=1
i32 sub_36ca5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36cf9, offset=0x36cf8, mode=Thumb, size=40, cc=1
i32 sub_36cf9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36d25, offset=0x36d24, mode=Thumb, size=78, cc=3
i32 sub_36d25(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36d75, offset=0x36d74, mode=Thumb, size=8, cc=1
i32 sub_36d75(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36d7d, offset=0x36d7c, mode=Thumb, size=58, cc=1
i32 sub_36d7d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36db9, offset=0x36db8, mode=Thumb, size=8, cc=1
i32 sub_36db9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36dc1, offset=0x36dc0, mode=Thumb, size=50, cc=1
i32 sub_36dc1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36df5, offset=0x36df4, mode=Thumb, size=8, cc=1
i32 sub_36df5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36dfd, offset=0x36dfc, mode=Thumb, size=160, cc=11
i32 sub_36dfd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36eb9, offset=0x36eb8, mode=Thumb, size=72, cc=4
i32 sub_36eb9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36f11, offset=0x36f10, mode=Thumb, size=42, cc=1
i32 sub_36f11(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36f3d, offset=0x36f3c, mode=Thumb, size=8, cc=1
i32 sub_36f3d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36f45, offset=0x36f44, mode=Thumb, size=66, cc=2
i32 sub_36f45(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36f89, offset=0x36f88, mode=Thumb, size=8, cc=1
i32 sub_36f89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36f91, offset=0x36f90, mode=Thumb, size=66, cc=1
i32 sub_36f91(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36fd5, offset=0x36fd4, mode=Thumb, size=8, cc=1
i32 sub_36fd5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36fdd, offset=0x36fdc, mode=Thumb, size=214, cc=15
i32 sub_36fdd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x370d9, offset=0x370d8, mode=Thumb, size=52, cc=1
i32 sub_370d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3710d, offset=0x3710c, mode=Thumb, size=12, cc=1
i32 sub_3710d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37119, offset=0x37118, mode=Thumb, size=24, cc=1
i32 sub_37119(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37131, offset=0x37130, mode=Thumb, size=66, cc=1
i32 sub_37131(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37175, offset=0x37174, mode=Thumb, size=8, cc=1
i32 sub_37175(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3717d, offset=0x3717c, mode=Thumb, size=34, cc=1
i32 sub_3717d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x371a1, offset=0x371a0, mode=Thumb, size=8, cc=1
i32 sub_371a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x371a9, offset=0x371a8, mode=Thumb, size=278, cc=13
i32 sub_371a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x372c1, offset=0x372c0, mode=Thumb, size=4, cc=1
i32 sub_372c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x372c5, offset=0x372c4, mode=Thumb, size=120, cc=15
i32 sub_372c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37345, offset=0x37344, mode=Thumb, size=26, cc=2
i32 sub_37345(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37361, offset=0x37360, mode=Thumb, size=210, cc=12
i32 sub_37361(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37465, offset=0x37464, mode=Thumb, size=34, cc=4
i32 sub_37465(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37489, offset=0x37488, mode=Thumb, size=22, cc=3
i32 sub_37489(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x374a1, offset=0x374a0, mode=Thumb, size=4, cc=1
i32 sub_374a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x374a5, offset=0x374a4, mode=Thumb, size=36, cc=2
i32 sub_374a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x374c9, offset=0x374c8, mode=Thumb, size=4, cc=1
i32 sub_374c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x374cd, offset=0x374cc, mode=Thumb, size=30, cc=2
i32 sub_374cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x374ed, offset=0x374ec, mode=Thumb, size=8, cc=1
i32 sub_374ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x374f5, offset=0x374f4, mode=Thumb, size=22, cc=1
i32 sub_374f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3750d, offset=0x3750c, mode=Thumb, size=4, cc=1
i32 sub_3750d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37511, offset=0x37510, mode=Thumb, size=82, cc=10
i32 sub_37511(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37565, offset=0x37564, mode=Thumb, size=110, cc=9
i32 sub_37565(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x375d5, offset=0x375d4, mode=Thumb, size=8, cc=1
i32 sub_375d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x375dd, offset=0x375dc, mode=Thumb, size=78, cc=7
i32 sub_375dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3762d, offset=0x3762c, mode=Thumb, size=94, cc=10
i32 sub_3762d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3768d, offset=0x3768c, mode=Thumb, size=32, cc=2
i32 sub_3768d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x376ad, offset=0x376ac, mode=Thumb, size=4, cc=1
i32 sub_376ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x376b1, offset=0x376b0, mode=Thumb, size=272, cc=24
i32 sub_376b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x377c1, offset=0x377c0, mode=Thumb, size=50, cc=3
i32 sub_377c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x377f5, offset=0x377f4, mode=Thumb, size=8, cc=1
i32 sub_377f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x377fd, offset=0x377fc, mode=Thumb, size=110, cc=5
i32 sub_377fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3787d, offset=0x3787c, mode=Thumb, size=36, cc=1
i32 sub_3787d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x378ad, offset=0x378ac, mode=Thumb, size=12, cc=1
i32 sub_378ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x378b9, offset=0x378b8, mode=Thumb, size=4, cc=1
i32 sub_378b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x378bd, offset=0x378bc, mode=Thumb, size=88, cc=7
i32 sub_378bd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37915, offset=0x37914, mode=Thumb, size=28, cc=1
i32 sub_37915(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37931, offset=0x37930, mode=Thumb, size=42, cc=1
i32 sub_37931(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3795d, offset=0x3795c, mode=Thumb, size=4, cc=1
i32 sub_3795d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37961, offset=0x37960, mode=Thumb, size=110, cc=9
i32 sub_37961(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x379d1, offset=0x379d0, mode=Thumb, size=4, cc=1
i32 sub_379d1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x379d5, offset=0x379d4, mode=Thumb, size=832, cc=31
i32 sub_379d5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37d49, offset=0x37d48, mode=Thumb, size=38, cc=1
i32 sub_37d49(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37d71, offset=0x37d70, mode=Thumb, size=84, cc=3
i32 sub_37d71(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37dc5, offset=0x37dc4, mode=Thumb, size=4, cc=1
i32 sub_37dc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37dc9, offset=0x37dc8, mode=Thumb, size=120, cc=12
i32 sub_37dc9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37e69, offset=0x37e68, mode=Thumb, size=32, cc=1
i32 sub_37e69(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x37e89, offset=0x37e88, mode=Thumb, size=644, cc=31
i32 sub_37e89(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38125, offset=0x38124, mode=Thumb, size=236, cc=18
i32 sub_38125(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38229, offset=0x38228, mode=Thumb, size=32, cc=1
i32 sub_38229(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38249, offset=0x38248, mode=Thumb, size=502, cc=49
i32 sub_38249(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38441, offset=0x38440, mode=Thumb, size=8, cc=1
i32 sub_38441(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38449, offset=0x38448, mode=Thumb, size=80, cc=5
i32 sub_38449(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38499, offset=0x38498, mode=Thumb, size=12, cc=1
i32 sub_38499(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x384a5, offset=0x384a4, mode=Thumb, size=186, cc=11
i32 sub_384a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38589, offset=0x38588, mode=Thumb, size=428, cc=31
i32 sub_38589(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38751, offset=0x38750, mode=Thumb, size=194, cc=17
i32 sub_38751(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38829, offset=0x38828, mode=Thumb, size=136, cc=13
i32 sub_38829(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x388c1, offset=0x388c0, mode=Thumb, size=100, cc=9
i32 sub_388c1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38939, offset=0x38938, mode=Thumb, size=62, cc=6
i32 sub_38939(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38979, offset=0x38978, mode=Thumb, size=8, cc=1
i32 sub_38979(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38981, offset=0x38980, mode=Thumb, size=264, cc=21
i32 sub_38981(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38a9d, offset=0x38a9c, mode=Thumb, size=860, cc=65
i32 sub_38a9d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38e35, offset=0x38e34, mode=Thumb, size=610, cc=29
i32 sub_38e35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x390c9, offset=0x390c8, mode=Thumb, size=90, cc=5
i32 sub_390c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39125, offset=0x39124, mode=Thumb, size=12, cc=1
i32 sub_39125(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39131, offset=0x39130, mode=Thumb, size=60, cc=5
i32 sub_39131(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3916d, offset=0x3916c, mode=Thumb, size=12, cc=1
i32 sub_3916d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39179, offset=0x39178, mode=Thumb, size=38, cc=1
i32 sub_39179(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x391a1, offset=0x391a0, mode=Thumb, size=8, cc=1
i32 sub_391a1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x391a9, offset=0x391a8, mode=Thumb, size=52, cc=5
i32 sub_391a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x391dd, offset=0x391dc, mode=Thumb, size=4, cc=1
i32 sub_391dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x391e1, offset=0x391e0, mode=Thumb, size=62, cc=4
i32 sub_391e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39221, offset=0x39220, mode=Thumb, size=8, cc=1
i32 sub_39221(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39229, offset=0x39228, mode=Thumb, size=90, cc=7
i32 sub_39229(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39285, offset=0x39284, mode=Thumb, size=8, cc=1
i32 sub_39285(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3928d, offset=0x3928c, mode=Thumb, size=88, cc=3
i32 sub_3928d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x392e5, offset=0x392e4, mode=Thumb, size=4, cc=1
i32 sub_392e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x392e9, offset=0x392e8, mode=Thumb, size=418, cc=34
i32 sub_392e9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x394a5, offset=0x394a4, mode=Thumb, size=4, cc=1
i32 sub_394a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x394a9, offset=0x394a8, mode=Thumb, size=56, cc=3
i32 sub_394a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x394e1, offset=0x394e0, mode=Thumb, size=4, cc=1
i32 sub_394e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x394e5, offset=0x394e4, mode=Thumb, size=466, cc=36
i32 sub_394e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x396e5, offset=0x396e4, mode=Thumb, size=180, cc=14
i32 sub_396e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x397ad, offset=0x397ac, mode=Thumb, size=288, cc=26
i32 sub_397ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x398cd, offset=0x398cc, mode=Thumb, size=90, cc=8
i32 sub_398cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39929, offset=0x39928, mode=Thumb, size=198, cc=13
i32 sub_39929(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39a05, offset=0x39a04, mode=Thumb, size=152, cc=9
i32 sub_39a05(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39a9d, offset=0x39a9c, mode=Thumb, size=8, cc=1
i32 sub_39a9d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39aa5, offset=0x39aa4, mode=Thumb, size=120, cc=8
i32 sub_39aa5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39b1d, offset=0x39b1c, mode=Thumb, size=8, cc=1
i32 sub_39b1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39b25, offset=0x39b24, mode=Thumb, size=148, cc=11
i32 sub_39b25(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39bb9, offset=0x39bb8, mode=Thumb, size=4, cc=1
i32 sub_39bb9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39bbd, offset=0x39bbc, mode=Thumb, size=30, cc=3
i32 sub_39bbd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39bdd, offset=0x39bdc, mode=Thumb, size=8, cc=1
i32 sub_39bdd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39be5, offset=0x39be4, mode=Thumb, size=58, cc=4
i32 sub_39be5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39c21, offset=0x39c20, mode=Thumb, size=4, cc=1
i32 sub_39c21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39c25, offset=0x39c24, mode=Thumb, size=68, cc=3
i32 sub_39c25(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39c69, offset=0x39c68, mode=Thumb, size=4, cc=1
i32 sub_39c69(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39c6d, offset=0x39c6c, mode=Thumb, size=66, cc=3
i32 sub_39c6d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39cb1, offset=0x39cb0, mode=Thumb, size=16, cc=1
i32 sub_39cb1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39cc1, offset=0x39cc0, mode=Thumb, size=16, cc=2
i32 sub_39cc1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39cd1, offset=0x39cd0, mode=Thumb, size=10, cc=1
i32 sub_39cd1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39cdd, offset=0x39cdc, mode=Thumb, size=46, cc=5
i32 sub_39cdd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39d0d, offset=0x39d0c, mode=Thumb, size=136, cc=8
i32 sub_39d0d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39d95, offset=0x39d94, mode=Thumb, size=42, cc=3
i32 sub_39d95(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39dc1, offset=0x39dc0, mode=Thumb, size=86, cc=8
i32 sub_39dc1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39e19, offset=0x39e18, mode=Thumb, size=50, cc=4
i32 sub_39e19(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39e4d, offset=0x39e4c, mode=Thumb, size=126, cc=13
i32 sub_39e4d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39ecd, offset=0x39ecc, mode=Thumb, size=12, cc=1
i32 sub_39ecd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39ed9, offset=0x39ed8, mode=Thumb, size=908, cc=67
i32 sub_39ed9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a2b5, offset=0x3a2b4, mode=Thumb, size=16, cc=1
i32 sub_3a2b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a2c9, offset=0x3a2c8, mode=Thumb, size=16, cc=1
i32 sub_3a2c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a2dd, offset=0x3a2dc, mode=Thumb, size=36, cc=1
i32 sub_3a2dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a301, offset=0x3a300, mode=Thumb, size=52, cc=2
i32 sub_3a301(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a334, offset=0x3a334, mode=ARM, size=44, cc=1
i32 sub_3a334(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a369, offset=0x3a368, mode=Thumb, size=8, cc=1
i32 sub_3a369(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a371, offset=0x3a370, mode=Thumb, size=30, cc=1
i32 sub_3a371(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a391, offset=0x3a390, mode=Thumb, size=8, cc=1
i32 sub_3a391(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a399, offset=0x3a398, mode=Thumb, size=68, cc=5
i32 sub_3a399(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a3dd, offset=0x3a3dc, mode=Thumb, size=8, cc=1
i32 sub_3a3dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a3e5, offset=0x3a3e4, mode=Thumb, size=256, cc=7
i32 sub_3a3e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a4e5, offset=0x3a4e4, mode=Thumb, size=126, cc=3
i32 sub_3a4e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a67f, offset=0x3a67e, mode=Thumb, size=200, cc=1
i32 sub_3a67f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a8e3, offset=0x3a8e2, mode=Thumb, size=160, cc=1
i32 sub_3a8e3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a987, offset=0x3a986, mode=Thumb, size=14, cc=1
i32 sub_3a987(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a99d, offset=0x3a99c, mode=Thumb, size=6, cc=1
i32 sub_3a99d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a9ab, offset=0x3a9aa, mode=Thumb, size=6, cc=1
i32 sub_3a9ab(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a9b1, offset=0x3a9b0, mode=Thumb, size=2, cc=1
i32 sub_3a9b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a9d0, offset=0x3a9d0, mode=ARM, size=12, cc=1
i32 sub_3a9d0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a9fd, offset=0x3a9fc, mode=Thumb, size=4, cc=1
i32 sub_3a9fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aa01, offset=0x3aa00, mode=Thumb, size=12, cc=1
i32 sub_3aa01(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aa15, offset=0x3aa14, mode=Thumb, size=8, cc=1
i32 sub_3aa15(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aa21, offset=0x3aa20, mode=Thumb, size=4, cc=1
i32 sub_3aa21(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aa2c, offset=0x3aa2c, mode=ARM, size=14, cc=1
i32 sub_3aa2c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aa47, offset=0x3aa46, mode=Thumb, size=2, cc=1
i32 sub_3aa47(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aa49, offset=0x3aa48, mode=Thumb, size=4, cc=1
i32 sub_3aa49(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aa4d, offset=0x3aa4c, mode=Thumb, size=4, cc=1
i32 sub_3aa4d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aa51, offset=0x3aa50, mode=Thumb, size=6, cc=1
i32 sub_3aa51(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aa80, offset=0x3aa80, mode=ARM, size=12, cc=1
i32 sub_3aa80(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aaa4, offset=0x3aaa4, mode=ARM, size=8, cc=1
i32 sub_3aaa4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aaac, offset=0x3aaac, mode=ARM, size=4, cc=1
i32 sub_3aaac(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aaef, offset=0x3aaee, mode=Thumb, size=14, cc=1
i32 sub_3aaef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aafd, offset=0x3aafc, mode=Thumb, size=18, cc=1
i32 sub_3aafd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ab14, offset=0x3ab14, mode=ARM, size=6, cc=1
i32 sub_3ab14(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ab45, offset=0x3ab44, mode=Thumb, size=4, cc=1
i32 sub_3ab45(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ab4c, offset=0x3ab4c, mode=ARM, size=4, cc=1
i32 sub_3ab4c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ab7c, offset=0x3ab7c, mode=ARM, size=12, cc=1
i32 sub_3ab7c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ab8c, offset=0x3ab8c, mode=ARM, size=8, cc=1
i32 sub_3ab8c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ab9f, offset=0x3ab9e, mode=Thumb, size=18, cc=1
i32 sub_3ab9f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3abc8, offset=0x3abc8, mode=ARM, size=4, cc=1
i32 sub_3abc8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3abd0, offset=0x3abd0, mode=ARM, size=12, cc=1
i32 sub_3abd0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3abef, offset=0x3abee, mode=Thumb, size=16, cc=1
i32 sub_3abef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ac08, offset=0x3ac08, mode=ARM, size=10, cc=1
i32 sub_3ac08(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ac16, offset=0x3ac16, mode=ARM, size=8, cc=1
i32 sub_3ac16(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3acb3, offset=0x3acb2, mode=Thumb, size=2, cc=1
i32 sub_3acb3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3acc0, offset=0x3acc0, mode=ARM, size=8, cc=1
i32 sub_3acc0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3acd7, offset=0x3acd6, mode=Thumb, size=2, cc=1
i32 sub_3acd7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3acd9, offset=0x3acd8, mode=Thumb, size=2, cc=1
i32 sub_3acd9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3acdf, offset=0x3acde, mode=Thumb, size=2, cc=1
i32 sub_3acdf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ace8, offset=0x3ace8, mode=ARM, size=16, cc=1
i32 sub_3ace8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ad3c, offset=0x3ad3c, mode=ARM, size=4, cc=1
i32 sub_3ad3c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ad49, offset=0x3ad48, mode=Thumb, size=6, cc=1
i32 sub_3ad49(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ade7, offset=0x3ade6, mode=Thumb, size=2, cc=1
i32 sub_3ade7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ade9, offset=0x3ade8, mode=Thumb, size=2, cc=1
i32 sub_3ade9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3adeb, offset=0x3adea, mode=Thumb, size=14, cc=1
i32 sub_3adeb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ae61, offset=0x3ae60, mode=Thumb, size=4, cc=1
i32 sub_3ae61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ae75, offset=0x3ae74, mode=Thumb, size=2, cc=1
i32 sub_3ae75(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ae7b, offset=0x3ae7a, mode=Thumb, size=2, cc=1
i32 sub_3ae7b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ae8f, offset=0x3ae8e, mode=Thumb, size=2, cc=1
i32 sub_3ae8f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ae98, offset=0x3ae98, mode=ARM, size=4, cc=1
i32 sub_3ae98(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aeb4, offset=0x3aeb4, mode=ARM, size=4, cc=1
i32 sub_3aeb4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aebd, offset=0x3aebc, mode=Thumb, size=52, cc=1
i32 sub_3aebd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aef1, offset=0x3aef0, mode=Thumb, size=2, cc=1
i32 sub_3aef1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3aef5, offset=0x3aef4, mode=Thumb, size=4, cc=1
i32 sub_3aef5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3af03, offset=0x3af02, mode=Thumb, size=2, cc=1
i32 sub_3af03(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3af05, offset=0x3af04, mode=Thumb, size=14, cc=1
i32 sub_3af05(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3af1f, offset=0x3af1e, mode=Thumb, size=2, cc=1
i32 sub_3af1f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3af27, offset=0x3af26, mode=Thumb, size=2, cc=1
i32 sub_3af27(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3af29, offset=0x3af28, mode=Thumb, size=2, cc=1
i32 sub_3af29(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3af38, offset=0x3af38, mode=ARM, size=12, cc=1
i32 sub_3af38(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3af5c, offset=0x3af5c, mode=ARM, size=8, cc=1
i32 sub_3af5c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3af79, offset=0x3af78, mode=Thumb, size=2, cc=1
i32 sub_3af79(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3af7b, offset=0x3af7a, mode=Thumb, size=2, cc=1
i32 sub_3af7b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3af8b, offset=0x3af8a, mode=Thumb, size=8, cc=1
i32 sub_3af8b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3af95, offset=0x3af94, mode=Thumb, size=4, cc=1
i32 sub_3af95(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3afa4, offset=0x3afa4, mode=ARM, size=8, cc=1
i32 sub_3afa4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3afc5, offset=0x3afc4, mode=Thumb, size=2, cc=1
i32 sub_3afc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3afcc, offset=0x3afcc, mode=ARM, size=8, cc=1
i32 sub_3afcc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3afdf, offset=0x3afde, mode=Thumb, size=2, cc=1
i32 sub_3afdf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3afe1, offset=0x3afe0, mode=Thumb, size=2, cc=1
i32 sub_3afe1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3afe7, offset=0x3afe6, mode=Thumb, size=2, cc=1
i32 sub_3afe7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3afec, offset=0x3afec, mode=ARM, size=8, cc=1
i32 sub_3afec(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3b00d, offset=0x3b00c, mode=Thumb, size=20, cc=1
i32 sub_3b00d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3b025, offset=0x3b024, mode=Thumb, size=10, cc=1
i32 sub_3b025(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x100014, offset=0x100014, mode=ARM, size=0, cc=1
i32 UnresolvableJumpTarget(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x100018, offset=0x100018, mode=ARM, size=0, cc=1
i32 UnresolvableCallTarget(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

