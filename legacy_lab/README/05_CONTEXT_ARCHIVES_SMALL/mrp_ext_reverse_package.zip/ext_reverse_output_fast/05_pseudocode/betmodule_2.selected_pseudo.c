/* Selected recovered pseudo-C for betmodule_2. Not original source. */


/* ===== _start @ 0x8, size=20, cc=1 ===== */
int _start(int a0)
{
    return sub_29e5(a0);
}


/* ===== sub_1a2d @ 0x1a2d, size=1986, cc=74 ===== */
typedef struct struct_0 {
    char padding_0[4];
    int field_4;
} struct_0;

extern char g_1;
extern char g_10;
extern int g_11;
extern int g_123;
extern int g_124;
extern int g_12f;
extern int g_137;
extern int g_14;
extern char g_18;
extern int g_1d;
extern char g_1f;
extern char g_2;
extern int g_23;
extern int g_2a;
extern int g_2d;
extern int g_2e;
extern int g_2f;
extern char g_3;
extern int g_30;
extern int g_31;
extern int g_32;
extern int g_327c;
extern int g_3284;
extern int g_328c;
extern int g_329c;
extern int g_32a0;
extern char g_32ac;
extern int g_32c4;
extern int g_32c8;
extern int g_32dc;
extern int g_32e4;
extern char g_32e8;
extern int g_32f8;
extern int g_32fc;
extern int g_3304;
extern char g_331c;
extern char g_3324;
extern char g_3330;
extern int g_35;
extern int g_3c;
extern int g_3f;
extern int g_4;
extern int g_41;
extern int g_5;
extern int g_56;
extern char g_6;
extern int g_7;
extern int g_9;
extern int g_9b;
extern int g_a;
extern int g_b;
extern char g_c;
extern int g_e1;
extern int g_ed;
extern int g_ff;

int sub_1a2d(void)
{
    int v19;  // r4
    int v20;  // r0
    int v29;  // r7
    int v31;  // r6
    int v32;  // r5
    int idx;  // r7
    int v34;  // r5
    unsigned int *index;  // r1
    int v36;  // r0
    unsigned int v37;  // r6
    unsigned int v38;  // r0
    int v21;  // r6
    int v39;  // r5
    int v40;  // r5
    int i;  // r6
    unsigned int v42;  // r0
    unsigned int idx1[9];  // r1
    struct_0 *v44;  // r1
    unsigned int v22;  // r9
    int v23;  // r7
    int v24;  // r0
    int v25;  // r0
    int v26;  // r0
    int v27;  // r7
    unsigned int v0;  // [bp-0x5c]
    unsigned int v1;  // [bp-0x58]
    unsigned int v2;  // [bp-0x54], Other Possible Types: int
    int v3;  // [bp-0x50]
    unsigned int v4;  // [bp-0x4c], Other Possible Types: int
    int v5;  // [bp-0x48]
    unsigned int v6;  // [bp-0x44], Other Possible Types: int
    unsigned int v7;  // [bp-0x40], Other Possible Types: int
    char v8;  // [bp-0x3c], Other Possible Types: int
    char v9;  // [bp-0x3b]
    unsigned int v10;  // [bp-0x38]
    int v11;  // [bp-0x34]
    int v12;  // [bp-0x30]
    int v13;  // [bp-0x2c]
    int v14;  // [bp-0x28]
    int v15;  // [bp-0x24], Other Possible Types: unsigned int
    char v16;  // [bp-0x20], Other Possible Types: unsigned int
    char v17;  // [bp-0x1c], Other Possible Types: unsigned int
    int v18;  // [bp-0x18]

    v19 = sub_2abd(0x1e200, sub_1c, "M", "M", "M", "M", "M");
    v20 = sub_2abd(0x1e200, 225, 237, "M", "M", "M", "M");
    if (v20 <= sub_0)
        return v20;
    sub_2abd(0x1e200, 292, "M", "M", "M", "M", "M");
    sub_2a6d("M", "M", "M");
    sub_2abd(0x1e200, 42, 0x327c, "M", "M", &v17, &v16);
    v21 = v16 * 3 + 12;
    v11 = v16 * 5 + 16;
    sub_2abd(0x1e200, 50, "M", "M", v19, v21, "M");
    sub_2abd(0x1e200, 35, 7, "M", "M", v19, v21);
    v15 = 5;
    if (*((int *)(4 + v22 + 4)) != 4294967295)
    {
        v23 = sub_2abd(0x1e200, 63, *((int *)(4 + v22 + 4)), "M", "M", "M", "M");
        v12 = sub_2abd(0x1e200, 45, sub_3294, v23, "M", "M", "M");
        sub_2abd(0x1e200, 9, v23, "M", "M", "M", "M");
        v24 = sub_2abd(0x1e200, 45, v12, 0x328c, "M", "M", "M");
        v25 = sub_2abd(0x1e200, 45, sub_2abd(0x1e200, 45, v24, *((int *)(20 + v22)), "M", "M", "M"), 0x3284, "M", "M", "M");
        v26 = sub_2abd(0x1e200, 45, v25, *((int *)(12 + v22 + 12)), "M", "M", "M");
    }
    else
    {
        v26 = sub_2abd(0x1e200, 45, sub_2abd(0x1e200, 45, 0x32a0, *((int *)(20 + v22)), "M", "M", "M"), 0x329c, "M", "M", "M");
    }
    sub_2abd(0x1e200, 311, v26, 5, v15, "M", "M");
    sub_2abd(0x1e200, 42, v26, "M", "M", &v17, &v16);
    v15 = v16 + 7;
    v27 = sub_2abd(0x1e200, 53, sub_2abd(0x1e200, 291, "M", *((int *)(12 + v22 + 16)), "M", "M", "M"), 0x32e4, "M", "M", "M");
    v12 = sub_2abd(0x1e200, 45, 0x32dc, v27, "M", "M", "M");
    sub_2abd(0x1e200, 9, v27, "M", "M", "M", "M");
    sub_2abd(0x1e200, 311, sub_2abd(0x1e200, 45, v12, 0x32c8, "M", "M", "M"), 5, v15, "M", "M");
    v29 = v15 + v16 + 2;
    sub_2abd(0x1e200, 311, sub_2abd(0x1e200, 45, sub_2abd(0x1e200, 45, 0x32c4, *((int *)(12 + v22 + 20)), "M", "M", "M"), 0x329c, "M", "M", "M"), 5, v29, "M", "M");
    v10 = v16 + 6;
    v31 = v29 + v16 + 2;
    sub_2abd(0x1e200, 46, "M", v31, v19, v10, "M");
    sub_2abd(0x1e200, 42, 0x32ac, "M", "M", &v17, &v16);
    v2 = (v19 - v17 >> 31) + v19 - v17 >> 1;
    v5 = 0xff;
    v6 = 0xff;
    v4 = 0xff;
    v3 = v31 + 3;
    v7 = sub_0;
    v8 = sub_0;
    v1 = 12972;
    sub_2abd(0x1e200, 86, &v1, "M", "M", "M", "M");
    v32 = v31 + v10;
    sub_2abd(0x1e200, 50, "M", v32, v19, v11, "M");
    v13 = v32;
    if (*((int *)(12 + v22 + 24)))
    {
        v8 = sub_2abd(0x1e200, 0x11, *((int *)(12 + v22 + 24)), 4, "M", "M", "M");
        if (!v8)
        {
            sub_2abd(0x1e200, 42, 0x32e8, "M", "M", &v17, &v16);
            v0 = 13032;
            sub_2abd(0x1e200, 86, &v0, "M", "M", "M", "M", v0, (v19 - v17 >> 31) + v19 - v17 >> 1, ((v11 - v16 >> 31) + v11 - v16 >> 1) + v13, 0xff, 0xff, 0xff, "M", "M");
            goto LABEL_1e3d;
        }
        else
        {
            idx = sub_0;
            v34 = v13 + 5;
            if (v8 <= sub_0)
                goto LABEL_1e3d;
            while (true)
            {
                index = *((int *)(*((int *)(12 + v22 + 24)) + idx * 4));
                v7 = index[1];
                v6 = *((int *)(index + _start));
                v18 = 10;
                v36 = sub_2abd(0x1e200, 45, sub_2abd(0x1e200, 45, 0x32f8, *(index), "M", "M", "M"), 0x329c, "M", "M", "M");
                sub_2abd(0x1e200, 311, v36, v18, v34, "M", "M");
                sub_2abd(0x1e200, 42, v36, "M", "M", &v17, &v16);
                v37 = v17 + 10;
                if (index[1] > sub_0)
                {
                    v14 = sub_2abd(0x1e200, 303, index[1], "M", "M", "M", "M");
                    v38 = sub_2abd(0x1e200, 60, 0x32fc, v14, v37, v34, "M");
                    sub_2abd(0x1e200, 9, v14, "M", "M", "M", "M");
                    v37 = v38 + v37 + 3;
                }
                if (*((int *)(index + _start)) > sub_0)
                {
                    v14 = sub_2abd(0x1e200, 303, *((int *)(index + _start)), "M", "M", "M", "M");
                    sub_2abd(0x1e200, 60, 0x3304, v14, v37, v34, "M");
                    sub_2abd(0x1e200, 9, v14, "M", "M", "M", "M");
                }
                idx += 1;
                v34 = v34 + v16 + 2;
                if (v8 <= idx)
                    break;
            }
        }
    }
    else
    {
LABEL_1e3d:
    }
    v39 = v13 + v11;
    sub_2abd(0x1e200, 46, "M", v39, v19, v10, "M");
    sub_2abd(0x1e200, 42, sub_330c, "M", "M", &v17, &v16);
    v2 = (v19 - v17 >> 31) + v19 - v17 >> 1;
    v3 = v39 + 3;
    v5 = 0xff;
    v6 = 0xff;
    v4 = 0xff;
    v7 = sub_0;
    v8 = sub_0;
    v1 = sub_330c;
    sub_2abd(0x1e200, 86, &v1, "M", "M", "M", "M");
    v40 = v39 + v10;
    sub_2abd(0x1e200, 29, "M", "M", "M", "M", "M");
    if (*((int *)(40 + v22)))
    {
        i = sub_0;
        v8 = sub_2abd(0x1e200, 0x11, *((int *)(40 + v22)), 4, "M", "M", "M");
        if (v8 > sub_0)
        {
            do
            {
                v42 = i * 4;
                idx1 = 12 + v22;
                v7 = *((int *)(*((int *)(idx1 + sub_1c)) + v42));
                v6 = *((int *)(*((int *)(idx1 + sub_20)) + v42));
                if (sub_2abd(0x1e200, 47, "M", v40, v19, 20, "M") == 1)
                {
                    v44 = 12 + v22;
                    if (i == v44->field_4)
                        sub_2abd(0x1e200, 35, 4, "M", v40, v19, 20);
                    else
                        v44->field_4 = i;
                }
                if (*((int *)(12 + v22 + 4)) == i)
                    sub_2abd(0x1e200, 48, "M", v40, v19, 20, "M");
                else
                    sub_2abd(0x1e200, 49, "M", v40, v19, 20, "M");
                sub_2abd(0x1e200, 60, *((int *)(*((int *)(idx1 + sub_1c)) + v42)), *((int *)(*((int *)(idx1 + sub_20)) + v42)), 20, v40 + 3, "M");
                v40 += 20;
                i += 1;
            } while (i < v8);
        }
    }
    sub_2abd(0x1e200, 42, 0x3330, "M", "M", &v17, &v16);
    v2 = 13104;
    v6 = (v19 - v17 + 5 >> 31) + v19 - v17 + 5 >> 1;
    v5 = 0xff;
    v3 = 0xff;
    v4 = 0xff;
    v7 = sub_2abd(0x1e200, 29, "M", "M", "M", "M", "M") - (v16 + _start);
    v8 = sub_0;
    sub_2abd(0x1e200, 155, &v2, "M", "M", "M", "M");
    sub_2abd(0x1e200, 35, 11, (v19 - v17 + 5 >> 31) + v19 - v17 + 5 >> 1, sub_2abd(0x1e200, 29, "M", "M", "M", "M", "M") - (v16 + _start), v17 + 5, v16 + _start);
    v4 = 13092;
    v5 = 0xff;
    v6 = 0xff;
    v7 = 0xff;
    v8 = 1;
    v9 = 1;
    sub_2abd(0x1e200, 65, &v4, "M", "M", "M", "M");
    v4 = 13084;
    v5 = 0xff;
    v6 = 0xff;
    v7 = 0xff;
    v8 = sub_0;
    v9 = 1;
    return sub_2abd(0x1e200, 65, &v4, "M", "M", "M", "M");
}


/* ===== sub_f95 @ 0xf95, size=1700, cc=65 ===== */
typedef struct struct_0 {
    char padding_0[48];
    int field_30;
} struct_0;

typedef struct struct_1 {
    char padding_0[36];
    unsigned int field_24;
} struct_1;

extern unsigned int g_1;
extern int g_124;
extern int g_12e;
extern int g_12f;
extern int g_137;
extern int g_14;
extern int g_2;
extern int g_23;
extern char g_24;
extern int g_25;
extern int g_2a;
extern int g_2d;
extern int g_2e;
extern int g_2f;
extern unsigned int g_3;
extern char g_30;
extern int g_32;
extern int g_327c;
extern int g_32fc;
extern int g_3304;
extern char g_3330;
extern char g_333c;
extern char g_34;
extern char g_343c;
extern int g_3448;
extern int g_344c;
extern int g_3450;
extern char g_346c;
extern int g_3478;
extern int g_3488;
extern char g_3498;
extern char g_38;
extern int g_3c;
extern int g_3f;
extern int g_4;
extern int g_41;
extern int g_5;
extern char g_54;
extern int g_56;
extern char g_58;
extern char g_6;
extern int g_64;
extern int g_69;
extern int g_9;
extern int g_a;
extern char g_c;
extern int g_c3;
extern int g_c7;
extern unsigned int g_c8;
extern int g_e1;
extern int g_ed;
extern char g_ff;

int sub_f95(void)
{
    int v23;  // r6
    int v24;  // r4
    unsigned int v33;  // r7
    struct_0 *v35;  // r1
    unsigned int iter;  // r4
    struct_1 *v40;  // r6
    int v41;  // r5
    int v42;  // r5
    int v25;  // r0
    unsigned int v43;  // r5
    int v44;  // r0
    unsigned int v45;  // r0
    int v46;  // r0
    unsigned int v26;  // r9
    unsigned int v27[9];  // r6
    int v28;  // r0
    int v29;  // r0
    unsigned int v30;  // r6
    unsigned int v32;  // r6
    unsigned int v0;  // [bp-0x70]
    int v1;  // [bp-0x6c]
    int v2;  // [bp-0x68]
    unsigned int v3;  // [bp-0x60]
    unsigned int v4;  // [bp-0x5c]
    unsigned int v5;  // [bp-0x58]
    int v6;  // [bp-0x54], Other Possible Types: unsigned int
    unsigned int v7;  // [bp-0x50], Other Possible Types: int
    int v8;  // [bp-0x4c], Other Possible Types: unsigned int
    int v9;  // [bp-0x48], Other Possible Types: unsigned int
    unsigned int v10;  // [bp-0x44]
    int v11;  // [bp-0x40], Other Possible Types: unsigned int
    unsigned int v12;  // [bp-0x3c], Other Possible Types: int
    unsigned int v13;  // [bp-0x38], Other Possible Types: int
    unsigned int v14;  // [bp-0x37]
    unsigned int v15;  // [bp-0x34]
    int v16;  // [bp-0x30]
    char v17;  // [bp-0x2c], Other Possible Types: unsigned int
    char v18;  // [bp-0x28], Other Possible Types: unsigned int
    int v19;  // [bp-0x24], Other Possible Types: unsigned int
    unsigned int v20;  // [bp-0x20]
    unsigned int v21;  // [bp-0x1c]
    char *v22;  // [bp-0x18]

    v23 = sub_2abd(0x1e200, sub_1c, "M", "M", "M", "M", "M");
    v24 = sub_0;
    v25 = sub_2abd(0x1e200, 225, 237, "M", "M", "M", "M");
    if (v25 <= sub_0)
        return v25;
    sub_2abd(0x1e200, 292, "M", "M", "M", "M", "M");
    sub_2a6d("M", "M", "M");
    sub_2abd(0x1e200, 42, 0x327c, "M", "M", &v18, &v17);
    v15 = v17 + 6;
    sub_2abd(0x1e200, 50, "M", "M", v23, v15, "M");
    v27 = 12 + v26;
    v28 = sub_2abd(0x1e200, 45, sub_2abd(0x1e200, 45, 0x3450, *((int *)(*((int *)(v27 + sub_1c)) + v27[1] * 4)), "M", "M", "M"), 0x344c, "M", "M", "M");
    v29 = sub_2abd(0x1e200, 45, sub_2abd(0x1e200, 45, v28, *((int *)(*((int *)(v27 + sub_20)) + v27[1] * 4)), "M", "M", "M"), 0x3448, "M", "M", "M");
    v0 = 3;
    v1 = sub_0;
    v2 = sub_0;
    sub_2abd(0x1e200, 311, v29, 10);
    v6 = 13372;
    v8 = v15 + 3;
    v7 = 10;
    v9 = 0xff;
    v10 = 0xff;
    v11 = 0xff;
    v12 = sub_0;
    v13 = sub_0;
    sub_2abd(0x1e200, 86, &v6, "M", "M", "M", "M");
    v30 = v15 * 2;
    v19 = 5;
    v16 = sub_2abd(0x1e200, 63, sub_2abd(0x1e200, 225, 105, "M", "M", "M", "M"), "M", "M", "M", "M");
    v19 = sub_2abd(0x1e200, 60, 0x32fc, v16, v19, v30, "M") + 5;
    sub_2abd(0x1e200, 9, v16, "M", "M", "M", "M");
    v19 += 10;
    sub_2abd(0x1e200, 60, 0x3304, sub_2abd(0x1e200, 63, sub_2abd(0x1e200, 225, sub_1c, "M", "M", "M", "M"), "M", "M", "M", "M"), v19, v30, "M");
    v32 = v30 + v15 + 10;
    v19 = 5;
    v22 = &v11;
    while (true)
    {
        v13 = v19;
        v33 = (v24 ? 13420 : sub_3460);
        v21 = v32 - 4;
        v20 = v21;
        sub_2abd(0x1e200, 46, "M", v21, sub_2abd(0x1e200, sub_1c, "M", "M", "M", "M", "M"), 35, "M");
        if (sub_2abd(0x1e200, 47, "M", v20, sub_2abd(0x1e200, sub_1c, "M", "M", "M", "M", "M"), 35, "M") == 1)
        {
            v35 = 12 + v26;
            if (v35->field_30 == v24)
                sub_2abd(0x1e200, 35, 4, "M", v21, sub_2abd(0x1e200, sub_1c, "M", "M", "M", "M", "M"), 35);
            else
                v35->field_30 = v24;
        }
        if (v24 == *((int *)(12 + v26 + 48)))
            sub_2abd(0x1e200, 199, "M", v21, sub_2abd(0x1e200, sub_1c, "M", "M", "M", "M", "M"), 35, "M");
        v5 = v33;
        v6 = v13;
        v8 = 0xff;
        v9 = 0xff;
        v7 = v32;
        v10 = 0xff;
        v11 = sub_0;
        v12 = sub_0;
        sub_2abd(0x1e200, 86, &v5, "M", "M", "M", "M");
        sub_2abd(0x1e200, 42, v33, "M", "M", &v18, &v17);
        v13 = v13 + v18 + 5;
        sub_2abd(0x1e200, 195, v13, v32, 100, 20, "M");
        v4 = v13 + 5;
        v5 = v32 + 3;
        v10 = 200;
        v6 = sub_0;
        v7 = sub_0;
        v8 = sub_0;
        v9 = sub_0;
        v3 = (v24 ? sub_2abd(0x1e200, 63, sub_2abd(0x1e200, 225, 303, "M", "M", "M", "M"), "M", "M", "M", "M") : sub_2abd(0x1e200, 63, sub_2abd(0x1e200, 225, 302, "M", "M", "M", "M"), "M", "M", "M", "M"));
        v11 = sub_0;
        v12 = 1;
        sub_2abd(0x1e200, 37, &v3, "M", "M", "M", "M");
        sub_2abd(0x1e200, 9, v3, "M", "M", "M", "M");
        v32 += 35;
        v24 += 1;
        if (v24 >= 2)
            break;
    }
    iter = v32 + 10;
    v40 = 12 + v26;
    if (*((int *)&v40[2].padding_0[4]) > sub_0)
    {
        v41 = sub_2abd(0x1e200, 63, *((int *)&v40[2].padding_0[4]), "M", "M", "M", "M");
        sub_2abd(0x1e200, 60, 0x3478, v41, v19, iter, "M");
        sub_2abd(0x1e200, 9, v41, "M", "M", "M", "M");
        iter += v15;
    }
    if (*((int *)&v40[2].padding_0[8]) > sub_0)
    {
        v42 = sub_2abd(0x1e200, 63, *((int *)&v40[2].padding_0[8]), "M", "M", "M", "M");
        sub_2abd(0x1e200, 60, 0x3488, v42, v19, iter, "M");
        sub_2abd(0x1e200, 9, v42, "M", "M", "M", "M");
        iter += v15;
    }
    v6 = v40->field_24;
    v7 = 5;
    v9 = 0xff;
    v8 = iter;
    v10 = 0xff;
    v11 = 0xff;
    v12 = sub_0;
    v13 = sub_0;
    sub_2abd(0x1e200, 86, &v6, "M", "M", "M", "M");
    if (sub_0 < *((int *)(12 + v26 + 52)) || *((int *)&v40[1].padding_0[16]))
    {
        v7 = 5;
        v9 = 0xff;
        v8 = iter + v15;
        v10 = 0xff;
        v11 = 0xff;
        v6 = 13464;
        v12 = sub_0;
        v13 = sub_0;
        sub_2abd(0x1e200, 86, &v6, "M", "M", "M", "M");
        sub_2abd(0x1e200, 42, 0x3498, "M", "M", &v18, &v17);
        v43 = v18 + 5;
        if (*((int *)(12 + v26 + 52)) > sub_0)
        {
            v44 = sub_2abd(0x1e200, 63, *((int *)(12 + v26 + 52)), "M", "M", "M", "M");
            v45 = sub_2abd(0x1e200, 60, 0x32fc, v44, v43, v8, "M");
            sub_2abd(0x1e200, 9, v44, "M", "M", "M", "M");
            v43 = v45 + v43 + 5;
        }
        if (*((int *)(12 + v26 + 56)) <= sub_0)
            goto LABEL_15ed;
        v46 = sub_2abd(0x1e200, 63, *((int *)(12 + v26 + 56)), "M", "M", "M", "M");
        sub_2abd(0x1e200, 60, 0x3304, v46, v43, v8, "M");
        sub_2abd(0x1e200, 9, v46, "M", "M", "M", "M");
    }
    else
    {
LABEL_15ed:
    }
    v9 = 13104;
    v10 = 0xff;
    v11 = 0xff;
    v12 = 0xff;
    v13 = 1;
    v14 = 1;
    sub_2abd(0x1e200, 65, &v9, "M", "M", "M", "M");
    v9 = 13116;
    v10 = 0xff;
    v11 = 0xff;
    v12 = 0xff;
    v13 = sub_0;
    v14 = 1;
    return sub_2abd(0x1e200, 65, &v9, "M", "M", "M", "M");
}


/* ===== sub_4b9 @ 0x4b9, size=1030, cc=50 ===== */
typedef struct struct_0 {
    char padding_0[92];
    int field_5c;
} struct_0;

extern int g_12;
extern int g_12e;
extern int g_12f;
extern int g_14;
extern int g_2d;
extern int g_33;
extern int g_3394;
extern int g_33a8;
extern int g_33b8;
extern int g_33c8;
extern int g_33e4;
extern int g_34;
extern int g_3400;
extern int g_3414;
extern int g_3428;
extern int g_3f;
extern char g_4;
extern int g_51;
extern char g_54;
extern char g_58;
extern char g_5c;
extern char g_60;
extern int g_69;
extern int g_9;
extern int g_9c;
extern char g_c;
extern int g_e1;

int sub_4b9(void)
{
    unsigned int v6;  // r4
    unsigned int v7;  // r5
    int v16;  // r0
    int v17;  // r0
    int v18;  // r0
    int v19;  // r0
    int v20;  // r0
    int v21;  // r0
    int v22;  // r0
    int v23;  // r0
    int v24;  // r0
    int v25;  // r0
    unsigned int v8;  // r6
    unsigned int v9;  // r7
    unsigned int v10;  // lr
    unsigned int v11;  // r9
    struct_0 *v12;  // r4
    int v13;  // r0
    int v14;  // r0
    int v15;  // r0
    int v0;  // [bp-0x18]
    unsigned int v1;  // [bp-0x14]
    unsigned int v2;  // [bp-0x10]
    unsigned int v3;  // [bp-0xc]
    unsigned int v4;  // [bp-0x8]
    unsigned int v5;  // [bp-0x4]

    v1 = v6;
    v2 = v7;
    v3 = v8;
    v4 = v9;
    v5 = v10;
    if (sub_0 >= sub_2abd(0x1e200, 225, 302, "M", "M", "M", "M") && sub_0 >= sub_2abd(0x1e200, 225, 303, "M", "M", "M", "M"))
        sub_2abd(0x1e200, 0x33, 0x3394, "M", "M", "M", "M");
    v12 = 12 + v11;
    if (*((int *)&v12->padding_0[84]) > sub_0 && sub_2abd(0x1e200, 225, 302, "M", "M", "M", "M") > sub_0)
    {
        v13 = sub_2abd(0x1e200, 225, 302, "M", "M", "M", "M");
        if (*((int *)&v12->padding_0[84]) > v13)
        {
            v14 = sub_2abd(0x1e200, 63, *((int *)&v12->padding_0[84]), "M", "M", "M", "M");
            v15 = sub_2abd(0x1e200, 45, 0x33a8, v14, "M", "M", "M");
            sub_2abd(0x1e200, 9, v14, "M", "M", "M", "M");
            sub_2abd(0x1e200, 0x33, v15, "M", "M", "M", "M");
        }
    }
    if (*((int *)&v12->padding_0[88]) > sub_0 && sub_2abd(0x1e200, 225, 303, "M", "M", "M", "M") > sub_0)
    {
        v16 = sub_2abd(0x1e200, 225, 303, "M", "M", "M", "M");
        if (*((int *)&v12->padding_0[88]) > v16)
        {
            v17 = sub_2abd(0x1e200, 63, *((int *)&v12->padding_0[88]), "M", "M", "M", "M");
            v18 = sub_2abd(0x1e200, 45, 0x33b8, v17, "M", "M", "M");
            sub_2abd(0x1e200, 9, v17, "M", "M", "M", "M");
            sub_2abd(0x1e200, 0x33, v18, "M", "M", "M", "M");
        }
    }
    v0 = sub_2abd(0x1e200, 225, 302, "M", "M", "M", "M");
    if (v0 > sub_2abd(0x1e200, 225, 105, "M", "M", "M", "M"))
    {
        sub_2abd(0x1e200, 0x33, 0x33c8, "M", "M", "M", "M");
    }
    else
    {
        v19 = sub_2abd(0x1e200, 225, 303, "M", "M", "M", "M");
        if (v19 > sub_2abd(0x1e200, 225, sub_1c, "M", "M", "M", "M"))
        {
            sub_2abd(0x1e200, 0x33, 0x33e4, "M", "M", "M", "M");
        }
        else
        {
            v20 = sub_2abd(0x1e200, 225, 302, "M", "M", "M", "M");
            if (v20 > v12->field_5c)
            {
                v21 = sub_2abd(0x1e200, 63, v12->field_5c, "M", "M", "M", "M");
                v22 = sub_2abd(0x1e200, 45, 0x3400, v21, "M", "M", "M");
                sub_2abd(0x1e200, 9, v21, "M", "M", "M", "M");
                sub_2abd(0x1e200, 0x33, v22, "M", "M", "M", "M");
            }
            else
            {
                v23 = sub_2abd(0x1e200, 225, 303, "M", "M", "M", "M");
                if (v23 > *((int *)&v12[1].padding_0[0]))
                {
                    v24 = sub_2abd(0x1e200, 63, *((int *)&v12[1].padding_0[0]), "M", "M", "M", "M");
                    v25 = sub_2abd(0x1e200, 45, 0x3414, v24, "M", "M", "M");
                    sub_2abd(0x1e200, 9, v24, "M", "M", "M", "M");
                    sub_2abd(0x1e200, 0x33, v25, "M", "M", "M", "M");
                }
                else if (!sub_2abd(0x1e200, 225, sub_20, "M", "M", "M", "M"))
                {
                    sub_2abd(0x1e200, 81, 0x3428, "M", "M", "M", "M");
                }
                else
                {
                    sub_2abd(0x1e200, 20, sub_20, "M", "M", "M", "M");
                    sub_2abd(0x1e200, 156, 18, "M", "M", "M", "M");
                    sub_2abd(0x1e200, 52, "M", "M", "M", "M", "M");
                    *((void* *)(4 + v11)) = sub_0;
                    sub_2abd(0x1e200, 225, 303, "M", "M", "M", "M");
                    sub_2abd(0x1e200, 225, 302, "M", "M", "M", "M");
                }
            }
        }
    }
}


/* ===== sub_aed @ 0xaed, size=804, cc=33 ===== */
typedef struct struct_0 {
    char padding_0[8];
    int field_8;
} struct_0;

extern unsigned int g_1;
extern char g_10;
extern char g_14;
extern char g_18;
extern int g_1ac;
extern char g_24;
extern int g_2c;
extern int g_4;
extern int g_44;
extern int g_45;
extern int g_46;
extern int g_47;
extern char g_50;
extern char g_54;
extern char g_58;
extern char g_5c;
extern char g_60;
extern int g_a;
extern int g_c;
extern int g_f;
extern char g_ff;

int sub_aed(struct_0 *a0, int a1)
{
    unsigned int i;  // r6
    unsigned int v3;  // r9
    unsigned int v12;  // r5
    unsigned int idx[9];  // r7
    unsigned int j;  // r6
    unsigned int v15;  // r0
    unsigned int v16;  // r7
    unsigned int v17;  // r0
    unsigned int idx1[25];  // r5
    int v4;  // r1
    unsigned int index[21];  // r5
    unsigned int idx2[7];  // r5
    unsigned int v7;  // r7
    unsigned int v8;  // r6
    unsigned int v9[3];  // r5
    unsigned int v10;  // r0
    unsigned int v11;  // r6
    unsigned int v0;  // [bp-0x20]
    struct_0 *v1;  // [bp-0x1c]

    v1 = a0;
    i = sub_0;
    sub_2abd(0x1e200, 0x44, a0, "M", "M", "M", "M");
    if (a1 == 428)
    {
        if (*((char *)(4 + v3)))
            sub_2abd(0x1e200, 44, "M", "M", "M", "M", "M");
        v4 = 4 + v3;
        *((char *)v4) = 1;
        sub_2f35(1, v4);
    }
    index = 12 + v3;
    *((unsigned int *)(index + _start)) = sub_2abd(0x1e200, 71, *((int *)(a0 + _start)), "M", "M", "M", "M");
    index[20] = sub_2abd(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M");
    if ((char)sub_2abd(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") == 1)
    {
        *((unsigned int *)(4 + v3 + 4)) = sub_2abd(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
        index[3] = sub_2abd(0x1e200, 71, *((int *)(a0 + _start)), "M", "M", "M", "M");
    }
    else
    {
        *((void* *)(4 + v3 + 4)) = ~(sub_0);
    }
    idx2 = 12 + v3;
    idx2[4] = sub_2abd(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
    idx2[5] = sub_2abd(0x1e200, 71, *((int *)(a0 + _start)), "M", "M", "M", "M");
    v7 = sub_2abd(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") & 0xff;
    idx2[6] = sub_2abd(0x1e200, 10, v7, 4, "M", "M", "M");
    if (v7 > sub_0)
    {
        do
        {
            v8 = i;
            v9 = sub_2abd(0x1e200, 15, 12, "M", "M", "M", "M");
            v0 = sub_2abd(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
            sub_2abd(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
            v10 = sub_2abd(0x1e200, 71, *((int *)(a0 + _start)), "M", "M", "M", "M", sub_2abd(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M"));
            v9[1] = v0;
            v9[0] = v10;
            *((unsigned int *)(v9 + _start)) = sub_2abd(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
            v11 = v8 + 1;
            *((unsigned int *[3])(*((int *)(12 + v3 + 24)) + v8 * 4)) = v9;
            i = v11;
        } while (i < v7);
    }
    v12 = sub_2abd(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") & 0xff;
    idx = 12 + v3;
    *((unsigned int *)(idx + sub_1c)) = sub_2abd(0x1e200, 10, v12, 4, "M", "M", "M");
    j = sub_0;
    *((unsigned int *)(idx + sub_20)) = sub_2abd(0x1e200, 10, v12, 4, "M", "M", "M");
    if (v12 > sub_0)
    {
        do
        {
            v15 = sub_2abd(0x1e200, 71, *((int *)(a0 + _start)), "M", "M", "M", "M");
            v16 = j * 4;
            *((unsigned int *)(*((int *)(40 + v3)) + v16)) = v15;
            v17 = sub_2abd(0x1e200, 71, *((int *)(a0 + _start)), "M", "M", "M", "M");
            j += 1;
            *((unsigned int *)(*((int *)(44 + v3)) + v16)) = v17;
        } while (j < v12);
    }
    idx1 = 12 + v3;
    idx1[9] = sub_2abd(0x1e200, 71, *((int *)(a0 + _start)), "M", "M", "M", "M");
    idx1[21] = sub_2abd(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
    idx1[22] = sub_2abd(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
    idx1[23] = sub_2abd(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
    idx1[24] = sub_2abd(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
    if (a1 == 428)
        return a1 - 428;
    return sub_2591(a1 - 428);
}


/* ===== sub_1685 @ 0x1685, size=728, cc=31 ===== */
typedef struct struct_0 {
    char padding_0[72];
    unsigned int field_48;
} struct_0;

extern int g_1;
extern int g_11;
extern int g_124;
extern int g_137;
extern int g_19;
extern int g_1d;
extern char g_1f;
extern int g_2;
extern int g_24;
extern int g_2a;
extern int g_2f;
extern int g_3;
extern int g_30;
extern int g_32;
extern int g_327c;
extern char g_34a4;
extern char g_34b4;
extern char g_34c4;
extern char g_34d4;
extern int g_3b;
extern char g_3c;
extern int g_4;
extern char g_40;
extern char g_44;
extern char g_48;
extern char g_4c;
extern int g_56;
extern char g_a;
extern int g_b3;
extern char g_c;
extern int g_e1;
extern int g_ed;
extern int g_ff;

int sub_1685(void)
{
    int v9;  // r7
    unsigned int v10;  // r5
    int v19;  // r2
    unsigned int v20;  // r1
    unsigned int v21;  // r0
    unsigned int v22;  // r0
    unsigned int v23;  // r0
    int v24;  // r6
    unsigned int idx;  // r7
    struct_0 *v26;  // r1
    unsigned int v11;  // r0
    unsigned int v12;  // r4
    unsigned int v13;  // r9
    unsigned int v14;  // r0
    unsigned int v15;  // r5
    unsigned int v16;  // r6
    int v17;  // r0
    unsigned int v18;  // r0
    unsigned int v0;  // [bp-0x44]
    unsigned int v1;  // [bp-0x34]
    unsigned int v2;  // [bp-0x30]
    unsigned int v3;  // [bp-0x2c]
    int v4;  // [bp-0x28]
    int v5;  // [bp-0x24]
    char v6;  // [bp-0x20], Other Possible Types: unsigned int
    char v7;  // [bp-0x1c], Other Possible Types: unsigned int
    unsigned int v8;  // [bp-0x18]

    v9 = sub_2abd(0x1e200, sub_1c, "M", "M", "M", "M", "M");
    v5 = 25;
    v10 = sub_0;
    v11 = sub_2abd(0x1e200, 225, 237, "M", "M", "M", "M");
    if (v11 <= sub_0)
        return v11;
    sub_2abd(0x1e200, 292, "M", "M", "M", "M", "M");
    sub_2a6d("M", "M", "M");
    sub_2abd(0x1e200, 42, 0x327c, "M", "M", &v7, &v6);
    v12 = v6 + 10;
    sub_2abd(0x1e200, 50, "M", "M", v9, v12, "M");
    v14 = *((int *)(12 + v13 + 76));
    switch (v14)
    {
    case 430:
        v10 = 13476;
        break;
    case 432:
        v10 = 13492;
        break;
    case 433:
        v10 = 13508;
        break;
    default:
        goto LABEL_1743;
    }
LABEL_1743:
    sub_2abd(0x1e200, 42, v10, "M", "M", &v7, &v6);
    v0 = v10;
    sub_2abd(0x1e200, 86, &v0, "M", "M", "M", "M", v0, (v9 - v7 >> 31) + v9 - v7 >> 1, 3, 0xff, 0xff, 0xff, "M", "M");
    v15 = sub_2abd(0x1e200, 29, "M", "M", "M", "M", "M") - v12 - 25;
    if (*((int *)(12 + v13 + 0x44)) && !((v16 = sub_2abd(0x1e200, 0x11, *((int *)(12 + v13 + 0x44)), 4, "M", "M", "M"), v16 <= sub_0)))
    {
        v8 = v15 - 25;
        v17 = sub_20(25, v8);
        v4 = v17;
        v18 = sub_20(v17, *((int *)(12 + v13 + 72)));
        v19 = v17;
        v3 = v18 * v19;
        v20 = v18 * v19 + v19;
        v21 = v16;
        if (v21 > v20)
            v21 = v20;
        v22 = v21;
        v2 = v22;
        v23 = sub_2abd(0x1e200, 29, "M", "M", "M", "M", "M");
        sub_2abd(0x1e200, 179, "M", v23 - v12 - 25, v5, *((int *)(12 + v13 + 64)), *((int *)(12 + v13 + 60)));
        v24 = v9 - 12;
        sub_2abd(0x1e200, 59, v24, v12, v8, v16, *((int *)(12 + v13 + 72)));
        idx = v18 * v19;
        if (v22 > idx)
        {
            do
            {
                v1 = *((int *)(*((int *)(12 + v13 + 0x44)) + idx * 4));
                if (sub_2abd(0x1e200, 47, "M", v12, v24, 25, "M") == 1)
                {
                    v26 = 12 + v13;
                    if (idx != v26->field_48)
                        v26->field_48 = idx;
                }
                if (*((int *)(12 + v13 + 72)) == idx)
                    sub_2abd(0x1e200, 48, "M", v12, v24, 25, "M");
                sub_2abd(0x1e200, 311, *((int *)(*((int *)(12 + v13 + 0x44)) + idx * 4)), 2, v12 + 3, "M", "M");
                v12 += 25;
                idx += 1;
            } while (idx < v22);
        }
    }
    else
    {
        sub_2abd(0x1e200, 42, 0x34d4, "M", "M", &v7, &v6);
        v0 = 13524;
        sub_2abd(0x1e200, 86, &v0, "M", "M", "M", "M", v0, (v9 - v7 >> 31) + v9 - v7 >> 1, ((v15 - v6 >> 31) + v15 - v6 >> 1) + v12, 0xff, 0xff, 0xff, "M", "M");
    }
    return sub_2abd(0x1e200, 36, 1, 1, "M", "M", "M");
}


/* ===== sub_2371 @ 0x2371, size=534, cc=22 ===== */
typedef struct struct_0 {
    char padding_0[40];
    unsigned int field_28;
} struct_0;

extern char g_1;
extern int g_13;
extern int g_14;
extern int g_147;
extern int g_17;
extern int g_26;
extern int g_27;
extern int g_28;
extern char g_2c;
extern int g_32e4;
extern int g_333c;
extern int g_3344;
extern int g_3350;
extern int g_335c;
extern int g_337c;
extern int g_34;
extern int g_35;
extern int g_36;
extern int g_4;
extern int g_9;
extern int g_a;
extern char g_c;

int sub_2371(void)
{
    int v0;  // r4
    struct_0 *idx;  // r7
    int index;  // r5
    unsigned int v12;  // r0
    int v13;  // r5
    int v7;  // r6
    int i;  // r5
    unsigned int v9;  // r9

    v0 = sub_2abd(0x1e200, 19, "M", "M", "M", "M", "M");
    sub_2abd(0x1e200, 52, "M", "M", "M", "M", "M");
    sub_2abd(0x1e200, 54, v0, sub_2abd(0x1e200, 53, 0x337c, 0x32e4, "M", "M", "M"), "M", "M", "M");
    sub_2abd(0x1e200, 54, v0, sub_2abd(0x1e200, 53, sub_336c, 0x32e4, "M", "M", "M"), "M", "M", "M");
    sub_2abd(0x1e200, 54, v0, sub_2abd(0x1e200, 53, 0x335c, 0x32e4, "M", "M", "M"), "M", "M", "M");
    sub_2abd(0x1e200, 54, v0, sub_2abd(0x1e200, 53, 0x3350, 0x32e4, "M", "M", "M"), "M", "M", "M");
    sub_2abd(0x1e200, 54, v0, sub_2abd(0x1e200, 53, 0x3344, 0x32e4, "M", "M", "M"), "M", "M", "M");
    sub_2abd(0x1e200, 54, v0, sub_2abd(0x1e200, 53, 0x333c, 0x32e4, "M", "M", "M"), "M", "M", "M");
    v7 = sub_2abd(0x1e200, 38, v0, "M", "M", "M", "M");
    i = sub_0;
    idx = 12 + v9;
    idx->field_28 = sub_2abd(0x1e200, 10, v7, 4, "M", "M", "M");
    if (v7 > sub_0)
    {
        do
        {
            index = i;
            v12 = sub_2abd(0x1e200, 39, v0, index, "M", "M", "M");
            v13 = index + 1;
            *((unsigned int *)(idx->field_28 + index * 4)) = v12;
            i = v13;
        } while (i < v7);
    }
    sub_2abd(0x1e200, 40, v0, "M", "M", "M", "M");
    sub_2abd(0x1e200, 9, v0, "M", "M", "M", "M");
    *((void* *)&idx[1].padding_0[0]) = sub_0;
    return sub_2abd(0x1e200, 20, 23, 327, "M", "M", "M");
}


/* ===== sub_8f9 @ 0x8f9, size=470, cc=28 ===== */
typedef struct struct_0 {
    unsigned int field_0;
} struct_0;

extern char g_100;
extern int g_12;
extern int g_1ab;
extern int g_1ac;
extern int g_1ae;
extern int g_1b0;
extern int g_1b1;
extern char g_333c;
extern char g_3344;
extern char g_3350;
extern char g_335c;
extern int g_34;
extern int g_50;
extern int g_9c;

int sub_8f9(unsigned int a0)
{
    unsigned int v0;  // r9
    int v1;  // r1
    int v10;  // r3
    struct_0 **v11;  // r7
    int v2;  // r2
    int v3;  // r3
    int v4;  // r1
    int v5;  // r2
    int v6;  // r3
    int v7;  // r0
    int v8;  // r1
    int v9;  // r2

    if (!(*((int *)(0x100 + v0)))())
    {
        sub_2abd(0x1e200, 156, 18, "M", "M", "M", "M");
        sub_2abd(0x1e200, 52, "M", "M", "M", "M", "M");
        return sub_2abd(0x1e200, 80, 428, "M", "M", "M", "M");
    }
    else if (!(*((int *)(0x100 + v0)))(a0, sub_336c, *((int *)(0x100 + v0))))
    {
        sub_2abd(0x1e200, 156, 18, "M", "M", "M", "M");
        return sub_31ad(433, ~(sub_0), sub_2249(sub_2abd(0x1e200, 52, "M", "M", "M", "M", "M"), v1, v2, v3, "M", "M", "M"));
    }
    else
    {
        if (!(*((int *)(0x100 + v0)))(a0, 0x335c, *((int *)(0x100 + v0))))
        {
            sub_2abd(0x1e200, 156, 18, "M", "M", "M", "M");
            v7 = sub_31ad(430, ~(sub_0), sub_2249(sub_2abd(0x1e200, 52, "M", "M", "M", "M", "M"), v4, v5, v6, "M", "M", "M"));
        }
        else if (!(*((int *)(0x100 + v0)))(a0, 0x3350, *((int *)(0x100 + v0))))
        {
            sub_2abd(0x1e200, 156, 18, "M", "M", "M", "M");
            return sub_31ad(432, ~(sub_0), sub_2249(sub_2abd(0x1e200, 52, "M", "M", "M", "M", "M"), v8, v9, v10, "M", "M", "M"));
        }
        else
        {
            v11 = 0x100 + v0;
            if (!(*(v11))(a0, 0x3344, *(v11)))
            {
                sub_2abd(0x1e200, 156, 18, "M", "M", "M", "M");
                sub_2abd(0x1e200, 52, "M", "M", "M", "M", "M");
                return sub_2abd(0x1e200, 80, 427, "M", "M", "M", "M");
            }
            v7 = (*(v11))(a0, 0x333c, *(v11));
            if (!v7)
                return sub_2abd(0x1e200, 156, 18, "M", "M", "M", "M");
        }
        return v7;
    }
}


/* ===== sub_2f35 @ 0x2f35, size=342, cc=20 ===== */
typedef struct struct_0 {
    char padding_0[12];
    int field_c;
} struct_0;

typedef struct struct_1 {
    char padding_0[24];
    int field_18;
} struct_1;

extern char g_1;
extern int g_11;
extern int g_12;
extern char g_14;
extern char g_18;
extern char g_24;
extern int g_4;
extern int g_9;
extern char g_c;

unsigned int sub_2f35(void)
{
    unsigned int v0;  // r9
    struct_0 *idx;  // r4
    unsigned int v2;  // r0
    unsigned int v3;  // r4
    int v4;  // r0
    int v5;  // r4
    struct_1 *v6;  // r5
    unsigned int v7;  // r4

    idx = 12 + v0;
    if (idx->field_c)
        v2 = sub_2abd(0x1e200, 9, idx->field_c, "M", "M", "M", "M");
    idx->field_c = sub_0;
    if (*((int *)(idx + _start)))
        v2 = sub_2abd(0x1e200, 9, *((int *)(idx + _start)), "M", "M", "M", "M");
    *((void* *)(idx + _start)) = sub_0;
    if (*((int *)&idx[1].padding_0[4]))
        v2 = sub_2abd(0x1e200, 9, *((int *)&idx[1].padding_0[4]), "M", "M", "M", "M");
    *((void* *)&idx[1].padding_0[4]) = sub_0;
    if (*((int *)(idx + sub_1c)))
        v2 = sub_2abd(0x1e200, 18, *((int *)(idx + sub_1c)), "M", "M", "M", "M");
    *((void* *)(idx + sub_1c)) = sub_0;
    if (*((int *)(idx + sub_20)))
        v2 = sub_2abd(0x1e200, 18, *((int *)(idx + sub_20)), "M", "M", "M", "M");
    v3 = 12 + v0;
    *((void* *)(32 + v3)) = sub_0;
    if (*((int *)(v3 + 24)))
    {
        v4 = sub_2abd(0x1e200, 0x11, *((int *)(v3 + 24)), 4, "M", "M", "M");
        v5 = sub_0;
        if (v4 > sub_0)
        {
            do
            {
                if (*((int *)*((int *)(*((int *)(12 + v0 + 24)) + v5 * 4))))
                    sub_2abd(0x1e200, 9, *((int *)*((int *)(*((int *)(12 + v0 + 24)) + v5 * 4))), "M", "M", "M", "M");
            } while ((sub_2abd(0x1e200, 9, *((int *)(*((int *)(12 + v0 + 24)) + v5 * 4)), "M", "M", "M", "M"), v5 += 1, v5 < v4));
        }
        v6 = 12 + v0;
        v2 = sub_2abd(0x1e200, 9, v6->field_18, "M", "M", "M", "M");
        v6->field_18 = sub_0;
    }
    v7 = 12 + v0;
    if (*((int *)(v7 + 36)))
        v2 = sub_2abd(0x1e200, 9, *((int *)(v7 + 36)), "M", "M", "M", "M");
    *((void* *)(v7 + 36)) = sub_0;
    return v2;
}


/* ===== sub_28bd @ 0x28bd, size=290, cc=21 ===== */
typedef struct struct_0 {
    int field_0;
    unsigned int field_4;
    char padding_8[20];
    int field_1c;
} struct_0;

extern int g_1;
extern int g_11;
extern int g_14;
extern int g_1af;
extern int g_2c;
extern int g_34;
extern int g_4;
extern int g_50;
extern int g_9c;
extern int g_be;
extern int g_bf;
extern int g_c;

int sub_28bd(int a0)
{
    unsigned int v0;  // r9
    struct_0 *idx;  // r4
    int v2;  // r0
    int v3;  // r1
    unsigned int v4;  // r0

    idx = 12 + v0;
    v2 = sub_2abd(0x1e200, 0x11, *((int *)(idx + sub_1c)), 4, "M", "M", "M");
    switch (a0)
    {
    case 2: case 12:
        v4 = idx->field_4;
        idx->field_4 = v4 - 1;
        if (v4 >= 1)
            return v4 - 1;
        idx->field_4 = sub_0;
        return v4 - 1;
    case 1:
        sub_2abd(0x1e200, 156, 0x11, "M", "M", "M", "M");
        return sub_2abd(0x1e200, 156, 20, "M", "M", "M", "M");
    case 17:
        return sub_2371();
    case 18:
        sub_2f35();
        if (idx->field_0)
        {
            sub_2abd(0x1e200, 190, idx->field_0, "M", "M", "M", "M");
            return sub_2abd(0x1e200, 191, "M", "M", "M", "M", "M");
        }
        return sub_2abd(0x1e200, 44, "M", "M", "M", "M", "M");
    case 5: case 20:
        sub_2abd(0x1e200, 52, "M", "M", "M", "M", "M");
        return sub_2abd(0x1e200, 80, 431, idx->field_4, "M", "M", "M");
    case 13:
        v3 = idx->field_4 + 1;
        idx->field_4 = v3;
        if (v3 < v2)
            return v2 - 1;
        idx->field_4 = v2 - 1;
        return v2 - 1;
    default:
        return v2;
    }
}


/* ===== sub_2cf1 @ 0x2cf1, size=276, cc=24 ===== */
typedef struct struct_0 {
    unsigned int field_0;
    struct struct_0 *field_4;
    unsigned int field_8;
    struct struct_0 *field_c;
    unsigned int field_10;
    unsigned int field_14;
    struct struct_0 *field_18;
} struct_0;

typedef struct struct_2 {
    char padding_0[8];
    struct struct_0 *field_8;
} struct_2;

extern char g_10;
extern char g_134;
extern char g_14;
extern char g_18;
extern char g_3;
extern char g_3e8;
extern char g_3e9;
extern char g_4;
extern char g_5;
extern struct_0 g_a;
extern char g_c;

struct_0 * sub_2cf1(struct_0 *idx, struct_0 *a1, unsigned int a2, struct_0 *a3)
{
    unsigned int v2;  // r5
    unsigned int v3;  // r9
    struct_0 *iter;  // r0
    struct_2 *index;  // r7
    unsigned int v5;  // r0
    struct_0 *v6;  // r5
    struct_0 *v7;  // r0
    struct_0 *idx1;  // r1
    struct_0 *v9;  // r0
    struct_0 *idx2;  // r1
    struct_0 *v0;  // [bp-0x18]
    unsigned int v1;  // [bp+0x0]

    v0 = a3;
    v2 = ~(sub_0);
    if (!idx)
    {
        (*((int *)0x475052b5))("timer err:%d", 1000, *((int *)0x475052b5));
        return v2;
    }
    if (*((int *)*((int *)(8 + *((int *)0x475052a9)))) == 3 || *((int *)*((int *)(8 + *((int *)0x475052a9)))) == 4)
        return v2;
    if (idx->field_0 != 2041298127)
    {
        (*((int *)0x475052b5))("timer err:%d", 1001, *((int *)0x475052b5));
        return v2;
    }
    if (a1)
        idx->field_4 = a1;
    idx->field_10 = a2;
    *((void* *)(idx + _start)) = sub_0;
    if (a3)
        idx->field_c = a3;
    idx->field_14 = v1;
    if (sub_0 >= idx->field_4)
        return v2;
    if (10 > idx->field_4)
        idx->field_4 = 10;
    *((struct struct_0 **)(idx + _start)) = idx->field_4;
    index = 308 + v3;
    if (*((int *)&index[1].padding_0[4]))
    {
        v5 = (*((int *)0x475052d1))(*((int *)0x475052d1));
        v6 = *((int *)&index[1].padding_0[4]) - v5;
    }
    else
    {
        v6 = sub_0;
    }
    v7 = *((int *)(index + _start));
    if (v7 && sub_0 > v6)
        v6 = sub_0;
    if (v7 && v6 > (char *)&v7->field_4->field_4 + 1)
        v6 = v7->field_4;
    sub_2c91(idx);
    idx1 = *((int *)(index + _start));
    if (idx1 && *((int *)(idx + _start)) >= v6)
    {
        *((struct_0 **)(idx + _start)) = *((int *)(idx + _start)) - (char *)v6;
    }
    else
    {
        v9 = *((int *)(idx + _start));
        *((void* *)(idx + _start)) = sub_0;
        if (idx1)
        {
            do
            {
                *((unsigned long *)(idx1 + _start)) = *((int *)(idx1 + _start)) + v6 - v9;
                idx1 = idx1->field_18;
            } while (idx1->field_18);
        }
        sub_2e1d(v9);
    }
    idx2 = *((int *)(index + _start));
    if (!idx2)
    {
        *((struct_0 **)(index + _start)) = idx;
        idx->field_18 = sub_0;
    }
    else if (*((int *)(idx2 + _start)) > *((int *)(idx + _start)))
    {
        idx->field_18 = idx2;
        *((struct_0 **)(index + _start)) = idx;
    }
    else
    {
        for (iter = idx2->field_18; iter && *((int *)(iter + _start)) <= *((int *)(idx + _start)); iter = iter->field_18)
        {
            idx2 = iter;
        }
        idx2->field_18 = idx;
        idx->field_18 = iter;
    }
    return sub_0;
    return v2;
}


/* ===== sub_3a1 @ 0x3a1, size=250, cc=18 ===== */
extern int g_1;
extern int g_12d;
extern int g_14;
extern char g_2;
extern char g_40;
extern char g_80;
extern int g_e1;
extern unsigned int g_f;

int sub_3a1(unsigned int a0, unsigned int a1, int a2, unsigned int a3)
{
    unsigned int v11;  // r6
    unsigned int v0;  // [bp-0x60]
    unsigned int v1;  // [bp-0x5c]
    unsigned int v2;  // [bp-0x58]
    int v3;  // [bp-0x30]
    int v4;  // [bp-0x2c]
    int v5;  // [bp-0x28]
    unsigned int v6;  // [bp-0x20]
    int v7;  // [bp-0x1c]
    unsigned int v8;  // [bp-0x18]
    unsigned int v9;  // [bp-0x14]
    unsigned int v10;  // [bp-0x8]

    v6 = a1;
    v7 = a2;
    v8 = a3;
    v9 = a1 * 128;
    v10 = 15;
    v2 = sub_0;
    v0 = sub_0;
    v1 = sub_0;
    if (!sub_2abd(0x1e200, 225, 301, "M", v3, v4, v5))
        sub_2abd(0x1e200, 20, 301, 1, "M", "M", "M");
    switch (v11 * 64)
    {
    case 0:
        return sub_2abd(65798, 62113, "M", "M", "M", "M", "M");
    case 1:
        return sub_2abd(65799, 62113, "M", "M", "M", "M", "M");
    case 2:
        sub_aed(a1, a2);
        return sub_0;
    case 3:
        sub_1a2d();
        return sub_0;
    case 4:
        sub_28bd(a1);
        return sub_0;
    case 5:
        sub_1975();
        return sub_0;
    case 6:
        sub_280d(a1);
        return sub_0;
    case 7:
        sub_2655(a1);
        return sub_0;
    case 8:
        sub_f95();
        return sub_0;
    case 9:
        sub_e19(a1);
        return sub_0;
    case 10:
        sub_eb5(a1);
        return sub_0;
    case 11:
        sub_2721(a1);
        return sub_0;
    case 12:
        sub_1685();
        return sub_0;
    default:
        return ~(2);
    }
}


/* ===== sub_2655 @ 0x2655, size=200, cc=19 ===== */
typedef struct struct_0 {
    char padding_0[48];
    unsigned int field_30;
} struct_0;

extern int g_1;
extern int g_11;
extern int g_14;
extern unsigned int g_1d;
extern unsigned int g_1e;
extern int g_2c;
extern char g_30;
extern int g_5;
extern int g_53;
extern int g_c;
extern int g_e1;

struct_0 * sub_2655(int a0)
{
    int v3;  // r4
    unsigned int v4;  // r9
    struct_0 *idx;  // r0
    int v6;  // r1
    int v7;  // r1
    unsigned int v0;  // [bp-0x20]
    int v1;  // [bp-0x1c]
    int v2;  // [bp-0x18]

    v3 = a0;
    if (sub_2abd(0x1e200, 225, sub_20, "M", "M", "M", "M") == 1)
    {
        if (v3 == 20)
        {
            v3 = 0x11;
        }
        else if (v3 == 5)
        {
            v3 = 0x11;
        }
    }
    idx = 12 + v4;
    switch (v3)
    {
    case 8: case 13:
        v7 = idx->field_30 + 1;
        idx->field_30 = v7;
        if (v7 <= 1)
            return idx;
        idx->field_30 = sub_0;
        return idx;
    case 17:
        return sub_4b9();
    case 2: case 12:
        v6 = idx->field_30;
        idx->field_30 = v6 - 1;
        if (v6 >= 1)
            return idx;
        idx->field_30 = 1;
        return idx;
    case 18:
        return sub_2abd(0x1e200, 44, "M", "M", "M", "M", "M");
    case 5: case 20:
        if (!idx->field_30)
        {
            v1 = sub_0;
            v2 = sub_0;
            v0 = 29;
            return sub_2abd(0x1e200, 83, 1);
        }
        v1 = sub_0;
        v2 = sub_0;
        v0 = 30;
        return sub_2abd(0x1e200, 83, 1);
    default:
        return idx;
    }
}


/* ===== sub_2e51 @ 0x2e51, size=216, cc=18 ===== */
typedef struct struct_2 {
    char padding_0[8];
    struct struct_0 *field_8;
    unsigned int field_c;
    unsigned int field_10;
} struct_2;

typedef struct struct_0 {
    char padding_0[12];
    struct struct_1 *field_c;
    unsigned int field_10;
    char padding_14[4];
    void* field_18;
    unsigned int field_1c;
} struct_0;

typedef struct struct_1 {
    unsigned int field_0;
} struct_1;

extern char g_10;
extern char g_134;
extern char g_14;
extern char g_18;
extern char g_32;
extern char g_7d0;
extern unsigned int g_a;
extern char g_c;

unsigned int sub_2e51(unsigned int a0, unsigned int a1, unsigned int a2, unsigned int a3)
{
    unsigned int v1;  // r0
    unsigned int v2;  // r9
    struct_0 *v11;  // r0, Other Possible Types: unsigned int
    struct_0 *idx;  // r0
    unsigned int v13;  // r1
    int v15;  // r0
    struct_2 *idx1;  // r6
    unsigned int v4;  // r1
    unsigned int v5;  // r1
    struct_0 *index;  // r0
    unsigned int v7;  // r3
    struct_0 *idx2;  // r4
    void* v9;  // r2
    void* v10;  // r2
    unsigned int v0;  // [bp-0x18]

    v0 = a3;
    v1 = (*((int *)0x475052d1))(*((int *)0x475052d1));
    idx1 = 308 + v2;
    v4 = idx1->field_10;
    idx1->field_10 = sub_0;
    v5 = v1 - v4;
    index = *((int *)(idx1 + _start));
    v7 = v5;
    if (!index)
        return index;
    if (!*((int *)(index + _start)))
    {
        *((void* *)(index + _start)) = ~(sub_0);
        idx2 = index;
        *((void* *)(idx1 + _start)) = index->field_18;
        if (50 > v5)
        {
            v5 = 50;
        }
        else if (v5 > 2000)
        {
            v5 = 2000;
        }
        while (true)
        {
            v9 = index->field_18;
            if (!v9 || *((int *)(v9 + _start)) >= v5)
                break;
            *((void* *)(v9 + _start)) = ~(sub_0);
            v10 = index->field_18;
            *((void* *)(index + sub_1c)) = v10;
            *((int *)(idx1 + _start)) = (int)v10[24];
            index = v10;
        }
        *((void* *)(index + sub_1c)) = sub_0;
        v11 = *((int *)(idx1 + _start));
    }
    else
    {
        idx2 = sub_0;
    }
    if (sub_0 > v7)
        v7 = sub_0;
    idx = *((int *)(idx1 + _start));
    v13 = *((int *)(idx + _start));
    if (sub_0 > v13)
    {
        v13 = sub_0;
        *((void* *)(idx + _start)) = sub_0;
    }
    if (v13 > 0xffff)
        v13 = 0xffff;
    do
    {
        *((unsigned int *)(idx + _start)) = *((int *)(idx + _start)) - v13;
        idx = idx->field_18;
    } while (idx->field_18);
    v15 = v13 - v7;
    if (sub_0 >= v15)
        v15 = 10;
    for (v11 = sub_2e1d(v15); idx2 && (v11 = (struct_0 *)*((int *)(idx2 + _start)), v11 < sub_0); idx2 = idx1->field_c)
    {
        *((void* *)(idx2 + _start)) = sub_0;
        idx1->field_c = *((int *)(idx2 + sub_1c));
        v11 = (unsigned int)idx2->padding_14;
        if (v11)
        {
            v0 = v11;
            v11 = sub_2cf1(idx2, "M", idx2->field_10, "M");
        }
        if (idx2->field_c)
            v11 = idx2->field_c(idx2->field_10);
    }
    idx1->field_c = sub_0;
    return v11;
}


/* ===== sub_2721 @ 0x2721, size=212, cc=17 ===== */
typedef struct struct_0 {
    char padding_0[60];
    int field_3c;
    unsigned int field_40;
    char padding_44[4];
    int field_48;
    int field_4c;
} struct_0;

extern int g_1;
extern int g_11;
extern int g_2c;
extern int g_34;
extern char g_3c;
extern int g_4;
extern char g_40;
extern char g_44;
extern char g_48;
extern char g_4c;
extern char g_c;

int sub_2721(int a0)
{
    unsigned int v0;  // r9
    struct_0 *idx;  // r4
    int v6;  // r2
    int v7;  // r3
    int v8;  // r0
    int v9;  // r1
    int v2;  // r0
    int v3;  // r1
    int v4;  // r1
    int v5;  // r0

    idx = 12 + v0;
    v2 = sub_0;
    if (idx->padding_44)
        v2 = sub_2abd(0x1e200, 0x11, idx->padding_44, 4, "M", "M", "M");
    switch (a0)
    {
    case 2: case 12:
        v4 = idx->field_48;
        idx->field_48 = v4 - 1;
        if (v4 < 1)
        {
            v2 -= 1;
            idx->field_48 = v2;
            break;
        }
        break;
    case 4: case 14:
        v2 = idx->field_3c;
        if (v2 > sub_0)
        {
            idx->field_3c = v2 - 1;
            v5 = sub_2249(sub_2abd(0x1e200, 52, "M", "M", "M", "M", "M"), v9, v6, v7, "M", "M", "M");
            v2 = sub_31ad(idx->field_4c, idx->field_3c, v5);
            break;
        }
        break;
    case 6: case 15:
        v2 = idx->field_3c;
        if (idx->field_40 - 1 > v2)
        {
            idx->field_3c = v2 + 1;
            v8 = sub_2249(sub_2abd(0x1e200, 52, "M", "M", "M", "M", "M"), v9, v6, v7, "M", "M", "M");
            v2 = sub_31ad(idx->field_4c, idx->field_3c, v8);
            break;
        }
        break;
    case 8: case 13:
        v3 = idx->field_48 + 1;
        idx->field_48 = v3;
        if (v3 >= v2)
        {
            v2 = sub_0;
            idx->field_48 = sub_0;
            break;
        }
        break;
    case 18:
        sub_3091();
        v2 = sub_2abd(0x1e200, 44, "M", "M", "M", "M", "M");
    }
    return v2;
}


/* ===== sub_280d @ 0x280d, size=170, cc=15 ===== */
extern int g_1;
extern int g_11;
extern int g_12;
extern char g_28;
extern int g_2c;
extern int g_4;
extern int g_c;

int sub_280d(int a0)
{
    unsigned int v0;  // r9
    int idx[12];  // r4
    int v2;  // r0
    int v3;  // r1
    int v4;  // r1

    idx = 12 + v0;
    v2 = sub_2abd(0x1e200, 0x11, idx[10], 4, "M", "M", "M");
    switch (a0)
    {
    case 8: case 13:
        v4 = idx[11] + 1;
        idx[11] = v4;
        if (v4 < v2)
            return v2;
        idx[11] = sub_0;
        return v2;
    case 5: case 17: case 20:
        return sub_8f9(*((int *)(idx[10] + idx[11] * 4)));
    case 2: case 12:
        v3 = idx[11];
        idx[11] = v3 - 1;
        if (v3 >= 1)
            return v2;
        idx[11] = v2 - 1;
        return v2 - 1;
    case 18:
        if (idx[10])
            sub_2abd(0x1e200, 18, idx[10], "M", "M", "M", "M");
        idx[10] = sub_0;
        return sub_2abd(0x1e200, 44, "M", "M", "M", "M", "M");
    default:
        return v2;
    }
}


/* ===== sub_2bc1 @ 0x2bc1, size=134, cc=12 ===== */
typedef struct struct_0 {
    char padding_0[20];
    int field_14;
} struct_0;

extern char g_14;
extern char g_2;
extern unsigned int g_2c5d;
extern char g_4;
extern char g_b4;
extern char g_c;

unsigned int sub_2bc1(int *idx, unsigned int a1, int *a2, unsigned int a3)
{
    int v4;  // r9
    unsigned int v5;  // r4
    int v10;  // r1, Other Possible Types: unsigned int
    int v11;  // r2, Other Possible Types: unsigned int
    unsigned int v6;  // r3
    unsigned int v7;  // r0
    struct_0 *v8;  // r1
    int v9;  // r3
    int v0;  // [bp-0x28]
    int v1[4];  // [bp-0x24]
    int v2[3];  // [bp-0x1c]
    unsigned int v3;  // [bp-0x18]

    v1 = idx;
    v2 = a2;
    v3 = a3;
    v0 = v4;
    v5 = sub_0;
    sub_2e0(*(idx), v4);
    switch (a1)
    {
    case 0:
        v7 = idx[3];
        v8 = 180 + v4;
        v8->field_14 = v7;
        v5 = sub_2b5d(sub_2e9(v7, v8), v10, v11, v9);
        break;
    case 1:
        v5 = (*(a2) != _start ? sub_2ab5(*(a2), a2[1], *((int *)(a2 + _start))) : sub_2ab9(_start));
        break;
    case 2:
        sub_2e51(a1, v10, v11, v6 * 2);
        break;
    case 3:
        idx[3] = a3;
        break;
    case 4:
        sub_2bbd();
        break;
    case 5:
        sub_2c8d();
        break;
    case 6:
        *((unsigned int *)(208 + v4)) = a3;
        break;
    case 8:
        *((int **)(212 + v4)) = a2;
        break;
    case 10:
        v5 = 11357;
        break;
    }
    return v5;
}


/* ===== sub_2c91 @ 0x2c91, size=90, cc=10 ===== */
typedef struct struct_1 {
    char padding_0[24];
    struct struct_0 *field_18;
    struct struct_2 *field_1c;
} struct_1;

typedef struct struct_0 {
    char padding_0[24];
    struct struct_1 *field_18;
} struct_0;

typedef struct struct_2 {
    char padding_0[28];
    struct struct_1 *field_1c;
} struct_2;

extern char g_134;
extern char g_18;
extern char g_c;

struct_1 * sub_2c91(struct_1 *a0)
{
    unsigned int v0;  // r9
    struct struct_1 *idx[4];  // r3
    struct_1 *v10;  // r0
    struct_1 *node;  // r0
    struct_1 *v12;  // r0
    struct_1 *v2;  // r2
    struct_0 *v3;  // r0
    struct_0 *v4;  // r0
    struct_0 *iter;  // r0
    struct_0 *v6;  // r2
    struct_1 *v7;  // r0
    struct_0 *v8;  // r0
    struct_1 *index;  // r2

    if (!a0)
        return a0;
    idx = 308 + v0;
    v2 = *((int *)(idx + _start));
    if (v2 == a0)
    {
        v3 = a0->field_18;
        *((struct_0 **)(idx + _start)) = v3;
        v4 = v3;
    }
    else
    {
        v4 = a0;
        if (v2)
        {
            iter = v2->field_18;
            v4 = iter;
            iter = v2;
            if (v4)
            {
                do
                {
                    v6 = iter;
                    if (iter == a0)
                    {
                        v7 = iter->field_18;
                        v6->field_18 = v7;
                        v4 = v7;
                        break;
                    }
                } while ((iter = (struct_0 *)iter->field_18, v4 = iter, v4));
            }
        }
    }
    v8 = v4;
    index = idx[3];
    if (!index)
    {
        return v8;
    }
    else if (index == a0)
    {
        v10 = *((int *)(index + sub_1c));
        idx[3] = v10;
        return v10;
    }
    else
    {
        node = *((int *)(index + sub_1c));
        if (!node)
            return node;
        while (node != a0)
        {
            index = node;
            node = *((int *)(node + sub_1c));
            if (!node)
                return sub_0;
        }
        v12 = *((int *)(node + sub_1c));
        *((struct_1 **)(index + sub_1c)) = v12;
        return v12;
    }
}


/* ===== sub_eb5 @ 0xeb5, size=220, cc=9 ===== */
typedef struct struct_0 {
    unsigned int field_0;
    char padding_4[4];
    int field_8;
} struct_0;

extern char g_1;
extern int g_2c;
extern char g_3c;
extern int g_4;
extern char g_40;
extern int g_44;
extern int g_45;
extern int g_47;
extern char g_4c;
extern int g_a;
extern char g_c;

int sub_eb5(struct_0 *a0)
{
    unsigned int v0;  // r9
    unsigned int idx[20];  // r7
    int v10;  // r4
    int i;  // r4
    int v4;  // r1
    int v5;  // r2
    int v6;  // r3
    int v7;  // r6
    int index;  // r4
    unsigned int v9;  // r0

    idx = 12 + v0;
    idx[19] = a0->field_0;
    i = sub_0;
    sub_3091(sub_2abd(0x1e200, 0x44, a0, "M", "M", "M", "M"), v4, v5, v6, "M", "M", "M");
    idx[16] = sub_2abd(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
    idx[15] = sub_2abd(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
    v7 = sub_2abd(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
    idx[0x11] = sub_2abd(0x1e200, 10, v7, 4, "M", "M", "M");
    if (v7 > sub_0)
    {
        do
        {
            index = i;
            v9 = sub_2abd(0x1e200, 71, *((int *)(a0 + _start)), "M", "M", "M", "M");
            v10 = index + 1;
            *((unsigned int *)(idx[0x11] + index * 4)) = v9;
            i = v10;
        } while (i < v7);
    }
    return sub_2311(sub_2abd(0x1e200, 44, "M", "M", "M", "M", "M"), v4, v5, v6, "M", "M", "M");
}


/* ===== sub_30c5 @ 0x30c5, size=232, cc=9 ===== */
typedef struct struct_0 {
    char padding_0[8];
    int field_8;
} struct_0;

extern int g_1;
extern int g_17;
extern int g_18;
extern int g_19;
extern int g_1ad;
extern int g_1b;
extern int g_1d;
extern int g_52;
extern char g_c;
extern int g_e1;

int sub_30c5(int a0, int a1, int a2)
{
    int v0;  // r0
    unsigned int v1;  // r7
    struct_0 *v2;  // r0

    sub_2abd(0x1e200, 23, 429, "M", "M", "M", "M");
    v0 = sub_2abd(0x1e200, 225, 29, "M", "M", "M", "M");
    v1 = *((int *)(sub_2abd(0x1e200, 225, 24, "M", "M", "M", "M") + 12));
    v2 = sub_2abd(0x1e200, 225, 24, "M", "M", "M", "M");
    sub_2abd(0x1e200, 82, 429, *((int *)(v2 + _start)), *((int *)(sub_2abd(0x1e200, 225, 24, "M", "M", "M", "M") + 12)), v0, "M");
    sub_2abd(0x1e200, 25, a0, "M", "M", "M", "M");
    sub_2abd(0x1e200, 25, a1, "M", "M", "M", "M");
    sub_2abd(0x1e200, 25, a2, "M", "M", "M", "M");
    return sub_2abd(0x1e200, 27, 1, "M", "M", "M", "M");
}


/* ===== sub_2591 @ 0x2591, size=188, cc=8 ===== */
extern char g_1;
extern int g_14;
extern int g_146;
extern int g_17;
extern int g_2c;
extern int g_34;
extern char g_4;
extern int g_74;
extern int g_ba;
extern char g_c;
extern int g_e1;

int sub_2591(void)
{
    unsigned int v0;  // r9
    unsigned int *v1;  // r6

    sub_2abd(0x1e200, 186, "M", "M", "M", "M", "M");
    *((char *)(4 + v0)) = 1;
    if (sub_2abd(0x1e200, 225, 23, "M", "M", "M", "M") != 326)
    {
        sub_2abd(0x1e200, 52, "M", "M", "M", "M", "M");
        v1 = 12 + v0;
        v1[1] = sub_0;
        *(v1) = sub_2abd(0x1e200, 225, 116, "M", "M", "M", "M");
        sub_2abd(0x1e200, 20, 116, "M", "M", "M", "M");
    }
    else
    {
        sub_2abd(0x1e200, 44, "M", "M", "M", "M", "M");
    }
    return sub_2abd(0x1e200, 20, 23, 326, "M", "M", "M");
}


/* ===== sub_e19 @ 0xe19, size=150, cc=6 ===== */
typedef struct struct_0 {
    char padding_0[8];
    int field_8;
} struct_0;

extern int g_2c;
extern char g_34;
extern char g_38;
extern int g_44;
extern int g_45;
extern int g_46;
extern char g_c;

int sub_e19(struct_0 *a0)
{
    unsigned int v0;  // r9
    unsigned int idx;  // r7
    int v2;  // r1
    int v3;  // r2
    int v4;  // r3

    sub_2abd(0x1e200, 0x44, a0, "M", "M", "M", "M");
    idx = 12 + v0;
    if ((char)sub_2abd(0x1e200, 70, *((int *)(a0 + _start)), "M", "M", "M", "M") == 1)
    {
        *((unsigned int *)(idx + 52)) = sub_2abd(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
        *((unsigned int *)(idx + 56)) = sub_2abd(0x1e200, 69, *((int *)(a0 + _start)), "M", "M", "M", "M");
    }
    else
    {
        *((void* *)(idx + 52)) = sub_0;
        *((void* *)(idx + 56)) = sub_0;
    }
    return sub_2299(sub_2abd(0x1e200, 44, "M", "M", "M", "M", "M"), v2, v3, v4, "M", "M", "M");
}


/* ===== sub_1975 @ 0x1975, size=174, cc=5 ===== */
typedef struct struct_0 {
    char padding_0[40];
    unsigned int field_28;
} struct_0;

extern int g_1;
extern int g_11;
extern char g_14;
extern int g_1d;
extern int g_24;
extern char g_28;
extern int g_2a;
extern int g_2b;
extern char g_2c;
extern char g_32;
extern int g_3388;
extern int g_4;
extern char g_a;
extern char g_c;

int sub_1975(void)
{
    unsigned int v7;  // r9
    struct_0 *v8;  // r7
    unsigned int v9;  // r0
    unsigned int v10;  // r4
    unsigned int v0;  // [bp-0x34]
    unsigned int v1;  // [bp-0x2c]
    unsigned int v2;  // [bp-0x28]
    unsigned int v3;  // [bp-0x24]
    unsigned int v4;  // [bp-0x20]
    char v5;  // [bp-0x1c], Other Possible Types: unsigned int
    char v6;  // [bp-0x18], Other Possible Types: unsigned int

    v8 = 12 + v7;
    v9 = sub_2abd(0x1e200, 0x11, v8->field_28, 4, "M", "M", "M");
    sub_2abd(0x1e200, 42, 0x3388, "M", "M", &v6, &v5);
    v10 = v9 * v5 + 10;
    v0 = v8->field_28;
    v1 = sub_2abd(0x1e200, 29, "M", "M", "M", "M", "M", v8->field_28, "M") - v10 - 20;
    v4 = 12 + v7 + 44;
    v2 = v6 + 50;
    v3 = v10;
    sub_2abd(0x1e200, 43, &v0, "M", "M", "M", "M");
    return sub_2abd(0x1e200, 36, 1, 1, "M", "M", "M");
}


/* ===== sub_2299 @ 0x2299, size=116, cc=4 ===== */
extern int g_12e;
extern int g_12f;
extern int g_14;
extern int g_148;
extern int g_17;
extern char g_30;
extern int g_34;
extern char g_c;

int sub_2299(void)
{
    unsigned int v0;  // r9

    *((void* *)(12 + v0 + 48)) = sub_0;
    sub_2abd(0x1e200, 52, "M", "M", "M", "M", "M");
    sub_2abd(0x1e200, 20, 302, "M", "M", "M", "M");
    sub_2abd(0x1e200, 20, 303, "M", "M", "M", "M");
    return sub_2abd(0x1e200, 20, 23, 328, "M", "M", "M");
}

