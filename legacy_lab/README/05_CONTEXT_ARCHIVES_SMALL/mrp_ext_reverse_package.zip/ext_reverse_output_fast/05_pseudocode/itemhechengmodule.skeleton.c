/* Skeleton recovered from function map for itemhechengmodule. Fill bodies from 02_disassembly. */
typedef int i32;

// addr=0x0, offset=0x0, mode=ARM, size=8, cc=1
i32 sub_0(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x8, offset=0x8, mode=ARM, size=20, cc=1
i32 _start(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1c, offset=0x1c, mode=ARM, size=4, cc=1
i32 sub_1c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20, offset=0x20, mode=ARM, size=424, cc=14
i32 sub_20(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xf4, offset=0xf4, mode=ARM, size=4, cc=1
i32 sub_f4(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x109, offset=0x108, mode=Thumb, size=2, cc=1
i32 sub_109(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x10b, offset=0x10a, mode=Thumb, size=2, cc=1
i32 sub_10b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x135, offset=0x134, mode=Thumb, size=58, cc=3
i32 sub_135(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x177, offset=0x176, mode=Thumb, size=6, cc=1
i32 sub_177(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x18d, offset=0x18c, mode=Thumb, size=8, cc=1
i32 sub_18d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x195, offset=0x194, mode=Thumb, size=150, cc=18
i32 sub_195(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x231, offset=0x230, mode=Thumb, size=130, cc=1
i32 sub_231(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2b5, offset=0x2b4, mode=Thumb, size=18, cc=1
i32 sub_2b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2c8, offset=0x2c8, mode=ARM, size=16, cc=1
i32 sub_2c8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2d9, offset=0x2d8, mode=Thumb, size=102, cc=4
i32 sub_2d9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e5, offset=0x2e4, mode=Thumb, size=4, cc=1
i32 sub_2e5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x2e8, offset=0x2e8, mode=ARM, size=28, cc=1
i32 sub_2e8(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x305, offset=0x304, mode=Thumb, size=4, cc=1
i32 sub_305(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x308, offset=0x308, mode=ARM, size=28, cc=1
i32 sub_308(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x324, offset=0x324, mode=ARM, size=4, cc=1
i32 sub_324(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x329, offset=0x328, mode=Thumb, size=22, cc=1
i32 sub_329(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x34b, offset=0x34a, mode=Thumb, size=148, cc=2
i32 sub_34b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e1, offset=0x3e0, mode=Thumb, size=16, cc=1
i32 sub_3e1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3f1, offset=0x3f0, mode=Thumb, size=280, cc=11
i32 sub_3f1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x509, offset=0x508, mode=Thumb, size=4, cc=1
i32 sub_509(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x50d, offset=0x50c, mode=Thumb, size=256, cc=10
i32 sub_50d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x60d, offset=0x60c, mode=Thumb, size=26, cc=1
i32 sub_60d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x681, offset=0x680, mode=Thumb, size=4, cc=1
i32 sub_681(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x685, offset=0x684, mode=Thumb, size=302, cc=12
i32 sub_685(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7b5, offset=0x7b4, mode=Thumb, size=4, cc=1
i32 sub_7b5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x7b9, offset=0x7b8, mode=Thumb, size=266, cc=12
i32 sub_7b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x961, offset=0x960, mode=Thumb, size=4, cc=1
i32 sub_961(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x965, offset=0x964, mode=Thumb, size=586, cc=27
i32 sub_965(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xbb1, offset=0xbb0, mode=Thumb, size=4, cc=1
i32 sub_bb1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xbb5, offset=0xbb4, mode=Thumb, size=738, cc=29
i32 sub_bb5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xe99, offset=0xe98, mode=Thumb, size=8, cc=1
i32 sub_e99(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0xea1, offset=0xea0, mode=Thumb, size=986, cc=39
i32 sub_ea1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x127d, offset=0x127c, mode=Thumb, size=4, cc=1
i32 sub_127d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1281, offset=0x1280, mode=Thumb, size=1704, cc=58
i32 sub_1281(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1955, offset=0x1954, mode=Thumb, size=1924, cc=71
i32 sub_1955(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x1de1, offset=0x1de0, mode=Thumb, size=12, cc=1
i32 sub_1de1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x20fd, offset=0x20fc, mode=Thumb, size=1008, cc=39
i32 sub_20fd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24ed, offset=0x24ec, mode=Thumb, size=8, cc=1
i32 sub_24ed(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x24f5, offset=0x24f4, mode=Thumb, size=948, cc=37
i32 sub_24f5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28a9, offset=0x28a8, mode=Thumb, size=8, cc=1
i32 sub_28a9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x28b1, offset=0x28b0, mode=Thumb, size=3380, cc=137
i32 sub_28b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3635, offset=0x3634, mode=Thumb, size=28, cc=1
i32 sub_3635(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3651, offset=0x3650, mode=Thumb, size=4, cc=1
i32 sub_3651(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3655, offset=0x3654, mode=Thumb, size=118, cc=11
i32 sub_3655(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x36dd, offset=0x36dc, mode=Thumb, size=440, cc=18
i32 sub_36dd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x38b1, offset=0x38b0, mode=Thumb, size=106, cc=11
i32 sub_38b1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3931, offset=0x3930, mode=Thumb, size=46, cc=2
i32 sub_3931(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3979, offset=0x3978, mode=Thumb, size=62, cc=2
i32 sub_3979(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39b9, offset=0x39b8, mode=Thumb, size=12, cc=1
i32 sub_39b9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x39c5, offset=0x39c4, mode=Thumb, size=118, cc=4
i32 sub_39c5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a3d, offset=0x3a3c, mode=Thumb, size=4, cc=1
i32 sub_3a3d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a41, offset=0x3a40, mode=Thumb, size=86, cc=3
i32 sub_3a41(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a99, offset=0x3a98, mode=Thumb, size=4, cc=1
i32 sub_3a99(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3a9d, offset=0x3a9c, mode=Thumb, size=150, cc=5
i32 sub_3a9d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3b35, offset=0x3b34, mode=Thumb, size=4, cc=1
i32 sub_3b35(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3b39, offset=0x3b38, mode=Thumb, size=100, cc=3
i32 sub_3b39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3b9d, offset=0x3b9c, mode=Thumb, size=4, cc=1
i32 sub_3b9d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ba1, offset=0x3ba0, mode=Thumb, size=86, cc=3
i32 sub_3ba1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3bf9, offset=0x3bf8, mode=Thumb, size=4, cc=1
i32 sub_3bf9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3bfd, offset=0x3bfc, mode=Thumb, size=150, cc=5
i32 sub_3bfd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3c95, offset=0x3c94, mode=Thumb, size=96, cc=3
i32 sub_3c95(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ced, offset=0x3cec, mode=Thumb, size=64, cc=1
i32 sub_3ced(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3d31, offset=0x3d30, mode=Thumb, size=10, cc=1
i32 sub_3d31(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3d3b, offset=0x3d3a, mode=Thumb, size=10, cc=1
i32 sub_3d3b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3d45, offset=0x3d44, mode=Thumb, size=10, cc=1
i32 sub_3d45(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3d4f, offset=0x3d4e, mode=Thumb, size=10, cc=1
i32 sub_3d4f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3d59, offset=0x3d58, mode=Thumb, size=8, cc=1
i32 sub_3d59(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3d61, offset=0x3d60, mode=Thumb, size=10, cc=1
i32 sub_3d61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3d6b, offset=0x3d6a, mode=Thumb, size=10, cc=1
i32 sub_3d6b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3d75, offset=0x3d74, mode=Thumb, size=42, cc=1
i32 sub_3d75(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3d9f, offset=0x3d9e, mode=Thumb, size=10, cc=1
i32 sub_3d9f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3da9, offset=0x3da8, mode=Thumb, size=10, cc=1
i32 sub_3da9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3db3, offset=0x3db2, mode=Thumb, size=8, cc=1
i32 sub_3db3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3dbb, offset=0x3dba, mode=Thumb, size=10, cc=1
i32 sub_3dbb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3dc5, offset=0x3dc4, mode=Thumb, size=10, cc=1
i32 sub_3dc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3dcf, offset=0x3dce, mode=Thumb, size=8, cc=1
i32 sub_3dcf(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3dd7, offset=0x3dd6, mode=Thumb, size=44, cc=1
i32 sub_3dd7(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e03, offset=0x3e02, mode=Thumb, size=8, cc=1
i32 sub_3e03(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e0b, offset=0x3e0a, mode=Thumb, size=10, cc=1
i32 sub_3e0b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e15, offset=0x3e14, mode=Thumb, size=8, cc=1
i32 sub_3e15(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e1d, offset=0x3e1c, mode=Thumb, size=10, cc=1
i32 sub_3e1d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e27, offset=0x3e26, mode=Thumb, size=10, cc=1
i32 sub_3e27(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e31, offset=0x3e30, mode=Thumb, size=8, cc=1
i32 sub_3e31(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e39, offset=0x3e38, mode=Thumb, size=44, cc=1
i32 sub_3e39(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e65, offset=0x3e64, mode=Thumb, size=4, cc=1
i32 sub_3e65(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e69, offset=0x3e68, mode=Thumb, size=6, cc=1
i32 sub_3e69(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e6f, offset=0x3e6e, mode=Thumb, size=8, cc=1
i32 sub_3e6f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e77, offset=0x3e76, mode=Thumb, size=22, cc=1
i32 sub_3e77(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3e8d, offset=0x3e8c, mode=Thumb, size=22, cc=1
i32 sub_3e8d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3ea9, offset=0x3ea8, mode=Thumb, size=16, cc=1
i32 sub_3ea9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x3eb9, offset=0x3eb8, mode=Thumb, size=706, cc=41
i32 sub_3eb9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x41ad, offset=0x41ac, mode=Thumb, size=622, cc=34
i32 sub_41ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4431, offset=0x4430, mode=Thumb, size=24, cc=1
i32 sub_4431(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4449, offset=0x4448, mode=Thumb, size=38, cc=1
i32 sub_4449(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x446f, offset=0x446e, mode=Thumb, size=2, cc=1
i32 sub_446f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4471, offset=0x4470, mode=Thumb, size=128, cc=6
i32 sub_4471(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x44f3, offset=0x44f2, mode=Thumb, size=90, cc=3
i32 sub_44f3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x454f, offset=0x454e, mode=Thumb, size=92, cc=3
i32 sub_454f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x45ab, offset=0x45aa, mode=Thumb, size=102, cc=3
i32 sub_45ab(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4611, offset=0x4610, mode=Thumb, size=104, cc=4
i32 sub_4611(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4677, offset=0x4676, mode=Thumb, size=220, cc=10
i32 sub_4677(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4751, offset=0x4750, mode=Thumb, size=4, cc=1
i32 sub_4751(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4755, offset=0x4754, mode=Thumb, size=984, cc=56
i32 sub_4755(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4b55, offset=0x4b54, mode=Thumb, size=118, cc=6
i32 sub_4b55(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4bd1, offset=0x4bd0, mode=Thumb, size=12, cc=1
i32 sub_4bd1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4bdd, offset=0x4bdc, mode=Thumb, size=66, cc=1
i32 sub_4bdd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4c25, offset=0x4c24, mode=Thumb, size=4, cc=1
i32 sub_4c25(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4c29, offset=0x4c28, mode=Thumb, size=4, cc=1
i32 sub_4c29(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4c2d, offset=0x4c2c, mode=Thumb, size=52, cc=1
i32 sub_4c2d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4c63, offset=0x4c62, mode=Thumb, size=10, cc=1
i32 sub_4c63(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4c6c, offset=0x4c6c, mode=ARM, size=4, cc=1
i32 sub_4c6c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4c78, offset=0x4c78, mode=ARM, size=8, cc=1
i32 sub_4c78(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4c8b, offset=0x4c8a, mode=Thumb, size=40, cc=1
i32 sub_4c8b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4cb9, offset=0x4cb8, mode=Thumb, size=14, cc=1
i32 sub_4cb9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4ccd, offset=0x4ccc, mode=Thumb, size=70, cc=2
i32 sub_4ccd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4d19, offset=0x4d18, mode=Thumb, size=20, cc=1
i32 sub_4d19(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4d2d, offset=0x4d2c, mode=Thumb, size=4, cc=1
i32 sub_4d2d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4d31, offset=0x4d30, mode=Thumb, size=126, cc=11
i32 sub_4d31(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4d6d, offset=0x4d6c, mode=Thumb, size=8, cc=1
i32 sub_4d6d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4dc5, offset=0x4dc4, mode=Thumb, size=54, cc=2
i32 sub_4dc5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4dfd, offset=0x4dfc, mode=Thumb, size=4, cc=1
i32 sub_4dfd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4e01, offset=0x4e00, mode=Thumb, size=90, cc=10
i32 sub_4e01(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4e5d, offset=0x4e5c, mode=Thumb, size=4, cc=1
i32 sub_4e5d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4e61, offset=0x4e60, mode=Thumb, size=276, cc=24
i32 sub_4e61(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4f8d, offset=0x4f8c, mode=Thumb, size=44, cc=3
i32 sub_4f8d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4fb9, offset=0x4fb8, mode=Thumb, size=8, cc=1
i32 sub_4fb9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x4fc1, offset=0x4fc0, mode=Thumb, size=216, cc=18
i32 sub_4fc1(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x50a3, offset=0x50a2, mode=Thumb, size=2, cc=1
i32 sub_50a3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x50a5, offset=0x50a4, mode=Thumb, size=150, cc=5
i32 sub_50a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x513d, offset=0x513c, mode=Thumb, size=112, cc=5
i32 sub_513d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x51ad, offset=0x51ac, mode=Thumb, size=248, cc=8
i32 sub_51ad(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x52a5, offset=0x52a4, mode=Thumb, size=234, cc=9
i32 sub_52a5(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5391, offset=0x5390, mode=Thumb, size=4, cc=1
i32 sub_5391(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5395, offset=0x5394, mode=Thumb, size=250, cc=8
i32 sub_5395(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5491, offset=0x5490, mode=Thumb, size=222, cc=13
i32 sub_5491(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5571, offset=0x5570, mode=Thumb, size=4, cc=1
i32 sub_5571(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5575, offset=0x5574, mode=Thumb, size=238, cc=13
i32 sub_5575(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5665, offset=0x5664, mode=Thumb, size=4, cc=1
i32 sub_5665(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5669, offset=0x5668, mode=Thumb, size=96, cc=6
i32 sub_5669(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x56c9, offset=0x56c8, mode=Thumb, size=146, cc=9
i32 sub_56c9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x575d, offset=0x575c, mode=Thumb, size=110, cc=6
i32 sub_575d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x57cd, offset=0x57cc, mode=Thumb, size=256, cc=10
i32 sub_57cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x58cd, offset=0x58cc, mode=Thumb, size=208, cc=8
i32 sub_58cd(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x599d, offset=0x599c, mode=Thumb, size=148, cc=6
i32 sub_599d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5a30, offset=0x5a30, mode=ARM, size=16, cc=1
i32 sub_5a30(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5a4c, offset=0x5a4c, mode=ARM, size=4, cc=1
i32 sub_5a4c(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5a6e, offset=0x5a6e, mode=ARM, size=4, cc=1
i32 sub_5a6e(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5b2a, offset=0x5b2a, mode=ARM, size=4, cc=1
i32 sub_5b2a(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5b54, offset=0x5b54, mode=ARM, size=4, cc=1
i32 sub_5b54(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5b5b, offset=0x5b5a, mode=Thumb, size=4, cc=1
i32 sub_5b5b(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5b5f, offset=0x5b5e, mode=Thumb, size=8, cc=1
i32 sub_5b5f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5b67, offset=0x5b66, mode=Thumb, size=10, cc=1
i32 sub_5b67(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5b71, offset=0x5b70, mode=Thumb, size=20, cc=1
i32 sub_5b71(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5ba3, offset=0x5ba2, mode=Thumb, size=4, cc=1
i32 sub_5ba3(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5bbc, offset=0x5bbc, mode=ARM, size=8, cc=1
i32 sub_5bbc(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5bc9, offset=0x5bc8, mode=Thumb, size=2, cc=1
i32 sub_5bc9(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5bcb, offset=0x5bca, mode=Thumb, size=4, cc=1
i32 sub_5bcb(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5bef, offset=0x5bee, mode=Thumb, size=12, cc=1
i32 sub_5bef(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5c08, offset=0x5c08, mode=ARM, size=12, cc=1
i32 sub_5c08(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5c24, offset=0x5c24, mode=ARM, size=4, cc=1
i32 sub_5c24(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5c2d, offset=0x5c2c, mode=Thumb, size=4, cc=1
i32 sub_5c2d(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5c33, offset=0x5c32, mode=Thumb, size=4, cc=1
i32 sub_5c33(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5c3f, offset=0x5c3e, mode=Thumb, size=4, cc=1
i32 sub_5c3f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5c43, offset=0x5c42, mode=Thumb, size=66, cc=1
i32 sub_5c43(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5c4f, offset=0x5c4e, mode=Thumb, size=16, cc=1
i32 sub_5c4f(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x5c65, offset=0x5c64, mode=Thumb, size=6, cc=1
i32 sub_5c65(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x100014, offset=0x100014, mode=ARM, size=0, cc=1
i32 UnresolvableJumpTarget(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

// addr=0x100018, offset=0x100018, mode=ARM, size=0, cc=1
i32 UnresolvableCallTarget(i32 r0, i32 r1, i32 r2, i32 r3) { /* TODO: translate from disassembly */ return 0; }

