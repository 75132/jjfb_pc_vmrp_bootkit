# MRP EXT reverse package summary

这些 `.ext` 解包后都是 `MRPGCMAP` ARM/Thumb 裸二进制，不是普通数据表。多数模块是 ARM 入口壳 + Thumb 业务代码。

| module | unpacked | gzip | funcs/candidates | analysis | ascii | gb18030-cstr |
|---|---:|---|---:|---|---:|---:|
| `mainmenumodule_1` | 28712 | True | 225 | angr-cfg | 322 | 178 |
| `cfunction_1` | 331520 | False | 1402 | prologue-scan | 726 | 5347 |
| `itemhechengmodule` | 25136 | True | 173 | angr-cfg | 276 | 207 |
| `shopmodule` | 14836 | True | 134 | angr-cfg | 174 | 115 |
| `robotol` | 253420 | True | 1042 | prologue-scan | 4271 | 1919 |
| `othermodule` | 46708 | True | 147 | prologue-scan | 515 | 308 |
| `lianmengmodule` | 36216 | True | 108 | prologue-scan | 454 | 274 |
| `reg_1` | 2472 | True | 9 | prologue-scan | 33 | 6 |
| `leitaimodule_1` | 21248 | True | 56 | prologue-scan | 258 | 166 |
| `monstermodule_1` | 19256 | True | 50 | prologue-scan | 188 | 143 |
| `betmodule_2` | 14512 | True | 45 | prologue-scan | 201 | 129 |
| `viewmanmodule_1` | 19436 | True | 52 | prologue-scan | 223 | 177 |
| `itembagshopmodule_1` | 43420 | True | 104 | prologue-scan | 402 | 343 |
| `monsterstatemodule_1` | 18712 | True | 55 | prologue-scan | 237 | 124 |
| `gameattackmodule_1` | 47368 | True | 161 | prologue-scan | 491 | 336 |
| `taobaomodule_1` | 16504 | True | 49 | prologue-scan | 184 | 145 |
| `gezimodule_1` | 7356 | True | 27 | prologue-scan | 113 | 55 |
| `chatmodule_1` | 15228 | True | 50 | prologue-scan | 189 | 127 |
| `moduletest_1` | 15152 | True | 31 | prologue-scan | 149 | 71 |
| `mailmodule_1` | 27692 | True | 68 | prologue-scan | 351 | 194 |

## 目录
- `01_uncompressed_ext/`：解压后的 MRPGCMAP 二进制。
- `02_disassembly/`：函数块或候选函数反汇编。`addr` 低位为 1 表示 Thumb 函数，真实文件偏移是 `addr & ~1`。
- `03_function_maps/`：函数/候选函数表。
- `04_strings/`：字符串候选。
- `05_pseudocode/`：精选函数伪 C。
- `06_reports/`：运行逻辑报告。

说明：`analysis=angr-cfg` 的模块函数边界更可靠；`prologue-scan` 是按 Thumb 函数序言扫描，适合快速覆盖全量模块，但需要结合反汇编人工确认。

## 新增报告
- `06_reports/high_value_functions.md`：每个模块最值得优先反编译/命名的函数地址。
- `06_reports/opcode_candidates.md`：已从伪 C 中提取出的引擎 opcode 候选。
- `05_pseudocode/*.skeleton.c`：全量函数骨架。
- `05_pseudocode/betmodule_2.selected_pseudo.c`：目前恢复质量最高的模块伪 C。
