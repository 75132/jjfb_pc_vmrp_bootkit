#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import socket, threading, time, json, os
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).resolve().parents[1]
LOGS = ROOT / "logs"
LOGS.mkdir(exist_ok=True)
JPATH = LOGS / f"mock_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jsonl"
LOCK = threading.Lock()

ACK_8B = bytes.fromhex("9800010000130100")
ACK_8B_ALT = bytes.fromhex("9800010000170100")
AUTH_18B = bytes.fromhex("980001000021010000010001980400001d31")
NO_UPDATE_50B = bytes.fromhex(
    "980001000021010000010001980400001d31"
    "9800010000130100"
    "9800010000170100"
    "9800010000130100"
    "9800010000130100"
)

def jlog(obj):
    obj["ts"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    with LOCK:
        with JPATH.open("a", encoding="utf-8") as f:
            f.write(json.dumps(obj, ensure_ascii=False) + "\n")

def classify(data):
    if len(data) == 103: return "LOGIN_103B"
    if len(data) == 27: return "HEARTBEAT_27B"
    if len(data) == 25: return "UNKNOWN_25B"
    if len(data) == 48: return "UNKNOWN_48B"
    if len(data) in (270,426,430,529) or b"skymp" in data or b"android" in data:
        return f"DEVICE_OR_COMBINED_{len(data)}B"
    return f"UNKNOWN_{len(data)}B"

def send(c, sid, port, data, note):
    c.sendall(data)
    jlog({"sid":sid,"port":port,"dir":"send","len":len(data),"hex":data.hex(),"note":note})

def handle_tcp(c, addr, port):
    sid = f"{port}-{int(time.time()*1000)%100000}"
    hb = 0
    jlog({"sid":sid,"port":port,"dir":"open","peer":str(addr)})
    c.settimeout(90)
    try:
        while True:
            try:
                data = c.recv(8192)
            except socket.timeout:
                jlog({"sid":sid,"port":port,"dir":"timeout"})
                break
            if not data:
                jlog({"sid":sid,"port":port,"dir":"eof"})
                break
            cls = classify(data)
            jlog({"sid":sid,"port":port,"dir":"recv","len":len(data),"class":cls,"hex":data.hex()})
            if port in (21002,21003):
                if cls == "LOGIN_103B":
                    send(c,sid,port,AUTH_18B+ACK_8B_ALT,"platform login 26B")
                else:
                    send(c,sid,port,ACK_8B,"platform ack")
                continue
            if port == 20000:
                if cls == "LOGIN_103B":
                    send(c,sid,port,AUTH_18B+ACK_8B_ALT+ACK_8B,"20000 login 34B")
                elif cls.startswith("DEVICE"):
                    if len(data) >= 500:
                        send(c,sid,port,AUTH_18B+ACK_8B_ALT+ACK_8B,"combined login part")
                        time.sleep(0.05)
                    send(c,sid,port,ACK_8B,"device ack")
                elif cls == "HEARTBEAT_27B":
                    hb += 1
                    if hb == 1:
                        send(c,sid,port,ACK_8B,"hb1 ack")
                    else:
                        send(c,sid,port,NO_UPDATE_50B,"hb2 no_update baseline")
                elif cls == "UNKNOWN_25B":
                    send(c,sid,port,NO_UPDATE_50B,"25B no_update baseline")
                else:
                    send(c,sid,port,ACK_8B,"default ack")
                continue
            send(c,sid,port,ACK_8B,"default ack")
    except Exception as e:
        jlog({"sid":sid,"port":port,"dir":"error","error":repr(e)})
    finally:
        try: c.close()
        except Exception: pass
        jlog({"sid":sid,"port":port,"dir":"close"})

def tcp_server(port):
    s = socket.socket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("0.0.0.0", port))
    s.listen(20)
    print(f"TCP {port} listening")
    while True:
        c,a = s.accept()
        threading.Thread(target=handle_tcp, args=(c,a,port), daemon=True).start()

def http6009():
    s = socket.socket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("0.0.0.0", 6009))
    s.listen(20)
    print("HTTP 6009 listening")
    while True:
        c,a = s.accept()
        try:
            req = c.recv(4096)
            jlog({"sid":"http6009","port":6009,"dir":"recv","peer":str(a),"len":len(req),"text":req.decode("latin1","replace")})
            resp = b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"
            c.sendall(resp)
            jlog({"sid":"http6009","port":6009,"dir":"send","len":len(resp),"text":resp.decode("latin1","replace")})
        except Exception as e:
            jlog({"sid":"http6009","port":6009,"dir":"error","error":repr(e)})
        finally:
            c.close()

if __name__ == "__main__":
    for p in [21002,21003,20000]:
        threading.Thread(target=tcp_server, args=(p,), daemon=True).start()
    threading.Thread(target=http6009, daemon=True).start()
    print("mock jsonl:", JPATH)
    while True:
        time.sleep(3600)
