# gwy 网游强制更新问题：静态模块定位与下一步方案

## 现在的目标

当前不是研究机甲风暴进游戏后的业务服，也不是直接启动 `jjfb.mrp`。

当前目标只有一个：

```text
从 gwy.mrp → 网游专区 → 点击任意网游
绕过“软件需要联网检查更新，是否立刻更新？”
让 gwy 继续按原上下文启动对应本地 MRP
```

也就是说，问题在 **gwy 大厅的更新检查门槛**，不是 `jjfb` 游戏内协议。

---

## 最重要的判断

你说“点什么都强制更新”，这说明它不是机甲风暴独有逻辑，而是 **gwy 网游列表的公共启动前检查**。

因此主攻模块应该是：

```text
gwy.mrp
gwy/gamelist.mrp
gwy/dload.mrp
gwy/vdload.mrp
gwy/reglogin.mrp
gwy/svrctrl.mrp
gwy/resmng.mrp
gwy/cfg.bin
```

暂时不要把注意力放到：

```text
gwy/jjfb.mrp
jjfbol/monster/item/map/attack 等游戏数据模块
```

这些是进入游戏加载后才需要处理的。

---

## 模块分工推测

| 模块 | 当前价值 | 重点 |
|---|---|---|
| `gwy/gamelist.mrp` | 最高 | 网游列表、点击条目、弹更新提示、拼启动参数 |
| `gwy/dload.mrp` | 最高 | 点击“立刻更新”后最可能进入的下载/更新模块 |
| `gwy/vdload.mrp` | 高 | 版本下载/校验候选 |
| `gwy/reglogin.mrp` | 中高 | 平台登录、注册、可能产生 103B 登录包 |
| `gwy/svrctrl.mrp` | 中高 | 服务器控制/网关控制候选 |
| `gwy/resmng.mrp` | 中 | 本地资源/已下载状态判断候选 |
| `gwy/cfg.bin` | 高但危险 | 条目状态、图标、下载状态、启动索引；不要整文件替换 |
| `gwy/jjfb.mrp` | 暂缓 | 游戏内服务器列表/角色资料，不是当前强制更新门槛 |

---

## 已经确认的关键证据

### 1. `gwy/gamelist.mrp` 是入口调度核心

里面能看到：

```text
gwy/cfg.bin
gwy/%s.mrp
gwyblink
nmrpname
bmrpname
napptype
nextid
ncode
narg
narg1
dload.mrp
reglogin.mrp
```

这说明点击网游并不是直接运行某个 `.mrp`，而是由 `gamelist` 读取 `cfg.bin` 并拼出启动参数。

### 2. 不能直接启动 `jjfb.mrp`

`jjfb.mrp` 需要 `gwy/gamelist` 提供启动上下文。  
所以不能再做：

```text
dload.mrp → jjfb.mrp
```

这种替换会绕过启动参数，方向不对。

### 3. `cfg.bin` 不能整文件替换

之前整体替换后出现：

```text
闪退
图标缓存消失
全部变成未下载状态
```

说明 `cfg.bin` 里不仅有条目配置，还有缓存/图标/下载状态索引。  
如果以后要动它，只能基于模拟器当前 live cfg 做极小字节 patch；但当前用户希望先继续抓包/模拟，不走文件 patch。

---

## 关键路线修正

### 错误路线

```text
研究 jjfb 游戏服登录
研究游戏内服务器列表
研究角色列表
研究 20000 业务服
```

这些太靠后。

### 正确路线

```text
gwy 点击任意网游
↓
公共强制更新提示
↓
点击确定
↓
进入 dload/vdload/reglogin/svrctrl 之一
↓
本地 mock 返回“无需更新 / 更新完成 / 可本地启动”
↓
gamelist 按原上下文启动本地 MRP
```

所以 mock 的目标不该叫“游戏登录成功”，而应该叫：

```text
gwy update-check bypass mock
```

---

## 抓包实验应该怎么做

### 实验 1：只点游戏，不点“确定”

目的：确认弹窗是否完全由本地逻辑产生。

操作：

```text
开始抓包
进入 gwy.mrp → 网游专区 → 点击任意游戏
弹出“软件需要联网检查更新，是否立刻更新？”
不要点确定
等 10 秒
停止抓包
```

判断：

```text
如果没有任何 21002/21003/20000 流量：
说明“需要更新”判断是本地 gamelist/cfg 分支产生的。
```

### 实验 2：点“确定”后抓包

目的：确认点确定后实际调用哪个更新模块/端口。

操作：

```text
开始抓包
点击任意游戏
弹窗后点确定
等 60 秒
停止抓包
```

重点看：

```text
先连 21002 还是 21003
是否出现 103B 登录包
是否出现 48B 后续请求
是否出现 HTTP
是否出现 20000
```

### 实验 3：换 2-3 个游戏对比

目的：确认强制更新是公共逻辑还是条目差异。

至少抓：

```text
机甲风暴
步步惊情
冒泡网游官网 / 口袋西游任选一个
```

如果不同游戏点击后的网络包结构高度一致，只是少数字段变，说明是 `gamelist/dload` 公共逻辑。

---

## mock 应该怎么改

不要叫 full game mock。  
当前应该做：

```text
gwy_update_mock_server.py
```

优先监听：

```text
21002
21003
```

20000 先不是主线，除非“更新通过后”自然出现。

mock 响应目标：

```text
不是伪造角色列表
不是伪造服务器列表
不是进入游戏世界
而是让 dload/vdload/gamelist 认为：
1. 已经检查过更新
2. 当前本地版本可用
3. 不需要下载
4. 可以回到 gamelist 启动本地 MRP
```

---

## 推荐 mock 模式

### Mode 1：no_update_ack

```text
103B 登录包 → 33B 成功
270/430B → 延迟 ACK
27B → 19B/23B ACK
48B → 38B compound
```

目标：模拟“检查成功，但无更新”。

### Mode 2：download_complete

在 Mode 1 基础上，当出现 48B 或连续心跳后主动推送候选完成包。

目标：模拟“更新完成，返回启动”。

### Mode 3：fast_success_push

103B 登录后主动推送 38B compound。

目标：测试 dload 是否只等待一个完成事件。

---

## 如果抓包路线无法绕过

那才考虑极小 patch，但不是改游戏。

目标仍然是：

```text
gwy/gamelist.ext 的 need_update 分支
或 cfg live 文件里的“需要检查更新”标志
```

patch 原则：

```text
只改当前模拟器 live 文件
只改 1 个字节
先 pull 备份
不要整文件覆盖
```

---

## 给 OpenClaw 的精简任务

```text
当前不要研究进游戏、角色列表、20000 业务服。
现在只研究 gwy 网游列表的公共强制更新门槛。

重点模块：
gwy/gamelist.mrp
gwy/dload.mrp
gwy/vdload.mrp
gwy/reglogin.mrp
gwy/svrctrl.mrp
gwy/resmng.mrp
gwy/cfg.bin

第一步抓包：
1. 点击游戏但不点“确定”，看是否有网络。
2. 点击“确定”，看进入哪个端口。
3. 换 2-3 个游戏做对比。

mock 目标：
让 dload/vdload/gamelist 认为“无需更新 / 更新完成 / 本地版本可启动”，而不是模拟游戏内登录。
```

---

## 附：扫描命中摘录


### strings__320480_gwy_gamelist.mrp.txt

```text
--- ENTRY dload.bmp gz=True size=3200 ---
--- ENTRY dload1.bmp gz=True size=338 ---
--- ENTRY dload.gif gz=True size=1452 ---
dload.gif
dload.gif
dload.gif
dload.gif
dload.gif
dload.gif
dload.gif
dload.gif
dload.gif
dload.gif
dload.gif
dload.gif
http://i.51mrp.com
```

### strings__320480_gwy_vdload.mrp.txt

```text
vdload.ext
--- ENTRY vdload.ext gz=True size=13228 ---
X-Online-Host: 
Host: 
```

### strings__320480_gwy_reglogin.mrp.txt

```text
reglogin.ext
--- ENTRY reglogin.ext gz=True size=36528 ---
```

### strings__320480_gwy_svrctrl.mrp.txt

```text
svrctrl.ext
--- ENTRY svrctrl.ext gz=True size=14812 ---
```
