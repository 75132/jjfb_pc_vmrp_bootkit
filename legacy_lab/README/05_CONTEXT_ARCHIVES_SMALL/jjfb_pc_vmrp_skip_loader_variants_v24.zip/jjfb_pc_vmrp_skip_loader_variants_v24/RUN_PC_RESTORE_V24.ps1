$ROOT = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ROOT
python .\scripts\skip_loader_variants_v24.py restore
