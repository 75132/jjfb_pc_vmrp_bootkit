# OpenClaw 记忆恢复文档：冒泡/MRP 网游抓包路线

## 0. 当前我们在干什么

我们正在尝试让旧的冒泡/MRP 网游“机甲风暴”在模拟器里继续进入游戏流程。

实际入口是：

```text
gwy.mrp
→ 网游专区
→ 点击“机甲风暴”
→ 弹出“软件需要联网检查更新，是否立刻更新？”
→ 点击确定
→ 正在连接服务器
```

重点：

```text
用户不是单独启动 jjfb.mrp。
单独启动 jjfb.mrp 是启动不了的。
必须保留 gwy.mrp → 网游专区 → gamelist/cfg → 游戏入口 这条链路。
```

当前用户明确决定：

```text
不走文件 patch 路线。
继续走抓包 / relay / 协议分析路线。
```

所以 OpenClaw 不要再改 `cfg.bin`、`gamelist.mrp`、`dload.mrp`。

---

## 1. 绝对不要做的事

```text
不要改 cfg.bin
不要替换 cfg.bin
不要改 gamelist.mrp
不要把 dload.mrp 替换成 jjfb.mrp
不要清空 mythroad 缓存
不要清空 gwy 目录
不要动游戏文件
不要安装 Npcap
不要修改系统网络驱动
不要同时劫持多个端口
不要后台运行看不见的脚本
不要用复杂中文 bat 菜单
不要把 172.16.1.2 写死在所有脚本里
```

原因：

1. 之前整体替换 `cfg.bin` 后，模拟器里出现闪退、图标缓存消失、全部游戏变成未下载状态。
2. `cfg.bin` 不只是配置，还包含本地缓存、图标状态、下载状态等信息。
3. 用户现在明确不要文件 patch，继续走抓包路线。

---

## 2. 已经确认过的结论

### 2.1 dyd.apk 不是主卡点

之前发现过：

```text
http://bcs.duapp.com/myplugins/dyd.apk
```

真实访问会返回 403 AccessDenied。  
但是 mock 这个 `dyd.apk` 返回 200 后，客户端行为没有实质变化，后续仍然进入平台连接流程。

结论：

```text
dyd.apk / bcs.duapp.com 不是当前主卡点。
```

### 2.2 111.1.17.146:21003 是旧平台链路，但不是当前唯一突破口

我们已经抓到并分析过 `111.1.17.146:21003`。

典型 21003 流程：

```text
客户端 103B 登录包
  明文包含：
  skymp
  android
  IMEI: 869169020812718
  IMSI: 460006887846701

服务器 33B 认证响应

客户端 270B / 430B 设备信息大包

服务器 19B / 23B ACK

后续心跳 / 断开 / 重连
```

已经成功做过 DNAT 到本地：

```text
111.1.17.146:21003 → 本地 172.16.1.2:21003
```

本地 mock 能收到完整登录流量，也能让客户端行为变化，不再立刻报“连接服务器失败”。

但是最新真实抓包显示：

```text
真实 21003 服务器也只给认证和 ACK
没有下发能进入游戏的业务数据
客户端会主动 FIN 后重连
```

所以：

```text
21003 是重要链路，但继续单独死磕 21003 的收益变低。
```

### 2.3 新主线：21002 → 20000

后续资料里发现更关键的新链路：

```text
111.1.17.148:21002
211.155.236.226:20000
211.155.236.227:20000
```

当前推测：

```text
21002 = 平台登录 / 网关 / 前置鉴权
20000 = 后续业务服 / 游戏服入口
```

特别重要：

```text
当 21002 mock/relay 处理成功后，客户端可能会继续连接 20000。
```

因此当前主攻方向从：

```text
只盯 21003
```

改成：

```text
验证 21002 → 20000 链路
```

---

## 3. 当前推荐技术路线

### 总原则

```text
只抓包，只 relay，不 patch 文件。
```

### 路线

```text
第一步：真实 baseline 抓包
  不加 DNAT
  不开 mock
  不开 relay
  只抓真实流量
  观察 21002 / 21003 / 20000 谁出现

第二步：21002 透明 relay
  只劫持 111.1.17.148:21002
  不劫持 20000
  不劫持 21003

第三步：hybrid 抓包
  客户端 → DNAT → 本地 21002 relay → 真实 111.1.17.148:21002
  同时观察客户端是否自然连接 20000

第四步：
  如果 20000 出现，再进入 20000 协议分析
  如果 20000 不出现，继续分析 21002 的认证/session/返回包
```

一句话：

```text
先证明 21002 是否能把客户端带到 20000。
```

---

## 4. 当前工具包

最新推荐工具包：

```text
maopao_capture_toolkit_v4_python_first.zip
```

核心特点：

```text
Python-first
bat 只是 ASCII 启动器
避免 Windows CMD 中文字符问题
默认只 DNAT 21002
不 DNAT 20000
不改 cfg.bin
不改 gamelist.mrp
自动读取 adb shell ip route 里的 Host IP
自动抓包 120 秒
自动 pull pcap
自动生成 md/csv/html 时间线报告
```

核心文件：

```text
maopao_capture_controller.py
config.json
RUN_CHECK.bat
RUN_CLEANUP.bat
RUN_BASELINE_120S.bat
RUN_HYBRID_21002_ONLY_120S.bat
RUN_SHOW_DNAT.bat
```

---

## 5. OpenClaw 应该按什么顺序执行

### 第 1 步：检查环境

运行：

```bat
RUN_CHECK.bat
```

确认：

```text
adb 可用
设备 emulator-5554 在线
su 可用
tcpdump 可用
adb shell ip route 能看到 default via
```

### 第 2 步：清理旧状态

运行：

```bat
RUN_CLEANUP.bat
```

它应该做：

```text
kill tcpdump
iptables -t nat -F OUTPUT
显示当前 DNAT 规则
```

目的：

```text
避免旧的 DNAT / 旧 tcpdump / 旧 relay 影响结果
```

### 第 3 步：baseline 真实抓包

运行：

```bat
RUN_BASELINE_120S.bat
```

运行后用户在模拟器里操作：

```text
gwy.mrp
→ 网游专区
→ 机甲风暴
→ 确定
→ 等待 Python 窗口自己结束
```

baseline 的含义：

```text
无 DNAT
无 relay
无 mock
只看真实客户端到底连哪些端口
```

输出：

```text
captures/baseline_ports.pcap
reports/baseline_ports_report.md
reports/baseline_ports_report.csv
reports/baseline_ports_report_timeline.html
```

重点看：

```text
21002 是否出现
21003 是否出现
20000 是否出现
是否有 103B 登录包
是否有 skymp/android/IMEI/IMSI 明文
```

### 第 4 步：hybrid 21002-only 抓包

运行：

```bat
RUN_HYBRID_21002_ONLY_120S.bat
```

这个脚本应该自动做：

```text
清理旧 DNAT
启动本地 21002 透明 relay
添加唯一 DNAT：
111.1.17.148:21002 → HostIP:21002
开始抓包 120 秒
抓完自动 pull
自动分析
```

非常重要：

```text
只劫持 21002。
不要劫持 20000。
不要劫持 21003。
```

运行后用户在模拟器里操作：

```text
gwy.mrp
→ 网游专区
→ 机甲风暴
→ 确定
→ 等待 Python 窗口自己结束
```

输出：

```text
captures/hybrid_21002relay.pcap
logs/relay21002.log
logs/relay21002_streams.csv
reports/hybrid_21002relay_report.md
reports/hybrid_21002relay_report.csv
reports/hybrid_21002relay_report_timeline.html
```

---

## 6. 如何判断结果

### 情况 A：hybrid 后出现 20000

如果报告里出现：

```text
211.155.236.226:20000
或
211.155.236.227:20000
```

说明主线基本成立：

```text
21002 是前置网关
20000 是后续业务服候选
```

下一步：

```text
开始研究 20000 首包和回包
做 20000 relay
但仍然不要同时改多个变量
```

### 情况 B：hybrid 后没有 20000，但 relay21002 有数据

如果：

```text
logs/relay21002_streams.csv
```

里有：

```text
C2S 103B
S2C 33B 或 38B
skymp
android
IMEI
IMSI
```

但客户端没有去 20000。

说明：

```text
21002 relay/认证还没真正让客户端通过
```

下一步：

```text
分析 21002 的真实服务端响应
判断 33B/38B 是否含 session seed
对比客户端后续大包是否依赖服务端响应
```

### 情况 C：baseline 只有 21003，没有 21002

说明用户当前操作流程仍然进入旧 21003 链路。

下一步：

```text
继续抓更长时间
确认是否不同入口/不同缓存状态下才会触发 21002
不要急着 patch 文件
```

### 情况 D：没有任何目标端口

说明抓包不对。

排查：

```text
设备是不是 emulator-5554
tcpdump 是否真的运行
用户是否在抓包窗口运行期间完成了点击操作
过滤条件是否是 port 21002 or port 21003 or port 20000
是否有旧 DNAT/旧 relay 干扰
```

---

## 7. 当前关键端口和 IP

```text
111.1.17.146:21003
  旧平台鉴权/ACK 链路

111.1.17.148:21002
  新发现的平台登录/网关候选

211.155.236.226:20000
211.155.236.227:20000
  业务服/游戏服候选
```

模拟器常见信息：

```text
设备：emulator-5554
模拟器内 IP：172.16.1.15 左右
Host 网关常见：172.16.1.2
```

但不要写死 Host 网关，应该从：

```bat
adb shell ip route
```

自动解析：

```text
default via 172.16.1.2
```

---

## 8. 已知明文登录信息

在 103B 登录包中已经多次看到：

```text
skymp
android
869169020812718
460006887846701
```

含义：

```text
平台：skymp/android
IMEI：869169020812718
IMSI：460006887846701
```

这些关键词用于判断是否抓到了真正的 MRP 平台登录包。

---

## 9. OpenClaw 不要犯的老错误

### 错误 1：把 dload.mrp 改成 jjfb.mrp

不行。

原因：

```text
jjfb.mrp 不能单独启动
必须由 gwy/gamelist 带参数和上下文启动
```

### 错误 2：整体替换 cfg.bin

不行。

原因：

```text
导致闪退
导致图标缓存消失
导致所有游戏显示未下载
```

### 错误 3：同时劫持 21002 和 20000

不推荐。

当前实验目的就是要看：

```text
只处理 21002 后，客户端是否自然去真实 20000
```

如果提前劫持 20000，会把变量搞混。

### 错误 4：复杂中文 bat 菜单

之前已经因为 CMD 编码和字符问题连续报错。

现在要求：

```text
bat 只做 ASCII 启动器
复杂逻辑用 Python
```

---

## 10. 下一步最重要的产物

OpenClaw 需要把这些发回：

```text
captures/baseline_ports.pcap
captures/hybrid_21002relay.pcap

reports/baseline_ports_report.md
reports/baseline_ports_report_timeline.html

reports/hybrid_21002relay_report.md
reports/hybrid_21002relay_report_timeline.html

logs/relay21002.log
logs/relay21002_streams.csv
```

不要只发截图。

---

## 11. 给 OpenClaw 的一句话任务

```text
不要再改文件。使用 v4 Python-first 工具包，先跑 baseline，再跑只劫持 21002 的 hybrid，观察客户端是否进入 20000。如果 20000 出现，下一步研究 20000；如果没有，分析 relay21002 的真实认证和 session。
```
