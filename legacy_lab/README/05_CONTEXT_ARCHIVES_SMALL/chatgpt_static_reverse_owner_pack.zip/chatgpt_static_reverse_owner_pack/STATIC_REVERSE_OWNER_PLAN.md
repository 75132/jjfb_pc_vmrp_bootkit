# 静态逆向由 ChatGPT 负责：OpenClaw 只负责抓包/跑实验

## 0. 分工结论

从现在开始：

```text
ChatGPT：负责 MRP/EXT/cfg 静态解析、反汇编/XREF、判断下一轮 mock 方向
OpenClaw：只负责按指令运行 mock、抓包、保存日志、做目录快照
```

OpenClaw 不再负责：
- 猜协议语义
- 修改路线
- 判断 25B/48B 是什么
- 泛泛反编译全部 MRP
- 改 cfg/gamelist
- 做大文件列表盲猜

---

## 1. 静态逆向现阶段能做到什么

MRP 不是不能解析，而是不能像 Python/JS 那样直接还原源码。

当前可做：

```text
1. 拆 MRP 容器
2. 解出 ext / cfg / 资源
3. 提取 UTF-16BE / ASCII 字符串
4. 找字符串池和字符串索引表
5. 对 ext 做 ARM/Thumb 反汇编
6. 围绕字符串 XREF / mr_send / mr_recv / runapp 做局部逆向
7. 生成“状态机推断”，指导 OpenClaw 下一轮抓包
```

暂时不能一键得到：
- 完整 C 源码
- 变量名
- 25B 正确完整回复
- ca7245 编码算法

但这已经足够把问题从“盲猜包”推进到“定位更新状态机”。

---

## 2. 已经确认的静态事实

### 2.1 强制更新弹窗在 gamelist.ext

`gwy/gamelist.mrp -> gamelist.ext` 内存在：

```text
软件需要联网检查更新，是否立刻更新？
检测到新版本，按确定键更新。
检测到公共模块有新版本，按确定键更新。
版本更新完毕，按确定键进入。
文件更新成功。
文件更新失败，请重试。
检查平台更新
更新配置文件
检查应用更新
正在加载应用
```

说明当前门槛是 `gwy/gamelist` 公共启动前更新检查，不是机甲风暴游戏内逻辑。

### 2.2 cfg.bin 能解析出机甲风暴条目

当前已知：

```text
index = 36
title = 机甲风暴(火爆公测)
icon = ng_jjfb.gif
target = gwy/jjfb.mrp
```

说明本地目标是存在的，卡点在启动前更新检查，不是 target 缺失。

### 2.3 vdload.ext 是下载/更新链

`gwy/vdload.mrp -> vdload.ext` 内存在：

```text
spd.skymobiapp.com:6009
/simpleDownload
/continueDownload
/dl_confirm
POST %s HTTP/1.1
Content-Type:application/x-tar
```

说明更新流程可能不只是 21002/20000 二进制协议，也可能接到 vdload 的下载/确认状态机。

### 2.4 gbrwcore.ext 有最终启动接口

`gwy/gbrwcore.mrp -> gbrwcore.ext` 内存在：

```text
startGame
runapp
download
isFileOnServerNewer
getFileVersion
getClientInfo
```

真正成功链更像：

```text
gamelist 更新检查
→ vdload/resmng 处理更新状态
→ gbrwcore startGame/runapp
→ 启动本地 target MRP
```

---

## 3. 动态抓包现阶段结论

OpenClaw 当前已经把动态流程推进到：

```text
21002 103B → 26B

20000 103B → 34B
20000 270/430/426/529B → 8B
20000 27B → 8B
20000 27B → 50B version_ok
20000 25B → 50B no_update
然后 25B 停发，但 30 秒超时重连
UI 无变化
gwy 文件无变化
```

25G-25L 已证明：

```text
1d31 是客户端当前认可字段
1d32 会触发持续重试，淘汰
no_update + 00 / 0000 / 00000000 没有推进
50B no_update 能让 25B 停发，但没有完成更新事务
```

因此当前不是“25B 完全不认”，而是：

```text
25B 的第一段回复被接受；
但服务端还缺少事务结束、后续块、或写状态触发条件。
```

---

## 4. ChatGPT 接下来负责的静态逆向任务

### P0：gamelist.ext 状态机

目标字符串：

```text
软件需要联网检查更新
是否立刻更新
检查平台更新
更新配置文件
检查应用更新
正在加载应用
版本更新完毕
文件更新成功
文件更新失败
文件不存在
```

我要追的是：

```text
这些字符串由哪些代码块调用？
点击条目后走哪个状态？
“版本更新完毕 / 文件更新成功”后是否调用 runapp/startGame？
是否写 cfg/cache？
```

### P1：vdload.ext 更新事务

目标字符串：

```text
/simpleDownload
/continueDownload
/dl_confirm
Content-Type:application/x-tar
spd.skymobiapp.com:6009
```

我要追的是：

```text
无更新/空文件列表是否有分支？
下载完成确认如何表示？
是否有文件数/版本号/校验字段？
```

### P2：gbrwcore.ext 启动入口

目标字符串：

```text
startGame
runapp
isFileOnServerNewer
getFileVersion
download
```

我要追的是：

```text
runapp/startGame 前需要哪些状态？
getFileVersion 失败/成功如何分支？
isFileOnServerNewer 的返回值如何影响启动？
```

### P3：cfg.bin/live cache 对比

我要结合 OpenClaw 快照判断：

```text
mock 到哪个阶段会写文件？
哪个文件代表“已更新/可启动”？
cfg.bin 哪些字段变化？
```

---

## 5. OpenClaw 只需要做什么

OpenClaw 只做采集，按固定格式回传。

### 5.1 每轮必须回传

```text
logs/*.log
logs/*.jsonl
captures/*.bin
pre_snapshot.csv
post_snapshot.csv
diff_snapshot.csv
UI 状态文字记录
```

### 5.2 JSONL 必须包含

```json
{
  "session": 1,
  "port": 20000,
  "recv_len": 25,
  "recv_class": "UNKNOWN_25B",
  "recv_hex": "...",
  "resp_hex_list": ["..."],
  "resp_total_hex": "...",
  "close_mode": "hold/close/half-close",
  "ui_note": "...",
  "clicked_item": "机甲风暴(火爆公测)"
}
```

### 5.3 快照必须覆盖

```text
/sdcard/mythroad/240x320/gwy/
以及 OpenClaw 已找到的 mrpstore/.../mythroad/gwy/
```

字段：

```text
relative_path
size
mtime
md5
phase: pre/post
mode
```

---

## 6. OpenClaw 禁止做的事

```text
不要改 cfg.bin
不要改 gamelist.mrp
不要直接启动 jjfb.mrp
不要造大文件列表
不要重新猜 21002
不要把 9804 解释成模块48
不要把 25B 叫 game_start
不要把 48B 当主线
不要只发截图
```

---

## 7. 下一轮动态实验仍然按 25M-25S

动态线继续跑：

```text
25M：25B → no_update 50B，延迟 close
25N：25B → no_update 50B，half-close
25O：25B → no_update 50B，300ms 后独立 ACK_8B
25P：25B → no_update 50B，ACK_8B 后 half-close
25Q：25B → no_update 50B，300ms 后第二个 no_update 50B
25R：25B → no_update 50B，300ms 后 dual ACK 16B
25S：25B → no_update 50B，300ms 后独立空块 00/0000/00000000
```

这些由 OpenClaw 跑。ChatGPT 负责根据结果决定下一步。

---

## 8. 当前一句话方向

```text
OpenClaw 不再分析。它只采集 25M-25S 的网络 hex、UI、gwy 文件快照。
ChatGPT 负责静态逆向 gamelist/vdload/gbrwcore，找“更新成功→写状态→runapp”的真实状态机。
```
