$ROOT = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ROOT
python .\scripts\source_build_loader_v27.py restore
