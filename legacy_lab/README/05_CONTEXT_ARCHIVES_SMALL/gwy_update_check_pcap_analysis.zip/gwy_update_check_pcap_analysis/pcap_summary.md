# 冒泡/MRP 抓包解析报告

- 输入文件：`/mnt/data/openclaw_maopao_toolkit/captures/gwy_update_check.pcap`
- PCAP linktype：`113`
- 数据包数量：`143`
- DNS 记录数：`10`
- HTTP 事件数：`6`
- TCP/UDP 连接数：`14`
- 关键词命中数：`22`
- 可疑端点数：`9`

## 快速判断

- wap.skmeg.com：❌ 未见
- /dsmWap/：❌ 未见
- error.jsp：❌ 未见
- update/version/upgrade/check：✅ 有
- bcs.duapp.com/myplugins/dyd.apk：✅ 有
- 111.1.17.146:21003：✅ 有
- skymp.android：❌ 未见

## 高价值 HTTP 事件

- packet 11 `request` `oc.umeng.com/check_config_update` status=`` location=``
- packet 17 `request` `bcs.duapp.com/myplugins/dyd.apk` status=`` location=``
- packet 19 `response` `` status=`200` location=``
- packet 24 `response` `` status=`403` location=``
- packet 31 `request` `alog.umeng.com/app_logs` status=`` location=``
- packet 35 `response` `` status=`200` location=``

## 高价值端点

- [high] dns: `bcs.duapp.com` — DNS query in packet 3
- [high] dns: `bcs.duapp.com` — DNS query in packet 6
- [high] http: `oc.umeng.com/check_config_update status= loc=` — HTTP event in packet 11: POST /check_config_update HTTP/1.1
- [high] http: `bcs.duapp.com/myplugins/dyd.apk status= loc=` — HTTP event in packet 17: GET /myplugins/dyd.apk HTTP/1.1
- [high] tcp: `111.1.17.146:21003 <-> 172.16.1.15:60806` — Known high-value binary platform endpoint candidate
- [high] tcp: `111.1.17.146:21003 <-> 172.16.1.15:60808` — Known high-value binary platform endpoint candidate
- [high] tcp: `111.1.17.146:21003 <-> 172.16.1.15:60810` — Known high-value binary platform endpoint candidate
- [high] tcp: `111.1.17.146:21003 <-> 172.16.1.15:60802` — Known high-value binary platform endpoint candidate
- [high] tcp: `111.1.17.146:21003 <-> 172.16.1.15:60812` — Known high-value binary platform endpoint candidate

## 下一步建议

- 已看到 `111.1.17.146:21003`：优先保留 `stream_21003_hex.txt` 和 `stream_21003_strings.txt`，这是冒泡/斯凯二进制平台接口候选。
- 已看到 `bcs.duapp.com/myplugins/dyd.apk`：如果客户端提示更新/插件缺失，优先拦截这个 APK 下载请求。
- 本次未看到 `wap.skmeg.com/error.jsp`：重新抓包时请从启动前开始，直到跳浏览器 error.jsp 后再等 10 秒。

相关 CSV 已输出到 `reports/`。