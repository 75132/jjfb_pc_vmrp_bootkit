# OpenClaw 下一步任务：定位 dyd.apk 和 21003 卡点

请只在本地执行，不要扫描公网，不要安装 Npcap，不要修改系统网络驱动。

## 已知抓包结论

用户点“软件需要联网检查更新 → 确定”之后，pcap 中出现：

1. `GET http://bcs.duapp.com/myplugins/dyd.apk`，返回 `403 Forbidden`。
2. 多次连接 `111.1.17.146:21003`，客户端首包含 `skymp/android/IMEI/IMSI`，服务端有回包。
3. 未出现 `wap.skmeg.com/dsmWap/error.jsp`。
4. 未出现 `applist2.sky-mobi.net` 或 `opensdk.51mrp.com`。

## 任务

1. 在用户提供的所有目录/压缩包中搜索：
   - `dyd.apk`
   - `myplugins`
   - `bcs.duapp.com`
   - `111.1.17.146`
   - `21003`
   - `skymp.android`
2. 如果找到 `dyd.apk`，复制到 mock_server 目录，准备作为 HTTP mock 返回文件。
3. 如果找不到 `dyd.apk`，启动 HTTP mock server，先让 `/myplugins/dyd.apk` 返回 200 + 占位内容，观察客户端是否只看状态码。
4. 同时保留 tcpdump，观察 mock 后是否继续进入游戏，还是继续走 21003。
5. 如果仍走 21003 卡住，把 `stream_21003_hex.txt` 中的首包和服务端 33 字节回包单独整理，准备做协议分析。

## 预期输出

- `dyd.apk` 是否存在；
- `dyd.apk 403` 是否是当前更新卡点；
- mock `/myplugins/dyd.apk` 后是否能继续；
- 21003 是否还会重复连接；
- 下一步是 HTTP mock 还是 patch MRP 更新逻辑。
