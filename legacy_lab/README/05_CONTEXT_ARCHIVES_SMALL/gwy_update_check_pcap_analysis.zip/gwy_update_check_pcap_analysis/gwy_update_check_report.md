# gwy_update_check.pcap 专项解析报告

## 结论

这份包抓得很准：它基本就是你点“确定/正在连接服务器”之后的联网行为。

关键判断：

```text
没有抓到 wap.skmeg.com
没有抓到 /dsmWap/error.jsp
没有抓到 applist2.sky-mobi.net
没有抓到 opensdk.51mrp.com
没有抓到 mrc_freesky.51mrp.com
```

但抓到了两个非常关键的动作：

```text
1. HTTP 请求 bcs.duapp.com/myplugins/dyd.apk，返回 403 Forbidden
2. 多次连接 111.1.17.146:21003，并且服务端确实有回包
```

所以这次能确认：你点“更新/连接服务器”后，主要不是在访问 `wap.skmeg.com/error.jsp`，而是在走：

```text
冒泡社区 Android 插件/组件下载：bcs.duapp.com/myplugins/dyd.apk
斯凯/冒泡二进制平台协议：111.1.17.146:21003
```

## HTTP 证据

抓到请求：

```http
GET /myplugins/dyd.apk HTTP/1.1
Host: bcs.duapp.com
```

服务端返回：

```http
HTTP/1.1 403 Forbidden
Content-Type: application/json; charset=utf-8

{"code":"AccessDenied","message":"Access Denied."}
```

这说明它在尝试下载一个叫 `dyd.apk` 的插件/组件，但是旧资源已经不可访问。

这个很像你界面里“软件需要联网检查更新”的直接原因之一。

## 21003 二进制接口证据

抓到多次 TCP 连接：

```text
172.16.1.15:60802 -> 111.1.17.146:21003
172.16.1.15:60806 -> 111.1.17.146:21003
172.16.1.15:60808 -> 111.1.17.146:21003
172.16.1.15:60810 -> 111.1.17.146:21003
172.16.1.15:60812 -> 111.1.17.146:21003
```

客户端首包里有明文：

```text
skymp
android
869169020812718
460006887846701
```

这个说明它不是普通 HTTP，而是一个旧冒泡/斯凯平台的自定义 TCP 协议。

更重要的是：`111.1.17.146:21003` 不是完全无响应。它有回包，比如 33 字节、19 字节、23 字节、38 字节等。

所以目前不能简单说“服务器彻底连不上”。更准确是：

```text
旧平台二进制端口还能连上并回包；
但客户端仍然认为更新/初始化没完成，可能是旧协议回包不满足当前壳的要求，或者 bcs.duapp.com 的 dyd.apk 下载失败导致流程卡住。
```

## 当前优先级

### 第一优先级：bcs.duapp.com/myplugins/dyd.apk

这是明确的 HTTP 403。

下一步可以尝试本地 mock：

```text
Host: bcs.duapp.com
Path: /myplugins/dyd.apk
```

但要注意：如果客户端真的要安装 APK，随便返回空文件可能不行，需要找到原始 `dyd.apk` 或判断客户端是否只看 HTTP 状态码。

### 第二优先级：111.1.17.146:21003

这是自定义二进制协议，不能用普通 HTTP mock。

下一步要继续分析：

```text
首包结构
服务端 33 字节回包含义
后续 430 字节加密/混淆 payload 的作用
客户端为什么重复连接 5 次
```

### 低优先级：wap.skmeg.com/error.jsp

本次完全没有抓到，继续降级。它大概率不是这一步的真实更新接口。

## 建议下一步

1. 先不要再找 `wap.skmeg.com`。
2. 先处理 `dyd.apk 403`。
3. 在上传包里搜索有没有 `dyd.apk` 或类似插件 APK。
4. 如果没有，就抓“取消更新”和“确定更新”两个包，对比是否只有 `dyd.apk` 不同。
5. 如果 mock 掉 `dyd.apk` 后仍卡住，再专门分析 `111.1.17.146:21003`。

## 本包文件

```text
pcap_summary.md
dns_queries.csv
http_requests.csv
tcp_connections.csv
keyword_hits.csv
suspicious_endpoints.csv
binary_payload_strings.csv
stream_21003_hex.txt
stream_21003_strings.txt
gwy_update_check_report.md
```
