@echo off
setlocal
cd /d "%~dp0"
adb devices
echo.

echo [INFO] rollback cfg.bin
adb shell "if [ -f /sdcard/mythroad/gwy/_patch_backup/cfg.bin.bak ]; then cp /sdcard/mythroad/gwy/_patch_backup/cfg.bin.bak /sdcard/mythroad/gwy/cfg.bin; fi"
adb shell "if [ -f /sdcard/mythroad/240x320/gwy/_patch_backup/cfg.bin.bak ]; then cp /sdcard/mythroad/240x320/gwy/_patch_backup/cfg.bin.bak /sdcard/mythroad/240x320/gwy/cfg.bin; fi"
echo [DONE] rollback cfg.bin
pause
