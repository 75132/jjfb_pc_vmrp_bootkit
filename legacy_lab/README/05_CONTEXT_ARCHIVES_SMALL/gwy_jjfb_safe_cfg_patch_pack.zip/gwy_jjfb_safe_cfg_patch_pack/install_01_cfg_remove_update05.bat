@echo off
setlocal
cd /d "%~dp0"
adb devices
echo.

echo [INFO] backup original cfg.bin
adb shell "mkdir -p /sdcard/mythroad/gwy/_patch_backup"
adb shell "mkdir -p /sdcard/mythroad/240x320/gwy/_patch_backup"
adb shell "if [ -f /sdcard/mythroad/gwy/cfg.bin ]; then cp /sdcard/mythroad/gwy/cfg.bin /sdcard/mythroad/gwy/_patch_backup/cfg.bin.bak; fi"
adb shell "if [ -f /sdcard/mythroad/240x320/gwy/cfg.bin ]; then cp /sdcard/mythroad/240x320/gwy/cfg.bin /sdcard/mythroad/240x320/gwy/_patch_backup/cfg.bin.bak; fi"
echo [INFO] ensure sdk_key.dat
adb shell "printf 123456789012345 > /sdcard/mythroad/sdk_key.dat"
adb shell "mkdir -p /sdcard/mythroad/gwy"
adb shell "printf 123456789012345 > /sdcard/mythroad/gwy/sdk_key.dat"
adb shell "if [ -d /sdcard/mythroad/240x320 ]; then printf 123456789012345 > /sdcard/mythroad/240x320/sdk_key.dat; fi"
adb shell "if [ -d /sdcard/mythroad/240x320/gwy ]; then printf 123456789012345 > /sdcard/mythroad/240x320/gwy/sdk_key.dat; fi"

echo [INFO] push cfg variant: 01_cfg_remove_update05
adb push "patches\01_cfg_remove_update05\gwy\cfg.bin" /sdcard/mythroad/gwy/cfg.bin
adb shell "if [ -d /sdcard/mythroad/240x320/gwy ]; then cp /sdcard/mythroad/gwy/cfg.bin /sdcard/mythroad/240x320/gwy/cfg.bin; fi"
echo.
echo [DONE] installed 01_cfg_remove_update05
echo �����´� gwy.mrp��������ר��������׷籩���ԡ�
pause
