# gwy_jjfb_safe_cfg_patch_pack

这个包是修正版：**不再改 gamelist.mrp，不再把 dload.mrp 替换成 jjfb.mrp**。

原因：
你说得对，`jjfb.mrp` 不能单独启动。正确目标应该是：

```text
仍然从 gwy.mrp 进入网游专区
仍然由 gamelist 正常读取 cfg.bin
仍然保留原来的 gwy/gamelist 启动上下文和参数
只改 cfg.bin 里“机甲风暴”条目的联网/更新动作标志
```

## jjfb 条目定位

```text
gwy/jjfb.mrp path offset = 10943
record_start             = 10808
flag byte offset         = 10942
action list offset       = 10983
old action bytes         = 0305ffffffffffffffffffffffffffff
```

## 补丁说明

### 01_cfg_remove_update05

把机甲风暴条目的动作：

```text
03 05 FF FF
```

改成：

```text
03 FF FF FF
```

含义推测：保留“进入/启动”动作 `03`，去掉疑似“检查更新/下载”动作 `05`。

### 02_cfg_action_0803

把机甲风暴动作改成：

```text
08 03 FF FF
```

这是参考其它能正常显示的条目格式，用于实验。

### 03_cfg_flag0_remove_update05

在 01 基础上，把 jjfb 条目前一个疑似 flag/nextid 字节从 `01` 改成 `00`，更激进，最后再试。

## 推荐测试顺序

```text
1. rollback_cfg.bat
2. install_01_cfg_remove_update05.bat
3. 重新打开 gwy.mrp，网游专区点击机甲风暴

无变化再：
1. rollback_cfg.bat
2. install_02_cfg_action_0803.bat

再无变化：
1. rollback_cfg.bat
2. install_03_cfg_flag0_remove_update05.bat
```

## 判断

好结果：

```text
不再弹“软件需要联网检查更新”
或者不再走 21003
或者错误变成 sdk_key/路径/参数类
```

坏结果：

```text
完全一样继续 21003 长轮询
```
