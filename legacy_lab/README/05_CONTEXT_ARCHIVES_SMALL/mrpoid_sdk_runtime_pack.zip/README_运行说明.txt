MRP/Mrpoid 运行测试包（用于解决“缺少 SDK / cfunction.ext”）

使用方法：
1. 在安卓模拟器/手机存储根目录创建 mythroad 文件夹：/sdcard/mythroad/
   如果你的 Mrpoid 使用 MythRoad 或 mrp 目录，也可以复制到对应目录。
2. 把 copy_to_sdcard_mythroad 目录里的内容整体复制到 /sdcard/mythroad/。
3. 在 Mrpoid2018 中选择 /sdcard/mythroad/jjfbol.mrp 启动。
4. 如果仍提示缺少 SDK，把 cfunction.ext 再复制一份到：
   /sdcard/mythroad/cfunction.ext
   /sdcard/mythroad/jjfbol/cfunction.ext
   /sdcard/mythroad/system/cfunction.ext（手动新建 system 文件夹）

说明：
- jjfbol.mrp 是主程序。
- jjfbol/ 目录是资源包，里面是多个子 mrp。
- cfunction.ext 是这个游戏依赖的公共 SDK/运行库封装，原全量解包里没有直接带在主目录，因此 Mrpoid 可能报“缺少 SDK”。
- 这只解决运行库缺失，不等于服务器恢复；联网功能后续仍需 hook/capture。
