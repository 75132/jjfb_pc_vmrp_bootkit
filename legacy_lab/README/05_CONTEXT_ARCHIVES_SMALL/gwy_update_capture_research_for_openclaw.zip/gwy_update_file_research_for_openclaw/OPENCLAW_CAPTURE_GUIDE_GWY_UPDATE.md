# 给 OpenClaw 的文件研究结论：gwy 强制更新门槛抓包指南

## 1. 当前真正要抓的不是游戏服

现在卡点是：

```text
gwy.mrp → 网游专区 → 点任意网游 → 软件需要联网检查更新，是否立刻更新？
```

这不是 `jjfb` 游戏内登录问题，而是 **gwy/gamelist 公共启动前更新检查**。

从文件静态扫描看，强制更新弹窗字符串直接出现在：

```text
gwy/gamelist.mrp → gamelist.ext
```

证据包括：

```text
软件需要联网检查更新
是否立刻更新
检测到新版本 按确定键更新
检测到公共模块有新版本 按确定键更新
您还未下载 是否立即下载
版本更新完毕 按确定键进入
正在更新 请稍候
文件更新成功
文件更新失败 请重试
```

这说明：**弹窗本身大概率由本地 gamelist/cfg 状态判断产生，不是服务器先发来的。**

---

## 2. OpenClaw 当前不要做什么

```text
不要研究 jjfb 游戏内服务器列表
不要研究角色列表
不要把 20000 当主线
不要把 dload.mrp 替换成 jjfb.mrp
不要直接启动 jjfb.mrp
不要整文件替换 cfg.bin
不要只抓 21002/21003
```

当前主线是：

```text
研究 gwy/gamelist/dload/vdload 如何判断“需要更新”
以及点确定后如何让它认为“更新完成/无需更新/可以启动本地 MRP”
```

---

## 3. 文件里最有价值的模块

详见 `module_evidence_for_capture.csv`。简表：

| 优先级 | 模块 | 抓包价值 |
|---|---|---|
| P0 | `gwy/gamelist.mrp -> gamelist.ext` | 弹窗、cfg.bin、启动参数、HTTP 平台入口都在这里 |
| P0 | `gwy/vdload.mrp -> vdload.ext` | 明确出现 `spd.skymobiapp.com:6009`、`/simpleDownload`、`/continueDownload` |
| P0 | `gwy/cfg.bin` | 条目状态/本地路径/游戏列表，`gwy/jjfb.mrp` 位于 offset 10943 |
| P1 | `gwy.mrp -> cfunction.ext` | 主壳加载 reglogin/dload/gamelist/resmng/vdload/svrctrl；含 HTTP 模板 |
| P1 | `gwy/reglogin.mrp -> reglogin.ext` | userpassport、userinfo、autologin、napptype 参数 |
| P1 | `gwy/resmng.mrp -> resmng.ext` | 资源更新成功/失败提示 |
| P2 | `gwy/dload.mrp -> download.ext` | 更新/下载入口，但明文字符串少 |
| P2 | `gwy/svrctrl.mrp -> svrctrl.ext` | 服务器控制候选，可能参与 21002/21003 二进制链路 |

---

## 4. 必须修改抓包过滤范围

之前只盯：

```text
21002 / 21003 / 20000
```

对当前“强制更新门槛”不够。

根据文件证据，至少要抓：

```text
udp port 53
or tcp port 80
or tcp port 6009
or tcp port 21002
or tcp port 21003
or tcp port 20000
```

原因：

```text
53：DNS，确认域名解析
80：gamelist/reglogin/cfunction HTTP 平台入口
6009：vdload 明确下载服务器 spd.skymobiapp.com:6009
21002/21003：平台二进制登录/ACK 候选
20000：暂时低优先级，只作为观察
```

OpenClaw 抓包报告必须解析这些字段：

```text
DNS query
HTTP Host
HTTP path
HTTP method
TCP endpoint
TCP payload length
payload ASCII/UTF-16BE 可打印字符串
```

---

## 5. 三个必须做的抓包实验

### 实验 A：点击游戏但不点“确定”

目的：判断弹窗是否完全由本地逻辑产生。

```text
开始抓包
进入 gwy.mrp → 网游专区
点击机甲风暴
出现“软件需要联网检查更新，是否立刻更新？”
不要点确定
等待 10 秒
停止抓包
```

判断：

```text
如果没有任何 DNS/HTTP/21002/21003 流量：
弹窗就是 gamelist/cfg 本地分支。
网络 mock 只能处理“点确定之后”，不能阻止它弹窗。
```

---

### 实验 B：点击“确定”后抓包

目的：确认点确定后进入哪个更新链路。

```text
开始抓包
点击机甲风暴
弹窗后点确定
等待 60-120 秒
停止抓包
```

重点看：

```text
是否访问 mrc_freesky.51mrp.com
是否访问 i.51mrp.com/commonprofile/userpassport.ftl
是否访问 spd.skymobiapp.com:6009
是否出现 /simpleDownload /continueDownload /dl_confirm
是否出现 21002/21003 的 103B 登录包
是否只出现 bcs.duapp.com/dyd.apk（低优先级，已排除）
```

---

### 实验 C：换 2-3 个网游对比

目的：确认强制更新是否公共逻辑。

至少对比：

```text
机甲风暴
另一个网游条目
再另一个网游条目
```

判断：

```text
如果不同游戏的点确定后流量结构一致：
这是 gwy 公共更新模块。

如果只有字段/长度略有变化：
记录变化字段，可能对应 nextid/ncode/narg/nmrpname。
```

---

## 6. 抓包结果对下一步的含义

### 情况 1：不点确定时无网络

结论：弹窗是本地 gamelist/cfg 逻辑。

下一步：mock 只能让点确定后“更新完成”，或者后续考虑极小 patch gamelist/cfg 状态位。

### 情况 2：点确定后出现 `spd.skymobiapp.com:6009`

结论：进入 `vdload` 下载/版本链。

下一步：本地 mock 应优先模拟：

```text
/dl_confirm
/simpleDownload
/continueDownload
```

而不是模拟 20000 游戏服。

### 情况 3：点确定后出现 `mrc_freesky.51mrp.com` 或 `i.51mrp.com`

结论：进入 `gamelist/reglogin/cfunction` 的 HTTP 平台链。

下一步：mock HTTP 200，重点看 body 格式和是否需要 `napptype/gwyblink`。

### 情况 4：点确定后只出现 21002/21003 二进制

结论：进入平台二进制登录/更新链。

下一步：继续用 103B/270B/430B/27B/48B 状态机，但目标改成“更新完成/启动本地 MRP”，不是“进游戏服”。

### 情况 5：点确定后直接访问 bcs.duapp.com/dyd.apk

结论：低优先级。之前 mock dyd.apk 200 后没有推进，不要再把它当主线。

---

## 7. 给 OpenClaw 的一句话

```text
现在不要再研究 jjfb 游戏内协议。文件证据显示强制更新弹窗在 gwy/gamelist.ext，本阶段要抓的是 gwy 公共更新检查：DNS、HTTP 80、spd.skymobiapp.com:6009、mrc_freesky/i.51mrp，以及 21002/21003。先做“不点确定”和“点确定后”两段抓包，再按 Host/path/端口判断该 mock dload/vdload/reglogin 哪一层。
```
