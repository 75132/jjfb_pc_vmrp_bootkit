# JJFB Direct Bootkit — 机甲风暴单游戏启动测试包

## 你要的目标

这包不是继续走 `gwy/gamelist` 大厅，而是尝试：

```text
直接用开源 MRP 模拟器 / 现有 Mrpoid 内核
加载 /sdcard/mythroad/gwy/jjfb.mrp
注入 gwyblink 启动参数
准备 sdk_key.dat / 文件树 / 本地网络 mock
自动抓 logcat / tcp / 目录快照
```

## 为什么选这个路线

公开项目里有两个可用方向：

- Android 端 Mrpoid/mrpoid2018：README 说明它是 Android 上的 MRP 模拟器，且 1.4.x.x 变更里有“增加外部调用功能”和“解决冒泡网游不能进”等记录。
- PC 端 vmrp：README 说明它是 MRP 模拟器，Windows 版本实现了联网功能，可以运行支持网络通信的 MRP。

本包优先使用 Android/Mrpoid/Mrpoid-fork，因为你现在已经在 LDPlayer + ADB 环境里抓包，路径和 root/tcpdump 都已经验证过。

## 重要限制

我现在不能把你的 `jjfb.mrp/gwy/cfg.bin/jjfbol` 原始游戏文件打进包里，因为当前运行环境里没有这些原始文件。你只需要把你已有的 `mythroad` 文件树放进：

```text
game_files/mythroad/
```

最终应该长这样：

```text
game_files/mythroad/
  gwy.mrp                         可选
  sdk_key.dat                     可选，没有脚本会生成
  gwy/
    cfg.bin
    jjfb.mrp
    jjfbol/
    gbrwcore.mrp                  建议保留
    gbrwshell.mrp                 建议保留
    font.mrp                      建议保留
    resmng.mrp                    建议保留
    vdload.mrp                    建议保留
    dload.mrp                     建议保留
    reglogin.mrp                  建议保留
```

模拟器 APK 也不强行塞包。你有 Mrpoid/Mythras APK 的话放到：

```text
bin/mrpoid.apk
```

没有也可以先用你模拟器里已经安装的 MRP 模拟器。

## 一键流程

Windows 桌面解压后，在包根目录打开 PowerShell：

```powershell
.\run_full_test.ps1
```

这个脚本会做：

```text
1. 检查 adb
2. 检测或安装 bin/mrpoid.apk
3. 推送 game_files/mythroad 到 /sdcard/mythroad
4. 写 sdk_key.dat
5. 启动本地 mock server：21002 / 21003 / 20000 / 6009
6. 尝试 iptables DNAT 到本机 mock
7. 尝试多种 Direct Launch Intent
8. 抓 logcat
9. 做 gwy 目录快照
10. 打包 feedback zip
```

## 最终把什么发回来

跑完后发：

```text
logs/feedback_*.zip
```

里面包含：

```text
logcat
mock jsonl
launch attempts
gwy snapshot
device/package probe
```

## 判断是否成功

成功不一定是进入角色界面。只要出现下面任意一种，就说明“单游戏启动路线成立”：

```text
机甲风暴 loading
正在登录
正在获取角色资料
连接超时
开始连接 20000
mock_server 收到 jjfb 新包
logcat 出现 jjfb/robotol/mainmenumodule 相关日志
```

如果还是：

```text
can't find sdk key
找不到 mrc_loader.ext
直接闪退
只打开模拟器文件列表
```

那就是启动上下文还没注入对，继续把 feedback zip 发回来。
