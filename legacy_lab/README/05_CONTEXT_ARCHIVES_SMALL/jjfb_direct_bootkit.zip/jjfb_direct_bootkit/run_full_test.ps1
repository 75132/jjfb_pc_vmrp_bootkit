param(
    [string]$Config = "CONFIG.json"
)

$ErrorActionPreference = "Continue"
$ROOT = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ROOT

New-Item -ItemType Directory -Force -Path logs | Out-Null

Write-Host "== JJFB Direct Bootkit =="

python .\scripts\bootkit.py probe --config $Config
python .\scripts\bootkit.py prepare --config $Config
python .\scripts\bootkit.py install-apk --config $Config
python .\scripts\bootkit.py deploy --config $Config

Write-Host "Starting mock server in a new window..."
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd `"$ROOT`"; python .\mock\jjfb_mock_server.py --config CONFIG.json"

Start-Sleep -Seconds 2

python .\scripts\bootkit.py redirect --config $Config
python .\scripts\bootkit.py snapshot --config $Config --phase pre

Write-Host "Starting direct launch attempts..."
python .\scripts\bootkit.py launch --config $Config

python .\scripts\bootkit.py snapshot --config $Config --phase post
python .\scripts\bootkit.py collect --config $Config

Write-Host ""
Write-Host "Done. Send back the newest logs\feedback_*.zip"
