# 反馈判读

优先看：
1. logs/mock_*.jsonl 是否出现 20000 新包
2. logs/logcat_launch_*.txt 是否有 jjfb / robotol / mrc_loader / sdk_key
3. launch_summary.txt 哪个 intent 成功打开了模拟器或直接加载
4. snapshots 前后文件是否变化

常见结果：
- 只打开模拟器主页：说明外部调用参数不对，需要看 manifest/activity
- can't find sdk key：说明 sdk_key.dat 路径或工作目录不对
- 连接 20000：说明已经越过单游戏启动门槛，后面回到网络 mock
- 闪退：看 logcat 里的 native crash / missing ext
