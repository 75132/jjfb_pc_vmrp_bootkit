#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
JJFB / GYW local mock server.
For local testing only. Logs every packet to logs/mock_*.jsonl.
"""
import socket, threading, json, time, argparse, os, sys
from pathlib import Path
from datetime import datetime
import binascii

ROOT = Path(__file__).resolve().parents[1]
LOGDIR = ROOT / "logs"
LOGDIR.mkdir(exist_ok=True)

ACK_8B = bytes.fromhex("9800010000130100")
ACK_8B_ALT = bytes.fromhex("9800010000170100")
AUTH_18B = bytes.fromhex("980001000021010000010001980400001d31")
AUTH_ALT = bytes.fromhex("980001000021010000010001980400001d32")
NO_UPDATE_50B = bytes.fromhex(
    "980001000021010000010001980400001d31"
    "9800010000130100"
    "9800010000170100"
    "9800010000130100"
    "9800010000130100"
)

def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

def classify(data):
    n = len(data)
    hx = data.hex()
    if n == 103:
        return "LOGIN_103B"
    if n in (270, 426, 430, 529) or b"skymp" in data or b"android" in data:
        return f"DEVICE_OR_COMBINED_{n}B"
    if n == 27:
        return "HEARTBEAT_27B"
    if n == 25:
        return "UNKNOWN_25B"
    if n == 48:
        return "UNKNOWN_48B"
    return f"UNKNOWN_{n}B"

class JsonLogger:
    def __init__(self):
        self.path = LOGDIR / f"mock_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jsonl"
        self.lock = threading.Lock()
    def write(self, obj):
        obj["ts"] = now()
        with self.lock:
            with self.path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(obj, ensure_ascii=False) + "\n")

JLOG = JsonLogger()

def send_and_log(conn, port, peer, session, data, note):
    if not data:
        return
    conn.sendall(data)
    JLOG.write({
        "session": session, "port": port, "peer": str(peer),
        "direction": "send", "len": len(data), "hex": data.hex(), "note": note
    })

def tcp_client(conn, peer, port, mode):
    session = f"{port}-{int(time.time()*1000)%100000}"
    hb_count = 0
    JLOG.write({"session": session, "port": port, "peer": str(peer), "direction":"open", "mode": mode})
    try:
        conn.settimeout(60)
        while True:
            try:
                data = conn.recv(8192)
            except socket.timeout:
                JLOG.write({"session": session, "port": port, "peer": str(peer), "direction":"timeout"})
                break
            if not data:
                JLOG.write({"session": session, "port": port, "peer": str(peer), "direction":"eof"})
                break
            cls = classify(data)
            JLOG.write({"session": session, "port": port, "peer": str(peer), "direction":"recv",
                        "len": len(data), "class": cls, "hex": data.hex()})
            resp = b""
            note = ""

            if port in (21002, 21003):
                if "LOGIN_103B" in cls:
                    resp = AUTH_18B + ACK_8B_ALT
                    note = "platform login 26B"
                else:
                    resp = ACK_8B
                    note = "platform ack"
                send_and_log(conn, port, peer, session, resp, note)
                continue

            if port == 20000:
                if cls == "LOGIN_103B":
                    send_and_log(conn, port, peer, session, AUTH_18B + ACK_8B_ALT + ACK_8B, "20000 login 34B")
                    continue
                if cls.startswith("DEVICE_OR_COMBINED"):
                    # If recv is combined 529B, still give login+device style response.
                    if len(data) >= 500:
                        send_and_log(conn, port, peer, session, AUTH_18B + ACK_8B_ALT + ACK_8B, "combined login part")
                        time.sleep(0.05)
                    send_and_log(conn, port, peer, session, ACK_8B, "device ack")
                    continue
                if cls == "HEARTBEAT_27B":
                    hb_count += 1
                    if hb_count == 1:
                        send_and_log(conn, port, peer, session, ACK_8B, "hb1 ack")
                    else:
                        send_and_log(conn, port, peer, session, NO_UPDATE_50B, "hb2 version_ok/no_update baseline")
                    continue
                if cls == "UNKNOWN_25B":
                    if mode == "baseline":
                        send_and_log(conn, port, peer, session, NO_UPDATE_50B, "25B no_update 50B")
                    elif mode == "module48_u1":
                        send_and_log(conn, port, peer, session, NO_UPDATE_50B, "25B no_update")
                        time.sleep(0.3)
                        # Placeholder probe: type01 + count=1. Full cfg record must be filled from CSV if available.
                        payload = bytes.fromhex("0101")
                        send_and_log(conn, port, peer, session, payload, "type01 count1 placeholder")
                    elif mode == "echo25":
                        send_and_log(conn, port, peer, session, data, "echo 25B")
                    else:
                        send_and_log(conn, port, peer, session, NO_UPDATE_50B, f"25B mode {mode} default no_update")
                    continue

            send_and_log(conn, port, peer, session, ACK_8B, "default ack")
    except Exception as e:
        JLOG.write({"session": session, "port": port, "peer": str(peer), "direction":"error", "error": repr(e)})
    finally:
        try:
            conn.close()
        except Exception:
            pass
        JLOG.write({"session": session, "port": port, "peer": str(peer), "direction":"close"})

def tcp_server(port, mode):
    s = socket.socket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("0.0.0.0", port))
    s.listen(20)
    print(f"[{now()}] TCP listening {port} mode={mode}", flush=True)
    while True:
        c, a = s.accept()
        threading.Thread(target=tcp_client, args=(c,a,port,mode), daemon=True).start()

def http_server_6009():
    s = socket.socket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("0.0.0.0", 6009))
    s.listen(20)
    print(f"[{now()}] HTTP listening 6009", flush=True)
    while True:
        c,a = s.accept()
        try:
            req = c.recv(4096)
            JLOG.write({"session":"http6009", "port":6009, "peer":str(a), "direction":"recv", "len":len(req), "text":req.decode("latin1","replace")})
            body = b""
            resp = b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\nConnection: close\r\n\r\n" + body
            c.sendall(resp)
            JLOG.write({"session":"http6009", "port":6009, "peer":str(a), "direction":"send", "len":len(resp), "text":resp.decode("latin1","replace")})
        except Exception as e:
            JLOG.write({"session":"http6009", "port":6009, "peer":str(a), "direction":"error", "error":repr(e)})
        finally:
            c.close()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="CONFIG.json")
    ap.add_argument("--mode", default=os.environ.get("JJFB_MOCK_MODE","baseline"))
    args = ap.parse_args()
    cfg_path = ROOT / args.config
    cfg = json.loads(cfg_path.read_text(encoding="utf-8")) if cfg_path.exists() else {}
    ports = cfg.get("mock_ports", [21002,21003,20000,6009])
    for p in ports:
        if int(p) == 6009:
            threading.Thread(target=http_server_6009, daemon=True).start()
        else:
            threading.Thread(target=tcp_server, args=(int(p), args.mode), daemon=True).start()
    print("mock jsonl:", JLOG.path, flush=True)
    while True:
        time.sleep(3600)

if __name__ == "__main__":
    main()
