#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse, json, subprocess, sys, os, time, shutil, zipfile, hashlib, re
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).resolve().parents[1]

def load_config(path):
    return json.loads((ROOT / path).read_text(encoding="utf-8"))

def adb_base(cfg):
    serial = cfg.get("adb_serial", "")
    base = ["adb"]
    if serial:
        base += ["-s", serial]
    return base

def run(cmd, timeout=30, check=False, text=True):
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           timeout=timeout, check=check, text=text, encoding="utf-8", errors="replace")
        return p.returncode, p.stdout
    except subprocess.TimeoutExpired as e:
        return 124, (e.stdout or "") + "\n[TIMEOUT]\n"

def adb(cfg, args, timeout=30):
    return run(adb_base(cfg) + args, timeout=timeout)

def log_write(name, content):
    (ROOT / "logs").mkdir(exist_ok=True)
    (ROOT / "logs" / name).write_text(content, encoding="utf-8", errors="replace")

def sha1_file(p):
    h = hashlib.sha1()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(65536), b""):
            h.update(b)
    return h.hexdigest()

def cmd_probe(args):
    cfg = load_config(args.config)
    out = []
    rc, s = run(["adb", "devices"], timeout=15)
    out.append("## adb devices\n" + s)

    rc, s = adb(cfg, ["shell", "getprop", "ro.product.model"], timeout=10)
    out.append("## device model\n" + s)

    rc, s = adb(cfg, ["shell", "pm", "list", "packages"], timeout=20)
    out.append("## packages\n" + s)

    hits = []
    for line in s.splitlines():
        low = line.lower()
        if any(k in low for k in ["mrpoid", "myth", "mrp", "vmrp"]):
            hits.append(line.strip())
    out.append("## candidate packages\n" + "\n".join(hits))

    log_write("probe_packages.txt", "\n\n".join(out))
    print("\n".join(out[-2:]))

def cmd_prepare(args):
    cfg = load_config(args.config)
    src = ROOT / "game_files" / "mythroad"
    if not src.exists():
        raise SystemExit("missing game_files/mythroad")
    # create sdk_key.dat if missing
    for rel in ["sdk_key.dat", "gwy/sdk_key.dat"]:
        p = src / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        if not p.exists():
            p.write_text(cfg.get("sdk_key_content", "123456789012345"), encoding="ascii")
            print("created", p)
    # basic check
    jjfb = src / "gwy" / "jjfb.mrp"
    if not jjfb.exists():
        print("[WARN] game_files/mythroad/gwy/jjfb.mrp not found. Deploy will still run but direct start cannot work.")
    else:
        print("found jjfb:", jjfb, "sha1", sha1_file(jjfb))
    log_write("prepare_status.txt", f"jjfb_exists={jjfb.exists()}\n")

def cmd_install_apk(args):
    cfg = load_config(args.config)
    apk = ROOT / "bin" / "mrpoid.apk"
    if apk.exists():
        print("installing apk:", apk)
        rc, out = adb(cfg, ["install", "-r", str(apk)], timeout=120)
        print(out)
        log_write("install_apk.txt", out)
    else:
        print("bin/mrpoid.apk not present; skip install and use installed emulator if available.")
        log_write("install_apk.txt", "apk not present\n")

def push_dir(cfg, local, remote):
    # remove only target mythroad if explicitly configured? safer: don't rm, mkdir + push.
    adb(cfg, ["shell", "mkdir", "-p", remote], timeout=20)
    rc, out = adb(cfg, ["push", str(local), remote.rsplit("/",1)[0] + "/"], timeout=300)
    return out

def cmd_deploy(args):
    cfg = load_config(args.config)
    src = ROOT / "game_files" / "mythroad"
    remote_root = cfg.get("android_root", "/sdcard/mythroad")
    adb(cfg, ["shell", "mkdir", "-p", remote_root], timeout=20)
    # Push contents of mythroad directory into /sdcard/mythroad
    output = []
    for item in src.iterdir():
        rc, out = adb(cfg, ["push", str(item), remote_root + "/"], timeout=300)
        output.append(out)
        print(out)
    # also ensure sdk keys through adb echo, in case push failed for empty files
    key = cfg.get("sdk_key_content", "123456789012345")
    adb(cfg, ["shell", "mkdir", "-p", remote_root + "/gwy"], timeout=20)
    adb(cfg, ["shell", "sh", "-c", f"echo -n '{key}' > {remote_root}/sdk_key.dat"], timeout=20)
    adb(cfg, ["shell", "sh", "-c", f"echo -n '{key}' > {remote_root}/gwy/sdk_key.dat"], timeout=20)
    log_write("deploy.txt", "\n".join(output))

def detect_packages(cfg):
    rc, s = adb(cfg, ["shell", "pm", "list", "packages"], timeout=20)
    pkgs = [line.split(":",1)[1].strip() for line in s.splitlines() if line.startswith("package:")]
    candidates = []
    for cand in cfg.get("emulator_package_candidates", []):
        if cand in pkgs:
            candidates.append(cand)
    # fuzzy
    for p in pkgs:
        low = p.lower()
        if p not in candidates and any(k in low for k in ["mrpoid", "mythras", "vmrp", "mrp"]):
            candidates.append(p)
    return candidates

def resolve_activity(cfg, pkg):
    rc, s = adb(cfg, ["shell", "cmd", "package", "resolve-activity", "--brief", pkg], timeout=20)
    lines = [x.strip() for x in s.splitlines() if x.strip()]
    # last line often pkg/activity
    for line in reversed(lines):
        if "/" in line:
            return line
    return ""

def quote_shell(s):
    return "'" + s.replace("'", "'\\''") + "'"

def launch_am(cfg, am_args, tag, wait=5):
    cmd = ["shell", "am", "start"] + am_args
    rc, out = adb(cfg, cmd, timeout=30)
    log_write(f"launch_{tag}.txt", "CMD: adb " + " ".join(cmd) + "\n\n" + out)
    print(f"[{tag}] rc={rc}\n{out}")
    time.sleep(wait)
    return out

def cmd_launch(args):
    cfg = load_config(args.config)
    pkgs = detect_packages(cfg)
    game = cfg.get("game_mrp", "/sdcard/mythroad/gwy/jjfb.mrp")
    params = cfg.get("mr_param_candidates", [])
    wait_sec = int(cfg.get("direct_launch_wait_seconds", 35))
    all_log = [f"packages={pkgs}", f"game={game}"]

    # Start logcat capture in background to file
    logcat_path = ROOT / "logs" / f"logcat_launch_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    with open(logcat_path, "wb") as lf:
        proc = subprocess.Popen(adb_base(cfg) + ["logcat", "-v", "time"], stdout=lf, stderr=subprocess.STDOUT)
        time.sleep(1)
        adb(cfg, ["logcat", "-c"], timeout=10)

        # ACTION_VIEW variants
        mime_types = ["application/x-mrp", "application/mrp", "application/octet-stream", "*/*"]
        for mime in mime_types:
            out = launch_am(cfg, ["-a", "android.intent.action.VIEW", "-d", "file://" + game, "-t", mime],
                            "action_view_" + re.sub(r'[^a-zA-Z0-9]+','_',mime), wait=3)
            all_log.append(out)

        # Package explicit variants with extras
        for pkg in pkgs:
            comp = resolve_activity(cfg, pkg)
            if not comp:
                continue
            for i, param in enumerate(params):
                extras = [
                    "-n", comp,
                    "-e", "path", game,
                    "-e", "file", game,
                    "-e", "mrp", game,
                    "-e", "mrpPath", game,
                    "-e", "mrp_path", game,
                    "-e", "_mr_param", param,
                    "-e", "param", param,
                    "-e", "arg", param,
                    "-e", "nmrpname", "gwy/jjfb.mrp",
                ]
                out = launch_am(cfg, extras, f"explicit_{pkg}_{i}", wait=wait_sec)
                all_log.append(out)

            # Also launch package normally, maybe it auto-scans /sdcard/mythroad
            out = launch_am(cfg, ["-n", comp], f"normal_{pkg}", wait=8)
            all_log.append(out)

        try:
            proc.terminate()
            proc.wait(timeout=5)
        except Exception:
            proc.kill()

    log_write("launch_summary.txt", "\n\n".join(all_log))
    print("launch logs saved:", logcat_path)

def cmd_redirect(args):
    cfg = load_config(args.config)
    host = cfg.get("host_for_emulator", "10.0.2.2")
    ports = cfg.get("mock_ports", [21002,21003,20000,6009])
    lines = []
    # Try iptables root. This redirects all outbound tcp dport to host.
    for p in ports:
        for action in ["-D", "-A"]:
            cmd = f"iptables -t nat {action} OUTPUT -p tcp --dport {p} -j DNAT --to-destination {host}:{p}"
            rc, out = adb(cfg, ["shell", "su", "root", cmd], timeout=20)
            lines.append(f"$ {cmd}\nrc={rc}\n{out}\n")
    log_write("redirect_iptables.txt", "\n".join(lines))
    print("redirect attempted; see logs/redirect_iptables.txt")

def snapshot_remote(cfg, roots, phase):
    rows = ["phase,root,path,size,mtime,md5"]
    for root in roots:
        # find files
        rc, s = adb(cfg, ["shell", "sh", "-c", f"find {root} -type f 2>/dev/null"], timeout=60)
        files = [x.strip() for x in s.splitlines() if x.strip().startswith("/")]
        for f in files:
            rc1, stat = adb(cfg, ["shell", "sh", "-c", f"ls -l '{f}' 2>/dev/null"], timeout=10)
            rc2, md5 = adb(cfg, ["shell", "sh", "-c", f"md5sum '{f}' 2>/dev/null | cut -d' ' -f1"], timeout=10)
            size = ""
            mtime = stat.strip().replace(",", " ")
            rows.append(f'{phase},"{root}","{f}","{size}","{mtime}","{md5.strip()}"')
    return "\n".join(rows)

def cmd_snapshot(args):
    cfg = load_config(args.config)
    roots = [
        cfg.get("android_root", "/sdcard/mythroad") + "/gwy",
        "/sdcard/mythroad/240x320/gwy",
        "/storage/emulated/0/mythroad/gwy",
        "/storage/emulated/0/mythroad/240x320/gwy",
    ]
    content = snapshot_remote(cfg, roots, args.phase)
    name = f"snapshot_{args.phase}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    log_write(name, content)
    print("snapshot saved:", name)

def cmd_collect(args):
    cfg = load_config(args.config)
    # final dumps
    rc, s = adb(cfg, ["logcat", "-d", "-v", "time"], timeout=60)
    log_write(f"logcat_final_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt", s)
    rc, s = adb(cfg, ["shell", "dumpsys", "activity", "top"], timeout=30)
    log_write("dumpsys_activity_top.txt", s)

    zipname = ROOT / "logs" / f"feedback_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
    with zipfile.ZipFile(zipname, "w", zipfile.ZIP_DEFLATED) as z:
        for p in (ROOT / "logs").glob("*"):
            if p.is_file() and p.name != zipname.name:
                z.write(p, p.relative_to(ROOT))
    print("feedback zip:", zipname)

def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    for c in ["probe","prepare","install-apk","deploy","redirect","launch","collect"]:
        sp = sub.add_parser(c)
        sp.add_argument("--config", default="CONFIG.json")
    sp = sub.add_parser("snapshot")
    sp.add_argument("--config", default="CONFIG.json")
    sp.add_argument("--phase", default="pre")
    args = ap.parse_args()
    globals()["cmd_" + args.cmd.replace("-","_")](args)

if __name__ == "__main__":
    main()
