把你的 mythroad 文件树复制到这个目录。

最终推荐结构：

game_files/mythroad/
  gwy.mrp
  sdk_key.dat
  gwy/
    cfg.bin
    jjfb.mrp
    jjfbol/
    gbrwcore.mrp
    gbrwshell.mrp
    font.mrp
    resmng.mrp
    vdload.mrp
    dload.mrp
    reglogin.mrp

不要只放 jjfb.mrp，单独一个 jjfb.mrp 大概率缺少启动上下文和资源。
