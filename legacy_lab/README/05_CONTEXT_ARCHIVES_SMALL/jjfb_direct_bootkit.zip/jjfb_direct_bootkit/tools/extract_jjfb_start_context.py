#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from pathlib import Path
import argparse, re, json, struct

def decode_utf16be_fragment(blob):
    best = ""
    for start in range(len(blob)):
        for end in range(start+2, min(len(blob), start+96), 2):
            try:
                s = blob[start:end].decode("utf-16be", errors="ignore").strip("\x00")
            except Exception:
                continue
            if "机甲" in s or "风暴" in s:
                return s
            if len(s) > len(best) and any('\u4e00' <= ch <= '\u9fff' for ch in s):
                best = s
    return best

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cfg", help="path to gwy/cfg.bin")
    ap.add_argument("--index", type=int, default=36)
    args = ap.parse_args()
    p = Path(args.cfg)
    data = p.read_bytes()
    off = 1024 + args.index * 272
    rec = data[off:off+272]
    strings = [(m.start(), m.group().decode("ascii", errors="replace"))
               for m in re.finditer(rb"[\x20-\x7e]{3,}", rec)]
    target = next((s for _,s in strings if s.startswith("gwy/") and s.endswith(".mrp")), "")
    icon = next((s for _,s in strings if s.endswith(".gif")), "")
    m = re.search(rb"gwy/[a-z0-9]+\.mrp", rec)
    prefix = rec[max(0,m.start()-16):m.start()].hex() if m else ""
    print(json.dumps({
        "cfg": str(p), "index": args.index, "offset": off,
        "title": decode_utf16be_fragment(rec),
        "target": target, "icon": icon,
        "prefix16_before_target": prefix,
        "strings": strings,
        "param_candidates": [
            f"napptype=0_nextid=0_ncode=0_narg=0_narg1=0_nmrpname={target}_gwyblink",
            f"napptype=0_nextid=482_ncode=512_narg=0_narg1=1_nmrpname={target}_gwyblink",
            f"napptype=1_nextid=482_ncode=512_narg=0_narg1=1_nmrpname={target}_gwyblink",
        ] if target else []
    }, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
