#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
extract_jjfb_start_context.py

用途：
从 gwy/cfg.bin 中提取 index=36 的机甲风暴启动上下文，
输出 target、icon、title、raw record、候选 _mr_param。

不修改任何文件。
"""

from pathlib import Path
import argparse
import re
import json
import struct

def find_cfg(root: Path) -> Path:
    candidates = [
        root / "gwy" / "cfg.bin",
        root / "240x320" / "gwy" / "cfg.bin",
        root / "mythroad" / "gwy" / "cfg.bin",
        root / "mythroad" / "240x320" / "gwy" / "cfg.bin",
    ]
    for p in candidates:
        if p.exists():
            return p
    raise FileNotFoundError("未找到 gwy/cfg.bin，请用 --cfg 指定")

def decode_utf16be_fragment(blob: bytes) -> str:
    best = ""
    for start in range(len(blob)):
        for end in range(start + 2, min(len(blob), start + 80), 2):
            try:
                s = blob[start:end].decode("utf-16be", errors="ignore").strip("\x00")
            except Exception:
                continue
            if "机甲" in s or "风暴" in s:
                return s
            if len(s) > len(best) and any('\u4e00' <= ch <= '\u9fff' for ch in s):
                best = s
    return best

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".", help="mythroad 根目录或其上级目录")
    ap.add_argument("--cfg", default="", help="直接指定 cfg.bin")
    ap.add_argument("--index", type=int, default=36)
    args = ap.parse_args()

    cfg_path = Path(args.cfg) if args.cfg else find_cfg(Path(args.root))
    data = cfg_path.read_bytes()

    app_base = 1024
    record_size = 272
    off = app_base + args.index * record_size
    rec = data[off:off + record_size]
    if len(rec) != record_size:
        raise RuntimeError("记录长度不足")

    strings = [(m.start(), m.group().decode("ascii", errors="replace"))
               for m in re.finditer(rb"[\x20-\x7e]{3,}", rec)]
    target = next((s for _, s in strings if s.startswith("gwy/") and s.endswith(".mrp")), "")
    icon = next((s for _, s in strings if s.endswith(".gif")), "")
    title = decode_utf16be_fragment(rec)

    m = re.search(rb"gwy/[a-z0-9]+\.mrp", rec)
    prefix16 = ""
    fields = {}
    if m:
        start = max(0, m.start() - 16)
        prefix = rec[start:m.start()]
        prefix16 = prefix.hex()
        if len(prefix) == 16:
            w = [prefix[i:i+4] for i in range(0, 16, 4)]
            fields = {
                "word0_be": struct.unpack(">I", w[0])[0],
                "word1_hex": w[1].hex(),
                "word1_be": struct.unpack(">I", w[1])[0],
                "word2_be": struct.unpack(">I", w[2])[0],
                "word3_be": struct.unpack(">I", w[3])[0],
                "word0_le": struct.unpack("<I", w[0])[0],
                "word1_le": struct.unpack("<I", w[1])[0],
                "word2_le": struct.unpack("<I", w[2])[0],
                "word3_le": struct.unpack("<I", w[3])[0],
            }

    # 基于当前已知 jjfb 记录生成候选参数
    params = []
    if target:
        params.append(f"napptype=0_nextid=0_ncode=0_narg=0_narg1=0_nmrpname={target}_gwyblink")
        params.append(f"napptype=0_nextid=482_ncode=512_narg=0_narg1=1_nmrpname={target}_gwyblink")
        params.append(f"napptype=1_nextid=482_ncode=512_narg=0_narg1=1_nmrpname={target}_gwyblink")

    result = {
        "cfg": str(cfg_path),
        "index": args.index,
        "record_offset": off,
        "title": title,
        "icon": icon,
        "target": target,
        "strings": strings,
        "prefix16_before_target": prefix16,
        "fields_guess": fields,
        "candidate_mr_params": params,
        "raw_record_hex": rec.hex(),
    }

    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
