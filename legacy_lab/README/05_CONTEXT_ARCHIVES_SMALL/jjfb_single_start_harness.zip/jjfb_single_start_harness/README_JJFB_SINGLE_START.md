# 机甲风暴：单游戏启动方式分析与“单游戏宿主”方案

## 1. 结论先说

已经能把启动方式收窄到可实现的程度：

```text
不是 jjfb.mrp 裸启动
而是 Mythroad/MRP 宿主给 jjfb.mrp 注入启动上下文，再运行它
```

原始完整链路是：

```text
/sdcard/mythroad/gwy.mrp
  ↓
gwy.mrp 内 cfunction.ext 加载公共模块
  ↓
gwy/gamelist.mrp 读取 gwy/cfg.bin
  ↓
cfg.bin index 36 = 机甲风暴(火爆公测)
  ↓
target = gwy/jjfb.mrp
  ↓
gamelist/gbrwcore 构造 gwyblink / nmrpname 启动参数
  ↓
宿主 runapp/startGame 启动 gwy/jjfb.mrp
```

所以“自己做模拟器只启动这个游戏”的最短路线不是先实现完整冒泡大厅，而是做一个：

```text
JJFB-only Mythroad host
```

也就是一个只会启动 `gwy/jjfb.mrp` 的小宿主。

---

## 2. 静态证据

### 2.1 cfg.bin 机甲风暴条目

`gwy/cfg.bin` 里 index 36：

```text
title  = 机甲风暴(火爆公测)
icon   = ng_jjfb.gif
target = gwy/jjfb.mrp
```

对应 272B app record 里，目标路径前的关键字节：

```text
00000000 01e20000 00000200 00000001 6777792f6a6a66622e6d7270
                                    ^ gwy/jjfb.mrp
```

这个字段组很可能就是 gamelist 后续构造 `napptype/nextid/ncode/narg/narg1/nmrpname` 的来源之一。

### 2.2 gamelist.ext 启动参数格式

`gwy/gamelist.mrp -> gamelist.ext` 里存在：

```text
gwy/cfg.bin
gwy/%s.mrp
%s.mrp
gwy.mrp
gwyblink
napptype
nextid
ncode
narg
narg1
nmrpname
bapptype
bextid
bcode
barg
barg1
bmrpname
napptype=%d_nurl=%s_gwyblink
napptype=%d_nextid=%d_ncode=%d_narg=%d_narg1=%d_nmrpname=%s_gwyblink
```

这基本说明它不是直接 `exec("gwy/jjfb.mrp")`，而是带参数启动。

### 2.3 gbrwcore.ext 最终启动接口

`gwy/gbrwcore.mrp -> gbrwcore.ext` 里存在：

```text
lib.startGame
lib.runapp
lib.download
lib.loadurl
lib.getFileVersion
lib.isFileOnServerNewer
```

所以最终启动很可能是 `gbrwcore` 暴露给 gamelist/脚本的 `runapp/startGame`。

### 2.4 jjfb.mrp 自己的启动脚本

`gwy/jjfb.mrp -> start.mr` 里有：

```text
sdk_key.dat
IMEI
hstype
cann`t find sdk key!
_mr_param
mrc_loader.ext
robotol.ext
```

说明直接启动 `jjfb.mrp` 时，至少要准备：

```text
/sdcard/mythroad/sdk_key.dat
/sdcard/mythroad/gwy/sdk_key.dat
启动参数 _mr_param
工作目录 /sdcard/mythroad
资源目录 /sdcard/mythroad/gwy/jjfbol/
```

---

## 3. “只启动这个游戏”的推荐技术路线

### 路线 A：真实从零做模拟器，不推荐马上做

要真正从零写模拟器，需要实现：

```text
1. MRP 容器加载
2. start.mr 字节码解释器
3. ARM/Thumb .ext 模块执行器
4. Mythroad 系统 API：文件、屏幕、键盘、定时器、网络、声音
5. 网络 mock：21002 / 20000 / 游戏业务协议
```

因为 `jjfb.mrp` 里大量逻辑在 `.ext`，例如 `robotol.ext`、`mainmenumodule.ext`、`gameattackmodule.ext`。这些是 ARM/Thumb 机器码，不是脚本源码。

所以从零写完整模拟器成本很高。

### 路线 B：做“单游戏宿主”，推荐

不要从零模拟全部 MRP。直接复用现有 Mythroad/Mrpoid 运行内核，只改启动入口：

```text
宿主启动时不进入 cookie/gwy/gamelist
而是直接：
  cwd = /sdcard/mythroad
  mrp = /sdcard/mythroad/gwy/jjfb.mrp
  _mr_param = 候选 gwyblink 参数
  sysinfo = 固定 IMEI / IMSI / hstype
  file root = /sdcard/mythroad
  network = 指向本地 mock
```

这就是“只启动机甲风暴”的最可行形态。

---

## 4. 直接启动时应准备的文件树

最小文件树建议：

```text
/sdcard/mythroad/
  sdk_key.dat
  gwy.mrp                  可选，保留兼容
  gwy/
    sdk_key.dat
    cfg.bin                可选，保留兼容
    jjfb.mrp
    jjfbol/
      downVersion
      *.mrp
      *.mrp.v
    gifs/
      ng_jjfb.gif          可选
```

更稳一点就把这些公共模块也保留：

```text
gwy/gbrwcore.mrp
gwy/gbrwshell.mrp
gwy/font.mrp
gwy/resmng.mrp
gwy/vdload.mrp
gwy/dload.mrp
gwy/reglogin.mrp
```

因为 `jjfb` 内部有可能仍调用公共函数或公共资源。

---

## 5. 启动参数候选

由于 cfg 字段还没有完全还原，先做三个候选。让单游戏宿主按顺序试。

### Candidate 0：最小参数

```text
napptype=0_nextid=0_ncode=0_narg=0_narg1=0_nmrpname=gwy/jjfb.mrp_gwyblink
```

### Candidate 1：按 cfg 记录直读的 4 字段

从 `gwy/jjfb.mrp` 前 16B 字段：

```text
00000000 01e20000 00000200 00000001
```

构造：

```text
napptype=0_nextid=482_ncode=512_narg=0_narg1=1_nmrpname=gwy/jjfb.mrp_gwyblink
```

解释：
- `01e2` 很可能是 app/code 类字段，十进制 482；
- `00000200` 可能对应 512；
- 最后一组 `00000001` 对应该条目的某个启动/分类字段。

### Candidate 2：保守启动型

```text
napptype=1_nextid=482_ncode=512_narg=0_narg1=1_nmrpname=gwy/jjfb.mrp_gwyblink
```

如果 Candidate 1 不动，试 Candidate 2。

---

## 6. 单游戏宿主伪代码

```python
host = MythroadHost()

host.set_root("/sdcard/mythroad")
host.set_cwd("/sdcard/mythroad")
host.set_screen(320, 480)

host.set_sysinfo({
    "IMEI": "869169020812718",
    "IMSI": "460006887846701",
    "hstype": "android",
})

host.set_file("sdk_key.dat", b"123456789012345")
host.set_file("gwy/sdk_key.dat", b"123456789012345")

host.set_param(
    "napptype=0_nextid=482_ncode=512_narg=0_narg1=1_nmrpname=gwy/jjfb.mrp_gwyblink"
)

host.redirect_network({
    "21002": "127.0.0.1:21002",
    "20000": "127.0.0.1:20000",
})

host.run_mrp("gwy/jjfb.mrp")
```

---

## 7. 下一步验证标准

只要单游戏宿主能把直接启动结果从：

```text
cann`t find sdk key!
MRP 启动失败
立即闪退
```

推进到：

```text
机甲风暴 loading 图
正在登录 / 正在获取角色资料
连接超时
网络请求 20000
```

就说明“只启动游戏”的路线成立。

到这个阶段，就不需要再通过 gwy/gamelist 的公共更新门槛了，后续直接 mock `jjfb/robotol` 的游戏业务协议。

---

## 8. 最关键判断

```text
可以做“只启动机甲风暴”的宿主。
但不是从零完整模拟器，而是先做 JJFB-only Mythroad host。
核心是：
1. 复用/实现 MRP runtime；
2. 直接加载 gwy/jjfb.mrp；
3. 注入 _mr_param；
4. 注入 sdk_key/sysinfo；
5. 文件根保持 /sdcard/mythroad；
6. 网络指向本地 mock。
```
