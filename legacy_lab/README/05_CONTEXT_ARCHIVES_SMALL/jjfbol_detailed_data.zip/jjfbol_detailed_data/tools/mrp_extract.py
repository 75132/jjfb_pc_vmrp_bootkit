#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
斯凯 / Mythroad MRP 资源包解析器

功能：
1. 解析 MRPG 容器目录并释放所有条目；
2. 自动识别并解开条目外层 GZIP；
3. 对 GB18030/UTF-8 文本生成可读 TXT；
4. 把 @record|@key=value 格式转换为 JSON / CSV；
5. 对 .ext 保留压缩版与解压后的 MRPGCMAP ARM 模块；
6. 生成 manifest.json 和 summary.json。

仅使用 Python 标准库。
"""
from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import re
import struct
from collections import defaultdict
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable

MAGIC = b"MRPG"
GZIP_MAGIC = b"\x1f\x8b"
MAX_NAME_LEN = 4096


@dataclass
class Entry:
    name: str
    offset: int
    stored_size: int
    flags: int
    compressed: bool = False
    unpacked_size: int | None = None
    sha256: str | None = None


def safe_name(name: str) -> str:
    """防止包内文件名逃逸输出目录，同时尽量保留原始命名。"""
    name = name.replace("\\", "/")
    parts = [p for p in name.split("/") if p not in ("", ".", "..")]
    cleaned = "__".join(parts) or "unnamed.bin"
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", cleaned)


def decode_name(raw: bytes) -> str:
    for enc in ("gb18030", "utf-8", "latin1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            pass
    return raw.decode("latin1", errors="replace")


def parse_mrp(data: bytes) -> tuple[list[Entry], dict]:
    if len(data) < 16 or data[:4] != MAGIC:
        raise ValueError("不是有效的 MRPG/MRP 文件")

    index_hint, declared_size, directory_offset = struct.unpack_from("<III", data, 4)
    if not (16 <= directory_offset < len(data)):
        raise ValueError(f"目录偏移异常: 0x{directory_offset:X}")

    cursor = directory_offset
    first_data_offset = len(data)
    entries: list[Entry] = []

    # 目录是变长项；当游标抵达最小数据偏移时停止。
    while cursor + 4 <= len(data) and cursor < first_data_offset:
        name_len = struct.unpack_from("<I", data, cursor)[0]
        if name_len < 2 or name_len > MAX_NAME_LEN:
            break
        entry_end = cursor + 4 + name_len + 12
        if entry_end > len(data):
            break

        raw_name = data[cursor + 4 : cursor + 4 + name_len]
        if raw_name[-1] != 0:
            break
        name = decode_name(raw_name[:-1])
        offset, size, flags = struct.unpack_from("<III", data, cursor + 4 + name_len)
        if offset > len(data) or size > len(data) - offset:
            # 目录末尾通常跟着 “启动文件名+大小” 的 trailer，外形像目录项，
            # 但没有完整的 offset/size/flags；遇到这种情况即视为目录结束。
            break

        entries.append(Entry(name=name, offset=offset, stored_size=size, flags=flags))
        first_data_offset = min(first_data_offset, offset)
        cursor = entry_end

    trailer = data[cursor:first_data_offset]
    header = {
        "magic": data[:4].decode("ascii", errors="replace"),
        "index_hint": index_hint,
        "declared_size": declared_size,
        "actual_size": len(data),
        "directory_offset": directory_offset,
        "directory_end": cursor,
        "first_data_offset": first_data_offset,
        "entry_count": len(entries),
        "directory_trailer_hex": trailer.hex(),
    }
    return entries, header


def maybe_gunzip(blob: bytes) -> tuple[bytes, bool, str | None]:
    if blob.startswith(GZIP_MAGIC):
        try:
            return gzip.decompress(blob), True, None
        except Exception as exc:
            return blob, False, f"GZIP 解压失败: {exc}"
    return blob, False, None


def decode_text(blob: bytes) -> tuple[str | None, str | None]:
    # NUL 密度太高通常是图片/机器码，避免误判。
    if blob and blob.count(0) / len(blob) > 0.08:
        return None, None
    for enc in ("utf-8-sig", "gb18030", "gbk"):
        try:
            text = blob.decode(enc)
            # 过滤明显的二进制误解码结果。
            printable = sum(ch.isprintable() or ch in "\r\n\t" for ch in text)
            if not text or printable / len(text) >= 0.92:
                return text, enc
        except UnicodeDecodeError:
            continue
    return None, None


FIELD_RE = re.compile(r"(?:^|\|)@([A-Za-z_][A-Za-z0-9_]*)=")
RECORD_RE = re.compile(r"^@([^|=\s]+)\|")
ASSIGN_RE = re.compile(r"^@([^=\s]+)=(.*)$")
DEFINE_RE = re.compile(r"^#define\s+(\w+)\s+\(([^)]*)\)\s*(?://\s*(.*))?$")


def parse_record_line(line: str) -> tuple[str, dict[str, str]] | None:
    m = RECORD_RE.match(line)
    if not m:
        return None
    record_type = m.group(1)
    matches = list(FIELD_RE.finditer(line))
    fields: dict[str, str] = {}
    for i, fm in enumerate(matches):
        start = fm.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(line)
        # 下一字段从 “|@” 开始，因此不会误切 value 内普通的竖线。
        fields[fm.group(1)] = line[start:end]
    return record_type, fields


def parse_mrp_text(text: str, source: str) -> dict:
    records: dict[str, list[dict[str, str]]] = defaultdict(list)
    assignments: list[dict[str, object]] = []
    defines: list[dict[str, object]] = []
    comments: list[dict[str, object]] = []
    unparsed: list[dict[str, object]] = []

    for lineno, original in enumerate(text.splitlines(), 1):
        line = original.strip()
        if not line:
            continue
        if line.startswith("///") or line.startswith("//") or line.startswith("（"):
            comments.append({"line": lineno, "text": original})
            continue
        rec = parse_record_line(line)
        if rec:
            record_type, fields = rec
            fields["_line"] = str(lineno)
            records[record_type].append(fields)
            continue
        m = ASSIGN_RE.match(line)
        if m:
            assignments.append({"line": lineno, "key": m.group(1), "value": m.group(2)})
            continue
        m = DEFINE_RE.match(line)
        if m:
            defines.append({"line": lineno, "name": m.group(1), "value": m.group(2), "comment": m.group(3) or ""})
            continue
        unparsed.append({"line": lineno, "text": original})

    return {
        "source": source,
        "assignments": assignments,
        "defines": defines,
        "comments": comments,
        "record_groups": dict(records),
        "unparsed": unparsed,
    }


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    if not rows:
        return
    keys: list[str] = []
    seen = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                keys.append(key)
    # 把行号放最后，方便查看数据字段。
    if "_line" in keys:
        keys.remove("_line")
        keys.append("_line")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def special_mapvalue(parsed: dict) -> list[dict[str, str]]:
    """把 mapValue 的连续 @mapName/@mapTileCount/@detail 合并成地图记录。"""
    maps: list[dict[str, str]] = []
    current: dict[str, str] | None = None
    for item in parsed["assignments"]:
        key, value = str(item["key"]), str(item["value"])
        if key == "mapName":
            if current:
                maps.append(current)
            current = {"mapName": value, "_line": str(item["line"])}
        elif current is not None and key in ("mapTileCount", "detail"):
            current[key] = value
    if current:
        maps.append(current)
    return maps


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    stem, suffix = path.stem, path.suffix
    i = 2
    while True:
        candidate = path.with_name(f"{stem}_{i}{suffix}")
        if not candidate.exists():
            return candidate
        i += 1


def process_mrp(mrp_path: Path, out_root: Path, source_label: str) -> dict:
    raw = mrp_path.read_bytes()
    entries, header = parse_mrp(raw)
    pack_dir = out_root / "unpacked" / safe_name(source_label)
    text_dir = out_root / "decoded_text"
    json_dir = out_root / "structured_json"
    csv_dir = out_root / "csv"
    ext_dir = out_root / "ext_uncompressed"
    pack_dir.mkdir(parents=True, exist_ok=True)

    manifest_entries = []
    text_summaries = []

    for entry in entries:
        stored = raw[entry.offset : entry.offset + entry.stored_size]
        unpacked, compressed, error = maybe_gunzip(stored)
        entry.compressed = compressed
        entry.unpacked_size = len(unpacked)
        entry.sha256 = hashlib.sha256(unpacked).hexdigest()

        original_path = unique_path(pack_dir / safe_name(entry.name))
        original_path.write_bytes(stored)

        effective_path = original_path
        if compressed:
            effective_path = unique_path(pack_dir / (safe_name(entry.name) + ".gunzip"))
            effective_path.write_bytes(unpacked)

        item = asdict(entry)
        item.update({
            "extract_path": str(original_path.relative_to(out_root)),
            "gunzip_path": str(effective_path.relative_to(out_root)) if compressed else None,
            "error": error,
        })

        # 解压后的 EXT 是 MRPGCMAP + ARM 代码，另存到集中目录。
        if entry.name.lower().endswith(".ext") and unpacked.startswith(b"MRPGCMAP"):
            ext_dir.mkdir(parents=True, exist_ok=True)
            ext_path = unique_path(ext_dir / f"{safe_name(source_label)}__{safe_name(entry.name)}")
            ext_path.write_bytes(unpacked)
            item["ext_format"] = "MRPGCMAP"
            item["arm_code_offset"] = 8
            item["ext_output"] = str(ext_path.relative_to(out_root))

        text, encoding = decode_text(unpacked)
        likely_text = entry.name.lower().endswith((".txt", ".ini", ".cfg", ".csv", ".xml", ".json"))
        if text is not None and (likely_text or "@" in text[:500]):
            base = f"{safe_name(source_label)}__{safe_name(entry.name)}"
            txt_path = unique_path(text_dir / (base + ".utf8.txt"))
            txt_path.parent.mkdir(parents=True, exist_ok=True)
            txt_path.write_text(text, encoding="utf-8-sig", newline="")

            parsed = parse_mrp_text(text, f"{source_label}:{entry.name}")
            json_path = unique_path(json_dir / (base + ".json"))
            json_path.parent.mkdir(parents=True, exist_ok=True)
            json_path.write_text(json.dumps(parsed, ensure_ascii=False, indent=2), encoding="utf-8")

            group_counts = {}
            for record_type, rows in parsed["record_groups"].items():
                group_counts[record_type] = len(rows)
                write_csv(csv_dir / f"{base}__{safe_name(record_type)}.csv", rows)

            maps = special_mapvalue(parsed)
            if maps:
                parsed_maps_path = json_dir / f"{base}__maps.json"
                parsed_maps_path.write_text(json.dumps(maps, ensure_ascii=False, indent=2), encoding="utf-8")
                write_csv(csv_dir / f"{base}__maps.csv", maps)

            item.update({
                "text_encoding": encoding,
                "decoded_text": str(txt_path.relative_to(out_root)),
                "structured_json": str(json_path.relative_to(out_root)),
                "record_counts": group_counts,
                "assignment_count": len(parsed["assignments"]),
            })
            text_summaries.append({
                "pack": source_label,
                "entry": entry.name,
                "encoding": encoding,
                "characters": len(text),
                "lines": len(text.splitlines()),
                "record_counts": group_counts,
                "assignment_count": len(parsed["assignments"]),
            })

        manifest_entries.append(item)

    return {
        "source": str(mrp_path),
        "label": source_label,
        "header": header,
        "entries": manifest_entries,
        "text_resources": text_summaries,
    }


def iter_mrp_files(input_path: Path) -> Iterable[tuple[Path, str]]:
    if input_path.is_file():
        yield input_path, input_path.name
    else:
        for p in sorted(input_path.rglob("*.mrp")):
            yield p, str(p.relative_to(input_path))


def main() -> int:
    ap = argparse.ArgumentParser(description="解析斯凯/Mythroad MRP 包，自动 GZIP、文本、JSON、CSV")
    ap.add_argument("input", type=Path, help="单个 .mrp 文件或包含 .mrp 的目录")
    ap.add_argument("-o", "--output", type=Path, default=Path("mrp_output"), help="输出目录")
    args = ap.parse_args()

    if not args.input.exists():
        ap.error(f"输入不存在: {args.input}")
    args.output.mkdir(parents=True, exist_ok=True)

    manifests = []
    failures = []
    for path, label in iter_mrp_files(args.input):
        try:
            manifests.append(process_mrp(path, args.output, label))
            print(f"[OK] {label}")
        except Exception as exc:
            failures.append({"source": str(path), "error": str(exc)})
            print(f"[FAIL] {label}: {exc}")

    manifest = {"packs": manifests, "failures": failures}
    (args.output / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    text_resources = [r for m in manifests for r in m["text_resources"]]
    summary = {
        "pack_count": len(manifests),
        "failure_count": len(failures),
        "entry_count": sum(len(m["entries"]) for m in manifests),
        "text_resource_count": len(text_resources),
        "text_resources": text_resources,
    }
    (args.output / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
