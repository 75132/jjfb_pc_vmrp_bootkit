#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""处理斯凯 MRP 中的 .ext：自动 GZIP，验证 MRPGCMAP，切出 ARM 代码并提取 ASCII 字符串。"""
from __future__ import annotations
import argparse, gzip, json, re
from pathlib import Path

GZIP_MAGIC = b"\x1f\x8b"
EXT_MAGIC = b"MRPGCMAP"


def unique(path: Path) -> Path:
    if not path.exists():
        return path
    for i in range(2, 10000):
        p = path.with_name(f"{path.stem}_{i}{path.suffix}")
        if not p.exists():
            return p
    raise RuntimeError("无法生成唯一输出名")


def process(path: Path, out: Path) -> dict:
    blob = path.read_bytes()
    was_gzip = blob.startswith(GZIP_MAGIC)
    raw = gzip.decompress(blob) if was_gzip else blob

    base = path.name
    raw_path = unique(out / f"{base}.unpacked")
    raw_path.write_bytes(raw)

    result = {
        "source": str(path),
        "stored_size": len(blob),
        "gzip": was_gzip,
        "unpacked_size": len(raw),
        "magic": raw[:8].decode("ascii", errors="replace"),
        "arm_code_offset": None,
        "outputs": {"unpacked": str(raw_path)},
    }

    if raw.startswith(EXT_MAGIC):
        arm = raw[8:]
        arm_path = unique(out / f"{base}.arm.bin")
        arm_path.write_bytes(arm)
        result["arm_code_offset"] = 8
        result["outputs"]["arm_binary"] = str(arm_path)

    strings = [m.group().decode("ascii") for m in re.finditer(rb"[\x20-\x7e]{4,}", raw)]
    strings_path = unique(out / f"{base}.strings.txt")
    strings_path.write_text("\n".join(strings), encoding="utf-8")
    result["ascii_string_count"] = len(strings)
    result["outputs"]["strings"] = str(strings_path)
    return result


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path, help="单个 .ext 或包含 .ext 的目录")
    ap.add_argument("-o", "--output", type=Path, default=Path("ext_output"))
    ns = ap.parse_args()
    ns.output.mkdir(parents=True, exist_ok=True)
    files = [ns.input] if ns.input.is_file() else sorted(ns.input.rglob("*.ext"))
    results = []
    for p in files:
        try:
            r = process(p, ns.output)
            results.append(r)
            print(f"[OK] {p}: {r['magic']}, ARM offset={r['arm_code_offset']}")
        except Exception as e:
            results.append({"source": str(p), "error": str(e)})
            print(f"[FAIL] {p}: {e}")
    (ns.output / "ext_manifest.json").write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
