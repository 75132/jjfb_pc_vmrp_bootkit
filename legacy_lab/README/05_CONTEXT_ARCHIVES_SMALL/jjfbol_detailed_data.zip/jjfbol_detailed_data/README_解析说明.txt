早期斯凯 / Mythroad MRP 游戏资源解析结果
=========================================

一、本样本的结论
----------------
1. 外层 .mrp 是 MRPG 容器，不是 ZIP。
2. 容器条目普遍又套了一层 GZIP；GZIP 文件头为 1F 8B 08。
3. .ext 解开 GZIP 后以 ASCII “MRPGCMAP” 开头：
   - 0x00~0x07：MRPGCMAP 标记
   - 0x08 起：ARM 32 位小端机器码
   因而 .ext 是可执行模块，不是能直接按表格读取的数据文件。
4. 本游戏的怪物、道具、世界地图、碰撞、人物及提示语等详细数据，主要位于子 .mrp 内的 .txt 条目；解开 GZIP 后用 GB18030/GBK 解码即可。

二、对上传样本的实测结果
------------------------
- 成功解析 MRP 包：60 个
- 成功释放目录条目：1036 个
- 解出 MRPGCMAP 扩展模块：21 个
- 可读数据文本：10 份
- 道具类型：18 条
- 道具详情：607 条
- 世界地图节点：22 条
- 地图通行/碰撞配置：22 组
- 地图人物形象：114 条
- 怪物记录：实际 469 行
- 武器图像映射：34 条
- 盾牌图像映射：33 条
- 枪械图像映射：26 条
- 翅膀图像映射：26 条
- 等待提示语：15 条

注意：monster.txt 顶部写的是 @count=449，但文件实际含 469 条 @monster 记录，
共有 462 个不同 id，且 395、396、424、434、435、437、438 等 id 重复。
这是源数据自身的不一致，不是 CSV 解析造成的；后追加的活动/特殊怪物很可能未同步修改 @count。

三、输出目录
------------
csv/
  最方便直接查看的数据表。Excel/WPS 可直接打开，编码为 UTF-8 BOM。

structured_json/
  完整结构化结果；保留字段、原始行号、全局赋值、#define 和未解析行。

decoded_text/
  从包内解压并转换为 UTF-8 的原始文本，适合核对。

ext_uncompressed/
  已去掉 GZIP 的 .ext，开头是 MRPGCMAP，可导入 Ghidra/radare2。

unpacked/
  每个 MRP 的全部原始条目；若条目是 GZIP，还会生成 .gunzip 文件。

manifest.json
  每个包、条目偏移、压缩状态、大小、SHA-256、输出路径。

summary.json
  汇总统计。

四、复用脚本
------------
解析单个 MRP：
  python mrp_extract.py game.mrp -o game_output

递归解析一个目录：
  python mrp_extract.py unpacked_folder -o all_output

单独处理已经拿到的 EXT：
  python ext_prepare.py module.ext -o ext_output

五、MRP 目录结构（由本样本实测）
--------------------------------
文件头：
  0x00  char[4]  "MRPG"
  0x04  uint32   索引相关字段（具体官方命名不确定）
  0x08  uint32   整包大小
  0x0C  uint32   目录起始偏移；本样本为 0xF0

变长目录项：
  uint32 name_len        文件名字节数，包含末尾 NUL
  byte   name[name_len]  通常按 GB18030/ASCII 解码
  uint32 data_offset
  uint32 stored_size
  uint32 flags           本样本均为 0

目录之后还有一段启动文件 trailer（例如 start.mr + 大小），不应误当成普通目录项。

六、逆向 EXT 的推荐设置
----------------------
Ghidra：
  File -> Import File -> Raw Binary
  Language 选 ARM little-endian 32-bit（ARMv5/兼容版本）
  Image Base 可先设 0
  从地址 0x08 开始反汇编

GNU ARM objdump：
  arm-linux-gnueabi-objdump -b binary -m arm -D --start-address=0x8 module.ext

radare2：
  r2 -a arm -b 32 -s 8 module.ext
  aaa
  afl
  iz

若目标只是怪物、道具、地图等数值，不建议先硬啃 EXT；优先检查 ext 中调用/引用的资源文件名，
再去相应子 MRP 的 TXT 条目中提取。EXT 更适合分析战斗公式、流程控制、协议和动态计算逻辑。
