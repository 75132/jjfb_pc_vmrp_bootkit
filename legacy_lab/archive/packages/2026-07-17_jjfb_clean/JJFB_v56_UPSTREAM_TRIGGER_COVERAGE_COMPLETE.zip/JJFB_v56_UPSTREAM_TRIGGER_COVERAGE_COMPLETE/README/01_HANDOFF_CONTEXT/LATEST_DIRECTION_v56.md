# LATEST DIRECTION — v56

当前不再研究“谁写 ui_mode”，该 writer 已锁定为 `0x2FC418`。v56 只研究为何三条自然上游都没有调用 `0x2DADC4`。

优先级：

1. 检查 `0x2F5404` 是否被注册但未由平台调度；
2. 检查 family dispatcher 是否永远只有 app=9、缺 app=0xC0；
3. 检查事件队列是否缺少 event 5/12；
4. 禁止 FORCE 0x45，禁止 AC8/progress，禁止主动注入目标事件。
