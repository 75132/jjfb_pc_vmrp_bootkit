# v56 Upstream Trigger Static Map

## 核心结论

v55 的三个直接调用点属于三种不同上游：

| 直接调用点 | 所在上游 | 自然触发条件 |
|---|---|---|
| `0x2E4066` | `0x2E2520` 事件分派 | 事件码 5 或 12 |
| `0x2FECA2` | `0x2FEBBC` 启动/重置函数 | 多个内部 caller；family app=0xC0 是一条明确入口 |
| `0x305EF4` | `0x305EB8` 周期门 | 注册回调 `0x2F5404` 被平台实际调度后到达 |

### 路径 A：事件队列

```text
0x2DC80C -> 0x2DC8D4 -> 0x2E2520
0x2E7B7C -> 0x2E7B9E -> 0x2E2520
                                   event 5/12
                                      -> 0x2E4066 -> 0x2DADC4
```

`event=0x13` 不会走这条自然 writer 链。

### 路径 B：family 启动/重置

`0x30D300` 的跳表只有在 `app=0xC0` 时到达 `0x30DC44 -> 0x2FEBBC`。v55 日志只有 `app=9`。

### 路径 C：平台回调

`0x2F5404` 没有普通 BL caller，而以 Thumb 函数指针 `0x2F5405` 传给 `0x3054A4`。这是典型的注册式回调：

```text
register callback 0x2F5405
       -> platform invokes 0x2F5404
       -> 0x2F5734 -> 0x305EB8
       -> conditional 0x305EF4 -> 0x2DADC4
```

因此 v56 最重要的判据是：**回调是否注册但从未被 host 调用。**
