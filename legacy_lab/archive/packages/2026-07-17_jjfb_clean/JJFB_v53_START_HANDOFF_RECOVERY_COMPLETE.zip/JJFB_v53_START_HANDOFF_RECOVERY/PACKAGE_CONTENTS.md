# v53 完整包内容

- `RUN_V53_START_HANDOFF_RECOVERY.ps1`：构建、运行、哈希保护、报告生成一体脚本。
- `runtime/.../bridge.c`：正式并入 `br_log → ext_base+0xD4` hook。
- `runtime/.../vmrp.c`：MR_IGNORE 三重后置条件恢复与 host `6→8→0`。
- `runtime/.../header/bridge.h`：别名/robotol 状态接口。
- `patches/v53_start_handoff_recovery.patch`：相对 v52 的增量补丁。
- `scripts/v53_audit_start_handoff.py`：canonical MRP 与源码契约静态审计。
- `scripts/v53_analyze_start_handoff_log.py`：Windows 实测日志自动判定。
- `scripts/v51_generate_sdk_key.py`：48 字节合法 SDK key 生成器。
- `sdk_key/sdk_key.dat`：默认 VMRP 身份对应的 48 字节 key。
- `reports/`：实施、证据、静态审计、编译检查、模拟分析和 dry-run 结果。
- `README/01_HANDOFF_CONTEXT/LATEST_DIRECTION_v53.md`：新对话接手时的最新路线。
- `PACKAGE_MANIFEST.sha256`：包内文件逐项 SHA-256。
