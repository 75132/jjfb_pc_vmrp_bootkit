# Phase 6P quick read

- True verdict: MID_SUCCESS (`GAMELIST_STARTED_AFTER_CONTINUE`).
- Trust `phase6p_verdict.md` and `CONCLUSION.md`; `phase6p_shell_core_continue_report.txt` has contradictory HIGH_SUCCESS / export=true values and should be treated as stale/report-generator conflict.
- Achieved: shell core continued past gbrwcore; gamelist started; gamelist.ext entry observed.
- Not achieved: cfg36 build, post-update, export call, native runapp, jjfb natural open, strCom.
- Slot call count is 0, so do not expand slot API matrix.
- New blocker: `dsm:cfunction.ext` ENTRY_ARGUMENT fault at `0x8CC00`, invalid address `0xE58F8FE0`, classified as `WRONG_HELPER_CALL_MISSING_P`.
- Also fix `gamelist.mrp` member_view: static package has `reg.ext` and `gamelist.ext`, but runtime says `reg_primary failed` and fileopen uses canonical gamelist.mrp rather than generated member_view.
